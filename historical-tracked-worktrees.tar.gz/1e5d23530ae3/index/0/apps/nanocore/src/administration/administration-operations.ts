import {
  type ADMINISTRATION_ENTRY_OPERATION_DEFINITIONS,
  type SubmitAdministrationConversationResponse,
  SubmitAdministrationConversationResponseSchema,
} from '@openkit/app-api-schemas';
import type { OpenKitNanoHostConfig } from '@openkit/config-schema';
import type { ActorRef } from '@openkit/protocol';
import { deriveEntityId } from '@openkit/protocol';
import { z } from 'zod';
import type { Actor } from '../auth/identity.js';
import {
  DeploymentAdminRequiredError,
  requireCurrentDeploymentAdmin,
} from '../auth/operation-authorizer.js';
import { createAdministrationConfiguration } from '../config/administration-configuration.js';
import type { CoreMode } from '../config/mode.js';
import type { RuntimeConfigManager } from '../config/runtime-config.js';
import { findWorkspaceConfig, type RuntimeConfigSnapshot } from '../config/runtime-config.js';
import type { RuntimeConfigFileService } from '../config/runtime-config-files.js';
import { RuntimeConfigFileServiceError } from '../config/runtime-config-files.js';
import { assembleBuiltInSystemPrompt } from '../internal-agents/builtin-prompts.js';
import { createInternalAgentGatewayProvider } from '../internal-agents/gateway-provider.js';
import { type AgentMessage, runInternalAgentLoop } from '../internal-agents/internal-agent-loop.js';
import { resolveInternalRoleProfile } from '../internal-agents/profile-resolver.js';
import { redactInternalAgentText } from '../internal-agents/redaction.js';
import {
  ALREADY_DECIDED_PUBLICATION_ADMISSION,
  type FsStore,
  StoreRecordNotFoundError,
} from '../lib/store.js';
import { resolveLogicalModel } from '../llm/logical-models.js';
import { withTurnModelCapture } from '../llm/model-capture.js';
import type { LLMGatewayProviderDispatcher } from '../llm/provider-dispatcher.js';
import type { ProviderSubscriptionAccountManager } from '../llm/provider-subscription-accounts.js';
import { type FamilyImplementations, publicOperationActor } from '../operation-contract.js';
import { OperationError } from '../operation-error.js';
import type { ResolvedLLMProviderConfig } from '../providers/llm-config.js';
import type { ProviderCredentialConfigured } from '../providers/registry.js';
import {
  IdempotencyKeyConflictError,
  type InflightIdempotentCommand,
  runIdempotentCommand,
} from '../runtime/idempotent-command.js';
import type { CoreDb, WorkspaceDb } from '../storage/db.js';
import {
  type AdministrationEnvironmentTools,
  createAdministrationTools,
} from './administration-tools.js';
import { createAdministrationConfigurationTools } from './configuration-tools.js';
import { createAdministrationNanoHostRuntimeTargetTool } from './nanohost-runtime-target-tool.js';

const ADMINISTRATION_AGENT_ID = 'assistant';
const ADMINISTRATION_TARGET_REF = 'internal-role:administration';
const DEFAULT_LIMITS = { maxModelTurns: 16, maxToolCalls: 48, deadlineMs: 120_000 } as const;

class AdministrationRecoveryRequiredError extends Error {
  public constructor() {
    super('Administration has partial durable state that requires inspection.');
    this.name = 'AdministrationRecoveryRequiredError';
  }
}

/** Context supplied to the Worker environment owner for one administration Turn. */
interface AdministrationEnvironmentToolContext {
  readonly actor: Actor;
  readonly administrationThreadId: string;
  readonly administrationTurnId: string;
  readonly administrationWorkspaceId: string;
  readonly requestId: string;
  readonly store: FsStore;
}

/** Dependencies for the private administration family; all request facts arrive in admitted context. */
interface AdministrationDependencies {
  readonly repositoryWorkspaceDb: (workspaceId: string) => WorkspaceDb;
  readonly coreDb: CoreDb | undefined;
  readonly environmentToolsForTurn: (
    context: AdministrationEnvironmentToolContext
  ) => AdministrationEnvironmentTools;
  readonly inflightCommands: WeakMap<FsStore, Map<string, InflightIdempotentCommand>>;
  readonly llmGatewayDispatcher: Pick<LLMGatewayProviderDispatcher, 'createResponses'>;
  readonly mode: CoreMode;
  readonly nanoHostConfig?: Pick<OpenKitNanoHostConfig, 'identityId' | 'deploymentId'>;
  readonly providerSubscriptionAccountManager?: ProviderSubscriptionAccountManager;
  /** Current API-key presence without resolving Vault material. */
  readonly providerCredentialConfigured?: ProviderCredentialConfigured;
  readonly quickChatWorkspaceIdForUser: (userId: string) => string;
  readonly store: FsStore;
  readonly runtimeConfigFiles: (actor: Actor) => RuntimeConfigFileService;
  readonly reloadRuntimeConfig: () => ReturnType<RuntimeConfigManager['reload']>;
  readonly resolveGatewayProvider: (providerId: string, model: string) => ResolvedLLMProviderConfig;
  readonly runtimeConfig: () => RuntimeConfigSnapshot;
}

/** Joins the private administration entry to its bounded conversation and immutable configuration owners. */
export function createAdministrationOperationImplementations(input: AdministrationDependencies) {
  /** Resolves request-owned configuration services without exposing authority to the model. */
  function configuration(actor: Actor) {
    if (!input.coreDb) throw new DeploymentAdminRequiredError();
    return createAdministrationConfiguration({
      actor,
      coreDb: input.coreDb,
      store: input.store,
      files: input.runtimeConfigFiles(actor),
      reload: input.reloadRuntimeConfig,
      inflightCommands: input.inflightCommands,
      runtimeConfig: input.runtimeConfig,
      repositoryWorkspaceDb: input.repositoryWorkspaceDb,
    });
  }
  return {
    'administration.configuration-apply': async (request, context) => {
      try {
        const actor = publicOperationActor(context);
        if (!input.coreDb) throw new DeploymentAdminRequiredError();
        requireCurrentDeploymentAdmin(input.coreDb, actor);
        return await configuration(actor).apply(request);
      } catch (error) {
        if (error instanceof DeploymentAdminRequiredError)
          throw new OperationError(
            'deployment_admin_required',
            'Current deployment administrator authority is required.',
            403,
            { cause: error }
          );
        if (
          error instanceof RuntimeConfigFileServiceError ||
          error instanceof IdempotencyKeyConflictError
        )
          throw new OperationError(error.code, error.message, error.status, { cause: error });
        if (
          error instanceof StoreRecordNotFoundError ||
          error instanceof z.ZodError ||
          error instanceof SyntaxError
        )
          throw new OperationError(
            'configuration_candidate_invalid',
            'Configuration candidate is unavailable or invalid.',
            409,
            { cause: error }
          );
        throw error;
      }
    },
    'administration.conversation-submit': async (request, context) => {
      if (!input.coreDb)
        throw new OperationError(
          'deployment_admin_required',
          'Current deployment administrator authority is required.',
          403
        );
      const actor = publicOperationActor(context);
      const workspaceId = input.quickChatWorkspaceIdForUser(actor.userId);
      const threadId = request.threadId ?? administrationThreadId(actor.userId, request.requestId);
      const store = input.store;
      try {
        requireCurrentDeploymentAdmin(input.coreDb, actor);
        const workspace = store.getWorkspace(workspaceId);
        if (workspace.kind !== 'quick-chat')
          throw new OperationError('administration_failed', 'Administration failed.', 500);
        const currentThread = store
          .listThreads(workspaceId)
          .find((thread) => thread.id === threadId);
        if (request.threadId && !currentThread) {
          throw new OperationError('target_missing', 'Administration Thread is unavailable.', 409);
        }
        if (currentThread && currentThread.entryPath !== 'administration') {
          throw new OperationError(
            'thread_entry_path_mismatch',
            'Administration submission cannot continue this Thread.',
            409
          );
        }

        const result = await runIdempotentCommand({
          command: 'conversation.submit',
          execute: async () => {
            requireCurrentDeploymentAdmin(input.coreDb!, actor);
            const thread =
              currentThread ??
              store.createThread(
                workspaceId,
                administrationThreadTitle(request.input),
                threadId,
                'administration',
                { visibility: 'private', privateOwnerUserId: actor.userId }
              );
            const turnId = administrationTurnId(actor.userId, thread.id, request.requestId);
            if (
              store
                .listThreadTurns(workspaceId, thread.id)
                .some((candidate) => candidate.id === turnId)
            ) {
              throw new AdministrationRecoveryRequiredError();
            }
            const triggerActor = { kind: 'user', id: actor.userId } as const satisfies ActorRef;
            let turn: ReturnType<FsStore['createTurn']>;
            try {
              turn = store.createTurn(workspaceId, thread.id, request.input, triggerActor, null, {
                turnId,
              });
              const createdAt = turn.startedAt ?? new Date().toISOString();
              store.createItem({
                id: deriveEntityId('it', ['administration_user', turn.id]),
                workspaceId,
                threadId: thread.id,
                turnId: turn.id,
                type: 'user-message',
                status: 'completed',
                actor: triggerActor,
                text: request.input,
                createdAt,
                completedAt: createdAt,
              });
            } catch (error) {
              if (
                store
                  .listThreadTurns(workspaceId, thread.id)
                  .some((candidate) => candidate.id === turnId)
              ) {
                throw new AdministrationRecoveryRequiredError();
              }
              throw error;
            }

            try {
              const snapshot = input.runtimeConfig();
              const workspaceConfig = findWorkspaceConfig(snapshot, workspaceId)?.config;
              const userConfig = snapshot.userConfigs.find(
                (entry) => entry.userId === actor.userId
              )?.config;
              const selection = resolveInternalRoleProfile({
                roleId: ADMINISTRATION_AGENT_ID,
                workspaceId,
                gatewayConfig: snapshot.gatewayConfig,
                profilesConfig: snapshot.internalRoleProfiles,
                providerRegistry: snapshot.providerRegistry,
                providerSubscriptionAccountManager: input.providerSubscriptionAccountManager,
                providerCredentialConfigured: input.providerCredentialConfigured,
                ...(request.logicalModelId
                  ? { requestedLogicalModelId: request.logicalModelId }
                  : {}),
                ...(workspaceConfig ? { workspaceConfig } : {}),
                ...(userConfig ? { userConfig } : {}),
              });
              if (
                !selection ||
                !selection.logicalModel.capabilities.includes('responses') ||
                !selection.logicalModel.capabilities.includes('tool-calling')
              ) {
                return failedAdministrationTurn(
                  store,
                  turn.id,
                  'administration_execution_failed',
                  !selection
                    ? 'Administration has no admitted logical model for this request.'
                    : 'Administration requires an admitted logical model with responses and tool-calling capabilities.'
                );
              }
              const catalog = configuration(actor);
              const tools = createAdministrationTools({
                configurationTools: createAdministrationConfigurationTools(
                  snapshot,
                  input.runtimeConfigFiles(actor),
                  {
                    ...catalog,
                    propose: (value) =>
                      catalog.propose(value, {
                        threadId: thread.id,
                        turnId: turn.id,
                        requestId: request.requestId,
                      }),
                    applyDelegated: (value, context) =>
                      catalog.applyDelegated(value, {
                        threadId: thread.id,
                        turnId: turn.id,
                        signal: context.signal,
                      }),
                  }
                ),
                requireCurrentAdministrator: () => {
                  requireCurrentDeploymentAdmin(input.coreDb!, actor);
                },
                environmentTools: input.environmentToolsForTurn({
                  actor,
                  administrationThreadId: thread.id,
                  administrationTurnId: turn.id,
                  administrationWorkspaceId: workspaceId,
                  requestId: request.requestId,
                  store,
                }),
                runtimeTargetTool: createAdministrationNanoHostRuntimeTargetTool({
                  actor,
                  lineage: { workspaceId, threadId: thread.id, turnId: turn.id },
                  coreDb: input.coreDb,
                  mode: input.mode,
                  ...(input.nanoHostConfig ? { nanoHostConfig: input.nanoHostConfig } : {}),
                }),
              });
              const priorMessages = administrationMessages(store, workspaceId, thread.id, turn.id);
              const systemPrompt = assembleBuiltInSystemPrompt('administration', {
                workspaceId,
                threadId: thread.id,
                workspaceKind: 'quick-chat',
              });
              const loopResult = await withTurnModelCapture(
                { store, turn, environment: { systemPrompt, tools } },
                (capture) =>
                  runInternalAgentLoop(
                    {
                      systemPrompt,
                      messages: priorMessages,
                      tools,
                      model: {
                        logicalModelId: selection.logicalModel.id,
                        capabilities: selection.logicalModel.capabilities,
                        modelFamilyId: selection.logicalModel.modelFamilyId,
                      },
                      limits: selection.profile?.limits ?? DEFAULT_LIMITS,
                      signal: context.signal ?? new AbortController().signal,
                    },
                    createInternalAgentGatewayProvider({
                      capture,
                      logicalModel: selection.logicalModel,
                      resolveLogicalModel: (logicalModelId) => {
                        const snapshot = input.runtimeConfig();
                        return resolveLogicalModel(
                          snapshot.gatewayConfig,
                          snapshot.providerRegistry,
                          logicalModelId,
                          input.providerSubscriptionAccountManager,
                          input.providerCredentialConfigured
                        );
                      },
                      dispatcher: input.llmGatewayDispatcher,
                      resolveGatewayProvider: input.resolveGatewayProvider,
                      ...(input.providerSubscriptionAccountManager
                        ? {
                            providerSubscriptionAccountManager:
                              input.providerSubscriptionAccountManager,
                          }
                        : {}),
                      promptCacheScope: { sessionId: `administration:${thread.id}`, workspaceId },
                      usageEndpoint: 'responses',
                      callContext: {
                        authorityActor: triggerActor,
                        agentId: ADMINISTRATION_AGENT_ID,
                        workspaceId,
                        family: 'llm',
                        operation: 'administration',
                        capabilityId: 'inference.local.administration',
                        providerRef: null,
                        requestId: null,
                        serviceRef: 'llm-gateway',
                        redactionClass: 'metadata-only',
                        summary: 'Private administration Assistant LLM call.',
                      },
                    })
                  )
              );
              if (loopResult.kind !== 'quiescent') {
                const code =
                  loopResult.kind === 'failed'
                    ? loopResult.code
                    : loopResult.kind === 'limit_reached'
                      ? `internal_agent_${loopResult.limit}_limit`
                      : 'internal_agent_aborted';
                return failedAdministrationTurn(
                  store,
                  turn.id,
                  code,
                  'Administration could not complete this bounded run.'
                );
              }
              const answer = finalAssistantText(loopResult.messages);
              if (!answer) {
                return failedAdministrationTurn(
                  store,
                  turn.id,
                  'internal_agent_empty_answer',
                  'Administration returned no publishable answer.'
                );
              }
              requireCurrentDeploymentAdmin(input.coreDb!, actor);
              try {
                const completedAt = new Date().toISOString();
                const item = store.createItem({
                  id: deriveEntityId('it', ['administration_answer', turn.id]),
                  workspaceId,
                  threadId: thread.id,
                  turnId: turn.id,
                  type: 'assistant-message',
                  status: 'completed',
                  text: redactInternalAgentText(answer),
                  createdAt: completedAt,
                  completedAt,
                });
                return {
                  body: administrationResponse(
                    store.updateTurn(turn.id, { status: 'completed', completedAt }),
                    item,
                    selection.logicalModel.id,
                    'answered',
                    'The private administration Assistant answered through the bounded Tool set.'
                  ),
                  resultKind: 'provider-answer' as const,
                  status: 200 as const,
                };
              } catch {
                throw new AdministrationRecoveryRequiredError();
              }
            } catch (error) {
              if (error instanceof AdministrationRecoveryRequiredError) throw error;
              return failedAdministrationTurn(
                store,
                turn.id,
                error instanceof DeploymentAdminRequiredError
                  ? 'deployment_admin_required'
                  : 'administration_execution_failed',
                error instanceof DeploymentAdminRequiredError
                  ? 'Current deployment administrator authority was lost before publication.'
                  : 'Administration could not settle the current bounded run.'
              );
            }
          },
          inflightCommands: input.inflightCommands,
          input: {
            input: request.input,
            logicalModelId: request.logicalModelId ?? null,
            targetRef: ADMINISTRATION_TARGET_REF,
          },
          replay: (record) =>
            replayAdministrationTurn(store, workspaceId, threadId, actor.userId, record),
          requestId: request.requestId,
          responseId: (result) => result.body.turn.id,
          responseKind: 'turn',
          conversationResponseMetadata: (result) => ({
            downstream: null,
            targetRef: ADMINISTRATION_TARGET_REF,
            logicalModelId: result.body.logicalModelId,
            receivingWorkspaceId: workspaceId,
            receivingThreadId: threadId,
            resultKind: result.resultKind,
            status: result.status,
          }),
          scope: { actorId: actor.userId, threadId, workspaceId },
          store,
        });
        return result.body;
      } catch (error) {
        if (error instanceof OperationError) throw error;
        if (error instanceof DeploymentAdminRequiredError)
          throw new OperationError(
            'deployment_admin_required',
            'Current deployment administrator authority is required.',
            403,
            { cause: error }
          );
        if (error instanceof IdempotencyKeyConflictError)
          throw new OperationError(
            error.code,
            redactInternalAgentText(error.message),
            error.status,
            { cause: error }
          );
        if (
          error instanceof AdministrationRecoveryRequiredError ||
          hasAdministrationTurn(
            store,
            workspaceId,
            threadId,
            administrationTurnId(actor.userId, threadId, request.requestId)
          )
        )
          throw new OperationError(
            'recovery_required',
            'Administration has partial durable state that requires inspection.',
            409,
            { cause: error }
          );
        if (error instanceof StoreRecordNotFoundError)
          throw new OperationError('administration_failed', 'Administration failed.', 500, {
            cause: error,
          });
        throw error;
      }
    },
  } satisfies FamilyImplementations<typeof ADMINISTRATION_ENTRY_OPERATION_DEFINITIONS>;
}

type AdministrationCommandResult = {
  readonly body: SubmitAdministrationConversationResponse;
  readonly resultKind: 'provider-answer' | 'refused';
  readonly status: 200;
};

function administrationMessages(
  store: FsStore,
  workspaceId: string,
  threadId: string,
  currentTurnId: string
): AgentMessage[] {
  return store
    .listThreadItems(workspaceId, threadId)
    .filter((item) => item.turnId !== currentTurnId || item.type === 'user-message')
    .flatMap((item): AgentMessage[] => {
      if (item.type === 'user-message') {
        return [{ role: 'user', content: [{ type: 'text', text: item.text }] }];
      }
      if (item.type === 'assistant-message') {
        return [
          { role: 'assistant', content: [{ type: 'text', text: item.text }], truncated: false },
        ];
      }
      return [];
    });
}

/** Reads publishable text only from the final response of a quiescent loop. */
function finalAssistantText(messages: readonly AgentMessage[]): string {
  const message = messages.at(-1);
  if (!message || message.role !== 'assistant') return '';
  return message.content
    .filter(
      (part): part is { readonly type: 'text'; readonly text: string } => part.type === 'text'
    )
    .map((part) => part.text)
    .join('')
    .trim();
}

function failedAdministrationTurn(
  store: FsStore,
  turnId: string,
  code: string,
  explanation: string
): AdministrationCommandResult {
  const turn = store.getTurnById(turnId);
  const completedAt = new Date().toISOString();
  try {
    const item = store.createItem(
      {
        id: deriveEntityId('it', ['administration_refused', turn.id]),
        workspaceId: turn.workspaceId,
        threadId: turn.threadId,
        turnId: turn.id,
        type: 'status',
        status: 'completed',
        level: 'warning',
        title: 'Administration request did not complete',
        summary: explanation,
        createdAt: completedAt,
        completedAt,
      },
      ALREADY_DECIDED_PUBLICATION_ADMISSION
    );
    const completedTurn = store.updateTurn(
      turn.id,
      {
        status: 'failed',
        completedAt,
        error: { code, message: explanation },
      },
      ALREADY_DECIDED_PUBLICATION_ADMISSION
    );
    return {
      body: administrationResponse(completedTurn, item, null, 'refused', explanation),
      resultKind: 'refused',
      status: 200,
    };
  } catch {
    throw new AdministrationRecoveryRequiredError();
  }
}

function administrationResponse(
  turn: ReturnType<FsStore['getTurnById']>,
  item: ReturnType<FsStore['createItem']>,
  logicalModelId: string | null,
  outcome: 'answered' | 'refused',
  explanation: string
): SubmitAdministrationConversationResponse {
  return SubmitAdministrationConversationResponseSchema.parse({
    outcome,
    explanation,
    turn,
    item,
    handoff: null,
    originatingWorkspaceId: turn.workspaceId,
    originatingThreadId: turn.threadId,
    receivingWorkspaceId: turn.workspaceId,
    receivingThreadId: turn.threadId,
    targetRef: ADMINISTRATION_TARGET_REF,
    logicalModelId,
  });
}

function replayAdministrationTurn(
  store: FsStore,
  workspaceId: string,
  threadId: string,
  userId: string,
  record: ReturnType<FsStore['getCommandRequest']> extends infer T ? NonNullable<T> : never
): AdministrationCommandResult {
  try {
    const metadata = record.response.conversationMetadata;
    const turn = store.getTurnById(record.response.id);
    const resultKind = metadata?.resultKind;
    if (
      record.response.kind !== 'turn' ||
      metadata?.targetRef !== ADMINISTRATION_TARGET_REF ||
      metadata.receivingWorkspaceId !== workspaceId ||
      metadata.receivingThreadId !== threadId ||
      turn.workspaceId !== workspaceId ||
      turn.threadId !== threadId ||
      store.getThread(workspaceId, threadId).entryPath !== 'administration'
    ) {
      throw new AdministrationRecoveryRequiredError();
    }
    const itemId =
      resultKind === 'provider-answer'
        ? deriveEntityId('it', ['administration_answer', turn.id])
        : deriveEntityId('it', ['administration_refused', turn.id]);
    const item = turn.items.find((candidate) => candidate.id === itemId);
    const userItem = turn.items.find(
      (candidate) => candidate.id === deriveEntityId('it', ['administration_user', turn.id])
    );
    const consistentUser =
      userItem?.type === 'user-message' &&
      userItem.status === 'completed' &&
      userItem.workspaceId === workspaceId &&
      userItem.threadId === threadId &&
      userItem.turnId === turn.id &&
      userItem.actor.kind === 'user' &&
      userItem.actor.id === userId;
    const consistentAnswer =
      resultKind === 'provider-answer' &&
      turn.status === 'completed' &&
      item?.type === 'assistant-message' &&
      item.status === 'completed';
    const consistentRefusal =
      resultKind === 'refused' &&
      turn.status === 'failed' &&
      turn.error !== null &&
      item?.type === 'status' &&
      item.status === 'completed';
    if (!consistentUser || (!consistentAnswer && !consistentRefusal)) {
      throw new AdministrationRecoveryRequiredError();
    }
    return {
      body: administrationResponse(
        turn,
        item,
        metadata.logicalModelId,
        resultKind === 'provider-answer' ? 'answered' : 'refused',
        resultKind === 'provider-answer'
          ? 'The private administration Assistant answered through the bounded Tool set.'
          : (turn.error?.message ?? 'Administration could not complete this bounded run.')
      ),
      resultKind,
      status: 200,
    };
  } catch {
    throw new AdministrationRecoveryRequiredError();
  }
}

function hasAdministrationTurn(
  store: FsStore,
  workspaceId: string,
  threadId: string,
  turnId: string
): boolean {
  try {
    return store.listThreadTurns(workspaceId, threadId).some((turn) => turn.id === turnId);
  } catch {
    return false;
  }
}

function administrationThreadId(userId: string, requestId: string): string {
  return deriveEntityId('th', ['administration', userId, requestId]);
}

function administrationTurnId(userId: string, threadId: string, requestId: string): string {
  return deriveEntityId('tu', ['administration', userId, threadId, requestId]);
}

function administrationThreadTitle(text: string): string {
  return text.trim().split(/\r?\n/, 1)[0]?.slice(0, 120) || 'Administration';
}
