# Test Support

This directory owns explicit reusable NanoCore test fixtures and no production behavior.

## Boundaries

- `execution-attempt.ts` establishes exact prepared Native attempt authority below the dispatcher from a caller-supplied authorized admission. It records an optional submission intent without inventing acceptance, a cleanup fence, or Workspace membership.
- `demo-store.ts` creates an isolated `FsStore` and explicitly seeds the Demo Workspace fixture.
- `git-repository.ts` seeds a writable Git repository with one resolvable HEAD commit.
- `agent-environment.ts` records deterministic production-shaped AEP snapshots for scheduler recovery fixtures. Requested workspace input ids use pinned, credential-free remote Git catalog sources supported by NanoHost; the fixture creates no host repository.
- `goal-intent.ts` creates a completed user Turn and initial objective Item so Goal fixtures bind a real `createdByItemId` and `currentIntentItemId` lineage.
- `app.ts` creates an app with an explicit Core-backed simulated executor and its same execution backend unless a test supplies another executor. Its explicit `createAppWithWorkspaceAuthority` fixture creates real temporary local identity and Workspace membership records for storage-only HTTP fixtures that exercise definition-derived operations, and closes those fixture databases after each test. Explicit databases and server authority remain caller-owned.
- Both app fixtures accept omitted options. Tests whose subject is file-backed configuration loading or reload supply an explicit `runtimeConfigManager` so synthetic Gateway and Provider defaults do not replace the authored initial snapshot.
- `workspace-sync.ts` records deterministic trusted input and materialization lineage for review fixtures.
- `mcp-stdio-stub.mjs` publishes a descendant-written PID, supervisor PID, and credential digest receipt so MCP process cleanup tests verify inherited credentials on supported POSIX hosts without external process-inspection tools. The server's parent is the gateway's detached supervisor and the inherited process-group leader.
- Its initialization-hang mode keeps stdin open while withholding protocol replies; an unresolved top-level Promise alone makes Node exit rather than simulate a live unresponsive server.
- `mcp-http-stub.ts` can hold its `delayed` tool response on a test-owned Promise; the test observes request ingress and releases the gate during cleanup to establish concurrency without a guessed delay.
- `knowledge-operation.ts` projects explicit test selectors and supplied request bytes to definition-derived routes. It supplies no Workspace authority, request identity, data or admission default; malformed bodies stay malformed.
- Fixtures must use production public paths where practical, stay deterministic, and avoid silently changing production defaults.
- Add shared helpers only when multiple tests repeat the same fixture knowledge.

## Verification

`nanohost-native-tls-peer.ts` is the isolated peer for NanoHost's real TLS regression. It uses the native secure HTTP/2 factory from `src/index.ts`, production Token verification, admission, and durable readiness routes. It generates its own temporary CA, server key, and Token, and sends the credential only through the captured child pipe. The Rust caller owns process and temporary-file cleanup. Run `cargo test native_tls_` from `apps/nanohost` with the repository's pinned Node and OpenSSL available after installing workspace dependencies and building NanoCore's dependency packages.

Its CA-as-leaf mode reproduces a server certificate that Rustls rejects although some other TLS clients accept it. A bounded pipe query observes HTTP requests, Token presentation and durable target absence after certificate rejection. These observations remain fixture-local and supply no runtime authority.

Run the tests that consume the changed fixture and the NanoCore package test suite.

See [NanoCore README](../../README.md) for the package test model.

## Confirmed Synthetic Images

`recordTestNativeRuntimeTarget` records explicitly requested fresh Native target evidence for simulated consumer fixtures and leaves an existing target untouched. It grants no execution, cleanup or admission authority.

`native-environment.ts` explicitly confirms synthetic image defaults through the production settlement path for fixtures whose subject is another contract. `prepared-agent-environment.ts` resolves production AEP/metadata/compatibility against that fixture evidence and supplies explicit server-scoped default-off capture when unrelated consumer fixtures omit it. Explicit capture values remain unchanged. Missing/stale image and capture admission regressions call the production resolver directly. Historical image-effect fixtures may retain a package without the optional environment record; newly resolved packages always require confirmed evidence.

Simulated and metadata-only consumers may explicitly install `withTestPreparedNativeEnvironment` in their test module. It runs the production resolver with fixture-owned confirmed evidence and preserves capture, credential and scheduler checks. Fixture-only databases are removed after the test module; real production paths retain no automatic admission or empty-default fallback.

`operation-request.ts` exports `operationRequest`, the generic request helper, reused for Artifact, Task, conversation, attention and Pending Request, NanoHost and data-root administration selectors and caller-supplied request bytes on the derived HTTP path. It adds no authority, fixture data, request identity or admission default and leaves malformed bodies malformed.

The HTTP MCP fixture exposes server-observed header snapshots for exact bearer and raw-header replacement assertions. These observations contain only synthetic test canaries and stay fixture-local.

`recordTestAgentEnvironmentPackage` accepts an explicit Core database when the test exercises a storage or physical runtime consumer. Use the same Core owner as the Workspace and executor so the package retains that data root's deployment and admission facts; its standalone default remains for package-only fixtures.

`local-user.ts` explicitly seeds a canonical fixture User for tests that assert exact identity bytes, then invokes the production recorded-User owner. Local identity lifecycle tests use the production initializer directly. The fixture supplies no production default or alternate identifier mechanism.

`createAppWithLocalIdentity` supplies only the explicit local fixture identity when a test has no Core database. Tests of production runtime or configuration defaults use it without simulated-provider or environment injection. Existing Core and server authority remain caller-owned.

`entity-ids.ts` allocates shared-codec IDs once for process-local fixture keys. Setup and assertions share those exact allocations. It declares no owner derivation and supplies no cross-process replay authority; process-boundary tests pass the recorded IDs explicitly.
