import { createHash } from 'node:crypto';
import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import {
  ImportWorkspaceArtifactResponseSchema,
  IntroduceWorkspaceArtifactResponseSchema,
  ListArtifactReviewsResponseSchema,
  SubmitArtifactReviewDecisionResponseSchema,
} from '@openkit/app-api-schemas';
import { GetArtifactResponseSchema, ListArtifactsResponseSchema } from '@openkit/protocol';
import { describe, expect, it, vi } from 'vitest';
import {
  createArtifactReview,
  deriveArtifactReviewFollowUpTurnId,
  getArtifactReview,
} from './artifact-reviews.js';
import { FsStore } from './lib/store.js';
import { ProviderRegistry } from './providers/registry.js';
import {
  allocateNanoHostRuntimeTargetConnectionGeneration,
  upsertNanoHostRuntimeTarget,
} from './runtime/nanohost-runtime-target.js';
import * as schedulerDispatch from './runtime/scheduler-dispatch-loop.js';
import { getWorkerCheckpoint } from './runtime/worker-checkpoints.js';
import {
  recordWorkspaceSyncReview,
  updateWorkspaceSyncReviewDecision,
} from './runtime/workspace-sync-records.js';
import { listSchedulerAdmissionEntriesForWorkspace } from './scheduler-records.js';
import { artifactFilePayloadPath } from './storage/artifacts/file-records.js';
import { openCoreDb, openWorkspaceDb } from './storage/db.js';
import { readDataRootLayoutMarker } from './storage/fs-layout.js';
import { applyMigrations, applyScopedMigrations } from './storage/migrate.js';
import { createTestAgentSetup } from './test-support/agent-environment.js';
import { createAppWithWorkspaceAuthority as createApp } from './test-support/app.js';
import { createDemoStore } from './test-support/demo-store.js';
import { seedWritableGitRepository } from './test-support/git-repository.js';
import { ensureLocalUser } from './test-support/local-user.js';
import { operationRequest } from './test-support/operation-request.js';
import { recordTestWorkspaceReviewMaterialization } from './test-support/workspace-sync.js';
import { recordWorkspaceOwnerMembership } from './workspace-membership.js';

/** Uses the current exact raw import binding; JSON bytes remain a test input only. */
function fileImportRequest(
  workspaceId: string,
  input: {
    requestId: string;
    title: string;
    mediaType: string;
    contentDigest: string;
    content: string;
  }
): [string, RequestInit] {
  const { requestId, content, ...metadata } = input;
  return [
    `/api/app/operations/artifact.import?${new URLSearchParams({ ...metadata, workspaceId, byteLength: String(Buffer.byteLength(content)) })}`,
    {
      method: 'POST',
      headers: { 'x-openkit-request-id': requestId, 'content-type': metadata.mediaType },
      body: Buffer.from(content),
    },
  ];
}

/**
 * Records the implicit local actor as the owner of one test Workspace.
 *
 * @param coreDb Core database used by the guarded route fixture.
 * @param workspaceId Workspace exposed by the fixture store.
 */
function recordLocalWorkspaceAccess(
  coreDb: ReturnType<typeof openCoreDb>,
  workspaceId: string
): void {
  ensureLocalUser(coreDb);
  recordWorkspaceOwnerMembership({
    coreDb,
    ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
    workspaceId,
  });
}

/**
 * Computes the canonical digest for exact UTF-8 Artifact content.
 *
 * @param content Exact Artifact body.
 * @returns Lowercase SHA-256 digest with the required prefix.
 */
function artifactDigest(content: string): string {
  return `sha256:${createHash('sha256').update(content, 'utf8').digest('hex')}`;
}

/**
 * Sends one JSON POST request through the route test app.
 *
 * @param app Test application.
 * @param path Route path.
 * @param body JSON request body.
 * @returns Route response.
 */
function postJson(
  app: ReturnType<typeof createApp>,
  path: string,
  body: unknown
): Promise<Response> {
  const options = {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  };
  return typeof path === 'string'
    ? app.request(path, options)
    : app.request(...operationRequest(path[0], path[1], options));
}

/**
 * Creates one ready turn-output Artifact and its matching unresolved Review fixture.
 *
 * @param store Product store that owns the Artifact.
 * @param workspaceDb Workspace database that owns the Review.
 * @param artifactId Artifact and Review identity.
 * @param content Exact Artifact content.
 * @param sourceTurnId Completed source Turn identity.
 * @returns Created unresolved Review view.
 */
function createReviewFixture(
  store: FsStore,
  workspaceDb: ReturnType<typeof openWorkspaceDb>,
  artifactId: string,
  content: string,
  sourceTurnId: string
): ReturnType<typeof createArtifactReview> {
  const sourceTurn = store.getTurnById(sourceTurnId);
  const createdAt = sourceTurn.startedAt ?? sourceTurn.completedAt;
  if (!createdAt) {
    throw new Error('Artifact Review fixture requires a started source Turn.');
  }
  const requestId = `produce-${artifactId}`;
  store.createArtifact({
    id: artifactId,
    workspaceId: workspaceDb.workspaceId,
    threadId: sourceTurn.threadId,
    turnId: sourceTurn.id,
    kind: 'summary',
    title: artifactId,
    status: 'ready',
    summary: null,
    version: 1,
    content: { format: 'text', body: content },
    contentDigest: artifactDigest(content),
    lastMutationRequestId: requestId,
    origin: {
      kind: 'turn-output',
      threadId: sourceTurn.threadId,
      turnId: sourceTurn.id,
      requestId,
    },
    createdAt,
    updatedAt: createdAt,
  });
  return createArtifactReview(workspaceDb, {
    artifactId,
    artifactVersion: 1,
    contentDigest: artifactDigest(content),
    sourceThreadId: sourceTurn.threadId,
    sourceTurnId: sourceTurn.id,
    sourceAgentId: sourceTurn.agentId ?? null,
    materialProposal: null,
    createdAt,
  });
}

describe('Core artifact routes', () => {
  it('lists and reads exact markdown inline Artifact content', async () => {
    const store = createDemoStore();
    const thread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Artifact content thread'
    );
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Create artifact',
      {
        kind: 'user',
        id: 'usr_00000000-0000-7000-8000-000000000001',
      }
    );
    const requestId = 'artifact-read-markdown-1';
    const body = '# Output';
    store.createArtifact({
      id: 'ar_00000000-0000-76a7-971b-3c2e3b40da06',
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
      threadId: thread.id,
      turnId: turn.id,
      kind: 'summary',
      title: 'Markdown output',
      status: 'ready',
      summary: 'Open me',
      version: 1,
      content: { format: 'markdown', body },
      contentDigest: artifactDigest(body),
      lastMutationRequestId: requestId,
      origin: { kind: 'turn-output', threadId: thread.id, turnId: turn.id, requestId },
      createdAt: turn.startedAt ?? new Date().toISOString(),
      updatedAt: turn.startedAt ?? new Date().toISOString(),
    });
    const app = createApp({ store });

    const listRes = await app.request(
      ...operationRequest('artifact.list', {
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
      })
    );
    const getRes = await app.request(
      ...operationRequest('artifact.read', {
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        artifactId: 'ar_00000000-0000-76a7-971b-3c2e3b40da06',
      })
    );

    expect(listRes.status).toBe(200);
    expect(ListArtifactsResponseSchema.parse(await listRes.json())).toMatchObject({
      items: [
        {
          id: 'ar_00000000-0000-76a7-971b-3c2e3b40da06',
          workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        },
      ],
    });
    expect(getRes.status).toBe(200);
    expect(GetArtifactResponseSchema.parse(await getRes.json())).toMatchObject({
      id: 'ar_00000000-0000-76a7-971b-3c2e3b40da06',
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
      content: { format: 'markdown', body: '# Output' },
    });
  });

  it('reads exact text and JSON inline Artifact content with their recorded formats', async () => {
    const store = createDemoStore();
    const thread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Artifact format thread'
    );
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Create formatted artifacts',
      {
        kind: 'user',
        id: 'usr_00000000-0000-7000-8000-000000000001',
      }
    );
    const timestamp = turn.startedAt ?? new Date().toISOString();
    const textRequestId = 'artifact-read-text-1';
    const textBody = 'Plain output';
    store.createArtifact({
      id: 'ar_00000000-0000-70b0-925c-a9f002bae163',
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
      threadId: thread.id,
      turnId: turn.id,
      kind: 'summary',
      title: 'Text output',
      status: 'ready',
      summary: null,
      version: 1,
      content: { format: 'text', body: textBody },
      contentDigest: artifactDigest(textBody),
      lastMutationRequestId: textRequestId,
      origin: {
        kind: 'turn-output',
        threadId: thread.id,
        turnId: turn.id,
        requestId: textRequestId,
      },
      createdAt: timestamp,
      updatedAt: timestamp,
    });
    const jsonRequestId = 'artifact-read-json-1';
    const jsonBody = '{"ok":true}';
    store.createArtifact({
      id: 'ar_00000000-0000-73de-845a-af433639db48',
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
      threadId: thread.id,
      turnId: turn.id,
      kind: 'summary',
      title: 'JSON output',
      status: 'ready',
      summary: null,
      version: 1,
      content: { format: 'json', body: jsonBody },
      contentDigest: artifactDigest(jsonBody),
      lastMutationRequestId: jsonRequestId,
      origin: {
        kind: 'turn-output',
        threadId: thread.id,
        turnId: turn.id,
        requestId: jsonRequestId,
      },
      createdAt: timestamp,
      updatedAt: timestamp,
    });
    const app = createApp({ store });

    const textRes = await app.request(
      ...operationRequest('artifact.read', {
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        artifactId: 'ar_00000000-0000-70b0-925c-a9f002bae163',
      })
    );
    const jsonRes = await app.request(
      ...operationRequest('artifact.read', {
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        artifactId: 'ar_00000000-0000-73de-845a-af433639db48',
      })
    );

    expect(textRes.status).toBe(200);
    await expect(textRes.json()).resolves.toMatchObject({
      content: { format: 'text', body: 'Plain output' },
    });
    expect(jsonRes.status).toBe(200);
    await expect(jsonRes.json()).resolves.toMatchObject({
      content: { format: 'json', body: '{"ok":true}' },
    });
  });

  it('imports exact Artifact bytes and introduces the immutable origin into an idle Thread', async () => {
    const dataRoot = mkdtempSync(join(tmpdir(), 'openkit-artifact-app-routes-'));
    const coreDb = openCoreDb(dataRoot);
    applyMigrations(coreDb);
    const store = new FsStore({ dataRoot });
    const workspace = store.createWorkspace('Artifact route workspace');
    recordLocalWorkspaceAccess(coreDb, workspace.id);
    const thread = store.createThread(workspace.id, 'Artifact route thread');
    const workspaceDb = openWorkspaceDb(dataRoot, workspace.id);
    applyScopedMigrations(workspaceDb);
    workspaceDb.sqlite.close();
    const app = createApp({ coreDb, dataRoot, store });
    const content = '# Imported\n\nExact bytes.';
    const contentDigest = artifactDigest(content);
    const importBody = {
      requestId: 'artifact-import-route-1',
      title: 'Imported route Artifact',
      mediaType: 'text/markdown',
      contentDigest,
      content,
    } as const;

    try {
      const importedRes = await app.request(...fileImportRequest(workspace.id, importBody));
      expect(importedRes.status).toBe(201);
      const imported = ImportWorkspaceArtifactResponseSchema.parse(await importedRes.json());
      expect(imported.artifactVersion).toBe(1);

      const artifact = store.getArtifact(workspace.id, imported.artifactId);
      expect(artifact).toMatchObject({
        workspaceId: workspace.id,
        threadId: null,
        turnId: null,
        version: 1,
        content: {
          format: 'file',
          mediaType: 'text/markdown',
          byteLength: Buffer.byteLength(content),
        },
        contentDigest,
        lastMutationRequestId: importBody.requestId,
        origin: {
          kind: 'imported',
          sourceKind: 'direct-import',
          sourceId: importBody.requestId,
          sourceDigest: contentDigest,
          actor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
          requestId: importBody.requestId,
        },
      });

      const importReplayRes = await app.request(...fileImportRequest(workspace.id, importBody));
      expect(importReplayRes.status).toBe(201);
      expect(ImportWorkspaceArtifactResponseSchema.parse(await importReplayRes.json())).toEqual(
        imported
      );

      const digestMismatchRes = await app.request(
        ...fileImportRequest(workspace.id, {
          ...importBody,
          requestId: 'artifact-import-mismatch',
          content: `${content}!`,
        })
      );
      expect(digestMismatchRes.status).toBe(400);
      await expect(digestMismatchRes.json()).resolves.toMatchObject({
        code: 'source_digest_mismatch',
      });

      const changedImportRes = await app.request(
        ...fileImportRequest(workspace.id, { ...importBody, title: 'Changed import title' })
      );
      expect(changedImportRes.status).toBe(409);
      await expect(changedImportRes.json()).resolves.toMatchObject({
        code: 'idempotency_key_conflict',
      });

      const introductionBody = {
        requestId: 'artifact-introduction-route-1',
        expectedArtifactVersion: 1,
      } as const;
      const introducedRes = await app.request(
        ...operationRequest(
          'artifact.introduce',
          { workspaceId: workspace.id, threadId: thread.id, artifactId: imported.artifactId },
          {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify(introductionBody),
          }
        )
      );
      expect(introducedRes.status).toBe(201);
      const introduced = IntroduceWorkspaceArtifactResponseSchema.parse(await introducedRes.json());
      expect(introduced).toMatchObject({
        artifactId: imported.artifactId,
        artifactVersion: 1,
      });
      expect(store.getTurn(workspace.id, thread.id, introduced.turnId)).toMatchObject({
        status: 'completed',
        items: [
          expect.objectContaining({
            id: introduced.itemId,
            artifactId: imported.artifactId,
            artifactVersion: 1,
            lastMutationRequestId: introductionBody.requestId,
            status: 'completed',
          }),
        ],
      });
      expect(store.getArtifact(workspace.id, imported.artifactId)).toEqual(artifact);

      const changedArtifactRes = await app.request(
        ...operationRequest(
          'artifact.introduce',
          {
            workspaceId: workspace.id,
            threadId: thread.id,
            artifactId: 'ar_00000000-0000-7dcf-9e49-194b732024ae',
          },
          {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify(introductionBody),
          }
        )
      );
      expect(changedArtifactRes.status).toBe(409);
      await expect(changedArtifactRes.json()).resolves.toMatchObject({
        code: 'idempotency_key_conflict',
      });

      store.createTurn(workspace.id, thread.id, 'Keep the Thread active after introduction', {
        kind: 'user',
        id: 'usr_00000000-0000-7000-8000-000000000001',
      });
      const introductionReplayRes = await app.request(
        ...operationRequest(
          'artifact.introduce',
          { workspaceId: workspace.id, threadId: thread.id, artifactId: imported.artifactId },
          {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify(introductionBody),
          }
        )
      );
      expect(introductionReplayRes.status).toBe(201);
      expect(
        IntroduceWorkspaceArtifactResponseSchema.parse(await introductionReplayRes.json())
      ).toEqual(introduced);

      const turnCount = store.listThreadTurns(workspace.id, thread.id).length;
      const itemCount = store.listThreadItems(workspace.id, thread.id).length;
      const busyRes = await app.request(
        ...operationRequest(
          'artifact.introduce',
          { workspaceId: workspace.id, threadId: thread.id, artifactId: imported.artifactId },
          {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({
              requestId: 'artifact-introduction-route-busy',
              expectedArtifactVersion: 1,
            }),
          }
        )
      );
      expect(busyRes.status).toBe(409);
      await expect(busyRes.json()).resolves.toMatchObject({ code: 'thread_busy' });
      expect(store.listThreadTurns(workspace.id, thread.id)).toHaveLength(turnCount);
      expect(store.listThreadItems(workspace.id, thread.id)).toHaveLength(itemCount);

      writeFileSync(
        artifactFilePayloadPath(
          join(dataRoot, 'workspaces', workspace.id),
          artifact.id,
          artifact.version
        ),
        `${content}!`
      );
      const corruptReplayRes = await app.request(...fileImportRequest(workspace.id, importBody));
      expect(corruptReplayRes.status).toBe(409);
      await expect(corruptReplayRes.json()).resolves.toMatchObject({
        code: 'recovery_required',
      });
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('decides exact Review targets and rejects conflicting generic owners or source proof', async () => {
    const dataRoot = mkdtempSync(join(tmpdir(), 'openkit-artifact-review-routes-'));
    const coreDb = openCoreDb(dataRoot);
    applyMigrations(coreDb);
    const store = createDemoStore({ dataRoot });
    recordLocalWorkspaceAccess(coreDb, 'ws_00000000-0000-7000-8000-000000000001');
    const thread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Artifact Review route thread'
    );
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Produce reviewed Artifacts',
      {
        kind: 'user',
        id: 'usr_00000000-0000-7000-8000-000000000001',
      }
    );
    const completedAt = new Date().toISOString();
    store.updateTurn(turn.id, { agentId: 'agent_codex_host' });
    const workspaceDb = openWorkspaceDb(dataRoot, 'ws_00000000-0000-7000-8000-000000000001');
    applyScopedMigrations(workspaceDb);
    const reviews = (
      [
        ['ar_00000000-0000-71cf-a641-bd9c6acde17b', 'Review the first Artifact.'],
        ['ar_00000000-0000-7c49-98d1-47c5d31a3268', 'Review the second Artifact.'],
      ] as const
    ).map(([artifactId, content]) =>
      createReviewFixture(store, workspaceDb, artifactId, content, turn.id)
    );
    const backing = store.getArtifact(
      'ws_00000000-0000-7000-8000-000000000001',
      'ar_00000000-0000-71cf-a641-bd9c6acde17b'
    );
    store.createArtifact({ ...backing, id: 'ar_00000000-0000-7f70-84f9-64a58b07cc9f' });
    store.updateTurn(turn.id, {
      status: 'completed',
      completedAt,
    });
    const firstReview = reviews[0]!;
    workspaceDb.sqlite.close();
    const app = createApp({ coreDb, dataRoot, store });
    const decisionPath = [
      'artifact.review.decide',
      {
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        artifactId: 'ar_00000000-0000-71cf-a641-bd9c6acde17b',
        artifactVersion: 1,
      },
    ] as const;
    const secondDecisionPath = [
      'artifact.review.decide',
      {
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        artifactId: 'ar_00000000-0000-7c49-98d1-47c5d31a3268',
        artifactVersion: 1,
      },
    ] as const;
    const request = {
      requestId: 'artifact-review-reject-1',
      decision: 'rejected',
      feedback: 'The output does not satisfy the request.',
    } as const;

    try {
      const listRes = await app.request(
        ...operationRequest('artifact.review-list', {
          workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
          artifactId: 'ar_00000000-0000-71cf-a641-bd9c6acde17b',
        })
      );
      expect(listRes.status).toBe(200);
      expect(ListArtifactReviewsResponseSchema.parse(await listRes.json())).toEqual({
        reviews: [firstReview],
      });

      const decidedRes = await postJson(app, decisionPath, request);
      expect(decidedRes.status).toBe(200);
      const decided = SubmitArtifactReviewDecisionResponseSchema.parse(await decidedRes.json());
      expect(decided).toMatchObject({
        reviewId: firstReview.reviewId,
        artifactId: firstReview.artifactId,
        artifactVersion: 1,
        decision: 'rejected',
        followUpTurnId: null,
      });

      const replayRes = await postJson(app, decisionPath, request);
      expect(replayRes.status).toBe(200);
      expect(SubmitArtifactReviewDecisionResponseSchema.parse(await replayRes.json())).toEqual(
        decided
      );

      const changedInputRes = await postJson(app, decisionPath, {
        ...request,
        feedback: 'Changed feedback.',
      });
      expect(changedInputRes.status).toBe(409);
      await expect(changedInputRes.json()).resolves.toMatchObject({
        code: 'idempotency_key_conflict',
      });

      const competingRes = await postJson(app, decisionPath, {
        requestId: 'artifact-review-reject-2',
        decision: 'deferred',
      });
      expect(competingRes.status).toBe(409);
      await expect(competingRes.json()).resolves.toMatchObject({ code: 'stale' });

      const secondRequest = {
        requestId: 'artifact-review-second-1',
        decision: 'rejected',
      } as const;
      const secondArtifact = store.getArtifact(
        'ws_00000000-0000-7000-8000-000000000001',
        'ar_00000000-0000-7c49-98d1-47c5d31a3268'
      );
      const secondContent = secondArtifact.content.body;
      secondArtifact.content.body = `${secondContent}!`;
      const corruptArtifactRes = await postJson(app, secondDecisionPath, secondRequest);
      expect(corruptArtifactRes.status).toBe(409);
      await expect(corruptArtifactRes.json()).resolves.toMatchObject({
        code: 'recovery_required',
      });
      secondArtifact.content.body = secondContent;

      expect(() => store.updateTurn(turn.id, { agentId: 'agent_other_runtime' })).toThrow(
        /is terminal and does not admit this write/
      );

      const syncDb = openWorkspaceDb(dataRoot, 'ws_00000000-0000-7000-8000-000000000001');
      try {
        for (const [suffix, artifactId] of [
          ['first', 'ar_00000000-0000-71cf-a641-bd9c6acde17b'],
          ['second', 'ar_00000000-0000-7c49-98d1-47c5d31a3268'],
        ] as const) {
          const item = {
            artifactId,
            changeSet: {
              artifactIds: [artifactId],
              base: { commit: `base-${suffix}`, contentDigest: null },
              bundle: null,
              changedPaths: [],
              createdAt: completedAt,
              evidenceRefs: [],
              head: { commit: `head-${suffix}`, contentDigest: null },
              id: `workspace-change-artifact-route-${suffix}`,
              inputSnapshotId: `workspace-input-artifact-route-${suffix}`,
              materializationRecordId: `workspace-materialization-artifact-route-${suffix}`,
              patch: null,
              redaction: { notes: [], status: 'no-sensitive-content-found' },
              resourceId: `repo_artifact_route_${suffix}`,
              strategy: 'git',
              workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
            },
            patchPayload: null,
            review: {
              actionCenterRowId: `workspace-review:artifact-route-${suffix}`,
              changeSetId: `workspace-change-artifact-route-${suffix}`,
              createdAt: completedAt,
              diffSummary: { additions: 0, deletions: 0, filesChanged: 0 },
              id: `workspace-review-artifact-route-${suffix}`,
              riskSummary: 'Artifact route ownership exclusion fixture.',
              staging: {
                ref: `staging://artifact-route/${suffix}`,
                strategy: 'git_worktree',
              },
              status: 'pending',
              updatedAt: completedAt,
              validation: [],
              workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
            },
          } satisfies Parameters<typeof recordWorkspaceSyncReview>[1]['item'];
          recordTestWorkspaceReviewMaterialization(syncDb, item);
          recordWorkspaceSyncReview(syncDb, { item });
          if (suffix === 'first')
            updateWorkspaceSyncReviewDecision(syncDb, {
              workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
              reviewId: item.review.id,
              status: 'rejected',
              requestId: 'reject-workspace-review-evidence',
              updatedAt: completedAt,
            });
        }

        // An explicitly submitted output with the same presentation remains a deliverable.
        const catalog = await app.request(
          ...operationRequest('artifact.list', {
            workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
          })
        );
        expect(catalog.status).toBe(200);
        expect(
          ListArtifactsResponseSchema.parse(await catalog.json()).items.map((item) => item.id)
        ).toEqual(['ar_00000000-0000-7f70-84f9-64a58b07cc9f']);
        const historical = await app.request(
          ...operationRequest('artifact.read', {
            workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
            artifactId: 'ar_00000000-0000-71cf-a641-bd9c6acde17b',
          })
        );
        expect(historical.status).toBe(200);
        const dashboard = await app.request(
          ...operationRequest('workspace.dashboard', {
            workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
          })
        );
        expect(dashboard.status).toBe(200);
        expect(await dashboard.json()).toMatchObject({ counts: { artifactCount: 1 } });
        const workspace = await app.request(
          ...operationRequest('workspace.read', {
            workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
          })
        );
        expect(await workspace.json()).toMatchObject({ counts: { artifactCount: 1 } });
        const workspaces = await app.request('/api/app/operations/workspace.list', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({}),
        });
        expect(
          (await workspaces.json()).items.find(
            (item: { workspace: { id: string } }) =>
              item.workspace.id === 'ws_00000000-0000-7000-8000-000000000001'
          )?.workspace
        ).toEqual(store.getWorkspace('ws_00000000-0000-7000-8000-000000000001'));
        for (let attempt = 0; attempt < 2; attempt++) {
          const renamed = await app.request(
            ...operationRequest(
              'workspace.update',
              { workspaceId: 'ws_00000000-0000-7000-8000-000000000001' },
              {
                method: 'PATCH',
                headers: { 'content-type': 'application/json' },
                body: JSON.stringify({
                  requestId: '09e42375-15b2-4fdd-8b7e-1b9e3c7f2401',
                  name: 'Outputs',
                }),
              }
            )
          );
          expect(renamed.status, await renamed.clone().text()).toBe(200);
          expect(await renamed.json()).toMatchObject({ counts: { artifactCount: 1 } });
        }
        const search = await app.request(
          ...operationRequest('app.search', { query: backing.title }, {})
        );
        expect(search.status).toBe(200);
        expect(
          (await search.json()).items
            .filter((item: { kind: string }) => item.kind === 'artifact')
            .map((item: { id: string }) => item.id)
        ).toEqual(['ar_00000000-0000-7f70-84f9-64a58b07cc9f']);

        const receivingThread = store.createThread(
          'ws_00000000-0000-7000-8000-000000000001',
          'Reference internal evidence'
        );
        const attached = await app.request(
          ...operationRequest(
            'conversation.submit',
            {
              workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
              threadId: receivingThread.id,
            },
            {
              method: 'POST',
              headers: { 'content-type': 'application/json' },
              body: JSON.stringify({
                requestId: 'reject-review-evidence-attachment',
                input: 'Use this output',
                targetRef: 'internal-role:assistant',
                artifactRefs: [
                  { artifactId: 'ar_00000000-0000-7c49-98d1-47c5d31a3268', artifactVersion: 1 },
                ],
              }),
            }
          )
        );
        expect(attached.status).toBe(409);
        expect(await attached.json()).toMatchObject({ code: 'artifact_not_found' });
        expect(
          store.listThreadTurns('ws_00000000-0000-7000-8000-000000000001', receivingThread.id)
        ).toHaveLength(0);
        const threads = await app.request('/api/app/operations/thread.dashboard', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
            threadId: thread.id,
          }),
        });
        expect(threads.status).toBe(200);
        const threadDashboard = await threads.json();
        expect(threadDashboard.artifacts.map((item: { id: string }) => item.id)).toEqual([
          'ar_00000000-0000-7f70-84f9-64a58b07cc9f',
        ]);
        expect(
          threadDashboard.turns
            .flatMap((item: { items: { type: string; artifactId?: string }[] }) => item.items)
            .filter((item: { type: string }) => item.type === 'artifact-reference')
            .map((item: { artifactId: string }) => item.artifactId)
        ).toContain('ar_00000000-0000-7c49-98d1-47c5d31a3268');

        const excludedReplayRes = await postJson(app, decisionPath, request);
        expect(excludedReplayRes.status).toBe(409);
        await expect(excludedReplayRes.json()).resolves.toMatchObject({
          code: 'recovery_required',
        });

        const excludedClaimRes = await postJson(app, secondDecisionPath, secondRequest);
        expect(excludedClaimRes.status).toBe(409);
        await expect(excludedClaimRes.json()).resolves.toMatchObject({
          code: 'recovery_required',
        });
      } finally {
        syncDb.sqlite.close();
      }

      const verificationDb = openWorkspaceDb(dataRoot, 'ws_00000000-0000-7000-8000-000000000001');
      try {
        expect(
          getArtifactReview(verificationDb, 'ar_00000000-0000-7c49-98d1-47c5d31a3268', 1).decision
        ).toBeNull();
      } finally {
        verificationDb.sqlite.close();
      }
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('rolls back a terminal Review decision when its receipt cannot commit', async () => {
    const dataRoot = mkdtempSync(join(tmpdir(), 'openkit-artifact-review-rollback-'));
    const coreDb = openCoreDb(dataRoot);
    applyMigrations(coreDb);
    const store = createDemoStore({ dataRoot });
    recordLocalWorkspaceAccess(coreDb, 'ws_00000000-0000-7000-8000-000000000001');
    const thread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Artifact Review rollback thread'
    );
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Produce rollback Artifact',
      {
        kind: 'user',
        id: 'usr_00000000-0000-7000-8000-000000000001',
      }
    );
    const completedAt = new Date().toISOString();
    store.updateTurn(turn.id, { agentId: 'agent_codex_host' });
    const workspaceDb = openWorkspaceDb(dataRoot, 'ws_00000000-0000-7000-8000-000000000001');
    applyScopedMigrations(workspaceDb);
    createReviewFixture(
      store,
      workspaceDb,
      'ar_00000000-0000-7292-84b1-02fe24f37662',
      'Keep this Review pending after receipt failure.',
      turn.id
    );
    store.updateTurn(turn.id, {
      status: 'completed',
      completedAt,
    });
    workspaceDb.sqlite.exec(`CREATE TRIGGER reject_artifact_review_receipt
      BEFORE INSERT ON idempotency_requests
      WHEN NEW.command_name = 'artifact.review.decide'
      BEGIN SELECT RAISE(ABORT, 'simulated receipt failure'); END`);
    workspaceDb.sqlite.close();
    const app = createApp({ coreDb, dataRoot, store });

    try {
      const response = await postJson(
        app,
        [
          'artifact.review.decide',
          {
            workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
            artifactId: 'ar_00000000-0000-7292-84b1-02fe24f37662',
            artifactVersion: 1,
          },
        ],
        {
          requestId: 'artifact-review-rollback-1',
          decision: 'accepted',
        }
      );
      expect(response.status).toBe(500);
      const verificationDb = openWorkspaceDb(dataRoot, 'ws_00000000-0000-7000-8000-000000000001');
      try {
        expect(
          getArtifactReview(verificationDb, 'ar_00000000-0000-7292-84b1-02fe24f37662', 1).decision
        ).toBeNull();
        expect(
          store.getCommandRequest(
            'artifact.review.decide',
            'artifact-review-rollback-1',
            {
              workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
              artifactId: 'ar_00000000-0000-7292-84b1-02fe24f37662',
              artifactVersion: '1',
            },
            verificationDb
          )
        ).toBeNull();
      } finally {
        verificationDb.sqlite.close();
      }
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('starts one exact redo and fails closed for replay and missing-receipt owner gaps', async () => {
    const dataRoot = mkdtempSync(join(tmpdir(), 'openkit-artifact-review-redo-'));
    const coreDb = openCoreDb(dataRoot);
    applyMigrations(coreDb);
    const target = allocateNanoHostRuntimeTargetConnectionGeneration(coreDb, {
      deploymentId: readDataRootLayoutMarker(dataRoot).deploymentId,
      identityId: 'identity_artifact_redo_fixture',
      observedAt: new Date().toISOString(),
      targetId: 'target_artifact_redo_fixture',
    });
    upsertNanoHostRuntimeTarget(coreDb, {
      ...target,
      freshEmpty: true,
      observedAt: new Date().toISOString(),
      physicalEpoch: 'a'.repeat(64),
      predecessorFenced: true,
      ready: true,
    });
    const store = createDemoStore({ dataRoot });
    recordLocalWorkspaceAccess(coreDb, 'ws_00000000-0000-7000-8000-000000000001');
    const setup = createTestAgentSetup();
    const runtimeAgent = {
      id: setup.manifest.id,
      name: setup.manifest.displayName,
      kind: 'coder',
      status: 'enabled',
      modelId: null,
      skillIds: [],
      profiles: [],
      defaultProfileId: null,
      capabilities: [],
      sandboxSummary: null,
      health: { status: 'ready', message: null, checkedAt: new Date().toISOString() },
    } as const;
    store.upsertAgent('ws_00000000-0000-7000-8000-000000000001', runtimeAgent);
    const workspaceDb = openWorkspaceDb(dataRoot, 'ws_00000000-0000-7000-8000-000000000001');
    applyScopedMigrations(workspaceDb);
    const thread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Artifact Review redo thread'
    );
    const sourceTurn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Produce redo Artifact',
      {
        kind: 'user',
        id: 'usr_00000000-0000-7000-8000-000000000001',
      }
    );
    const completedAt = new Date().toISOString();
    store.updateTurn(sourceTurn.id, { agentId: setup.manifest.id });
    createReviewFixture(
      store,
      workspaceDb,
      'ar_00000000-0000-7431-9ff1-49c2a2686f52',
      'Redo this exact output.',
      sourceTurn.id
    );
    store.updateTurn(sourceTurn.id, {
      status: 'completed',
      completedAt,
    });
    const partialThread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Artifact Review partial thread'
    );
    const partialSourceTurn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      partialThread.id,
      'Produce partial Artifact',
      { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' }
    );
    store.updateTurn(partialSourceTurn.id, { agentId: setup.manifest.id });
    createReviewFixture(
      store,
      workspaceDb,
      'ar_00000000-0000-7c8a-afc3-6af1d0f39c53',
      'Do not resume partial proof.',
      partialSourceTurn.id
    );
    store.updateTurn(partialSourceTurn.id, {
      status: 'completed',
      completedAt,
    });
    const partialRequestId = 'artifact-review-partial-1';
    const partialFollowUpTurnId = deriveArtifactReviewFollowUpTurnId(
      'ws_00000000-0000-7000-8000-000000000001',
      'ar_00000000-0000-7c8a-afc3-6af1d0f39c53',
      1,
      partialRequestId
    );
    const orphanTurn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      partialThread.id,
      'Contradictory partial proof',
      { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
      null,
      {
        turnId: partialFollowUpTurnId,
      }
    );
    store.updateTurn(orphanTurn.id, {
      status: 'completed',
      completedAt,
    });
    workspaceDb.sqlite.close();
    const app = createApp({
      agentManifests: [setup.manifest],
      coreDb,
      dataRoot,
      providerRegistry: new ProviderRegistry([
        {
          displayName: 'Agent OpenRouter',
          id: 'agent-openrouter',
          kind: 'local',
          models: ['openai/gpt-5.2'],
        },
      ]),
      store,
    });
    const repositoryPath = mkdtempSync(join(tmpdir(), 'openkit-artifact-review-repository-'));
    seedWritableGitRepository(repositoryPath);
    const decisionPath = [
      'artifact.review.decide',
      {
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        artifactId: 'ar_00000000-0000-7431-9ff1-49c2a2686f52',
        artifactVersion: 1,
      },
    ] as const;
    const request = {
      requestId: '0190f4c8-0000-7000-8000-000000000401',
      decision: 'redo',
      feedback: 'Rework the response with the missing evidence.',
    } as const;

    try {
      const dispatch = vi.spyOn(schedulerDispatch, 'runSchedulerDispatchLoop');
      let responseSettled = false;
      const pendingResponse = postJson(app, decisionPath, request).then((response) => {
        responseSettled = true;
        return response;
      });
      try {
        // This local command must publish its receipt before waiting for the follow-up execution.
        await vi.waitFor(() =>
          expect(
            responseSettled,
            'Artifact review acknowledgement must not wait for a worker whose dispatch requires that receipt.'
          ).toBe(true)
        );
      } finally {
        const ownCalls = dispatch.mock.calls
          .map(([input], index) => ({ input, index }))
          .filter(({ input }) => input.store === store);
        for (const { index } of ownCalls) {
          const result = dispatch.mock.results[index];
          if (result?.type === 'return') {
            console.info('artifact_redo_dispatch_observation', JSON.stringify(await result.value));
          }
        }
        console.info(
          'artifact_redo_admission_observation',
          JSON.stringify(
            listSchedulerAdmissionEntriesForWorkspace(coreDb, {
              workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
              statuses: ['queued', 'admitted', 'denied', 'cancelled'],
            })
          )
        );
        dispatch.mockRestore();
      }
      const response = await pendingResponse;
      const responseBody = await response.json();
      expect(response.status, JSON.stringify(responseBody)).toBe(200);
      const decided = SubmitArtifactReviewDecisionResponseSchema.parse(responseBody);
      const followUpTurnId = deriveArtifactReviewFollowUpTurnId(
        'ws_00000000-0000-7000-8000-000000000001',
        'ar_00000000-0000-7431-9ff1-49c2a2686f52',
        1,
        request.requestId
      );
      expect(decided).toMatchObject({ decision: 'redo', followUpTurnId });
      await vi.waitFor(() =>
        expect(
          store.getTurn('ws_00000000-0000-7000-8000-000000000001', thread.id, followUpTurnId).status
        ).toBe('completed')
      );
      expect(
        store.getTurn('ws_00000000-0000-7000-8000-000000000001', thread.id, followUpTurnId)
      ).toMatchObject({
        id: followUpTurnId,
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        threadId: thread.id,
        agentId: setup.manifest.id,
      });
      const admissions = listSchedulerAdmissionEntriesForWorkspace(coreDb, {
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        statuses: ['admitted'],
      }).filter((entry) => entry.turnId === followUpTurnId);
      expect(admissions).toEqual([
        expect.objectContaining({
          requestId: request.requestId,
          requestedAgentId: setup.manifest.id,
          threadId: thread.id,
          turnId: followUpTurnId,
        }),
      ]);
      expect(JSON.parse(admissions[0]?.turnInput ?? '{}')).toMatchObject({
        artifactMediaType: 'text/plain',
      });
      const checkpointDb = openWorkspaceDb(dataRoot, 'ws_00000000-0000-7000-8000-000000000001');
      try {
        expect(
          getWorkerCheckpoint(
            checkpointDb,
            'ws_00000000-0000-7000-8000-000000000001',
            thread.id,
            followUpTurnId
          )
        ).toMatchObject({
          stage: 'completed',
          workerSessionId: expect.any(String),
        });
      } finally {
        checkpointDb.sqlite.close();
      }

      const replayRes = await postJson(app, decisionPath, request);
      expect(replayRes.status).toBe(200);
      expect(SubmitArtifactReviewDecisionResponseSchema.parse(await replayRes.json())).toEqual(
        decided
      );

      const tamperedPrompt = {
        ...(JSON.parse(admissions[0]?.turnInput ?? '{}') as Record<string, unknown>),
        artifactContent: 'Tampered scheduler content.',
      };
      coreDb.sqlite
        .prepare('UPDATE scheduler_admission_entries SET turn_input = ? WHERE turn_id = ?')
        .run(JSON.stringify(tamperedPrompt), followUpTurnId);
      const corruptReplayRes = await postJson(app, decisionPath, request);
      expect(corruptReplayRes.status).toBe(409);
      await expect(corruptReplayRes.json()).resolves.toMatchObject({ code: 'recovery_required' });

      const receiptDb = openWorkspaceDb(dataRoot, 'ws_00000000-0000-7000-8000-000000000001');
      receiptDb.sqlite
        .prepare(
          "DELETE FROM idempotency_requests WHERE command_name = 'artifact.review.decide' AND request_id = ?"
        )
        .run(request.requestId);
      receiptDb.sqlite.close();
      const changedClaimRes = await postJson(app, decisionPath, {
        ...request,
        feedback: 'Changed missing-receipt input.',
      });
      expect(changedClaimRes.status).toBe(409);
      await expect(changedClaimRes.json()).resolves.toMatchObject({
        code: 'idempotency_key_conflict',
      });

      store.upsertAgent('ws_00000000-0000-7000-8000-000000000001', {
        ...runtimeAgent,
        status: 'disabled',
      });
      const disabledGapRes = await postJson(app, decisionPath, request);
      expect(disabledGapRes.status).toBe(409);
      await expect(disabledGapRes.json()).resolves.toMatchObject({ code: 'recovery_required' });

      const partialRes = await postJson(
        app,
        [
          'artifact.review.decide',
          {
            workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
            artifactId: 'ar_00000000-0000-7c8a-afc3-6af1d0f39c53',
            artifactVersion: 1,
          },
        ],
        {
          requestId: partialRequestId,
          decision: 'redo',
          feedback: 'Try the partial request again.',
        }
      );
      expect(partialRes.status).toBe(409);
      await expect(partialRes.json()).resolves.toMatchObject({ code: 'recovery_required' });
      const verificationDb = openWorkspaceDb(dataRoot, 'ws_00000000-0000-7000-8000-000000000001');
      try {
        expect(
          getArtifactReview(verificationDb, 'ar_00000000-0000-7c8a-afc3-6af1d0f39c53', 1).decision
        ).toBeNull();
      } finally {
        verificationDb.sqlite.close();
      }
    } finally {
      coreDb.sqlite.close();
    }
  });
});

// This fixture supplies confirmed image evidence; the production resolver and subject checks still run.
vi.mock('./runtime/agent-environment.js', async (importOriginal) => {
  const actual = await importOriginal<typeof import('./runtime/agent-environment.js')>();
  const { withTestPreparedNativeEnvironment } = await import(
    './test-support/native-environment.js'
  );
  return withTestPreparedNativeEnvironment(actual);
});
