// openkit-test-platform: posix

import { createHash } from 'node:crypto';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, expect, it, vi } from 'vitest';
import { createOpenKitAccessTokenRecord } from './auth/access-token-store.js';
import { FsStore } from './lib/store.js';
import { closeRetrievalServices } from './retrieval-service.js';
import { openCoreDb } from './storage/db.js';
import { applyMigrations } from './storage/migrate.js';
import { createAppWithWorkspaceAuthority as createApp } from './test-support/app.js';
import { testEntityId } from './test-support/entity-ids.js';
import { ensureLocalUser } from './test-support/local-user.js';
import { operationRequest } from './test-support/operation-request.js';
import { recordWorkspaceOwnerMembership } from './workspace-membership.js';

describe('dashboard and search Thread audiences', () => {
  it('binds private creation to the actor and keeps explicitly shared work shared', async () => {
    const store = new FsStore();
    const workspace = store.createWorkspace('Creation team');
    const app = createApp({ store });
    for (const visibility of ['private', 'workspace'] as const) {
      const response = await ((input: Record<string, unknown>) =>
        app.request('/api/app/operations/thread.create', {
          method: 'POST',
          headers: {
            ...{
              ...{ 'content-type': 'application/json' },
              'content-type': 'application/json',
              'x-openkit-request-id':
                visibility === 'private'
                  ? '11111111-1111-4111-8111-111111111111'
                  : '22222222-2222-4222-8222-222222222222',
            },
            ...(typeof input.requestId === 'string'
              ? { 'x-openkit-request-id': input.requestId }
              : {}),
          },
          body: JSON.stringify(input),
        }))({
        ...{
          requestId:
            visibility === 'private'
              ? '11111111-1111-4111-8111-111111111111'
              : '22222222-2222-4222-8222-222222222222',
          name: 'New work',
          visibility,
        },
        workspaceId: workspace.id,
      });
      expect(response.status).toBe(200);
      const thread = await response.json();
      expect(thread.visibility).toBe(visibility);
      expect(thread.privateOwnerUserId).toBe(
        visibility === 'private' ? 'usr_00000000-0000-7000-8000-000000000001' : undefined
      );
    }
  });

  it('keeps visibility and private ownership immutable under metadata updates', () => {
    const store = new FsStore();
    const workspace = store.createWorkspace('Immutable audience');
    const thread = store.createThread(workspace.id, 'Private', undefined, 'conversation', {
      visibility: 'private',
      privateOwnerUserId: 'usr_00000000-0000-7000-8000-000000000001',
    });
    const changed = store.updateThread(workspace.id, thread.id, {
      name: 'Renamed',
      visibility: 'workspace',
      privateOwnerUserId: 'usr_00000000-0000-73d4-904a-d4c4b905df7c',
    } as never);
    expect(changed).toMatchObject({
      name: 'Renamed',
      visibility: 'private',
      privateOwnerUserId: 'usr_00000000-0000-7000-8000-000000000001',
    });
  });

  it('requires shared inception for formal Task and Goal work without converting private history', async () => {
    const store = new FsStore();
    const workspace = store.createWorkspace('Formal admission');
    const thread = store.createThread(workspace.id, 'Private source', undefined, 'conversation', {
      visibility: 'private',
      privateOwnerUserId: 'usr_00000000-0000-7000-8000-000000000001',
    });
    const app = createApp({ store });
    for (const _mode of ['task']) {
      const response = await app.request(
        ...operationRequest(
          'task.start',
          { workspaceId: workspace.id, threadId: thread.id },
          {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({
              requestId: '44444444-4444-4444-8444-444444444444',
              input: 'Start formal work',
            }),
          }
        )
      );
      expect(response.status).toBe(409);
      expect(await response.json()).toMatchObject({
        code: 'shared_thread_required',
      });
      expect(store.getThread(workspace.id, thread.id).visibility).toBe('private');
      expect(store.listThreadTurns(workspace.id, thread.id)).toEqual([]);
    }
  });

  it('creates a new shared Goal from a private origin without changing its audience', async () => {
    const store = new FsStore();
    const ws = store.createWorkspace('Goal inception');
    const origin = store.createThread(ws.id, 'Private origin', undefined, 'conversation', {
      visibility: 'private',
      privateOwnerUserId: 'usr_00000000-0000-7000-8000-000000000001',
    });
    const app = createApp({ store });
    const response = await app.request('/api/app/operations/goal.create', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-openkit-request-id': '12345678-1234-4234-8234-123456789012',
      },
      body: JSON.stringify({
        workspaceId: ws.id,
        originThreadId: origin.id,
        intent: 'Review design',
      }),
    });
    expect(response.status).toBe(200);
    const data = await response.json();
    expect(store.getThread(ws.id, data.goal.threadId).visibility).toBe('workspace');
    expect(store.getThread(ws.id, origin.id).visibility).toBe('private');
  });

  it('isolates private content before discovery and preserves shared work for members and admin', async () => {
    const dataRoot = mkdtempSync(join(tmpdir(), 'openkit-visibility-'));
    const coreDb = openCoreDb(dataRoot);
    applyMigrations(coreDb);
    ensureLocalUser(coreDb);
    const store = new FsStore({ dataRoot });
    const workspace = store.createWorkspace('Team');
    recordWorkspaceOwnerMembership({
      coreDb,
      ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
      workspaceId: workspace.id,
    });
    const now = Date.now();
    coreDb.sqlite
      .prepare(
        `INSERT INTO users (id, display_name, email, email_verified, created_at, updated_at, kind, status, disabled_at) VALUES ('usr_00000000-0000-73d4-904a-d4c4b905df7c', 'Other', 'other@example.invalid', false, ?, ?, 'human', 'active', NULL)`
      )
      .run(now, now);
    const stamp = '2026-09-14T00:00:00.000Z';
    coreDb.sqlite
      .prepare(
        `INSERT INTO workspace_members (workspace_id, user_id, status, access_level, invitation_id, joined_at, removed_at, revision, created_at, updated_at) VALUES (?, 'usr_00000000-0000-73d4-904a-d4c4b905df7c', 'active', 'editor', NULL, ?, NULL, 1, ?, ?)`
      )
      .run(workspace.id, stamp, stamp, stamp);
    const threads = [
      'local-private',
      'other-private',
      'Task',
      'Goal',
      'missing',
      'contradictory',
    ].map((label) => {
      const thread = store.createThread(workspace.id, `${label} needle`);
      const raw = thread as unknown as Record<string, unknown>;
      delete raw.privateOwnerUserId;
      if (label.endsWith('private'))
        Object.assign(raw, {
          visibility: 'private',
          privateOwnerUserId: label.startsWith('local')
            ? 'usr_00000000-0000-7000-8000-000000000001'
            : 'usr_00000000-0000-73d4-904a-d4c4b905df7c',
        });
      else Object.assign(raw, { visibility: 'workspace' });
      const turn = store.createTurn(workspace.id, thread.id, `${label} needle`, {
        kind: 'user',
        id: 'usr_00000000-0000-7000-8000-000000000001',
      });
      store.createItem({
        id: testEntityId('it', `it_${label}`),
        workspaceId: workspace.id,
        threadId: thread.id,
        turnId: turn.id,
        type: 'assistant-message',
        status: 'completed',
        text: `${label} needle content`,
        createdAt: stamp,
        completedAt: stamp,
      });
      if (label !== 'missing' && label !== 'contradictory')
        store.createArtifact({
          id: testEntityId('ar', `ar_${label}`),
          workspaceId: workspace.id,
          threadId: thread.id,
          turnId: turn.id,
          kind: 'summary',
          title: `${label} needle artifact`,
          status: 'ready',
          summary: `${label} needle summary`,
          version: 1,
          content: { format: 'text', body: `${label} output` },
          contentDigest: `sha256:${createHash('sha256').update(`${label} output`).digest('hex')}`,
          lastMutationRequestId: `artifact-${label}`,
          origin: {
            kind: 'turn-output',
            threadId: thread.id,
            turnId: turn.id,
            requestId: `artifact-${label}`,
          },
          createdAt: stamp,
          updatedAt: stamp,
        });
      return thread;
    });
    const sharedTurn = store.listThreadTurns(workspace.id, threads[2]!.id)[0]!;
    for (const label of ['local-private', 'other-private'])
      store.createItem({
        id: testEntityId('it', `it_link_${label}`),
        workspaceId: workspace.id,
        threadId: threads[2]!.id,
        turnId: sharedTurn.id,
        type: 'artifact-reference',
        status: 'completed',
        artifactId: testEntityId('ar', `ar_${label}`),
        artifactVersion: 1,
        lastMutationRequestId: `link-${label}`,
        title: `${label} needle artifact`,
        summary: `${label} needle summary`,
        createdAt: stamp,
        completedAt: stamp,
      });
    // Simulate unavailable audience projections at the read owner. Durable fixture writes stay valid.
    let exposeUnavailableAudience = true;
    const unavailableAudience = (thread: ReturnType<FsStore['getThread']>) => {
      if (!exposeUnavailableAudience) return thread;
      const copy = { ...thread } as unknown as Record<string, unknown>;
      if (thread.id === threads[4]!.id) delete copy.visibility;
      if (thread.id === threads[5]!.id)
        copy.privateOwnerUserId = 'usr_00000000-0000-73d4-904a-d4c4b905df7c';
      return copy as unknown as typeof thread;
    };
    const getThread = store.getThread.bind(store);
    const listThreads = store.listThreads.bind(store);
    vi.spyOn(store, 'getThread').mockImplementation((workspaceId, threadId) =>
      unavailableAudience(getThread(workspaceId, threadId))
    );
    vi.spyOn(store, 'listThreads').mockImplementation((workspaceId) =>
      listThreads(workspaceId).map(unavailableAudience)
    );
    const app = createApp({
      auth: {
        api: { getSession: async () => null },
        handler: async () => new Response(null, { status: 404 }),
      },
      coreDb,
      dataRoot,
      mode: 'server',
      store,
    });
    try {
      for (const [userId, scope] of [
        ['usr_00000000-0000-7000-8000-000000000001', 'workspace-readonly'],
        ['usr_00000000-0000-73d4-904a-d4c4b905df7c', 'workspace-readonly'],
        ['usr_00000000-0000-7000-8000-000000000001', 'server-admin'],
      ] as const) {
        const token = createOpenKitAccessTokenRecord(coreDb, {
          ownerUserId: userId,
          scope,
          workspaceIds: scope === 'server-admin' ? [] : [workspace.id],
          expiresAt: '2999-01-01T00:00:00.000Z',
        });
        const headers = { authorization: `Bearer ${token.secret}` };
        const own =
          userId === 'usr_00000000-0000-7000-8000-000000000001' ? threads[0]! : threads[1]!;
        const denied =
          userId === 'usr_00000000-0000-7000-8000-000000000001' ? threads[1]! : threads[0]!;
        const readItems = vi.spyOn(store, 'listThreadItems');
        const dashboard = await app.request(
          ...operationRequest(
            'workspace.dashboard',
            { workspaceId: workspace.id },
            {
              headers,
            }
          )
        );
        expect(dashboard.status).toBe(200);
        const body = await dashboard.json();
        expect(body.recentThreads.map((thread: { id: string }) => thread.id).sort()).toEqual(
          [
            own.id,
            ...(scope === 'server-admin' ? [denied.id] : []),
            threads[2]!.id,
            threads[3]!.id,
          ].sort()
        );
        expect(body.counts.threadCount).toBe(scope === 'server-admin' ? 4 : 3);
        expect(body.counts.artifactCount).toBe(scope === 'server-admin' ? 4 : 3);
        expect(body.workspace.counts).toEqual({
          threadCount: scope === 'server-admin' ? 4 : 3,
          artifactCount: scope === 'server-admin' ? 4 : 3,
          knowledgeEntryCount: 0,
        });
        const localPrivateArtifactId = testEntityId('ar', 'ar_local-private');
        const otherPrivateArtifactId = testEntityId('ar', 'ar_other-private');
        const deniedArtifactId =
          userId === 'usr_00000000-0000-7000-8000-000000000001'
            ? otherPrivateArtifactId
            : localPrivateArtifactId;
        const ownArtifactId =
          userId === 'usr_00000000-0000-7000-8000-000000000001'
            ? localPrivateArtifactId
            : otherPrivateArtifactId;
        const catalog = await app.request(
          ...operationRequest('artifact.list', { workspaceId: workspace.id }, { headers })
        );
        expect(catalog.status).toBe(200);
        expect((await catalog.json()).items.map((item: { id: string }) => item.id).sort()).toEqual(
          [
            ownArtifactId,
            ...(scope === 'server-admin' ? [deniedArtifactId] : []),
            testEntityId('ar', 'ar_Task'),
            testEntityId('ar', 'ar_Goal'),
          ].sort()
        );
        const record = await app.request(
          ...operationRequest('workspace.read', { workspaceId: workspace.id }, { headers })
        );
        expect(await record.json()).toMatchObject({
          counts: { artifactCount: scope === 'server-admin' ? 4 : 3 },
        });
        {
          const hidden = await app.request(
            ...operationRequest(
              'artifact.read',
              { workspaceId: workspace.id, artifactId: deniedArtifactId },
              { headers }
            )
          );
          expect(hidden.status).toBe(scope === 'server-admin' ? 200 : 404);
          if (scope !== 'server-admin') expect(await hidden.text()).not.toContain(denied.name);
          const visible = await app.request(
            ...operationRequest(
              'artifact.read',
              { workspaceId: workspace.id, artifactId: ownArtifactId },
              { headers }
            )
          );
          expect(visible.status).toBe(200);
        }
        const hiddenReview = await app.request(
          ...operationRequest(
            'artifact.review-list',
            { workspaceId: workspace.id, artifactId: deniedArtifactId },
            { headers }
          )
        );
        expect(hiddenReview.status).toBe(scope === 'server-admin' ? 200 : 404);
        if (scope === 'server-admin') {
          exposeUnavailableAudience = false;
          const receiving = store.createThread(workspace.id, 'Attachment audience');
          const attached = await app.request(
            ...operationRequest(
              'conversation.submit',
              { workspaceId: workspace.id, threadId: receiving.id },
              {
                method: 'POST',
                headers: { ...headers, 'content-type': 'application/json' },
                body: JSON.stringify({
                  requestId: 'private-artifact-attachment',
                  input: 'Use output',
                  targetRef: 'internal-role:assistant',
                  artifactRefs: [{ artifactId: deniedArtifactId, artifactVersion: 1 }],
                }),
              }
            )
          );
          expect(attached.status, await attached.clone().text()).toBe(409);
          expect(await attached.json()).toMatchObject({ code: 'artifact_not_found' });
          expect(store.listThreadTurns(workspace.id, receiving.id)).toEqual([]);
          const source = store.getArtifact(workspace.id, ownArtifactId);
          store.createArtifact({
            ...source,
            id: 'ar_00000000-0000-756e-88a2-a6c7d0485997',
            kind: 'file',
            title: 'Imported safe content',
            summary: null,
            threadId: null,
            turnId: null,
            origin: {
              kind: 'imported',
              sourceKind: 'direct-import',
              sourceId: 'import-safe',
              sourceDigest: source.contentDigest,
              actor: { kind: 'user', id: userId },
              requestId: 'import-safe',
              recordedAt: stamp,
            },
            lastMutationRequestId: 'import-safe',
          });
          const introduced = await app.request(
            ...operationRequest(
              'artifact.introduce',
              {
                workspaceId: workspace.id,
                threadId: denied.id,
                artifactId: 'ar_00000000-0000-756e-88a2-a6c7d0485997',
              },
              {
                method: 'POST',
                headers: { ...headers, 'content-type': 'application/json' },
                body: JSON.stringify({
                  requestId: 'forbidden-introduction',
                  expectedArtifactVersion: 1,
                }),
              }
            )
          );
          expect(introduced.status).toBe(409);
          expect(await introduced.json()).toMatchObject({ code: 'thread_busy' });
        }
        exposeUnavailableAudience = true;
        const search = await app.request(
          ...operationRequest('app.search', { query: 'needle' }, { headers })
        );
        expect(search.status, await search.clone().text()).toBe(200);
        const hits = await search.json();
        expect(
          hits.items
            .filter((item: { kind: string }) => item.kind === 'thread')
            .map((item: { id: string }) => item.id)
            .sort()
        ).toEqual(
          [
            own.id,
            ...(scope === 'server-admin' ? [denied.id] : []),
            threads[2]!.id,
            threads[3]!.id,
          ].sort()
        );
        if (scope !== 'server-admin') expect(JSON.stringify(hits)).not.toContain(denied.name);
        expect(
          hits.items.filter((item: { kind: string }) => item.kind === 'artifact')
        ).toHaveLength(scope === 'server-admin' ? 4 : 3);
        for (const hidden of [denied, threads[4]!, threads[5]!]) {
          if (scope !== 'server-admin' || hidden.id !== denied.id)
            expect(readItems.mock.calls.some((args) => args[1] === hidden.id)).toBe(false);
          const direct = await app.request('/api/app/operations/thread.dashboard', {
            ...{ headers },
            method: 'POST',
            headers: { ...headers, ...headers, 'content-type': 'application/json' },
            body: JSON.stringify({ workspaceId: workspace.id, threadId: hidden.id }),
          });
          if (scope === 'server-admin' && [own.id, denied.id].includes(hidden.id)) {
            expect(direct.status).toBe(200);
          } else {
            expect(direct.status).toBe(404);
            expect(await direct.text()).not.toContain(hidden.name);
          }
        }
        for (const visible of [own, threads[2]!, threads[3]!]) {
          const response = await app.request('/api/app/operations/thread.dashboard', {
            ...{ headers },
            method: 'POST',
            headers: { ...headers, ...headers, 'content-type': 'application/json' },
            body: JSON.stringify({ workspaceId: workspace.id, threadId: visible.id }),
          });
          expect(response.status).toBe(200);
          if (scope !== 'server-admin') expect(await response.text()).not.toContain(denied.name);
        }
        readItems.mockRestore();
      }
    } finally {
      await closeRetrievalServices();
      vi.restoreAllMocks();
      coreDb.sqlite.close();
      rmSync(dataRoot, { recursive: true, force: true });
    }
  });
});
