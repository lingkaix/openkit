import { createHash } from 'node:crypto';
import { existsSync, lstatSync, mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { isDeepStrictEqual } from 'node:util';
import type {
  IntroduceWorkspaceArtifactResponse,
  KnowledgeClaim,
  KnowledgeConflict,
  KnowledgeConflictStatus,
  KnowledgeManagerDraftProposalRequest,
  KnowledgeManagerDraftProposalResponse,
  KnowledgeObservation,
  KnowledgeProposalApplication,
  KnowledgeProposalReview,
  MaterializedWorkspaceRoot,
  ReverseKnowledgeProposalResponse,
  SubmitKnowledgeProposalDecisionRequest,
  SubmitKnowledgeProposalDecisionResponse,
} from '@openkit/app-api-schemas';
import {
  KnowledgeManagerDraftProposalRequestSchema,
  KnowledgeProposalReviewSchema,
  ReverseKnowledgeProposalResponseSchema,
  SubmitKnowledgeProposalDecisionRequestSchema,
  SubmitKnowledgeProposalDecisionResponseSchema,
} from '@openkit/app-api-schemas';
import type {
  ActorRef,
  KnowledgeEntrySchema,
  WorkspaceRecordSchema,
  WorkspaceResourcesSchema,
} from '@openkit/protocol';
import {
  type AgentSessionSchema,
  type ApprovalRequestSchema,
  ArtifactSchema,
  allocateEntityId,
  deriveEntityId,
  ItemSchema,
  isSealedTurnTerminal,
  PROTOCOL_VERSION,
  RequestIdSchema,
  responsibleUserIdForActor,
  SseEventEnvelopeSchema,
  ThreadSchema,
  TurnSchema,
  type TurnStatus,
} from '@openkit/protocol';
import { resolveDataRoot } from '../config/data-root.js';
import { loadOpenKitConfig } from '../config/openkit-config.js';
import { captureCoverageBindingFromOpenKitConfig } from '../config/runtime-config.js';
import { uuidv5 } from '../generative-kernel/uuid.js';
import {
  type KnowledgePageReferenceProof,
  KnowledgePageValidationError,
  parseOkfDocument,
  stringListFrontmatterField,
  validateKnowledgePageCandidate,
} from '../knowledge/okf.js';
import { OperationError } from '../operation-error.js';
import { ensureTurnFeedback } from '../runtime/feedback.js';
import { loadApprovalProjections } from '../runtime/pending-requests.js';
import type { RuntimeAgent } from '../runtime/types.js';
import type { AppDb } from '../storage/app-db.js';
import type { StagedArtifactPayload } from '../storage/artifacts/file-payload.js';
import { verifyArtifactFilePayload } from '../storage/artifacts/file-records.js';
import {
  getCommandRequestRecord,
  getCommandRequestRecordFromDb,
  listCommandRequestRecords,
  normalizeCommandRequestResponse,
  recordCommandRequestRecord,
  recordCommandRequestRecordInDb,
} from '../storage/command-request-records.js';
import { type CoreDb, openWorkspaceDbAtRoot, type WorkspaceDb } from '../storage/db.js';
import {
  ensureLayoutDirectories,
  ensureWorkspaceLayout,
  ensureWorkspaceLayoutRoot,
  resolveDataRootPath,
} from '../storage/fs-layout.js';
import { applyScopedMigrations } from '../storage/migrate.js';
import {
  AgentSessionRecordSchema,
  appendWorkspaceItemRevision,
  appendWorkspaceTurnEvent,
  artifactReferenceItemId,
  assertCanonicalDirectory,
  assertImmutableItemAttribution,
  assertSafeWorkspacePathSegment,
  assertTurnEventPayloadLineage,
  type CaptureCoverageBinding,
  CaptureCoverageBindingSchema,
  deleteWorkspaceKnowledgeRecord,
  isCurrentAgentSessionStatus,
  KnowledgeProposalRecordSchema,
  KnowledgeProposalReviewFileSchema,
  loadWorkspaceFileRecords,
  parseCanonicalWorkspaceHistory,
  parseOwnedKnowledgeEntry,
  publishArtifactFileRecord,
  publishCanonicalPath,
  readCanonicalTextFile,
  readWorkspaceKnowledgePage,
  readWorkspaceTurnEvents,
  serializeKnowledgeProposalRecord,
  serializeUserAuthoredKnowledgePage,
  TURN_STREAM_EVENT_WINDOW_SIZE,
  updateUserAuthoredKnowledgePage,
  type WorkspaceFileRecords,
  writeFileAtomic,
  writeWorkspaceFileRecords,
} from '../storage/workspace-file-records.js';
import { isTargetIssuedEffectAuthority } from '../storage/workspace-import-authority.js';
import {
  appendWorkspaceKnowledgeClaim,
  appendWorkspaceKnowledgeConflict,
  appendWorkspaceKnowledgeObservation,
  readWorkspaceKnowledgeClaimLedger,
  readWorkspaceKnowledgeConflictLedger,
  readWorkspaceKnowledgeObservationLedger,
} from '../storage/workspace-portable-file-state.js';

type WorkspaceRecord = import('zod').infer<typeof WorkspaceRecordSchema>;
type ProtocolWorkspaceResources = import('zod').infer<typeof WorkspaceResourcesSchema>;
type WorkspaceResources = Omit<ProtocolWorkspaceResources, 'agents'> & { agents: RuntimeAgent[] };

/** Staged workspace root made available before an imported workspace is published. */
export interface ImportWorkspaceStage {
  /** Imported workspace id. */
  workspaceId: string;
  /** Same-filesystem staging root that will be renamed into the final workspace root. */
  workspaceRoot: string;
}

type KnowledgeEntry = import('zod').infer<typeof KnowledgeEntrySchema>;
type Thread = import('zod').infer<typeof ThreadSchema>;
type Turn = import('zod').infer<typeof TurnSchema>;
type Item = import('zod').infer<typeof ItemSchema>;
type Artifact = import('zod').infer<typeof ArtifactSchema>;
type ApprovalRequest = import('zod').infer<typeof ApprovalRequestSchema>;
type Agent = RuntimeAgent;
type ProtocolAgentSession = import('zod').infer<typeof AgentSessionSchema>;

/** Conflict states that remain unresolved for Knowledge Proposal publication. */
const UNRESOLVED_KNOWLEDGE_CONFLICT_STATUSES = new Set<KnowledgeConflictStatus>([
  'conflicting',
  'needs_review',
  'weak_evidence',
  'stale',
]);

/** Durable app-local AgentSession stored beside protocol-safe session fields. */
export type AgentSession = ProtocolAgentSession & {
  configVersion: number | null;
  environmentPackageSnapshotId: string | null;
  /** Accepted ready native handle digest; with `id` as locator it is the resume pair. */
  nativeHandleDigest: string | null;
  /** Historical admitted association and slot; grants no current attachment authority. */
  retainedStorage: { storageRef: string; workSlotRef: string } | null;
  policySnapshotId: string | null;
  sessionCompatibilityKey: string | null;
  stale: boolean;
  workspaceRoots: MaterializedWorkspaceRoot[];
};
type SseEventEnvelope = import('zod').infer<typeof SseEventEnvelopeSchema>;
type AgentSessionInput = Omit<
  AgentSession,
  | 'configVersion'
  | 'environmentPackageSnapshotId'
  | 'nativeHandleDigest'
  | 'retainedStorage'
  | 'policySnapshotId'
  | 'sandboxSummary'
  | 'sessionCompatibilityKey'
  | 'stale'
  | 'workspaceRoots'
> &
  Partial<
    Pick<
      AgentSession,
      | 'configVersion'
      | 'environmentPackageSnapshotId'
      | 'nativeHandleDigest'
      | 'retainedStorage'
      | 'policySnapshotId'
      | 'sandboxSummary'
      | 'sessionCompatibilityKey'
      | 'stale'
      | 'workspaceRoots'
    >
  >;

type EventListener = (event: SseEventEnvelope) => void;
type TurnEventInput = Omit<
  SseEventEnvelope,
  'protocolVersion' | 'requestId' | 'sequence' | 'timestamp'
> & {
  requestId?: string | null;
};

const COMMAND_REQUEST_RETENTION_MS = 7 * 24 * 60 * 60 * 1000;

/**
 * Stable command names tracked by the app-local idempotency ledger.
 */
export type CommandRequestName =
  | 'workspace.create'
  | 'workspace.update'
  | 'workspace.invitation.create'
  | 'workspace.invitation.accept'
  | 'workspace.invitation.decline'
  | 'workspace.invitation.revoke'
  | 'workspace.member.access.change'
  | 'workspace.member.remove'
  | 'workspace.leave'
  | 'workspace.ownership.transfer'
  | 'workspace.access.recover'
  | 'workspace.delete'
  | 'user.disable'
  | 'knowledge.create'
  | 'knowledge.update'
  | 'knowledge.delete'
  | 'knowledge.source.register'
  | 'knowledge.observation.record'
  | 'knowledge.claim.record'
  | 'knowledge.conflict.record'
  | 'knowledge.conflict.resolve'
  | 'thread.create'
  | 'thread.update'
  | 'thread.archive'
  | 'conversation.submit'
  | 'task.start'
  | 'turn.start'
  | 'turn.input.submit'
  | 'turn.interrupt'
  | 'git_push.approval.request'
  | 'git_push.execute'
  | 'approval.respond'
  | 'user_input.answer'
  | 'pending_request.withdraw'
  | 'workspace_sync.review.decide'
  | 'workspace_sync.recovery.decide'
  | 'knowledge.proposal.draft'
  | 'knowledge.proposal.decide'
  | 'knowledge.proposal.reverse'
  | 'goal.create'
  | 'goal.card.create'
  | 'goal.card.edit'
  | 'goal.card.cancel'
  | 'goal.plan.propose'
  | 'goal.cancel'
  | 'goal.completion.accept'
  | 'goal.start'
  | 'goal.plan'
  | 'goal.plan.approve'
  | 'goal.plan.revise'
  | 'goal.intent.revise'
  | 'goal.pause'
  | 'goal.resume'
  | 'goal.step'
  | 'goal.review.decide'
  | 'goal.steering.send'
  | 'goal.steering.follow_up'
  | 'goal.steering.cancel'
  | 'worker.recovery.retry'
  | 'worker_environment.purge'
  | 'worker_environment.prepare'
  | 'administration.configuration.apply'
  | 'worker_environment.activate'
  | 'artifact.import'
  | 'artifact.introduce'
  | 'artifact.submit'
  | 'artifact.review.decide'
  | 'material.create'
  | 'material.save'
  | 'material.bind'
  | 'material.unbind'
  | 'material.exclude'
  | 'material.restore'
  | 'kernel.apps.create'
  | 'kernel.schema.update'
  | 'kernel.apps.retire'
  | 'kernel.records.create'
  | 'kernel.records.update'
  | 'kernel.records.batch'
  | 'generative-ui.publish';

/**
 * Resource kind returned by an idempotent command.
 */
export type CommandRequestResponseKind =
  | 'workspace'
  | 'workspace_invitation'
  | 'workspace_member'
  | 'workspace_recovery'
  | 'workspace_deletion'
  | 'user'
  | 'knowledge'
  | 'knowledge_source'
  | 'knowledge_observation'
  | 'knowledge_claim'
  | 'knowledge_conflict'
  | 'thread'
  | 'turn'
  | 'approval'
  | 'pending_request'
  | 'git_push_record'
  | 'artifact'
  | 'artifact_review'
  | 'workspace_sync_review'
  | 'knowledge_proposal'
  | 'knowledge_proposal_review'
  | 'goal'
  | 'goal_plan'
  | 'goal_review'
  | 'pending_user_turn'
  | 'steering_terminal_outcome'
  | 'material'
  | 'material_revision'
  | 'thread_material_binding'
  | 'light_app'
  | 'light_app_record'
  | 'light_app_batch'
  | 'generative_presentation'
  | 'worker_environment';

/**
 * Non-secret scope identifiers used to isolate idempotency keys.
 */
export type CommandRequestScope = Readonly<Record<string, string>>;

/** Bounded, non-authoritative metadata retained only by a `conversation.submit` receipt. */
export interface ConversationCommandReceiptMetadata {
  /** Opaque target accepted by the original command. */
  readonly targetRef: string;
  /** Product-visible logical model accepted by the original command. */
  readonly logicalModelId: string | null;
  /** Actual receiving Workspace and Thread selected by the branch. */
  readonly receivingWorkspaceId: string;
  readonly receivingThreadId: string;
  /** Optional downstream business owner created by a handoff. */
  readonly downstream:
    | { readonly kind: 'task'; readonly turnId: string }
    | { readonly kind: 'goal'; readonly goalId: string; readonly turnId: string }
    | null;
  /** Closed Chat outcome needed to locate its fixed durable owners. */
  readonly resultKind:
    | 'knowledge-answer'
    | 'provider-answer'
    | 'clarification'
    | 'task-handoff'
    | 'goal-handoff'
    | 'worker-turn'
    | 'goal-intent'
    | 'goal-steering'
    | 'refused';
  /** Original successful HTTP status for the closed outcome. */
  readonly status: 200 | 202;
}

/**
 * Resource pointer stored for replaying an idempotent command response.
 */
export interface CommandRequestResponse {
  /** Resource kind produced by the original command. */
  kind: CommandRequestResponseKind;
  /** Resource id produced by the original command. */
  id: string;
  /** Sole bounded extra receipt metadata allowed for `conversation.submit`; rejected for every other command. */
  conversationMetadata?: ConversationCommandReceiptMetadata;
}

/**
 * Persisted idempotency ledger record.
 */
export interface CommandRequestRecord {
  /** Stable ledger key derived from command, scope, and request id. */
  key: string;
  /** Command name that accepted the request. */
  command: CommandRequestName;
  /** Caller-supplied idempotency and correlation id. */
  requestId: string;
  /** Non-secret scope ids used for deduplication. */
  scope: CommandRequestScope;
  /** Hash of canonical command input. */
  inputHash: string;
  /** Resource pointer returned by the command. */
  response: CommandRequestResponse;
  /** Timestamp when the record was created. */
  createdAt: string;
  /** Timestamp when the record should be pruned. */
  expiresAt: string;
}

/**
 * Input used to create one idempotency ledger record.
 */
export interface CommandRequestRecordInput {
  /** Command name that accepted the request. */
  command: CommandRequestName;
  /** Caller-supplied idempotency and correlation id. */
  requestId: string;
  /** Non-secret scope ids used for deduplication. */
  scope: CommandRequestScope;
  /** Hash of canonical command input. */
  inputHash: string;
  /** Resource pointer returned by the command. */
  response: CommandRequestResponse;
  /** Optional creation timestamp for tests and migrations. */
  createdAt?: string;
  /** Optional expiry timestamp for tests and migrations. */
  expiresAt?: string;
}

/** Immutable create-only Knowledge Proposal stored before human review. */
export type KnowledgeProposalRecord = Omit<
  KnowledgeManagerDraftProposalResponse['proposal'],
  'status'
>;

/** Append-only human decision row for one Knowledge Proposal. */
export type KnowledgeProposalReviewRecord = KnowledgeProposalReview;

/** Input used to create one deterministic immutable Knowledge Proposal. */
export interface CreateKnowledgeProposalInput extends KnowledgeManagerDraftProposalRequest {
  /** Workspace that owns the proposal. */
  workspaceId: string;
  /** Exact external-owner references already verified by the calling authority. */
  verifiedExternalReferences: readonly string[];
  /** Authenticated producer assigned by the calling route. */
  producer: ActorRef;
  /** Canonical proposal creation timestamp. */
  createdAt: string;
}

/** Input used to append one human Knowledge Proposal decision. */
export interface RecordKnowledgeProposalReviewDecisionInput
  extends SubmitKnowledgeProposalDecisionRequest {
  /** Workspace that owns the proposal. */
  workspaceId: string;
  /** Immutable proposal receiving the decision. */
  proposalId: string;
  /** Exact external-owner references reverified by the calling authority. */
  verifiedExternalReferences: readonly string[];
  /** Authenticated human actor assigned by the calling route. */
  actor: ActorRef;
  /** Canonical decision timestamp. */
  decidedAt: string;
}

/** Input used to reverse one unchanged proposal-created Knowledge Page. */
export interface ReverseKnowledgeProposalApplicationInput {
  /** Workspace that owns the proposal and page. */
  workspaceId: string;
  /** Immutable proposal that authorized the page. */
  proposalId: string;
  /** Accepted review that authorized the page. */
  reviewId: string;
  /** Fixed Knowledge Page id owned by the proposal. */
  knowledgePageId: string;
  /** Expected digest of the exact current page bytes. */
  expectedContentDigest: string;
}

/** Knowledge source kind tracked by the first source registry slice. */
export type KnowledgeSourceKind = 'upload' | 'url' | 'document' | 'transcript' | 'code';

/**
 * Stored workspace source identity record.
 */
export interface KnowledgeSourceRecord {
  /** Stable source id. */
  id: string;
  /** Workspace that owns the source. */
  workspaceId: string;
  /** Source material category. */
  kind: KnowledgeSourceKind;
  /** Human-readable source title. */
  title: string;
  /** External or workspace URI when one exists. */
  uri: string | null;
  /** Stable digest for the captured source bytes or text. */
  contentDigest: string;
  /** Thread that originated the source capture, when applicable. */
  originatingThreadId: string | null;
  /** Turn that originated the source capture, when applicable. */
  originatingTurnId: string | null;
  /** File id from the originating turn input, when applicable. */
  originatingFileId: string | null;
  /** ISO timestamp when the source was captured. */
  capturedAt: string;
  /** ISO timestamp for creation. */
  createdAt: string;
  /** ISO timestamp for latest update. */
  updatedAt: string;
}

/**
 * Stored text material captured for one workspace knowledge source.
 */
export interface KnowledgeSourceMaterialRecord {
  /** Source id that owns the material. */
  sourceId: string;
  /** Captured source text content. */
  content: string;
}

/** Derived text representation metadata for one knowledge source. */
export interface KnowledgeSourceDerivedRepresentationRecord {
  /** Stable representation id. */
  id: string;
  /** Workspace that owns the representation. */
  workspaceId: string;
  /** Source id this representation derives from. */
  sourceId: string;
  /** First-slice derived representation kind. */
  kind: 'text';
  /** Metadata path relative to the workspace root. */
  path: string;
  /** Source material path relative to the workspace root. */
  materialPath: string;
  /** Digest of the derived representation content. */
  contentDigest: string;
  /** Digest of the source content version used to derive this record. */
  sourceContentDigest: string;
  /** ISO timestamp when the representation was created. */
  createdAt: string;
}

/** Input for appending one Knowledge Store conflict resolution row. */
export interface ResolveKnowledgeConflictInput {
  /** Workspace that owns the conflict. */
  workspaceId: string;
  /** Conflict id to resolve. */
  conflictId: string;
  /** Final resolution status. */
  status: Extract<KnowledgeConflictStatus, 'resolved' | 'superseded' | 'partially_superseded'>;
  /** Human-readable resolution summary. */
  resolution: string;
  /** Actor or agent resolving the conflict. */
  resolvedBy: string;
  /** ISO timestamp for the resolution append. */
  resolvedAt: string;
}

interface TurnStreamState {
  sequence: number;
  events: SseEventEnvelope[];
  listeners: Set<EventListener>;
  timers: Set<NodeJS.Timeout>;
}

/** Default admission-time capture pair when no authored switch is on. */
export const DEFAULT_CAPTURE_COVERAGE_BINDING: CaptureCoverageBinding = {
  scope: 'server',
  value: 'off',
};

interface CreateTurnOptions {
  /** Scheduler-owned turn id when external coordination already reserved lineage. */
  turnId?: string;
  /** Immutable explicit or composed effort captured when the Turn is admitted. */
  reasoningEffort?: Turn['reasoningEffort'];
  /** Command-owned start time when a Core-local Turn must share one accepted timestamp. */
  startedAt?: string;
  /** Admission-time capture pair when the caller already resolved the effective setting. */
  captureCoverage?: CaptureCoverageBinding;
  /** Initial status. Ordinary turns start running. Outcome turns may start pending. */
  status?: 'pending' | 'running';
  /** Agent bound at admission. */
  agentId?: string | null;
  /** AgentSession bound at admission. */
  agentSessionId?: string | null;
  /** Trigger recorded at admission. */
  triggerSource?: Turn['triggerSource'];
  /** Executor that this admission may freeze outcomes for. */
  executorKind?: 'worker' | 'assistant' | 'coordinator' | 'person';
}

/** Hooks invoked when a Turn is admitted or first becomes terminal. */
export interface TurnAdmissionHooks {
  /** Freezes matching ready outcomes into the admitted Turn. */
  onAdmitted?: (turn: Turn) => void;
  /** Commits the minimal Task result before canonical file publication. */
  onTerminalFact?: (turn: Turn) => void;
  /** Admits the next outcome Turn after a terminal barrier. */
  onTerminal?: (turn: Turn) => void;
}

/** Completes an already-decided publication against a sealed-terminal Turn. */
export const ALREADY_DECIDED_PUBLICATION_ADMISSION = {
  category: 'already-decided-publication',
} as const;

/** Item fields admitted by the named post-terminal display-projection refresh. */
export const DISPLAY_PROJECTION_REFRESH_FIELDS = ['level', 'title', 'summary'] as const;

/** Named field-limited display-projection refresh; this is not already-decided publication. */
export const DISPLAY_PROJECTION_REFRESH_ADMISSION = {
  category: 'display-projection-refresh',
} as const;

/**
 * Configuration-apply marker Item on the Turn that executes the apply.
 * Pending docs/specs/20260930-pending_requests.md; this category stays admitted.
 */
export const CONFIGURATION_APPLY_PENDING_DELAYED_USER_INPUT_ADMISSION = {
  category: 'configuration-apply-pending-delayed-user-input',
} as const;

/** Admission for completing an already-decided publication after terminal. */
export type AlreadyDecidedPublicationAdmission = typeof ALREADY_DECIDED_PUBLICATION_ADMISSION;

/** Admission for a named field-limited display-projection refresh after terminal. */
export type DisplayProjectionRefreshAdmission = typeof DISPLAY_PROJECTION_REFRESH_ADMISSION;

/** Admission for the configuration-apply marker pending delayed-user-input ownership. */
export type ConfigurationApplyPendingDelayedUserInputAdmission =
  typeof CONFIGURATION_APPLY_PENDING_DELAYED_USER_INPUT_ADMISSION;

/** Declared post-terminal write category; the two equality rules stay separate types. */
export type TerminalTurnWriteAdmission =
  | AlreadyDecidedPublicationAdmission
  | DisplayProjectionRefreshAdmission
  | ConfigurationApplyPendingDelayedUserInputAdmission;

/**
 * Returns whether already-recorded bytes equal a candidate publication.
 *
 * @param recorded Already-recorded value.
 * @param candidate Candidate publication.
 * @returns True when the values are deeply equal.
 */
function alreadyDecidedPublicationBytesEqual(recorded: unknown, candidate: unknown): boolean {
  return isDeepStrictEqual(recorded, candidate);
}

/**
 * Returns whether one Item's display fields match a named projection.
 *
 * @param item Recorded Item.
 * @param projection Candidate level, title, and summary.
 * @returns True when those three display fields already match.
 */
function displayProjectionFieldsEqual(
  item: Item,
  projection: { readonly level: unknown; readonly title: unknown; readonly summary: unknown }
): boolean {
  const recorded = item as unknown as Record<string, unknown>;
  return (
    recorded.level === projection.level &&
    recorded.title === projection.title &&
    recorded.summary === projection.summary
  );
}

/**
 * Returns whether a terminal completion stopReason matches a sealed Turn status.
 *
 * @param stopReason Event stopReason.
 * @param status Sealed Turn status.
 * @returns True when the pair is the already-decided terminal mapping.
 */
function stopReasonMatchesSealedStatus(stopReason: unknown, status: TurnStatus): boolean {
  if (status === 'completed') {
    return (
      stopReason === 'completed' || stopReason === 'length' || stopReason === 'budget_exhausted'
    );
  }
  if (status === 'failed') {
    return stopReason === 'error';
  }
  if (status === 'cancelled' || status === 'interrupted') {
    return stopReason === 'aborted';
  }
  return false;
}

/**
 * Returns whether an event payload is the sealed Turn's missing terminal publication.
 *
 * @param turn Sealed Turn.
 * @param event Candidate event input.
 * @returns True when the event publishes that Turn's sealed outcome, not merely names it.
 */
function eventAgreesWithSealedTurnOutcome(turn: Turn, event: TurnEventInput): boolean {
  const data = event.data as {
    type?: unknown;
    stopReason?: unknown;
    turn?: {
      id?: unknown;
      workspaceId?: unknown;
      threadId?: unknown;
      status?: unknown;
      error?: unknown;
    };
  };
  if (data.type !== 'turn-completed' && data.type !== 'turn-updated') {
    return false;
  }
  const carried = data.turn;
  if (!carried || typeof carried !== 'object') {
    return false;
  }
  if (
    carried.id !== turn.id ||
    carried.workspaceId !== turn.workspaceId ||
    carried.threadId !== turn.threadId ||
    carried.status !== turn.status
  ) {
    return false;
  }
  if (
    carried.error !== undefined &&
    !alreadyDecidedPublicationBytesEqual(carried.error ?? null, turn.error ?? null)
  ) {
    return false;
  }
  if (
    data.stopReason !== undefined &&
    !stopReasonMatchesSealedStatus(data.stopReason, turn.status)
  ) {
    return false;
  }
  return true;
}

/**
 * Returns whether an event payload names this Turn but disagrees with its decided outcome.
 *
 * @param turn Sealed Turn.
 * @param event Candidate event input.
 * @returns True when the event identifies this Turn and contradicts its sealed status, error, or stopReason.
 */
function eventConflictsWithSealedTurnOutcome(turn: Turn, event: TurnEventInput): boolean {
  const data = event.data as {
    stopReason?: unknown;
    turn?: { id?: unknown; status?: unknown; error?: unknown };
  };
  const carried = data.turn;
  if (!carried || typeof carried !== 'object' || carried.id !== turn.id) {
    return false;
  }
  if (carried.status !== undefined && carried.status !== turn.status) {
    return true;
  }
  if (
    carried.error !== undefined &&
    !alreadyDecidedPublicationBytesEqual(carried.error ?? null, turn.error ?? null)
  ) {
    return true;
  }
  if (
    data.stopReason !== undefined &&
    !stopReasonMatchesSealedStatus(data.stopReason, turn.status)
  ) {
    return true;
  }
  return false;
}

/**
 * Returns whether a parsed Turn rewrite would change already-set decided fields.
 *
 * @param current Recorded terminal Turn.
 * @param next Candidate merged Turn.
 * @returns True when an already-set decided field would change.
 */
function decidedTurnFieldsConflict(current: Turn, next: Turn): boolean {
  if (next.status !== current.status) {
    return true;
  }
  const keys = [
    'error',
    'completedAt',
    'agentId',
    'agentProfileId',
    'agentSessionId',
    'triggerSource',
    'configVersion',
  ] as const;
  for (const key of keys) {
    const recorded = current[key];
    if (
      recorded !== undefined &&
      recorded !== null &&
      !alreadyDecidedPublicationBytesEqual(recorded, next[key])
    ) {
      return true;
    }
  }
  return false;
}

/**
 * Creates the rejection for a new write against a sealed-terminal Turn.
 *
 * @param turnId Terminal Turn id.
 * @returns Error for a write that is not an admitted post-terminal publication.
 */
function terminalTurnWriteRejected(turnId: string): Error {
  return new Error(`Turn ${turnId} is terminal and does not admit this write.`);
}

/**
 * Creates the rejection for a conflicting publication against a sealed-terminal Turn.
 *
 * @param turnId Terminal Turn id.
 * @returns Error for a publication that disagrees with already-decided bytes.
 */
function terminalTurnPublicationConflict(turnId: string): Error {
  return new Error(
    `Turn ${turnId} is terminal and the publication conflicts with the already-decided record.`
  );
}

/** Accepted store input for one workspace-only Artifact introduction. */
export interface IntroduceArtifactInput {
  /** Workspace that owns the Artifact and Thread. */
  readonly workspaceId: string;
  /** Idle Thread that will receive the Core-local Turn. */
  readonly threadId: string;
  /** Workspace-only imported Artifact to communicate. */
  readonly artifactId: string;
  /** Exact Artifact version accepted by the caller. */
  readonly expectedArtifactVersion: number;
  /** Command identity copied into the reference proof. */
  readonly requestId: string;
  /** Accepted command timestamp. */
  readonly acceptedAt: string;
  /** Deterministic Core-local Turn id reserved by the command owner. */
  readonly turnId: string;
  /** Exact authenticated actor whose command created the introduction Turn. */
  readonly triggerActor: ActorRef;
}

/** Native absence of an addressed record, distinct from unexpected storage or implementation failure. */
export class StoreRecordNotFoundError extends Error {}

/** Closed S16 failures owned by the Artifact authority boundary. */
export type ArtifactAuthorityErrorCode =
  | 'invalid_request'
  | 'source_digest_mismatch'
  | 'recovery_required'
  | 'stale'
  | 'conflict'
  | 'thread_busy';

/** Structured failure raised by Artifact creation and introduction. */
export class ArtifactAuthorityError extends Error {
  /** Stable S16 error code. */
  public readonly code: ArtifactAuthorityErrorCode;
  /** Exact HTTP status assigned by S16. */
  public readonly status: 400 | 409;

  /**
   * Creates one Artifact authority failure.
   *
   * @param code Stable S16 error code.
   * @param message Product-safe diagnostic.
   */
  public constructor(code: ArtifactAuthorityErrorCode, message: string) {
    super(message);
    this.name = 'ArtifactAuthorityError';
    this.code = code;
    this.status = ['invalid_request', 'source_digest_mismatch'].includes(code) ? 400 : 409;
  }
}

/**
 * Optional store configuration.
 */
export interface FsStoreOptions {
  /** Optional data root for durable file-backed storage. */
  dataRoot?: string;
}

function now(): string {
  return new Date().toISOString();
}

/** Closed product-safe failure codes raised by Knowledge Proposal authority. */
export type KnowledgeProposalAuthorityErrorCode =
  | 'invalid_request'
  | 'not_found'
  | 'conflict'
  | 'recovery_required';

/**
 * Creates one bounded Knowledge Proposal authority failure.
 *
 * @param code Stable public failure code.
 * @returns Error carrying the corresponding HTTP status.
 */
/** Native Knowledge Proposal refusal; only its owning family projects it. */
export class KnowledgeProposalAuthorityError extends Error {
  readonly status: 400 | 404 | 409;
  constructor(readonly code: KnowledgeProposalAuthorityErrorCode) {
    super('Knowledge Proposal authority check failed.');
    this.status = code === 'invalid_request' ? 400 : code === 'not_found' ? 404 : 409;
  }
}

export function knowledgeProposalAuthorityError(
  code: KnowledgeProposalAuthorityErrorCode
): Error & { code: KnowledgeProposalAuthorityErrorCode; status: 400 | 404 | 409 } {
  return new KnowledgeProposalAuthorityError(code);
}

/**
 * Computes one lowercase SHA-256 content digest over exact UTF-8 bytes.
 *
 * @param content Exact content bytes represented as a UTF-8 string.
 * @returns Prefixed content digest.
 */
function contentDigest(content: string): string {
  return `sha256:${createHash('sha256').update(content, 'utf8').digest('hex')}`;
}

/**
 * Derives one Knowledge-owned Proposal id from its canonical tuple; entity Review ids use Protocol.
 *
 * @param prefix Closed owner-family prefix.
 * @param tuple Canonical tuple with fields already in required order.
 * @returns Stable owner id.
 */
export function knowledgeAuthorityId(
  prefix: 'kp_',
  tuple: Readonly<Record<string, string>>
): string {
  return `${prefix}${createHash('sha256').update(JSON.stringify(tuple), 'utf8').digest('hex')}`;
}

/**
 * Projects App command request ids onto protocol event envelope identity.
 *
 * Canonical UUIDs pass through. Null remains null. Blank strings stay invalid so the envelope schema still rejects them. Other nonempty ids become a Workspace/Thread-scoped UUID from the shared RFC 4122 helper.
 *
 * @param requestId App command id, protocol UUID, blank, or null.
 * @param workspaceId Workspace carried by the event.
 * @param threadId Optional Thread carried by the event.
 * @returns Protocol envelope requestId before schema parse.
 */
export function projectTurnEventRequestId(
  requestId: string | null | undefined,
  workspaceId: string,
  threadId: string | undefined
): string | null {
  if (requestId == null) {
    return null;
  }

  const canonical = RequestIdSchema.safeParse(requestId);
  if (canonical.success) {
    return canonical.data;
  }
  if (requestId.trim() === '') {
    return requestId;
  }

  return uuidv5(
    `openkit:protocol.turn-event.request:${JSON.stringify([workspaceId, threadId ?? '', requestId])}`
  );
}

/**
 * Builds a stable string key for one command idempotency scope.
 *
 * @param scope Non-secret command scope ids.
 * @returns Stable scope key.
 */
function commandRequestScopeKey(scope: CommandRequestScope): string {
  return Object.entries(scope)
    .sort(([left], [right]) => left.localeCompare(right))
    .map(([key, value]) => `${key}=${value}`)
    .join('&');
}

/**
 * Builds the internal map key for one command idempotency record.
 *
 * @param command Stable command name.
 * @param requestId Caller-provided idempotency id.
 * @param scope Non-secret command scope ids.
 * @returns Internal command request key.
 */
export function commandRequestKey(
  command: CommandRequestName,
  requestId: string,
  scope: CommandRequestScope
): string {
  return `${command}|${requestId}|${commandRequestScopeKey(scope)}`;
}

/**
 * Computes the default expiry timestamp for an idempotency record.
 *
 * @param createdAt Record creation timestamp.
 * @returns Expiry timestamp after the retention window.
 */
function commandRequestExpiresAt(createdAt: string): string {
  return new Date(new Date(createdAt).getTime() + COMMAND_REQUEST_RETENTION_MS).toISOString();
}

/**
 * Checks whether one idempotency record has expired.
 *
 * @param record Ledger record to inspect.
 * @param referenceTime Timestamp used as the current time.
 * @returns True when the record is expired.
 */
function isCommandRequestExpired(record: CommandRequestRecord, referenceTime: string): boolean {
  return new Date(record.expiresAt).getTime() <= new Date(referenceTime).getTime();
}

/** Derives the built-in private Workspace from the recorded canonical User owner. */
export function quickChatWorkspaceIdForUser(userId: string): string {
  return deriveEntityId('ws', ['quick_chat', userId]);
}

/**
 * Builds a product-safe sandbox summary from app-local workspace roots.
 *
 * @param roots Workspace roots captured for a session.
 * @returns Stable sandbox summary without host paths.
 */
function sandboxSummaryForWorkspaceRoots(
  roots: MaterializedWorkspaceRoot[]
): ProtocolAgentSession['sandboxSummary'] {
  if (roots.length === 0) {
    return null;
  }

  return {
    access: roots.some((root) => root.access === 'read-write') ? 'read-write' : 'read-only',
    workspaceRootRefs: roots.map((root) => root.id),
    summary: `${roots.length} workspace root${roots.length === 1 ? '' : 's'} materialized.`,
  };
}

/**
 * Returns empty dynamic resources for a workspace.
 *
 * @param knowledge Seed knowledge entries.
 * @returns Workspace resources without a second agent or model catalog.
 */
function createWorkspaceResources(knowledge: KnowledgeEntry[] = []): WorkspaceResources {
  return {
    knowledge,
    skills: [],
    agents: [],
    models: [],
  };
}

/** Builds the canonical empty history used when publishing a new Workspace. */
function emptyWorkspaceFileRecords(workspace: WorkspaceRecord): WorkspaceFileRecords {
  return {
    workspace,
    knowledge: [],
    threads: [],
    turns: [],
    itemRevisions: [],
    artifacts: [],
    knowledgeProposals: [],
    knowledgeProposalReviews: [],
    knowledgeSources: [],
    agentSessions: [],
    streamEvents: [],
  };
}

/**
 * File-backed protocol store used by NanoCore.
 */
export class FsStore {
  private workspaces = new Map<string, WorkspaceRecord>();
  private workspaceResources = new Map<string, WorkspaceResources>();
  private workspaceAgentCatalogProjection: (() => RuntimeAgent[]) | null = null;
  private threads = new Map<string, Thread>();
  private turns = new Map<string, Turn>();
  private items = new Map<string, Item>();
  private itemRevisions: Item[] = [];
  private approvals = new Map<string, ApprovalRequest>();
  private agentSessions = new Map<string, AgentSession>();
  private artifacts = new Map<string, Artifact>();
  private knowledgeProposals = new Map<string, KnowledgeProposalRecord>();
  private knowledgeProposalReviews = new Map<string, KnowledgeProposalReviewRecord[]>();
  private knowledgeSources = new Map<string, KnowledgeSourceRecord>();
  private commandRequests = new Map<string, CommandRequestRecord>();
  private streams = new Map<string, TurnStreamState>();
  private liveCaptureCoverage: CaptureCoverageBinding = DEFAULT_CAPTURE_COVERAGE_BINDING;
  private turnCaptureCoverage = new Map<string, CaptureCoverageBinding>();
  private turnExecutors = new Map<string, 'worker' | 'assistant' | 'coordinator' | 'person'>();
  private turnAdmissionHooks: TurnAdmissionHooks | null = null;
  private terminalHookDepth = 0;
  private readonly dataRoot: string | null;

  public constructor(options: FsStoreOptions = {}) {
    this.dataRoot =
      options.dataRoot ?? (process.env.OPENKIT_DATA_ROOT ? resolveDataRoot(process.env) : null);

    if (this.dataRoot) {
      this.liveCaptureCoverage = captureCoverageBindingFromOpenKitConfig(
        loadOpenKitConfig(this.dataRoot)
      );
      const workspaceRecords = loadWorkspaceFileRecords(this.dataRoot);

      if (workspaceRecords.length > 0) {
        if (this.restoreWorkspaceFileRecords(workspaceRecords)) {
          for (const workspaceId of this.workspaces.keys()) {
            this.persist(workspaceId);
          }
        }
        return;
      }
    }
  }

  /**
   * Restores in-memory indexes from canonical workspace file records.
   *
   * @param workspaceRecords Canonical records loaded for every published workspace.
   * @returns True when an interrupted approval projection was repaired.
   */
  private restoreWorkspaceFileRecords(workspaceRecords: readonly WorkspaceFileRecords[]): boolean {
    for (const records of workspaceRecords) {
      this.workspaces.set(records.workspace.id, records.workspace);
      this.workspaceResources.set(
        records.workspace.id,
        records.workspace.kind === 'quick-chat'
          ? { knowledge: [...records.knowledge], skills: [], agents: [], models: [] }
          : createWorkspaceResources([...records.knowledge])
      );
      for (const thread of records.threads) {
        this.threads.set(thread.id, thread);
      }
      for (const turn of records.turns) {
        for (const item of turn.items) {
          if (
            item.type === 'user-input-request' &&
            item.responsibleUserId !== responsibleUserIdForActor(turn.triggerActor)
          ) {
            throw new Error(`User-input request has invalid responsible user: ${item.id}`);
          }
          if (item.type === 'user-input-response') {
            const request = turn.items.find(
              (candidate) =>
                candidate.type === 'user-input-request' &&
                candidate.userInputRequestId === item.userInputRequestId
            );
            if (
              request?.type === 'user-input-request' &&
              request.responsibleUserId !== item.actor.id
            ) {
              throw new Error(`User-input response has invalid responsible user: ${item.id}`);
            }
          }
        }
        this.turns.set(turn.id, turn);
        for (const item of turn.items) {
          this.items.set(item.id, item);
        }
      }
      if (records.turnCaptureCoverage) {
        for (const [turnId, binding] of records.turnCaptureCoverage) {
          this.turnCaptureCoverage.set(turnId, binding);
        }
      }
      this.itemRevisions.push(...records.itemRevisions);
      for (const session of records.agentSessions) {
        this.agentSessions.set(session.id, session);
      }
      for (const artifact of records.artifacts) {
        this.artifacts.set(artifact.id, artifact);
      }
      for (const proposal of records.knowledgeProposals) {
        this.knowledgeProposals.set(proposal.id, proposal);
      }
      for (const review of records.knowledgeProposalReviews) {
        this.knowledgeProposalReviews.set(review.proposalId, [
          ...(this.knowledgeProposalReviews.get(review.proposalId) ?? []),
          review,
        ]);
      }
      for (const source of records.knowledgeSources) {
        this.knowledgeSources.set(source.id, source);
      }
      for (const [turnId, events] of records.streamEvents) {
        this.streams.set(turnId, {
          sequence: events.at(-1)?.sequence ?? 0,
          events: [...events],
          listeners: new Set(),
          timers: new Set(),
        });
      }
    }

    if (this.dataRoot) {
      for (const approval of loadApprovalProjections(
        this.dataRoot,
        [...this.turns.values()],
        [...this.commandRequests.values()]
      )) {
        this.approvals.set(approval.id, approval);
      }
    }
    return false;
  }

  /**
   * Removes expired idempotency ledger records.
   *
   * @returns True when at least one record was removed.
   */
  private pruneExpiredCommandRequests(): boolean {
    const referenceTime = now();
    let changed = false;

    for (const [key, record] of this.commandRequests.entries()) {
      if (isCommandRequestExpired(record, referenceTime)) {
        this.commandRequests.delete(key);
        changed = true;
      }
    }

    return changed;
  }

  /**
   * Returns active idempotency records for tests and diagnostics.
   *
   * @returns Non-expired idempotency records.
   */
  public listCommandRequests(): CommandRequestRecord[] {
    if (this.dataRoot) {
      return listCommandRequestRecords(this.dataRoot, now());
    }

    this.pruneExpiredCommandRequests();

    return [...this.commandRequests.values()];
  }

  /**
   * Looks up one non-expired idempotency record.
   *
   * @param command Stable command name.
   * @param requestId Caller-supplied idempotency id.
   * @param scope Non-secret command scope ids.
   * @param commandDb Optional open Core or Workspace database for transaction-local reads.
   * @returns Matching command request record, or null.
   */
  public getCommandRequest(
    command: CommandRequestName,
    requestId: string,
    scope: CommandRequestScope,
    commandDb?: CoreDb | WorkspaceDb | AppDb
  ): CommandRequestRecord | null {
    const key = commandRequestKey(command, requestId, scope);

    if (commandDb) {
      return getCommandRequestRecordFromDb(commandDb, key, now());
    }

    if (this.dataRoot) {
      return getCommandRequestRecord(this.dataRoot, scope, key, now());
    }

    this.pruneExpiredCommandRequests();

    return this.commandRequests.get(key) ?? null;
  }

  /**
   * Records the resource pointer for a completed idempotent command.
   *
   * @param input Idempotency record input.
   * @param commandDb Optional open Core or Workspace database for transaction-local writes.
   * @returns Persisted idempotency record.
   */
  public recordCommandRequest(
    input: CommandRequestRecordInput,
    commandDb?: CoreDb | WorkspaceDb | AppDb
  ): CommandRequestRecord {
    const createdAt = input.createdAt ?? now();
    const record: CommandRequestRecord = {
      key: commandRequestKey(input.command, input.requestId, input.scope),
      command: input.command,
      requestId: input.requestId,
      scope: input.scope,
      inputHash: input.inputHash,
      response: normalizeCommandRequestResponse(input.command, input.response),
      createdAt,
      expiresAt: input.expiresAt ?? commandRequestExpiresAt(createdAt),
    };

    if (commandDb) {
      recordCommandRequestRecordInDb(commandDb, record);
    } else if (this.dataRoot) {
      recordCommandRequestRecord(this.dataRoot, record);
    } else {
      this.commandRequests.set(record.key, record);
    }

    return record;
  }

  /**
   * Projects one workspace's in-memory state into its canonical file records.
   *
   * @param workspaceId Workspace to persist.
   * @param updateWorkspaceConfigName Whether Core may refresh its owned config name.
   * @param exactKnowledgePageBytes Final validated direct-edit bytes keyed by Page id.
   */
  private persist(
    workspaceId: string,
    updateWorkspaceConfigName = false,
    exactKnowledgePageBytes: ReadonlyMap<string, string> = new Map()
  ): void {
    if (!this.dataRoot) {
      return;
    }

    const workspaceRoot = ensureWorkspaceLayout(this.dataRoot, workspaceId).root;
    this.writeWorkspaceFileRecordsToRoot(
      workspaceId,
      workspaceRoot,
      updateWorkspaceConfigName,
      exactKnowledgePageBytes
    );
  }

  /**
   * Publishes one new workspace with its migrated database through a same-filesystem staging root.
   *
   * @param records Complete canonical records to publish.
   * @param stageWorkspace Optional side-effect writer that runs under the staging root.
   */
  private persistNewWorkspaceAtomically(
    records: WorkspaceFileRecords,
    stageWorkspace?: (stage: ImportWorkspaceStage) => void
  ): void {
    if (!this.dataRoot) {
      return;
    }

    ensureLayoutDirectories(this.dataRoot);

    const workspaceId = records.workspace.id;
    const finalRoot = this.workspaceRootPath(workspaceId);
    const stagingRoot = join(
      dirname(finalRoot),
      '.staging',
      `${workspaceId}-${process.pid}-${Date.now()}`
    );
    const stagingParent = dirname(stagingRoot);

    if (existsSync(finalRoot)) {
      throw new Error(`Workspace path already exists: ${workspaceId}`);
    }

    mkdirSync(stagingParent, { recursive: true });
    assertCanonicalDirectory(stagingParent);

    try {
      rmSync(stagingRoot, { recursive: true, force: true });
      const workspaceDb = openWorkspaceDbAtRoot({
        dataRoot: this.dataRoot,
        workspaceId,
        workspaceRoot: stagingRoot,
      });
      try {
        applyScopedMigrations(workspaceDb);
      } finally {
        // Publish a complete main database rather than depending on an open handle or WAL sidecar.
        workspaceDb.sqlite.close();
      }
      stageWorkspace?.({ workspaceId, workspaceRoot: stagingRoot });
      writeWorkspaceFileRecords(stagingRoot, records);
      publishCanonicalPath(stagingRoot, finalRoot);
    } catch (error) {
      rmSync(stagingRoot, { recursive: true, force: true });
      throw error;
    }
  }

  /**
   * Projects current in-memory state into one canonical workspace root.
   *
   * @param workspaceId Workspace to write.
   * @param workspaceRoot Resolved workspace root.
   * @param updateWorkspaceConfigName Whether Core may refresh its owned config name.
   * @param exactKnowledgePageBytes Final validated direct-edit bytes keyed by Page id.
   */
  private writeWorkspaceFileRecordsToRoot(
    workspaceId: string,
    workspaceRoot: string,
    updateWorkspaceConfigName = false,
    exactKnowledgePageBytes: ReadonlyMap<string, string> = new Map()
  ): void {
    const workspace = this.getWorkspace(workspaceId);
    const turnIds = new Set(
      [...this.turns.values()]
        .filter((turn) => turn.workspaceId === workspaceId)
        .map((turn) => turn.id)
    );

    writeWorkspaceFileRecords(
      workspaceRoot,
      {
        workspace,
        knowledge: this.getWorkspaceResources(workspaceId).knowledge,
        threads: this.listThreads(workspaceId),
        turns: [...this.turns.values()].filter((turn) => turn.workspaceId === workspaceId),
        itemRevisions: this.itemRevisions.filter((item) => item.workspaceId === workspaceId),
        artifacts: this.listArtifacts(workspaceId),
        knowledgeProposals: [...this.knowledgeProposals.values()].filter(
          (proposal) => proposal.workspaceId === workspaceId
        ),
        knowledgeProposalReviews: [...this.knowledgeProposalReviews.values()]
          .flat()
          .filter((review) => review.workspaceId === workspaceId),
        knowledgeSources: [...this.knowledgeSources.values()].filter(
          (source) => source.workspaceId === workspaceId
        ),
        agentSessions: [...this.agentSessions.values()].filter(
          (session) => session.workspaceId === workspaceId
        ),
        streamEvents: [...this.streams.entries()]
          .filter(([turnId]) => turnIds.has(turnId))
          .map(([turnId, stream]) => [turnId, stream.events]),
        turnCaptureCoverage: new Map(
          [...this.turnCaptureCoverage.entries()].filter(([turnId]) => turnIds.has(turnId))
        ),
      },
      updateWorkspaceConfigName,
      exactKnowledgePageBytes
    );
  }

  /**
   * Returns one owner-independent Workspace root path under the configured data-root layout.
   *
   * @param workspaceId Workspace whose root path should be returned.
   * @returns Workspace root path.
   */
  private workspaceRootPath(workspaceId: string): string {
    if (!this.dataRoot) {
      throw new Error('FsStore data root is not configured.');
    }

    assertSafeWorkspacePathSegment(workspaceId, 'Workspace id');
    return resolveDataRootPath(this.dataRoot, 'workspaces', workspaceId);
  }

  /**
   * Validates exact direct-write Knowledge Page bytes before store mutation.
   *
   * @param workspaceId Workspace that owns the candidate page.
   * @param candidate Candidate entry about to be written.
   * @param knowledge Knowledge entries that will exist after the write.
   * @param candidateContent Exact final page bytes to validate.
   * @throws KnowledgePageValidationError when the candidate or current schema is invalid.
   */
  private assertValidKnowledgeEntryCandidate(
    workspaceId: string,
    candidate: KnowledgeEntry,
    knowledge: readonly KnowledgeEntry[],
    candidateContent = serializeUserAuthoredKnowledgePage(candidate)
  ): void {
    let workspaceSchemaText: string | undefined;
    let resolvedReferences: ReadonlySet<string> = new Set();

    try {
      if (this.dataRoot) {
        const schemaPath = join(
          this.workspaceRootPath(workspaceId),
          'knowledge',
          'schema',
          'workspace-schema.yaml'
        );

        if (existsSync(schemaPath)) {
          workspaceSchemaText = readCanonicalTextFile(schemaPath);
        }
      }
      const qualifiedLocalReferences = (candidate.sourceReferences ?? []).filter((reference) =>
        /^(?:source|knowledge):.+@sha256:[a-f0-9]{64}$/.test(reference)
      );
      if (qualifiedLocalReferences.length > 0) {
        resolvedReferences = this.resolveKnowledgePageSourceReferences(
          workspaceId,
          qualifiedLocalReferences,
          []
        );
      }
    } catch {
      throw new KnowledgePageValidationError();
    }

    const report = validateKnowledgePageCandidate({
      path: `knowledge/pages/${candidate.id}.md`,
      content: candidateContent,
      ...(workspaceSchemaText === undefined ? {} : { workspaceSchemaText }),
      registeredSources: new Map(
        [...this.knowledgeSources.values()]
          .filter((source) => source.workspaceId === workspaceId)
          .map((source) => [source.id, source.contentDigest])
      ),
      knowledgeIds: new Set(knowledge.map((entry) => entry.id)),
      resolvedReferences,
    });

    if (report.conformance !== 'Workspace-schema-valid' || report.errors.length > 0) {
      throw new KnowledgePageValidationError();
    }
  }

  /**
   * Validates one immutable proposal tuple and its exact current evidence.
   *
   * @param proposal Proposal owner to verify.
   * @param verifiedExternalReferences Exact Core/S39 references verified by their owners.
   * @returns Candidate Knowledge entry projected from the fixed page bytes.
   * @throws KnowledgePageValidationError when any candidate or source authority is invalid.
   */
  private assertValidKnowledgeProposal(
    proposal: KnowledgeProposalRecord,
    verifiedExternalReferences: readonly string[]
  ): KnowledgeEntry {
    let workspaceSchemaText: string | undefined;
    try {
      KnowledgeProposalRecordSchema.parse(proposal);
      if (this.dataRoot) {
        const schemaPath = join(
          this.workspaceRootPath(proposal.workspaceId),
          'knowledge',
          'schema',
          'workspace-schema.yaml'
        );
        if (existsSync(schemaPath)) {
          workspaceSchemaText = readCanonicalTextFile(schemaPath);
        }
      }
    } catch {
      throw new KnowledgePageValidationError();
    }

    const candidatePath = `knowledge/pages/${proposal.knowledgePageId}.md`;
    const parsed = parseOkfDocument({ path: candidatePath, content: proposal.canonicalPageBytes });
    const sourceReferences = parsed.document
      ? stringListFrontmatterField(parsed.document, 'source_refs')
      : null;
    if (
      proposal.contentDigest !== contentDigest(proposal.canonicalPageBytes) ||
      !parsed.ok ||
      parsed.document.conceptId !== proposal.knowledgePageId ||
      parsed.document.frontmatter.type !== 'KnowledgePage' ||
      parsed.document.frontmatter.openkit_status !== 'active' ||
      (parsed.document.frontmatter.status !== undefined &&
        parsed.document.frontmatter.status !== 'stable') ||
      parsed.document.frontmatter.review_state !== 'accepted' ||
      JSON.stringify(sourceReferences) !== JSON.stringify(proposal.sourceReferences)
    ) {
      throw new KnowledgePageValidationError();
    }

    const knowledge = this.getWorkspaceResources(proposal.workspaceId).knowledge;
    const resolvedReferences = this.resolveKnowledgePageSourceReferences(
      proposal.workspaceId,
      proposal.sourceReferences,
      verifiedExternalReferences
    );

    const report = validateKnowledgePageCandidate({
      path: candidatePath,
      content: proposal.canonicalPageBytes,
      ...(workspaceSchemaText === undefined ? {} : { workspaceSchemaText }),
      registeredSources: new Map(
        [...this.knowledgeSources.values()]
          .filter((source) => source.workspaceId === proposal.workspaceId)
          .map((source) => [source.id, source.contentDigest])
      ),
      knowledgeIds: new Set(knowledge.map((entry) => entry.id)),
      resolvedReferences,
    });
    if (report.conformance !== 'Workspace-schema-valid' || report.errors.length > 0) {
      throw new KnowledgePageValidationError();
    }

    try {
      return parseOwnedKnowledgeEntry(
        candidatePath,
        proposal.knowledgePageId,
        proposal.canonicalPageBytes
      );
    } catch {
      throw new KnowledgePageValidationError();
    }
  }

  /**
   * Resolves one closed Knowledge Page source-reference set against current owners.
   *
   * @param workspaceId Workspace that must own every local reference.
   * @param sourceReferences Complete source references carried by the page.
   * @param verifiedExternalReferences Exact work-history references verified outside the store.
   * @returns Complete reference set after every current owner is verified.
   * @throws KnowledgePageValidationError when any reference is missing or contradictory.
   */
  private resolveKnowledgePageSourceReferences(
    workspaceId: string,
    sourceReferences: readonly string[],
    verifiedExternalReferences: readonly string[]
  ): ReadonlySet<string> {
    const externalReferences = new Set(verifiedExternalReferences);
    if (
      externalReferences.size !== verifiedExternalReferences.length ||
      verifiedExternalReferences.some(
        (reference) =>
          !/^(?:turn|item|context-package):/.test(reference) ||
          !sourceReferences.includes(reference)
      )
    ) {
      throw new KnowledgePageValidationError();
    }

    const knowledge = this.getWorkspaceResources(workspaceId).knowledge;
    const resolvedReferences = new Set(externalReferences);
    for (const reference of sourceReferences) {
      const qualifiedReference = /^(source|knowledge):(.+)@(sha256:[a-f0-9]{64})$/.exec(reference);
      if (!qualifiedReference) {
        if (!externalReferences.has(reference)) {
          throw new KnowledgePageValidationError();
        }
        continue;
      }
      const [, family, ownerId, expectedDigest] = qualifiedReference;
      if (family === 'source') {
        const source = this.knowledgeSources.get(ownerId!);
        if (
          !source ||
          source.workspaceId !== workspaceId ||
          source.contentDigest !== expectedDigest
        ) {
          throw new KnowledgePageValidationError();
        }
        let sourceMaterial: string | null;
        try {
          sourceMaterial = this.readKnowledgeSourceMaterial(workspaceId, ownerId!);
        } catch {
          throw new KnowledgePageValidationError();
        }
        if (sourceMaterial === null || contentDigest(sourceMaterial) !== expectedDigest) {
          throw new KnowledgePageValidationError();
        }
        resolvedReferences.add(reference);
        continue;
      }

      let pageBytes: string | null;
      try {
        pageBytes = this.dataRoot
          ? readWorkspaceKnowledgePage(this.workspaceRootPath(workspaceId), ownerId!)
          : (() => {
              const entry = knowledge.find((candidate) => candidate.id === ownerId);
              return entry ? serializeUserAuthoredKnowledgePage(entry) : null;
            })();
      } catch {
        throw new KnowledgePageValidationError();
      }
      if (!pageBytes || contentDigest(pageBytes) !== expectedDigest) {
        throw new KnowledgePageValidationError();
      }
      const parsed = parseOkfDocument({
        path: `knowledge/pages/${ownerId}.md`,
        content: pageBytes,
      });
      if (
        !parsed.ok ||
        parsed.document.conceptId !== ownerId ||
        parsed.document.frontmatter.openkit_entry_id !== ownerId ||
        parsed.document.frontmatter.type !== 'KnowledgePage' ||
        parsed.document.frontmatter.openkit_status !== 'active' ||
        (parsed.document.frontmatter.status !== undefined &&
          parsed.document.frontmatter.status !== 'stable') ||
        parsed.document.frontmatter.review_state !== 'user-authored'
      ) {
        throw new KnowledgePageValidationError();
      }
      resolvedReferences.add(reference);
    }

    return resolvedReferences;
  }

  /**
   * Rejects publication while one latest unresolved conflict names the proposal target or source.
   *
   * @param proposal Immutable proposal whose publication boundary is being checked.
   * @throws Knowledge Proposal conflict failure before any Review or Page mutation.
   */
  private assertNoUnresolvedKnowledgeProposalConflict(proposal: KnowledgeProposalRecord): void {
    const relevantReferences = new Set<string>([
      `knowledge:${proposal.knowledgePageId}`,
      ...proposal.sourceReferences,
    ]);
    for (const reference of proposal.sourceReferences) {
      const qualifiedReference = /^(source|knowledge):(.+)@sha256:[a-f0-9]{64}$/.exec(reference);
      if (qualifiedReference) {
        relevantReferences.add(`${qualifiedReference[1]}:${qualifiedReference[2]}`);
      }
    }

    if (
      this.listKnowledgeConflicts(proposal.workspaceId).some(
        (conflict) =>
          UNRESOLVED_KNOWLEDGE_CONFLICT_STATUSES.has(conflict.status) &&
          conflict.subjectReferences.some((reference) => relevantReferences.has(reference))
      )
    ) {
      throw knowledgeProposalAuthorityError('conflict');
    }
  }

  /**
   * Reports whether another accepted proposal reserves one generated Page identity.
   *
   * @param workspaceId Workspace that owns the Page identity.
   * @param knowledgePageId Generated Page identity being proposed or accepted.
   * @param excludedProposalId Current proposal to ignore while checking its own replay.
   * @returns True when an accepted Review reserves the identity against another proposal.
   */
  private hasAcceptedKnowledgeProposalForPage(
    workspaceId: string,
    knowledgePageId: string,
    excludedProposalId?: string
  ): boolean {
    return [...this.knowledgeProposals.values()].some(
      (candidate) =>
        candidate.id !== excludedProposalId &&
        candidate.workspaceId === workspaceId &&
        candidate.knowledgePageId === knowledgePageId &&
        (this.knowledgeProposalReviews.get(candidate.id) ?? []).some(
          (review) => review.decision === 'accepted'
        )
    );
  }

  /**
   * Re-reads one proposal file and verifies its exact immutable bytes.
   *
   * @param proposal Proposal owner held in memory.
   * @returns Exact verified proposal-file bytes.
   * @throws Error with recovery_required when durable authority is missing or changed.
   */
  private verifiedKnowledgeProposalBytes(proposal: KnowledgeProposalRecord): string {
    const expected = serializeKnowledgeProposalRecord(proposal);
    if (!this.dataRoot) {
      return expected;
    }

    try {
      const path = join(
        this.workspaceRootPath(proposal.workspaceId),
        'knowledge',
        'proposals',
        `${proposal.id}.md`
      );
      const actual = readCanonicalTextFile(path);
      if (actual !== expected) {
        throw knowledgeProposalAuthorityError('recovery_required');
      }
      return actual;
    } catch (error) {
      if (
        typeof error === 'object' &&
        error !== null &&
        'code' in error &&
        error.code === 'recovery_required'
      ) {
        throw error;
      }
      throw knowledgeProposalAuthorityError('recovery_required');
    }
  }

  /**
   * Re-reads one retained Review file and verifies its ordered decision core and Proposal digest.
   *
   * @param proposal Immutable Proposal that owns the Review history.
   * @param reviewId Exact Review row to return.
   * @param proposalBytes Already verified immutable Proposal-file bytes.
   * @returns Exact verified Review row.
   * @throws Error with recovery_required when durable Review authority is missing or changed.
   */
  private verifiedKnowledgeProposalReview(
    proposal: KnowledgeProposalRecord,
    reviewId: string,
    proposalBytes: string
  ): KnowledgeProposalReviewRecord {
    const decisions = this.knowledgeProposalReviews.get(proposal.id) ?? [];
    const review = decisions.find((candidate) => candidate.reviewId === reviewId);
    if (
      !review ||
      review.workspaceId !== proposal.workspaceId ||
      review.proposalDigest !== contentDigest(proposalBytes) ||
      review.knowledgePageId !== proposal.knowledgePageId ||
      review.contentDigest !== proposal.contentDigest
    ) {
      throw knowledgeProposalAuthorityError('recovery_required');
    }
    if (!this.dataRoot) {
      return review;
    }

    try {
      const path = join(
        this.workspaceRootPath(proposal.workspaceId),
        'knowledge',
        'reviews',
        `${proposal.id}.json`
      );
      const retained = KnowledgeProposalReviewFileSchema.parse(
        JSON.parse(readCanonicalTextFile(path))
      );
      if (
        !isDeepStrictEqual(retained, {
          proposalId: proposal.id,
          workspaceId: proposal.workspaceId,
          decisions,
        })
      ) {
        throw knowledgeProposalAuthorityError('recovery_required');
      }
      return review;
    } catch (error) {
      if (
        typeof error === 'object' &&
        error !== null &&
        'code' in error &&
        error.code === 'recovery_required'
      ) {
        throw error;
      }
      throw knowledgeProposalAuthorityError('recovery_required');
    }
  }

  /**
   * Reads the current page bytes addressed by one proposal.
   *
   * @param proposal Proposal that owns the page identity.
   * @returns Exact durable page bytes, or null when absent.
   * @throws Error with recovery_required when the page path is unreadable.
   */
  private readKnowledgeProposalPage(proposal: KnowledgeProposalRecord): string | null {
    if (!this.dataRoot) {
      const entry = this.getWorkspaceResources(proposal.workspaceId).knowledge.find(
        (candidate) => candidate.id === proposal.knowledgePageId
      );
      if (!entry) {
        return null;
      }
      const proposalEntry = parseOwnedKnowledgeEntry(
        `knowledge/pages/${proposal.knowledgePageId}.md`,
        proposal.knowledgePageId,
        proposal.canonicalPageBytes
      );
      return JSON.stringify(entry) === JSON.stringify(proposalEntry)
        ? proposal.canonicalPageBytes
        : serializeUserAuthoredKnowledgePage(entry);
    }

    try {
      return readWorkspaceKnowledgePage(
        this.workspaceRootPath(proposal.workspaceId),
        proposal.knowledgePageId
      );
    } catch {
      throw knowledgeProposalAuthorityError('recovery_required');
    }
  }

  private refreshWorkspaceCounts(workspaceId: string): void {
    const workspace = this.getWorkspace(workspaceId);
    const resources = this.getWorkspaceResources(workspaceId);
    this.workspaces.set(workspaceId, {
      ...workspace,
      counts: {
        threadCount: this.listThreads(workspaceId).length,
        artifactCount: this.listArtifacts(workspaceId).length,
        knowledgeEntryCount: resources.knowledge.length,
      },
      updatedAt: now(),
    });
  }

  public listWorkspaces(): WorkspaceRecord[] {
    return [...this.workspaces.values()];
  }

  /**
   * Ensures the built-in owner-only Quick Chat Workspace for one canonical user.
   *
   * @param userId Canonical user id that determines the stable Workspace id.
   * @returns Existing or newly created Quick Chat Workspace.
   * @throws Error when the reserved id already belongs to another Workspace kind.
   */
  public ensureQuickChatWorkspace(userId: string): WorkspaceRecord {
    const workspaceId = quickChatWorkspaceIdForUser(userId);
    const existing = this.workspaces.get(workspaceId);
    if (existing) {
      if (existing.kind !== 'quick-chat') {
        throw new Error(`Reserved Quick Chat workspace id ${workspaceId} has another kind.`);
      }
      return existing;
    }

    const timestamp = now();
    const workspace: WorkspaceRecord = {
      id: workspaceId,
      name: 'Quick Chat',
      kind: 'quick-chat',
      status: 'active',
      counts: {
        threadCount: 0,
        artifactCount: 0,
        knowledgeEntryCount: 0,
      },
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    this.persistNewWorkspaceAtomically(emptyWorkspaceFileRecords(workspace));
    this.workspaces.set(workspace.id, workspace);
    this.workspaceResources.set(workspace.id, createWorkspaceResources());
    return workspace;
  }

  public createWorkspace(name: string): WorkspaceRecord {
    const timestamp = now();
    const workspace: WorkspaceRecord = {
      id: allocateEntityId('ws'),
      name,
      kind: 'general',
      status: 'active',
      counts: {
        threadCount: 0,
        artifactCount: 0,
        knowledgeEntryCount: 0,
      },
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    const resources = createWorkspaceResources();
    this.persistNewWorkspaceAtomically(emptyWorkspaceFileRecords(workspace));
    this.workspaces.set(workspace.id, workspace);
    this.workspaceResources.set(workspace.id, resources);
    return workspace;
  }

  /**
   * Imports one verified workspace snapshot into the file-backed store.
   *
   * @param input Complete canonical workspace history to persist.
   * @returns Imported workspace record with recomputed counts.
   * @throws Error when target ids collide or records point at another workspace.
   */
  public importWorkspaceSnapshot(input: {
    workspace: WorkspaceRecord;
    threads: readonly Thread[];
    turns: readonly Turn[];
    knowledge: readonly KnowledgeEntry[];
    itemRevisions: readonly Item[];
    artifacts: readonly Artifact[];
    agentSessions: readonly AgentSession[];
    turnEvents: readonly (readonly [string, readonly SseEventEnvelope[]])[];
    knowledgeSources?: readonly KnowledgeSourceRecord[];
    knowledgeSourceMaterials?: readonly KnowledgeSourceMaterialRecord[];
    /** Immutable capture admission for imported Turns; absence remains unknown history. */
    turnCaptureCoverage?: ReadonlyMap<string, CaptureCoverageBinding>;
    stageWorkspace?: (stage: ImportWorkspaceStage) => void;
  }): WorkspaceRecord {
    const history = parseCanonicalWorkspaceHistory({
      workspace: input.workspace,
      threads: input.threads,
      turns: input.turns,
      itemRevisions: input.itemRevisions,
      artifacts: input.artifacts,
      knowledgeSources: input.knowledgeSources,
      agentSessions: input.agentSessions,
      turnEvents: input.turnEvents,
    });
    if (this.workspaces.has(history.workspace.id)) {
      throw new Error(`Workspace already exists: ${history.workspace.id}`);
    }

    for (const thread of history.threads) {
      if (this.threads.has(thread.id)) {
        throw new Error(`Thread already exists: ${thread.id}`);
      }
    }

    const importedTurnIds = new Set(history.turns.map((turn) => turn.id));
    const captureCoverage = new Map<string, CaptureCoverageBinding>();
    for (const [turnId, binding] of input.turnCaptureCoverage ?? []) {
      if (!importedTurnIds.has(turnId)) {
        throw new Error(`Capture coverage references missing imported Turn: ${turnId}`);
      }
      captureCoverage.set(turnId, CaptureCoverageBindingSchema.parse(binding));
    }

    const currentItems = history.turns.flatMap((turn) => turn.items);

    for (const turn of history.turns) {
      if (this.turns.has(turn.id)) {
        throw new Error(`Turn already exists: ${turn.id}`);
      }
    }
    for (const item of history.itemRevisions) {
      if (this.items.has(item.id)) {
        throw new Error(`Thread item already exists: ${item.id}`);
      }
    }
    for (const artifact of history.artifacts) {
      if (this.artifacts.has(artifact.id)) {
        throw new Error(`Artifact already exists: ${artifact.id}`);
      }
    }
    for (const session of history.agentSessions) {
      if (this.agentSessions.has(session.id)) {
        throw new Error(`AgentSession already exists: ${session.id}`);
      }
    }

    for (const source of history.knowledgeSources) {
      if (this.knowledgeSources.has(source.id)) {
        throw new Error(`Knowledge source already exists: ${source.id}`);
      }
    }

    const importedSourceIds = new Set(history.knowledgeSources.map((source) => source.id));
    for (const material of input.knowledgeSourceMaterials ?? []) {
      if (!importedSourceIds.has(material.sourceId)) {
        throw new Error(
          `Knowledge source material references missing source: ${material.sourceId}`
        );
      }
    }

    const workspace: WorkspaceRecord = {
      ...history.workspace,
      counts: {
        threadCount: history.threads.length,
        artifactCount: history.artifacts.length,
        knowledgeEntryCount: input.knowledge.length,
      },
    };

    const records: WorkspaceFileRecords = {
      workspace,
      knowledge: [...input.knowledge],
      threads: history.threads,
      turns: history.turns,
      turnCaptureCoverage: captureCoverage,
      itemRevisions: history.itemRevisions,
      artifacts: history.artifacts,
      knowledgeProposals: [],
      knowledgeProposalReviews: [],
      knowledgeSources: history.knowledgeSources,
      agentSessions: history.agentSessions,
      streamEvents: history.turnEvents,
    };

    this.persistNewWorkspaceAtomically(records, (stage) => {
      this.writeKnowledgeSourceMaterialsToRoot(
        stage.workspaceRoot,
        input.knowledgeSourceMaterials ?? [],
        history.knowledgeSources
      );
      input.stageWorkspace?.(stage);
    });

    this.workspaces.set(workspace.id, workspace);
    this.workspaceResources.set(workspace.id, createWorkspaceResources([...input.knowledge]));
    for (const thread of history.threads) {
      this.threads.set(thread.id, thread);
    }
    for (const turn of history.turns) {
      this.turns.set(turn.id, turn);
      const binding = captureCoverage.get(turn.id);
      if (binding) this.turnCaptureCoverage.set(turn.id, binding);
    }
    for (const item of currentItems) {
      this.items.set(item.id, item);
    }
    this.itemRevisions.push(...history.itemRevisions);
    for (const artifact of history.artifacts) {
      this.artifacts.set(artifact.id, artifact);
    }
    for (const session of history.agentSessions) {
      this.agentSessions.set(session.id, session);
    }
    for (const [turnId, events] of history.turnEvents) {
      this.streams.set(turnId, {
        sequence: events.at(-1)?.sequence ?? 0,
        events: events.slice(-TURN_STREAM_EVENT_WINDOW_SIZE),
        listeners: new Set(),
        timers: new Set(),
      });
    }
    for (const source of history.knowledgeSources) {
      this.knowledgeSources.set(source.id, source);
    }
    if (this.dataRoot) {
      for (const approval of loadApprovalProjections(
        this.dataRoot,
        [...this.turns.values()],
        [...this.commandRequests.values()]
      )) {
        if (approval.workspaceId === workspace.id) this.approvals.set(approval.id, approval);
      }
    }

    return workspace;
  }

  /**
   * Removes a workspace that was published before a coordinated external import failed.
   *
   * @param workspaceId Imported workspace to compensate.
   */
  public rollbackImportedWorkspace(workspaceId: string): void {
    this.getWorkspace(workspaceId);

    if (this.dataRoot) {
      const root = this.workspaceRootPath(workspaceId);
      if (lstatSync(root, { throwIfNoEntry: false })) {
        assertCanonicalDirectory(root);
        rmSync(root, { recursive: true });
      }
    }

    this.evictWorkspace(workspaceId);
  }

  /** Removes one Workspace from process-local read models without touching its filesystem root. */
  public evictWorkspace(workspaceId: string): void {
    const turnIds = new Set(
      [...this.turns.values()]
        .filter((turn) => turn.workspaceId === workspaceId)
        .map((turn) => turn.id)
    );

    this.workspaces.delete(workspaceId);
    this.workspaceResources.delete(workspaceId);
    for (const [threadId, thread] of this.threads) {
      if (thread.workspaceId === workspaceId) {
        this.threads.delete(threadId);
      }
    }
    for (const turnId of turnIds) {
      this.turns.delete(turnId);
      this.turnCaptureCoverage.delete(turnId);
      const stream = this.streams.get(turnId);
      if (stream) {
        for (const timer of stream.timers) {
          clearTimeout(timer);
        }
        this.streams.delete(turnId);
      }
    }
    for (const [itemId, item] of this.items) {
      if (item.workspaceId === workspaceId) {
        this.items.delete(itemId);
      }
    }
    this.itemRevisions = this.itemRevisions.filter((item) => item.workspaceId !== workspaceId);
    for (const [artifactId, artifact] of this.artifacts) {
      if (artifact.workspaceId === workspaceId) {
        this.artifacts.delete(artifactId);
      }
    }
    for (const [sessionId, session] of this.agentSessions) {
      if (session.workspaceId === workspaceId) {
        this.agentSessions.delete(sessionId);
      }
    }
    for (const [proposalId, proposal] of this.knowledgeProposals) {
      if (proposal.workspaceId === workspaceId) {
        this.knowledgeProposals.delete(proposalId);
        this.knowledgeProposalReviews.delete(proposalId);
      }
    }
    for (const [sourceId, source] of this.knowledgeSources) {
      if (source.workspaceId === workspaceId) {
        this.knowledgeSources.delete(sourceId);
      }
    }
    for (const [approvalId, approval] of this.approvals) {
      if (approval.workspaceId === workspaceId) {
        this.approvals.delete(approvalId);
      }
    }
  }

  public getWorkspace(workspaceId: string): WorkspaceRecord {
    const workspace = this.workspaces.get(workspaceId);

    if (!workspace) {
      throw new StoreRecordNotFoundError(`Workspace not found: ${workspaceId}`);
    }

    return workspace;
  }

  /**
   * Installs a live Agent catalog read projection for Workspace resources.
   *
   * The callback is consulted on each read. It does not persist catalog rows.
   *
   * @param projection Current-snapshot catalog projection.
   */
  public setWorkspaceAgentCatalogProjection(projection: () => RuntimeAgent[]): void {
    this.workspaceAgentCatalogProjection = projection;
  }

  /**
   * Returns stored Workspace resources without the live Agent catalog overlay.
   *
   * @param workspaceId Workspace whose stored resources should be read.
   * @returns Unprojected Workspace resource rows.
   */
  private storedWorkspaceResources(workspaceId: string): WorkspaceResources {
    this.getWorkspace(workspaceId);
    const resources = this.workspaceResources.get(workspaceId);

    if (!resources) {
      throw new StoreRecordNotFoundError(`Workspace resources not found: ${workspaceId}`);
    }

    return resources;
  }

  /** Reads Workspace resources with current Agent supply, without persisting the projection. */
  public getWorkspaceResources(workspaceId: string): WorkspaceResources {
    const resources = this.storedWorkspaceResources(workspaceId);
    const project = this.workspaceAgentCatalogProjection;

    return project ? { ...resources, agents: project() } : resources;
  }

  public updateWorkspace(
    workspaceId: string,
    input: {
      name?: WorkspaceRecord['name'] | undefined;
      kind?: WorkspaceRecord['kind'] | undefined;
      status?: WorkspaceRecord['status'] | undefined;
    }
  ): WorkspaceRecord {
    const workspace = this.getWorkspace(workspaceId);
    const updated: WorkspaceRecord = {
      ...workspace,
      name: input.name ?? workspace.name,
      kind: input.kind ?? workspace.kind,
      status: input.status ?? workspace.status,
      updatedAt: now(),
    };
    this.workspaces.set(workspaceId, updated);
    try {
      this.persist(workspaceId, input.name !== undefined);
    } catch (error) {
      this.workspaces.set(workspaceId, workspace);
      throw error;
    }
    return updated;
  }

  /** Refreshes joined Workspace names after an accepted runtime-config reload. */
  public refreshWorkspaceConfigNames(
    workspaceNames: readonly { readonly workspaceId: string; readonly name: string }[]
  ): void {
    for (const { workspaceId, name } of workspaceNames) {
      const workspace = this.workspaces.get(workspaceId);
      if (workspace && workspace.name !== name) {
        this.workspaces.set(workspaceId, { ...workspace, name });
      }
    }
  }

  public listKnowledge(workspaceId: string): KnowledgeEntry[] {
    return this.getWorkspaceResources(workspaceId).knowledge;
  }

  /**
   * Returns one workspace knowledge entry by id.
   *
   * @param workspaceId Workspace that owns the knowledge entry.
   * @param knowledgeEntryId Knowledge entry id to return.
   * @returns Stored knowledge entry.
   */
  public getKnowledgeEntry(workspaceId: string, knowledgeEntryId: string): KnowledgeEntry {
    const entry = this.listKnowledge(workspaceId).find((item) => item.id === knowledgeEntryId);

    if (!entry) {
      throw new StoreRecordNotFoundError(`Knowledge entry not found: ${knowledgeEntryId}`);
    }

    return entry;
  }

  /**
   * Creates or replaces one agent in a workspace resource set.
   *
   * @param workspaceId Workspace that owns the agent.
   * @param agent Agent read model to store.
   * @returns Stored agent.
   */
  public upsertAgent(workspaceId: string, agent: Agent): Agent {
    const resources = this.storedWorkspaceResources(workspaceId);
    let replaced = false;
    const agents = resources.agents.map((candidate) => {
      if (candidate.id !== agent.id) {
        return candidate;
      }

      replaced = true;
      return agent;
    });

    if (!replaced) {
      agents.push(agent);
    }

    this.workspaceResources.set(workspaceId, {
      ...resources,
      agents,
    });
    return agent;
  }

  /**
   * Refresh agent health timestamps for one workspace.
   *
   * @param workspaceId Workspace whose agents should be refreshed.
   * @returns Agent health read models.
   */
  public refreshAgentHealth(workspaceId: string): Array<{
    agentId: string;
    status: Agent['health']['status'];
    message: string | null;
    checkedAt: string;
  }> {
    const checkedAt = now();

    return this.getWorkspaceResources(workspaceId).agents.map((agent) => ({
      agentId: agent.id,
      status: agent.health.status,
      message: agent.health.message,
      checkedAt,
    }));
  }

  /**
   * Update one agent health record.
   *
   * @param workspaceId Workspace that owns the agent.
   * @param agentId Agent whose health should be updated.
   * @param health Agent health patch.
   * @returns Updated agent.
   */
  public updateAgentHealth(
    workspaceId: string,
    agentId: string,
    health: Partial<Agent['health']>
  ): Agent {
    const resources = this.storedWorkspaceResources(workspaceId);
    let updatedAgent: Agent | null = null;
    const agents = resources.agents.map((agent) => {
      if (agent.id !== agentId) {
        return agent;
      }

      updatedAgent = {
        ...agent,
        health: {
          ...agent.health,
          ...health,
        },
      };
      return updatedAgent;
    });

    if (!updatedAgent) {
      throw new StoreRecordNotFoundError(`Agent not found: ${agentId}`);
    }

    this.workspaceResources.set(workspaceId, {
      ...resources,
      agents,
    });
    return updatedAgent;
  }

  public createKnowledgeEntry(
    workspaceId: string,
    input: Pick<KnowledgeEntry, 'kind' | 'title' | 'content'> & {
      sourceReferences?: string[] | undefined;
    }
  ): KnowledgeEntry {
    const resources = this.storedWorkspaceResources(workspaceId);
    const entry: KnowledgeEntry = {
      id: `mem_${resources.knowledge.length + 1}`,
      ...input,
      ...(input.sourceReferences === undefined ? {} : { sourceReferences: input.sourceReferences }),
      createdAt: now(),
      updatedAt: now(),
    };
    this.assertValidKnowledgeEntryCandidate(workspaceId, entry, [...resources.knowledge, entry]);
    this.workspaceResources.set(workspaceId, {
      ...resources,
      knowledge: [...resources.knowledge, entry],
    });
    this.refreshWorkspaceCounts(workspaceId);
    this.persist(workspaceId);
    return entry;
  }

  /**
   * Delete one workspace knowledge entry.
   *
   * @param workspaceId Workspace identifier.
   * @param knowledgeEntryId Knowledge entry identifier.
   */
  public deleteKnowledgeEntry(workspaceId: string, knowledgeEntryId: string): void {
    const resources = this.storedWorkspaceResources(workspaceId);
    const knowledge = resources.knowledge.filter((entry) => entry.id !== knowledgeEntryId);

    if (knowledge.length === resources.knowledge.length) {
      throw new StoreRecordNotFoundError(`Knowledge entry not found: ${knowledgeEntryId}`);
    }

    if (this.dataRoot) {
      deleteWorkspaceKnowledgeRecord(this.workspaceRootPath(workspaceId), knowledgeEntryId);
    }
    this.workspaceResources.set(workspaceId, {
      ...resources,
      knowledge,
    });
    this.refreshWorkspaceCounts(workspaceId);
    this.persist(workspaceId);
  }

  public updateKnowledgeEntry(
    workspaceId: string,
    knowledgeEntryId: string,
    input: {
      title?: KnowledgeEntry['title'] | undefined;
      content?: KnowledgeEntry['content'] | undefined;
    }
  ): KnowledgeEntry {
    const resources = this.storedWorkspaceResources(workspaceId);
    const existing = resources.knowledge.find((entry) => entry.id === knowledgeEntryId);

    if (!existing) {
      throw new StoreRecordNotFoundError(`Knowledge entry not found: ${knowledgeEntryId}`);
    }

    const updated: KnowledgeEntry = {
      ...existing,
      title: input.title ?? existing.title,
      content: input.content ?? existing.content,
      updatedAt: now(),
    };
    const knowledge = resources.knowledge.map((entry) =>
      entry.id === knowledgeEntryId ? updated : entry
    );
    const path = `knowledge/pages/${knowledgeEntryId}.md`;
    const currentPageBytes = this.dataRoot
      ? (readWorkspaceKnowledgePage(this.workspaceRootPath(workspaceId), knowledgeEntryId) ??
        serializeUserAuthoredKnowledgePage(existing))
      : serializeUserAuthoredKnowledgePage(existing);
    const candidatePageBytes = updateUserAuthoredKnowledgePage(path, currentPageBytes, updated);
    this.assertValidKnowledgeEntryCandidate(workspaceId, updated, knowledge, candidatePageBytes);
    this.workspaceResources.set(workspaceId, {
      ...resources,
      knowledge,
    });
    this.refreshWorkspaceCounts(workspaceId);
    this.persist(workspaceId, false, new Map([[knowledgeEntryId, candidatePageBytes]]));
    return updated;
  }

  public listThreads(workspaceId: string): Thread[] {
    return [...this.threads.values()].filter((thread) => thread.workspaceId === workspaceId);
  }

  /** Creates formal shared work by default; conversation entrypoints supply the authenticated private audience explicitly. */
  public createThread(
    workspaceId: string,
    title: string,
    threadId?: string,
    entryPath: Thread['entryPath'] = 'conversation',
    audience?: { visibility: Thread['visibility']; privateOwnerUserId?: string },
    parentThreadId?: string
  ): Thread {
    const id = threadId ?? allocateEntityId('th');
    if (this.threads.has(id)) {
      throw new Error(`Thread already exists: ${id}`);
    }
    if (
      !audience &&
      (this.getWorkspace(workspaceId).kind === 'quick-chat' || entryPath === 'administration')
    ) {
      throw new Error('Private Thread creation requires its explicit canonical User audience.');
    }
    audience ??= { visibility: 'workspace' };
    if (
      this.getWorkspace(workspaceId).kind === 'quick-chat' &&
      (audience.visibility !== 'private' ||
        workspaceId !== quickChatWorkspaceIdForUser(audience.privateOwnerUserId ?? ''))
    ) {
      throw new Error('Quick Chat requires its owner-only private audience.');
    }
    if (parentThreadId !== undefined) {
      if (parentThreadId === id) throw new Error('A receiving Thread must differ from its parent.');
      this.getThread(workspaceId, parentThreadId);
    }
    const thread = ThreadSchema.parse({
      id,
      workspaceId,
      ...(parentThreadId === undefined ? {} : { parentThreadId }),
      name: title,
      preview: title,
      status: 'active',
      entryPath,
      ...audience,
      createdAt: now(),
      updatedAt: now(),
    });
    this.threads.set(thread.id, thread);
    this.refreshWorkspaceCounts(workspaceId);
    this.persist(workspaceId);
    return thread;
  }

  /**
   * Update one thread's product-visible metadata.
   *
   * @param workspaceId Workspace that owns the thread.
   * @param threadId Thread to update.
   * @param input Thread metadata patch.
   * @returns Updated thread.
   */
  public updateThread(
    workspaceId: string,
    threadId: string,
    input: Partial<Pick<Thread, 'name' | 'status'>>
  ): Thread {
    const thread = this.getThread(workspaceId, threadId);
    const updated: Thread = {
      ...thread,
      ...(input.name !== undefined ? { name: input.name } : {}),
      ...(input.status !== undefined ? { status: input.status } : {}),
      updatedAt: now(),
    };
    this.threads.set(threadId, updated);
    this.persist(workspaceId);
    return updated;
  }

  /**
   * Archive one thread.
   *
   * @param workspaceId Workspace that owns the thread.
   * @param threadId Thread to archive.
   * @returns Archived thread.
   */
  public archiveThread(workspaceId: string, threadId: string): Thread {
    return this.updateThread(workspaceId, threadId, { status: 'archived' });
  }

  public getThread(workspaceId: string, threadId: string): Thread {
    const thread = this.threads.get(threadId);

    if (!thread || thread.workspaceId !== workspaceId) {
      throw new StoreRecordNotFoundError(`Thread not found: ${threadId}`);
    }

    return thread;
  }

  /**
   * Creates one running turn and updates the owning thread preview.
   *
   * @param workspaceId Workspace that owns the turn.
   * @param threadId Thread that owns the turn.
   * @param input User or scheduler input used for the thread preview.
   * @param triggerActor Exact actor whose accepted action created the Turn.
   * @param configVersion Runtime config version captured for the turn.
   * @param options Optional turn creation controls, including the admission-time capture pair.
   * @returns Created turn.
   * @throws Error when the requested turn id already exists.
   */
  public createTurn(
    workspaceId: string,
    threadId: string,
    input: string,
    triggerActor: ActorRef,
    configVersion: number | null = null,
    options: CreateTurnOptions = {}
  ): Turn {
    const timestamp = options.startedAt ?? now();
    const turnId = options.turnId ?? allocateEntityId('tu');

    if (this.turns.has(turnId)) {
      throw new Error(`Turn already exists: ${turnId}`);
    }

    const thread = this.getThread(workspaceId, threadId);
    const turn = TurnSchema.parse({
      id: turnId,
      workspaceId,
      threadId,
      triggerActor,
      items: [],
      status: options.status ?? 'running',
      error: null,
      configVersion,
      startedAt: timestamp,
      completedAt: null,
      durationMs: null,
      ...(options.reasoningEffort !== undefined
        ? { reasoningEffort: options.reasoningEffort }
        : {}),
      ...(options.agentId !== undefined ? { agentId: options.agentId } : {}),
      ...(options.agentSessionId !== undefined ? { agentSessionId: options.agentSessionId } : {}),
      ...(options.triggerSource !== undefined ? { triggerSource: options.triggerSource } : {}),
    });
    this.turns.set(turn.id, turn);
    if (options.executorKind) this.turnExecutors.set(turn.id, options.executorKind);
    this.threads.set(threadId, {
      ...thread,
      preview: input,
      updatedAt: timestamp,
    });
    this.streams.set(turn.id, {
      sequence: 0,
      events: [],
      listeners: new Set(),
      timers: new Set(),
    });
    this.turnCaptureCoverage.set(turn.id, options.captureCoverage ?? this.liveCaptureCoverage);
    this.persist(workspaceId);
    this.turnAdmissionHooks?.onAdmitted?.(turn);
    return this.getTurnById(turn.id);
  }

  /**
   * Registers admission and terminal hooks for pending-request delivery.
   *
   * @param hooks Hooks invoked by Turn admission and the first terminal transition.
   */
  public setTurnAdmissionHooks(hooks: TurnAdmissionHooks | null): void {
    this.turnAdmissionHooks = hooks;
  }

  /**
   * Returns the executor declared when the Turn was admitted.
   *
   * @param turnId Turn id.
   * @returns Executor, or null when admission did not declare one.
   */
  public getTurnExecutor(turnId: string): 'worker' | 'assistant' | 'coordinator' | 'person' | null {
    return this.turnExecutors.get(turnId) ?? null;
  }

  /**
   * Sets the live capture-coverage policy used by later Turn admission.
   *
   * @param binding Resolved pair to snapshot onto the next admitted Turn.
   */
  public setLiveCaptureCoverage(binding: CaptureCoverageBinding): void {
    this.liveCaptureCoverage = binding;
  }

  /**
   * Returns the live capture-coverage policy used by later Turn admission.
   *
   * @returns Current live pair.
   */
  public getLiveCaptureCoverage(): CaptureCoverageBinding {
    return this.liveCaptureCoverage;
  }

  /**
   * Returns the admission-time capture pair recorded for one Turn.
   *
   * @param turnId Turn whose historical pair should be read.
   * @returns Recorded pair, or null when that Turn was never recorded.
   */
  public getTurnCaptureCoverage(turnId: string): CaptureCoverageBinding | null {
    return this.turnCaptureCoverage.get(turnId) ?? null;
  }

  public getTurn(workspaceId: string, threadId: string, turnId: string): Turn {
    const turn = this.turns.get(turnId);

    if (!turn || turn.workspaceId !== workspaceId || turn.threadId !== threadId) {
      throw new StoreRecordNotFoundError(`Turn not found: ${turnId}`);
    }

    return turn;
  }

  /** Returns only the opaque Turn's canonical Workspace and Thread selectors before content admission. */
  public getTurnLineage(turnId: string): { workspaceId: string; threadId: string } | null {
    const turn = this.turns.get(turnId);
    return turn ? { workspaceId: turn.workspaceId, threadId: turn.threadId } : null;
  }

  public getTurnById(turnId: string): Turn {
    const turn = this.turns.get(turnId);

    if (!turn) {
      throw new StoreRecordNotFoundError(`Turn not found: ${turnId}`);
    }

    return turn;
  }

  /**
   * List turns for one thread in chronological order.
   *
   * @param workspaceId Workspace that owns the thread.
   * @param threadId Thread whose turns should be returned.
   * @returns Ordered thread turns.
   */
  public listThreadTurns(workspaceId: string, threadId: string): Turn[] {
    this.getThread(workspaceId, threadId);
    return [...this.turns.values()]
      .filter((turn) => turn.workspaceId === workspaceId && turn.threadId === threadId)
      .sort((left, right) => (left.startedAt ?? '').localeCompare(right.startedAt ?? ''));
  }

  /**
   * Updates a turn and revalidates the protocol record.
   *
   * @param turnId Turn identifier to update.
   * @param input Partial turn fields to merge onto the stored turn.
   * @param admission Declared post-terminal category when the Turn is already sealed.
   * @returns Updated turn after protocol validation.
   * @throws Error when the turn does not exist, the merged turn violates the protocol schema, or a post-terminal write is not admitted.
   */
  public updateTurn(
    turnId: string,
    input: Partial<
      Pick<
        Turn,
        | 'agentId'
        | 'agentProfileId'
        | 'agentSessionId'
        | 'completedAt'
        | 'configVersion'
        | 'durationMs'
        | 'error'
        | 'status'
        | 'triggerSource'
      >
    >,
    admission?: TerminalTurnWriteAdmission
  ): Turn {
    const turn = this.turns.get(turnId);

    if (!turn) {
      throw new StoreRecordNotFoundError(`Turn not found: ${turnId}`);
    }

    const unsupportedField = Object.keys(input).find(
      (field) =>
        ![
          'agentId',
          'agentProfileId',
          'agentSessionId',
          'completedAt',
          'configVersion',
          'durationMs',
          'error',
          'status',
          'triggerSource',
        ].includes(field)
    );
    if (unsupportedField) {
      throw new Error(`Turn update cannot change field: ${unsupportedField}`);
    }

    const updated = TurnSchema.parse({
      ...turn,
      ...input,
      durationMs:
        (input.completedAt ?? turn.completedAt) && turn.startedAt
          ? Math.max(
              0,
              new Date(input.completedAt ?? turn.completedAt ?? now()).getTime() -
                new Date(turn.startedAt).getTime()
            )
          : (input.durationMs ?? turn.durationMs),
    });
    if (isSealedTurnTerminal(turn.status)) {
      if (alreadyDecidedPublicationBytesEqual(turn, updated)) {
        return turn;
      }
      if (
        admission?.category === 'already-decided-publication' &&
        !decidedTurnFieldsConflict(turn, updated)
      ) {
        // Fill-only completion of an already-decided terminal Turn.
      } else if (admission?.category === 'already-decided-publication') {
        throw terminalTurnPublicationConflict(turnId);
      } else {
        throw terminalTurnWriteRejected(turnId);
      }
    }
    if (!isSealedTurnTerminal(turn.status) && isSealedTurnTerminal(updated.status))
      this.turnAdmissionHooks?.onTerminalFact?.(updated);
    this.turns.set(turnId, updated);
    this.persist(turn.workspaceId);
    if (updated.status === 'completed' && !turn.completedAt && updated.completedAt) {
      ensureTurnFeedback(this, updated, updated.agentId ?? null);
    }
    if (
      !isSealedTurnTerminal(turn.status) &&
      isSealedTurnTerminal(updated.status) &&
      this.terminalHookDepth < 8
    ) {
      this.terminalHookDepth += 1;
      try {
        this.turnAdmissionHooks?.onTerminal?.(updated);
      } finally {
        this.terminalHookDepth -= 1;
      }
    }
    return this.getTurnById(turnId);
  }

  /**
   * Returns the configured data root for file-backed operations.
   *
   * @returns Data root, or null for in-memory stores.
   */
  public getDataRoot(): string | null {
    return this.dataRoot;
  }

  /**
   * Creates or returns one Item, admitting post-terminal completion or display-projection create when declared.
   *
   * @param input Item to persist.
   * @param admission Declared post-terminal category when the owning Turn is already sealed.
   * @returns Stored Item.
   * @throws Error when lineage is invalid or a post-terminal write is not admitted.
   */
  public createItem(input: Item, admission?: TerminalTurnWriteAdmission): Item {
    const item = ItemSchema.parse(input);
    const existing = this.items.get(item.id);
    const turn = this.getTurnById(item.turnId);
    if (turn.workspaceId !== item.workspaceId || turn.threadId !== item.threadId) {
      throw new Error(`Item has invalid turn lineage: ${item.id}`);
    }
    if (
      item.type === 'user-input-request' &&
      item.responsibleUserId !== responsibleUserIdForActor(turn.triggerActor)
    ) {
      throw new Error(`User-input request has invalid responsible user: ${item.id}`);
    }
    if (item.type === 'user-input-response') {
      const request = turn.items.find(
        (candidate) =>
          candidate.type === 'user-input-request' &&
          candidate.userInputRequestId === item.userInputRequestId
      );
      if (request?.type === 'user-input-request' && request.responsibleUserId !== item.actor.id) {
        throw new Error(`User-input response has invalid responsible user: ${item.id}`);
      }
    }
    if (isSealedTurnTerminal(turn.status)) {
      if (existing && alreadyDecidedPublicationBytesEqual(existing, item)) {
        return existing;
      }
      const pendingConfigurationApply =
        admission?.category === 'configuration-apply-pending-delayed-user-input' && !existing;
      const missingAlreadyDecided =
        admission?.category === 'already-decided-publication' && !existing;
      const missingDisplayProjection =
        admission?.category === 'display-projection-refresh' && !existing && item.type === 'status';
      if (pendingConfigurationApply) {
        // Pending docs/specs/20260930-pending_requests.md: configuration apply is a new authorized command, not post-terminal repair.
      } else if (missingAlreadyDecided || missingDisplayProjection) {
        // Complete a missing publication of an already-decided outcome, or create a missing display projection.
      } else if (existing) {
        throw terminalTurnPublicationConflict(turn.id);
      } else {
        throw terminalTurnWriteRejected(turn.id);
      }
    }
    if (
      existing &&
      (existing.workspaceId !== item.workspaceId ||
        existing.threadId !== item.threadId ||
        existing.turnId !== item.turnId ||
        existing.type !== item.type ||
        existing.createdAt !== item.createdAt)
    ) {
      throw new Error(`Item immutable identity cannot change: ${item.id}`);
    }
    if (existing) {
      assertImmutableItemAttribution(existing, item);
    }
    const updatedTurn = {
      ...turn,
      items: existing
        ? turn.items.map((candidate) => (candidate.id === item.id ? item : candidate))
        : [...turn.items, item],
    };
    if (this.dataRoot) {
      appendWorkspaceItemRevision(this.workspaceRootPath(item.workspaceId), item);
    }
    this.itemRevisions.push(item);
    this.items.set(item.id, item);
    this.turns.set(item.turnId, updatedTurn);
    return item;
  }

  /**
   * Updates one Item, admitting a named display-projection refresh after the owning Turn is sealed.
   *
   * @param itemId Item identifier to update.
   * @param input Partial Item fields to merge.
   * @param admission Declared post-terminal category when the owning Turn is already sealed.
   * @returns Updated Item.
   * @throws Error when the Item does not exist, identity would change, or a post-terminal write is not admitted.
   */
  public updateItem(
    itemId: string,
    input: Partial<Item>,
    admission?: TerminalTurnWriteAdmission
  ): Item {
    const item = this.items.get(itemId);

    if (!item) {
      throw new StoreRecordNotFoundError(`Item not found: ${itemId}`);
    }

    const turn = this.getTurnById(item.turnId);
    let patch: Partial<Item> = input;
    if (isSealedTurnTerminal(turn.status)) {
      if (admission?.category === 'display-projection-refresh') {
        const unsupportedField = Object.keys(input).find(
          (field) => !DISPLAY_PROJECTION_REFRESH_FIELDS.some((allowed) => allowed === field)
        );
        if (unsupportedField) {
          throw terminalTurnWriteRejected(turn.id);
        }
        const recorded = item as unknown as Record<string, unknown>;
        const patchFields = input as unknown as Record<string, unknown>;
        const projection = {
          level: patchFields.level !== undefined ? patchFields.level : recorded.level,
          title: patchFields.title !== undefined ? patchFields.title : recorded.title,
          summary: patchFields.summary !== undefined ? patchFields.summary : recorded.summary,
        };
        if (displayProjectionFieldsEqual(item, projection)) {
          return item;
        }
        patch = {
          level: projection.level,
          title: projection.title,
          summary: projection.summary,
        } as Partial<Item>;
      } else if (admission?.category === 'already-decided-publication') {
        const candidate = ItemSchema.parse({ ...item, ...input });
        if (alreadyDecidedPublicationBytesEqual(item, candidate)) {
          return item;
        }
        throw terminalTurnPublicationConflict(turn.id);
      } else {
        throw terminalTurnWriteRejected(turn.id);
      }
    }

    const updated = ItemSchema.parse({ ...item, ...patch });
    if (
      updated.id !== item.id ||
      updated.workspaceId !== item.workspaceId ||
      updated.threadId !== item.threadId ||
      updated.turnId !== item.turnId ||
      updated.type !== item.type ||
      updated.createdAt !== item.createdAt
    ) {
      throw new Error(`Item immutable identity cannot change: ${itemId}`);
    }
    assertImmutableItemAttribution(item, updated);
    const updatedTurn = {
      ...turn,
      items: turn.items.map((candidate) => (candidate.id === itemId ? updated : candidate)),
    };

    if (this.dataRoot) {
      appendWorkspaceItemRevision(this.workspaceRootPath(updated.workspaceId), updated);
    }
    this.itemRevisions.push(updated);
    this.items.set(itemId, updated);
    this.turns.set(item.turnId, updatedTurn);
    return updated;
  }

  /**
   * List durable items for one thread in chronological order.
   *
   * @param workspaceId Workspace that owns the thread.
   * @param threadId Thread whose item history should be returned.
   * @returns Ordered thread items.
   */
  public listThreadItems(workspaceId: string, threadId: string): Item[] {
    this.getThread(workspaceId, threadId);
    return [...this.items.values()]
      .filter((item) => item.workspaceId === workspaceId && item.threadId === threadId)
      .sort((left, right) => left.createdAt.localeCompare(right.createdAt));
  }

  /**
   * Lists every durable item revision for one workspace in append order.
   *
   * @param workspaceId Workspace whose item history should be returned.
   * @returns Full item revision history.
   */
  public listWorkspaceItemRevisions(workspaceId: string): Item[] {
    this.getWorkspace(workspaceId);
    return this.itemRevisions.filter((item) => item.workspaceId === workspaceId);
  }

  /**
   * Return all durable items across workspaces for app-local read models.
   *
   * @returns Stored items.
   */
  public listAllItems(): Item[] {
    return [...this.items.values()];
  }

  /**
   * Creates or replaces one target-issued Approval request.
   *
   * @param input Approval request to store.
   * @returns Stored Approval request.
   * @throws When the id belongs to the portable-import history namespace.
   */
  public createApproval(input: ApprovalRequest): ApprovalRequest {
    if (!isTargetIssuedEffectAuthority(input.id)) {
      throw new Error('Approval id uses the reserved portable-import authority namespace.');
    }

    this.approvals.set(input.id, input);
    return input;
  }

  /** Reads only existing Approval-map lineage under the selected Workspace; its command owner validates the canonical Pending Request. */
  public getApprovalProjectionLineage(
    workspaceId: string,
    requestId: string
  ): { workspaceId: string; threadId: string } | null {
    const approval = this.approvals.get(requestId);
    if (approval?.workspaceId === workspaceId) return { workspaceId, threadId: approval.threadId };
    return null;
  }

  public getApproval(approvalRequestId: string): ApprovalRequest {
    const approval = this.approvals.get(approvalRequestId);

    if (!approval) {
      throw new StoreRecordNotFoundError(`Approval request not found: ${approvalRequestId}`);
    }

    return approval;
  }

  public updateApproval(
    approvalRequestId: string,
    input: Partial<ApprovalRequest>
  ): ApprovalRequest {
    const approval = this.getApproval(approvalRequestId);
    const updated: ApprovalRequest = { ...approval, ...input };
    this.approvals.set(approvalRequestId, updated);
    return updated;
  }

  public createAgentSession(input: AgentSessionInput): AgentSession {
    this.getWorkspace(input.workspaceId);
    if (!input.threadId) {
      throw new Error(`AgentSession requires a thread: ${input.id}`);
    }
    this.getThread(input.workspaceId, input.threadId);
    const existing = this.agentSessions.get(input.id);

    if (existing) {
      throw new Error(`AgentSession id already exists: ${input.id}`);
    }

    const workspaceRoots = input.workspaceRoots ?? [];
    const agentSession = AgentSessionRecordSchema.parse({
      configVersion: null,
      environmentPackageSnapshotId: null,
      nativeHandleDigest: null,
      retainedStorage: null,
      policySnapshotId: null,
      sandboxSummary: sandboxSummaryForWorkspaceRoots(workspaceRoots),
      sessionCompatibilityKey: null,
      stale: false,
      workspaceRoots,
      ...input,
    }) as AgentSession;

    if (
      isCurrentAgentSessionStatus(agentSession.status) &&
      this.listThreadAgentSessions(agentSession.workspaceId, input.threadId).some((candidate) =>
        isCurrentAgentSessionStatus(candidate.status)
      )
    ) {
      throw new Error(`Thread already has a current AgentSession: ${input.threadId}`);
    }

    this.agentSessions.set(agentSession.id, agentSession);
    this.persist(agentSession.workspaceId);
    return agentSession;
  }

  /**
   * Return one AgentSession by id.
   *
   * @param agentSessionId AgentSession id to load.
   * @returns Stored AgentSession.
   */
  public getAgentSession(agentSessionId: string): AgentSession {
    const agentSession = this.agentSessions.get(agentSessionId);

    if (!agentSession) {
      throw new StoreRecordNotFoundError(`AgentSession not found: ${agentSessionId}`);
    }

    return agentSession;
  }

  /** Updates session lifecycle while preserving its write-once native proof and attachment provenance. */
  public updateAgentSession(
    agentSessionId: string,
    input: Partial<
      Pick<
        AgentSession,
        | 'configVersion'
        | 'environmentPackageSnapshotId'
        | 'message'
        | 'nativeHandleDigest'
        | 'retainedStorage'
        | 'stale'
        | 'status'
        | 'updatedAt'
      >
    >
  ): AgentSession {
    const agentSession = this.getAgentSession(agentSessionId);
    const unsupportedField = Object.keys(input).find(
      (field) =>
        ![
          'configVersion',
          'environmentPackageSnapshotId',
          'message',
          'nativeHandleDigest',
          'retainedStorage',
          'stale',
          'status',
          'updatedAt',
        ].includes(field)
    );
    if (unsupportedField) {
      throw new Error(`AgentSession update cannot change field: ${unsupportedField}`);
    }
    // The resume pair is write-once: a later proof for the same binding must carry the same digest.
    if (
      input.retainedStorage !== undefined &&
      agentSession.retainedStorage !== null &&
      (input.retainedStorage?.storageRef !== agentSession.retainedStorage.storageRef ||
        input.retainedStorage?.workSlotRef !== agentSession.retainedStorage.workSlotRef)
    ) {
      throw new Error('AgentSession retained-storage attachment cannot change.');
    }
    if (
      input.nativeHandleDigest !== undefined &&
      agentSession.nativeHandleDigest !== null &&
      input.nativeHandleDigest !== agentSession.nativeHandleDigest
    ) {
      throw new Error(`AgentSession resume digest cannot change: ${agentSessionId}`);
    }
    if (
      input.status &&
      !isCurrentAgentSessionStatus(agentSession.status) &&
      isCurrentAgentSessionStatus(input.status)
    ) {
      throw new Error(`Terminal AgentSession cannot become current again: ${agentSessionId}`);
    }
    const updated = AgentSessionRecordSchema.parse({
      ...agentSession,
      ...input,
      updatedAt: input.updatedAt ?? now(),
    }) as AgentSession;
    this.agentSessions.set(agentSessionId, updated);
    this.persist(agentSession.workspaceId);
    return updated;
  }

  /**
   * List AgentSessions for one thread in durable creation order.
   *
   * @param workspaceId Workspace that owns the thread.
   * @param threadId Thread whose AgentSessions should be returned.
   * @returns AgentSessions recorded for the thread.
   */
  public listThreadAgentSessions(workspaceId: string, threadId: string): AgentSession[] {
    this.getThread(workspaceId, threadId);
    return [...this.agentSessions.values()].filter(
      (agentSession) =>
        agentSession.workspaceId === workspaceId && agentSession.threadId === threadId
    );
  }

  /**
   * Lists every durable AgentSession for one workspace.
   *
   * @param workspaceId Workspace whose sessions should be returned.
   * @returns Workspace-owned AgentSessions.
   */
  public listWorkspaceAgentSessions(workspaceId: string): AgentSession[] {
    this.getWorkspace(workspaceId);
    return [...this.agentSessions.values()].filter(
      (agentSession) => agentSession.workspaceId === workspaceId
    );
  }

  /**
   * Creates one immutable Artifact and its producing-Turn reference when applicable.
   *
   * @param input Complete Artifact authority.
   * @param filePayload Exact privately staged original for file-backed content.
   * @returns Created Artifact.
   * @throws ArtifactAuthorityError when content proof or create-only ownership is invalid.
   */
  public createArtifact(input: Artifact, filePayload?: StagedArtifactPayload): Artifact {
    const parsed = ArtifactSchema.safeParse(input);
    if (!parsed.success) {
      throw new ArtifactAuthorityError('invalid_request', 'Artifact input is invalid.');
    }
    const artifact = parsed.data;
    if (
      artifact.version !== 1 ||
      (artifact.origin.kind === 'imported' &&
        (artifact.kind !== 'file' || artifact.status !== 'ready' || artifact.summary !== null))
    ) {
      throw new ArtifactAuthorityError(
        'invalid_request',
        'Artifact creation accepts only a valid initial authority shape.'
      );
    }
    this.getWorkspace(artifact.workspaceId);
    const contentDigest =
      artifact.content.format === 'file'
        ? filePayload?.contentDigest
        : `sha256:${createHash('sha256').update(artifact.content.body, 'utf8').digest('hex')}`;
    if (contentDigest !== artifact.contentDigest) {
      throw new ArtifactAuthorityError(
        'source_digest_mismatch',
        'Artifact content does not match its digest.'
      );
    }
    if (
      artifact.content.format === 'file' &&
      (!this.dataRoot || !filePayload || filePayload.byteLength !== artifact.content.byteLength)
    ) {
      throw new ArtifactAuthorityError(
        'invalid_request',
        'Artifact file creation requires exact privately staged bytes and durable storage.'
      );
    }
    if (
      this.artifacts.has(artifact.id) ||
      [...this.items.values()].some(
        (item) => item.type === 'artifact-reference' && item.artifactId === artifact.id
      )
    ) {
      throw new ArtifactAuthorityError(
        'recovery_required',
        'The request-owned Artifact already has authority without a receipt.'
      );
    }

    let producingTurn: Turn | null = null;
    let reference: Extract<Item, { type: 'artifact-reference' }> | null = null;
    if (artifact.origin.kind === 'turn-output') {
      producingTurn = this.getTurn(
        artifact.workspaceId,
        artifact.origin.threadId,
        artifact.origin.turnId
      );
      const itemId = artifactReferenceItemId(artifact.id, producingTurn.id);
      if (this.items.has(itemId)) {
        throw new ArtifactAuthorityError(
          'recovery_required',
          'The producing Artifact reference identity is already occupied.'
        );
      }
      reference = ItemSchema.parse({
        id: itemId,
        workspaceId: artifact.workspaceId,
        threadId: producingTurn.threadId,
        turnId: producingTurn.id,
        type: 'artifact-reference',
        status: 'completed',
        artifactId: artifact.id,
        artifactVersion: artifact.version,
        title: artifact.title,
        summary: artifact.summary,
        lastMutationRequestId: artifact.lastMutationRequestId,
        createdAt: artifact.createdAt,
        completedAt: artifact.updatedAt,
      }) as Extract<Item, { type: 'artifact-reference' }>;
    }

    this.artifacts.set(artifact.id, artifact);
    this.refreshWorkspaceCounts(artifact.workspaceId);
    try {
      if (artifact.content.format === 'file' && filePayload) {
        publishArtifactFileRecord({
          workspaceRoot: this.workspaceRootPath(artifact.workspaceId),
          artifact,
          payloadPath: filePayload.path,
        });
      }
      this.persist(artifact.workspaceId);
    } catch (error) {
      this.artifacts.delete(artifact.id);
      this.refreshWorkspaceCounts(artifact.workspaceId);
      this.persist(artifact.workspaceId);
      throw error;
    }
    if (reference) {
      this.createItem(reference);
    }
    return artifact;
  }

  /** Rolls back only a newly created request-owned Artifact after handled publication failure. @param artifactId Initial Artifact identity, preflighted absent by the command. */
  public rollbackArtifactCreation(artifactId: string): void {
    const artifact = this.artifacts.get(artifactId);
    if (!artifact) return;
    if (artifact.version !== 1)
      throw new ArtifactAuthorityError(
        'recovery_required',
        'Artifact rollback cannot remove a later version.'
      );
    if (this.dataRoot && artifact.origin.kind === 'turn-output') {
      const itemsPath = join(
        this.workspaceRootPath(artifact.workspaceId),
        'threads',
        artifact.origin.threadId,
        'turns',
        artifact.origin.turnId,
        'items.jsonl'
      );
      const referenceId = artifactReferenceItemId(artifactId, artifact.origin.turnId);
      // Remove only this unacknowledged append; preserve all prior canonical row bytes and extensions.
      const before = readCanonicalTextFile(itemsPath);
      const retained = before
        .split('\n')
        .filter((line) => {
          if (!line.trim()) return true;
          const row = JSON.parse(line);
          return !(
            row.id === referenceId &&
            row.type === 'artifact-reference' &&
            row.artifactId === artifactId
          );
        })
        .join('\n');
      if (retained !== before) writeFileAtomic(itemsPath, retained);
    }
    this.artifacts.delete(artifactId);
    this.itemRevisions = this.itemRevisions.filter(
      (item) => item.type !== 'artifact-reference' || item.artifactId !== artifactId
    );
    for (const [id, item] of this.items) {
      if (item.type === 'artifact-reference' && item.artifactId === artifactId) {
        this.items.delete(id);
        const turn = this.turns.get(item.turnId);
        if (turn)
          this.turns.set(turn.id, {
            ...turn,
            items: turn.items.filter((candidate) => candidate.id !== id),
          });
      }
    }
    this.refreshWorkspaceCounts(artifact.workspaceId);
    this.persist(artifact.workspaceId);
  }

  /**
   * Introduces one workspace-only imported Artifact into an idle Thread.
   *
   * @param input Accepted command scope, proof, and deterministic identities.
   * @returns Stable Artifact, Turn, and Item identities.
   * @throws ArtifactAuthorityError when the target is stale, busy, conflicting, or incomplete.
   */
  public introduceArtifact(input: IntroduceArtifactInput): IntroduceWorkspaceArtifactResponse {
    const thread = this.threads.get(input.threadId);
    if (
      !this.workspaces.has(input.workspaceId) ||
      !thread ||
      thread.workspaceId !== input.workspaceId
    ) {
      throw new ArtifactAuthorityError('stale', 'The requested Workspace or Thread is absent.');
    }
    const artifact = this.artifacts.get(input.artifactId);
    if (!artifact || artifact.workspaceId !== input.workspaceId) {
      throw new ArtifactAuthorityError('stale', 'The requested Artifact is absent.');
    }
    if (
      artifact.origin.kind !== 'imported' ||
      artifact.threadId !== null ||
      artifact.turnId !== null
    ) {
      throw new ArtifactAuthorityError(
        'stale',
        'The requested Artifact is not workspace-only imported content.'
      );
    }
    this.assertArtifactContent(artifact);
    const contentDigest = artifact.contentDigest;
    if (
      contentDigest !== artifact.contentDigest ||
      contentDigest !== artifact.origin.sourceDigest
    ) {
      throw new ArtifactAuthorityError(
        'recovery_required',
        'The imported Artifact has invalid durable content proof.'
      );
    }
    if (artifact.version !== input.expectedArtifactVersion) {
      throw new ArtifactAuthorityError(
        'conflict',
        'The Artifact version does not match the request.'
      );
    }

    const itemId = artifactReferenceItemId(input.artifactId, input.turnId);
    const matchingReference = [...this.items.values()].find(
      (item) =>
        item.type === 'artifact-reference' &&
        item.workspaceId === input.workspaceId &&
        item.threadId === input.threadId &&
        item.artifactId === input.artifactId &&
        (item.turnId === input.turnId || item.lastMutationRequestId === input.requestId)
    );
    if (
      this.turns.has(input.turnId) ||
      this.items.has(itemId) ||
      this.streams.has(input.turnId) ||
      matchingReference
    ) {
      throw new ArtifactAuthorityError(
        'recovery_required',
        'The Artifact introduction owner tuple already exists without a receipt.'
      );
    }
    if (
      [...this.turns.values()].some(
        (turn) =>
          turn.workspaceId === input.workspaceId &&
          turn.threadId === input.threadId &&
          !isSealedTurnTerminal(turn.status)
      )
    ) {
      throw new ArtifactAuthorityError(
        'thread_busy',
        'The Thread already has a non-terminal Turn.'
      );
    }

    const reference = ItemSchema.parse({
      id: itemId,
      workspaceId: input.workspaceId,
      threadId: input.threadId,
      turnId: input.turnId,
      type: 'artifact-reference',
      status: 'completed',
      artifactId: artifact.id,
      artifactVersion: artifact.version,
      title: artifact.title,
      summary: artifact.summary,
      lastMutationRequestId: input.requestId,
      createdAt: input.acceptedAt,
      completedAt: input.acceptedAt,
    }) as Extract<Item, { type: 'artifact-reference' }>;
    const turn = TurnSchema.parse({
      id: input.turnId,
      workspaceId: input.workspaceId,
      threadId: input.threadId,
      triggerActor: input.triggerActor,
      items: [reference],
      status: 'completed',
      error: null,
      configVersion: null,
      startedAt: input.acceptedAt,
      completedAt: input.acceptedAt,
      durationMs: 0,
    });
    const itemRevisionCount = this.itemRevisions.length;

    this.turns.set(turn.id, turn);
    this.items.set(reference.id, reference);
    this.itemRevisions.push(reference);
    this.streams.set(turn.id, {
      sequence: 0,
      events: [],
      listeners: new Set(),
      timers: new Set(),
    });
    try {
      this.persist(input.workspaceId);
    } catch (error) {
      this.turns.delete(turn.id);
      this.items.delete(reference.id);
      this.itemRevisions.length = itemRevisionCount;
      this.streams.delete(turn.id);
      this.persist(input.workspaceId);
      throw error;
    }

    return {
      artifactId: artifact.id,
      artifactVersion: artifact.version,
      turnId: turn.id,
      itemId: reference.id,
    };
  }

  public listArtifacts(workspaceId: string): Artifact[] {
    return [...this.artifacts.values()].filter((artifact) => artifact.workspaceId === workspaceId);
  }

  public getArtifact(workspaceId: string, artifactId: string): Artifact {
    const artifact = this.artifacts.get(artifactId);

    if (!artifact || artifact.workspaceId !== workspaceId) {
      throw new StoreRecordNotFoundError(`Artifact not found: ${artifactId}`);
    }

    return artifact;
  }

  /** Verifies the exact original without materializing a file body or substituting another version. */
  public assertArtifactContent(artifact: Artifact): void {
    if (artifact.content.format === 'file') {
      if (!this.dataRoot) {
        throw new ArtifactAuthorityError(
          'recovery_required',
          'Artifact file storage is unavailable.'
        );
      }
      try {
        verifyArtifactFilePayload({
          workspaceRoot: this.workspaceRootPath(artifact.workspaceId),
          artifactId: artifact.id,
          version: artifact.version,
          byteLength: artifact.content.byteLength,
          contentDigest: artifact.contentDigest,
        });
      } catch {
        throw new ArtifactAuthorityError('recovery_required', 'The Artifact file is unavailable.');
      }
      return;
    }
    const digest = `sha256:${createHash('sha256').update(artifact.content.body, 'utf8').digest('hex')}`;
    if (digest !== artifact.contentDigest) {
      throw new ArtifactAuthorityError(
        'recovery_required',
        'Artifact content integrity is invalid.'
      );
    }
  }

  /**
   * Creates one deterministic immutable Knowledge Proposal awaiting review.
   *
   * @param input Validated proposal request and server-owned attribution.
   * @returns Stored knowledge proposal.
   */
  public createKnowledgeProposal(input: CreateKnowledgeProposalInput): KnowledgeProposalRecord {
    this.getWorkspace(input.workspaceId);
    let request: KnowledgeManagerDraftProposalRequest;
    let proposal: KnowledgeProposalRecord;
    try {
      request = KnowledgeManagerDraftProposalRequestSchema.parse({
        requestId: input.requestId,
        knowledgePageId: input.knowledgePageId,
        canonicalPageBytes: input.canonicalPageBytes,
        contentDigest: input.contentDigest,
        sourceReferences: input.sourceReferences,
        rationale: input.rationale,
        confidence: input.confidence,
      });
      proposal = KnowledgeProposalRecordSchema.parse({
        id: knowledgeAuthorityId('kp_', {
          workspaceId: input.workspaceId,
          requestId: request.requestId,
        }),
        workspaceId: input.workspaceId,
        operation: 'create',
        knowledgePageId: request.knowledgePageId,
        canonicalPageBytes: request.canonicalPageBytes,
        contentDigest: request.contentDigest,
        sourceReferences: request.sourceReferences,
        rationale: request.rationale,
        confidence: request.confidence,
        producer: input.producer,
        createdAt: input.createdAt,
      });
    } catch {
      throw new KnowledgePageValidationError();
    }

    const existing = this.knowledgeProposals.get(proposal.id);
    if (existing) {
      if (JSON.stringify(existing) !== JSON.stringify(proposal)) {
        throw knowledgeProposalAuthorityError('conflict');
      }
      this.verifiedKnowledgeProposalBytes(existing);
      return existing;
    }
    if (
      this.hasAcceptedKnowledgeProposalForPage(proposal.workspaceId, proposal.knowledgePageId) ||
      this.getWorkspaceResources(proposal.workspaceId).knowledge.some(
        (entry) => entry.id === proposal.knowledgePageId
      ) ||
      this.readKnowledgeProposalPage(proposal) !== null
    ) {
      throw knowledgeProposalAuthorityError('conflict');
    }
    this.assertValidKnowledgeProposal(proposal, input.verifiedExternalReferences);

    this.knowledgeProposals.set(proposal.id, proposal);
    try {
      this.persist(proposal.workspaceId);
    } catch (error) {
      this.knowledgeProposals.delete(proposal.id);
      throw error;
    }
    return proposal;
  }

  /**
   * Returns one app-local knowledge proposal.
   *
   * @param proposalId Proposal id to inspect.
   * @returns Stored proposal, or null.
   */
  public getKnowledgeProposal(proposalId: string): KnowledgeProposalRecord | null {
    return this.knowledgeProposals.get(proposalId) ?? null;
  }

  /**
   * Projects one immutable Proposal from exact durable authority for receipt replay.
   *
   * @param workspaceId Workspace that owns the proposal.
   * @param proposalId Exact immutable Proposal id to project.
   * @returns Existing Proposal after verifying its canonical file bytes.
   * @throws Error with recovery_required when the owner is missing or changed.
   */
  public projectKnowledgeProposalDraft(
    workspaceId: string,
    proposalId: string
  ): KnowledgeProposalRecord {
    const proposal = this.knowledgeProposals.get(proposalId);
    if (!proposal || proposal.workspaceId !== workspaceId) {
      throw knowledgeProposalAuthorityError('recovery_required');
    }
    this.verifiedKnowledgeProposalBytes(proposal);
    return proposal;
  }

  /**
   * Lists app-local knowledge proposals for one workspace.
   *
   * @param workspaceId Workspace that owns the proposals.
   * @returns Stored knowledge proposal records.
   */
  public listKnowledgeProposals(workspaceId: string): KnowledgeProposalRecord[] {
    this.getWorkspace(workspaceId);
    return [...this.knowledgeProposals.values()].filter(
      (proposal) => proposal.workspaceId === workspaceId
    );
  }

  /**
   * Appends one human decision and applies an accepted create-only proposal.
   *
   * @param input Authenticated append request.
   * @returns Stored review row and current application projection.
   */
  public recordKnowledgeProposalReviewDecision(
    input: RecordKnowledgeProposalReviewDecisionInput
  ): SubmitKnowledgeProposalDecisionResponse {
    const proposal = this.knowledgeProposals.get(input.proposalId);

    if (!proposal || proposal.workspaceId !== input.workspaceId) {
      throw knowledgeProposalAuthorityError('not_found');
    }
    let command: SubmitKnowledgeProposalDecisionRequest;
    try {
      command = SubmitKnowledgeProposalDecisionRequestSchema.parse({
        requestId: input.requestId,
        decision: input.decision,
      });
    } catch {
      throw knowledgeProposalAuthorityError('invalid_request');
    }

    const proposalBytes = this.verifiedKnowledgeProposalBytes(proposal);
    const proposalDigest = contentDigest(proposalBytes);
    const decisions = this.knowledgeProposalReviews.get(proposal.id) ?? [];
    const existing = decisions.find((review) => review.requestId === command.requestId);
    if (existing) {
      if (
        existing.decision !== command.decision ||
        JSON.stringify(existing.actor) !== JSON.stringify(input.actor)
      ) {
        throw knowledgeProposalAuthorityError('conflict');
      }
      this.verifiedKnowledgeProposalReview(proposal, existing.reviewId, proposalBytes);

      if (existing.decision === 'accepted') {
        const pageBytes = this.readKnowledgeProposalPage(proposal);
        if (pageBytes === null) {
          this.assertNoUnresolvedKnowledgeProposalConflict(proposal);
          const entry = this.assertValidKnowledgeProposal(
            proposal,
            input.verifiedExternalReferences
          );
          const resources = this.storedWorkspaceResources(proposal.workspaceId);
          const existingEntry = resources.knowledge.find(
            (candidate) => candidate.id === proposal.knowledgePageId
          );
          if (existingEntry && JSON.stringify(existingEntry) !== JSON.stringify(entry)) {
            throw knowledgeProposalAuthorityError('recovery_required');
          }
          if (!existingEntry) {
            this.workspaceResources.set(proposal.workspaceId, {
              ...resources,
              knowledge: [...resources.knowledge, entry],
            });
          }
          this.refreshWorkspaceCounts(proposal.workspaceId);
          this.persist(proposal.workspaceId);
        } else if (
          pageBytes !== proposal.canonicalPageBytes ||
          contentDigest(pageBytes) !== proposal.contentDigest
        ) {
          throw knowledgeProposalAuthorityError('recovery_required');
        }
      }

      return this.projectKnowledgeProposalDecision(proposal.workspaceId, existing.reviewId);
    }

    if (decisions.some((review) => review.decision !== 'deferred')) {
      throw knowledgeProposalAuthorityError('conflict');
    }

    const accepted = command.decision === 'accepted';
    if (accepted) {
      if (
        this.hasAcceptedKnowledgeProposalForPage(
          proposal.workspaceId,
          proposal.knowledgePageId,
          proposal.id
        )
      ) {
        throw knowledgeProposalAuthorityError('conflict');
      }
      this.assertNoUnresolvedKnowledgeProposalConflict(proposal);
    }
    const entry = accepted
      ? this.assertValidKnowledgeProposal(proposal, input.verifiedExternalReferences)
      : null;
    if (
      accepted &&
      (this.getWorkspaceResources(proposal.workspaceId).knowledge.some(
        (candidate) => candidate.id === proposal.knowledgePageId
      ) ||
        this.readKnowledgeProposalPage(proposal) !== null)
    ) {
      throw knowledgeProposalAuthorityError('conflict');
    }

    let review: KnowledgeProposalReviewRecord;
    try {
      review = KnowledgeProposalReviewSchema.parse({
        reviewId: deriveEntityId('kr', {
          ownerScope: { kind: 'workspace', workspaceId: proposal.workspaceId },
          proposalId: proposal.id,
          requestId: command.requestId,
        }),
        proposalId: proposal.id,
        workspaceId: proposal.workspaceId,
        requestId: command.requestId,
        decision: command.decision,
        actor: input.actor,
        proposalDigest,
        knowledgePageId: proposal.knowledgePageId,
        contentDigest: proposal.contentDigest,
        targetAbsentAtDecision: accepted ? true : null,
        decidedAt: input.decidedAt,
      });
    } catch {
      throw knowledgeProposalAuthorityError('invalid_request');
    }

    this.knowledgeProposalReviews.set(proposal.id, [...decisions, review]);
    let application: KnowledgeProposalApplication | null = null;
    if (accepted) {
      const resources = this.storedWorkspaceResources(proposal.workspaceId);
      this.workspaceResources.set(proposal.workspaceId, {
        ...resources,
        knowledge: [...resources.knowledge, entry!],
      });
      this.refreshWorkspaceCounts(proposal.workspaceId);
      application = {
        knowledgePageId: proposal.knowledgePageId,
        contentDigest: proposal.contentDigest,
        present: true,
      };
    }

    this.persist(proposal.workspaceId);
    return SubmitKnowledgeProposalDecisionResponseSchema.parse({ review, application });
  }

  /**
   * Projects one existing decision from exact durable owners without repairing effects.
   *
   * @param workspaceId Workspace that owns the decision.
   * @param reviewId Exact append-only Review row to project.
   * @returns Existing decision response derived from current durable authority.
   * @throws Error with recovery_required when any required owner is missing or changed.
   */
  public projectKnowledgeProposalDecision(
    workspaceId: string,
    reviewId: string
  ): SubmitKnowledgeProposalDecisionResponse {
    this.getWorkspace(workspaceId);
    const review = [...this.knowledgeProposalReviews.values()]
      .flat()
      .find(
        (candidate) => candidate.workspaceId === workspaceId && candidate.reviewId === reviewId
      );
    const proposal = review ? this.knowledgeProposals.get(review.proposalId) : null;
    if (!review || !proposal || proposal.workspaceId !== workspaceId) {
      throw knowledgeProposalAuthorityError('recovery_required');
    }
    const proposalBytes = this.verifiedKnowledgeProposalBytes(proposal);
    this.verifiedKnowledgeProposalReview(proposal, review.reviewId, proposalBytes);

    let application: KnowledgeProposalApplication | null = null;
    if (review.decision === 'accepted') {
      const pageBytes = this.readKnowledgeProposalPage(proposal);
      if (
        pageBytes === null ||
        pageBytes !== proposal.canonicalPageBytes ||
        contentDigest(pageBytes) !== proposal.contentDigest
      ) {
        throw knowledgeProposalAuthorityError('recovery_required');
      }
      application = {
        knowledgePageId: proposal.knowledgePageId,
        contentDigest: proposal.contentDigest,
        present: true,
      };
    }

    return SubmitKnowledgeProposalDecisionResponseSchema.parse({ review, application });
  }

  /**
   * Projects one exact accepted Proposal tuple into request-scoped reference proof.
   *
   * @param workspaceId Workspace that owns the Proposal, Review, and Page.
   * @param reviewId Exact accepted Review row.
   * @param verifiedExternalReferences Exact work-history references verified by their owners.
   * @returns Page-bound proof after every current owner is revalidated.
   * @throws Error when the accepted tuple or any source owner is absent or contradictory.
   */
  public projectKnowledgeProposalReferenceProof(
    workspaceId: string,
    reviewId: string,
    verifiedExternalReferences: readonly string[]
  ): KnowledgePageReferenceProof {
    const decision = this.projectKnowledgeProposalDecision(workspaceId, reviewId);
    const proposal = this.knowledgeProposals.get(decision.review.proposalId);
    if (decision.review.decision !== 'accepted' || !decision.application || !proposal) {
      throw knowledgeProposalAuthorityError('recovery_required');
    }
    this.assertValidKnowledgeProposal(proposal, verifiedExternalReferences);
    return {
      contentDigest: proposal.contentDigest,
      knowledgePageId: proposal.knowledgePageId,
      resolvedReferences: new Set(proposal.sourceReferences),
      sourceReferences: proposal.sourceReferences,
    };
  }

  /**
   * Projects one accepted portable-import Page into request-scoped reference proof.
   *
   * @param workspaceId Imported Workspace that owns the ordinary authoritative Page.
   * @param knowledgePageId Exact bundle-relative Page identity.
   * @param verifiedExternalReferences Exact reminted work-history references verified by S39.
   * @returns Page-bound proof after every current owner is revalidated.
   * @throws KnowledgePageValidationError when import lineage, Page bytes, or sources conflict.
   */
  public projectImportedKnowledgePageReferenceProof(
    workspaceId: string,
    knowledgePageId: string,
    verifiedExternalReferences: readonly string[]
  ): KnowledgePageReferenceProof {
    const workspace = this.getWorkspace(workspaceId);
    if (!workspace.importedFrom || !this.dataRoot) {
      throw new KnowledgePageValidationError();
    }

    let content: string | null;
    let workspaceSchemaText: string | undefined;
    try {
      const workspaceRoot = this.workspaceRootPath(workspaceId);
      content = readWorkspaceKnowledgePage(workspaceRoot, knowledgePageId);
      const schemaPath = join(workspaceRoot, 'knowledge', 'schema', 'workspace-schema.yaml');
      if (existsSync(schemaPath)) {
        workspaceSchemaText = readCanonicalTextFile(schemaPath);
      }
    } catch {
      throw new KnowledgePageValidationError();
    }
    if (!content) {
      throw new KnowledgePageValidationError();
    }

    const path = `knowledge/pages/${knowledgePageId}.md`;
    const parsed = parseOkfDocument({ path, content });
    const sourceReferences = parsed.document
      ? stringListFrontmatterField(parsed.document, 'source_refs')
      : null;
    if (
      !parsed.ok ||
      parsed.document.conceptId !== knowledgePageId ||
      parsed.document.frontmatter.openkit_entry_id !== knowledgePageId ||
      parsed.document.frontmatter.type !== 'KnowledgePage' ||
      parsed.document.frontmatter.openkit_status !== 'active' ||
      (parsed.document.frontmatter.status !== undefined &&
        parsed.document.frontmatter.status !== 'stable') ||
      parsed.document.frontmatter.review_state !== 'accepted' ||
      sourceReferences === null ||
      !KnowledgeManagerDraftProposalRequestSchema.shape.sourceReferences.safeParse(sourceReferences)
        .success
    ) {
      throw new KnowledgePageValidationError();
    }

    const resolvedReferences = this.resolveKnowledgePageSourceReferences(
      workspaceId,
      sourceReferences,
      verifiedExternalReferences
    );
    const report = validateKnowledgePageCandidate({
      path,
      content,
      ...(workspaceSchemaText === undefined ? {} : { workspaceSchemaText }),
      registeredSources: new Map(
        [...this.knowledgeSources.values()]
          .filter((source) => source.workspaceId === workspaceId)
          .map((source) => [source.id, source.contentDigest])
      ),
      knowledgeIds: new Set(
        this.getWorkspaceResources(workspaceId).knowledge.map((entry) => entry.id)
      ),
      resolvedReferences,
    });
    if (report.conformance !== 'Workspace-schema-valid' || report.errors.length > 0) {
      throw new KnowledgePageValidationError();
    }

    return {
      contentDigest: contentDigest(content),
      knowledgePageId,
      resolvedReferences,
      sourceReferences,
    };
  }

  /**
   * Returns the latest recorded decision for one Knowledge Proposal.
   *
   * @param proposalId Proposal id to inspect.
   * @returns Stored proposal review record, or null.
   */
  public getKnowledgeProposalReviewDecision(
    proposalId: string
  ): KnowledgeProposalReviewRecord | null {
    return this.knowledgeProposalReviews.get(proposalId)?.at(-1) ?? null;
  }

  /**
   * Lists app-local knowledge proposal review decisions for one workspace.
   *
   * @param workspaceId Workspace that owns the decisions.
   * @returns Stored proposal review records.
   */
  public listKnowledgeProposalReviewDecisions(
    workspaceId: string
  ): KnowledgeProposalReviewRecord[] {
    this.getWorkspace(workspaceId);
    return [...this.knowledgeProposalReviews.values()]
      .flat()
      .filter((review) => review.workspaceId === workspaceId);
  }

  /**
   * Removes one unchanged page created by an accepted Knowledge Proposal.
   *
   * @param input Exact proposal, accepted review, page, and digest tuple.
   * @returns Derived projection showing that the page is absent.
   */
  public reverseKnowledgeProposalApplication(
    input: ReverseKnowledgeProposalApplicationInput
  ): ReverseKnowledgeProposalResponse {
    const proposal = this.knowledgeProposals.get(input.proposalId);
    if (!proposal || proposal.workspaceId !== input.workspaceId) {
      throw knowledgeProposalAuthorityError('not_found');
    }
    const proposalBytes = this.verifiedKnowledgeProposalBytes(proposal);
    const review = this.verifiedKnowledgeProposalReview(proposal, input.reviewId, proposalBytes);
    if (
      review.decision !== 'accepted' ||
      review.knowledgePageId !== proposal.knowledgePageId ||
      review.contentDigest !== proposal.contentDigest ||
      input.knowledgePageId !== proposal.knowledgePageId ||
      input.expectedContentDigest !== proposal.contentDigest
    ) {
      throw knowledgeProposalAuthorityError('recovery_required');
    }

    const pageBytes = this.readKnowledgeProposalPage(proposal);
    if (pageBytes === null) {
      throw knowledgeProposalAuthorityError('recovery_required');
    }
    if (
      pageBytes !== proposal.canonicalPageBytes ||
      contentDigest(pageBytes) !== input.expectedContentDigest
    ) {
      throw knowledgeProposalAuthorityError('conflict');
    }

    if (this.dataRoot) {
      deleteWorkspaceKnowledgeRecord(
        this.workspaceRootPath(proposal.workspaceId),
        proposal.knowledgePageId
      );
    }
    const resources = this.storedWorkspaceResources(proposal.workspaceId);
    this.workspaceResources.set(proposal.workspaceId, {
      ...resources,
      knowledge: resources.knowledge.filter((entry) => entry.id !== proposal.knowledgePageId),
    });
    this.refreshWorkspaceCounts(proposal.workspaceId);
    this.persist(proposal.workspaceId);

    return this.projectKnowledgeProposalReversal(input);
  }

  /**
   * Projects one completed reversal from exact durable owners without repairing effects.
   *
   * @param input Exact proposal, accepted review, page, and digest tuple.
   * @returns Existing reversal response derived from current durable authority.
   * @throws Error with recovery_required when any required owner is missing or changed.
   */
  public projectKnowledgeProposalReversal(
    input: ReverseKnowledgeProposalApplicationInput
  ): ReverseKnowledgeProposalResponse {
    const proposal = this.knowledgeProposals.get(input.proposalId);
    if (!proposal || proposal.workspaceId !== input.workspaceId) {
      throw knowledgeProposalAuthorityError('recovery_required');
    }
    const proposalBytes = this.verifiedKnowledgeProposalBytes(proposal);
    const review = this.verifiedKnowledgeProposalReview(proposal, input.reviewId, proposalBytes);
    if (
      review.decision !== 'accepted' ||
      review.knowledgePageId !== proposal.knowledgePageId ||
      review.contentDigest !== proposal.contentDigest ||
      input.knowledgePageId !== proposal.knowledgePageId ||
      input.expectedContentDigest !== proposal.contentDigest ||
      this.readKnowledgeProposalPage(proposal) !== null
    ) {
      throw knowledgeProposalAuthorityError('recovery_required');
    }

    return ReverseKnowledgeProposalResponseSchema.parse({
      proposalId: proposal.id,
      reviewId: review.reviewId,
      application: {
        knowledgePageId: proposal.knowledgePageId,
        contentDigest: proposal.contentDigest,
        present: false,
      },
    });
  }

  /**
   * Creates one workspace source registry record.
   *
   * @param input Source identity record to store.
   * @param materialContent Optional captured source text to write beside the registry record.
   * @returns Stored source identity record.
   * @throws OperationError for invalid source lineage or an id owned by another Workspace.
   */
  public createKnowledgeSource(
    input: KnowledgeSourceRecord,
    materialContent?: string
  ): KnowledgeSourceRecord {
    this.getWorkspace(input.workspaceId);
    if (input.originatingThreadId !== null) {
      this.getThread(input.workspaceId, input.originatingThreadId);
    }
    if (input.originatingTurnId !== null) {
      if (input.originatingThreadId === null) {
        throw new OperationError(
          'knowledge_source_register_failed',
          `Knowledge source turn requires a thread: ${input.id}`,
          404
        );
      }
      this.getTurn(input.workspaceId, input.originatingThreadId, input.originatingTurnId);
    }

    const previous = this.knowledgeSources.get(input.id);
    if (previous && previous.workspaceId !== input.workspaceId) {
      throw new OperationError(
        'knowledge_source_register_failed',
        `Knowledge source id belongs to another workspace: ${input.id}`,
        404
      );
    }

    try {
      this.knowledgeSources.set(input.id, input);
      if (materialContent !== undefined) {
        this.writeKnowledgeSourceMaterial(input.workspaceId, input.id, materialContent);
      }
      this.persist(input.workspaceId);
    } catch (error) {
      if (previous) {
        this.knowledgeSources.set(input.id, previous);
      } else {
        this.knowledgeSources.delete(input.id);
      }
      throw error;
    }

    return input;
  }

  /**
   * Appends one workspace Knowledge Store observation to the monthly JSONL ledger.
   *
   * @param input Observation row to append.
   * @returns Stored observation row.
   */
  public recordKnowledgeObservation(input: KnowledgeObservation): KnowledgeObservation {
    this.getWorkspace(input.workspaceId);

    if (!this.dataRoot) {
      return input;
    }

    appendWorkspaceKnowledgeObservation(this.workspaceRootPath(input.workspaceId), input);

    return input;
  }

  /**
   * Returns one workspace Knowledge Store observation by id.
   *
   * @param workspaceId Workspace that owns the observation.
   * @param observationId Observation id.
   * @returns Stored observation row.
   */
  public getKnowledgeObservation(workspaceId: string, observationId: string): KnowledgeObservation {
    const observation = this.listKnowledgeObservations(workspaceId).find(
      (candidate) => candidate.id === observationId
    );

    if (!observation) {
      throw new StoreRecordNotFoundError(`Knowledge observation not found: ${observationId}`);
    }

    return observation;
  }

  /**
   * Lists workspace Knowledge Store observations from monthly JSONL ledgers.
   *
   * @param workspaceId Workspace that owns the observations.
   * @returns Stored observation rows.
   */
  public listKnowledgeObservations(workspaceId: string): KnowledgeObservation[] {
    this.getWorkspace(workspaceId);

    if (!this.dataRoot) {
      return [];
    }

    return [...readWorkspaceKnowledgeObservationLedger(this.workspaceRootPath(workspaceId), true)]
      .sort(([left], [right]) => left.localeCompare(right))
      .flatMap(([, rows]) => rows);
  }

  /**
   * Appends one workspace Knowledge Store claim to the monthly JSONL ledger.
   *
   * @param input Claim row to append.
   * @returns Stored claim row.
   */
  public recordKnowledgeClaim(input: KnowledgeClaim): KnowledgeClaim {
    this.getWorkspace(input.workspaceId);

    if (!this.dataRoot) {
      return input;
    }

    appendWorkspaceKnowledgeClaim(this.workspaceRootPath(input.workspaceId), input);

    return input;
  }

  /**
   * Returns one workspace Knowledge Store claim by id.
   *
   * @param workspaceId Workspace that owns the claim.
   * @param claimId Claim id.
   * @returns Stored claim row.
   */
  public getKnowledgeClaim(workspaceId: string, claimId: string): KnowledgeClaim {
    const claim = this.listKnowledgeClaims(workspaceId).find(
      (candidate) => candidate.id === claimId
    );

    if (!claim) {
      throw new StoreRecordNotFoundError(`Knowledge claim not found: ${claimId}`);
    }

    return claim;
  }

  /**
   * Lists workspace Knowledge Store claims from monthly JSONL ledgers.
   *
   * @param workspaceId Workspace that owns the claims.
   * @returns Stored claim rows.
   */
  public listKnowledgeClaims(workspaceId: string): KnowledgeClaim[] {
    this.getWorkspace(workspaceId);

    if (!this.dataRoot) {
      return [];
    }

    return [...readWorkspaceKnowledgeClaimLedger(this.workspaceRootPath(workspaceId), true)]
      .sort(([left], [right]) => left.localeCompare(right))
      .flatMap(([, rows]) => rows);
  }

  /**
   * Appends one workspace Knowledge Store conflict to the monthly JSONL ledger.
   *
   * @param input Conflict row to append.
   * @returns Stored conflict row.
   */
  public recordKnowledgeConflict(input: KnowledgeConflict): KnowledgeConflict {
    this.getWorkspace(input.workspaceId);

    if (!this.dataRoot) {
      return input;
    }

    appendWorkspaceKnowledgeConflict(this.workspaceRootPath(input.workspaceId), input);

    return input;
  }

  /**
   * Appends one resolution update for an existing workspace Knowledge Store conflict.
   *
   * @param input Conflict resolution input.
   * @returns Latest conflict row after resolution.
   */
  public resolveKnowledgeConflict(input: ResolveKnowledgeConflictInput): KnowledgeConflict {
    const current = this.getKnowledgeConflict(input.workspaceId, input.conflictId);
    const resolved: KnowledgeConflict = {
      ...current,
      status: input.status,
      resolution: input.resolution,
      resolvedAt: input.resolvedAt,
      resolvedBy: input.resolvedBy,
      updatedAt: input.resolvedAt,
    };

    if (!this.dataRoot) {
      return resolved;
    }

    appendWorkspaceKnowledgeConflict(this.workspaceRootPath(input.workspaceId), resolved);

    return resolved;
  }

  /**
   * Returns one workspace Knowledge Store conflict by id.
   *
   * @param workspaceId Workspace that owns the conflict.
   * @param conflictId Conflict id.
   * @returns Stored conflict row.
   */
  public getKnowledgeConflict(workspaceId: string, conflictId: string): KnowledgeConflict {
    const conflict = this.listKnowledgeConflicts(workspaceId).find(
      (candidate) => candidate.id === conflictId
    );

    if (!conflict) {
      throw new StoreRecordNotFoundError(`Knowledge conflict not found: ${conflictId}`);
    }

    return conflict;
  }

  /**
   * Lists workspace Knowledge Store conflicts from monthly JSONL ledgers.
   *
   * @param workspaceId Workspace that owns the conflicts.
   * @returns Stored conflict rows.
   */
  public listKnowledgeConflicts(workspaceId: string): KnowledgeConflict[] {
    this.getWorkspace(workspaceId);

    if (!this.dataRoot) {
      return [];
    }

    const rows = [
      ...readWorkspaceKnowledgeConflictLedger(this.workspaceRootPath(workspaceId), true),
    ]
      .sort(([left], [right]) => left.localeCompare(right))
      .flatMap(([, revisions]) => revisions);
    const latestById = new Map<string, KnowledgeConflict>();

    for (const row of rows) {
      latestById.set(row.id, row);
    }

    return [...latestById.values()];
  }

  /**
   * Returns one workspace source registry record.
   *
   * @param workspaceId Workspace that owns the source.
   * @param sourceId Source id to return.
   * @returns Stored source identity record.
   */
  public getKnowledgeSource(workspaceId: string, sourceId: string): KnowledgeSourceRecord {
    const source = this.knowledgeSources.get(sourceId);

    if (!source || source.workspaceId !== workspaceId) {
      throw new StoreRecordNotFoundError(`Knowledge source not found: ${sourceId}`);
    }

    return source;
  }

  /**
   * Lists source registry records for one workspace.
   *
   * @param workspaceId Workspace that owns the sources.
   * @returns Stored source identity records.
   */
  public listKnowledgeSources(workspaceId: string): KnowledgeSourceRecord[] {
    this.getWorkspace(workspaceId);
    return [...this.knowledgeSources.values()].filter(
      (source) => source.workspaceId === workspaceId
    );
  }

  /**
   * Reads captured text material for one workspace source.
   *
   * @param workspaceId Workspace that owns the source.
   * @param sourceId Source id whose material should be returned.
   * @returns Captured source text, or null when no material file exists.
   */
  public readKnowledgeSourceMaterial(workspaceId: string, sourceId: string): string | null {
    this.getKnowledgeSource(workspaceId, sourceId);

    if (!this.dataRoot) {
      return null;
    }

    const path = this.knowledgeSourceMaterialPath(workspaceId, sourceId);

    return lstatSync(path, { throwIfNoEntry: false }) ? readCanonicalTextFile(path) : null;
  }

  /**
   * Lists captured text materials for all sources in one workspace.
   *
   * @param workspaceId Workspace that owns the source materials.
   * @returns Captured source text materials.
   */
  public listKnowledgeSourceMaterials(workspaceId: string): KnowledgeSourceMaterialRecord[] {
    return this.listKnowledgeSources(workspaceId)
      .map((source) => ({
        sourceId: source.id,
        content: this.readKnowledgeSourceMaterial(workspaceId, source.id),
      }))
      .filter((material): material is KnowledgeSourceMaterialRecord => material.content !== null);
  }

  /**
   * Lists derived representation metadata for one source or workspace.
   *
   * @param workspaceId Workspace that owns the source.
   * @param sourceId Optional source id to filter.
   * @returns Derived representation records.
   */
  public listKnowledgeSourceDerivedRepresentations(
    workspaceId: string,
    sourceId?: string
  ): KnowledgeSourceDerivedRepresentationRecord[] {
    const sources = sourceId
      ? [this.getKnowledgeSource(workspaceId, sourceId)]
      : this.listKnowledgeSources(workspaceId);

    return sources.flatMap((source) => {
      if (!this.dataRoot) {
        return [];
      }

      const path = this.knowledgeSourceDerivedRepresentationPath(source.workspaceId, source.id);

      return lstatSync(path, { throwIfNoEntry: false })
        ? [JSON.parse(readCanonicalTextFile(path)) as KnowledgeSourceDerivedRepresentationRecord]
        : [];
    });
  }

  /**
   * Writes captured text material for one workspace source.
   *
   * @param workspaceId Workspace that owns the source.
   * @param sourceId Source id whose material should be written.
   * @param content Captured source text.
   */
  private writeKnowledgeSourceMaterial(
    workspaceId: string,
    sourceId: string,
    content: string
  ): void {
    this.getKnowledgeSource(workspaceId, sourceId);

    if (!this.dataRoot) {
      return;
    }

    const path = this.knowledgeSourceMaterialPath(workspaceId, sourceId);
    const source = this.getKnowledgeSource(workspaceId, sourceId);

    mkdirSync(dirname(path), { recursive: true });
    assertCanonicalDirectory(dirname(path));
    writeFileSync(path, content);
    this.writeKnowledgeSourceDerivedRepresentation(this.workspaceRootPath(workspaceId), source);
  }

  /**
   * Writes imported captured text materials under a staged workspace root.
   *
   * @param workspaceRoot Staged workspace root.
   * @param materials Captured source text materials to publish.
   */
  private writeKnowledgeSourceMaterialsToRoot(
    workspaceRoot: string,
    materials: readonly KnowledgeSourceMaterialRecord[],
    sources: readonly KnowledgeSourceRecord[] = []
  ): void {
    const sourcesById = new Map(sources.map((source) => [source.id, source]));

    for (const material of materials) {
      assertSafeWorkspacePathSegment(material.sourceId, 'Knowledge source id');
      const path = join(workspaceRoot, 'sources', 'materials', material.sourceId, 'content.txt');
      const source = sourcesById.get(material.sourceId);

      mkdirSync(dirname(path), { recursive: true });
      assertCanonicalDirectory(dirname(path));
      writeFileSync(path, material.content);
      if (source) {
        this.writeKnowledgeSourceDerivedRepresentation(workspaceRoot, source);
      }
    }
  }

  /**
   * Returns the durable text material path for one workspace source.
   *
   * @param workspaceId Workspace that owns the source.
   * @param sourceId Source id whose material path should be returned.
   * @returns Workspace-root-relative source material file path.
   */
  private knowledgeSourceMaterialPath(workspaceId: string, sourceId: string): string {
    assertSafeWorkspacePathSegment(sourceId, 'Knowledge source id');
    return join(
      this.workspaceRootPath(workspaceId),
      'sources',
      'materials',
      sourceId,
      'content.txt'
    );
  }

  /**
   * Writes derived text representation metadata for one source.
   *
   * @param workspaceRoot Workspace root path.
   * @param source Source identity record.
   */
  private writeKnowledgeSourceDerivedRepresentation(
    workspaceRoot: string,
    source: KnowledgeSourceRecord
  ): void {
    assertSafeWorkspacePathSegment(source.id, 'Knowledge source id');
    const path = join(workspaceRoot, 'sources', 'derived', source.id, 'text.json');
    const record: KnowledgeSourceDerivedRepresentationRecord = {
      id: `${source.id}:text`,
      workspaceId: source.workspaceId,
      sourceId: source.id,
      kind: 'text',
      path: `sources/derived/${source.id}/text.json`,
      materialPath: `sources/materials/${source.id}/content.txt`,
      contentDigest: source.contentDigest,
      sourceContentDigest: source.contentDigest,
      createdAt: source.createdAt,
    };

    mkdirSync(dirname(path), { recursive: true });
    assertCanonicalDirectory(dirname(path));
    writeFileSync(path, `${JSON.stringify(record, null, 2)}\n`);
  }

  /**
   * Returns the durable derived text representation metadata path for one source.
   *
   * @param workspaceId Workspace that owns the source.
   * @param sourceId Source id whose derived metadata path should be returned.
   * @returns Derived metadata path.
   */
  private knowledgeSourceDerivedRepresentationPath(workspaceId: string, sourceId: string): string {
    assertSafeWorkspacePathSegment(sourceId, 'Knowledge source id');
    return join(this.workspaceRootPath(workspaceId), 'sources', 'derived', sourceId, 'text.json');
  }

  /**
   * Emits one Turn event, admitting completion of an already-decided terminal event after the Turn is sealed.
   *
   * @param turnId Turn whose stream receives the event.
   * @param event Event payload without protocol envelope fields.
   * @param admission Declared post-terminal category when the Turn is already sealed.
   * @returns Stored envelope.
   * @throws Error when the stream is missing, lineage is invalid, or a post-terminal write is not admitted.
   */
  public emitTurnEvent(
    turnId: string,
    event: TurnEventInput,
    admission?: TerminalTurnWriteAdmission
  ): SseEventEnvelope {
    const stream = this.streams.get(turnId);

    if (!stream) {
      throw new StoreRecordNotFoundError(`Turn stream not found: ${turnId}`);
    }

    const turn = this.getTurnById(turnId);
    const projectedRequestId = projectTurnEventRequestId(
      event.requestId,
      event.workspaceId,
      event.threadId
    );
    if (isSealedTurnTerminal(turn.status)) {
      const existingIdentical = stream.events.find(
        (candidate) =>
          candidate.event === event.event &&
          candidate.workspaceId === event.workspaceId &&
          candidate.threadId === event.threadId &&
          candidate.turnId === event.turnId &&
          candidate.requestId === projectedRequestId &&
          alreadyDecidedPublicationBytesEqual(candidate.data, event.data)
      );
      if (existingIdentical) {
        return existingIdentical;
      }
      if (eventConflictsWithSealedTurnOutcome(turn, event)) {
        throw terminalTurnPublicationConflict(turn.id);
      }
      if (
        admission?.category !== 'already-decided-publication' &&
        !eventAgreesWithSealedTurnOutcome(turn, event)
      ) {
        throw terminalTurnWriteRejected(turn.id);
      }
    }

    const envelope = SseEventEnvelopeSchema.parse({
      ...event,
      protocolVersion: PROTOCOL_VERSION,
      requestId: projectedRequestId,
      sequence: stream.sequence + 1,
      timestamp: now(),
    });

    if (
      envelope.workspaceId !== turn.workspaceId ||
      envelope.threadId !== turn.threadId ||
      envelope.turnId !== turn.id
    ) {
      throw new Error(`Turn event ${envelope.event} has invalid lineage for ${turnId}.`);
    }
    assertTurnEventPayloadLineage(
      envelope,
      turn.workspaceId,
      turn.threadId,
      turn.id,
      new Set(turn.items.map((item) => item.id))
    );
    if (this.dataRoot) {
      appendWorkspaceTurnEvent(this.workspaceRootPath(envelope.workspaceId), envelope);
    }
    stream.sequence = envelope.sequence;
    stream.events.push(envelope);
    if (stream.events.length > TURN_STREAM_EVENT_WINDOW_SIZE) {
      stream.events.shift();
    }
    for (const listener of stream.listeners) {
      listener(envelope);
    }
    return envelope;
  }

  public addTurnListener(turnId: string, listener: EventListener): () => void {
    const stream = this.streams.get(turnId);

    if (!stream) {
      throw new StoreRecordNotFoundError(`Turn stream not found: ${turnId}`);
    }

    stream.listeners.add(listener);

    return () => {
      stream.listeners.delete(listener);
    };
  }

  public getTurnEvents(turnId: string): SseEventEnvelope[] {
    return this.streams.get(turnId)?.events ?? [];
  }

  /**
   * Returns the complete durable event history used by workspace export.
   *
   * @param turnId Turn whose event log should be exported.
   * @returns Full canonical history, or the in-memory history when persistence is disabled.
   */
  public getTurnEventsForExport(turnId: string): SseEventEnvelope[] {
    const turn = this.getTurnById(turnId);
    return this.dataRoot
      ? readWorkspaceTurnEvents(this.workspaceRootPath(turn.workspaceId), turn)
      : this.getTurnEvents(turnId);
  }

  public addTimer(turnId: string, timer: NodeJS.Timeout): void {
    this.streams.get(turnId)?.timers.add(timer);
  }

  public clearTimers(turnId: string): void {
    const timers = this.streams.get(turnId)?.timers;

    if (!timers) {
      return;
    }

    for (const timer of timers) {
      clearTimeout(timer);
    }
    timers.clear();
  }
}
