import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { basename, dirname, join } from 'node:path';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { workObservationBodyBundleId } from '../evidence-bundles.js';
import { withTurnModelCapture } from '../llm/model-capture.js';
import { openWorkspaceDb } from '../storage/db.js';
import { applyScopedMigrations } from '../storage/migrate.js';
import { appendWorkObservation, readWorkObservations } from '../storage/work-observations.js';
import { createDemoStore } from '../test-support/demo-store.js';
import { DEFAULT_CAPTURE_COVERAGE_BINDING, FsStore } from './store.js';

// Fault the armed Turn manifest's durable synchronization.
// A new Turn is written under workspaces/.staging/record-* and published by one rename,
// so the file fault is that temporary turn.json fsync. The directory fault is only the
// directory explicitly armed for the case: the canonical turns/ parent after the rename
// for admission, once turn.json is visible. An existing Turn is rewritten in place, so
// the observation cases arm that Turn directory and no parent or child can satisfy it.
const syncFailure = vi.hoisted(() => ({
  target: null as string | null,
  /** Exact directory whose synchronization is armed by this case. */
  directoryTarget: null as string | null,
  stage: 'file' as 'file' | 'directory',
  failures: 0,
  descriptors: new Map<number, string>(),
}));
vi.mock('node:fs', async (importOriginal) => {
  const actual = await importOriginal<typeof import('node:fs')>();

  /** Returns the workspaces directory that contains one canonical turn.json path. */
  const workspacesRoot = (turnJsonPath: string): string | null => {
    const turnDirectory = dirname(turnJsonPath);
    const turnsDirectory = dirname(turnDirectory);
    const threadDirectory = dirname(turnsDirectory);
    const threadsDirectory = dirname(threadDirectory);
    const workspaceDirectory = dirname(threadsDirectory);
    const workspacesDirectory = dirname(workspaceDirectory);
    if (
      basename(turnJsonPath) !== 'turn.json' ||
      basename(turnsDirectory) !== 'turns' ||
      basename(threadsDirectory) !== 'threads' ||
      basename(workspacesDirectory) !== 'workspaces'
    ) {
      return null;
    }
    return workspacesDirectory;
  };

  /** Returns whether a staged temporary turn.json body is the armed Turn. */
  const stagedBodyIsTurn = (path: string, turnId: string): boolean => {
    try {
      const parsed: unknown = JSON.parse(actual.readFileSync(path, 'utf8'));
      return (
        typeof parsed === 'object' &&
        parsed !== null &&
        'id' in parsed &&
        (parsed as { id?: unknown }).id === turnId
      );
    } catch {
      return false;
    }
  };

  /**
   * Selects the temporary turn.json fsync for the armed Turn.
   *
   * @param path Opened temporary file.
   * @param target Canonical turn.json path armed by the test.
   */
  const isArmedTurnManifestTemp = (path: string, target: string): boolean => {
    if (!basename(path).startsWith('.turn.json.')) return false;
    if (dirname(path) === dirname(target)) return true;
    const recordDirectory = dirname(path);
    const stagingDirectory = dirname(recordDirectory);
    return (
      basename(stagingDirectory) === '.staging' &&
      basename(recordDirectory).startsWith('record-') &&
      dirname(stagingDirectory) === workspacesRoot(target) &&
      stagedBodyIsTurn(path, basename(dirname(target)))
    );
  };

  /**
   * Selects only the directory explicitly armed for this case.
   *
   * @param path Opened directory.
   * @param target Canonical turn.json path armed by the test.
   */
  const isArmedTurnDirectorySync = (path: string, target: string): boolean => {
    return path === syncFailure.directoryTarget && actual.existsSync(target);
  };

  const openSync: typeof actual.openSync = (path, flags, mode) => {
    const descriptor = actual.openSync(path, flags, mode);
    syncFailure.descriptors.set(descriptor, String(path));
    return descriptor;
  };
  const closeSync: typeof actual.closeSync = (descriptor) => {
    syncFailure.descriptors.delete(descriptor);
    actual.closeSync(descriptor);
  };
  const fsyncSync: typeof actual.fsyncSync = (descriptor) => {
    const path = syncFailure.descriptors.get(descriptor);
    const target = syncFailure.target;
    if (
      target &&
      path &&
      (syncFailure.stage === 'file'
        ? isArmedTurnManifestTemp(path, target)
        : isArmedTurnDirectorySync(path, target))
    ) {
      syncFailure.failures += 1;
      throw new Error(`injected Turn manifest ${syncFailure.stage} sync failure`);
    }
    actual.fsyncSync(descriptor);
  };
  return { ...actual, openSync, closeSync, fsyncSync };
});

const syncFailureRoots: string[] = [];
afterEach(() => {
  syncFailure.target = null;
  syncFailure.directoryTarget = null;
  syncFailure.failures = 0;
  for (const root of syncFailureRoots.splice(0)) rmSync(root, { recursive: true, force: true });
});

const LOCAL_ACTOR = { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' } as const;

describe('Turn capture coverage binding', () => {
  it.each([
    'file',
    'directory',
  ] as const)('blocks governed collection when admission coverage %s sync fails', async (stage) => {
    const dataRoot = mkdtempSync(join(tmpdir(), 'openkit-capture-sync-'));
    syncFailureRoots.push(dataRoot);
    const store = createDemoStore({ dataRoot });
    store.setLiveCaptureCoverage({ scope: 'server', value: 'on' });
    const thread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Capture sync failure'
    );
    const turnId = 'tu_00000000-0000-7a17-81b3-4a0efca762bc';
    const turnPath = join(
      dataRoot,
      'workspaces',
      'ws_00000000-0000-7000-8000-000000000001',
      'threads',
      thread.id,
      'turns',
      turnId,
      'turn.json'
    );
    syncFailure.target = turnPath;
    syncFailure.directoryTarget = dirname(dirname(turnPath));
    syncFailure.stage = stage;
    const collect = vi.fn(async () => undefined);

    await expect(
      (async () => {
        const turn = store.createTurn(
          'ws_00000000-0000-7000-8000-000000000001',
          thread.id,
          'Must not collect',
          LOCAL_ACTOR,
          null,
          {
            turnId,
          }
        );
        await withTurnModelCapture({ store, turn }, collect);
      })()
    ).rejects.toThrow(`injected Turn manifest ${stage} sync failure`);
    expect(syncFailure.failures).toBe(1);
    expect(collect).not.toHaveBeenCalled();
    // A rename may be visible after directory-sync failure; visibility is not admission ACK.
    expect(existsSync(turnPath)).toBe(stage === 'directory');
    expect(existsSync(join(dirname(turnPath), 'observations.jsonl'))).toBe(false);
  });

  it.each([
    'file',
    'directory',
  ] as const)('retains no observation or body when required Turn manifest %s sync fails', (stage) => {
    const dataRoot = mkdtempSync(join(tmpdir(), 'openkit-capture-manifest-sync-'));
    syncFailureRoots.push(dataRoot);
    const store = createDemoStore({ dataRoot });
    const thread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Manifest sync failure'
    );
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Admitted',
      LOCAL_ACTOR,
      null,
      {
        captureCoverage: { scope: 'server', value: 'on' },
      }
    );
    const turnRoot = join(
      dataRoot,
      'workspaces',
      'ws_00000000-0000-7000-8000-000000000001',
      'threads',
      thread.id,
      'turns',
      turn.id
    );
    const db = openWorkspaceDb(dataRoot, 'ws_00000000-0000-7000-8000-000000000001');
    try {
      applyScopedMigrations(db);
      syncFailure.target = join(turnRoot, 'turn.json');
      syncFailure.directoryTarget = turnRoot;
      syncFailure.stage = stage;
      expect(() =>
        appendWorkObservation(db, {
          threadId: thread.id,
          turnId: turn.id,
          observation: {
            id: 'blocked-observation',
            type: 'model.observed',
            ts: '2026-09-29T00:00:00.000Z',
            obs: 'gateway',
            payload: {
              attempt: 0,
              direction: 'response',
              event: 'text_end',
              runtimeOriginRef: null,
              content: { state: 'expected' },
            },
          },
          bodies: [
            {
              id: 'semantic',
              bytes: Buffer.from('Must not be retained'),
              mediaType: 'text/plain',
              boundary: 'test-semantic-v1',
            },
          ],
        })
      ).toThrow(`injected Turn manifest ${stage} sync failure`);
      expect(syncFailure.failures).toBe(1);
      expect(readWorkObservations(db, { threadId: thread.id, turnId: turn.id })).toEqual([]);
      expect(db.sqlite.prepare('SELECT COUNT(*) AS count FROM evidence_bundles').get()).toEqual({
        count: 0,
      });
      const bundleId = workObservationBodyBundleId(
        'ws_00000000-0000-7000-8000-000000000001',
        thread.id,
        turn.id,
        'blocked-observation',
        'semantic'
      );
      expect(
        existsSync(
          join(
            dataRoot,
            'workspaces',
            'ws_00000000-0000-7000-8000-000000000001',
            'evidence',
            'backend',
            bundleId,
            'raw',
            'content'
          )
        )
      ).toBe(false);
      expect(existsSync(join(turnRoot, 'observations.jsonl'))).toBe(false);
    } finally {
      syncFailure.target = null;
      db.sqlite.close();
    }
  });

  it('records the off pair at admission by default', () => {
    const store = createDemoStore();
    const thread = store.createThread('ws_00000000-0000-7000-8000-000000000001', 'Capture off');
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Default off',
      LOCAL_ACTOR
    );

    expect(store.getTurnCaptureCoverage(turn.id)).toEqual(DEFAULT_CAPTURE_COVERAGE_BINDING);
    expect(store.getLiveCaptureCoverage()).toEqual({ scope: 'server', value: 'off' });
  });

  it('records the on pair when the live switch is on at admission', () => {
    const store = createDemoStore();
    store.setLiveCaptureCoverage({ scope: 'workspace', value: 'on' });
    const thread = store.createThread('ws_00000000-0000-7000-8000-000000000001', 'Capture on');
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Switch on',
      LOCAL_ACTOR
    );

    expect(store.getTurnCaptureCoverage(turn.id)).toEqual({ scope: 'workspace', value: 'on' });
  });

  it('keeps a running Turn pair unchanged and does not interrupt when the live switch changes', () => {
    const store = createDemoStore();
    const thread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Capture mid-turn'
    );
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Keep historical pair',
      LOCAL_ACTOR
    );
    store.setLiveCaptureCoverage({ scope: 'server', value: 'on' });

    expect(store.getTurnById(turn.id).status).toBe('running');
    expect(store.getTurnCaptureCoverage(turn.id)).toEqual(DEFAULT_CAPTURE_COVERAGE_BINDING);
    const next = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Next turn sees the new pair',
      LOCAL_ACTOR
    );
    expect(store.getTurnCaptureCoverage(next.id)).toEqual({ scope: 'server', value: 'on' });
    expect(store.getTurnById(turn.id).status).toBe('running');
  });

  it('reads the recorded pair back from turn.json after restart', () => {
    const dataRoot = mkdtempSync(join(tmpdir(), 'openkit-capture-coverage-'));
    const store = createDemoStore({ dataRoot });
    store.setLiveCaptureCoverage({ scope: 'task', value: 'on' });
    const thread = store.createThread('ws_00000000-0000-7000-8000-000000000001', 'Capture restart');
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Persist the pair',
      LOCAL_ACTOR
    );
    const turnPath = join(
      dataRoot,
      'workspaces',
      'ws_00000000-0000-7000-8000-000000000001',
      'threads',
      thread.id,
      'turns',
      turn.id,
      'turn.json'
    );
    const recorded = JSON.parse(readFileSync(turnPath, 'utf8')) as {
      captureCoverage?: { scope: string; value: string };
      items: unknown[];
    };
    expect(recorded.items).toEqual([]);
    expect(recorded.captureCoverage).toEqual({ scope: 'task', value: 'on' });

    const reloaded = new FsStore({ dataRoot });
    expect(reloaded.getTurnCaptureCoverage(turn.id)).toEqual({ scope: 'task', value: 'on' });
    expect(reloaded.getTurnById(turn.id).status).toBe('running');
  });

  it('records on from server.jsonc policy.workDataCapture at the next admitted Turn', () => {
    const dataRoot = mkdtempSync(join(tmpdir(), 'openkit-capture-config-on-'));
    mkdirSync(join(dataRoot, 'config'), { recursive: true });
    writeFileSync(
      join(dataRoot, 'config', 'server.jsonc'),
      JSON.stringify({
        schemaVersion: 1,
        policy: { workDataCapture: { value: 'on' } },
      })
    );
    const store = createDemoStore({ dataRoot });
    const thread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Configured capture'
    );
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Operator switch on',
      LOCAL_ACTOR
    );

    expect(store.getTurnCaptureCoverage(turn.id)).toEqual({ scope: 'server', value: 'on' });
  });
});
