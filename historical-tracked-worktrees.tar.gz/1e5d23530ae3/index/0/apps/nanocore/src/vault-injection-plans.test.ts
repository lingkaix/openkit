import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterEach, describe, expect, it } from 'vitest';
import { type CoreDb, openCoreDb } from './storage/db.js';
import { applyMigrations } from './storage/migrate.js';
import {
  createVaultGrant,
  getVaultGrant,
  importWorkspaceVaultGrants,
  revokeVaultGrant,
} from './vault/vault-grants.js';
import { createVaultReference } from './vault/vault-references.js';
import {
  createVaultInjectionPlan,
  getVaultInjectionPlan,
  listVaultInjectionPlans,
} from './vault-injection-plans.js';

const fixtureRoots = new Set<string>();
afterEach(() => {
  for (const root of fixtureRoots) rmSync(root, { recursive: true, force: true });
  fixtureRoots.clear();
});

/**
 * Opens a migrated Core database for injection plan tests.
 *
 * @returns Migrated Core database handle.
 */
function createCoreDb(): CoreDb {
  const dataRoot = mkdtempSync(join(tmpdir(), 'openkit-injection-plan-'));
  fixtureRoots.add(dataRoot);
  const coreDb = openCoreDb(dataRoot);
  applyMigrations(coreDb);
  return coreDb;
}

describe('injection plans', () => {
  it('creates, reads, and lists non-secret runtime-file injection plans', () => {
    const coreDb = createCoreDb();

    try {
      createGrant(coreDb);

      const created = createVaultInjectionPlan(coreDb, {
        backendCapabilityRequirement: 'encrypted-file:resolve',
        capabilityId: 'mcp.github.call_tool',
        expirationBehavior: 'delete-on-turn-end',
        grantId: 'grant_00000000-0000-7502-bb07-4104daba6c66',
        injectionVisibility: 'runtime-file',
        now: () => '2026-07-05T00:10:00.000Z',
        packageSnapshotId: 'aep_1',
        planId: 'plan_github_file',
        redactionRule: 'path-only',
        revocationBehavior: 'mark-session-stale',
        targetPath: '/openkit/secrets/github-token',
      });
      const duplicate = createVaultInjectionPlan(coreDb, {
        ...created,
        now: () => '2026-07-05T00:20:00.000Z',
      });
      expect(duplicate).toEqual(created);
      for (const patch of [
        { backendCapabilityRequirement: 'changed' },
        { capabilityId: null },
        { expirationBehavior: 'grant-lifetime' },
        { packageSnapshotId: null },
        { redactionRule: 'changed' },
        { revocationBehavior: 'changed' },
        { targetPath: '/openkit/secrets/changed' },
        { injectionVisibility: 'runtime-env', targetPath: null, targetEnvVarName: 'SERVICE_TOKEN' },
        { injectionVisibility: 'gateway-only', targetPath: null },
      ] as const) {
        expect(() => createVaultInjectionPlan(coreDb, { ...created, ...patch })).toThrow(
          'Vault injection plan identity conflict.'
        );
        expect(listVaultInjectionPlans(coreDb)).toEqual([created]);
      }

      expect(getVaultInjectionPlan(coreDb, 'plan_github_file')).toEqual(created);
      expect(listVaultInjectionPlans(coreDb)).toEqual([created]);
      expect(created).toMatchObject({
        backendCapabilityRequirement: 'encrypted-file:resolve',
        capabilityId: 'mcp.github.call_tool',
        expirationBehavior: 'delete-on-turn-end',
        grantId: 'grant_00000000-0000-7502-bb07-4104daba6c66',
        injectionVisibility: 'runtime-file',
        packageSnapshotId: 'aep_1',
        planId: 'plan_github_file',
        redactionRule: 'path-only',
        revocationBehavior: 'mark-session-stale',
        status: 'active',
        targetPath: '/openkit/secrets/github-token',
      });
      expect(JSON.stringify(created)).not.toContain('ghp_');
      revokeVaultGrant(coreDb, { grantId: created.grantId });
      const revoked = getVaultInjectionPlan(coreDb, created.planId);
      expect(revoked?.status).toBe('revoked');
      expect(createVaultInjectionPlan(coreDb, { ...created })).toEqual(revoked);
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('requires an existing grant and visibility-specific targets', () => {
    const coreDb = createCoreDb();

    try {
      expect(() =>
        createVaultInjectionPlan(coreDb, {
          backendCapabilityRequirement: 'encrypted-file:resolve',
          expirationBehavior: 'delete-on-turn-end',
          grantId: 'grant_00000000-0000-7278-b714-46e2d53cb316',
          injectionVisibility: 'gateway-only',
          planId: 'plan_missing',
          redactionRule: 'status-only',
          revocationBehavior: 'deny-new-use',
        })
      ).toThrow('Vault grant not found: grant_00000000-0000-7278-b714-46e2d53cb316');

      createGrant(coreDb);

      expect(() =>
        createVaultInjectionPlan(coreDb, {
          backendCapabilityRequirement: 'encrypted-file:resolve',
          expirationBehavior: 'delete-on-turn-end',
          grantId: 'grant_00000000-0000-7502-bb07-4104daba6c66',
          injectionVisibility: 'runtime-file',
          planId: 'plan_missing_path',
          redactionRule: 'path-only',
          revocationBehavior: 'mark-session-stale',
        })
      ).toThrow('Runtime-file injection plans require targetPath.');
      expect(() =>
        createVaultInjectionPlan(coreDb, {
          backendCapabilityRequirement: 'encrypted-file:resolve',
          expirationBehavior: 'unset-env-on-turn-end',
          grantId: 'grant_00000000-0000-7502-bb07-4104daba6c66',
          injectionVisibility: 'runtime-env',
          planId: 'plan_missing_env',
          redactionRule: 'name-only',
          revocationBehavior: 'mark-session-stale',
        })
      ).toThrow('Runtime-env injection plans require targetEnvVarName.');
      expect(() =>
        createVaultInjectionPlan(coreDb, {
          backendCapabilityRequirement: 'encrypted-file:resolve',
          expirationBehavior: 'delete-on-turn-end',
          grantId: 'grant_00000000-0000-7502-bb07-4104daba6c66',
          injectionVisibility: 'gateway-only',
          planId: 'plan_gateway_path',
          redactionRule: 'status-only',
          revocationBehavior: 'deny-new-use',
          targetPath: '/openkit/secrets/github-token',
        })
      ).toThrow('Gateway-only injection plans cannot include runtime targets.');
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('keeps imported VaultGrant history from authorizing an injection plan', () => {
    const coreDb = createCoreDb();

    try {
      createGrant(coreDb);
      const source = getVaultGrant(coreDb, 'grant_00000000-0000-7502-bb07-4104daba6c66');
      expect(source).not.toBeNull();
      importWorkspaceVaultGrants(coreDb, [
        { ...source!, grantId: 'grant_00000000-0000-721b-84e8-23aac7d1425e' },
      ]);

      expect(() =>
        createVaultInjectionPlan(coreDb, {
          backendCapabilityRequirement: 'encrypted-file:resolve',
          expirationBehavior: 'delete-on-turn-end',
          grantId: 'grant_00000000-0000-721b-84e8-23aac7d1425e',
          injectionVisibility: 'gateway-only',
          planId: 'plan_imported_grant',
          redactionRule: 'status-only',
          revocationBehavior: 'deny-new-use',
        })
      ).toThrow('Vault grant is portable-import history and cannot authorize effects.');
      expect(getVaultInjectionPlan(coreDb, 'plan_imported_grant')).toBeNull();
    } finally {
      coreDb.sqlite.close();
    }
  });
});

/**
 * Creates the grant fixture used by injection plan tests.
 *
 * @param coreDb Open Core database handle.
 */
function createGrant(coreDb: CoreDb): void {
  createVaultReference(coreDb, {
    backendKind: 'encrypted-file',
    displayName: 'GitHub token',
    ownerScope: 'server',
    referenceId: 'vault_00000000-0000-7f73-bffa-d96a61ee4d70',
    secretKind: 'repository-token',
  });
  createVaultGrant(coreDb, {
    allowedInjectionPaths: ['runtime-file', 'gateway-only'],
    grantId: 'grant_00000000-0000-7502-bb07-4104daba6c66',
    lifetime: 'turn',
    ownerScope: 'workspace',
    vaultReferenceId: 'vault_00000000-0000-7f73-bffa-d96a61ee4d70',
    workspaceId: 'ws_00000000-0000-73c3-900f-8d310e4ba201',
  });
}
