import { createHash } from 'node:crypto';
import { mkdtempSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import {
  type AgentEnvironmentPackage,
  AgentEnvironmentPackageSchema,
  type MaterializedWorkspaceRoot,
} from '@openkit/config-schema';
import { describe, expect, it, vi } from 'vitest';
import { WorkerControlClient } from '../../../packages/worker-shim/src/control-client.js';
import { createDefaultWorkerControlGateway } from './app.js';
import { SimulatedTurnExecutor } from './lib/simulator.js';
import { ALREADY_DECIDED_PUBLICATION_ADMISSION, type FsStore } from './lib/store.js';
import { recordAgentEnvironmentPackageSnapshot } from './runtime/aep-snapshot-ledger.js';
import * as attemptActionOwners from './runtime/execution-attempt-records.js';
import {
  acceptNanoHostAttemptHeartbeat,
  bindNanoHostAttemptRouteTokenHashes,
  requireNanoHostExecutionAttempt,
  resolveNanoHostAttemptTokenBinding,
} from './runtime/nanohost-attempt-records.js';
import { runNanoHostAttemptRecoveryMaintenance } from './runtime/nanohost-attempt-recovery.js';
import {
  allocateNanoHostRuntimeTargetConnectionGeneration,
  getNanoHostRuntimeTarget,
  recordNanoHostRuntimeTargetConnectionClose,
  upsertNanoHostRuntimeTarget,
} from './runtime/nanohost-runtime-target.js';
import { projectWorkerBackendCleanup } from './runtime/worker-backend-cleanup-projection.js';
import {
  type getWorkerBackendSession,
  markWorkerBackendWorkspaceHandoffComplete,
  recordWorkerBackendSessionMaterializing,
  transitionWorkerBackendSessionState,
} from './runtime/worker-backend-sessions.js';
import {
  hashWorkerRouteToken,
  WorkerControlGateway,
  type WorkerControlGatewayError,
  type WorkerControlLineage,
} from './runtime/worker-control-gateway.js';
import {
  createWorkerControlAcceptedRecordRecorder,
  listWorkerControlAcceptedEvents,
  resolveWorkerControlFinalStatusTokenBinding,
} from './runtime/worker-control-records.js';
import { createWorkerControlSequenceRecorder } from './runtime/worker-control-sequences.js';
import { importWorkerTranscript } from './runtime/worker-transcript.js';
import {
  buildWorkspaceInputSnapshots,
  buildWorkspaceMaterializationRecords,
} from './runtime/workspace-materializer.js';
import { listWorkspaceReconciliationRecords } from './runtime/workspace-reconciliation-records.js';
import {
  listBackendWorkspaceHandles,
  recordWorkspaceInputSnapshots,
  recordWorkspaceMaterializationRecords,
  updateBackendWorkspaceHandleCleanupStatus,
} from './runtime/workspace-sync-records.js';
import {
  createSchedulerAdmissionEntry,
  requireSchedulerAdmissionEntry,
} from './scheduler-records.js';
import { type CoreDb, openCoreDb, openWorkspaceDb } from './storage/db.js';
import { coreDbPath } from './storage/fs-layout.js';
import { applyMigrations, applyScopedMigrations } from './storage/migrate.js';
import { createTestAgentSetup } from './test-support/agent-environment.js';
import { createApp } from './test-support/app.js';
import { createDemoStore } from './test-support/demo-store.js';
import { testEntityId } from './test-support/entity-ids.js';
import { recordTestExecutionAttempt } from './test-support/execution-attempt.js';
import {
  ensureLocalUser,
  FIXTURE_LOCAL_USER_ID as LOCAL_USER_ID,
} from './test-support/local-user.js';
import { resolveAgentEnvironmentPackage } from './test-support/prepared-agent-environment.js';
import { recordWorkspaceOwnerMembership } from './workspace-membership.js';

// The real client retry owner uses timers/promises; route tests control only its clock.
vi.mock('node:timers/promises', async (original) => {
  const actual = await original<typeof import('node:timers/promises')>();
  return {
    ...actual,
    setTimeout: <T>(ms: number, value: T, options?: { signal?: AbortSignal }) => {
      if (!vi.isFakeTimers()) return actual.setTimeout(ms, value, options);
      return new Promise<T>((resolve, reject) => {
        const abort = () => {
          clearTimeout(timer);
          reject(options?.signal?.reason);
        };
        const timer = setTimeout(() => {
          options?.signal?.removeEventListener('abort', abort);
          resolve(value);
        }, ms);
        options?.signal?.addEventListener('abort', abort, { once: true });
      });
    },
  };
});

/**
 * Creates an app with one registered worker control session.
 *
 * @param workspaceRoots Workspace inputs declared by the package fixture.
 * @returns App, gateway, token, package, and lineage fixtures.
 */
function createWorkerControlRouteFixture(workspaceRoots: MaterializedWorkspaceRoot[] = []): {
  app: ReturnType<typeof createApp>;
  environmentPackage: AgentEnvironmentPackage;
  gateway: WorkerControlGateway;
  lineage: WorkerControlLineage;
  store: FsStore;
  token: string;
} {
  const store = createDemoStore();
  const turn = store.createTurn(
    'ws_00000000-0000-7000-8000-000000000001',
    'th_00000000-0000-7000-8000-000000000001',
    'Control worker over HTTP',
    {
      kind: 'user',
      id: 'usr_00000000-0000-7000-8000-000000000001',
    }
  );
  const environmentPackage = AgentEnvironmentPackageSchema.parse(
    resolveAgentEnvironmentPackage({
      agentSetup: createTestAgentSetup(),
      agentSessionId: testEntityId('as', 'as_control_route_1'),
      triggerActor: { kind: 'user', id: LOCAL_USER_ID },
      backend: {
        kind: 'openshell',
      },
      createdAt: '2026-06-16T00:00:00.000Z',
      requestId: 'req_control_route_1',
      turn,
      workspaceCwd: '/workspace/repo',
      workspaceRoots,
      workspaceSourceRefs: Object.fromEntries(workspaceRoots.map((root) => [root.id, root.id])),
      workspaceDataSourceCatalog: {
        schemaVersion: 1,
        requiredFeatures: [],
        extensions: {},
        sources: workspaceRoots.map((root) => ({
          id: root.id,
          displayName: root.id,
          kind: 'git' as const,
          locator: { commit: root.sourceCommit!, url: 'https://example.invalid/control.git' },
          access: root.access,
          allowedSlotKinds: ['worktree' as const],
          sensitivity: 'internal' as const,
          status: 'active' as const,
          syncHints: {},
          requiredFeatures: [],
          extensions: {},
        })),
      },
    })
  );
  const gateway = new WorkerControlGateway({
    createToken: () => 'token_control_route_1',
    now: () => '2026-06-16T00:00:02.000Z',
  });
  const registration = gateway.registerSession(environmentPackage);

  return {
    app: createApp({ mode: 'server', store, workerControlGateway: gateway }),
    environmentPackage,
    gateway,
    lineage: {
      agentSessionId: testEntityId('as', 'as_control_route_1'),
      packageSnapshotId: environmentPackage.snapshotId,
      requestId: 'req_control_route_1',
      threadId: 'th_00000000-0000-7000-8000-000000000001',
      turnId: turn.id,
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
    },
    store,
    token: registration.token,
  };
}

/**
 * Creates one live scheduler lease for a default database-backed worker-control gateway.
 *
 * @param coreDb Open Core database handle.
 * @param environmentPackage Durable package snapshot owned by the lease.
 * @param lineage Worker lineage owned by the lease.
 * @param suffix Stable test id suffix.
 * @returns Sandbox binding ref registered on the lease.
 */
function createDurableWorkerControlLease(
  coreDb: CoreDb,
  environmentPackage: AgentEnvironmentPackage,
  lineage: WorkerControlLineage,
  suffix: string
): string {
  const binding = `lease-binding:lease_${suffix}`;

  createSchedulerAdmissionEntry(coreDb, {
    backendId: 'nanohost',
    triggerActor: { kind: 'user', id: LOCAL_USER_ID },
    profileRef: environmentPackage.agent.profileId,
    queueEntryId: `queue_${suffix}`,
    requestId: lineage.requestId,
    requestedAgentId: environmentPackage.agent.agentId,
    threadId: lineage.threadId,
    turnId: lineage.turnId,
    turnInput: 'Run durable worker-control test',
    workspaceId: lineage.workspaceId,
  });
  const submittedAttempt = recordTestExecutionAttempt(coreDb, {
    entry: requireSchedulerAdmissionEntry(coreDb, `queue_${suffix}`),
    attemptId: testEntityId('attempt', `lease_${suffix}`),
    agentSessionId: lineage.agentSessionId,
    inputRef: lineage.packageSnapshotId,
    bindingRef: binding,
    sessionCompatibilityKey: 'fixture-compatibility',
    now: () => new Date().toISOString(),
    operationId: `fixture-submit:${String(testEntityId('attempt', `lease_${suffix}`))}`,
  });
  attemptActionOwners.acceptSchedulerExecutionObservation(coreDb, {
    ...attemptActionOwners.schedulerExecutionCorrelation(submittedAttempt),
    disposition: 'accepted',
    execution: 'running',
    fenceRef: null,
    outcomeRef: null,
  });
  bindNanoHostAttemptRouteTokenHashes(coreDb, {
    attemptId: testEntityId('attempt', `lease_${suffix}`),
    sandboxBindingRef: binding,
    workerCapabilityTokenHash: hashWorkerRouteToken(workerRouteToken(binding, 'capability')),
    workerControlTokenHash: hashWorkerRouteToken(workerRouteToken(binding, 'worker-control')),
    workerInferenceTokenHash: hashWorkerRouteToken(workerRouteToken(binding, 'inference')),
  });
  const workspaceDb = openWorkspaceDb(coreDb.dataRoot, lineage.workspaceId);

  try {
    applyScopedMigrations(workspaceDb);
    recordAgentEnvironmentPackageSnapshot(workspaceDb, {
      createdAt: environmentPackage.createdAt,
      environmentPackage,
    });
  } finally {
    workspaceDb.sqlite.close();
  }

  return binding;
}

/** Derives one deterministic 32-byte raw route token for a durable fixture. */
function workerRouteToken(
  sandboxBindingRef: string,
  family: 'capability' | 'worker-control' | 'inference'
): string {
  return createHash('sha256').update(`${family}:${sandboxBindingRef}`).digest('base64url');
}

/** Registers the exact raw token pair whose hashes are owned by a durable fixture lease. */
function registerDurableWorkerControlSession(
  gateway: WorkerControlGateway,
  environmentPackage: AgentEnvironmentPackage,
  sandboxBindingRef: string
) {
  return gateway.registerSession(environmentPackage, {
    sandboxBindingRef,
    workerCapabilityToken: workerRouteToken(sandboxBindingRef, 'capability'),
    workerControlToken: workerRouteToken(sandboxBindingRef, 'worker-control'),
    workerInferenceToken: workerRouteToken(sandboxBindingRef, 'inference'),
  });
}

/** Records the exact durable backend identity owned by one worker-control lease fixture. */
function recordWorkerControlBackendSession(
  coreDb: CoreDb,
  _environmentPackage: AgentEnvironmentPackage,
  lineage: WorkerControlLineage,
  sandboxBindingRef: string,
  backendSessionId: string
): string {
  if (!getNanoHostRuntimeTarget(coreDb, 'runtime-target-test')) {
    const allocated = allocateNanoHostRuntimeTargetConnectionGeneration(coreDb, {
      deploymentId: 'deployment-worker-control-test',
      identityId: 'identity-worker-control-test',
      observedAt: '2026-06-16T00:00:00.000Z',
      targetId: 'runtime-target-test',
    });
    upsertNanoHostRuntimeTarget(coreDb, {
      ...allocated,
      freshEmpty: true,
      observedAt: '2026-06-16T00:00:01.000Z',
      physicalEpoch: 'a'.repeat(64),
      predecessorFenced: true,
      ready: true,
    });
  }
  return recordWorkerBackendSessionMaterializing(coreDb, {
    backendLineage: { imageRef: 'openkit/worker-codex:dev', kind: 'reference' },
    backendVersion: '0.0.80',
    identity: {
      agentSessionId: lineage.agentSessionId,
      backendKind: 'openshell',
      backendSessionId,
      deploymentId: 'deployment-worker-control-test',
      packageSnapshotId: lineage.packageSnapshotId,
      runtimeTargetId: 'runtime-target-test',
      stagingDirectoryRef: `server/runtime/worker-backend-sessions/${lineage.packageSnapshotId}`,
      transientProviderInstanceId: null,
    },
    lineage: {
      threadId: lineage.threadId,
      turnId: lineage.turnId,
      workspaceId: lineage.workspaceId,
    },
    sandboxBindingRef,
  }).attemptId;
}

/** Advances one test backend identity through successful physical and durable cleanup. */
function markWorkerControlBackendSessionCleaned(coreDb: CoreDb, attemptId: string): void {
  const transitions = [
    ['materializing', 'cleanup-pending'],
    ['cleanup-pending', 'physical-cleaned'],
    ['physical-cleaned', 'cleaned'],
  ] as const;

  for (const [fromState, toState] of transitions) {
    transitionWorkerBackendSessionState(coreDb, { fromState, attemptId, toState });
  }
}

/** Builds the only worker heartbeat request shape accepted by the HTTP route. */
function heartbeatEnvelope(
  lineage: WorkerControlLineage,
  sequence: number,
  status: 'starting' | 'running' | 'stopping',
  message: string | null = null,
  processKeyHash?: string
) {
  return {
    body: { message, ...(processKeyHash ? { processKeyHash } : {}), status },
    lineage,
    operation: 'heartbeat' as const,
    schemaVersion: 2 as const,
    sequence,
  };
}

/** Reads exact Core attempt ownership without interpreting backend-private progress. */
function observeExecutionAttempts(
  coreDb: ReturnType<typeof openCoreDb>
): Record<string, unknown>[] {
  const present = coreDb.sqlite
    .prepare(
      "SELECT name FROM sqlite_master WHERE type='table' AND name='scheduler_execution_attempts'"
    )
    .get();
  return present
    ? (coreDb.sqlite
        .prepare('SELECT * FROM scheduler_execution_attempts ORDER BY rowid')
        .all() as Record<string, unknown>[])
    : [];
}

/** Observes the immutable Core deadline separately from adapter liveness and sequence updates. */
function absoluteAttemptDeadline(coreDb: CoreDb, turnId: string): string {
  const row = observeExecutionAttempts(coreDb).find((attempt) => attempt.turn_id === turnId);
  expect(
    row,
    'Activity must retain a real attempt with a durable absolute deadline.'
  ).toBeDefined();
  const deadline = String(row!.deadline);
  expect(Number.isFinite(Date.parse(deadline))).toBe(true);
  return deadline;
}

describe('worker control routes', () => {
  it.each([
    ['final-status', 'final_status'],
    ['supply-refresh-ack', 'supply_refresh_ack'],
    ['capability-summary', 'capability_summary'],
  ])('observes early %s refusals without echoing attempted values', async (path, operation) => {
    const { app, lineage, token } = createWorkerControlRouteFixture();
    const log = vi.spyOn(console, 'error').mockImplementation(() => {});
    try {
      for (const attemptedOperation of ['heartbeat', operation]) {
        log.mockClear();
        const response = await app.request(`/api/worker-control/${path}`, {
          method: 'POST',
          headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json' },
          body: JSON.stringify({
            schemaVersion: 2,
            lineage,
            operation: attemptedOperation,
            sequence: 4,
            body: { privateValue: 'PRIVATE_BODY_SENTINEL' },
          }),
        });
        expect(response.status).toBe(400);
        expect(log).toHaveBeenCalledTimes(1);
        expect(JSON.parse(String(log.mock.calls[0]?.[0]))).toMatchObject({
          event: 'worker.control.request',
          operation,
          sequence: 4,
          code: 'invalid_request',
          outcome: 'refused',
          status: 400,
          attemptId: null,
          attemptPhase: null,
          turnId: null,
          agentSessionId: null,
        });
        expect(log.mock.calls.join(' ')).not.toContain('PRIVATE_BODY_SENTINEL');
        expect(log.mock.calls.join(' ')).not.toContain(token);
      }
    } finally {
      log.mockRestore();
    }
  });

  it('localizes withheld heartbeat acknowledgements and blocked carriage without renewing stale authority', async () => {
    const fixture = createWorkerControlRouteFixture();
    const coreDb = openCoreDb(mkdtempSync(join(tmpdir(), 'openkit-heartbeat-gap-')));
    applyMigrations(coreDb);
    ensureLocalUser(coreDb);
    recordWorkspaceOwnerMembership({
      coreDb,
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
      ownerUserId: LOCAL_USER_ID,
    });
    const binding = createDurableWorkerControlLease(
      coreDb,
      fixture.environmentPackage,
      fixture.lineage,
      'diagnostic_gap'
    );
    const gateway = createDefaultWorkerControlGateway(coreDb);
    const registration = registerDurableWorkerControlSession(
      gateway,
      fixture.environmentPackage,
      binding
    );
    const app = createApp({
      coreDb,
      mode: 'server',
      store: fixture.store,
      workerControlGateway: gateway,
    });
    const log = vi.spyOn(console, 'error').mockImplementation(() => {});
    const attempts: string[] = [];
    let releaseCarriage!: () => void;
    const blocked = new Promise<void>((resolve) => {
      releaseCarriage = resolve;
    });
    let entered!: () => void;
    const firstAccepted = new Promise<void>((resolve) => {
      entered = resolve;
    });
    let baseline: ReturnType<typeof requireNanoHostExecutionAttempt> | undefined;
    vi.useFakeTimers({ toFake: ['setTimeout', 'clearTimeout', 'Date', 'performance'] });
    const stop = new AbortController();
    const client = new WorkerControlClient({
      baseUrl: 'http://core/api/worker-control',
      token: registration.token,
      lineage: fixture.lineage,
      fetch: async (url, init) => {
        attempts.push(init.body);
        if (attempts.length > 2) await blocked;
        const response = await app.request(url, init);
        if (attempts.length <= 2) {
          expect(response.status).toBe(200);
          const lease = requireNanoHostExecutionAttempt(
            coreDb,
            testEntityId('attempt', 'lease_diagnostic_gap')
          );
          if (!baseline) {
            baseline = lease;
            entered();
          } else expect(lease).toEqual(baseline); // Exact replay acknowledges; it never renews.
          return { ok: true, status: 200, text: () => new Promise<string>(() => {}) };
        }
        return response;
      },
    });
    client.enablePostLaunchRecovery();
    const heartbeat = client
      .recordHeartbeat({ status: 'starting', message: 'PRIVATE_STATUS_SENTINEL' }, stop.signal)
      .catch((error: unknown) => error);
    try {
      await firstAccepted;
      await vi.advanceTimersByTimeAsync(31_000);
      expect(attempts.length).toBeGreaterThanOrEqual(3);
      expect(new Set(attempts).size).toBe(1);
      expect(
        requireNanoHostExecutionAttempt(coreDb, testEntityId('attempt', 'lease_diagnostic_gap'))
          .heartbeatDeadline
      ).toBe(baseline!.heartbeatDeadline);
      expect(
        resolveNanoHostAttemptTokenBinding(coreDb, {
          sandboxBindingRef: binding,
          lineage: fixture.lineage,
          token: registration.token,
          tokenFamily: 'worker-control',
        })
      ).toEqual({ status: 'rejected', reason: 'attempt-not-live' });
      expect(
        attemptActionOwners.requireSchedulerExecutionAttempt(
          coreDb,
          testEntityId('attempt', 'lease_diagnostic_gap')
        )
      ).toMatchObject({
        phase: 'open',
        disposition: 'accepted',
        operationId: `fixture-submit:${testEntityId('attempt', 'lease_diagnostic_gap')}`,
        fenceRef: null,
      });
      releaseCarriage();
      expect(await heartbeat).toMatchObject({ code: 'worker_control_lease_not_live', status: 403 });
      expect(['open', 'closing']).toContain(
        observeExecutionAttempts(coreDb).find(
          (attempt) => attempt.attempt_id === testEntityId('attempt', 'lease_diagnostic_gap')
        )?.phase
      );
      expect(
        requireNanoHostExecutionAttempt(coreDb, testEntityId('attempt', 'lease_diagnostic_gap'))
      ).toMatchObject({
        lastWorkerSequence: 0,
        heartbeatDeadline: baseline!.heartbeatDeadline,
      });
      expect(
        coreDb.sqlite
          .prepare(
            "SELECT count(*) AS count FROM worker_control_records WHERE operation = 'final_status'"
          )
          .get()
      ).toEqual({ count: 0 });
      const lines = log.mock.calls.map(([line]) => JSON.parse(String(line)));
      expect(lines).toContainEqual(
        expect.objectContaining({
          event: 'worker.control.request',
          operation: 'heartbeat',
          sequence: 0,
          attemptId: testEntityId('attempt', 'lease_diagnostic_gap'),
          attemptPhase: 'open',
          outcome: 'accepted',
        })
      );
      expect(lines).toContainEqual(
        expect.objectContaining({
          event: 'worker.control.request',
          sequence: 0,
          attemptId: testEntityId('attempt', 'lease_diagnostic_gap'),
          attemptPhase: 'open',
          outcome: 'refused',
          status: 403,
          deadlineDeltaMs: 1000,
        })
      );
      expect(log.mock.calls.join(' ')).not.toContain(registration.token);
      expect(log.mock.calls.join(' ')).not.toContain('PRIVATE_STATUS_SENTINEL');
      expect(log.mock.calls.join(' ')).not.toContain('processKey');
    } finally {
      stop.abort();
      releaseCarriage();
      await heartbeat;
      vi.useRealTimers();
      log.mockRestore();
      coreDb.sqlite.close();
    }
  });

  it('strips descriptive heartbeat, final-status and refresh additions before gateway admission', async () => {
    const { app, gateway, lineage, token, environmentPackage } = createWorkerControlRouteFixture();
    const heartbeat = heartbeatEnvelope(lineage, 1, 'running', 'alive');
    const cases = [
      {
        path: 'heartbeat',
        body: { ...heartbeat, body: { ...heartbeat.body, futureNote: 'ignored' } },
      },
      {
        path: 'supply-refresh-ack',
        body: {
          schemaVersion: 2,
          lineage,
          sequence: 1,
          operation: 'supply_refresh_ack',
          body: { refreshId: 'refresh_1', status: 'applied', futureNote: 'ignored' },
        },
      },
      {
        path: 'final-status',
        body: {
          schemaVersion: 2,
          lineage,
          sequence: 3,
          operation: 'final_status',
          body: {
            status: 'completed',
            stopReason: 'completed',
            evidenceManifestDigests: {},
            futureNote: 'ignored',
          },
        },
      },
    ];
    for (const entry of cases) {
      const response = await app.request(`/api/worker-control/${entry.path}`, {
        method: 'POST',
        headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json' },
        body: JSON.stringify({ ...entry.body, futureNote: 'ignored' }),
      });
      expect(response.status).toBe(200);
      expect(JSON.stringify(await response.json())).not.toContain('futureNote');
    }
    const snapshot = gateway.getSessionSnapshot(environmentPackage.snapshotId);
    expect(snapshot?.heartbeat).toMatchObject({ status: 'running', message: 'alive' });
    expect(snapshot?.supplyRefreshAcks).toEqual([
      expect.objectContaining({ refreshId: 'refresh_1', status: 'applied' }),
    ]);
    expect(JSON.stringify(snapshot)).not.toContain('futureNote');
  });

  it.each([
    [
      'heartbeat',
      { schemaVersion: 2, sequence: 1, operation: 'heartbeat', body: { status: 'invented' } },
    ],
    [
      'supply-refresh-ack',
      {
        schemaVersion: 2,
        sequence: 1,
        operation: 'supply_refresh_ack',
        body: { status: 'invented', refreshId: 'refresh_1' },
      },
    ],
    [
      'final-status',
      { schemaVersion: 2, sequence: 1, operation: 'final_status', body: { status: 'completed' } },
    ],
  ])('refuses invalid known core in %s before admission', async (path, body) => {
    const { app, gateway, lineage, token, environmentPackage } = createWorkerControlRouteFixture();
    const response = await app.request(`/api/worker-control/${path}`, {
      method: 'POST',
      headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json' },
      body: JSON.stringify({ ...body, lineage, futureNote: 'ignored' }),
    });
    expect(response.status).toBe(400);
    expect(gateway.getSessionSnapshot(environmentPackage.snapshotId)).toMatchObject({
      heartbeat: null,
      events: [],
      supplyRefreshAcks: [],
    });
  });

  it('keeps worker route planes ahead of product API middleware', () => {
    const routes = createApp()
      .routes.filter(({ path }) => path.startsWith('/api/worker-') || path === '/api/*')
      .map(({ method, path }) => `${method} ${path}`);

    expect(routes).toEqual([
      'ALL /api/worker-control/*',
      'POST /api/worker-control/heartbeat',
      'POST /api/worker-control/artifacts',
      'POST /api/worker-control/events/append',
      'POST /api/worker-control/final-status',
      'POST /api/worker-control/supply-refresh-ack',
      'POST /api/worker-control/capability-summary',
      'ALL /api/worker-inference/*',
      'POST /api/worker-inference/v1/chat/completions',
      'POST /api/worker-inference/v1/responses',
      'ALL /api/worker-capabilities/*',
      'POST /api/worker-capabilities/mcp/_list-servers',
      'POST /api/worker-capabilities/mcp/:serverId',
      'ALL /api/*',
      'ALL /api/*',
    ]);
  });

  it.each([
    [
      'original process key',
      createHash('sha256').update('route-process-key').digest('base64url'),
      true,
      false,
      false,
      null,
      null,
    ],
    [
      'different process key',
      createHash('sha256').update('wrong-route-process-key').digest('base64url'),
      false,
      false,
      false,
      null,
      null,
    ],
    [
      'original process key before RuntimeTarget readiness returns',
      createHash('sha256').update('route-process-key').digest('base64url'),
      false,
      true,
      false,
      503,
      'worker_control_reconnect_required',
    ],
    [
      'original process key after backend cleanup starts',
      createHash('sha256').update('route-process-key').digest('base64url'),
      false,
      false,
      true,
      403,
      'worker_control_lease_not_live',
    ],
  ] as const)('accepts restart heartbeat only for the %s', async (_case, reconnectKey, accepted, clearRuntimeTargetReadiness, beginBackendCleanup, expectedStatus, expectedErrorCode) => {
    const coreDb = openCoreDb(mkdtempSync(join(tmpdir(), 'openkit-worker-reconnect-route-')));
    const fixture = createWorkerControlRouteFixture();
    const originalKey = createHash('sha256').update('route-process-key').digest('base64url');
    const processKeyHash = createHash('sha256')
      .update(Buffer.from(originalKey, 'base64url'))
      .digest('base64url');

    try {
      applyMigrations(coreDb);
      ensureLocalUser(coreDb);
      recordWorkspaceOwnerMembership({
        coreDb,
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        ownerUserId: LOCAL_USER_ID,
      });
      const binding = createDurableWorkerControlLease(
        coreDb,
        fixture.environmentPackage,
        fixture.lineage,
        'process_key_reconnect'
      );
      const attemptId = recordWorkerControlBackendSession(
        coreDb,
        fixture.environmentPackage,
        fixture.lineage,
        binding,
        'sandbox-process-key-reconnect'
      );
      transitionWorkerBackendSessionState(coreDb, {
        fromState: 'materializing',
        attemptId,
        toState: 'materialized',
      });
      transitionWorkerBackendSessionState(coreDb, {
        fromState: 'materialized',
        attemptId,
        toState: 'launching',
      });
      markWorkerBackendWorkspaceHandoffComplete(coreDb, { attemptId });
      const absoluteDeadline = absoluteAttemptDeadline(coreDb, fixture.lineage.turnId);
      const firstGateway = createDefaultWorkerControlGateway(coreDb);
      registerDurableWorkerControlSession(firstGateway, fixture.environmentPackage, binding);
      const firstApp = createApp({
        coreDb,
        mode: 'server',
        store: fixture.store,
        workerControlGateway: firstGateway,
      });
      const firstHeartbeat = await firstApp.request('/api/worker-control/heartbeat', {
        body: JSON.stringify(
          heartbeatEnvelope(fixture.lineage, 0, 'starting', null, processKeyHash)
        ),
        headers: {
          authorization: `Bearer ${workerRouteToken(binding, 'worker-control')}`,
          'content-type': 'application/json',
        },
        method: 'POST',
      });
      expect(firstHeartbeat.status).toBe(200);
      expect(absoluteAttemptDeadline(coreDb, fixture.lineage.turnId)).toBe(absoluteDeadline);
      coreDb.sqlite
        .prepare(
          `UPDATE scheduler_execution_attempts
           SET recovery_state = 'awaiting-reconnect',
               recovery_deadline = '2099-01-01T00:00:00.000Z'
           WHERE attempt_id = '${testEntityId('attempt', 'lease_process_key_reconnect')}'`
        )
        .run();
      if (clearRuntimeTargetReadiness) {
        recordNanoHostRuntimeTargetConnectionClose(coreDb, {
          authoritativeGeneration: null,
          closedGeneration: 1,
          observedAt: '2026-07-05T00:00:01.000Z',
          targetId: 'runtime-target-test',
        });
      }
      if (beginBackendCleanup) {
        transitionWorkerBackendSessionState(coreDb, {
          fromState: 'launching',
          attemptId,
          toState: 'cleanup-pending',
        });
      }

      const restartedGateway = createDefaultWorkerControlGateway(coreDb);
      registerDurableWorkerControlSession(restartedGateway, fixture.environmentPackage, binding);
      const restartedApp = createApp({
        coreDb,
        mode: 'server',
        store: fixture.store,
        workerControlGateway: restartedGateway,
      });
      const reconnect = await restartedApp.request('/api/worker-control/heartbeat', {
        body: JSON.stringify({
          ...heartbeatEnvelope(fixture.lineage, 1, 'running', 'Worker survived NanoCore restart.'),
          reconnectKey,
        }),
        headers: {
          authorization: `Bearer ${workerRouteToken(binding, 'worker-control')}`,
          'content-type': 'application/json',
        },
        method: 'POST',
      });
      const lease = requireNanoHostExecutionAttempt(
        coreDb,
        testEntityId('attempt', 'lease_process_key_reconnect')
      );
      const durableWorkerControl = JSON.stringify(
        coreDb.sqlite
          .prepare(
            `SELECT record_json FROM worker_control_records
             UNION ALL
             SELECT fingerprint AS record_json FROM worker_control_sequence_fingerprints`
          )
          .all()
      );

      expect(reconnect.status === 200).toBe(accepted);
      expect(absoluteAttemptDeadline(coreDb, fixture.lineage.turnId)).toBe(absoluteDeadline);
      if (expectedErrorCode) {
        expect(reconnect.status).toBe(expectedStatus);
        expect(await reconnect.clone().json()).toMatchObject({ code: expectedErrorCode });
      }
      expect(lease).toMatchObject(
        accepted
          ? { lastWorkerSequence: 1, recoveryDeadline: null, recoveryState: null }
          : {
              lastWorkerSequence: 0,
              recoveryDeadline: '2099-01-01T00:00:00.000Z',
              recoveryState: 'awaiting-reconnect',
            }
      );
      expect(await reconnect.text()).not.toContain(reconnectKey);
      expect(durableWorkerControl).not.toContain(reconnectKey);
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('keeps event append sequence conflicts durable across default gateway instances', async () => {
    const coreDb = openCoreDb(mkdtempSync(join(tmpdir(), 'openkit-worker-control-sequence-')));
    const store = createDemoStore();
    const thread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Durable sequence thread'
    );
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Control worker',
      {
        kind: 'user',
        id: 'usr_00000000-0000-7000-8000-000000000001',
      }
    );
    const environmentPackage = AgentEnvironmentPackageSchema.parse(
      resolveAgentEnvironmentPackage({
        agentSetup: createTestAgentSetup(),
        agentSessionId: testEntityId('as', 'session_durable_sequence'),
        triggerActor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
        backend: {
          kind: 'openshell',
        },
        createdAt: '2026-06-16T00:00:00.000Z',
        requestId: 'req_durable_sequence',
        turn,
        workspaceCwd: '/workspace/repo',
        workspaceRoots: [],
      })
    );
    const lineage: WorkerControlLineage = {
      agentSessionId: environmentPackage.scope.agentSessionId,
      packageSnapshotId: environmentPackage.snapshotId,
      requestId: environmentPackage.scope.requestId,
      threadId: environmentPackage.scope.threadId,
      turnId: environmentPackage.scope.turnId,
      workspaceId: environmentPackage.scope.workspaceId,
    };

    try {
      applyMigrations(coreDb);
      ensureLocalUser(coreDb);
      recordWorkspaceOwnerMembership({
        coreDb,
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        ownerUserId: LOCAL_USER_ID,
      });

      const binding = createDurableWorkerControlLease(
        coreDb,
        environmentPackage,
        lineage,
        'durable_sequence'
      );
      const firstGateway = createDefaultWorkerControlGateway(coreDb);
      const firstRegistration = registerDurableWorkerControlSession(
        firstGateway,
        environmentPackage,
        binding
      );
      const firstApp = createApp({
        coreDb,
        mode: 'server',
        store,
        workerControlGateway: firstGateway,
      });
      const first = await firstApp.request('/api/worker-control/events/append', {
        body: JSON.stringify({
          lineage,
          record: {
            event: { data: { delta: 'hello', itemId: 'candidate_item_1' }, type: 'item.delta' },
            kind: 'event',
            lineage,
            schemaVersion: 1,
            sequence: 3,
          },
        }),
        headers: {
          authorization: `Bearer ${firstRegistration.token}`,
          'content-type': 'application/json',
        },
        method: 'POST',
      });

      const secondGateway = createDefaultWorkerControlGateway(coreDb);
      const secondRegistration = registerDurableWorkerControlSession(
        secondGateway,
        environmentPackage,
        binding
      );
      const secondApp = createApp({
        coreDb,
        mode: 'server',
        store,
        workerControlGateway: secondGateway,
      });
      const conflict = await secondApp.request('/api/worker-control/events/append', {
        body: JSON.stringify({
          lineage,
          record: {
            event: {
              data: { delta: 'different', itemId: 'candidate_item_1' },
              type: 'item.delta',
            },
            kind: 'event',
            lineage,
            schemaVersion: 1,
            sequence: 3,
          },
        }),
        headers: {
          authorization: `Bearer ${secondRegistration.token}`,
          'content-type': 'application/json',
        },
        method: 'POST',
      });
      const body = (await conflict.json()) as { code: string };

      expect(first.status).toBe(200);
      expect(conflict.status).toBe(409);
      expect(body.code).toBe('worker_control_sequence_conflict');
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('persists accepted worker-control records through the default gateway', async () => {
    const coreDb = openCoreDb(mkdtempSync(join(tmpdir(), 'openkit-worker-control-records-')));
    const store = createDemoStore();
    const thread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Durable control records thread'
    );
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Control worker',
      {
        kind: 'user',
        id: 'usr_00000000-0000-7000-8000-000000000001',
      }
    );
    const environmentPackage = AgentEnvironmentPackageSchema.parse(
      resolveAgentEnvironmentPackage({
        agentSetup: createTestAgentSetup(),
        agentSessionId: testEntityId('as', 'session_durable_records'),
        triggerActor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
        backend: {
          kind: 'openshell',
        },
        createdAt: '2026-06-16T00:00:00.000Z',
        requestId: 'req_durable_records',
        turn,
        workspaceCwd: '/workspace/repo',
        workspaceRoots: [],
      })
    );
    const lineage: WorkerControlLineage = {
      agentSessionId: environmentPackage.scope.agentSessionId,
      packageSnapshotId: environmentPackage.snapshotId,
      requestId: environmentPackage.scope.requestId,
      threadId: environmentPackage.scope.threadId,
      turnId: environmentPackage.scope.turnId,
      workspaceId: environmentPackage.scope.workspaceId,
    };

    try {
      applyMigrations(coreDb);
      ensureLocalUser(coreDb);
      recordWorkspaceOwnerMembership({
        coreDb,
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        ownerUserId: LOCAL_USER_ID,
      });

      const binding = createDurableWorkerControlLease(
        coreDb,
        environmentPackage,
        lineage,
        'durable_records'
      );
      const gateway = createDefaultWorkerControlGateway(coreDb);
      const registration = registerDurableWorkerControlSession(
        gateway,
        environmentPackage,
        binding
      );
      const app = createApp({
        coreDb,
        mode: 'server',
        store,
        workerControlGateway: gateway,
      });
      const heartbeat = await app.request('/api/worker-control/heartbeat', {
        body: JSON.stringify(heartbeatEnvelope(lineage, 1, 'running', 'Worker is alive.')),
        headers: {
          authorization: `Bearer ${registration.token}`,
          'content-type': 'application/json',
        },
        method: 'POST',
      });
      const event = await app.request('/api/worker-control/events/append', {
        body: JSON.stringify({
          lineage,
          record: {
            event: { data: { delta: 'hello', itemId: 'candidate_item_1' }, type: 'item.delta' },
            kind: 'event',
            lineage,
            schemaVersion: 1,
            sequence: 3,
          },
        }),
        headers: {
          authorization: `Bearer ${registration.token}`,
          'content-type': 'application/json',
        },
        method: 'POST',
      });
      const rows = coreDb.sqlite
        .prepare(
          `
          SELECT operation, record_key AS recordKey, sequence, record_json AS recordJson
          FROM worker_control_records
          ORDER BY operation
          `
        )
        .all() as Array<{
        operation: string;
        recordJson: string;
        recordKey: string;
        sequence: number;
      }>;

      expect(heartbeat.status).toBe(200);
      expect(event.status).toBe(200);
      expect(rows).toHaveLength(2);
      expect(rows.map((row) => [row.operation, row.recordKey, row.sequence])).toEqual([
        ['event_append', '3', 3],
        ['heartbeat', '1', 1],
      ]);
      expect(JSON.parse(rows[0].recordJson)).toMatchObject({
        event: { type: 'item.delta' },
        sequence: 3,
      });
      expect(JSON.parse(rows[1].recordJson)).toMatchObject({
        status: 'running',
        sequence: 1,
      });
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('never persists worker bearer tokens in sequenced control state', async () => {
    const dataRoot = mkdtempSync(join(tmpdir(), 'openkit-worker-control-token-redaction-'));
    const coreDb = openCoreDb(dataRoot);
    const { environmentPackage, lineage, store } = createWorkerControlRouteFixture();
    const token = 'okw_sequence_fingerprint_secret';

    try {
      applyMigrations(coreDb);
      ensureLocalUser(coreDb);
      recordWorkspaceOwnerMembership({
        coreDb,
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        ownerUserId: LOCAL_USER_ID,
      });
      const gateway = new WorkerControlGateway({
        acceptedRecordRecorder: createWorkerControlAcceptedRecordRecorder(coreDb),
        createToken: () => token,
        now: () => '2026-07-15T00:00:00.000Z',
        sequenceRecorder: createWorkerControlSequenceRecorder(coreDb),
      });
      gateway.registerSession(environmentPackage);
      const app = createApp({ coreDb, mode: 'server', store, workerControlGateway: gateway });
      const requests = [
        {
          accepted: heartbeatEnvelope(lineage, 1, 'running', 'alive'),
          conflict: heartbeatEnvelope(lineage, 1, 'running', 'changed'),
          operation: 'heartbeat',
          route: '/api/worker-control/heartbeat',
        },
        {
          accepted: {
            artifact: { path: 'reports/result.md', title: 'Result' },
            lineage,
            sequence: 2,
          },
          conflict: {
            artifact: { path: 'reports/result.md', title: 'Changed result' },
            lineage,
            sequence: 2,
          },
          operation: 'artifact_notice',
          route: '/api/worker-control/artifacts',
        },
        {
          accepted: {
            body: { message: 'refreshed', refreshId: 'refresh_token_redaction', status: 'applied' },
            lineage,
            operation: 'supply_refresh_ack',
            schemaVersion: 2,
            sequence: 3,
          },
          conflict: {
            body: { message: 'changed', refreshId: 'refresh_token_redaction', status: 'applied' },
            lineage,
            operation: 'supply_refresh_ack',
            schemaVersion: 2,
            sequence: 3,
          },
          operation: 'supply_refresh_ack',
          route: '/api/worker-control/supply-refresh-ack',
        },
      ] as const;

      for (const request of requests) {
        const send = (body: unknown) =>
          app.request(request.route, {
            body: JSON.stringify(body),
            headers: {
              authorization: `Bearer ${token}`,
              'content-type': 'application/json',
            },
            method: 'POST',
          });
        const accepted = await send(request.accepted);
        const replay = await send(request.accepted);
        const conflict = await send(request.conflict);

        expect.soft(accepted.status, request.operation).toBe(200);
        expect.soft(replay.status, request.operation).toBe(200);
        expect.soft(conflict.status, request.operation).toBe(409);
        expect.soft(await conflict.json(), request.operation).toMatchObject({
          code: 'worker_control_sequence_conflict',
        });
      }

      const fingerprints = coreDb.sqlite
        .prepare(
          `SELECT operation, fingerprint
             FROM worker_control_sequence_fingerprints
            ORDER BY operation`
        )
        .all() as Array<{ fingerprint: string; operation: string }>;
      const records = coreDb.sqlite
        .prepare(
          `SELECT operation, record_json AS recordJson
             FROM worker_control_records
            ORDER BY operation`
        )
        .all() as Array<{ operation: string; recordJson: string }>;

      expect(fingerprints.map(({ operation }) => operation)).toEqual(
        requests.map(({ operation }) => operation).sort()
      );
      expect(records.map(({ operation }) => operation)).toEqual(
        requests.map(({ operation }) => operation).sort()
      );
      expect(JSON.stringify(fingerprints)).not.toContain(token);
      expect(JSON.stringify(records)).not.toContain(token);
      coreDb.sqlite.close();
      expect(readFileSync(coreDbPath(dataRoot)).includes(token)).toBe(false);
    } finally {
      if (coreDb.sqlite.open) {
        coreDb.sqlite.close();
      }
    }
  });

  it('records rejected worker-control evidence through the default gateway', async () => {
    const coreDb = openCoreDb(mkdtempSync(join(tmpdir(), 'openkit-worker-control-rejected-')));
    const store = createDemoStore();
    const thread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Rejected control records thread'
    );
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Control worker',
      {
        kind: 'user',
        id: 'usr_00000000-0000-7000-8000-000000000001',
      }
    );
    const environmentPackage = AgentEnvironmentPackageSchema.parse(
      resolveAgentEnvironmentPackage({
        agentSetup: createTestAgentSetup(),
        agentSessionId: testEntityId('as', 'session_rejected_records'),
        triggerActor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
        backend: {
          kind: 'openshell',
        },
        createdAt: '2026-06-16T00:00:00.000Z',
        requestId: 'req_rejected_records',
        turn,
        workspaceCwd: '/workspace/repo',
        workspaceRoots: [],
      })
    );
    const lineage: WorkerControlLineage = {
      agentSessionId: environmentPackage.scope.agentSessionId,
      packageSnapshotId: environmentPackage.snapshotId,
      requestId: environmentPackage.scope.requestId,
      threadId: environmentPackage.scope.threadId,
      turnId: environmentPackage.scope.turnId,
      workspaceId: environmentPackage.scope.workspaceId,
    };

    try {
      applyMigrations(coreDb);
      ensureLocalUser(coreDb);
      recordWorkspaceOwnerMembership({
        coreDb,
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        ownerUserId: LOCAL_USER_ID,
      });

      const binding = createDurableWorkerControlLease(
        coreDb,
        environmentPackage,
        lineage,
        'rejected_records'
      );
      const gateway = createDefaultWorkerControlGateway(coreDb);
      const registration = registerDurableWorkerControlSession(
        gateway,
        environmentPackage,
        binding
      );
      const app = createApp({
        coreDb,
        mode: 'server',
        store,
        workerControlGateway: gateway,
      });
      const response = await app.request('/api/worker-control/events/append', {
        body: JSON.stringify({
          lineage,
          record: {
            event: { data: { delta: 'hello', itemId: 'candidate_item_1' }, type: 'item.delta' },
            kind: 'event',
            lineage: { ...lineage, threadId: testEntityId('th', 'th_other') },
            schemaVersion: 1,
            sequence: 1,
          },
        }),
        headers: {
          authorization: `Bearer ${registration.token}`,
          'content-type': 'application/json',
        },
        method: 'POST',
      });
      const body = (await response.json()) as { code: string };
      const rejectedRow = coreDb.sqlite
        .prepare(
          `
          SELECT route, operation, error_code AS errorCode, http_status AS httpStatus, thread_id AS threadId
          FROM worker_control_rejected_evidence
          WHERE agent_session_id = ?
          `
        )
        .get(lineage.agentSessionId) as
        | {
            errorCode: string;
            httpStatus: number;
            operation: string;
            route: string;
            threadId: string;
          }
        | undefined;
      const acceptedCount = coreDb.sqlite
        .prepare('SELECT COUNT(*) AS count FROM worker_control_records')
        .get() as { count: number };

      expect(response.status).toBe(403);
      expect(body.code).toBe('worker_control_lineage_mismatch');
      expect(rejectedRow).toEqual({
        errorCode: 'worker_control_lineage_mismatch',
        httpStatus: 403,
        operation: 'event_append',
        route: '/api/worker-control/events/append',
        threadId: lineage.threadId,
      });
      expect(acceptedCount.count).toBe(0);
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('enforces durable scheduler binding refs through the default gateway factory', async () => {
    const coreDb = openCoreDb(mkdtempSync(join(tmpdir(), 'openkit-worker-control-default-')));
    const store = createDemoStore();
    const thread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Default binding thread'
    );
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Control worker',
      {
        kind: 'user',
        id: 'usr_00000000-0000-7000-8000-000000000001',
      }
    );
    const environmentPackage = AgentEnvironmentPackageSchema.parse(
      resolveAgentEnvironmentPackage({
        agentSetup: createTestAgentSetup(),
        agentSessionId: testEntityId('as', 'session_default_binding'),
        triggerActor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
        backend: {
          kind: 'openshell',
        },
        createdAt: '2026-06-16T00:00:00.000Z',
        requestId: 'req_default_binding',
        turn,
        workspaceCwd: '/workspace/repo',
        workspaceRoots: [],
      })
    );
    const lineage: WorkerControlLineage = {
      agentSessionId: environmentPackage.scope.agentSessionId,
      packageSnapshotId: environmentPackage.snapshotId,
      requestId: environmentPackage.scope.requestId,
      threadId: environmentPackage.scope.threadId,
      turnId: environmentPackage.scope.turnId,
      workspaceId: environmentPackage.scope.workspaceId,
    };

    applyMigrations(coreDb);
    ensureLocalUser(coreDb);
    recordWorkspaceOwnerMembership({
      coreDb,
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
      ownerUserId: LOCAL_USER_ID,
    });
    const gateway = createDefaultWorkerControlGateway(coreDb);
    createSchedulerAdmissionEntry(coreDb, {
      backendId: 'nanohost',
      triggerActor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
      profileRef: environmentPackage.agent.profileId,
      queueEntryId: 'queue_default_binding',
      requestedAgentId: environmentPackage.agent.agentId,
      threadId: lineage.threadId,
      turnId: lineage.turnId,
      turnInput: 'Run worker control route test',
      workspaceId: lineage.workspaceId,
    });
    const submittedAttempt = recordTestExecutionAttempt(coreDb, {
      entry: requireSchedulerAdmissionEntry(coreDb, 'queue_default_binding'),
      attemptId: testEntityId('attempt', 'lease_default_binding'),
      agentSessionId: lineage.agentSessionId,
      inputRef: lineage.packageSnapshotId,
      bindingRef: 'lease-binding:lease_default_binding',
      sessionCompatibilityKey: 'fixture-compatibility',
      now: () => new Date().toISOString(),
      operationId: `fixture-submit:${String(testEntityId('attempt', 'lease_default_binding'))}`,
    });
    attemptActionOwners.acceptSchedulerExecutionObservation(coreDb, {
      ...attemptActionOwners.schedulerExecutionCorrelation(submittedAttempt),
      disposition: 'accepted',
      execution: 'running',
      fenceRef: null,
      outcomeRef: null,
    });
    bindNanoHostAttemptRouteTokenHashes(coreDb, {
      attemptId: testEntityId('attempt', 'lease_default_binding'),
      sandboxBindingRef: 'lease-binding:lease_default_binding',
      workerCapabilityTokenHash: hashWorkerRouteToken(
        workerRouteToken('lease-binding:lease_default_binding', 'capability')
      ),
      workerControlTokenHash: hashWorkerRouteToken(
        workerRouteToken('lease-binding:lease_default_binding', 'worker-control')
      ),
      workerInferenceTokenHash: hashWorkerRouteToken(
        workerRouteToken('lease-binding:lease_default_binding', 'inference')
      ),
    });
    const backendLeaseId = recordWorkerControlBackendSession(
      coreDb,
      environmentPackage,
      lineage,
      'lease-binding:lease_default_binding',
      'sandbox_default_binding'
    );
    const registration = registerDurableWorkerControlSession(
      gateway,
      environmentPackage,
      'lease-binding:lease_default_binding'
    );
    const app = createApp({ coreDb, mode: 'server', store, workerControlGateway: gateway });

    gateway.recordHeartbeat({
      authorization: `Bearer ${registration.token}`,
      ...heartbeatEnvelope(lineage, 1, 'running'),
    });
    expect(['open', 'closing']).toContain(
      observeExecutionAttempts(coreDb).find(
        (attempt) => attempt.attempt_id === testEntityId('attempt', 'lease_default_binding')
      )?.phase
    );
    expect(
      requireNanoHostExecutionAttempt(coreDb, testEntityId('attempt', 'lease_default_binding'))
    ).toMatchObject({
      lastAcceptedHeartbeatAt: expect.any(String),
      lastWorkerSequence: 1,
    });
    const heartbeatBaseline = requireNanoHostExecutionAttempt(
      coreDb,
      testEntityId('attempt', 'lease_default_binding')
    );

    coreDb.sqlite
      .prepare(
        'UPDATE scheduler_execution_attempts SET last_worker_sequence = ? WHERE attempt_id = ?'
      )
      .run(3, testEntityId('attempt', 'lease_default_binding'));
    const staleSequenceResponse = await app.request('/api/worker-control/heartbeat', {
      body: JSON.stringify(heartbeatEnvelope(lineage, 2, 'running')),
      headers: {
        authorization: `Bearer ${registration.token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });
    const staleSequenceBody = (await staleSequenceResponse.json()) as { code: string };

    expect.soft(staleSequenceResponse.status).toBe(409);
    expect.soft(staleSequenceBody.code).toBe('worker_control_sequence_stale');
    coreDb.sqlite
      .prepare(
        "DELETE FROM worker_control_sequence_fingerprints WHERE operation = 'heartbeat' AND sequence = ?"
      )
      .run(2);
    coreDb.sqlite
      .prepare(
        'UPDATE scheduler_execution_attempts SET last_worker_sequence = ? WHERE attempt_id = ?'
      )
      .run(heartbeatBaseline.lastWorkerSequence, testEntityId('attempt', 'lease_default_binding'));

    coreDb.sqlite.exec(`
      CREATE TRIGGER reject_second_heartbeat_record
      BEFORE INSERT ON worker_control_records
      WHEN NEW.operation = 'heartbeat' AND NEW.record_key = '2'
      BEGIN
        SELECT RAISE(ABORT, 'injected heartbeat record failure');
      END
    `);
    const failedHeartbeatResponse = await app.request('/api/worker-control/heartbeat', {
      body: JSON.stringify(heartbeatEnvelope(lineage, 2, 'running')),
      headers: {
        authorization: `Bearer ${registration.token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });
    coreDb.sqlite.exec('DROP TRIGGER reject_second_heartbeat_record');
    const failedSequence = coreDb.sqlite
      .prepare(
        "SELECT COUNT(*) AS count FROM worker_control_sequence_fingerprints WHERE operation = 'heartbeat' AND sequence = ?"
      )
      .get(2) as { count: number };
    const failedRecord = coreDb.sqlite
      .prepare(
        "SELECT COUNT(*) AS count FROM worker_control_records WHERE operation = 'heartbeat' AND record_key = ?"
      )
      .get('2') as { count: number };
    const leaseAfterFailure = requireNanoHostExecutionAttempt(
      coreDb,
      testEntityId('attempt', 'lease_default_binding')
    );

    expect(failedHeartbeatResponse.status).toBe(500);
    expect.soft(failedSequence.count).toBe(0);
    expect.soft(failedRecord.count).toBe(0);
    expect.soft(leaseAfterFailure).toMatchObject({
      heartbeatDeadline: heartbeatBaseline.heartbeatDeadline,
      lastAcceptedHeartbeatAt: heartbeatBaseline.lastAcceptedHeartbeatAt,
      lastWorkerSequence: heartbeatBaseline.lastWorkerSequence,
      phase: heartbeatBaseline.phase,
    });
    coreDb.sqlite
      .prepare(
        "DELETE FROM worker_control_sequence_fingerprints WHERE operation = 'heartbeat' AND sequence = ?"
      )
      .run(2);
    coreDb.sqlite
      .prepare(
        `UPDATE scheduler_execution_attempts
         SET phase = ?, heartbeat_deadline = ?, last_accepted_heartbeat_at = ?, last_worker_sequence = ?
         WHERE attempt_id = ?`
      )
      .run(
        heartbeatBaseline.phase,
        heartbeatBaseline.heartbeatDeadline,
        heartbeatBaseline.lastAcceptedHeartbeatAt,
        heartbeatBaseline.lastWorkerSequence,
        testEntityId('attempt', 'lease_default_binding')
      );
    coreDb.sqlite
      .prepare(
        "UPDATE scheduler_execution_attempts SET heartbeat_deadline = '2000-01-01T00:00:00.000Z' WHERE attempt_id = ?"
      )
      .run(testEntityId('attempt', 'lease_default_binding'));
    const staleResponse = await app.request('/api/worker-control/heartbeat', {
      body: JSON.stringify(heartbeatEnvelope(lineage, 2, 'running')),
      headers: {
        authorization: `Bearer ${registration.token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });
    const staleBody = (await staleResponse.json()) as { code: string };

    expect(staleResponse.status).toBe(403);
    expect(staleBody.code).toBe('worker_control_lease_not_live');
    markWorkerControlBackendSessionCleaned(coreDb, backendLeaseId);
    await closeOwnedExecutionAttempt(coreDb, {
      attemptId: testEntityId('attempt', 'lease_default_binding'),
      firstTerminalCause: 'completed',
      outcome: 'completed',
    });

    expect(() =>
      gateway.recordHeartbeat({
        authorization: `Bearer ${registration.token}`,
        ...heartbeatEnvelope(lineage, 3, 'running'),
      })
    ).toThrowError(
      expect.objectContaining({
        code: 'worker_control_lease_not_live',
        status: 403,
      }) as WorkerControlGatewayError
    );

    coreDb.sqlite.close();
  });

  it('rejects non-lease tokens on the default database gateway', async () => {
    const coreDb = openCoreDb(mkdtempSync(join(tmpdir(), 'openkit-worker-control-non-lease-')));
    const { environmentPackage, lineage, store } = createWorkerControlRouteFixture();

    try {
      applyMigrations(coreDb);
      ensureLocalUser(coreDb);
      recordWorkspaceOwnerMembership({
        coreDb,
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        ownerUserId: LOCAL_USER_ID,
      });
      const gateway = createDefaultWorkerControlGateway(coreDb);
      const registration = registerDurableWorkerControlSession(
        gateway,
        environmentPackage,
        'lease-binding:missing_lease'
      );
      const app = createApp({ coreDb, mode: 'server', store, workerControlGateway: gateway });
      const response = await app.request('/api/worker-control/heartbeat', {
        body: JSON.stringify(heartbeatEnvelope(lineage, 1, 'running')),
        headers: {
          authorization: `Bearer ${registration.token}`,
          'content-type': 'application/json',
        },
        method: 'POST',
      });
      const body = (await response.json()) as { code: string };

      expect(response.status).toBe(401);
      expect(body.code).toBe('worker_control_unauthorized');
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('keeps worker-control database failures as internal server errors', async () => {
    const coreDb = openCoreDb(mkdtempSync(join(tmpdir(), 'openkit-worker-control-db-error-')));
    const { environmentPackage, lineage, store } = createWorkerControlRouteFixture();

    applyMigrations(coreDb);
    ensureLocalUser(coreDb);
    recordWorkspaceOwnerMembership({
      coreDb,
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
      ownerUserId: LOCAL_USER_ID,
    });
    const gateway = createDefaultWorkerControlGateway(coreDb);
    const registration = gateway.registerSession(environmentPackage, {
      sandboxBindingRef: 'lease-binding:database_failure',
    });
    const app = createApp({ mode: 'server', store, workerControlGateway: gateway });

    coreDb.sqlite.close();
    const response = await app.request('/api/worker-control/heartbeat', {
      body: JSON.stringify(heartbeatEnvelope(lineage, 1, 'running')),
      headers: {
        authorization: `Bearer ${registration.token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });

    expect(response.status).toBe(500);
  });

  it.each([
    ['missing', {}],
    ['null', { stopReason: null }],
    ['empty', { stopReason: '' }],
    ['whitespace', { stopReason: '   ' }],
  ])('rejects %s final-status stopReason', async (_label, bodyOverride) => {
    const { app, environmentPackage, gateway, lineage, token } = createWorkerControlRouteFixture();
    const response = await app.request('/api/worker-control/final-status', {
      body: JSON.stringify({
        body: { status: 'completed', ...bodyOverride },
        lineage,
        operation: 'final_status',
        schemaVersion: 2,
        sequence: 7,
      }),
      headers: {
        authorization: `Bearer ${token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });
    const responseBody = (await response.json()) as { code: string };

    expect(response.status).toBe(400);
    expect(responseBody.code).toBe('invalid_request');
    expect(gateway.getSessionSnapshot(environmentPackage.snapshotId)?.events).toEqual([]);
  });

  it('records final status as the exact canonical terminal event', async () => {
    const { app, environmentPackage, gateway, lineage, token } = createWorkerControlRouteFixture();
    const response = await app.request('/api/worker-control/final-status', {
      body: JSON.stringify({
        body: {
          diagnostics: { stderr: 'Product-safe failure summary.' },
          evidenceManifestDigests: { runtime: 'sha256:runtime' },
          status: 'failed',
          stopReason: 'worker-runtime-failed',
        },
        lineage,
        operation: 'final_status',
        schemaVersion: 2,
        sequence: 7,
      }),
      headers: {
        authorization: `Bearer ${token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });

    expect(response.status, await response.clone().text()).toBe(200);
    expect(gateway.getSessionSnapshot(environmentPackage.snapshotId)?.events).toEqual([
      {
        event: {
          data: {
            diagnostics: { stderr: 'Product-safe failure summary.' },
            evidenceManifestDigests: { runtime: 'sha256:runtime' },
            status: 'failed',
            stopReason: 'worker-runtime-failed',
          },
          type: 'turn.failed',
        },
        kind: 'event',
        lineage,
        schemaVersion: 1,
        sequence: 7,
      },
    ]);
  });

  it.each([
    'turn.completed',
    'turn.failed',
  ] as const)('rejects direct %s event append outside final status', async (eventType) => {
    const { app, environmentPackage, gateway, lineage, token } = createWorkerControlRouteFixture();
    const response = await app.request('/api/worker-control/events/append', {
      body: JSON.stringify({
        lineage,
        record: {
          event: {
            data: {
              evidenceManifestDigests: {},
              status: eventType === 'turn.completed' ? 'completed' : 'failed',
              stopReason: eventType === 'turn.completed' ? 'completed' : 'failed',
            },
            type: eventType,
          },
          kind: 'event',
          lineage,
          schemaVersion: 1,
          sequence: 7,
        },
      }),
      headers: {
        authorization: `Bearer ${token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });
    const responseBody = (await response.json()) as { code: string };

    expect(response.status).toBe(400);
    expect(responseBody.code).toBe('worker_control_terminal_event_requires_final_status');
    expect(gateway.getSessionSnapshot(environmentPackage.snapshotId)?.events).toEqual([]);
  });

  it('rolls back final status atomically before a successful restart retry', async () => {
    const coreDb = openCoreDb(mkdtempSync(join(tmpdir(), 'openkit-worker-control-final-')));
    const store = createDemoStore();
    const thread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Final status thread'
    );
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Complete worker',
      {
        kind: 'user',
        id: 'usr_00000000-0000-7000-8000-000000000001',
      }
    );
    const environmentPackage = AgentEnvironmentPackageSchema.parse(
      resolveAgentEnvironmentPackage({
        agentSetup: createTestAgentSetup(),
        agentSessionId: testEntityId('as', 'session_final_status'),
        triggerActor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
        backend: {
          kind: 'openshell',
        },
        createdAt: '2026-06-16T00:00:00.000Z',
        requestId: 'req_final_status',
        turn,
        workspaceCwd: '/workspace/repo',
        workspaceRoots: [],
      })
    );
    const lineage: WorkerControlLineage = {
      agentSessionId: environmentPackage.scope.agentSessionId,
      packageSnapshotId: environmentPackage.snapshotId,
      requestId: environmentPackage.scope.requestId,
      threadId: environmentPackage.scope.threadId,
      turnId: environmentPackage.scope.turnId,
      workspaceId: environmentPackage.scope.workspaceId,
    };

    applyMigrations(coreDb);
    ensureLocalUser(coreDb);
    recordWorkspaceOwnerMembership({
      coreDb,
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
      ownerUserId: LOCAL_USER_ID,
    });
    const gateway = createDefaultWorkerControlGateway(coreDb);
    const workspaceDb = openWorkspaceDb(coreDb.dataRoot, lineage.workspaceId);
    applyScopedMigrations(workspaceDb);
    recordAgentEnvironmentPackageSnapshot(workspaceDb, {
      createdAt: environmentPackage.createdAt,
      environmentPackage,
    });
    recordWorkspaceMaterializationRecords(workspaceDb, [
      {
        backendKind: 'openshell',
        base: { commit: 'abc123', contentDigest: null },
        createdAt: '2026-06-16T00:00:01.000Z',
        id: 'wmr_final_status',
        inputSnapshotId: 'wis_final_status',
        materializedRootRef: 'workspace://ws_00000000-0000-7000-8000-000000000001/repo_default',
        packageSnapshotId: lineage.packageSnapshotId,
        policyDigest: 'sha256:policy',
        readinessEvidence: [{ kind: 'backend.ready', ref: 'version:0.0.63' }],
        sourceId: 'repo_default',
        strategy: 'git',
        workerSessionId: 'sandbox_final_status',
        workspaceId: lineage.workspaceId,
      },
    ]);
    createSchedulerAdmissionEntry(coreDb, {
      backendId: 'nanohost',
      triggerActor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
      profileRef: environmentPackage.agent.profileId,
      queueEntryId: 'queue_final_status',
      requestId: lineage.requestId,
      requestedAgentId: environmentPackage.agent.agentId,
      threadId: lineage.threadId,
      turnId: lineage.turnId,
      turnInput: 'Run final status route test',
      workspaceId: lineage.workspaceId,
    });
    const submittedAttempt = recordTestExecutionAttempt(coreDb, {
      entry: requireSchedulerAdmissionEntry(coreDb, 'queue_final_status'),
      attemptId: testEntityId('attempt', 'lease_final_status'),
      agentSessionId: lineage.agentSessionId,
      inputRef: lineage.packageSnapshotId,
      bindingRef: 'lease-binding:lease_final_status',
      sessionCompatibilityKey: 'fixture-compatibility',
      now: () => '2099-07-05T00:00:02.000Z',
      operationId: `fixture-submit:${String(testEntityId('attempt', 'lease_final_status'))}`,
    });
    attemptActionOwners.acceptSchedulerExecutionObservation(coreDb, {
      ...attemptActionOwners.schedulerExecutionCorrelation(submittedAttempt),
      disposition: 'accepted',
      execution: 'running',
      fenceRef: null,
      outcomeRef: null,
    });
    bindNanoHostAttemptRouteTokenHashes(coreDb, {
      attemptId: testEntityId('attempt', 'lease_final_status'),
      now: () => '2099-07-05T00:00:03.000Z',
      sandboxBindingRef: 'lease-binding:lease_final_status',
      workerCapabilityTokenHash: hashWorkerRouteToken(
        workerRouteToken('lease-binding:lease_final_status', 'capability')
      ),
      workerControlTokenHash: hashWorkerRouteToken(
        workerRouteToken('lease-binding:lease_final_status', 'worker-control')
      ),
      workerInferenceTokenHash: hashWorkerRouteToken(
        workerRouteToken('lease-binding:lease_final_status', 'inference')
      ),
    });
    const backendLeaseId = recordWorkerControlBackendSession(
      coreDb,
      environmentPackage,
      lineage,
      'lease-binding:lease_final_status',
      'sandbox_final_status'
    );
    acceptNanoHostAttemptHeartbeat(coreDb, {
      heartbeatTimeoutMs: 30_000,
      attemptId: testEntityId('attempt', 'lease_final_status'),
      now: () => '2099-07-05T00:00:10.000Z',
      workerSequence: 1,
    });
    const registration = registerDurableWorkerControlSession(
      gateway,
      environmentPackage,
      'lease-binding:lease_final_status'
    );
    const app = createApp({ coreDb, mode: 'server', store, workerControlGateway: gateway });
    const finalStatusBody = JSON.stringify({
      schemaVersion: 2,
      lineage,
      operation: 'final_status',
      sequence: 7,
      body: {
        status: 'completed',
        stopReason: 'completed',
      },
    });

    coreDb.sqlite.exec(`
      CREATE TRIGGER reject_final_status_release
      BEFORE UPDATE OF phase ON scheduler_execution_attempts
      WHEN OLD.attempt_id = '${testEntityId('attempt', 'lease_final_status')}' AND NEW.phase = 'closing'
      BEGIN
        SELECT RAISE(ABORT, 'injected final status release failure');
      END
    `);
    const failed = await app.request('/api/worker-control/final-status', {
      body: finalStatusBody,
      headers: {
        authorization: `Bearer ${registration.token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });
    const recordsAfterFailure = coreDb.sqlite
      .prepare(
        `SELECT operation
           FROM worker_control_records
          WHERE turn_id = ? AND operation IN ('event_append', 'final_status')
          ORDER BY operation`
      )
      .all(lineage.turnId);
    const fingerprintsAfterFailure = coreDb.sqlite
      .prepare(
        `SELECT operation
           FROM worker_control_sequence_fingerprints
          WHERE turn_id = ? AND operation IN ('event_append', 'final_status')
          ORDER BY operation`
      )
      .all(lineage.turnId);

    expect(failed.status).toBe(500);
    expect.soft(recordsAfterFailure).toEqual([]);
    expect.soft(fingerprintsAfterFailure).toEqual([]);
    expect(['open', 'closing']).toContain(
      observeExecutionAttempts(coreDb).find(
        (attempt) => attempt.attempt_id === testEntityId('attempt', 'lease_final_status')
      )?.phase
    );

    coreDb.sqlite.exec('DROP TRIGGER reject_final_status_release');
    const rebuiltGateway = createDefaultWorkerControlGateway(coreDb);
    const rebuiltApp = createApp({
      coreDb,
      mode: 'server',
      store,
      workerControlGateway: rebuiltGateway,
    });
    const accepted = await rebuiltApp.request('/api/worker-control/final-status', {
      body: finalStatusBody,
      headers: {
        authorization: `Bearer ${registration.token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });

    const acceptedRecords = coreDb.sqlite
      .prepare(
        `SELECT operation, COUNT(*) AS count
           FROM worker_control_records
          WHERE turn_id = ? AND operation IN ('event_append', 'final_status')
          GROUP BY operation
          ORDER BY operation`
      )
      .all(lineage.turnId);
    const acceptedFingerprints = coreDb.sqlite
      .prepare(
        `SELECT operation, COUNT(*) AS count
           FROM worker_control_sequence_fingerprints
          WHERE turn_id = ? AND operation IN ('event_append', 'final_status')
          GROUP BY operation
          ORDER BY operation`
      )
      .all(lineage.turnId);
    const acceptedEvents = listWorkerControlAcceptedEvents(coreDb, lineage);
    const transcriptImport = importWorkerTranscript(
      store,
      environmentPackage,
      { eventsJsonl: `${JSON.stringify(acceptedEvents[0])}\n` },
      { acceptedLiveEvents: acceptedEvents }
    );

    expect(accepted.status).toBe(200);
    expect.soft(acceptedEvents).toEqual([
      {
        event: {
          data: {
            evidenceManifestDigests: {},
            status: 'completed',
            stopReason: 'completed',
          },
          type: 'turn.completed',
        },
        kind: 'event',
        lineage,
        schemaVersion: 1,
        sequence: 7,
      },
    ]);
    expect.soft(transcriptImport).toMatchObject({
      dedupedEventSequences: [7],
      diagnostics: [],
      rejectedEventSequences: [],
    });
    expect.soft(acceptedRecords).toEqual([
      { count: 1, operation: 'event_append' },
      { count: 1, operation: 'final_status' },
    ]);
    expect.soft(acceptedFingerprints).toEqual([
      { count: 1, operation: 'event_append' },
      { count: 1, operation: 'final_status' },
    ]);
    expect(
      observeExecutionAttempts(coreDb).find(
        (attempt) => attempt.attempt_id === testEntityId('attempt', 'lease_final_status')
      )?.phase
    ).toBe('closing');

    expect(listBackendWorkspaceHandles(workspaceDb, lineage.workspaceId)).toEqual([
      expect.objectContaining({
        cleanupStatus: 'retained',
        id: 'bwh_wmr_final_status',
        packageSnapshotId: lineage.packageSnapshotId,
        workerSessionId: 'sandbox_final_status',
      }),
    ]);
    expect(
      resolveNanoHostAttemptTokenBinding(coreDb, {
        sandboxBindingRef: 'lease-binding:lease_final_status',
        lineage,
      })
    ).toEqual({ status: 'rejected', reason: 'attempt-not-live' });

    const reconcileAcceptedFinalStatus = vi.fn(async () => undefined);
    await runNanoHostAttemptRecoveryMaintenance(coreDb, {
      executionBackend: {
        id: 'nanohost',
        submit: vi.fn(),
        inspect: vi.fn(),
        cancel: vi.fn(),
        release: vi.fn(),
      },
      cleanupBackendSession: vi.fn(),
      prepareBackendCleanup: vi.fn(),
      restoreBackendSession: vi.fn(),
      projectRecoveredTurn: vi.fn(),
      reconcileAcceptedFinalStatus,
      now: () => new Date(Date.now() + 60_000).toISOString(),
    });
    expect(reconcileAcceptedFinalStatus).toHaveBeenCalledOnce();
    expect(listWorkspaceReconciliationRecords(workspaceDb, lineage.workspaceId)).toEqual([]);
    expect(
      observeExecutionAttempts(coreDb).find(
        (attempt) => attempt.attempt_id === testEntityId('attempt', 'lease_final_status')
      )?.phase
    ).toBe('closing');
    expect(
      requireNanoHostExecutionAttempt(coreDb, testEntityId('attempt', 'lease_final_status'))
    ).toMatchObject({
      heartbeatDeadline: '2099-07-05T00:00:40.000Z',
    });

    const completedTurn = {
      id: lineage.turnId,
      status: 'completed' as const,
      threadId: lineage.threadId,
      workspaceId: lineage.workspaceId,
    };
    markWorkerControlBackendSessionCleaned(coreDb, backendLeaseId);
    // This route-level fixture supplies settled handoff barriers after checking the accepted
    // transcript and retained Workspace handle; executor integration tests prove their producers.
    attemptActionOwners.markSchedulerAttemptForTerminalTurn(coreDb, completedTurn);
    const closing = attemptActionOwners.requireSchedulerExecutionAttempt(
      coreDb,
      testEntityId('attempt', 'lease_final_status')
    );
    const release = {
      correlation: attemptActionOwners.schedulerExecutionCorrelation(closing),
      proof: {
        terminalHandoff: true,
        output: true,
        evidence: true,
        outsideWorkspaceCollection: true,
        integrationDrain: true,
        routesRevoked: true,
      },
      fenceRef: 'fixture-cleaned:lease_final_status',
    };
    attemptActionOwners.closeSchedulerExecutionAttemptWithFence(coreDb, release);
    attemptActionOwners.closeSchedulerExecutionAttemptWithFence(coreDb, release);

    expect(
      observeExecutionAttempts(coreDb).find(
        (attempt) => attempt.attempt_id === testEntityId('attempt', 'lease_final_status')
      )?.phase
    ).toBe('closed');

    workspaceDb.sqlite.close();
    coreDb.sqlite.close();
  });

  it('resolves a live final-status binding inside its Core transaction', async () => {
    const coreDb = openCoreDb(mkdtempSync(join(tmpdir(), 'openkit-final-status-live-race-')));
    const { environmentPackage, lineage, store } = createWorkerControlRouteFixture();

    try {
      applyMigrations(coreDb);
      ensureLocalUser(coreDb);
      recordWorkspaceOwnerMembership({
        coreDb,
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        ownerUserId: LOCAL_USER_ID,
      });
      const binding = createDurableWorkerControlLease(
        coreDb,
        environmentPackage,
        lineage,
        'final_status_live_race'
      );
      const gateway = new WorkerControlGateway({
        acceptedRecordRecorder: createWorkerControlAcceptedRecordRecorder(coreDb),
        resolveFinalStatusTokenBinding: (input) =>
          resolveWorkerControlFinalStatusTokenBinding(coreDb, input),
        runFinalStatusTransaction: (operation) => {
          coreDb.sqlite
            .prepare('UPDATE scheduler_execution_attempts SET binding_ref = ? WHERE attempt_id = ?')
            .run('revoked-binding', testEntityId('attempt', 'lease_final_status_live_race'));
          return coreDb.sqlite.transaction(operation)();
        },
        sequenceRecorder: createWorkerControlSequenceRecorder(coreDb),
      });
      registerDurableWorkerControlSession(gateway, environmentPackage, binding);
      const app = createApp({ coreDb, mode: 'server', store, workerControlGateway: gateway });
      const response = await app.request('/api/worker-control/final-status', {
        body: JSON.stringify({
          body: { status: 'completed', stopReason: 'completed' },
          lineage,
          operation: 'final_status',
          schemaVersion: 2,
          sequence: 7,
        }),
        headers: {
          authorization: `Bearer ${workerRouteToken(binding, 'worker-control')}`,
          'content-type': 'application/json',
        },
        method: 'POST',
      });
      const acceptedRecordCount = coreDb.sqlite
        .prepare(
          `SELECT COUNT(*) AS count
             FROM worker_control_records
            WHERE turn_id = ? AND operation IN ('event_append', 'final_status')`
        )
        .get(lineage.turnId) as { count: number };
      const fingerprintCount = coreDb.sqlite
        .prepare(
          `SELECT COUNT(*) AS count
             FROM worker_control_sequence_fingerprints
            WHERE turn_id = ? AND operation IN ('event_append', 'final_status')`
        )
        .get(lineage.turnId) as { count: number };

      expect(response.status).toBe(401);
      expect.soft(acceptedRecordCount.count).toBe(0);
      expect.soft(fingerprintCount.count).toBe(0);
      expect(['open', 'closing']).toContain(
        observeExecutionAttempts(coreDb).find(
          (attempt) =>
            attempt.attempt_id === testEntityId('attempt', 'lease_final_status_live_race')
        )?.phase
      );
      expect(
        observeExecutionAttempts(coreDb).find(
          (attempt) =>
            attempt.attempt_id === testEntityId('attempt', 'lease_final_status_live_race')
        )
      ).toMatchObject({ binding_ref: 'revoked-binding' });
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('rejects exact final-status replay when the authority deadline expires at transaction entry', async () => {
    const coreDb = openCoreDb(mkdtempSync(join(tmpdir(), 'openkit-final-status-replay-race-')));
    const { environmentPackage, lineage, store } = createWorkerControlRouteFixture();
    let transactionCount = 0;

    try {
      applyMigrations(coreDb);
      ensureLocalUser(coreDb);
      recordWorkspaceOwnerMembership({
        coreDb,
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        ownerUserId: LOCAL_USER_ID,
      });
      const binding = createDurableWorkerControlLease(
        coreDb,
        environmentPackage,
        lineage,
        'final_status_replay_race'
      );
      const backendLeaseId = recordWorkerControlBackendSession(
        coreDb,
        environmentPackage,
        lineage,
        binding,
        'sandbox_final_status_replay_race'
      );
      const gateway = new WorkerControlGateway({
        acceptedRecordRecorder: createWorkerControlAcceptedRecordRecorder(coreDb),
        onFinalStatusAccepted: (input) => {
          const resolution = resolveNanoHostAttemptTokenBinding(coreDb, input);

          if (resolution.status !== 'accepted') {
            throw new Error('Expected a live lease during initial final-status acceptance.');
          }

          beginOwnedAttemptCloseout(coreDb, {
            attemptId: resolution.attempt.attemptId,
            firstTerminalCause: 'worker-final-status',
          });
        },
        resolveFinalStatusTokenBinding: (input) =>
          resolveWorkerControlFinalStatusTokenBinding(coreDb, input),
        runFinalStatusTransaction: (operation) => {
          transactionCount += 1;
          if (transactionCount === 2) {
            coreDb.sqlite
              .prepare('UPDATE scheduler_execution_attempts SET deadline = ? WHERE attempt_id = ?')
              .run(
                '2000-01-01T00:00:00.000Z',
                testEntityId('attempt', 'lease_final_status_replay_race')
              );
            markWorkerControlBackendSessionCleaned(coreDb, backendLeaseId);
            beginOwnedAttemptCloseout(coreDb, {
              attemptId: testEntityId('attempt', 'lease_final_status_replay_race'),

              firstTerminalCause: 'worker-final-status',
            });
          }
          return coreDb.sqlite.transaction(operation)();
        },
        sequenceRecorder: createWorkerControlSequenceRecorder(coreDb),
      });
      registerDurableWorkerControlSession(gateway, environmentPackage, binding);
      const app = createApp({ coreDb, mode: 'server', store, workerControlGateway: gateway });
      const request = {
        body: JSON.stringify({
          body: { status: 'completed', stopReason: 'completed' },
          lineage,
          operation: 'final_status',
          schemaVersion: 2,
          sequence: 7,
        }),
        headers: {
          authorization: `Bearer ${workerRouteToken(binding, 'worker-control')}`,
          'content-type': 'application/json',
        },
        method: 'POST' as const,
      };
      const accepted = await app.request('/api/worker-control/final-status', request);
      const replay = await app.request('/api/worker-control/final-status', request);
      const acceptedRecordCount = coreDb.sqlite
        .prepare(
          `SELECT COUNT(*) AS count
             FROM worker_control_records
            WHERE turn_id = ? AND operation IN ('event_append', 'final_status')`
        )
        .get(lineage.turnId) as { count: number };
      const fingerprintCount = coreDb.sqlite
        .prepare(
          `SELECT COUNT(*) AS count
             FROM worker_control_sequence_fingerprints
            WHERE turn_id = ? AND operation IN ('event_append', 'final_status')`
        )
        .get(lineage.turnId) as { count: number };

      expect(accepted.status).toBe(200);
      expect(replay.status).toBe(403);
      expect.soft(acceptedRecordCount.count).toBe(2);
      expect.soft(fingerprintCount.count).toBe(2);
      expect(
        observeExecutionAttempts(coreDb).find(
          (attempt) =>
            attempt.attempt_id === testEntityId('attempt', 'lease_final_status_replay_race')
        )?.phase
      ).toBe('closing');
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('retains the backend handle in the canonical Workspace across final-status replay', async () => {
    const coreDb = openCoreDb(mkdtempSync(join(tmpdir(), 'openkit-final-status-workspace-')));
    const sourceCommit = 'a'.repeat(40);
    const { environmentPackage, lineage, store } = createWorkerControlRouteFixture([
      {
        access: 'read-write',
        id: 'repo_default',
        sourceCommit,
        sourceKind: 'remote-git',
        workerPath: '/workspace/repo',
      },
    ]);
    const workspaceDb = openWorkspaceDb(coreDb.dataRoot, lineage.workspaceId);

    try {
      applyMigrations(coreDb);
      ensureLocalUser(coreDb);
      recordWorkspaceOwnerMembership({
        coreDb,
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        ownerUserId: LOCAL_USER_ID,
      });
      const binding = createDurableWorkerControlLease(
        coreDb,
        environmentPackage,
        lineage,
        'final_status_workspace'
      );
      const backendLeaseId = recordWorkerControlBackendSession(
        coreDb,
        environmentPackage,
        lineage,
        binding,
        'sandbox_final_status_workspace'
      );
      applyScopedMigrations(workspaceDb);
      const inputSnapshots = buildWorkspaceInputSnapshots({
        backendCapabilities: environmentPackage.backend.requiredCapabilities,
        backendKind: 'openshell',
        createdAt: '2026-06-16T00:00:01.000Z',
        environmentPackage,
      });
      const materializations = buildWorkspaceMaterializationRecords({
        createdAt: '2026-06-16T00:00:01.000Z',
        inputSnapshots,
        materialization: {
          backendKind: 'openshell',
          backendStatus: { health: 'ready', version: '0.0.80' },
          packageSnapshotId: environmentPackage.snapshotId,
          requiredCapabilities: environmentPackage.backend.requiredCapabilities,
          sandbox: { name: 'sandbox_final_status_workspace', state: 'created' },
          workspaceInputs: environmentPackage.workspace.inputs.map((input) => ({
            id: input.id,
            target: input.target,
          })),
        },
      });
      recordWorkspaceInputSnapshots(workspaceDb, inputSnapshots);
      recordWorkspaceMaterializationRecords(workspaceDb, materializations);
      const gateway = createDefaultWorkerControlGateway(coreDb);
      const app = createApp({ coreDb, mode: 'server', store, workerControlGateway: gateway });
      const request = {
        body: JSON.stringify({
          body: { status: 'completed', stopReason: 'completed' },
          lineage,
          operation: 'final_status',
          schemaVersion: 2,
          sequence: 7,
        }),
        headers: {
          authorization: `Bearer ${workerRouteToken(binding, 'worker-control')}`,
          'content-type': 'application/json',
        },
        method: 'POST' as const,
      };
      const absoluteDeadline = absoluteAttemptDeadline(coreDb, lineage.turnId);
      const response = await app.request('/api/worker-control/final-status', request);

      expect(response.status).toBe(200);
      expect(listBackendWorkspaceHandles(workspaceDb, lineage.workspaceId)).toEqual([
        expect.objectContaining({ cleanupStatus: 'retained' }),
      ]);

      updateBackendWorkspaceHandleCleanupStatus(
        workspaceDb,
        lineage.workspaceId,
        lineage.packageSnapshotId,
        'pending',
        '2026-06-16T00:00:02.000Z'
      );
      const restartedGateway = createDefaultWorkerControlGateway(coreDb);
      const restartedApp = createApp({
        coreDb,
        mode: 'server',
        store,
        workerControlGateway: restartedGateway,
      });
      expect(absoluteAttemptDeadline(coreDb, lineage.turnId)).toBe(absoluteDeadline);
      const replay = await restartedApp.request('/api/worker-control/final-status', request);

      expect(absoluteAttemptDeadline(coreDb, lineage.turnId)).toBe(absoluteDeadline);
      expect(replay.status).toBe(200);
      expect(listBackendWorkspaceHandles(workspaceDb, lineage.workspaceId)).toEqual([
        expect.objectContaining({ cleanupStatus: 'retained' }),
      ]);

      markWorkerControlBackendSessionCleaned(coreDb, backendLeaseId);
      const releasingLease = requireNanoHostExecutionAttempt(
        coreDb,
        testEntityId('attempt', 'lease_final_status_workspace')
      );
      beginOwnedAttemptCloseout(coreDb, {
        attemptId: releasingLease.attemptId,

        firstTerminalCause: 'worker-final-status',
      });
      const reconcileAcceptedFinalStatus = vi.fn(
        async (session: NonNullable<ReturnType<typeof getWorkerBackendSession>>) => {
          expect(session.attemptId).toBe(backendLeaseId);
          expect(session.state).toBe('cleaned');
          // This transport fixture has no physical worker; the normal terminal callback settles its actual Workspace projection before modeled release.
          const completedAt = session.physicalCleanedAt!;
          const projection = projectWorkerBackendCleanup(workspaceDb, {
            agentSessionId: lineage.agentSessionId,
            backendType: session.backendKind,
            backendVersion: session.backendVersion,
            completedAt,
            outcome: 'succeeded',
            backendSessionId: 'sandbox_final_status_workspace',
            environmentPackage,
            packageSnapshotId: lineage.packageSnapshotId,
            placement: 'local',
            threadId: lineage.threadId,
            turnId: lineage.turnId,
            workerImage: environmentPackage.runtime.image.ref,
            workspaceHandoffState: 'complete',
            workspaceId: lineage.workspaceId,
          });
          expect(projection.workspaceHandoffComplete).toBe(true);
          store.createAgentSession({
            id: lineage.agentSessionId,
            agentId: environmentPackage.agent.agentId,
            workspaceId: lineage.workspaceId,
            threadId: lineage.threadId,
            status: 'idle',
            message: null,
            environmentPackageSnapshotId: lineage.packageSnapshotId,
            createdAt: completedAt,
            updatedAt: completedAt,
          });
          const terminal = store.updateTurn(lineage.turnId, {
            agentId: environmentPackage.agent.agentId,
            agentSessionId: lineage.agentSessionId,
            status: 'completed',
            completedAt,
          });
          store.emitTurnEvent(
            lineage.turnId,
            {
              event: 'turn.completed',
              requestId: lineage.requestId,
              workspaceId: lineage.workspaceId,
              threadId: lineage.threadId,
              turnId: lineage.turnId,
              data: { type: 'turn-completed', stopReason: 'completed', turn: terminal },
            },
            ALREADY_DECIDED_PUBLICATION_ADMISSION
          );
          await closeOwnedExecutionAttempt(coreDb, {
            attemptId: session.attemptId,
            firstTerminalCause: 'turn-completed',
            outcome: `turn:${lineage.turnId}:completed`,
          });
        }
      );
      await runNanoHostAttemptRecoveryMaintenance(coreDb, {
        executionBackend: new SimulatedTurnExecutor({ coreDb }),
        now: () => new Date(Date.parse(releasingLease.deadline!) + 1).toISOString(),
        cleanupBackendSession: vi.fn(async () => {}),
        prepareBackendCleanup: vi.fn(),
        restoreBackendSession: vi.fn(async () => {}),
        projectRecoveredTurn: vi.fn(async () => ({ status: 'interrupted' as const })),
        reconcileAcceptedFinalStatus,
      });
      expect(reconcileAcceptedFinalStatus).toHaveBeenCalledTimes(1);
      expect(listBackendWorkspaceHandles(workspaceDb, lineage.workspaceId)).toEqual([
        expect.objectContaining({ cleanupStatus: 'cleaned' }),
      ]);
      expect(listWorkspaceReconciliationRecords(workspaceDb, lineage.workspaceId)).toEqual([]);
      expect(
        observeExecutionAttempts(coreDb).find(
          (attempt) =>
            attempt.attempt_id === testEntityId('attempt', 'lease_final_status_workspace')
        )?.phase
      ).toBe('closed');
    } finally {
      workspaceDb.sqlite.close();
      coreDb.sqlite.close();
    }
  });

  it('replays only exact final status while its lease is releasing', async () => {
    const coreDb = openCoreDb(mkdtempSync(join(tmpdir(), 'openkit-final-status-replay-')));
    const { environmentPackage, lineage, store } = createWorkerControlRouteFixture();

    try {
      applyMigrations(coreDb);
      ensureLocalUser(coreDb);
      recordWorkspaceOwnerMembership({
        coreDb,
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        ownerUserId: LOCAL_USER_ID,
      });
      const binding = createDurableWorkerControlLease(
        coreDb,
        environmentPackage,
        lineage,
        'final_status_replay'
      );
      const gateway = createDefaultWorkerControlGateway(coreDb);
      const app = createApp({ coreDb, mode: 'server', store, workerControlGateway: gateway });
      const authorization = `Bearer ${workerRouteToken(binding, 'worker-control')}`;
      const finalStatusBody = JSON.stringify({
        body: { status: 'completed', stopReason: 'completed' },
        lineage,
        operation: 'final_status',
        schemaVersion: 2,
        sequence: 7,
      });
      const accepted = await app.request('/api/worker-control/final-status', {
        body: finalStatusBody,
        headers: { authorization, 'content-type': 'application/json' },
        method: 'POST',
      });

      expect(accepted.status).toBe(200);
      expect(
        observeExecutionAttempts(coreDb).find(
          (attempt) => attempt.attempt_id === testEntityId('attempt', 'lease_final_status_replay')
        )?.phase
      ).toBe('closing');

      const sameProcessReplay = await app.request('/api/worker-control/final-status', {
        body: finalStatusBody,
        headers: { authorization, 'content-type': 'application/json' },
        method: 'POST',
      });
      const restartedGateway = createDefaultWorkerControlGateway(coreDb);
      const restartedApp = createApp({
        coreDb,
        mode: 'server',
        store,
        workerControlGateway: restartedGateway,
      });
      const restartedReplay = await restartedApp.request('/api/worker-control/final-status', {
        body: finalStatusBody,
        headers: { authorization, 'content-type': 'application/json' },
        method: 'POST',
      });
      const rejectedEventAppend = await restartedApp.request('/api/worker-control/events/append', {
        body: JSON.stringify({
          lineage,
          record: {
            event: {
              data: {
                evidenceManifestDigests: {},
                status: 'completed',
                stopReason: 'completed',
              },
              type: 'turn.completed',
            },
            kind: 'event',
            lineage,
            schemaVersion: 1,
            sequence: 7,
          },
        }),
        headers: { authorization, 'content-type': 'application/json' },
        method: 'POST',
      });
      const acceptedRecords = coreDb.sqlite
        .prepare(
          `SELECT operation, COUNT(*) AS count
             FROM worker_control_records
            WHERE turn_id = ? AND operation IN ('event_append', 'final_status')
            GROUP BY operation
            ORDER BY operation`
        )
        .all(lineage.turnId);
      const acceptedFingerprints = coreDb.sqlite
        .prepare(
          `SELECT operation, COUNT(*) AS count
             FROM worker_control_sequence_fingerprints
            WHERE turn_id = ? AND operation IN ('event_append', 'final_status')
            GROUP BY operation
            ORDER BY operation`
        )
        .all(lineage.turnId);

      expect.soft(sameProcessReplay.status).toBe(200);
      expect.soft(restartedReplay.status).toBe(200);
      expect(rejectedEventAppend.status).not.toBe(200);
      expect.soft(acceptedRecords).toEqual([
        { count: 1, operation: 'event_append' },
        { count: 1, operation: 'final_status' },
      ]);
      expect.soft(acceptedFingerprints).toEqual([
        { count: 1, operation: 'event_append' },
        { count: 1, operation: 'final_status' },
      ]);
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('accepts supply refresh acknowledgements through the control envelope', async () => {
    const { app, environmentPackage, gateway, lineage, token } = createWorkerControlRouteFixture();

    const res = await app.request('/api/worker-control/supply-refresh-ack', {
      body: JSON.stringify({
        body: {
          refreshId: 'refresh_1',
          status: 'applied',
        },
        lineage,
        operation: 'supply_refresh_ack',
        schemaVersion: 2,
        sequence: 8,
      }),
      headers: {
        authorization: `Bearer ${token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });
    const body = (await res.json()) as { supplyRefreshAck: { refreshId: string; status: string } };

    expect(res.status).toBe(200);
    expect(body.supplyRefreshAck).toMatchObject({
      refreshId: 'refresh_1',
      status: 'applied',
    });
    const invalidOperation = await app.request('/api/worker-control/supply-refresh-ack', {
      body: JSON.stringify({
        body: { refreshId: 'refresh_2', status: 'applied' },
        lineage,
        operation: 'final_status',
        schemaVersion: 2,
        sequence: 9,
      }),
      headers: {
        authorization: `Bearer ${token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });

    expect(invalidOperation.status).toBe(400);
    expect(gateway.getSessionSnapshot(environmentPackage.snapshotId)?.supplyRefreshAcks).toEqual([
      expect.objectContaining({ refreshId: 'refresh_1', status: 'applied' }),
    ]);
  });

  it('retains accepted supply refresh acknowledgement evidence in Core', async () => {
    const coreDb = openCoreDb(mkdtempSync(join(tmpdir(), 'openkit-supply-refresh-ack-')));
    const store = createDemoStore();
    const thread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Supply refresh thread'
    );
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Control worker',
      {
        kind: 'user',
        id: 'usr_00000000-0000-7000-8000-000000000001',
      }
    );
    const environmentPackage = AgentEnvironmentPackageSchema.parse(
      resolveAgentEnvironmentPackage({
        agentSetup: createTestAgentSetup(),
        agentSessionId: testEntityId('as', 'session_supply_refresh'),
        triggerActor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
        backend: {
          kind: 'openshell',
        },
        createdAt: '2026-06-16T00:00:00.000Z',
        requestId: 'req_supply_refresh',
        turn,
        workspaceCwd: '/workspace/repo',
        workspaceRoots: [],
      })
    );
    const lineage: WorkerControlLineage = {
      agentSessionId: environmentPackage.scope.agentSessionId,
      packageSnapshotId: environmentPackage.snapshotId,
      requestId: environmentPackage.scope.requestId,
      threadId: environmentPackage.scope.threadId,
      turnId: environmentPackage.scope.turnId,
      workspaceId: environmentPackage.scope.workspaceId,
    };

    try {
      applyMigrations(coreDb);
      ensureLocalUser(coreDb);
      recordWorkspaceOwnerMembership({
        coreDb,
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        ownerUserId: LOCAL_USER_ID,
      });
      const gateway = createDefaultWorkerControlGateway(coreDb);
      createSchedulerAdmissionEntry(coreDb, {
        backendId: 'nanohost',
        triggerActor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
        profileRef: environmentPackage.agent.profileId,
        queueEntryId: 'queue_supply_refresh',
        requestedAgentId: environmentPackage.agent.agentId,
        threadId: lineage.threadId,
        turnId: lineage.turnId,
        turnInput: 'Run supply refresh worker',
        workspaceId: lineage.workspaceId,
      });
      const submittedAttempt = recordTestExecutionAttempt(coreDb, {
        entry: requireSchedulerAdmissionEntry(coreDb, 'queue_supply_refresh'),
        attemptId: testEntityId('attempt', 'lease_supply_refresh'),
        agentSessionId: lineage.agentSessionId,
        inputRef: lineage.packageSnapshotId,
        bindingRef: 'lease-binding:lease_supply_refresh',
        sessionCompatibilityKey: 'fixture-compatibility',
        now: () => new Date().toISOString(),
        operationId: `fixture-submit:${String(testEntityId('attempt', 'lease_supply_refresh'))}`,
      });
      attemptActionOwners.acceptSchedulerExecutionObservation(coreDb, {
        ...attemptActionOwners.schedulerExecutionCorrelation(submittedAttempt),
        disposition: 'accepted',
        execution: 'running',
        fenceRef: null,
        outcomeRef: null,
      });
      bindNanoHostAttemptRouteTokenHashes(coreDb, {
        attemptId: testEntityId('attempt', 'lease_supply_refresh'),
        sandboxBindingRef: 'lease-binding:lease_supply_refresh',
        workerCapabilityTokenHash: hashWorkerRouteToken(
          workerRouteToken('lease-binding:lease_supply_refresh', 'capability')
        ),
        workerControlTokenHash: hashWorkerRouteToken(
          workerRouteToken('lease-binding:lease_supply_refresh', 'worker-control')
        ),
        workerInferenceTokenHash: hashWorkerRouteToken(
          workerRouteToken('lease-binding:lease_supply_refresh', 'inference')
        ),
      });
      const registration = registerDurableWorkerControlSession(
        gateway,
        environmentPackage,
        'lease-binding:lease_supply_refresh'
      );
      const app = createApp({ coreDb, mode: 'server', store, workerControlGateway: gateway });

      const res = await app.request('/api/worker-control/supply-refresh-ack', {
        body: JSON.stringify({
          body: {
            refreshId: 'refresh_safe_1',
            status: 'applied',
          },
          lineage,
          operation: 'supply_refresh_ack',
          schemaVersion: 2,
          sequence: 4,
        }),
        headers: {
          authorization: `Bearer ${registration.token}`,
          'content-type': 'application/json',
        },
        method: 'POST',
      });

      expect(res.status).toBe(200);
      const durableAck = coreDb.sqlite
        .prepare(
          "SELECT record_json AS recordJson FROM worker_control_records WHERE turn_id = ? AND operation = 'supply_refresh_ack'"
        )
        .get(lineage.turnId) as { recordJson: string };
      expect(JSON.parse(durableAck.recordJson)).toMatchObject({
        refreshId: 'refresh_safe_1',
        status: 'applied',
      });
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('accepts capability summaries through the control envelope', async () => {
    const { app, environmentPackage, gateway, lineage, token } = createWorkerControlRouteFixture();

    const res = await app.request('/api/worker-control/capability-summary', {
      body: JSON.stringify({
        body: {
          capabilityCallId: testEntityId('cap', 'capability_1'),
          diagnostics: [],
          family: 'knowledge.search',
          inputSummary: 'Search project knowledge.',
          lineage,
          outputSummary: 'Returned one entry.',
          schemaVersion: 1,
          sequence: 10,
          status: 'succeeded',
        },
        lineage,
        operation: 'capability_summary',
        schemaVersion: 2,
        sequence: 10,
      }),
      headers: {
        authorization: `Bearer ${token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });
    const body = (await res.json()) as {
      response: { accepted: boolean; nextExpectedSequence: number };
    };

    expect(res.status).toBe(200);
    expect(body.response).toMatchObject({
      accepted: true,
      nextExpectedSequence: 11,
    });
    expect(gateway.getSessionSnapshot(environmentPackage.snapshotId)?.capabilitySummaries).toEqual([
      expect.objectContaining({
        capabilityCallId: testEntityId('cap', 'capability_1'),
        status: 'succeeded',
      }),
    ]);
  });

  it('rejects oversized simple control requests before sandbox authentication', async () => {
    const { app, lineage } = createWorkerControlRouteFixture();
    const padding = 'x'.repeat(70 * 1024);
    const requests = [
      {
        body: {
          schemaVersion: 2,
          lineage,
          sequence: 1,
          operation: 'supply_refresh_ack',
          body: { refreshId: 'refresh_oversized', status: 'applied' },
          futureNote: padding,
        },
        path: '/api/worker-control/supply-refresh-ack',
      },
      {
        body: heartbeatEnvelope(lineage, 1, 'running', padding),
        path: '/api/worker-control/heartbeat',
      },
      {
        body: {
          artifact: { path: padding, title: 'Oversized artifact' },
          lineage,
          sequence: 1,
        },
        path: '/api/worker-control/artifacts',
      },
    ];
    const results = await Promise.all(
      requests.map(async ({ body, path }) => {
        const response = await app.request(path, {
          body: JSON.stringify(body),
          headers: {
            authorization: 'Bearer invalid',
            'content-type': 'application/json',
          },
          method: 'POST',
        });

        return {
          body: (await response.json()) as { code: string },
          status: response.status,
        };
      })
    );

    expect(results).toEqual(
      requests.map(() => ({
        body: expect.objectContaining({ code: 'worker_control_payload_too_large' }),
        status: 413,
      }))
    );
  });

  it('accepts sandbox bearer heartbeats without a browser session cookie', async () => {
    const { app, lineage, token } = createWorkerControlRouteFixture();

    const res = await app.request('/api/worker-control/heartbeat', {
      body: JSON.stringify(heartbeatEnvelope(lineage, 1, 'running', 'Worker is alive.')),
      headers: {
        authorization: `Bearer ${token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });
    const body = (await res.json()) as { heartbeat: { status: string; lastHeartbeatAt: string } };

    expect(res.status).toBe(200);
    expect(body.heartbeat).toMatchObject({
      lastHeartbeatAt: '2026-06-16T00:00:02.000Z',
      status: 'running',
    });
  });

  it('accepts worker artifact notices over HTTP', async () => {
    const { app, lineage, token } = createWorkerControlRouteFixture();

    const res = await app.request('/api/worker-control/artifacts', {
      body: JSON.stringify({
        artifact: {
          mediaType: 'text/markdown',
          path: '/openkit/artifacts/report.md',
          title: 'Worker report',
        },
        lineage,
        sequence: 2,
      }),
      headers: {
        authorization: `Bearer ${token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });
    const body = (await res.json()) as {
      artifact: { path: string; title: string };
    };

    expect(res.status).toBe(200);
    expect(body.artifact).toMatchObject({
      path: '/openkit/artifacts/report.md',
      title: 'Worker report',
    });
  });

  it('rebuilds live worker-control sessions from durable gateway rows', async () => {
    const coreDb = openCoreDb(mkdtempSync(join(tmpdir(), 'openkit-worker-control-rebuild-')));
    const store = createDemoStore();
    const thread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Rebuild worker session'
    );
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Control worker',
      {
        kind: 'user',
        id: 'usr_00000000-0000-7000-8000-000000000001',
      }
    );
    const environmentPackage = AgentEnvironmentPackageSchema.parse(
      resolveAgentEnvironmentPackage({
        agentSetup: createTestAgentSetup(),
        agentSessionId: testEntityId('as', 'session_rebuild'),
        triggerActor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
        backend: {
          kind: 'openshell',
        },
        createdAt: '2026-06-16T00:00:00.000Z',
        requestId: 'req_rebuild',
        turn,
        workspaceCwd: '/workspace/repo',
        workspaceRoots: [],
      })
    );
    const lineage: WorkerControlLineage = {
      agentSessionId: environmentPackage.scope.agentSessionId,
      packageSnapshotId: environmentPackage.snapshotId,
      requestId: environmentPackage.scope.requestId,
      threadId: environmentPackage.scope.threadId,
      turnId: environmentPackage.scope.turnId,
      workspaceId: environmentPackage.scope.workspaceId,
    };

    try {
      applyMigrations(coreDb);
      ensureLocalUser(coreDb);
      recordWorkspaceOwnerMembership({
        coreDb,
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        ownerUserId: LOCAL_USER_ID,
      });
      const firstGateway = createDefaultWorkerControlGateway(coreDb);
      createSchedulerAdmissionEntry(coreDb, {
        backendId: 'nanohost',
        triggerActor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
        profileRef: environmentPackage.agent.profileId,
        queueEntryId: 'queue_rebuild',
        requestId: lineage.requestId,
        requestedAgentId: environmentPackage.agent.agentId,
        threadId: lineage.threadId,
        turnId: lineage.turnId,
        turnInput: 'Run worker control rebuild test',
        workspaceId: lineage.workspaceId,
      });
      const submittedAttempt = recordTestExecutionAttempt(coreDb, {
        entry: requireSchedulerAdmissionEntry(coreDb, 'queue_rebuild'),
        attemptId: testEntityId('attempt', 'lease_rebuild'),
        agentSessionId: lineage.agentSessionId,
        inputRef: lineage.packageSnapshotId,
        bindingRef: 'lease-binding:lease_rebuild',
        sessionCompatibilityKey: 'fixture-compatibility',
        now: () => new Date().toISOString(),
        operationId: `fixture-submit:${String(testEntityId('attempt', 'lease_rebuild'))}`,
      });
      attemptActionOwners.acceptSchedulerExecutionObservation(coreDb, {
        ...attemptActionOwners.schedulerExecutionCorrelation(submittedAttempt),
        disposition: 'accepted',
        execution: 'running',
        fenceRef: null,
        outcomeRef: null,
      });
      bindNanoHostAttemptRouteTokenHashes(coreDb, {
        attemptId: testEntityId('attempt', 'lease_rebuild'),
        sandboxBindingRef: 'lease-binding:lease_rebuild',
        workerCapabilityTokenHash: hashWorkerRouteToken(
          workerRouteToken('lease-binding:lease_rebuild', 'capability')
        ),
        workerControlTokenHash: hashWorkerRouteToken(
          workerRouteToken('lease-binding:lease_rebuild', 'worker-control')
        ),
        workerInferenceTokenHash: hashWorkerRouteToken(
          workerRouteToken('lease-binding:lease_rebuild', 'inference')
        ),
      });

      const firstRegistration = registerDurableWorkerControlSession(
        firstGateway,
        environmentPackage,
        'lease-binding:lease_rebuild'
      );
      const firstApp = createApp({
        coreDb,
        mode: 'server',
        store,
        workerControlGateway: firstGateway,
      });

      const absoluteDeadline = absoluteAttemptDeadline(coreDb, lineage.turnId);
      const firstHeartbeatResponse = await firstApp.request('/api/worker-control/heartbeat', {
        body: JSON.stringify(heartbeatEnvelope(lineage, 1, 'running', 'Worker is alive.')),
        headers: {
          authorization: `Bearer ${firstRegistration.token}`,
          'content-type': 'application/json',
        },
        method: 'POST',
      });
      const firstHeartbeatBody = (await firstHeartbeatResponse.json()) as {
        heartbeat: { lastHeartbeatAt: string; sequence: number; status: string };
      };
      await firstApp.request('/api/worker-control/events/append', {
        body: JSON.stringify({
          lineage,
          record: {
            event: { data: { delta: 'hello', itemId: 'candidate_item_1' }, type: 'item.delta' },
            kind: 'event',
            lineage,
            schemaVersion: 1,
            sequence: 3,
          },
        }),
        headers: {
          authorization: `Bearer ${firstRegistration.token}`,
          'content-type': 'application/json',
        },
        method: 'POST',
      });

      const workspaceDb = openWorkspaceDb(coreDb.dataRoot, lineage.workspaceId);
      try {
        applyScopedMigrations(workspaceDb);
        recordAgentEnvironmentPackageSnapshot(workspaceDb, {
          createdAt: '2026-06-16T00:00:01.000Z',
          environmentPackage,
        });
      } finally {
        workspaceDb.sqlite.close();
      }

      vi.useFakeTimers();
      vi.setSystemTime(new Date(Date.parse(firstHeartbeatBody.heartbeat.lastHeartbeatAt) + 1_000));
      const rebuiltGateway = createDefaultWorkerControlGateway(coreDb);
      const authorization = `Bearer ${workerRouteToken(
        'lease-binding:lease_rebuild',
        'worker-control'
      )}`;
      const retryHeartbeat = rebuiltGateway.recordHeartbeat({
        authorization,
        ...heartbeatEnvelope(lineage, 1, 'running', 'Worker is alive.'),
      });
      const snapshot = rebuiltGateway.getSessionSnapshot(lineage.packageSnapshotId);
      const leaseAfterRetry = requireNanoHostExecutionAttempt(
        coreDb,
        testEntityId('attempt', 'lease_rebuild')
      );
      expect(absoluteAttemptDeadline(coreDb, lineage.turnId)).toBe(absoluteDeadline);
      expect.soft(retryHeartbeat).toEqual(firstHeartbeatBody.heartbeat);
      expect.soft(snapshot?.heartbeat).toEqual(firstHeartbeatBody.heartbeat);
      expect
        .soft(leaseAfterRetry.lastAcceptedHeartbeatAt)
        .toBe(firstHeartbeatBody.heartbeat.lastHeartbeatAt);
      expect(snapshot).toMatchObject({
        agentSessionId: testEntityId('as', 'session_rebuild'),
        events: [expect.objectContaining({ sequence: 3 })],
        heartbeat: expect.objectContaining({ status: 'running' }),
        packageSnapshotId: lineage.packageSnapshotId,
      });
    } finally {
      vi.useRealTimers();
      coreDb.sqlite.close();
    }
  });

  it('accepts canonical event append requests without a browser session cookie', async () => {
    const { app, environmentPackage, gateway, lineage, token } = createWorkerControlRouteFixture();

    const res = await app.request('/api/worker-control/events/append', {
      body: JSON.stringify({
        lineage,
        record: {
          event: {
            data: {
              delta: 'hello',
              itemId: 'candidate_item_1',
            },
            type: 'item.delta',
          },
          kind: 'event',
          lineage,
          schemaVersion: 1,
          sequence: 3,
        },
      }),
      headers: {
        authorization: `Bearer ${token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });
    const body = (await res.json()) as { accepted: boolean; nextExpectedSequence: number };

    expect(res.status).toBe(200);
    expect(body).toMatchObject({
      accepted: true,
      nextExpectedSequence: 4,
    });
    expect(gateway.getSessionSnapshot(environmentPackage.snapshotId)?.events).toEqual([
      expect.objectContaining({
        event: expect.objectContaining({ type: 'item.delta' }),
        sequence: 3,
      }),
    ]);
  });

  it('rejects oversized event append requests before schema handling', async () => {
    const { app, lineage, token } = createWorkerControlRouteFixture();

    const res = await app.request('/api/worker-control/events/append', {
      body: JSON.stringify({
        lineage,
        record: {
          event: {
            data: {
              delta: 'x'.repeat(260 * 1024),
              itemId: 'candidate_item_oversized',
            },
            type: 'item.delta',
          },
          kind: 'event',
          lineage,
          schemaVersion: 1,
          sequence: 13,
        },
      }),
      headers: {
        authorization: `Bearer ${token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });
    const body = (await res.json()) as { code: string };

    expect(res.status).toBe(413);
    expect(body.code).toBe('worker_control_payload_too_large');
  });

  it('projects event append sequence conflicts as worker-control API errors', async () => {
    const { app, lineage, token } = createWorkerControlRouteFixture();
    const record = {
      event: {
        data: {
          delta: 'hello',
          itemId: 'candidate_item_1',
        },
        type: 'item.delta',
      },
      kind: 'event',
      lineage,
      schemaVersion: 1,
      sequence: 3,
    };

    await app.request('/api/worker-control/events/append', {
      body: JSON.stringify({ lineage, record }),
      headers: {
        authorization: `Bearer ${token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });
    const res = await app.request('/api/worker-control/events/append', {
      body: JSON.stringify({
        lineage,
        record: {
          ...record,
          event: {
            data: {
              delta: 'different',
              itemId: 'candidate_item_1',
            },
            type: 'item.delta',
          },
        },
      }),
      headers: {
        authorization: `Bearer ${token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });
    const body = (await res.json()) as { code: string };

    expect(res.status).toBe(409);
    expect(body.code).toBe('worker_control_sequence_conflict');
  });

  it('rejects worker requests with invalid sandbox bearer tokens', async () => {
    const { app, lineage } = createWorkerControlRouteFixture();

    const res = await app.request('/api/worker-control/heartbeat', {
      body: JSON.stringify(heartbeatEnvelope(lineage, 1, 'running')),
      headers: {
        authorization: 'Bearer wrong',
        'content-type': 'application/json',
      },
      method: 'POST',
    });
    const body = (await res.json()) as { code: string };

    expect(res.status).toBe(401);
    expect(body.code).toBe('worker_control_unauthorized');
  });

  it('authenticates only the worker-control token family', () => {
    const source = readFileSync(
      new URL('./runtime/worker-control-routes.ts', import.meta.url),
      'utf8'
    );

    expect(source).toContain('workerControlTokenHash');
    expect(source).toContain("tokenFamily: 'worker-control'");
    expect(source).not.toContain("tokenFamily: 'inference'");
  });
});

/** Closes this explicit no-process control fixture only after its six modeled barriers and exact simulator fence settle. */
async function closeOwnedExecutionAttempt(
  db: CoreDb,
  input: {
    readonly attemptId: string;
    readonly firstTerminalCause: string;
    readonly outcome?: string;
    readonly now?: () => string;
  }
) {
  const attempt = attemptActionOwners.markSchedulerExecutionAttemptClosing(db, {
    attemptId: input.attemptId,
    cause: input.firstTerminalCause,
    ...(input.outcome ? { outcomeRef: input.outcome } : {}),
    ...(input.now ? { now: input.now } : {}),
  });
  const proof = {
    terminalHandoff: true,
    output: true,
    evidence: true,
    outsideWorkspaceCollection: true,
    integrationDrain: true,
    routesRevoked: true,
  } as const;
  const correlation = attemptActionOwners.schedulerExecutionCorrelation(attempt);
  const result = await new SimulatedTurnExecutor({ coreDb: db }).release({ ...correlation, proof });
  return attemptActionOwners.closeSchedulerExecutionAttemptWithFence(db, {
    correlation,
    proof,
    fenceRef: result.fenceRef!,
    ...(input.now ? { now: input.now } : {}),
  });
}

/** Calls the current attempt owner at the deciding action; the private API spelling is an adaptable test seam. */
function beginOwnedAttemptCloseout(
  db: ReturnType<typeof openCoreDb>,
  input: {
    readonly attemptId: string;
    readonly firstTerminalCause: string;
    readonly outcome?: string;
    readonly now?: () => string;
  }
) {
  const action = attemptActionOwners.markSchedulerExecutionAttemptClosing;
  expect(
    action,
    'The deciding action needs the current attempt owner, without a SessionLease compatibility action.'
  ).toBeTypeOf('function');
  return action(db, {
    attemptId: input.attemptId,
    cause: input.firstTerminalCause,
    ...(input.outcome ? { outcomeRef: input.outcome } : {}),
    ...(input.now ? { now: input.now } : {}),
  });
}
