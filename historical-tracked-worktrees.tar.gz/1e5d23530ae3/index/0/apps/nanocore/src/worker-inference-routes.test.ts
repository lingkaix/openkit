import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { request as requestHttp } from 'node:http';
import { createServer as createHttp2Server, type ServerHttp2Session } from 'node:http2';
import { connect as connectSocket } from 'node:net';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { zstdCompressSync } from 'node:zlib';
import {
  createModels,
  fauxAssistantMessage,
  fauxProvider,
  getCurrentTools,
} from '@earendil-works/pi-ai';
import { openrouterProvider } from '@earendil-works/pi-ai/providers/openrouter';
import { serve } from '@hono/node-server';
import type { AgentEnvironmentPackage, GatewayConfig } from '@openkit/config-schema';
import { AgentEnvironmentPackageSchema } from '@openkit/config-schema';
import type { ReasoningEffort } from '@openkit/protocol';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { WORKER_ADAPTERS } from '../../../packages/worker-shim/src/adapter-registry.js';
import { openSandboxIntegration } from '../../../packages/worker-shim/src/integration-client.js';
import { createDefaultWorkerControlGateway } from './app.js';
import { createOpenKitAccessTokenRecord } from './auth/access-token-store.js';
import { disableCanonicalUser } from './auth/user-lifecycle.js';
import {
  listWorkspaceCapabilityCalls,
  listWorkspaceUsageRecords,
} from './capability/usage-ledger.js';
import { FsStore } from './lib/store.js';
import { type ResolvedLogicalModel, resolveLogicalModel } from './llm/logical-models.js';
import {
  type OpenAICompatibleChatCompletionRequest,
  OpenAICompatibleProviderError,
  type OpenAICompatibleResponsesRequest,
  type OpenAICompatibleResponsesResponse,
} from './llm/openai-compatible-client.js';
import { GatewayUnsupportedFeatureError, PiAiGatewayClient } from './llm/pi-ai-client.js';
import { attachPiAiFailure } from './llm/pi-ai-failure.js';
import {
  type LLMGatewayDispatchContext,
  LLMGatewayProviderDispatcher,
} from './llm/provider-dispatcher.js';
import type { ResolvedLLMProviderConfig } from './providers/llm-config.js';
import { ProviderRegistry } from './providers/registry.js';
import { recordAgentEnvironmentPackageSnapshot } from './runtime/aep-snapshot-ledger.js';
import {
  acceptSchedulerExecutionObservation,
  schedulerExecutionCorrelation,
} from './runtime/execution-attempt-records.js';
import { bindNanoHostAttemptRouteTokenHashes } from './runtime/nanohost-attempt-records.js';
import { hashWorkerRouteToken, WorkerControlGateway } from './runtime/worker-control-gateway.js';
import { createSchedulerAdmissionEntry } from './scheduler-records.js';
import { type CoreDb, openCoreDb, openWorkspaceDb } from './storage/db.js';
import { applyMigrations, applyScopedMigrations } from './storage/migrate.js';
import { readWorkObservations } from './storage/work-observations.js';
import { createTestAgentSetup } from './test-support/agent-environment.js';
import { createApp } from './test-support/app.js';
import { createDemoStore } from './test-support/demo-store.js';
import { testEntityId } from './test-support/entity-ids.js';
import { recordTestExecutionAttempt } from './test-support/execution-attempt.js';
import { ensureLocalUser } from './test-support/local-user.js';
import { resolveAgentEnvironmentPackage } from './test-support/prepared-agent-environment.js';
import { recordWorkspaceOwnerMembership } from './workspace-membership.js';

interface WorkerInferenceDispatchCall {
  /** Dispatcher context derived by the route. */
  readonly context: LLMGatewayDispatchContext;
  /** Worker request after authority fields are stripped. */
  readonly request: OpenAICompatibleChatCompletionRequest | OpenAICompatibleResponsesRequest;
  /** AEP-selected provider passed to the shared dispatcher. */
  readonly provider: ResolvedLLMProviderConfig;
}

/** Minimal dispatcher fake for worker inference route tests. */
class FakeWorkerInferenceDispatcher {
  /** The fake's fixed Provider output is fully known before public delivery; it supplies source proof independently of its held HTTP streams. */
  public observeSource(context: LLMGatewayDispatchContext, text = ''): void {
    const boundary = context.transport?.rawOutput;
    if (!boundary) return;
    const settle = boundary.sourceStarted();
    try {
      boundary.sourceEvent();
      if (text)
        boundary.observe({
          partId: 0,
          field: 'text',
          fromBytePosition: 0,
          bytePosition: Buffer.byteLength(text, 'utf8'),
        });
    } finally {
      settle();
    }
  }
  /** Chat Completions calls accepted by the fake. */
  public readonly chatCalls: WorkerInferenceDispatchCall[] = [];
  /** Responses calls accepted by the fake. */
  public readonly responseCalls: WorkerInferenceDispatchCall[] = [];
  /** Optional Responses failure raised before a response is returned. */
  public responseError: Error | null = null;
  /** Optional failure raised after the routed request signal is aborted. */
  public responseErrorAfterAbort: Error | 'signal-reason' | null = null;
  /** Optional non-stream Responses value used for serialization failure tests. */
  public responsesResponseOverride: OpenAICompatibleResponsesResponse | null = null;
  /** Whether the Responses stream should fail after its first chunk. */
  public shouldFailResponsesStream = false;
  /** Error thrown after the first Responses stream chunk when `shouldFailResponsesStream` is set. */
  public responsesStreamFailure: Error = new Error('private upstream stream failure');
  /** Whether the Responses stream should stay open until its consumer cancels it. */
  public shouldHoldResponsesStream = false;
  /** Exposes controlled lifecycle-only bytes to test the public commit boundary. */
  public holdLifecycle = false;
  public lifecycleController?: ReadableStreamDefaultController<Uint8Array>;
  /** Cancellation reasons observed by the upstream Responses stream. */
  public readonly responsesStreamCancellations: unknown[] = [];

  /**
   * Returns one deterministic Chat Completions response.
   *
   * @param provider Selected provider.
   * @param request Sanitized worker request.
   * @param context Derived dispatch context.
   * @returns OpenAI-compatible completion fixture.
   */
  public async createChatCompletion(
    provider: ResolvedLLMProviderConfig,
    request: OpenAICompatibleChatCompletionRequest,
    context: LLMGatewayDispatchContext = {}
  ) {
    this.chatCalls.push({ context, provider, request });
    this.observeSource(context, request.stream ? '' : 'worker chat ok');
    context.transport?.onCodexTurnState?.('worker-provider-response-state');

    return {
      choices: [
        {
          finish_reason: 'stop',
          index: 0,
          message: { content: 'worker chat ok', role: 'assistant' as const },
        },
      ],
      created: 1,
      id: 'chatcmpl_worker_inference',
      model: request.model,
      object: 'chat.completion' as const,
    };
  }

  /**
   * Returns one deterministic Chat Completions SSE stream.
   *
   * @param provider Selected provider.
   * @param request Sanitized worker request.
   * @param context Derived dispatch context.
   * @returns OpenAI-compatible SSE bytes.
   */
  public async createChatCompletionStream(
    provider: ResolvedLLMProviderConfig,
    request: OpenAICompatibleChatCompletionRequest,
    context: LLMGatewayDispatchContext = {}
  ): Promise<ReadableStream<Uint8Array>> {
    this.chatCalls.push({ context, provider, request });
    this.observeSource(context, request.stream ? '' : 'worker chat ok');
    context.transport?.onCodexTurnState?.('worker-provider-response-state');

    return streamText('data: {"id":"chatcmpl_worker_stream"}\n\ndata: [DONE]\n\n');
  }

  /**
   * Returns one deterministic Responses response.
   *
   * @param provider Selected provider.
   * @param request Sanitized worker request.
   * @param context Derived dispatch context.
   * @returns OpenAI-compatible Responses fixture.
   */
  public async createResponses(
    provider: ResolvedLLMProviderConfig,
    request: OpenAICompatibleResponsesRequest,
    context: LLMGatewayDispatchContext = {}
  ) {
    this.responseCalls.push({ context, provider, request });
    this.observeSource(
      context,
      this.shouldFailResponsesStream || this.shouldHoldResponsesStream ? 'Hi' : ''
    );
    if (this.responseErrorAfterAbort) {
      const signal = context.transport?.signal;

      if (!signal) {
        throw new Error('Worker inference test expected a routed request signal.');
      }
      if (!signal.aborted) {
        await new Promise<void>((resolve) =>
          signal.addEventListener('abort', () => resolve(), { once: true })
        );
      }
      throw this.responseErrorAfterAbort === 'signal-reason'
        ? signal.reason
        : this.responseErrorAfterAbort;
    }
    if (this.responseError) {
      throw this.responseError;
    }
    context.transport?.onCodexTurnState?.('worker-provider-response-state');
    if (this.responsesResponseOverride) {
      return this.responsesResponseOverride;
    }

    return {
      id: 'resp_worker_inference',
      object: 'response' as const,
      model: request.model,
      output: [],
      status: 'completed' as const,
    };
  }

  /**
   * Returns one deterministic Responses SSE stream.
   *
   * @param provider Selected provider.
   * @param request Sanitized worker request.
   * @param context Derived dispatch context.
   * @returns OpenAI-compatible SSE bytes.
   */
  public async createResponsesStream(
    provider: ResolvedLLMProviderConfig,
    request: OpenAICompatibleResponsesRequest,
    context: LLMGatewayDispatchContext = {}
  ): Promise<ReadableStream<Uint8Array>> {
    this.responseCalls.push({ context, provider, request });
    this.observeSource(
      context,
      this.shouldFailResponsesStream || this.shouldHoldResponsesStream ? 'Hi' : ''
    );
    if (this.responseError) {
      throw this.responseError;
    }
    context.transport?.onCodexTurnState?.('worker-provider-response-state');

    if (this.holdLifecycle) {
      return new ReadableStream<Uint8Array>({
        start: (controller) => {
          this.lifecycleController = controller;
          controller.enqueue(new TextEncoder().encode('data: {"type":"response.created"}\n\n'));
        },
      });
    }

    if (this.shouldHoldResponsesStream) {
      return new ReadableStream<Uint8Array>({
        cancel: async (reason) => {
          this.responsesStreamCancellations.push(reason);
          await Promise.resolve();
          context.onUsage?.({ input_tokens: 3, output_tokens: 1, total_tokens: 4 });
        },
        start(controller) {
          controller.enqueue(
            new TextEncoder().encode('data: {"type":"response.output_text.delta","delta":"Hi"}\n\n')
          );
        },
      });
    }

    if (this.shouldFailResponsesStream) {
      const failure = this.responsesStreamFailure;
      let emitted = false;
      return new ReadableStream<Uint8Array>({
        pull(controller) {
          if (!emitted) {
            emitted = true;
            controller.enqueue(
              new TextEncoder().encode(
                'data: {"type":"response.output_text.delta","delta":"Hi"}\n\n'
              )
            );
            return;
          }
          controller.error(failure);
        },
      });
    }

    return streamText('data: {"type":"response.completed"}\n\ndata: [DONE]\n\n');
  }
}

interface WorkerInferenceRouteFixture {
  /** App serving the worker-only routes. */
  readonly app: ReturnType<typeof createApp>;
  /** Core database backing durable worker inference attribution, when configured. */
  readonly coreDb: CoreDb | undefined;
  /** Dispatcher fake shared with the app. */
  readonly dispatcher: FakeWorkerInferenceDispatcher;
  /** Package bound to the worker token. */
  readonly environmentPackage: AgentEnvironmentPackage;
  /** Marks the durable worker lease unavailable for request-time revalidation. */
  readonly expireLease: () => void;
  /** Durable worker bearer token. */
  readonly token: string;
  /** Capability token paired with the inference bearer. */
  readonly workerCapabilityToken: string;
  /** Non-secret binding owned independently from the route credentials. */
  readonly sandboxBindingRef: string;
  /** Worker-control token paired with the inference bearer. */
  readonly workerControlToken: string;
  /** Worker-control gateway retaining the authenticated package session. */
  readonly workerControlGateway: WorkerControlGateway;
}

const ownedCoreDatabases: CoreDb[] = [];
/** Request body limit shared with the worker inference transport contract. */
const WORKER_INFERENCE_TEST_BODY_LIMIT = 16 * 1024 * 1024;
const WORKER_LOGICAL_MODEL_ID = 'worker-reasoning';
const WORKER_PROVIDER_MODEL = 'openai/gpt-5.2';
const CODEX_PROVIDER_ID = 'openai-codex';
const CODEX_PROVIDER_MODEL = 'openai-codex/gpt-5.6-sol';

afterEach(() => {
  vi.restoreAllMocks();
  for (const coreDb of ownedCoreDatabases.splice(0)) {
    coreDb.sqlite.close();
    rmSync(coreDb.dataRoot, { recursive: true, force: true });
  }
});

/**
 * Creates one live trusted worker inference session and app.
 *
 * @param trustedRelay Whether the AEP requires the trusted relay capability.
 * @param coreDb Optional shared Core database.
 * @param durableStorage Whether the app receives durable storage.
 * @param includeWorkerProvider Whether the AEP-selected provider is available.
 * @param runtimeProvenance Whether the AEP requires runtime provenance.
 * @param options Optional provider family, admitted authority and logical model, and current Gateway supply.
 * @returns Route fixture.
 */
function createWorkerInferenceRouteFixture(
  trustedRelay = true,
  coreDb?: CoreDb,
  durableStorage = true,
  includeWorkerProvider = true,
  runtimeProvenance = false,
  options: {
    readonly subscriptionFamily?: 'openai-codex';
    readonly subscriptionCheckUnavailable?: boolean;
    readonly persistedTurn?: boolean;
    /** Use the production credential/deadline consumer for the absolute-deadline regression. */
    readonly durableAuthority?: boolean;
    readonly adminBearer?: boolean;
    readonly autoFailover?: boolean;
    readonly reasoningEffort?: ReasoningEffort;
    readonly dispatcher?: LLMGatewayProviderDispatcher;
    readonly missingApiKey?: boolean;
    readonly admittedLogicalModel?: ResolvedLogicalModel;
    readonly gatewayConfig?: GatewayConfig;
    readonly providerRegistry?: ProviderRegistry;
  } = {}
): WorkerInferenceRouteFixture {
  const providerProfileId =
    options.subscriptionFamily === 'openai-codex' ? CODEX_PROVIDER_ID : 'agent-openrouter';
  const providerModel =
    options.subscriptionFamily === 'openai-codex' ? CODEX_PROVIDER_MODEL : WORKER_PROVIDER_MODEL;
  const appCoreDb =
    coreDb ??
    (durableStorage
      ? openCoreDb(mkdtempSync(join(tmpdir(), 'openkit-worker-inference-route-')))
      : undefined);
  if (appCoreDb && !coreDb) {
    applyMigrations(appCoreDb);
    ownedCoreDatabases.push(appCoreDb);
  }
  if (appCoreDb) {
    ensureLocalUser(appCoreDb);
    recordWorkspaceOwnerMembership({
      coreDb: appCoreDb,
      ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
    });
  }
  const store = createDemoStore();
  const turn = store.createTurn(
    'ws_00000000-0000-7000-8000-000000000001',
    'th_00000000-0000-7000-8000-000000000001',
    'Call worker inference',
    {
      kind: 'user',
      id: 'usr_00000000-0000-7000-8000-000000000001',
    },
    null,
    options.reasoningEffort === undefined ? {} : { reasoningEffort: options.reasoningEffort }
  );
  if (options.persistedTurn && appCoreDb) {
    const persisted = new FsStore({ dataRoot: appCoreDb.dataRoot });
    persisted.importWorkspaceSnapshot({
      workspace: store.getWorkspace(turn.workspaceId),
      threads: [store.getThread(turn.workspaceId, turn.threadId)],
      turns: [turn],
      knowledge: [],
      itemRevisions: store.listThreadItems(turn.workspaceId, turn.threadId),
      artifacts: [],
      agentSessions: [],
      turnEvents: [],
      turnCaptureCoverage: new Map([[turn.id, store.getTurnCaptureCoverage(turn.id)!]]),
    });
  }
  const agentSetup = createTestAgentSetup({
    logicalModelId: WORKER_LOGICAL_MODEL_ID,
    privateRoute: {
      providerProfileId,
      providerModel,
    },
    requiredCapabilities: trustedRelay
      ? [
          'trusted-worker-inference-relay',
          ...(runtimeProvenance ? (['worker.runtime-provenance.v1'] as const) : []),
        ]
      : ['backend-local-inference'],
  });
  if (options.admittedLogicalModel) {
    agentSetup.logicalModels.allowed = [options.admittedLogicalModel];
  }
  const environmentPackage = AgentEnvironmentPackageSchema.parse(
    resolveAgentEnvironmentPackage({
      captureCoverage: store.getTurnCaptureCoverage(turn.id)!,
      agentSetup,
      agentSessionId: trustedRelay
        ? 'as_00000000-0000-72a4-a75d-bbe733e57f67'
        : 'as_00000000-0000-7560-ba81-ac4d1a3c3153',
      backend: {
        kind: 'openshell',
      },
      createdAt: '2026-07-13T00:00:00.000Z',
      requestId: 'req_worker_inference_outer_1',
      triggerActor: options.adminBearer
        ? { kind: 'user', id: 'usr_00000000-0000-7e31-ad22-0a4ca76f76f3' }
        : {
            kind: 'automation',
            id: 'auto_00000000-0000-755a-81b4-0445480bb7a3',
            responsibleUserId: 'usr_00000000-0000-7000-8000-000000000001',
          },
      turn,
      workspaceCwd: '/workspace/openkit',
      workspaceRoots: [],
    })
  );
  const sandboxBindingRef = trustedRelay
    ? 'lease-binding:worker_inference_1'
    : 'lease-binding:direct_worker_1';
  const workerControlToken = trustedRelay
    ? 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
    : 'CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC';
  const workerInferenceToken = trustedRelay
    ? 'BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB'
    : 'DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD';
  const workerCapabilityToken = trustedRelay
    ? 'CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC'
    : 'EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE';
  if (appCoreDb) {
    if (options.adminBearer) {
      const now = Date.now();
      appCoreDb.sqlite
        .prepare(
          "INSERT INTO users (id, display_name, email, email_verified, created_at, updated_at, kind, status) VALUES ('usr_00000000-0000-7e31-ad22-0a4ca76f76f3', 'Inference Admin', 'inference-admin@example.com', false, ?, ?, 'human', 'active')"
        )
        .run(now, now);
      createOpenKitAccessTokenRecord(appCoreDb, {
        expiresAt: '2099-01-01T00:00:00.000Z',
        ownerUserId: 'usr_00000000-0000-7e31-ad22-0a4ca76f76f3',
        scope: 'server-admin',
        tokenId: 'token_worker_inference_admin',
        workspaceIds: [],
      });
    }
    const entry = createSchedulerAdmissionEntry(appCoreDb, {
      backendId: 'nanohost',
      queueEntryId: `queue_${turn.id}`,
      requestId: 'req_worker_inference_outer_1',
      triggerActor: environmentPackage.scope.triggerActor,
      serverAdminTokenId: options.adminBearer ? 'token_worker_inference_admin' : null,
      workspaceId: turn.workspaceId,
      threadId: turn.threadId,
      turnId: turn.id,
      turnInput: 'Call worker inference',
      requestedAgentId: environmentPackage.agent.agentId,
    });
    const submittedAttempt = recordTestExecutionAttempt(appCoreDb, {
      entry,
      attemptId: testEntityId('attempt', `lease_${turn.id}`),
      agentSessionId: environmentPackage.scope.agentSessionId,
      inputRef: environmentPackage.snapshotId,
      bindingRef: sandboxBindingRef,
      sessionCompatibilityKey: 'fixture-compatibility',
      now: () => new Date().toISOString(),
      operationId: `fixture-submit:${testEntityId('attempt', `lease_${turn.id}`)}`,
    });
    expect(
      acceptSchedulerExecutionObservation(appCoreDb, {
        ...schedulerExecutionCorrelation(submittedAttempt),
        disposition: 'accepted',
        execution: 'running',
        fenceRef: null,
        outcomeRef: null,
      })?.disposition
    ).toBe('accepted');
  }
  if (options.durableAuthority && appCoreDb) {
    bindNanoHostAttemptRouteTokenHashes(appCoreDb, {
      attemptId: testEntityId('attempt', `lease_${turn.id}`),
      sandboxBindingRef,
      workerCapabilityTokenHash: hashWorkerRouteToken(workerCapabilityToken),
      workerControlTokenHash: hashWorkerRouteToken(workerControlToken),
      workerInferenceTokenHash: hashWorkerRouteToken(workerInferenceToken),
    });
    const workspaceDb = openWorkspaceDb(appCoreDb.dataRoot, turn.workspaceId);
    try {
      applyScopedMigrations(workspaceDb);
      recordAgentEnvironmentPackageSnapshot(workspaceDb, {
        environmentPackage,
        createdAt: environmentPackage.createdAt,
      });
    } finally {
      workspaceDb.sqlite.close();
    }
  }
  let leaseLive = true;
  const workerControlGateway = options.durableAuthority
    ? createDefaultWorkerControlGateway(appCoreDb)
    : new WorkerControlGateway({
        resolveTokenBinding: () =>
          leaseLive ? { status: 'accepted' } : { reason: 'lease-not-live', status: 'rejected' },
      });
  const dispatcher = new FakeWorkerInferenceDispatcher();

  workerControlGateway.registerSession(environmentPackage, {
    sandboxBindingRef,
    workerCapabilityToken,
    workerControlToken,
    workerInferenceToken,
  });

  return {
    app: createApp({
      ...(appCoreDb ? { coreDb: appCoreDb } : {}),
      gatewayConfig: options.gatewayConfig ?? {
        schemaVersion: 1,
        enabled: true,
        defaultLogicalModelId: WORKER_LOGICAL_MODEL_ID,
        logicalModels: [
          {
            id: WORKER_LOGICAL_MODEL_ID,
            displayName: 'Worker reasoning',
            routing: { autoFailover: options.autoFailover ?? true },
            contextManagement: [{ type: 'compaction', compactThreshold: 8_000 }],
            routes: [
              {
                id: 'primary',
                providerProfileId,
                providerModel,
              },
            ],
          },
        ],
        requiredFeatures: [],
      },
      ...(options.subscriptionCheckUnavailable
        ? {
            providerSubscriptionAccountManager: {
              gatewayUnavailableReason: () => null,
              getPairHandle: async () => {
                throw new Error('private account detail');
              },
            } as never,
          }
        : {}),
      llmGatewayDispatcher:
        options.dispatcher ?? (dispatcher as unknown as LLMGatewayProviderDispatcher),
      ...(options.dispatcher ? { providerCredentialResolver: () => 'synthetic-secret' } : {}),
      ...(options.dispatcher
        ? {
            agentManifests: [
              {
                ...agentSetup.manifest,
                models: { ...agentSetup.manifest.models, reasoningEffort: 'max' as const },
              },
            ],
          }
        : {}),
      mode: 'server',
      openKitConfig: {},
      // Successful fake dispatch still requires configured supply under the Gateway owner.
      providerCredentialResolver: (ref) =>
        !options.missingApiKey && ref === 'test:worker-api-key' ? 'synthetic-worker-key' : null,
      providerRegistry:
        options.providerRegistry ??
        new ProviderRegistry([
          ...(includeWorkerProvider
            ? [
                options.subscriptionFamily === 'openai-codex'
                  ? {
                      defaultModel: providerModel,
                      displayName: 'OpenAI Codex',
                      id: providerProfileId,
                      kind: options.subscriptionCheckUnavailable
                        ? ('oauth' as const)
                        : ('gateway' as const),
                      ...(options.subscriptionCheckUnavailable
                        ? {
                            extensions: {
                              openkit: {
                                subscriptionAccount: { accountSlotId: 'private-account-slot' },
                              },
                            },
                          }
                        : { secretRef: 'test:worker-api-key' }),
                      models: [providerModel],
                      vendor: 'openai-codex' as const,
                    }
                  : {
                      defaultModel: providerModel,
                      displayName: 'Agent OpenRouter',
                      id: providerProfileId,
                      kind: 'gateway' as const,
                      secretRef: 'test:worker-api-key',
                      models: [providerModel],
                      vendor: 'openrouter' as const,
                    },
              ]
            : []),
          {
            defaultModel: 'public-model',
            displayName: 'Public Default',
            id: 'public-default',
            kind: 'local',
            models: ['public-model'],
            vendor: 'ollama',
          },
        ]),
      store,
      workerControlGateway,
    }),
    coreDb: appCoreDb,
    dispatcher,
    environmentPackage,
    expireLease: () => {
      leaseLive = false;
    },
    sandboxBindingRef,
    token: workerInferenceToken,
    workerCapabilityToken,
    workerControlToken,
    workerControlGateway,
  };
}

/**
 * Creates one byte-preserving text stream.
 *
 * @param value Text to emit once.
 * @returns Readable UTF-8 stream.
 */
function streamText(value: string): ReadableStream<Uint8Array> {
  return new ReadableStream<Uint8Array>({
    start(controller) {
      controller.enqueue(new TextEncoder().encode(value));
      controller.close();
    },
  });
}

/**
 * Reads durable capability calls owned by one worker inference fixture.
 *
 * @param fixture Worker inference route fixture.
 * @returns Capability call rows in creation order.
 */
function readWorkerInferenceCapabilityCalls(
  fixture: WorkerInferenceRouteFixture
): Array<Record<string, unknown>> {
  const workspaceDb = openWorkspaceDb(
    fixture.coreDb!.dataRoot,
    fixture.environmentPackage.scope.workspaceId
  );

  try {
    applyScopedMigrations(workspaceDb);
    return workspaceDb.sqlite
      .prepare(
        `SELECT status, error_code AS errorCode, provider_ref AS providerRef, summary,
                package_snapshot_id AS packageSnapshotId,
                runtime_origin_ref AS runtimeOriginRef,
                runtime_cache_lineage_ref AS runtimeCacheLineageRef
         FROM capability_calls
         ORDER BY started_at ASC, call_id ASC`
      )
      .all() as Array<Record<string, unknown>>;
  } finally {
    workspaceDb.sqlite.close();
  }
}

/**
 * Posts one JSON request to the worker Responses route.
 *
 * @param fixture Worker route fixture.
 * @param body Request body.
 * @param headers Optional extra headers.
 * @returns Route response.
 */
function postWorkerResponses(
  fixture: WorkerInferenceRouteFixture,
  body: Record<string, unknown>,
  headers: Record<string, string> = {}
): Promise<Response> {
  return fixture.app.request('/api/worker-inference/v1/responses', {
    body: JSON.stringify(body),
    headers: {
      authorization: `Bearer ${fixture.token}`,
      'content-type': 'application/json',
      ...headers,
    },
    method: 'POST',
  });
}

/**
 * Posts raw bytes to the worker Responses route.
 *
 * @param fixture Worker route fixture.
 * @param body Encoded request body.
 * @param headers Request representation headers.
 * @returns Route response.
 */
function postRawWorkerResponses(
  fixture: WorkerInferenceRouteFixture,
  body: BodyInit,
  headers: Record<string, string> = {}
): Promise<Response> {
  return fixture.app.request('/api/worker-inference/v1/responses', {
    body,
    headers: {
      authorization: `Bearer ${fixture.token}`,
      'content-type': 'application/json',
      ...headers,
    },
    method: 'POST',
  });
}

describe('worker inference routes', () => {
  it.each([
    false,
    true,
  ])('refuses successful Provider output without native raw observation proof (stream=%s)', async (stream) => {
    const fixture = createWorkerInferenceRouteFixture();
    vi.spyOn(fixture.dispatcher, 'createResponses').mockImplementation(
      async (_provider, request) => ({
        id: 'resp_unobserved',
        object: 'response',
        model: request.model,
        output: [],
        status: 'completed',
      })
    );
    vi.spyOn(fixture.dispatcher, 'createResponsesStream').mockResolvedValue(
      new ReadableStream({
        start(controller) {
          controller.enqueue(
            new TextEncoder().encode(
              'data: {"type":"response.output_text.delta","delta":"unobserved"}\n\n'
            )
          );
          controller.close();
        },
      })
    );
    const response = await postWorkerResponses(fixture, {
      model: WORKER_LOGICAL_MODEL_ID,
      input: 'Observe exactly',
      stream,
    });
    expect(response.status).toBe(503);
    const workspaceDb = openWorkspaceDb(
      fixture.coreDb!.dataRoot,
      fixture.environmentPackage.scope.workspaceId
    );
    try {
      expect(
        workspaceDb.sqlite
          .prepare(
            "SELECT status, error_code FROM capability_calls WHERE service_ref = 'worker-inference-gateway'"
          )
          .all()
      ).toEqual([{ status: 'failed', error_code: 'worker_raw_output_unavailable' }]);
    } finally {
      workspaceDb.sqlite.close();
    }
  });
  it('dispatches canonical Responses through the AEP provider', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    const response = await postWorkerResponses(
      fixture,
      {
        client_metadata: { private: true },
        input: 'Hello from the worker',
        metadata: {
          trace: 'preserve-me',
        },
        model: WORKER_LOGICAL_MODEL_ID,
        prompt_cache_key: 'raw-worker-cache-key',
        prompt_cache_retention: '24h',
        user: 'caller-controlled-user',
      },
      {
        'x-codex-turn-state': 'worker-request-state',
        'x-request-id': 'private-provider-request-id',
      }
    );

    expect(response.status).toBe(200);
    expect(response.headers.get('x-codex-turn-state')).toBe('worker-provider-response-state');
    expect(response.headers.get('x-request-id')).toBeNull();
    await expect(response.json()).resolves.toMatchObject({
      id: 'resp_worker_inference',
      model: WORKER_LOGICAL_MODEL_ID,
    });
    expect(fixture.dispatcher.responseCalls).toHaveLength(1);
    expect(fixture.dispatcher.responseCalls[0]?.provider.id).toBe('agent-openrouter');
    expect(fixture.dispatcher.responseCalls[0]?.request).toEqual(
      expect.objectContaining({
        input: 'Hello from the worker',
        metadata: { trace: 'preserve-me' },
        model: WORKER_PROVIDER_MODEL,
        prompt_cache_key: expect.stringMatching(/^openkit:responses:request:/),
        prompt_cache_retention: '24h',
        store: false,
        stream: false,
      })
    );
    expect(fixture.dispatcher.responseCalls[0]?.context.transport).toMatchObject({
      codexTurnState: 'worker-request-state',
    });
    expect(JSON.stringify(fixture.dispatcher.responseCalls[0]?.context.transport)).not.toContain(
      'private-provider-request-id'
    );
    const serializedCall = JSON.stringify(fixture.dispatcher.responseCalls[0], (key, value) =>
      key === 'workspaceDb' ? undefined : value
    );
    expect(serializedCall).not.toContain('raw-worker-cache-key');
    expect(serializedCall).not.toContain(fixture.token);
    expect(readWorkerInferenceCapabilityCalls(fixture)).toEqual([
      expect.objectContaining({
        packageSnapshotId: fixture.environmentPackage.snapshotId,
        runtimeCacheLineageRef: null,
        runtimeOriginRef: null,
        summary: expect.stringMatching(/request-scoped cache isolation/i),
      }),
    ]);
  });

  it('normalizes pinned Codex Responses tools into the message-anchored prefix', async () => {
    const fixture = createWorkerInferenceRouteFixture(true, undefined, true, true, false, {
      subscriptionFamily: 'openai-codex',
    });
    const tools = [
      {
        description: 'Apply one patch.',
        format: { definition: 'start: /[\\s\\S]+/', syntax: 'lark', type: 'grammar' },
        name: 'apply_patch',
        type: 'custom',
      },
      {
        description: 'Run one command.',
        name: 'exec_command',
        parameters: { properties: { cmd: { type: 'string' } }, type: 'object' },
        strict: false,
        type: 'function',
      },
    ];
    const input = [
      { content: [{ text: 'Run the bounded task.', type: 'input_text' }], role: 'user' },
    ];
    const response = await postWorkerResponses(fixture, {
      input,
      model: WORKER_LOGICAL_MODEL_ID,
      tools,
    });

    expect(response.status).toBe(200);
    expect(fixture.dispatcher.responseCalls[0]?.request).toEqual(
      expect.objectContaining({
        input,
        tools,
      })
    );
  });

  it('keeps worker function tools through direct stock IR mapping', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    const tool = {
      description: 'Return the provided text unchanged.',
      name: 'probe_echo',
      parameters: {
        properties: { text: { type: 'string' } },
        required: ['text'],
        type: 'object',
      },
      strict: false,
      type: 'function' as const,
    };
    const input = 'Reply with the single word ok. Do not call tools.';
    const response = await postWorkerResponses(fixture, {
      input,
      model: WORKER_LOGICAL_MODEL_ID,
      tools: [tool],
    });

    expect(response.status).toBe(200);
    const routed = fixture.dispatcher.responseCalls[0]?.request;
    expect(routed).toMatchObject({
      input,
      tools: [tool],
    });
    expect(JSON.stringify(routed?.input)).not.toContain('additional_tools');
    const faux = fauxProvider({
      provider: 'worker_direct',
      api: 'openai-completions',
      models: [{ id: routed!.model }],
    });
    const models = createModels();
    models.setProvider(faux.provider);
    faux.setResponses([
      (context) => {
        expect(getCurrentTools(context.messages)).toEqual([
          expect.objectContaining({
            name: 'probe_echo',
            description: tool.description,
            parameters: tool.parameters,
          }),
        ]);
        return fauxAssistantMessage('ok');
      },
    ]);
    await new PiAiGatewayClient({ models }).createResponses(
      {
        id: 'worker_direct',
        adapterId: 'worker_direct',
        apiKey: 'explicit',
        requiresApiKey: true,
        models: [routed!.model],
        gatewayCapabilities: { chatCompletions: 'native', responses: 'bridged' },
      } as ResolvedLLMProviderConfig,
      routed!
    );
    expect(faux.state.callCount).toBe(1);
  });

  it('does not recover missing adapter authority from descriptive runtime kind', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    Reflect.deleteProperty(fixture.environmentPackage.control, 'adapter');

    const response = await postWorkerResponses(fixture, {
      input: 'Missing adapter authority',
      model: WORKER_LOGICAL_MODEL_ID,
    });

    expect(response.status).toBe(400);
    await expect(response.json()).resolves.toMatchObject({
      error: { code: 'worker_inference_invalid_request' },
    });
    expect(fixture.dispatcher.responseCalls).toEqual([]);
  });

  it('dispatches Chat Completions through the AEP provider and model', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    const response = await fixture.app.request('/api/worker-inference/v1/chat/completions', {
      body: JSON.stringify({
        messages: [{ content: 'Hello', role: 'user' }],
        model: WORKER_LOGICAL_MODEL_ID,
      }),
      headers: {
        authorization: `Bearer ${fixture.token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });

    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toMatchObject({ id: 'chatcmpl_worker_inference' });
    expect(fixture.dispatcher.chatCalls[0]).toMatchObject({
      provider: { id: 'agent-openrouter' },
      request: { model: WORKER_PROVIDER_MODEL, stream: false },
    });
  });

  it.each([
    false,
    true,
  ])('maps native Codex metadata through Integration and Core with mapping=%s', async (mapped) => {
    const fixture = createWorkerInferenceRouteFixture(true, undefined, true, true, mapped);
    const canonical = JSON.stringify({
      request_kind: 'turn',
      session_id: 'native-session',
      thread_id: 'native-thread',
    });
    const native = {
      input: 'Hello through Integration',
      model: WORKER_LOGICAL_MODEL_ID,
      client_metadata: {
        session_id: 'native-session',
        thread_id: 'native-thread',
        'x-codex-turn-metadata': canonical,
      },
      prompt_cache_key: 'private-cache',
      ...(!mapped
        ? {
            openkit_runtime_hint: {
              runtimeFamily: 'codex',
              nativeSessionId: 'forged-session',
              nativeThreadId: 'forged-thread',
            },
          }
        : {}),
    };
    const bridge = createHttp2Server();
    let bridgeSession: ServerHttp2Session | undefined;
    const coreRequests: Array<{ headers: Record<string, unknown>; body: Record<string, unknown> }> =
      [];
    bridge.on('session', (session) => {
      bridgeSession = session;
    });
    bridge.on('stream', (stream, headers) => {
      const chunks: Buffer[] = [];
      stream.on('error', () => undefined);
      stream.on('data', (chunk: Buffer) => chunks.push(chunk));
      stream.on('end', () => {
        void (async () => {
          const body = Buffer.concat(chunks);
          coreRequests.push({ headers, body: JSON.parse(body.toString('utf8')) });
          const forwarded = new Headers();
          for (const [key, value] of Object.entries(headers)) {
            if (!key.startsWith(':') && typeof value === 'string') forwarded.set(key, value);
          }
          const response = await fixture.app.request('/api/worker-inference/v1/responses', {
            method: 'POST',
            headers: forwarded,
            body,
          });
          stream.respond({
            ':status': response.status,
            'content-type': response.headers.get('content-type') ?? 'application/json',
          });
          stream.end(await response.text());
        })().catch(() => {
          if (!stream.destroyed) {
            stream.respond({ ':status': 500 });
            stream.end();
          }
        });
      });
    });
    const integration = await openSandboxIntegration();
    const socket = connectSocket(17891, '127.0.0.1');
    bridge.emit('connection', socket);
    try {
      await integration.ready;
      integration.registerSessionLoopback('as-core-mapping', {
        capabilityCredential: 'C'.repeat(43),
        inferenceCredential: 'I'.repeat(43),
        ...(mapped
          ? { inferenceRuntimeHintMapping: WORKER_ADAPTERS.codex?.inferenceRuntimeHintMapping }
          : {}),
      });
      integration.bindTurnRouteTokens('as-core-mapping', {
        capabilityToken: 'capability',
        controlToken: 'control',
        inferenceToken: fixture.token,
      });
      const status = await new Promise<number>((resolve, reject) => {
        const request = requestHttp(
          {
            host: '127.0.0.1',
            port: 17892,
            method: 'POST',
            path: '/inference/v1/responses',
            headers: {
              authorization: `Bearer ${'I'.repeat(43)}`,
              'content-type': 'application/json',
              'session-id': 'native-session',
              'thread-id': 'native-thread',
              'x-client-request-id': 'native-thread',
              'x-codex-turn-metadata': canonical,
            },
          },
          (response) => {
            response.resume();
            response.on('end', () => resolve(response.statusCode ?? 0));
          }
        );
        request.on('error', reject);
        request.end(JSON.stringify(native));
      });
      expect(status).toBe(200);
      expect(coreRequests).toHaveLength(1);
      expect(fixture.dispatcher.responseCalls).toHaveLength(1);
      const upstream = fixture.dispatcher.responseCalls[0]?.request;
      expect(upstream).toMatchObject({
        input: native.input,
        model: WORKER_PROVIDER_MODEL,
        store: false,
      });
      expect(upstream).not.toHaveProperty('openkit_runtime_hint');
      expect(upstream).not.toHaveProperty('client_metadata');
      if (mapped) {
        expect(coreRequests[0]?.body.openkit_runtime_hint).toEqual({
          runtimeFamily: 'codex',
          nativeSessionId: 'native-session',
          nativeThreadId: 'native-thread',
          nativeCacheLineageId: 'private-cache',
        });
        expect(coreRequests[0]?.headers['x-codex-turn-metadata']).toBeUndefined();
        expect(coreRequests[0]?.body).not.toHaveProperty('client_metadata');
        expect(readWorkerInferenceCapabilityCalls(fixture)[0]?.runtimeOriginRef).toMatch(
          /^rto_[a-f0-9]{24}$/
        );
        expect(readWorkerInferenceCapabilityCalls(fixture)[0]?.runtimeCacheLineageRef).toMatch(
          /^rcl_[a-f0-9]{24}$/
        );
      } else {
        expect(coreRequests[0]?.body).not.toHaveProperty('openkit_runtime_hint');
        expect(readWorkerInferenceCapabilityCalls(fixture)[0]?.runtimeOriginRef).toBeNull();
        expect(readWorkerInferenceCapabilityCalls(fixture)[0]?.runtimeCacheLineageRef).toBeNull();
      }
      expect(JSON.stringify(upstream)).not.toContain('private-cache');
      expect(JSON.stringify(upstream)).not.toContain('native-thread');
    } finally {
      integration.close();
      bridgeSession?.destroy();
      socket.destroy();
      await new Promise<void>((resolve) => bridge.close(() => resolve()));
    }
  });

  it.each([
    false,
    true,
  ])('consumes normalized runtime hints with provenance required=%s', async (required) => {
    const fixture = createWorkerInferenceRouteFixture(true, undefined, true, true, required);
    const turnMetadata = {
      parent_thread_id: '018f2f55-7f6d-7d95-a4d0-5f4b6f2b5e04',
      request_kind: 'turn',
      session_id: '018f2f55-7f6d-7d95-a4d0-5f4b6f2b5e01',
      subagent_kind: 'thread_spawn',
      thread_id: '018f2f55-7f6d-7d95-a4d0-5f4b6f2b5e02',
      turn_id: '018f2f55-7f6d-7d95-a4d0-5f4b6f2b5e03',
    };
    const response = await postWorkerResponses(fixture, {
      input: 'Hello from a Codex child',
      model: WORKER_LOGICAL_MODEL_ID,
      openkit_runtime_hint: {
        nativeCacheLineageId: 'private-runtime-cache-lineage',
        nativeSessionId: turnMetadata.session_id,
        nativeThreadId: turnMetadata.thread_id,
        nativeTurnId: turnMetadata.turn_id,
        parentNativeThreadId: turnMetadata.parent_thread_id,
        runtimeFamily: 'codex',
        subagentKind: 'thread_spawn',
      },
    });

    expect(response.status).toBe(200);
    expect(fixture.dispatcher.responseCalls[0]?.request).toEqual(
      expect.objectContaining({
        input: 'Hello from a Codex child',
        model: WORKER_PROVIDER_MODEL,
        prompt_cache_key: expect.stringMatching(/^openkit:responses:[a-f0-9]{32}$/),
        store: false,
        stream: false,
      })
    );
    expect(readWorkerInferenceCapabilityCalls(fixture)).toEqual([
      expect.objectContaining({
        packageSnapshotId: fixture.environmentPackage.snapshotId,
        runtimeCacheLineageRef: expect.stringMatching(/^rcl_[a-f0-9]{24}$/),
        runtimeOriginRef: expect.stringMatching(/^rto_[a-f0-9]{24}$/),
      }),
    ]);
    const serializedCall = JSON.stringify(fixture.dispatcher.responseCalls[0], (key, value) =>
      key === 'workspaceDb' ? undefined : value
    );
    expect(serializedCall).not.toContain(turnMetadata.thread_id);
    expect(serializedCall).not.toContain('private-runtime-cache-lineage');
    for (const nativeValue of [
      turnMetadata.session_id,
      turnMetadata.turn_id,
      turnMetadata.parent_thread_id,
      'collab_spawn',
    ]) {
      expect(serializedCall).not.toContain(nativeValue);
      expect(JSON.stringify(readWorkerInferenceCapabilityCalls(fixture))).not.toContain(
        nativeValue
      );
    }
    expect(JSON.stringify(readWorkerInferenceCapabilityCalls(fixture))).not.toContain(
      turnMetadata.thread_id
    );
  });

  it('requires canonical runtime hints for provenance-required packages', async () => {
    const fixture = createWorkerInferenceRouteFixture(true, undefined, true, true, true);
    const response = await postWorkerResponses(fixture, {
      input: 'Missing provenance hint',
      model: WORKER_LOGICAL_MODEL_ID,
    });

    expect(response.status).toBe(400);
    await expect(response.json()).resolves.toMatchObject({
      error: { code: 'worker_inference_invalid_request' },
    });
    expect(fixture.dispatcher.responseCalls).toEqual([]);
    expect(readWorkerInferenceCapabilityCalls(fixture)).toEqual([]);
  });

  it.each([
    null,
    {},
    { nativeSessionId: 'private-id', nativeThreadId: '', runtimeFamily: 'codex' },
  ])('rejects malformed normalized hints before provider dispatch: %j', async (hint) => {
    const fixture = createWorkerInferenceRouteFixture();
    const response = await postWorkerResponses(fixture, {
      input: 'Hello',
      model: WORKER_LOGICAL_MODEL_ID,
      openkit_runtime_hint: hint,
    });
    expect(response.status).toBe(400);
    await expect(response.json()).resolves.toMatchObject({
      error: {
        code: 'worker_inference_invalid_request',
        message: 'Worker inference request is invalid.',
      },
    });
    expect(fixture.dispatcher.responseCalls).toEqual([]);
    expect(readWorkerInferenceCapabilityCalls(fixture)).toEqual([]);
  });

  it('does not parse retired native metadata at Core', async () => {
    const fixture = createWorkerInferenceRouteFixture(true, undefined, true, true, true);
    const native = JSON.stringify({
      request_kind: 'turn',
      session_id: 'session',
      thread_id: 'thread',
    });
    const response = await postWorkerResponses(
      fixture,
      {
        input: 'Hello',
        model: WORKER_LOGICAL_MODEL_ID,
        client_metadata: {
          session_id: 'session',
          thread_id: 'thread',
          'x-codex-turn-metadata': native,
        },
      },
      {
        'session-id': 'session',
        'thread-id': 'thread',
        'x-client-request-id': 'thread',
        'x-codex-turn-metadata': native,
      }
    );
    expect(response.status).toBe(400);
    expect(fixture.dispatcher.responseCalls).toEqual([]);
  });

  it('preserves provider-compatible Chat Completions message fields', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    const toolCalls = [
      {
        function: { arguments: '{"path":"README.md"}', name: 'read_file' },
        id: 'call_worker_1',
        type: 'function',
      },
    ];
    const response = await fixture.app.request('/api/worker-inference/v1/chat/completions', {
      body: JSON.stringify({
        messages: [{ content: null, role: 'assistant', tool_calls: toolCalls }],
        model: WORKER_LOGICAL_MODEL_ID,
        tools: [{ function: { name: 'read_file' }, type: 'function' }],
      }),
      headers: {
        authorization: `Bearer ${fixture.token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });

    expect(response.status).toBe(200);
    expect(fixture.dispatcher.chatCalls[0]?.request).toMatchObject({
      messages: [{ content: null, role: 'assistant', tool_calls: toolCalls }],
      tools: [{ function: { name: 'read_file' }, type: 'function' }],
    });
  });

  it('rejects duplicate Chat and Responses callable keys before provider dispatch', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    const cases = [
      {
        body: {
          messages: [{ content: 'Hello', role: 'user' }],
          model: WORKER_PROVIDER_MODEL,
          tools: [
            { function: { name: 'read_file' }, type: 'function' },
            { function: { name: 'read_file' }, type: 'function' },
          ],
        },
        path: '/api/worker-inference/v1/chat/completions',
      },
      {
        body: {
          input: 'Hello',
          model: WORKER_LOGICAL_MODEL_ID,
          tools: [
            { name: 'read_file', parameters: { type: 'object' }, type: 'function' },
            { name: 'read_file', parameters: { type: 'object' }, type: 'function' },
          ],
        },
        path: '/api/worker-inference/v1/responses',
      },
      {
        body: {
          input: 'Hello',
          model: WORKER_LOGICAL_MODEL_ID,
          tools: [{ type: 'tool_search' }, { type: 'tool_search' }],
        },
        path: '/api/worker-inference/v1/responses',
      },
    ];

    for (const testCase of cases) {
      const response = await fixture.app.request(testCase.path, {
        body: JSON.stringify(testCase.body),
        headers: {
          authorization: `Bearer ${fixture.token}`,
          'content-type': 'application/json',
        },
        method: 'POST',
      });

      expect(response.status).toBe(403);
      await expect(response.json()).resolves.toMatchObject({
        error: { code: 'worker_inference_lineage_mismatch' },
      });
    }
    expect(fixture.dispatcher.chatCalls).toEqual([]);
    expect(fixture.dispatcher.responseCalls).toEqual([]);
  });

  it('preserves Chat Completions and Responses SSE bytes', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    const cases = [
      {
        body: { input: 'Hello', model: WORKER_LOGICAL_MODEL_ID, stream: true },
        expected: 'data: {"type":"response.completed"}\n\ndata: [DONE]\n\n',
        path: '/api/worker-inference/v1/responses',
      },
      {
        body: {
          messages: [{ content: 'Hello', role: 'user' }],
          model: WORKER_LOGICAL_MODEL_ID,
          stream: true,
        },
        expected: 'data: {"id":"chatcmpl_worker_stream"}\n\ndata: [DONE]\n\n',
        path: '/api/worker-inference/v1/chat/completions',
      },
    ];

    for (const testCase of cases) {
      const response = await fixture.app.request(testCase.path, {
        body: JSON.stringify(testCase.body),
        headers: {
          authorization: `Bearer ${fixture.token}`,
          'content-type': 'application/json',
          'x-codex-turn-state': 'worker-stream-request-state',
          'x-request-id': 'private-worker-stream-request-id',
        },
        method: 'POST',
      });

      expect(response.status).toBe(200);
      expect(response.headers.get('content-type')).toContain('text/event-stream');
      expect(response.headers.get('x-codex-turn-state')).toBe('worker-provider-response-state');
      expect(response.headers.get('x-request-id')).toBeNull();
      await expect(response.text()).resolves.toBe(testCase.expected);
    }

    expect(fixture.dispatcher.responseCalls[0]?.context.transport).toMatchObject({
      codexTurnState: 'worker-stream-request-state',
    });
    expect(fixture.dispatcher.chatCalls[0]?.context.transport).toMatchObject({
      codexTurnState: 'worker-stream-request-state',
    });
  });

  it('cancels worker inference streams once and preserves its terminal evidence', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    fixture.dispatcher.shouldHoldResponsesStream = true;
    const request = new Request('http://localhost/api/worker-inference/v1/responses', {
      body: JSON.stringify({
        input: 'Wait for cancellation',
        model: WORKER_LOGICAL_MODEL_ID,
        stream: true,
      }),
      headers: {
        authorization: `Bearer ${fixture.token}`,
        'content-type': 'application/json',
      },
      method: 'POST',
    });
    const response = await fixture.app.fetch(request);
    const dispatchSignal = (
      fixture.dispatcher.responseCalls[0]?.context.transport as
        | { readonly signal?: AbortSignal }
        | undefined
    )?.signal;
    const reader = response.body!.getReader();

    expect(response.status).toBe(200);
    expect(dispatchSignal).toBeInstanceOf(AbortSignal);
    expect(dispatchSignal?.aborted).toBe(false);
    await expect(reader.read()).resolves.toMatchObject({ done: false });
    await reader.cancel('consumer disconnected');

    expect(fixture.dispatcher.responsesStreamCancellations).toEqual(['consumer disconnected']);
    expect(readWorkerInferenceCapabilityCalls(fixture)).toEqual([
      expect.objectContaining({
        errorCode: 'worker_inference_cancelled',
        status: 'aborted',
      }),
    ]);
    expect(() =>
      fixture.dispatcher.responseCalls[0]?.context.onUsage?.({
        input_tokens: 99,
        output_tokens: 99,
        total_tokens: 198,
      })
    ).not.toThrow();

    const workspaceDb = openWorkspaceDb(
      fixture.coreDb!.dataRoot,
      fixture.environmentPackage.scope.workspaceId
    );
    try {
      applyScopedMigrations(workspaceDb);
      expect(
        workspaceDb.sqlite
          .prepare(
            `SELECT outcome, error_code AS errorCode
             FROM audit_events
             WHERE action = 'capability.finish'
             ORDER BY created_at ASC`
          )
          .all()
      ).toEqual([{ errorCode: 'worker_inference_cancelled', outcome: 'cancelled' }]);
      expect(
        workspaceDb.sqlite
          .prepare(
            `SELECT quantity, source, unit
             FROM usage_records
             ORDER BY source ASC`
          )
          .all()
      ).toEqual([
        {
          quantity: 3,
          source: 'llm-gateway-adapter-reported:input',
          unit: 'tokens',
        },
        {
          quantity: 1,
          source: 'llm-gateway-adapter-reported:output',
          unit: 'tokens',
        },
      ]);
    } finally {
      workspaceDb.sqlite.close();
    }
  });

  it('emits a bounded SSE heartbeat while worker inference is idle', async () => {
    vi.useFakeTimers();
    const fixture = createWorkerInferenceRouteFixture();
    fixture.dispatcher.shouldHoldResponsesStream = true;
    const response = await postWorkerResponses(fixture, {
      input: 'Wait through one idle interval',
      model: WORKER_LOGICAL_MODEL_ID,
      stream: true,
    });
    const reader = response.body!.getReader();

    try {
      await expect(reader.read()).resolves.toMatchObject({ done: false });
      let heartbeat: ReadableStreamReadResult<Uint8Array> | null = null;
      void reader.read().then((result) => {
        heartbeat = result;
      });

      await vi.advanceTimersByTimeAsync(1000);

      expect(heartbeat).toEqual({
        done: false,
        value: new TextEncoder().encode(': openkit-worker-inference-heartbeat\n\n'),
      });
    } finally {
      await reader.cancel('heartbeat test completed');
      vi.useRealTimers();
    }
  });

  it('cancels the upstream stream when a real HTTP consumer disconnects', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    fixture.dispatcher.shouldHoldResponsesStream = true;
    const server = serve({ fetch: fixture.app.fetch, hostname: '127.0.0.1', port: 0 });
    await new Promise<void>((resolve, reject) => {
      server.once('error', reject);
      server.once('listening', resolve);
    });
    const address = server.address();
    if (!address || typeof address === 'string') {
      throw new Error('Worker inference network test did not bind a TCP address.');
    }

    try {
      const response = await fetch(
        `http://127.0.0.1:${address.port}/api/worker-inference/v1/responses`,
        {
          body: JSON.stringify({
            input: 'Wait for network cancellation',
            model: WORKER_LOGICAL_MODEL_ID,
            stream: true,
          }),
          headers: {
            authorization: `Bearer ${fixture.token}`,
            'content-type': 'application/json',
          },
          method: 'POST',
        }
      );
      const reader = response.body!.getReader();

      expect(response.status).toBe(200);
      await expect(reader.read()).resolves.toMatchObject({ done: false });
      await reader.cancel('network consumer disconnected');
      await vi.waitFor(() => {
        expect(fixture.dispatcher.responsesStreamCancellations).toHaveLength(1);
      });
      expect(readWorkerInferenceCapabilityCalls(fixture)).toEqual([
        expect.objectContaining({
          errorCode: 'worker_inference_cancelled',
          status: 'aborted',
        }),
      ]);
    } finally {
      server.closeAllConnections();
      await new Promise<void>((resolve, reject) => {
        server.close((error) => (error ? reject(error) : resolve()));
      });
    }
  });

  it.each([
    {
      caseName: 'request-signal cancellation',
      error: 'signal-reason' as const,
      expectedCode: 'worker_inference_cancelled',
      expectedLedgerCode: 'worker_inference_cancelled',
      expectedStatus: 499,
      expectedLedgerStatus: 'aborted',
    },
    {
      caseName: 'independent provider failure after request abort',
      error: new Error('private independent provider failure'),
      expectedCode: 'worker_inference_request_failed',
      expectedLedgerCode: 'worker_inference_failed',
      expectedStatus: 400,
      expectedLedgerStatus: 'failed',
    },
    {
      caseName: 'typed unsupported feature after request abort',
      error: new GatewayUnsupportedFeatureError('pi-ai Responses function tools'),
      expectedCode: 'unsupported_gateway_feature',
      expectedLedgerCode: 'unsupported_gateway_feature',
      expectedStatus: 400,
      expectedLedgerStatus: 'failed',
    },
  ])('classifies $caseName by the thrown error cause', async (testCase) => {
    const fixture = createWorkerInferenceRouteFixture();
    const abortController = new AbortController();
    fixture.dispatcher.responseErrorAfterAbort = testCase.error;
    const responsePromise = fixture.app.fetch(
      new Request('http://localhost/api/worker-inference/v1/responses', {
        body: JSON.stringify({ input: 'Wait for abort', model: WORKER_LOGICAL_MODEL_ID }),
        headers: {
          authorization: `Bearer ${fixture.token}`,
          'content-type': 'application/json',
        },
        method: 'POST',
        signal: abortController.signal,
      })
    );

    await expect.poll(() => fixture.dispatcher.responseCalls.length).toBe(1);
    abortController.abort(new DOMException('Worker request cancelled.', 'AbortError'));
    const response = await responsePromise;

    expect(response.status).toBe(testCase.expectedStatus);
    await expect(response.json()).resolves.toMatchObject({
      error: { code: testCase.expectedCode },
    });
    expect(readWorkerInferenceCapabilityCalls(fixture)).toEqual([
      expect.objectContaining({
        errorCode: testCase.expectedLedgerCode,
        status: testCase.expectedLedgerStatus,
      }),
    ]);
  });

  it('preserves sanitized terminal SSE when durable finish audit insertion fails', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    const workspaceDb = openWorkspaceDb(
      fixture.coreDb!.dataRoot,
      fixture.environmentPackage.scope.workspaceId
    );

    try {
      applyScopedMigrations(workspaceDb);
      workspaceDb.sqlite.exec(`
        CREATE TRIGGER reject_worker_inference_finish_audit
        BEFORE INSERT ON audit_events
        WHEN NEW.action = 'capability.finish'
        BEGIN
          SELECT RAISE(ABORT, 'private capability finish audit trigger failure');
        END
      `);
    } finally {
      workspaceDb.sqlite.close();
    }

    const response = await postWorkerResponses(fixture, {
      input: 'Finish despite audit failure',
      model: WORKER_LOGICAL_MODEL_ID,
      stream: true,
    });

    expect(response.status).toBe(200);
    const body = await response.text();
    expect(body).toContain('data: {"type":"response.completed"}');
    expect(body).toContain('data: [DONE]');
    expect(body).not.toContain('private capability finish audit trigger failure');
  });

  it('records a fresh durable capability request for every worker call', async () => {
    const dataRoot = mkdtempSync(join(tmpdir(), 'openkit-worker-inference-ledger-'));
    const coreDb = openCoreDb(dataRoot);

    try {
      applyMigrations(coreDb);
      const fixture = createWorkerInferenceRouteFixture(true, coreDb);

      await postWorkerResponses(fixture, {
        input: 'First sibling call',
        model: WORKER_LOGICAL_MODEL_ID,
      });
      await postWorkerResponses(fixture, {
        input: 'Second sibling call',
        model: WORKER_LOGICAL_MODEL_ID,
      });

      const workspaceDb = openWorkspaceDb(dataRoot, 'ws_00000000-0000-7000-8000-000000000001');
      try {
        applyScopedMigrations(workspaceDb);
        const calls = workspaceDb.sqlite
          .prepare(
            `SELECT request_id AS requestId, workspace_id AS workspaceId,
                    thread_id AS threadId, turn_id AS turnId, agent_id AS agentId,
                    agent_session_id AS agentSessionId, provider_ref AS providerRef,
                    capability_id AS capabilityId, operation, status
             FROM capability_calls
             ORDER BY started_at ASC, call_id ASC`
          )
          .all() as Array<Record<string, unknown>>;

        expect(calls).toHaveLength(2);
        expect(new Set(calls.map((call) => call.requestId)).size).toBe(2);
        expect(calls.map((call) => call.requestId)).not.toContain(
          fixture.environmentPackage.scope.requestId
        );
        expect(calls).toEqual([
          expect.objectContaining({
            agentId: fixture.environmentPackage.agent.agentId,
            agentSessionId: fixture.environmentPackage.scope.agentSessionId,
            capabilityId: 'llm.responses',
            operation: 'responses',
            providerRef: null,
            status: 'succeeded',
            threadId: fixture.environmentPackage.scope.threadId,
            turnId: fixture.environmentPackage.scope.turnId,
            workspaceId: fixture.environmentPackage.scope.workspaceId,
          }),
          expect.objectContaining({ status: 'succeeded' }),
        ]);
      } finally {
        workspaceDb.sqlite.close();
      }
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('denies worker inference when the exact AEP actor loses current Workspace authority', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    fixture.coreDb!.sqlite.transaction(() => {
      disableCanonicalUser(fixture.coreDb!, 'usr_00000000-0000-7000-8000-000000000001');
    })();

    const response = await postWorkerResponses(fixture, {
      input: 'Do not dispatch',
      model: WORKER_LOGICAL_MODEL_ID,
    });

    expect(response.status).toBe(503);
    await expect(response.json()).resolves.toMatchObject({
      error: { code: 'worker_inference_unavailable' },
    });
    expect(fixture.dispatcher.chatCalls).toEqual([]);
    expect(fixture.dispatcher.responseCalls).toEqual([]);

    const workspaceDb = openWorkspaceDb(
      fixture.coreDb!.dataRoot,
      fixture.environmentPackage.scope.workspaceId
    );
    try {
      applyScopedMigrations(workspaceDb);
      expect(
        workspaceDb.sqlite.prepare('SELECT COUNT(*) AS count FROM capability_calls').get()
      ).toEqual({ count: 0 });
      expect(
        workspaceDb.sqlite.prepare('SELECT COUNT(*) AS count FROM usage_records').get()
      ).toEqual({ count: 0 });
    } finally {
      workspaceDb.sqlite.close();
    }
  });

  it('reloads administrator provenance and refuses its revocation even after the actor becomes a Workspace member', async () => {
    const fixture = createWorkerInferenceRouteFixture(true, undefined, true, true, false, {
      adminBearer: true,
    });
    const reloaded = openCoreDb(fixture.coreDb!.dataRoot);
    try {
      const admission = reloaded.sqlite
        .prepare(
          'SELECT server_admin_token_id AS tokenId FROM scheduler_admission_entries WHERE turn_id = ?'
        )
        .get(fixture.environmentPackage.scope.turnId);
      expect(admission).toEqual({ tokenId: 'token_worker_inference_admin' });
      expect(
        (
          await postWorkerResponses(fixture, {
            input: 'Use the presented administrator authority.',
            model: WORKER_LOGICAL_MODEL_ID,
          })
        ).status
      ).toBe(200);
      const joinedAt = new Date().toISOString();
      reloaded.sqlite
        .prepare(`INSERT INTO workspace_members (
        workspace_id, user_id, status, access_level, invitation_id, joined_at,
        removed_at, revision, created_at, updated_at
      ) VALUES ('ws_00000000-0000-7000-8000-000000000001', 'usr_00000000-0000-7e31-ad22-0a4ca76f76f3', 'active', 'editor', NULL, ?, NULL, 1, ?, ?)`)
        .run(joinedAt, joinedAt, joinedAt);
      reloaded.sqlite
        .prepare(
          "UPDATE openkit_access_tokens SET status = 'revoked', revoked_at = ? WHERE token_id = ?"
        )
        .run(new Date().toISOString(), 'token_worker_inference_admin');
      const refused = await postWorkerResponses(fixture, {
        input: 'Do not substitute membership for revoked provenance.',
        model: WORKER_LOGICAL_MODEL_ID,
      });
      expect(refused.status).toBe(503);
      expect(fixture.dispatcher.responseCalls).toHaveLength(1);
      expect(
        reloaded.sqlite
          .prepare(
            'SELECT server_admin_token_id AS tokenId FROM scheduler_admission_entries WHERE turn_id = ?'
          )
          .get(fixture.environmentPackage.scope.turnId)
      ).toEqual(admission);
    } finally {
      reloaded.sqlite.close();
    }
  });

  it('uses the exact admitted admin bearer for nonmember inference and denies revocation or lineage drift', async () => {
    const fixture = createWorkerInferenceRouteFixture(true, undefined, true, true, false, {
      adminBearer: true,
    });
    const request = () =>
      postWorkerResponses(fixture, {
        input: 'Admin worker inference',
        model: WORKER_LOGICAL_MODEL_ID,
      });

    expect((await request()).status).toBe(200);
    expect(fixture.dispatcher.responseCalls).toHaveLength(1);

    fixture
      .coreDb!.sqlite.prepare(
        "UPDATE openkit_access_tokens SET status = 'revoked', revoked_at = ? WHERE token_id = 'token_worker_inference_admin'"
      )
      .run(new Date().toISOString());
    const revoked = await request();
    expect(revoked.status).toBe(503);
    await expect(revoked.json()).resolves.toMatchObject({
      error: { code: 'worker_inference_unavailable' },
    });
    expect(fixture.dispatcher.responseCalls).toHaveLength(1);

    fixture
      .coreDb!.sqlite.prepare(
        "UPDATE openkit_access_tokens SET status = 'active', revoked_at = NULL WHERE token_id = 'token_worker_inference_admin'"
      )
      .run();
    fixture
      .coreDb!.sqlite.prepare(
        'UPDATE scheduler_execution_attempts SET input_ref = ? WHERE turn_id = ?'
      )
      .run('pkg_other', fixture.environmentPackage.scope.turnId);
    const mismatched = await request();
    expect(mismatched.status).toBe(503);
    await expect(mismatched.json()).resolves.toMatchObject({
      error: { code: 'worker_inference_unavailable' },
    });
    expect(fixture.dispatcher.responseCalls).toHaveLength(1);
  });

  it('rejects missing and invalid worker identity', async () => {
    const trusted = createWorkerInferenceRouteFixture();
    const requests = [
      trusted.app.request('/api/worker-inference/v1/responses', {
        body: JSON.stringify({ input: 'Hello', model: WORKER_LOGICAL_MODEL_ID }),
        headers: { 'content-type': 'application/json' },
        method: 'POST',
      }),
      trusted.app.request('/api/worker-inference/v1/responses', {
        body: JSON.stringify({ input: 'Hello', model: WORKER_LOGICAL_MODEL_ID }),
        headers: { authorization: 'Bearer okt_product_token', 'content-type': 'application/json' },
        method: 'POST',
      }),
    ];

    for (const pending of requests) {
      const response = await pending;

      expect(response.status).toBe(401);
      await expect(response.json()).resolves.toMatchObject({
        error: { code: 'worker_inference_unauthorized' },
      });
    }
    expect(trusted.dispatcher.responseCalls).toEqual([]);
  });

  it('rejects caller authority conflicts before provider dispatch', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    const conflicts = [
      { model: 'other-model' },
      { model_id: 'other-model' },
      { providerId: 'public-default' },
      { provider_ref: 'public-default' },
      { workspaceId: 'ws_00000000-0000-71f5-922f-6fd42f52f580' },
      { metadata: { openkit: { requestId: 'req_other' } } },
      { policy: { mode: 'allow' } },
    ];

    for (const conflict of conflicts) {
      const response = await postWorkerResponses(fixture, {
        input: 'Hello',
        model: WORKER_LOGICAL_MODEL_ID,
        ...conflict,
      });

      expect(response.status).toBe(403);
      await expect(response.json()).resolves.toMatchObject({
        error: { code: 'worker_inference_lineage_mismatch' },
      });
    }

    const headerConflict = await postWorkerResponses(
      fixture,
      { input: 'Hello', model: WORKER_LOGICAL_MODEL_ID },
      { 'x-openkit-workspace-id': 'ws_00000000-0000-7000-8000-000000000001' }
    );

    expect(headerConflict.status).toBe(403);
    expect(fixture.dispatcher.responseCalls).toEqual([]);
  });

  it('rejects caller authority aliases even when they match trusted AEP authority', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    const scope = fixture.environmentPackage.scope;
    const aliases = [
      { provider_id: 'agent-openrouter' },
      { workspaceId: scope.workspaceId },
      { agent_session_id: scope.agentSessionId },
      { package_snapshot_id: fixture.environmentPackage.snapshotId },
      { request_id: scope.requestId },
      { metadata: { openkit: { routeId: 'nanocore-gateway' } } },
    ];

    for (const alias of aliases) {
      const response = await postWorkerResponses(fixture, {
        input: 'Hello',
        model: WORKER_LOGICAL_MODEL_ID,
        ...alias,
      });
      expect(response.status).toBe(403);
      await expect(response.json()).resolves.toMatchObject({
        error: { code: 'worker_inference_lineage_mismatch' },
      });
    }
    expect(fixture.dispatcher.responseCalls).toEqual([]);
  });

  it('enforces the persisted absolute attempt deadline at the mediated inference boundary', async () => {
    const f = createWorkerInferenceRouteFixture(true, undefined, true, true, false, {
      durableAuthority: true,
    });
    const db = f.coreDb!;
    const scope = f.environmentPackage.scope;
    const present = db.sqlite
      .prepare(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='scheduler_execution_attempts'"
      )
      .get();
    expect(
      present,
      'The fixture must seed the current attempt before route evidence is meaningful.'
    ).toBeDefined();
    const attempt = db.sqlite
      .prepare('SELECT * FROM scheduler_execution_attempts WHERE turn_id = ?')
      .get(scope.turnId) as Record<string, unknown>;
    expect(attempt).toBeDefined();
    expect(Number.isFinite(Date.parse(String(attempt.deadline)))).toBe(true);
    // Move only the authority deadline into the fixture's still-live adapter window.
    const deadline = new Date(Date.now() + 1000).toISOString();
    db.sqlite
      .prepare('UPDATE scheduler_execution_attempts SET deadline = ? WHERE attempt_id = ?')
      .run(deadline, attempt.attempt_id);
    vi.useFakeTimers({ toFake: ['Date'] });
    try {
      vi.setSystemTime(Date.parse(deadline) - 1);
      expect(
        (await postWorkerResponses(f, { input: 'Before expiry', model: WORKER_LOGICAL_MODEL_ID }))
          .status
      ).toBe(200);
      const calls = f.dispatcher.responseCalls.length;
      vi.setSystemTime(Date.parse(deadline));
      expect(
        (await postWorkerResponses(f, { input: 'At expiry', model: WORKER_LOGICAL_MODEL_ID }))
          .status
      ).toBe(403);
      expect(f.dispatcher.responseCalls).toHaveLength(calls);
      expect(
        db.sqlite
          .prepare('SELECT deadline FROM scheduler_execution_attempts WHERE attempt_id = ?')
          .get(attempt.attempt_id)
      ).toEqual({ deadline });
    } finally {
      vi.useRealTimers();
    }
  });

  it('fails closed when the durable lease dies or a restored session has no AEP', async () => {
    const deadLease = createWorkerInferenceRouteFixture();
    deadLease.expireLease();
    const deadLeaseResponse = await postWorkerResponses(deadLease, {
      input: 'Hello',
      model: WORKER_LOGICAL_MODEL_ID,
    });

    expect(deadLeaseResponse.status).toBe(403);
    await expect(deadLeaseResponse.json()).resolves.toMatchObject({
      error: { code: 'worker_inference_unauthorized' },
    });
    expect(deadLease.dispatcher.responseCalls).toEqual([]);

    const unhydrated = createWorkerInferenceRouteFixture();
    const scope = unhydrated.environmentPackage.scope;
    unhydrated.workerControlGateway.unregisterSession(unhydrated.environmentPackage.snapshotId);
    unhydrated.workerControlGateway.restoreSession({
      lineage: {
        agentSessionId: scope.agentSessionId,
        packageSnapshotId: unhydrated.environmentPackage.snapshotId,
        requestId: scope.requestId ?? null,
        threadId: scope.threadId,
        turnId: scope.turnId,
        workspaceId: scope.workspaceId,
      },
      registeredAt: '2026-07-13T00:00:01.000Z',
      sandboxBindingRef: unhydrated.sandboxBindingRef,
      workerCapabilityTokenHash: hashWorkerRouteToken(unhydrated.workerCapabilityToken),
      workerControlTokenHash: hashWorkerRouteToken(unhydrated.workerControlToken),
      workerInferenceTokenHash: hashWorkerRouteToken(unhydrated.token),
    });
    const unhydratedResponse = await postWorkerResponses(unhydrated, {
      input: 'Hello',
      model: WORKER_LOGICAL_MODEL_ID,
    });

    expect(unhydratedResponse.status).toBe(401);
    await expect(unhydratedResponse.json()).resolves.toMatchObject({
      error: { code: 'worker_inference_unauthorized' },
    });
    expect(unhydrated.dispatcher.responseCalls).toEqual([]);
  });

  it('strips cache hints and rejects provider-side state authority', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    const scope = fixture.environmentPackage.scope;
    const accepted = await postWorkerResponses(fixture, {
      input: 'Hello',
      model: WORKER_LOGICAL_MODEL_ID,
      prompt_cache_key: 'runtime-private-cache-key',
      safety_identifier: 'caller-safety-id',
      sessionId: 'runtime-cache-session',
      store: false,
    });

    expect(accepted.status).toBe(200);
    expect(fixture.dispatcher.responseCalls[0]?.request).toEqual({
      input: 'Hello',
      model: WORKER_PROVIDER_MODEL,
      prompt_cache_key: expect.stringMatching(/^openkit:responses:request:/),
      store: false,
      stream: false,
    });

    const conflicts = [
      { store: true },
      { previous_response_id: 'resp_shared_provider_state' },
      { conversation: 'conv_shared_provider_state' },
      { background: true },
      { service_tier: 'priority' },
      { openkit: { workspaceId: scope.workspaceId } },
      { lineage: { workspaceId: scope.workspaceId } },
      { scope: { workspaceId: scope.workspaceId } },
      { access_token: 'caller-token' },
      { client_secret: 'caller-secret' },
      { sourceId: 'source-caller' },
      { tools: [{ server_url: 'https://attacker.example/mcp', type: 'mcp' }] },
      { tools: [{ type: 'web_search_preview' }] },
      {
        tools: [
          {
            name: 'remote',
            tools: [{ type: 'web_search_preview' }],
            type: 'namespace',
          },
        ],
      },
      {
        tools: [
          {
            name: 'local',
            parameters: { type: 'object' },
            server_url: 'https://attacker.example/mcp',
            type: 'function',
          },
        ],
      },
      { tools: [{}] },
      { tools: [{ type: 7 }] },
    ];

    for (const conflict of conflicts) {
      const response = await postWorkerResponses(fixture, {
        input: 'Hello',
        model: WORKER_LOGICAL_MODEL_ID,
        ...conflict,
      });

      expect(response.status).toBe(403);
      await expect(response.json()).resolves.toMatchObject({
        error: { code: 'worker_inference_lineage_mismatch' },
      });
    }
    expect(fixture.dispatcher.responseCalls).toHaveLength(1);
  });

  it('rejects worker inference when durable capability storage is unavailable', async () => {
    const fixture = createWorkerInferenceRouteFixture(true, undefined, false);
    const response = await postWorkerResponses(fixture, {
      input: 'Hello',
      model: WORKER_LOGICAL_MODEL_ID,
    });

    expect(response.status).toBe(503);
    await expect(response.json()).resolves.toMatchObject({
      error: { code: 'worker_inference_unavailable' },
    });
    expect(fixture.dispatcher.responseCalls).toEqual([]);
  });

  it('projects durable workspace failures as worker inference unavailability', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    const originalDataRoot = fixture.coreDb!.dataRoot;
    const blockedParent = mkdtempSync(join(tmpdir(), 'openkit-worker-inference-blocked-'));
    const blockedDataRoot = join(blockedParent, 'not-a-directory');
    writeFileSync(blockedDataRoot, 'blocked');
    fixture.coreDb!.dataRoot = blockedDataRoot;

    try {
      const response = await postWorkerResponses(fixture, {
        input: 'Hello',
        model: WORKER_LOGICAL_MODEL_ID,
      });

      expect(response.status).toBe(503);
      await expect(response.json()).resolves.toMatchObject({
        error: { code: 'worker_inference_unavailable' },
      });
      expect(fixture.dispatcher.responseCalls).toEqual([]);
    } finally {
      fixture.coreDb!.dataRoot = originalDataRoot;
      rmSync(blockedParent, { force: true, recursive: true });
    }
  });

  it('marks dispatch and response serialization failures in the durable ledger', async () => {
    const dispatchFailure = createWorkerInferenceRouteFixture();
    dispatchFailure.dispatcher.responseError = new Error('private provider failure');
    const rejected = await postWorkerResponses(dispatchFailure, {
      input: 'Hello',
      model: WORKER_LOGICAL_MODEL_ID,
    });

    expect(rejected.status).toBe(400);
    expect(readWorkerInferenceCapabilityCalls(dispatchFailure)).toEqual([
      expect.objectContaining({ errorCode: 'worker_inference_failed', status: 'failed' }),
    ]);

    const serializationFailure = createWorkerInferenceRouteFixture();
    const cyclicResponse: Record<string, unknown> = {
      id: 'resp_cyclic',
      object: 'response',
      output: [],
      status: 'completed',
    };
    cyclicResponse.self = cyclicResponse;
    serializationFailure.dispatcher.responsesResponseOverride =
      cyclicResponse as OpenAICompatibleResponsesResponse;
    const unserializable = await postWorkerResponses(serializationFailure, {
      input: 'Hello',
      model: WORKER_LOGICAL_MODEL_ID,
    });

    expect(unserializable.status).toBe(400);
    expect(readWorkerInferenceCapabilityCalls(serializationFailure)).toEqual([
      expect.objectContaining({ errorCode: 'worker_inference_failed', status: 'failed' }),
    ]);
  });

  it.each([
    false,
    true,
  ])('preserves typed unsupported feature failures before stream=%s', async (stream) => {
    const fixture = createWorkerInferenceRouteFixture();
    const request = { input: 'Hello', model: WORKER_LOGICAL_MODEL_ID, stream };
    const supported = await postWorkerResponses(fixture, request);
    expect(supported.status).toBe(200);
    await supported.text();

    fixture.dispatcher.responseError = new GatewayUnsupportedFeatureError(
      'pi-ai Responses function tools token=tok_00000000-0000-7608-9cb9-96beaf03534f'
    );
    const rejected = await postWorkerResponses(fixture, request);
    const body = await rejected.json();
    const calls = readWorkerInferenceCapabilityCalls(fixture);
    expect(rejected.status).toBe(400);
    expect(calls).toEqual([
      expect.objectContaining({ errorCode: null, status: 'succeeded' }),
      expect.objectContaining({ errorCode: 'unsupported_gateway_feature', status: 'failed' }),
    ]);
    expect(body).toEqual({
      error: {
        code: 'unsupported_gateway_feature',
        message: 'Requested features are not supported by the Gateway.',
        type: 'invalid_request_error',
      },
    });
    expect(JSON.stringify({ body, calls })).not.toMatch(/pi-ai|tok_secret/);

    fixture.dispatcher.responseError = Object.assign(
      new Error('private token=tok_00000000-0000-7608-9cb9-96beaf03534f'),
      {
        code: 'unsupported_gateway_feature',
      }
    );
    const untyped = await postWorkerResponses(fixture, request);
    expect(await untyped.json()).toMatchObject({
      error: { code: 'worker_inference_request_failed' },
    });
    expect(readWorkerInferenceCapabilityCalls(fixture).at(-1)).toMatchObject({
      errorCode: 'worker_inference_failed',
      status: 'failed',
    });
  });

  it('projects typed provider request failures as generic worker errors', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    fixture.dispatcher.responseError = attachPiAiFailure(
      new OpenAICompatibleProviderError({
        code: 'model_not_supported',
        message: 'Unsupported model token=tok_00000000-0000-7608-9cb9-96beaf03534f',
        status: 400,
        type: 'provider_error',
      })
    ) as OpenAICompatibleProviderError;

    const response = await postWorkerResponses(fixture, {
      input: 'Hello',
      model: WORKER_LOGICAL_MODEL_ID,
    });
    const body = await response.json();
    const calls = readWorkerInferenceCapabilityCalls(fixture);

    expect(response.status).toBe(400);
    expect(body).toMatchObject({
      error: {
        code: 'gateway_provider_request_invalid',
        message: 'Provider rejected the request.',
        type: 'provider_error',
      },
    });
    expect(calls).toEqual([
      expect.objectContaining({ errorCode: 'worker_inference_failed', status: 'failed' }),
    ]);
    expect(JSON.stringify({ body, calls })).not.toContain(
      'tok_00000000-0000-7608-9cb9-96beaf03534f'
    );
  });

  it('marks post-start stream read failures before emitting terminal SSE', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    fixture.dispatcher.shouldFailResponsesStream = true;
    const response = await postWorkerResponses(fixture, {
      input: 'Hello',
      model: WORKER_LOGICAL_MODEL_ID,
      stream: true,
    });

    expect(response.status).toBe(200);
    const body = await response.text();
    expect(body).toContain('gateway_stream_failed');
    expect(body).not.toContain('private upstream stream failure');
    const terminal = body
      .split('\n')
      .filter((line) => line.startsWith('data: {'))
      .map((line) => JSON.parse(line.slice(6)))
      .find((event) => event.type === 'response.failed');
    expect(terminal).toMatchObject({
      response: {
        status: 'failed',
        error: { code: 'gateway_stream_failed', message: 'Worker inference stream failed.' },
      },
    });
    expect(readWorkerInferenceCapabilityCalls(fixture)).toEqual([
      expect.objectContaining({
        errorCode: 'worker_inference_stream_failed',
        status: 'failed',
      }),
    ]);
  });

  it('preserves known inner stream diagnostic codes on worker capability calls', async () => {
    for (const testCase of [
      {
        code: 'provider_stream_truncated',
        durableErrorCode: 'provider_stream_truncated',
      },
      {
        code: 'provider_stream_failed',
        durableErrorCode: 'provider_stream_failed',
      },
      {
        code: 'provider_transport_failure',
        durableErrorCode: 'worker_inference_stream_failed',
      },
    ]) {
      const fixture = createWorkerInferenceRouteFixture();
      fixture.dispatcher.shouldFailResponsesStream = true;
      fixture.dispatcher.responsesStreamFailure = Object.assign(
        new Error('Provider stream failed. token=tok_00000000-0000-7608-9cb9-96beaf03534f'),
        { code: testCase.code }
      );
      const response = await postWorkerResponses(fixture, {
        input: 'Hello',
        model: WORKER_LOGICAL_MODEL_ID,
        stream: true,
      });

      expect(response.status).toBe(200);
      const body = await response.text();
      expect(body).toContain('gateway_stream_failed');
      expect(body).not.toContain(testCase.code);
      expect(body).not.toContain('tok_00000000-0000-7608-9cb9-96beaf03534f');
      const terminal = body
        .split('\n')
        .filter((line) => line.startsWith('data: {'))
        .map((line) => JSON.parse(line.slice(6)))
        .find((event) => event.type === 'response.failed');
      expect(terminal).toMatchObject({
        response: {
          status: 'failed',
          error: { code: 'gateway_stream_failed', message: 'Worker inference stream failed.' },
        },
      });
      expect(readWorkerInferenceCapabilityCalls(fixture)).toEqual([
        expect.objectContaining({
          errorCode: testCase.durableErrorCode,
          status: 'failed',
        }),
      ]);
    }
  });

  it('records classified worker stream failures as the public OpenKit code', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    fixture.dispatcher.shouldFailResponsesStream = true;
    fixture.dispatcher.responsesStreamFailure = attachPiAiFailure(
      new Error('rate limit exceeded token=tok_00000000-0000-7608-9cb9-96beaf03534f')
    ) as Error;
    const response = await postWorkerResponses(fixture, {
      input: 'Hello',
      model: WORKER_LOGICAL_MODEL_ID,
      stream: true,
    });

    expect(response.status).toBe(200);
    const body = await response.text();
    expect(body).toContain('gateway_provider_rate_limited');
    expect(body).not.toContain('tok_00000000-0000-7608-9cb9-96beaf03534f');
    expect(body).not.toContain('rate limit exceeded');
    expect(readWorkerInferenceCapabilityCalls(fixture)).toEqual([
      expect.objectContaining({
        errorCode: 'gateway_provider_rate_limited',
        status: 'failed',
      }),
    ]);
  });

  it('records unsupported-feature stream failures as invalid request, not the uncoded envelope', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    fixture.dispatcher.shouldFailResponsesStream = true;
    fixture.dispatcher.responsesStreamFailure = new GatewayUnsupportedFeatureError(
      'pi-ai Responses reasoning stream'
    );
    const response = await postWorkerResponses(fixture, {
      input: 'Hello',
      model: WORKER_LOGICAL_MODEL_ID,
      stream: true,
    });

    expect(response.status).toBe(200);
    const body = await response.text();
    expect(body).toContain('gateway_provider_request_invalid');
    expect(body).not.toContain('reasoning stream');
    expect(body).not.toContain('unsupported_gateway_feature');
    expect(readWorkerInferenceCapabilityCalls(fixture)).toEqual([
      expect.objectContaining({
        errorCode: 'gateway_provider_request_invalid',
        status: 'failed',
      }),
    ]);
  });

  it('records provider registry drift as a failed capability call without fallback', async () => {
    const fixture = createWorkerInferenceRouteFixture(true, undefined, true, false, false, {
      persistedTurn: true,
    });
    const response = await postWorkerResponses(fixture, {
      input: 'Hello',
      model: WORKER_LOGICAL_MODEL_ID,
    });

    expect(response.status).toBe(503);
    await expect(response.json()).resolves.toMatchObject({
      error: { code: 'gateway_logical_model_unavailable' },
    });
    expect(fixture.dispatcher.responseCalls).toEqual([]);

    expect(readWorkerInferenceCapabilityCalls(fixture)).toEqual([
      expect.objectContaining({
        errorCode: 'gateway_logical_model_unavailable',
        packageSnapshotId: fixture.environmentPackage.snapshotId,
        providerRef: null,
        runtimeCacheLineageRef: null,
        runtimeOriginRef: null,
        status: 'failed',
      }),
    ]);
  });

  it('decodes identity and Zstd JSON into the same provider request', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    const body = JSON.stringify({
      input: 'Compressed worker input',
      model: WORKER_LOGICAL_MODEL_ID,
    });
    const identity = await postRawWorkerResponses(fixture, body);
    const compressed = await postRawWorkerResponses(fixture, zstdCompressSync(body), {
      'content-encoding': 'zstd',
    });

    expect(identity.status).toBe(200);
    expect(compressed.status).toBe(200);
    expect(fixture.dispatcher.responseCalls).toHaveLength(2);
    for (const call of fixture.dispatcher.responseCalls) {
      expect(call.request).toEqual(
        expect.objectContaining({
          input: 'Compressed worker input',
          model: WORKER_PROVIDER_MODEL,
          prompt_cache_key: expect.stringMatching(/^openkit:responses:request:/),
          store: false,
          stream: false,
        })
      );
    }
    expect(fixture.dispatcher.responseCalls[1]?.request.prompt_cache_key).not.toBe(
      fixture.dispatcher.responseCalls[0]?.request.prompt_cache_key
    );
  });

  it('rejects unsupported representations and malformed worker JSON', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    const cases = [
      {
        body: JSON.stringify({ input: 'Hello', model: WORKER_LOGICAL_MODEL_ID }),
        code: 'worker_inference_unsupported_media_type',
        headers: { 'content-type': 'text/plain' },
        status: 415,
      },
      {
        body: JSON.stringify({ input: 'Hello', model: WORKER_LOGICAL_MODEL_ID }),
        code: 'worker_inference_unsupported_content_encoding',
        headers: { 'content-encoding': 'gzip' },
        status: 415,
      },
      {
        body: Buffer.from([0x28, 0xb5, 0x2f, 0xfd, 0xff]),
        code: 'worker_inference_invalid_request',
        headers: { 'content-encoding': 'zstd' },
        status: 400,
      },
      {
        body: Buffer.from([0xff]),
        code: 'worker_inference_invalid_request',
        headers: {},
        status: 400,
      },
      {
        body: '{',
        code: 'worker_inference_invalid_request',
        headers: {},
        status: 400,
      },
    ];

    for (const testCase of cases) {
      const response = await postRawWorkerResponses(fixture, testCase.body, testCase.headers);

      expect(response.status).toBe(testCase.status);
      await expect(response.json()).resolves.toMatchObject({
        error: { code: testCase.code },
      });
    }
    expect(fixture.dispatcher.responseCalls).toEqual([]);
  });

  it('rejects encoded and decoded worker bodies above the fixed limit', async () => {
    const fixture = createWorkerInferenceRouteFixture();
    const encodedOverflow = await postRawWorkerResponses(
      fixture,
      Buffer.alloc(WORKER_INFERENCE_TEST_BODY_LIMIT + 1, 0x20)
    );
    const decodedBody = JSON.stringify({
      input: 'x'.repeat(WORKER_INFERENCE_TEST_BODY_LIMIT),
      model: WORKER_LOGICAL_MODEL_ID,
    });
    const decodedOverflow = await postRawWorkerResponses(fixture, zstdCompressSync(decodedBody), {
      'content-encoding': 'zstd',
    });

    for (const response of [encodedOverflow, decodedOverflow]) {
      expect(response.status).toBe(413);
      await expect(response.json()).resolves.toMatchObject({
        error: { code: 'worker_inference_payload_too_large' },
      });
    }
    expect(fixture.dispatcher.responseCalls).toEqual([]);
  });

  it('authenticates only the worker-inference token family', () => {
    const source = readFileSync(new URL('./llm/gateway-routes.ts', import.meta.url), 'utf8');

    expect(source).toContain('workerInferenceTokenHash');
    expect(source).toContain("tokenFamily: 'inference'");
    expect(source).not.toContain('authenticatePackageToken(authorization)');
  });
});

// This fixture supplies confirmed image evidence; the production resolver and subject checks still run.
vi.mock('./runtime/agent-environment.js', async (importOriginal) => {
  const actual = await importOriginal<typeof import('./runtime/agent-environment.js')>();
  const { withTestPreparedNativeEnvironment } = await import(
    './test-support/native-environment.js'
  );
  return withTestPreparedNativeEnvironment(actual);
});

describe('worker inference pre-commit privacy', () => {
  it.each([
    { type: 'response.output_text.delta', delta: 'text' },
    { type: 'response.reasoning_text.delta', delta: 'reasoning' },
    {
      type: 'response.output_item.added',
      item: { type: 'function_call', id: 'call', name: 'status' },
    },
  ])('holds Response and heartbeat until the first output: %j', async (output) => {
    vi.useFakeTimers();
    const fixture = createWorkerInferenceRouteFixture();
    fixture.dispatcher.holdLifecycle = true;
    let visible: Response | undefined;
    const pending = postWorkerResponses(fixture, {
      input: 'hello',
      model: WORKER_LOGICAL_MODEL_ID,
      stream: true,
    }).then((response) => {
      visible = response;
      return response;
    });
    try {
      await vi.advanceTimersByTimeAsync(1000);
      expect(fixture.dispatcher.lifecycleController).toBeDefined();
      expect(visible).toBeUndefined();
      fixture.dispatcher.lifecycleController!.enqueue(
        new TextEncoder().encode(`data: ${JSON.stringify(output)}\n\n`)
      );
      const response = await pending;
      expect(response.status).toBe(200);
      const reader = response.body!.getReader();
      const bytes = new TextDecoder().decode((await reader.read()).value);
      expect(bytes).toContain('response.created');
      expect(bytes).not.toContain('heartbeat');
      await reader.read();
      const heartbeat = reader.read();
      await vi.advanceTimersByTimeAsync(1000);
      expect(new TextDecoder().decode((await heartbeat).value)).toContain(
        'openkit-worker-inference-heartbeat'
      );
      await reader.cancel();
    } finally {
      vi.useRealTimers();
    }
  });

  it('returns private JSON for a held first failure without publishing lifecycle or heartbeat', async () => {
    vi.useFakeTimers();
    const fixture = createWorkerInferenceRouteFixture();
    fixture.dispatcher.holdLifecycle = true;
    const pending = postWorkerResponses(fixture, {
      input: 'hello',
      model: WORKER_LOGICAL_MODEL_ID,
      stream: true,
    });
    try {
      await vi.advanceTimersByTimeAsync(1000);
      fixture.dispatcher.lifecycleController!.error(
        Object.assign(new Error('private quota'), {
          failure: { kind: 'quota_exhausted', settled: true },
        })
      );
      const response = await pending;
      expect(response.status).toBe(503);
      expect(response.headers.get('content-type')).toContain('application/json');
      const body = await response.text();
      expect(body).toContain('gateway_logical_model_unavailable');
      expect(body).not.toMatch(/heartbeat|response.created|private quota/);
    } finally {
      vi.useRealTimers();
    }
  });
});

/** Worker wire oracle exercises the same envelope through token and AEP authority. */
const workerCauseCases = [
  { name: 'retryable rate final', kind: 'rate_limited', status: 429, attempts: 4 },
  { name: 'retryable unavailable final', kind: 'provider_unavailable', status: 503, attempts: 4 },
  {
    name: 'auth final',
    kind: 'auth_rejected',
    status: 401,
    attempts: 1,
  },
  { name: 'quota final', kind: 'quota_exhausted', status: 429, attempts: 1 },
  { name: 'no available member', kind: undefined, status: 503, attempts: 0 },
  {
    name: 'failover disabled auth',
    kind: 'auth_rejected',
    status: 401,
    attempts: 1,
    disabled: true,
  },
  {
    name: 'failover disabled rate',
    kind: 'rate_limited',
    status: 429,
    attempts: 4,
    disabled: true,
  },
  { name: 'request-terminal context', kind: 'context_overflow', status: 400, attempts: 1 },
] as const;

describe('Round 2 worker exhaustion cause', () => {
  for (const endpoint of ['responses', 'chat/completions'] as const) {
    for (const stream of [false, true]) {
      it.each(workerCauseCases)(`${endpoint} stream=${stream}: $name`, async (scenario) => {
        vi.useFakeTimers();
        try {
          const disabled = 'disabled' in scenario;
          const terminal = scenario.kind === 'context_overflow';
          const fixture = createWorkerInferenceRouteFixture(
            true,
            undefined,
            true,
            scenario.kind !== undefined,
            false,
            { autoFailover: !disabled }
          );
          const failure = Object.assign(new Error('private upstream marker=worker-secret'), {
            failure: { kind: scenario.kind, status: scenario.status, settled: true },
          });
          const method =
            endpoint === 'responses'
              ? stream
                ? 'createResponsesStream'
                : 'createResponses'
              : stream
                ? 'createChatCompletionStream'
                : 'createChatCompletion';
          const dispatch = vi.spyOn(fixture.dispatcher, method).mockRejectedValue(failure);
          const pending = fixture.app.request(`/api/worker-inference/v1/${endpoint}`, {
            method: 'POST',
            headers: {
              authorization: `Bearer ${fixture.token}`,
              'content-type': 'application/json',
            },
            body: JSON.stringify({
              model: WORKER_LOGICAL_MODEL_ID,
              stream,
              ...(endpoint === 'responses'
                ? { input: 'Hello' }
                : { messages: [{ role: 'user', content: 'Hello' }] }),
            }),
          });
          await vi.runAllTimersAsync();
          const response = await pending;
          expect(response.status).toBe(disabled || terminal ? scenario.status : 503);
          expect(response.headers.get('content-type')).toContain('application/json');
          expect(await response.json()).toEqual({
            error:
              disabled || terminal
                ? {
                    type: 'provider_error',
                    code: terminal
                      ? 'gateway_context_overflow'
                      : scenario.kind === 'rate_limited'
                        ? 'gateway_provider_rate_limited'
                        : 'gateway_provider_authentication_failed',
                    message: terminal
                      ? 'Provider context limit exceeded.'
                      : scenario.kind === 'rate_limited'
                        ? 'Provider rate limit exceeded.'
                        : 'Provider authentication failed.',
                  }
                : {
                    code: 'gateway_logical_model_unavailable',
                    type: 'provider_error',
                    message: 'Logical model is temporarily unavailable.',
                    ...(scenario.kind !== undefined ? { cause: scenario.kind } : {}),
                  },
          });
          expect(dispatch).toHaveBeenCalledTimes(scenario.attempts);
        } finally {
          vi.useRealTimers();
        }
      });
    }
  }
});

describe('slice 1d Worker durable selection', () => {
  it('A2 retains one failed logical call with exclusions and no dispatch observations or usage', async () => {
    const f = createWorkerInferenceRouteFixture(true, undefined, true, false, false, {
      persistedTurn: true,
    });
    const response = await postWorkerResponses(f, {
      input: 'Hello',
      model: WORKER_LOGICAL_MODEL_ID,
    });
    expect(response.status).toBe(503);
    expect(await response.json()).toMatchObject({
      error: { code: 'gateway_logical_model_unavailable' },
    });
    const db = openWorkspaceDb(f.coreDb!.dataRoot, f.environmentPackage.scope.workspaceId);
    try {
      const calls = listWorkspaceCapabilityCalls(db, f.environmentPackage.scope.workspaceId);
      expect(calls).toHaveLength(1);
      expect(calls[0]).toMatchObject({
        status: 'failed',
        errorCode: 'gateway_logical_model_unavailable',
        providerRef: null,
        extensions: {
          'openkit.gateway/routeLineage': {
            entries: [
              {
                kind: 'unavailable',
                routeMemberId: 'primary',
                failureKind: 'provider_unavailable',
              },
            ],
          },
        },
      });
      expect(listWorkspaceUsageRecords(db, f.environmentPackage.scope.workspaceId)).toEqual([]);
      expect(f.dispatcher.responseCalls).toEqual([]);
      expect(
        readWorkObservations(db, {
          threadId: f.environmentPackage.scope.threadId,
          turnId: f.environmentPackage.scope.turnId,
        }).filter((row) => row.type === 'model.observed')
      ).toEqual([]);
    } finally {
      db.sqlite.close();
    }
  });
  it('A2 subscription check failure records one unavailable entry, no attempt and the closed public cause', async () => {
    vi.useFakeTimers();
    const f = createWorkerInferenceRouteFixture(true, undefined, true, true, false, {
      subscriptionFamily: 'openai-codex',
      subscriptionCheckUnavailable: true,
      persistedTurn: true,
    });
    try {
      const pending = postWorkerResponses(f, { input: 'Hello', model: WORKER_LOGICAL_MODEL_ID });
      await vi.runAllTimersAsync();
      const response = await pending;
      expect(response.status).toBe(503);
      expect(await response.json()).toMatchObject({
        error: { code: 'gateway_logical_model_unavailable', cause: 'provider_unavailable' },
      });
      const db = openWorkspaceDb(f.coreDb!.dataRoot, f.environmentPackage.scope.workspaceId);
      try {
        const calls = listWorkspaceCapabilityCalls(db, f.environmentPackage.scope.workspaceId);
        expect(calls).toHaveLength(1);
        expect(calls[0]).toMatchObject({
          status: 'failed',
          errorCode: 'gateway_logical_model_unavailable',
          extensions: {
            'openkit.gateway/routeLineage': {
              entries: [{ kind: 'unavailable', failureKind: 'provider_unavailable' }],
            },
          },
        });
        expect(calls[0]?.extensions?.['openkit.gateway/routeLineage']?.entries).toHaveLength(1);
        expect(JSON.stringify(calls)).not.toContain('accountSlotId');
        expect(JSON.stringify(calls)).not.toContain('private-account-slot');
        expect(listWorkspaceUsageRecords(db, f.environmentPackage.scope.workspaceId)).toEqual([]);
        expect(
          readWorkObservations(db, {
            threadId: f.environmentPackage.scope.threadId,
            turnId: f.environmentPackage.scope.turnId,
          }).filter((row) => row.type === 'model.observed')
        ).toEqual([]);
        expect(f.dispatcher.responseCalls).toEqual([]);
      } finally {
        db.sqlite.close();
      }
    } finally {
      vi.useRealTimers();
    }
  });
  for (const endpoint of ['responses', 'chat/completions'])
    for (const stream of [false, true]) {
      it(`${endpoint} stream=${stream} transport carries the absolute deadline`, async () => {
        const f = createWorkerInferenceRouteFixture();
        const before = Date.now();
        const response = await f.app.request(`/api/worker-inference/v1/${endpoint}`, {
          method: 'POST',
          headers: { authorization: `Bearer ${f.token}`, 'content-type': 'application/json' },
          body: JSON.stringify({
            model: WORKER_LOGICAL_MODEL_ID,
            stream,
            ...(endpoint === 'responses'
              ? { input: 'Hello' }
              : { messages: [{ role: 'user', content: 'Hello' }] }),
          }),
        });
        expect(response.status).toBe(200);
        await response.text();
        const call = [...f.dispatcher.responseCalls, ...f.dispatcher.chatCalls][0];
        expect(call?.context.transport?.deadline).toBeGreaterThanOrEqual(before + 120000);
        expect(call?.context.transport?.deadline).toBeLessThanOrEqual(Date.now() + 120000);
      });
    }
});

describe('slice 1d round 2 terminal frame closeout', () => {
  for (const failed of [true, false])
    it(`Worker released ${failed ? 'failed' : 'incomplete'} frame keeps its logical outcome`, async () => {
      const f = createWorkerInferenceRouteFixture();
      const frames = [
        { type: 'response.output_text.delta', delta: 'released' },
        {
          type: failed ? 'response.failed' : 'response.incomplete',
          response: {
            status: failed ? 'failed' : 'incomplete',
            ...(failed ? { error: { code: 'gateway_provider_unavailable' } } : {}),
          },
        },
      ];
      let index = 0;
      const dispatch = vi
        .spyOn(f.dispatcher, 'createResponsesStream')
        .mockImplementation(async (_provider, _request, context) => {
          f.dispatcher.observeSource(context, 'released');
          return new ReadableStream({
            pull(controller) {
              if (index < frames.length)
                controller.enqueue(
                  new TextEncoder().encode(`data: ${JSON.stringify(frames[index++])}\n\n`)
                );
              else controller.close();
            },
          });
        });
      const response = await postWorkerResponses(f, {
        input: 'Hello',
        model: WORKER_LOGICAL_MODEL_ID,
        stream: true,
      });
      expect(response.status).toBe(200);
      expect(await response.text()).toContain(failed ? 'response.failed' : 'response.incomplete');
      const db = openWorkspaceDb(f.coreDb!.dataRoot, f.environmentPackage.scope.workspaceId);
      try {
        expect(
          listWorkspaceCapabilityCalls(db, f.environmentPackage.scope.workspaceId)[0]
        ).toMatchObject({
          status: failed ? 'failed' : 'succeeded',
          errorCode: failed ? 'gateway_provider_unavailable' : null,
        });
        expect(dispatch).toHaveBeenCalledTimes(1);
      } finally {
        db.sqlite.close();
      }
    });
});

describe('slice 3c Worker native effort and immutable package', () => {
  it.each([
    'responses',
    'chat/completions',
  ] as const)('refuses unknown %s effort without an effect', async (endpoint) => {
    const f = createWorkerInferenceRouteFixture();
    for (const effort of ['turbo', null, 4, {}]) {
      const response = await f.app.request(`/api/worker-inference/v1/${endpoint}`, {
        method: 'POST',
        headers: { authorization: `Bearer ${f.token}`, 'content-type': 'application/json' },
        body: JSON.stringify({
          model: WORKER_LOGICAL_MODEL_ID,
          ...(endpoint === 'responses'
            ? { input: 'hello', reasoning: { effort } }
            : { messages: [{ role: 'user', content: 'hello' }], reasoning_effort: effort }),
        }),
      });
      expect(response.status).toBe(400);
    }
    expect(f.dispatcher.responseCalls).toHaveLength(0);
    expect(f.dispatcher.chatCalls).toHaveLength(0);
    expect(readWorkerInferenceCapabilityCalls(f)).toEqual([]);
  });

  it.each([
    ['high', 'low', 'low'],
    ['high', undefined, 'high'],
    [undefined, 'low', 'low'],
    [undefined, undefined, undefined],
  ] as const)('request %s/%s uses %s through stock Models', async (recorded, requested, expected) => {
    const received: unknown[] = [];
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockImplementation(async (_input, init) => {
      const body = JSON.parse(String(init?.body));
      received.push(body.reasoning?.effort ?? body.reasoning_effort);
      return new Response(
        'data: {"id":"chatcmpl_effort","model":"openai/gpt-5.2","choices":[{"index":0,"delta":{"content":"worker effort answer"},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
        { headers: { 'content-type': 'text/event-stream' } }
      );
    });
    const models = createModels();
    models.setProvider(openrouterProvider());
    const dispatcher = new LLMGatewayProviderDispatcher({
      piAiClient: new PiAiGatewayClient({ models }),
    });
    const f = createWorkerInferenceRouteFixture(true, undefined, true, true, false, {
      persistedTurn: true,
      dispatcher,
      ...(recorded ? { reasoningEffort: recorded } : {}),
    });
    const admittedPackage = structuredClone(f.environmentPackage);
    expect(admittedPackage.llm.reasoningEffort).toBe(recorded);
    const dispatched = vi.spyOn(dispatcher, 'createResponses');
    const response = await postWorkerResponses(f, {
      model: WORKER_LOGICAL_MODEL_ID,
      input: 'hello',
      ...(requested === undefined ? {} : { reasoning: { effort: requested } }),
    });
    expect(response.status, await response.text()).toBe(200);
    const request = dispatched.mock.calls[0]?.[1];
    if (expected === undefined) expect(request).not.toHaveProperty('reasoning');
    else expect(request).toMatchObject({ reasoning: { effort: expected } });
    // Stock Completions maps an omitted Core effort through this model's disabled-thinking value.
    expect(received).toEqual([expected ?? 'none']);
    expect(f.environmentPackage).toEqual(admittedPackage);
    const db = openWorkspaceDb(f.coreDb!.dataRoot, 'ws_00000000-0000-7000-8000-000000000001');
    applyScopedMigrations(db);
    try {
      const entries = listWorkspaceCapabilityCalls(db, 'ws_00000000-0000-7000-8000-000000000001')[0]
        ?.extensions?.['openkit.gateway/routeLineage']?.entries;
      expect(entries).toHaveLength(1);
      if (requested === undefined) expect(entries?.[0]).not.toHaveProperty('requestedEffort');
      else expect(entries?.[0]).toHaveProperty('requestedEffort', requested);
      if (expected === undefined)
        expect(entries?.[0]).toHaveProperty('effectiveEffortReason', 'provider_default_no_effort');
      else expect(entries?.[0]).toHaveProperty('effectiveEffort', expected);
    } finally {
      fetchSpy.mockRestore();
      db.sqlite.close();
    }
  });
});

it('Worker inference skips missing API-key supply without a Provider callback', async () => {
  const fixture = createWorkerInferenceRouteFixture(true, undefined, true, true, false, {
    missingApiKey: true,
  });
  const response = await postWorkerResponses(fixture, {
    model: WORKER_LOGICAL_MODEL_ID,
    input: 'Hello',
  });
  expect(response.status).toBe(503);
  const body = await response.json();
  expect(body).toMatchObject({ error: { code: 'gateway_logical_model_unavailable' } });
  expect(body.error).not.toHaveProperty('cause');
  expect(fixture.dispatcher.responseCalls).toEqual([]);
});

describe('Worker Turn admitted limits', () => {
  for (const endpoint of ['responses', 'chat/completions'] as const) {
    it.each([
      'new smaller primary',
      'all members shrunk',
      'absent modelParameters',
    ] as const)(`${endpoint}: %s`, async (scenario) => {
      const originalProfiles = [
        { id: 'original-primary', context: 240_000, output: 16_000 },
        { id: 'original-backup', context: 200_000, output: 8_000 },
      ].map(({ id, context, output }) => ({
        id,
        displayName: id,
        kind: 'gateway' as const,
        vendor: 'openrouter' as const,
        secretRef: 'test:worker-api-key',
        models: [WORKER_PROVIDER_MODEL],
        modelMetadata: {
          [WORKER_PROVIDER_MODEL]: {
            limit: { context, output },
            modalities: { input: ['text'], output: ['text'] },
          },
        },
      }));
      const admittedConfig: GatewayConfig = {
        schemaVersion: 1,
        enabled: true,
        defaultLogicalModelId: WORKER_LOGICAL_MODEL_ID,
        requiredFeatures: [],
        logicalModels: [
          {
            id: WORKER_LOGICAL_MODEL_ID,
            displayName: 'Worker reasoning',
            routing: { autoFailover: true },
            contextManagement: [{ type: 'compaction', compactThreshold: 8_000 }],
            routes: originalProfiles.map((profile) => ({
              id: profile.id,
              providerProfileId: profile.id,
              providerModel: WORKER_PROVIDER_MODEL,
            })),
          },
        ],
      };
      const admittedModel = resolveLogicalModel(
        admittedConfig,
        new ProviderRegistry(originalProfiles),
        WORKER_LOGICAL_MODEL_ID
      )!;
      expect(admittedModel.modelParameters).toMatchObject({
        contextWindow: 200_000,
        maxOutputTokens: 8_000,
      });
      const { modelParameters: _admittedParameters, ...modelWithoutParameters } = admittedModel;
      const currentProfiles =
        scenario === 'all members shrunk'
          ? originalProfiles.map((profile) => ({
              ...profile,
              modelMetadata: {
                [WORKER_PROVIDER_MODEL]: {
                  ...profile.modelMetadata[WORKER_PROVIDER_MODEL],
                  limit: { context: 20_000, output: 1_000 },
                },
              },
            }))
          : [
              {
                ...originalProfiles[0]!,
                id: 'new-smaller-primary',
                displayName: 'New smaller primary',
                modelMetadata: {
                  [WORKER_PROVIDER_MODEL]: {
                    ...originalProfiles[0]!.modelMetadata[WORKER_PROVIDER_MODEL],
                    limit: { context: 20_000, output: 1_000 },
                  },
                },
              },
              ...originalProfiles,
            ];
      const currentConfig = structuredClone(admittedConfig);
      currentConfig.logicalModels[0]!.routes = currentProfiles.map((profile) => ({
        id: profile.id,
        providerProfileId: profile.id,
        providerModel: WORKER_PROVIDER_MODEL,
      }));
      const f = createWorkerInferenceRouteFixture(true, undefined, true, true, false, {
        persistedTurn: true,
        admittedLogicalModel:
          scenario === 'absent modelParameters' ? modelWithoutParameters : admittedModel,
        gatewayConfig: currentConfig,
        providerRegistry: new ProviderRegistry(currentProfiles),
      });
      const admittedPackage = structuredClone(f.environmentPackage);
      if (scenario === 'absent modelParameters') {
        expect(f.environmentPackage.llm.routes[0]).not.toHaveProperty('modelParameters');
      } else {
        expect(f.environmentPackage.llm.routes[0]?.modelParameters).toMatchObject({
          contextWindow: 200_000,
          maxOutputTokens: 8_000,
        });
      }
      const response = await f.app.request(`/api/worker-inference/v1/${endpoint}`, {
        method: 'POST',
        headers: { authorization: `Bearer ${f.token}`, 'content-type': 'application/json' },
        body: JSON.stringify({
          model: WORKER_LOGICAL_MODEL_ID,
          ...(endpoint === 'responses'
            ? { input: 'Hello' }
            : { messages: [{ role: 'user', content: 'Hello' }] }),
        }),
      });
      const failed = scenario === 'all members shrunk';
      expect(response.status).toBe(failed ? 503 : 200);
      if (failed) {
        const body = await response.json();
        expect(body).toMatchObject({ error: { code: 'gateway_logical_model_unavailable' } });
        expect(body.error).not.toHaveProperty('cause');
      } else {
        await response.json();
      }
      const providerCalls = [...f.dispatcher.responseCalls, ...f.dispatcher.chatCalls];
      expect(providerCalls.map((call) => call.provider.id)).toEqual(
        failed
          ? []
          : [scenario === 'absent modelParameters' ? 'new-smaller-primary' : 'original-primary']
      );
      const db = openWorkspaceDb(f.coreDb!.dataRoot, f.environmentPackage.scope.workspaceId);
      try {
        const calls = listWorkspaceCapabilityCalls(db, f.environmentPackage.scope.workspaceId);
        expect(calls).toHaveLength(1);
        expect(calls[0]).toMatchObject({
          status: failed ? 'failed' : 'succeeded',
          errorCode: failed ? 'gateway_logical_model_unavailable' : null,
          providerRef: null,
          turnId: f.environmentPackage.scope.turnId,
          agentSessionId: f.environmentPackage.scope.agentSessionId,
          packageSnapshotId: f.environmentPackage.snapshotId,
        });
        const entries = calls[0]?.extensions?.['openkit.gateway/routeLineage']?.entries;
        const excluded = (routeMemberId: string) => ({
          kind: 'unavailable',
          routeMemberId,
          selectionReason: 'pinned_capability_unavailable',
          unavailableReason: 'pinned_capability_unavailable',
          failureKind: 'unsupported',
        });
        expect(entries).toMatchObject(
          failed
            ? originalProfiles.map((profile) => excluded(profile.id))
            : scenario === 'absent modelParameters'
              ? [{ kind: 'attempt', routeMemberId: 'new-smaller-primary' }]
              : [
                  excluded('new-smaller-primary'),
                  { kind: 'attempt', routeMemberId: 'original-primary' },
                ]
        );
        expect(entries).toHaveLength(failed ? 2 : scenario === 'absent modelParameters' ? 1 : 2);
        if (failed) {
          expect(listWorkspaceUsageRecords(db, f.environmentPackage.scope.workspaceId)).toEqual([]);
          expect(
            readWorkObservations(db, {
              threadId: f.environmentPackage.scope.threadId,
              turnId: f.environmentPackage.scope.turnId,
            }).filter((row) => row.type === 'model.observed')
          ).toEqual([]);
        }
      } finally {
        db.sqlite.close();
      }
      expect(f.environmentPackage).toEqual(admittedPackage);
    });
  }
});
