import {
  chmodSync,
  existsSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  statSync,
  writeFileSync,
} from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { createRuntimeConfigManager } from './config/runtime-config.js';
import { openCoreDb, openWorkspaceDb } from './storage/db.js';
import { applyMigrations, applyScopedMigrations } from './storage/migrate.js';
import { createApp as createTestApp } from './test-support/app.js';
import { createDemoStore } from './test-support/demo-store.js';
import { ensureLocalUser } from './test-support/local-user.js';
import { operationRequest } from './test-support/operation-request.js';
import { recordWorkspaceOwnerMembership } from './workspace-membership.js';

/**
 * Creates a temporary NanoCore data root for config file API tests.
 *
 * @returns Temporary data root path.
 */
function createDataRoot(): string {
  return mkdtempSync(join(tmpdir(), 'openkit-config-files-'));
}

/** Creates a simulated app whose runtime config owner reads the real test data root. */
function createApp(options: Parameters<typeof createTestApp>[0]): ReturnType<typeof createTestApp> {
  const dataRoot = options.dataRoot;
  if (!dataRoot) {
    throw new Error('Runtime config file tests require a data root.');
  }
  return createTestApp({
    ...options,
    runtimeConfigManager: createRuntimeConfigManager({ dataRoot }),
  });
}

/**
 * Writes a minimal valid server config to one data root.
 *
 * @param dataRoot Data root to prepare.
 */
function writeServerConfig(dataRoot: string): void {
  mkdirSync(join(dataRoot, 'config'), { recursive: true });
  writeFileSync(
    join(dataRoot, 'config', 'server.jsonc'),
    `{
      // comments must survive editor round-trips
      "schemaVersion": 1,
      "defaults": {
        "defaultAgentId": "agent_codex"
      }
    }\n`
  );
  mkdirSync(join(dataRoot, 'config', 'providers'), { recursive: true });
  writeFileSync(
    join(dataRoot, 'config', 'providers', 'agent-openrouter.provider.jsonc'),
    `${JSON.stringify(
      {
        id: 'agent-openrouter',
        vendor: 'openrouter',
        displayName: 'Agent OpenRouter',
        kind: 'custom',
        baseUrl: 'https://openrouter.ai/api/v1',
        models: ['openai/gpt-5.1'],
        secretRef: 'vault://vault_00000000-0000-794f-be5b-43dd897fef0c',
      },
      null,
      2
    )}\n`
  );
  writeFileSync(
    join(dataRoot, 'config', 'gateway.jsonc'),
    `${JSON.stringify(
      {
        schemaVersion: 1,
        enabled: true,
        defaultLogicalModelId: 'openai/gpt-5.2',
        logicalModels: [
          {
            id: 'openai/gpt-5.2',
            displayName: 'OpenAI GPT-5.2',
            contextManagement: [{ type: 'compaction', compactThreshold: 200_000 }],
            routes: [
              {
                id: 'primary',
                providerProfileId: 'agent-openrouter',
                providerModel: 'openai/gpt-5.1',
              },
            ],
          },
        ],
        requiredFeatures: [],
      },
      null,
      2
    )}\n`
  );
}

describe('runtime config file API', () => {
  it('lists and reads allowed runtime config files with stable revisions', async () => {
    const dataRoot = createDataRoot();
    writeServerConfig(dataRoot);
    const app = createApp({ dataRoot, store: createDemoStore({ dataRoot }) });

    const listRes = await app.request(...operationRequest('runtime.file-list', {}));
    const list = (await listRes.json()) as {
      files: Array<{ id: string; kind: string; revision: string | null }>;
    };

    expect(listRes.status).toBe(200);
    expect(list.files).toContainEqual(
      expect.objectContaining({
        id: 'server.jsonc',
        kind: 'server',
        revision: expect.stringMatching(/^sha256:/),
      })
    );

    const readRes = await app.request(
      ...operationRequest('runtime.file-read', { id: 'server.jsonc' })
    );
    const read = (await readRes.json()) as { content: string; file: { id: string } };

    expect(read.file.id).toBe('server.jsonc');
    expect(read.content).toContain('comments must survive');
  });

  it('lists, reads, and updates workspace config files under the current user workspace', async () => {
    const dataRoot = createDataRoot();
    writeServerConfig(dataRoot);
    const store = createDemoStore({ dataRoot });
    mkdirSync(join(dataRoot, 'workspaces', 'ws_00000000-0000-7000-8000-000000000001', 'config'), {
      recursive: true,
    });
    writeFileSync(
      join(
        dataRoot,
        'workspaces',
        'ws_00000000-0000-7000-8000-000000000001',
        'config',
        'workspace.jsonc'
      ),
      `{
        "schemaVersion": 1,
        "workspace": {
          "name": "Demo Workspace",
          "roots": []
        }
      }\n`
    );
    const app = createApp({ dataRoot, store });

    const listRes = await app.request(...operationRequest('runtime.file-list', {}));
    const list = (await listRes.json()) as {
      files: Array<{ id: string; kind: string; revision: string | null }>;
    };
    const fileId = 'workspaces/ws_00000000-0000-7000-8000-000000000001/workspace.jsonc';
    const readRes = await app.request(...operationRequest('runtime.file-read', { id: fileId }));
    const read = (await readRes.json()) as { file: { revision: string }; content: string };
    const updateRes = await app.request(
      ...operationRequest(
        'runtime.file-update',
        {},
        {
          method: 'PUT',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            id: fileId,
            kind: 'workspace',
            content: read.content.replace('"roots": []', '"roots": [] // saved'),
            expectedRevision: read.file.revision,
          }),
        }
      )
    );

    expect(list.files).toContainEqual(expect.objectContaining({ id: fileId, kind: 'workspace' }));
    expect(readRes.status).toBe(200);
    expect(updateRes.status).toBe(200);
  });

  it('lists, reads, validates, and updates workspace data source catalog files', async () => {
    const dataRoot = createDataRoot();
    writeServerConfig(dataRoot);
    const store = createDemoStore({ dataRoot });
    const configRoot = join(
      dataRoot,
      'workspaces',
      'ws_00000000-0000-7000-8000-000000000001',
      'config'
    );
    mkdirSync(configRoot, { recursive: true });
    writeFileSync(
      join(configRoot, 'data-sources.jsonc'),
      `{
        "schemaVersion": 1,
        "sources": []
      }\n`
    );
    const app = createApp({ dataRoot, store });

    const fileId = 'workspaces/ws_00000000-0000-7000-8000-000000000001/data-sources.jsonc';
    const listRes = await app.request(...operationRequest('runtime.file-list', {}));
    const list = (await listRes.json()) as { files: Array<{ id: string; kind: string }> };
    const readRes = await app.request(...operationRequest('runtime.file-read', { id: fileId }));
    expect(readRes.status).toBe(200);
    const read = (await readRes.json()) as { file: { revision: string }; content: string };
    const validateRes = await app.request(
      ...operationRequest(
        'runtime.validate',
        {},
        {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            files: [{ id: fileId, content: read.content }],
          }),
        }
      )
    );
    const updateRes = await app.request(
      ...operationRequest(
        'runtime.file-update',
        {},
        {
          method: 'PUT',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            id: fileId,
            kind: 'data-source',
            content: read.content.replace('"sources": []', '"sources": [] // saved'),
            expectedRevision: read.file.revision,
          }),
        }
      )
    );
    const schemasRes = await app.request(...operationRequest('runtime.schemas', {}));
    const schemas = (await schemasRes.json()) as { schemas: Array<{ kind: string }> };

    expect(list.files).toContainEqual(expect.objectContaining({ id: fileId, kind: 'data-source' }));
    expect(readRes.status).toBe(200);
    expect(validateRes.status).toBe(200);
    await expect(validateRes.json()).resolves.toMatchObject({ valid: true });
    expect(updateRes.status).toBe(200);
    expect(schemas.schemas).toContainEqual(expect.objectContaining({ kind: 'data-source' }));
  });

  it('audits authority-bearing workspace data source catalog edits', async () => {
    const dataRoot = createDataRoot();
    const coreDb = openCoreDb(dataRoot);
    applyMigrations(coreDb);
    writeServerConfig(dataRoot);
    const store = createDemoStore({ dataRoot });
    const configRoot = join(
      dataRoot,
      'workspaces',
      'ws_00000000-0000-7000-8000-000000000001',
      'config'
    );
    mkdirSync(configRoot, { recursive: true });
    writeFileSync(
      join(configRoot, 'data-sources.jsonc'),
      `{
        "schemaVersion": 1,
        "sources": [
          {
            "id": "repo_default",
            "kind": "git",
            "displayName": "Default repository",
            "locator": { "repositoryResourceId": "repo_default" },
            "access": "read-only",
            "sensitivity": "internal",
            "allowedSlotKinds": ["worktree"],
            "status": "active"
          }
        ]
      }\n`
    );

    try {
      const app = createApp({ coreDb, dataRoot, store });
      const fileId = 'workspaces/ws_00000000-0000-7000-8000-000000000001/data-sources.jsonc';
      const readRes = await app.request(...operationRequest('runtime.file-read', { id: fileId }));
      const read = (await readRes.json()) as { file: { revision: string }; content: string };
      const updateRes = await app.request(
        ...operationRequest(
          'runtime.file-update',
          {},
          {
            method: 'PUT',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({
              id: fileId,
              kind: 'data-source',
              content: read.content.replace('"access": "read-only"', '"access": "read-write"'),
              expectedRevision: read.file.revision,
            }),
          }
        )
      );
      const workspaceDb = openWorkspaceDb(dataRoot, 'ws_00000000-0000-7000-8000-000000000001');
      applyScopedMigrations(workspaceDb);

      try {
        const row = workspaceDb.sqlite
          .prepare(
            "SELECT * FROM audit_events WHERE action = 'data_source_catalog.authority.update'"
          )
          .get() as Record<string, unknown> | undefined;

        expect(updateRes.status).toBe(200);
        expect(row).toMatchObject({
          workspace_id: 'ws_00000000-0000-7000-8000-000000000001',
          category: 'system',
          resource: 'data-source-catalog:repo_default',
          outcome: 'succeeded',
          severity: 'info',
          summary: 'Workspace data source catalog authority changed for repo_default: access.',
        });
      } finally {
        workspaceDb.sqlite.close();
      }
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('creates Workspace MCP configurations through the catalog App API instead of runtime config files', async () => {
    const dataRoot = createDataRoot();
    const coreDb = openCoreDb(dataRoot);
    applyMigrations(coreDb);
    ensureLocalUser(coreDb);
    writeServerConfig(dataRoot);
    const store = createDemoStore({ dataRoot });
    recordWorkspaceOwnerMembership({
      coreDb,
      ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
    });

    try {
      const app = createApp({ coreDb, dataRoot, store });
      const created = await app.request(
        ...operationRequest(
          'catalog.mcp-create',
          {},
          {
            method: 'POST',
            headers: {
              ...{ 'content-type': 'application/json' },
              'content-type': 'application/json',
            },
            body: JSON.stringify({
              workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
              ...{
                allowedTools: ['echo'],
                declaration: { args: [], command: 'node', kind: 'stdio' },
                displayName: 'Echo',
                expectedRevision: 0,
                id: 'echo',
                requestId: '00000000-0000-4000-8000-000000000101',
              },
            }),
          }
        )
      );
      const listed = await app.request(
        ...operationRequest(
          'catalog.mcp-list',
          {},
          {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ workspaceId: 'ws_00000000-0000-7000-8000-000000000001' }),
          }
        )
      );
      const files = await app.request(...operationRequest('runtime.file-list', {}));
      const fileList = (await files.json()) as { files: Array<{ id: string; kind: string }> };

      expect(created.status).toBe(201);
      expect(listed.status).toBe(200);
      expect((await listed.json()) as { items: Array<{ id: string }> }).toMatchObject({
        items: [expect.objectContaining({ id: 'echo', enabled: false })],
      });
      expect(fileList.files.some((file) => file.id.includes('mcp-servers.jsonc'))).toBe(false);
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('creates provider and agent config files from server templates', async () => {
    const dataRoot = createDataRoot();
    writeServerConfig(dataRoot);
    const app = createApp({ dataRoot });

    const providerRes = await app.request(
      ...operationRequest(
        'runtime.file-create',
        {},
        {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            id: 'providers/new-openrouter.provider.jsonc',
            kind: 'provider',
          }),
        }
      )
    );
    const agentRes = await app.request(
      ...operationRequest(
        'runtime.file-create',
        {},
        {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            id: 'agents/new-agent.agent.jsonc',
            kind: 'agent',
          }),
        }
      )
    );

    expect(providerRes.status).toBe(200);
    expect(agentRes.status).toBe(200);
    const providerTemplate = JSON.parse(
      readFileSync(join(dataRoot, 'config', 'providers', 'new-openrouter.provider.jsonc'), 'utf8')
    );
    expect(providerTemplate.secretRef).toMatch(
      /^vault:\/\/vault_[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/
    );
    const agentTemplate = readFileSync(
      join(dataRoot, 'config', 'agents', 'new-agent.agent.jsonc'),
      'utf8'
    );
    expect(agentTemplate).toContain('"id": "new-agent"');
    expect(JSON.parse(agentTemplate).models).toEqual({
      preferredLogicalModelId: 'smart',
      allowedLogicalModelIds: 'all',
    });
    expect(agentTemplate).toContain('"kind": "reference"');
    expect(JSON.parse(agentTemplate).runtime).toMatchObject({
      adapter: 'codex',
      version: '0.160.0',
      image: { kind: 'reference', ref: 'openkit/worker-runtimes:dev' },
    });
    expect(agentTemplate).toContain('"path": "/opt/openkit/venv/bin/python"');
    expect(agentTemplate).toContain('"path": "/opt/openkit/venv/bin/pip"');
    expect(agentTemplate).not.toContain('/sandbox/.venv');
  });

  it('updates config files with revision guards and rejects stale writes', async () => {
    const dataRoot = createDataRoot();
    writeServerConfig(dataRoot);
    const serverPath = join(dataRoot, 'config', 'server.jsonc');
    const previousUmask = process.umask(0o022);
    try {
      chmodSync(serverPath, 0o600);
      expect(statSync(serverPath).mode & 0o777).toBe(0o600);
      const app = createApp({ dataRoot });
      const readRes = await app.request(
        ...operationRequest('runtime.file-read', { id: 'server.jsonc' })
      );
      const read = (await readRes.json()) as { file: { revision: string }; content: string };
      const nextContent = read.content.replace('agent_codex', 'agent_pi');

      const okRes = await app.request(
        ...operationRequest(
          'runtime.file-update',
          {},
          {
            method: 'PUT',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({
              id: 'server.jsonc',
              kind: 'server',
              content: nextContent,
              expectedRevision: read.file.revision,
            }),
          }
        )
      );
      const staleRes = await app.request(
        ...operationRequest(
          'runtime.file-update',
          {},
          {
            method: 'PUT',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({
              id: 'server.jsonc',
              kind: 'server',
              content: read.content,
              expectedRevision: read.file.revision,
            }),
          }
        )
      );

      expect(okRes.status).toBe(200);
      expect(readFileSync(serverPath, 'utf8')).toBe(nextContent);
      expect(statSync(serverPath).mode & 0o777).toBe(0o600);
      expect(staleRes.status).toBe(409);
    } finally {
      process.umask(previousUmask);
    }
  });

  it('rejects path traversal and invalid config writes', async () => {
    const dataRoot = createDataRoot();
    writeServerConfig(dataRoot);
    const app = createApp({ dataRoot });

    const traversalRes = await app.request(
      ...operationRequest('runtime.file-read', { id: '../server.jsonc' })
    );
    const invalidRes = await app.request(
      ...operationRequest(
        'runtime.file-update',
        {},
        {
          method: 'PUT',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            id: 'server.jsonc',
            kind: 'server',
            content: '{',
            expectedRevision: 'sha256:not-current',
          }),
        }
      )
    );

    expect(traversalRes.status).toBe(400);
    expect(invalidRes.status).toBe(400);
  });

  it('validates draft overlays without mutating disk and returns reload plans', async () => {
    const dataRoot = createDataRoot();
    writeServerConfig(dataRoot);
    const app = createApp({ dataRoot });
    const providerFileId = 'providers/agent-openrouter.provider.jsonc';
    const providerPath = join(dataRoot, 'config', providerFileId);
    const original = readFileSync(providerPath, 'utf8');

    const invalidRes = await app.request(
      ...operationRequest(
        'runtime.validate',
        {},
        {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            files: [{ id: 'server.jsonc', content: '{' }],
            mode: 'safe',
          }),
        }
      )
    );
    const changedRes = await app.request(
      ...operationRequest(
        'runtime.validate',
        {},
        {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            files: [
              {
                id: providerFileId,
                content: original.replace('openrouter.ai', 'openrouter.example.com'),
              },
            ],
            mode: 'safe',
          }),
        }
      )
    );
    const invalid = (await invalidRes.json()) as {
      valid: boolean;
      diagnostics: Array<{ range: { startLine: number } | null }>;
    };
    const changed = (await changedRes.json()) as {
      valid: boolean;
      plan: { applied: unknown[]; requiresRestart: Array<{ path: string }> };
    };

    expect(invalid.valid).toBe(false);
    expect(invalid.diagnostics[0]?.range?.startLine).toBe(1);
    expect(changed.valid).toBe(true);
    expect(changed.plan.applied).toEqual([]);
    expect(changed.plan.requiresRestart).toEqual([expect.objectContaining({ path: 'providers' })]);
    expect(readFileSync(providerPath, 'utf8')).toBe(original);
  });

  it('keeps admin config routes protected in server mode', async () => {
    const dataRoot = createDataRoot();
    writeServerConfig(dataRoot);
    const app = createApp({
      auth: {
        api: { getSession: async () => null },
        handler: async () => Response.json({ status: 'auth-ok' }),
      },
      dataRoot,
      mode: 'server',
    });
    const listRes = await app.request(...operationRequest('runtime.file-list', {}));

    expect(listRes.status).toBe(401);
  });

  it('does not reload unsaved validation overlays', async () => {
    const dataRoot = createDataRoot();
    writeServerConfig(dataRoot);
    const app = createApp({ dataRoot });
    const providerFileId = 'providers/agent-openrouter.provider.jsonc';
    const original = readFileSync(join(dataRoot, 'config', providerFileId), 'utf8');

    await app.request(
      ...operationRequest(
        'runtime.validate',
        {},
        {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            files: [
              {
                id: providerFileId,
                content: original.replace('openrouter.ai', 'openrouter.example.com'),
              },
            ],
          }),
        }
      )
    );
    const reloadRes = await app.request(
      ...operationRequest(
        'runtime.reload',
        {},
        {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ dryRun: true, mode: 'safe' }),
        }
      )
    );
    const reload = (await reloadRes.json()) as { plan: { applied: unknown[] } };

    expect(existsSync(join(dataRoot, 'config', 'server.jsonc'))).toBe(true);
    expect(reload.plan.applied).toEqual([]);
  });
});
