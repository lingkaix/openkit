import { createHash } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';
import {
  ArchivedGitPushRecordSchema,
  ArchivedWorkspaceRepositoryGitConfigSchema,
  ArtifactReviewViewSchema,
  BackendWorkspaceHandleReaderSchema,
  BackendWorkspaceHandleSchema,
  EvidenceBundleRecordSchema,
  GoalCardSchema,
  GoalPlanVersionSchema,
  GoalRecordSchema,
  GoalTaskLinkSchema,
  InjectionVisibilitySchema,
  KnowledgeClaimSchema,
  KnowledgeConflictSchema,
  KnowledgeObservationSchema,
  type KnowledgeRetrievalTrace,
  KnowledgeRetrievalTraceSchema,
  RuntimeEvidenceRecordSchema,
  StagedWorkspaceReviewReaderSchema,
  StagedWorkspaceReviewSchema,
  WorkerOutputManifestReaderSchema,
  WorkerOutputManifestSchema,
  WorkspaceApplyPlanSchema,
  WorkspaceApplyResultReaderSchema,
  WorkspaceApplyResultSchema,
  WorkspaceChangeSetReaderSchema,
  WorkspaceChangeSetSchema,
  WorkspaceInputSnapshotReaderSchema,
  WorkspaceInputSnapshotSchema,
  WorkspaceMaterializationRecordReaderSchema,
  WorkspaceMaterializationRecordSchema,
  WorkspaceMaterialRevisionViewSchema,
  WorkspaceMaterialViewSchema,
  WorkspaceQuarantineRecordSchema,
  WorkspaceReconciliationRecordReaderSchema,
  WorkspaceReconciliationRecordSchema,
  WorkspaceSyncReviewPatchPayloadSchema,
} from '@openkit/app-api-schemas';
import type {
  AgentEnvironmentPackage,
  PortableSkillPayload,
  ResourceCatalogDocument,
} from '@openkit/config-schema';
import {
  AgentEnvironmentPackageSchema,
  parseWorkspaceDataSourceCatalog,
  planSessionWorkspaceMaterialization,
  RetainedAgentEnvironmentPackageSchema,
  redactAgentEnvironmentPackageSnapshot,
  WorkspaceConfigSchema,
  type WorkspaceDataSourceCatalog,
  type WorkspaceExportManifest,
} from '@openkit/config-schema';
import {
  AgentSessionIdSchema,
  ArtifactIdSchema,
  ArtifactSchema,
  AuditEventIdSchema,
  AuditEventSchema,
  allocateEntityId,
  CapabilityCallIdSchema,
  CapabilityCallSchema,
  type EntityKind,
  ItemSchema,
  KnowledgeEntrySchema,
  MaterialIdSchema,
  PermissionDecisionIdSchema,
  parseReferenceScope,
  type RetrievalTraceReference,
  RetrievalTraceReferenceSchema,
  SseEventEnvelopeSchema,
  ThreadIdSchema,
  ThreadSchema,
  TurnIdSchema,
  TurnSchema,
  UsageRecordSchema,
  VaultGrantIdSchema,
  VaultReferenceIdSchema,
  WorkspaceIdSchema,
  WorkspaceRecordSchema,
} from '@openkit/protocol';
import { workerSessionInputPaths } from '@openkit/worker-protocol';
import { z } from 'zod';
import type { ResolvedAgentSetupRecord } from '../agents/setup-ledger.js';
import {
  ArtifactReviewFollowUpRequestSchema,
  deriveArtifactReviewFollowUpTurnId,
  deriveArtifactReviewId,
  deriveArtifactReviewWorkerRequestId,
  serializeArtifactReviewFollowUpRequest,
} from '../artifact-reviews.js';
import { CanonicalCapabilityCallExtensionsSchema } from '../capability/usage-ledger.js';
import {
  AGENT_RESOURCE_CATALOG_EXPORT_PATH,
  readPortableAgentResourceCatalog,
  readPortableSkillPayload,
  reconstructImportedWorkspaceCatalog,
} from '../catalog/catalog-portability.js';
import { parseJsoncObject } from '../config/jsonc.js';
import {
  buildWorkerContextPackageWorkspaceInput,
  canonicalJson,
  createWorkerContextPackageFiles,
  createWorkerContextPackagePolicyDigest,
  createWorkerContextPackageTrace,
  parseWorkerContextPackageTrace,
  serializeWorkerContextPackageTrace,
  verifyImportedWorkerContextPackageTrace,
  type WorkerContextPackageAuthorityReader,
  WorkerContextPackageManifestSchema,
  type WorkerContextPackageTrace,
} from '../context/worker-context-package.js';
import { workObservationBodyBundleId } from '../evidence-bundles.js';
import {
  StructuredWorkerDelegationRequestSchema,
  serializeStructuredWorkerDelegationRequest,
} from '../internal-agents/delegation.js';
import {
  parseOkfDocument,
  stringFrontmatterField,
  stringListFrontmatterField,
  updateOkfFrontmatter,
} from '../knowledge/okf.js';
import type { AgentSession, KnowledgeSourceRecord } from '../lib/store.js';
import type { AgentEnvironmentPackageSnapshotRecord } from '../runtime/aep-snapshot-ledger.js';
import { createWorkerRuntimeProvenanceEvidenceId } from '../runtime/runtime-evidence.js';
import { TaskTerminalFactSchema } from '../runtime/task-terminal-fact.js';
import {
  createWorkerRuntimeProvenanceBundleId,
  remintWorkerRuntimeProvenanceIndex,
  WorkerRuntimeOriginIndexRowSchema,
} from '../runtime/worker-runtime-provenance.js';
import { retrievalTraceRelativePath } from './retrieval-traces.js';
import { parseWorkObservationRecord, type WorkObservationReference } from './work-observations.js';
import { assertWorkspaceArchiveFilePath } from './workspace-archive.js';
import {
  dryRunWorkspaceImport,
  type ExportedKnowledgeSourceMaterial,
  parsePortableWorkObservations,
  UNSUPPORTED_WORKSPACE_EXPORT_RECORD_PATHS,
  type VerifiedWorkspaceExportTree,
  type WorkspaceImportDryRunReport,
} from './workspace-export.js';
import {
  AgentSessionRecordSchema,
  artifactContentFileName,
  artifactReferenceItemId,
  assertSafeWorkspacePathSegment,
  type CaptureCoverageBinding,
  CaptureCoverageBindingSchema,
  KnowledgeSourceRecordSchema,
  knowledgeEntriesEqual,
  listUnresolvedUserInputRequestItemIds,
  parseCanonicalWorkspaceHistory,
  parseOwnedKnowledgeEntry,
  WorkspaceSystemRecordSchema,
} from './workspace-file-records.js';
import {
  parseWorkspaceRetrievalTraceFile,
  serializeWorkspaceRetrievalTrace,
  type WorkspacePortableFileState,
} from './workspace-portable-file-state.js';

type WorkspaceRecord = import('zod').infer<typeof WorkspaceRecordSchema>;
type Thread = import('zod').infer<typeof ThreadSchema>;
type Turn = import('zod').infer<typeof TurnSchema>;
type KnowledgeEntry = import('zod').infer<typeof KnowledgeEntrySchema>;
type Item = import('zod').infer<typeof ItemSchema>;
type Artifact = import('zod').infer<typeof ArtifactSchema>;
type SseEventEnvelope = import('zod').infer<typeof SseEventEnvelopeSchema>;
type AuditEvent = import('zod').infer<typeof AuditEventSchema>;
type EvidenceBundleRecord = z.infer<typeof EvidenceBundleRecordSchema>;
type RuntimeEvidenceRecord = z.infer<typeof RuntimeEvidenceRecordSchema>;
type UsageRecord = import('zod').infer<typeof UsageRecordSchema>;
type WorkspaceInputSnapshot = z.infer<typeof WorkspaceInputSnapshotSchema>;
type WorkspaceMaterializationRecord = z.infer<typeof WorkspaceMaterializationRecordSchema>;
type BackendWorkspaceHandle = z.infer<typeof BackendWorkspaceHandleSchema>;
type WorkerOutputManifest = z.infer<typeof WorkerOutputManifestSchema>;
type WorkspaceChangeSet = z.infer<typeof WorkspaceChangeSetSchema>;
type WorkspaceApplyPlan = z.infer<typeof WorkspaceApplyPlanSchema>;
type WorkspaceQuarantineRecord = z.infer<typeof WorkspaceQuarantineRecordSchema>;
type WorkspaceReconciliationRecord = z.infer<typeof WorkspaceReconciliationRecordSchema>;

const ImportedWorkspaceMaterialSchema = WorkspaceMaterialViewSchema.extend({
  lastMutationRequestId: z.string().min(1),
}).strip();
const ImportedWorkspaceMaterialRevisionSchema = WorkspaceMaterialRevisionViewSchema.extend({
  createdByRequestId: z.string().min(1),
}).strip();
const ImportedThreadMaterialBindingSchema = z
  .object({
    workspaceId: WorkspaceIdSchema,
    threadId: ThreadIdSchema,
    materialId: MaterialIdSchema,
    bindingState: z.enum(['bound', 'unbound']),
    latestQueuedRevisionId: z.string().min(1).nullable(),
    inclusionState: z.enum(['included', 'excluded']),
    lastMutationRequestId: z.string().min(1),
    createdAt: z.string().datetime(),
    updatedAt: z.string().datetime(),
  })
  .strip();
const ImportedArtifactReviewSchema = ArtifactReviewViewSchema.safeExtend({
  materialProposal: ArtifactReviewViewSchema.shape.materialProposal.unwrap().strip().nullable(),
  decisionRequestId: z.string().min(1).nullable(),
}).strip();

/** Known-field portable Workspace Material owner accepted by import. */
type ImportedWorkspaceMaterial = z.infer<typeof ImportedWorkspaceMaterialSchema>;
/** Known-field portable immutable Material revision accepted by import. */
type ImportedWorkspaceMaterialRevision = z.infer<typeof ImportedWorkspaceMaterialRevisionSchema>;
/** Known-field portable Thread-to-Material binding accepted by import. */
type ImportedThreadMaterialBinding = z.infer<typeof ImportedThreadMaterialBindingSchema>;
/** Known-field portable version-keyed Artifact Review accepted by import. */
type ImportedArtifactReview = z.infer<typeof ImportedArtifactReviewSchema>;

const ImportedEvidenceBundleRecordSchema = EvidenceBundleRecordSchema.safeExtend({
  rawEvidenceRefs: z.array(EvidenceBundleRecordSchema.shape.rawEvidenceRefs.element.strip()),
  redactedEvidenceRefs: z.array(
    EvidenceBundleRecordSchema.shape.redactedEvidenceRefs.element.strip()
  ),
}).strip();
const ImportedRuntimeEvidenceRecordSchema = RuntimeEvidenceRecordSchema.safeExtend({
  uploadManifest: z.array(RuntimeEvidenceRecordSchema.shape.uploadManifest.element.strip()),
  downloadManifest: z.array(RuntimeEvidenceRecordSchema.shape.downloadManifest.element.strip()),
}).strip();
const ImportedUsageRecordSchema = UsageRecordSchema.strip();
const ImportedKnowledgeObservationSchema = KnowledgeObservationSchema.strip();
const ImportedKnowledgeClaimSchema = KnowledgeClaimSchema.strip();
const ImportedKnowledgeConflictSchema = KnowledgeConflictSchema.strip();
const ExportedResolvedAgentSetupSchema = z
  .object({
    id: z.string().min(1),
    workspaceId: WorkspaceIdSchema,
    turnId: TurnIdSchema.nullable(),
    requestId: z.string().min(1).nullable(),
    agentId: z.string().min(1),
    logicalModelId: z.string().min(1),
    runtimeKind: z.string().min(1),
    runtimeAdapter: z.string().min(1),
    setupRequiredFeatures: z.array(z.string().min(1)),
    setup: z.unknown(),
    createdAt: z.string().datetime(),
  })
  .strip();

type ExportedResolvedAgentSetup = Omit<ResolvedAgentSetupRecord, 'setup'> & {
  readonly requiredFeatures: ResolvedAgentSetupRecord['requiredFeatures'];
  readonly setup: ResolvedAgentSetupRecord['setup'];
};

const ExportedAgentEnvironmentPackageSnapshotSchema = z
  .object({
    snapshotId: z.string().min(1),
    workspaceId: WorkspaceIdSchema,
    turnId: TurnIdSchema,
    threadId: ThreadIdSchema,
    agentSessionId: AgentSessionIdSchema,
    agentId: z.string().min(1),
    packageId: z.string().min(1),
    runtimeKind: z.string().min(1),
    backendKind: z.string().min(1),
    contentDigest: z.string().min(1),
    snapshot: z.unknown(),
    createdAt: z.string().datetime(),
  })
  .strip();

type ExportedAgentEnvironmentPackageSnapshot = Omit<
  AgentEnvironmentPackageSnapshotRecord,
  'snapshot'
> & {
  readonly snapshot: AgentEnvironmentPackageSnapshotRecord['snapshot'];
};

const ExportedWorkspaceRepositoryResourceSchema = z
  .object({
    resourceId: z.string().min(1),
    type: z.literal('git_repository'),
    displayName: z.string().min(1),
    git: ArchivedWorkspaceRepositoryGitConfigSchema.strip(),
    createdAt: z.string().datetime(),
    updatedAt: z.string().datetime(),
  })
  .strip();

type ExportedWorkspaceRepositoryResource = z.infer<
  typeof ExportedWorkspaceRepositoryResourceSchema
>;

const ExportedCapabilityCallSchema = CapabilityCallSchema.safeExtend({
  extensions: CanonicalCapabilityCallExtensionsSchema.optional(),
  family: z.enum(['llm', 'mcp', 'knowledge', 'runtime', 'storage', 'workspace']),
  operation: z.string().min(1),
  providerRef: z.string().min(1).nullable(),
  serviceRef: z.string().min(1).nullable(),
  redactionClass: z.string().min(1),
}).strip();

type ExportedCapabilityCall = z.infer<typeof ExportedCapabilityCallSchema>;

const ExportedGitPushRecordSchema = ArchivedGitPushRecordSchema.extend({
  requestId: z.string().min(1),
}).strip();

type ExportedGitPushRecord = z.infer<typeof ExportedGitPushRecordSchema>;

const ExportedStagedWorkspaceReviewSchema = z
  .object({
    artifactId: ArtifactIdSchema,
    review: StagedWorkspaceReviewSchema,
    patchPayload: WorkspaceSyncReviewPatchPayloadSchema.nullable(),
  })
  .strip();

type ExportedStagedWorkspaceReview = z.infer<typeof ExportedStagedWorkspaceReviewSchema>;

/** Portable review source reader; target emission still uses the exact review core. */
const ExportedStagedWorkspaceReviewReaderSchema = ExportedStagedWorkspaceReviewSchema.safeExtend({
  review: StagedWorkspaceReviewReaderSchema,
});

const ExportedWorkspaceApplyResultSchema = WorkspaceApplyResultSchema.extend({
  requestId: z.string().min(1),
}).strip();

type ExportedWorkspaceApplyResult = z.infer<typeof ExportedWorkspaceApplyResultSchema>;

/** Portable apply-result observation with its required retained replay identity. */
const ExportedWorkspaceApplyResultReaderSchema = WorkspaceApplyResultReaderSchema.safeExtend({
  requestId: z.string().min(1),
}).strip();

const ExportedWorkspacePermissionDecisionSchema = z
  .object({
    action: z.string().min(1),
    approvalId: z.string().min(1).nullable(),
    auditEventId: AuditEventIdSchema.nullable(),
    contextSummary: z.unknown(),
    createdAt: z.string().datetime(),
    decisionId: PermissionDecisionIdSchema,
    enforcementPoint: z.string().min(1),
    ownerScope: z.literal('workspace'),
    policyEngineVersion: z.string().min(1),
    policySnapshotId: z.string().min(1),
    reasonCode: z.string().min(1),
    requiredApprovalKind: z.string().min(1).nullable(),
    resourceSummary: z.unknown(),
    result: z.enum([
      'allow',
      'deny',
      'require_approval',
      'require_escalation',
      'defer',
      'not_applicable',
      'error',
    ]),
    subjectSummary: z.unknown(),
    workspaceId: WorkspaceIdSchema,
  })
  .strict();

type ExportedWorkspacePermissionDecision = z.infer<
  typeof ExportedWorkspacePermissionDecisionSchema
>;

const ExportedStopReasonSchema = z.enum([
  'completed',
  'aborted',
  'error',
  'length',
  'budget_exhausted',
]);

const ExportedWorkerCheckpointSchema = z
  .object({
    checkpointId: z.string().min(1),
    workspaceId: WorkspaceIdSchema,
    threadId: ThreadIdSchema,
    turnId: TurnIdSchema,
    goalId: z.string().min(1).nullable(),
    taskId: z.string().min(1).nullable(),
    requestId: z.string().min(1),
    requestInputHash: z.string().min(1),
    stage: z.enum([
      'preparing',
      'running_worker',
      'waiting_for_user',
      'completed',
      'failed',
      'aborted',
    ]),
    iteration: z.number().int().nonnegative(),
    workerSessionId: z.string().min(1).nullable(),
    contextDigest: z.string().min(1).nullable(),
    stopReason: ExportedStopReasonSchema.nullable(),
    diagnosticsSummary: z.string().min(1).nullable(),
    replayInstruction: z.literal(false),
    createdAt: z.string().datetime(),
    updatedAt: z.string().datetime(),
  })
  .strip();

type ExportedWorkerCheckpoint = z.infer<typeof ExportedWorkerCheckpointSchema>;

const ExportedMcpToolSchemaSnapshotSchema = z
  .object({
    capturedAt: z.string().datetime(),
    catalogEntryId: z.string().min(1),
    contentDigest: z.string().min(1),
    schemaSnapshotId: z.string().min(1),
    serverVersion: z.string().min(1).nullable(),
    source: z.enum(['aep', 'live']),
    sourceRef: z.string().min(1).nullable(),
    tools: z.array(
      z
        .object({
          inputSchema: z.record(z.string(), z.unknown()),
          name: z.string().min(1),
        })
        .strip()
    ),
    workspaceId: WorkspaceIdSchema,
  })
  .strip();

type ExportedMcpToolSchemaSnapshot = z.infer<typeof ExportedMcpToolSchemaSnapshotSchema>;

const ExportedWorkspaceVaultReferenceSchema = z
  .object({
    sourceReferenceId: z.string().min(1),
    displayName: z.string().min(1),
    secretKind: z.string().min(1),
    backendKind: z.literal('encrypted-file'),
    createdAt: z.string().datetime(),
    updatedAt: z.string().datetime(),
  })
  .strict();

const ImportedWorkspaceVaultReferenceSchema = ExportedWorkspaceVaultReferenceSchema.extend({
  referenceId: z.string().min(1),
  ownerScope: z.literal('workspace'),
  workspaceId: WorkspaceIdSchema,
  backendLocator: z.null(),
  status: z.literal('unbound'),
  currentVersion: z.literal(0),
}).strict();

type ImportedWorkspaceVaultReference = z.infer<typeof ImportedWorkspaceVaultReferenceSchema>;

const ExportedVaultGrantSchema = z
  .object({
    issuance: z.enum(['target', 'imported-history']),
    grantId: VaultGrantIdSchema,
    vaultReferenceId: VaultReferenceIdSchema,
    ownerScope: z.literal('workspace'),
    workspaceId: WorkspaceIdSchema,
    userId: z.null(),
    subjectSummary: z.string().min(1).nullable(),
    targetAgentId: z.string().min(1).nullable(),
    targetAgentSessionId: AgentSessionIdSchema.nullable(),
    targetCapabilityId: z.string().min(1).nullable(),
    allowedInjectionPaths: z.array(z.string().min(1)),
    lifetime: z.enum(['capability-call', 'turn', 'agent-session', 'workspace', 'server']),
    policyDecisionId: PermissionDecisionIdSchema.nullable(),
    approvalId: z.string().min(1).nullable(),
    status: z.enum(['active', 'revoked', 'expired']),
    createdAt: z.string().datetime(),
    expiresAt: z.string().datetime().nullable(),
  })
  .strict();

type ExportedVaultGrant = z.infer<typeof ExportedVaultGrantSchema>;

const ExportedVaultInjectionPlanSchema = z
  .object({
    planId: z.string().min(1),
    grantId: VaultGrantIdSchema,
    packageSnapshotId: z.string().min(1).nullable(),
    capabilityId: z.string().min(1).nullable(),
    injectionVisibility: InjectionVisibilitySchema,
    targetPath: z.string().min(1).nullable(),
    targetEnvVarName: z.string().min(1).nullable(),
    expirationBehavior: z.string().min(1),
    revocationBehavior: z.string().min(1),
    redactionRule: z.string().min(1),
    backendCapabilityRequirement: z.string().min(1),
    status: z.enum(['active', 'revoked', 'expired']),
    createdAt: z.string().datetime(),
  })
  .strict();

type ExportedVaultInjectionPlan = z.infer<typeof ExportedVaultInjectionPlanSchema>;

const ExportedVaultInjectionReceiptSchema = z
  .object({
    receiptId: z.string().min(1),
    planId: z.string().min(1),
    grantId: VaultGrantIdSchema,
    agentSessionId: AgentSessionIdSchema.nullable(),
    capabilityCallId: CapabilityCallIdSchema.nullable(),
    backendSummary: z.string().min(1),
    injectedAt: z.string().datetime(),
    expiresAt: z.string().datetime().nullable(),
    revocationStatus: z.enum(['active', 'revoked', 'expired', 'stale-session']),
    auditEventId: AuditEventIdSchema.nullable(),
  })
  .strict();

type ExportedVaultInjectionReceipt = z.infer<typeof ExportedVaultInjectionReceiptSchema>;

const ExportedVaultUseRecordSchema = z
  .object({
    useId: z.string().min(1),
    ownerScope: z.literal('workspace'),
    workspaceId: WorkspaceIdSchema,
    vaultReferenceId: VaultReferenceIdSchema,
    materialVersion: z.number().int().nonnegative().nullable(),
    backendKind: z.literal('encrypted-file'),
    resolvingPath: z.enum(['grant', 'plan', 'admin', 'provider']),
    grantId: VaultGrantIdSchema.nullable(),
    planId: z.string().min(1).nullable(),
    receiptId: z.string().min(1).nullable(),
    agentSessionId: AgentSessionIdSchema.nullable(),
    capabilityCallId: CapabilityCallIdSchema.nullable(),
    outcome: z.enum(['succeeded', 'failed', 'denied']),
    failureCode: z.string().min(1).nullable(),
    auditEventId: AuditEventIdSchema.nullable(),
    usedAt: z.string().datetime(),
  })
  .strict();

type ExportedVaultUseRecord = z.infer<typeof ExportedVaultUseRecordSchema>;

/** Input for reading one verified export into importable records. */
export interface ReadWorkspaceImportSnapshotInput {
  /** Already verified export tree whose exact bytes are being imported. */
  verified: VerifiedWorkspaceExportTree;
  /** Workspace id to use in imported records. */
  targetWorkspaceId: string;
  /** Current target Server identity used for reminted trusted query context. */
  targetServerId?: string;
}

/** Importable record snapshot extracted from one workspace export. */
export interface WorkspaceImportSnapshot {
  /** Target-relative immutable payload paths mapped to their verified private export sources. */
  artifactPayloadFiles: ReadonlyMap<string, string>;
  /** Validated current Goal records and Task terminal facts; approval grants remain source-local. */
  goalState: ReturnType<typeof readCurrentGoalImportState>;
  /** Verified dry-run report for the export. */
  report: WorkspaceImportDryRunReport;
  /** Imported workspace record with target id. */
  workspace: WorkspaceRecord;
  /** Imported thread records with target workspace id. */
  threads: Thread[];
  /** Imported turns with target workspace, thread, and current item lineage. */
  turns: Turn[];
  /** Imported knowledge records. */
  knowledge: KnowledgeEntry[];
  /** Imported full item revision history. */
  itemRevisions: Item[];
  /** Imported artifacts with reconstructed bodies. */
  artifacts: Artifact[];
  /** Imported Workspace Material owners. */
  workspaceMaterials: ImportedWorkspaceMaterial[];
  /** Imported immutable Material revisions. */
  workspaceMaterialRevisions: ImportedWorkspaceMaterialRevision[];
  /** Imported Thread-to-Material bindings. */
  threadMaterialBindings: ImportedThreadMaterialBinding[];
  /** Imported version-keyed Artifact Reviews. */
  artifactReviews: ImportedArtifactReview[];
  /** Imported durable AgentSessions. */
  agentSessions: AgentSession[];
  /** Imported retained turn event logs keyed by reminted turn id. */
  turnEvents: Array<[string, SseEventEnvelope[]]>;
  /** Imported knowledge source identity records. */
  knowledgeSources: KnowledgeSourceRecord[];
  /** Imported knowledge source text materials. */
  knowledgeSourceMaterials: ExportedKnowledgeSourceMaterial[];
  /** Imported unbound workspace vault references. */
  vaultReferences: ImportedWorkspaceVaultReference[];
  /** Imported non-secret workspace vault grants. */
  vaultGrants: ExportedVaultGrant[];
  /** Imported non-secret injection plans. */
  vaultInjectionPlans: ExportedVaultInjectionPlan[];
  /** Imported non-secret injection receipts. */
  vaultInjectionReceipts: ExportedVaultInjectionReceipt[];
  /** Imported non-secret workspace vault use records. */
  vaultUseRecords: ExportedVaultUseRecord[];
  /** Imported workspace audit events. */
  auditEvents: AuditEvent[];
  /** Imported workspace capability calls. */
  capabilityCalls: ExportedCapabilityCall[];
  /** Imported workspace evidence bundles. */
  evidenceBundles: EvidenceBundleRecord[];
  /** Imported workspace runtime evidence. */
  runtimeEvidence: RuntimeEvidenceRecord[];
  /** Reminted product-safe runtime provenance indexes keyed by target bundle id. */
  runtimeProvenanceIndexes: ReadonlyMap<string, string>;
  /** Exact retained restricted bodies keyed by reminted bundle and unchanged relative path. */
  restrictedEvidenceFiles: ReadonlyMap<string, Uint8Array>;
  /** Reminted committed observation JSONL keyed by target Turn id. */
  turnObservations: ReadonlyMap<string, string>;
  /** Immutable historical coverage keyed by target Turn id. */
  turnCaptureCoverage: ReadonlyMap<string, CaptureCoverageBinding>;
  /** Imported workspace usage records. */
  usageRecords: UsageRecord[];
  /** Imported workspace-owned data source catalog. */
  dataSourceCatalog: WorkspaceDataSourceCatalog | null;
  /** Imported workspace Git push records. */
  gitPushRecords: ExportedGitPushRecord[];
  /** Imported resolved agent setup records. */
  resolvedAgentSetups: ExportedResolvedAgentSetup[];
  /** Imported redacted Agent Environment Package snapshots. */
  agentEnvironmentPackageSnapshots: ExportedAgentEnvironmentPackageSnapshot[];
  /** Imported workspace repository resources. */
  workspaceRepositories: ExportedWorkspaceRepositoryResource[];
  /** Imported workspace sync input snapshots. */
  workspaceInputSnapshots: WorkspaceInputSnapshot[];
  /** Imported workspace sync materialization records. */
  workspaceMaterializationRecords: WorkspaceMaterializationRecord[];
  /** Imported workspace sync backend handles. */
  backendWorkspaceHandles: BackendWorkspaceHandle[];
  /** Imported worker output manifests. */
  workerOutputManifests: WorkerOutputManifest[];
  /** Imported workspace sync change sets. */
  workspaceChangeSets: WorkspaceChangeSet[];
  /** Imported staged workspace review rows. */
  stagedWorkspaceReviews: ExportedStagedWorkspaceReview[];
  /** Imported workspace apply plan rows. */
  workspaceApplyPlans: WorkspaceApplyPlan[];
  /** Imported workspace apply result rows. */
  workspaceApplyResults: ExportedWorkspaceApplyResult[];
  /** Imported workspace reconciliation rows. */
  workspaceReconciliationRecords: WorkspaceReconciliationRecord[];
  /** Imported workspace quarantine rows. */
  workspaceQuarantineRecords: WorkspaceQuarantineRecord[];
  /** Imported workspace permission decision rows. */
  permissionDecisions: ExportedWorkspacePermissionDecision[];
  /** Imported worker checkpoint rows. */
  workerCheckpoints: ExportedWorkerCheckpoint[];
  /** Imported MCP tool schema snapshot rows. */
  mcpToolSchemaSnapshots: ExportedMcpToolSchemaSnapshot[];
  /** Portable Light App identity rows. */
  lightApps: unknown[];
  /** Portable Light App definition rows. */
  lightAppDefinitions: unknown[];
  /** Portable Light App record rows. */
  lightAppRecords: unknown[];
  /** Portable Generative UI presentation rows. */
  generativePresentations: Record<string, unknown>[];
  /** Imported presentation ids keyed by source id. */
  presentationIds: Map<string, string>;
  /** Imported thread ids keyed by source id. */
  threadIds: Map<string, string>;
  /** Imported turn ids keyed by source id. */
  turnIds: Map<string, string>;
  /** Imported item ids keyed by source id. */
  itemIds: Map<string, string>;
  /** Reconstructed inactive Workspace resource catalog, or null when the export omits it. */
  agentResourceCatalog: ResourceCatalogDocument | null;
  /** Verified Skill payloads to materialize beside the reconstructed catalog. */
  importedSkillPayloads: readonly PortableSkillPayload[];
  /** Imported authoritative workspace files ready for staged publication. */
  portableFileState: WorkspacePortableFileState;
}

/**
 * Verifies every staged imported-history Context Package against the reminted snapshot owners.
 *
 * @param snapshot Fully parsed and reminted import snapshot.
 * @param workspaceRoot Staging root containing the exact reminted package files.
 * @throws Error when any trace, package byte, or portable owner tuple is inconsistent.
 */
export function verifyImportedWorkerContextPackageSnapshot(
  snapshot: WorkspaceImportSnapshot,
  workspaceRoot: string
): void {
  const authorities = createImportedWorkerContextPackageAuthorityReader(snapshot);
  for (const [path, text] of snapshot.portableFileState.workerContextPackageFiles) {
    if (!path.endsWith('/context-package.json')) {
      continue;
    }
    verifyImportedWorkerContextPackageTrace({
      authorities,
      trace: parseWorkerContextPackageTrace(JSON.parse(text)),
      workspaceRoot,
    });
  }
}

/**
 * Builds the read-only authority projection required by imported-history verification.
 *
 * @param snapshot Fully reminted import snapshot.
 * @returns Authority reader backed only by the snapshot's durable owners.
 */
function createImportedWorkerContextPackageAuthorityReader(
  snapshot: WorkspaceImportSnapshot
): WorkerContextPackageAuthorityReader {
  const items = snapshot.turns.flatMap((turn) => turn.items);
  return {
    readAdmission: () => null,
    readThreadParent: (workspaceId, threadId) =>
      snapshot.threads.find(
        (thread) => thread.workspaceId === workspaceId && thread.id === threadId
      )?.parentThreadId ?? null,
    readAgentEnvironmentPackage: (workspaceId, packageSnapshotId) =>
      snapshot.agentEnvironmentPackageSnapshots.find(
        (record) => record.workspaceId === workspaceId && record.snapshotId === packageSnapshotId
      )?.snapshot ?? null,
    readAgentSession: (workspaceId, agentSessionId) => {
      const session = snapshot.agentSessions.find(
        (candidate) => candidate.workspaceId === workspaceId && candidate.id === agentSessionId
      );
      return session?.threadId
        ? {
            id: session.id,
            workspaceId: session.workspaceId,
            threadId: session.threadId,
            environmentPackageSnapshotId: session.environmentPackageSnapshotId,
            stale: session.stale,
          }
        : null;
    },
    readWorkspaceImportedFrom: (workspaceId) =>
      workspaceId === snapshot.workspace.id ? (snapshot.workspace.importedFrom ?? null) : null,
    readBackendHandoff: () => null,
    readMaterialRevision: (workspaceId, materialId, revisionId) => {
      const material = snapshot.workspaceMaterials.find(
        (candidate) => candidate.workspaceId === workspaceId && candidate.materialId === materialId
      );
      const revision = snapshot.workspaceMaterialRevisions.find(
        (candidate) =>
          candidate.workspaceId === workspaceId &&
          candidate.materialId === materialId &&
          candidate.revisionId === revisionId
      );
      return material && revision ? { ...revision, sensitivity: material.sensitivity } : null;
    },
    readThreadItems: (workspaceId, threadId) =>
      items.filter((item) => item.workspaceId === workspaceId && item.threadId === threadId),
    readTurn: (workspaceId, threadId, turnId) => {
      const turn = snapshot.turns.find(
        (candidate) =>
          candidate.workspaceId === workspaceId &&
          candidate.threadId === threadId &&
          candidate.id === turnId
      );
      return turn ? { ...turn, agentSessionId: turn.agentSessionId ?? null } : null;
    },
    readWorkspaceInputSnapshot: (workspaceId, snapshotId) =>
      snapshot.workspaceInputSnapshots.find(
        (candidate) => candidate.workspaceId === workspaceId && candidate.id === snapshotId
      ) ?? null,
    readWorkspaceMaterializationRecord: (workspaceId, recordId) =>
      snapshot.workspaceMaterializationRecords.find(
        (candidate) => candidate.workspaceId === workspaceId && candidate.id === recordId
      ) ?? null,
  };
}

/** Shared id lineage used while reconstructing one portable workspace import. */
interface ImportRemintContext {
  /** Exact export files captured by offline verification. */
  files: ReadonlyMap<string, string>;
  /** Verified original evidence bytes, never parsed or rewritten as canonical history. */
  binaryFiles: ReadonlyMap<string, Uint8Array>;
  /** Digest of the verified manifest bytes. */
  manifestDigest: string;
  /** Dry-run report that owns source export lineage. */
  report: WorkspaceImportDryRunReport;
  /** Workspace id assigned to reconstructed records. */
  targetWorkspaceId: string;
  /** Current target Server identity, required when the export contains retrieval traces. */
  targetServerId?: string;
  /** Parsed source Material owners. */
  sourceWorkspaceMaterials: ImportedWorkspaceMaterial[];
  /** Parsed source Material revisions. */
  sourceWorkspaceMaterialRevisions: ImportedWorkspaceMaterialRevision[];
  /** Parsed source Thread Material bindings. */
  sourceThreadMaterialBindings: ImportedThreadMaterialBinding[];
  /** Parsed source version-keyed Artifact Reviews. */
  sourceArtifactReviews: ImportedArtifactReview[];
  /** Imported thread ids keyed by source id. */
  threadIds: Map<string, string>;
  /** Imported turn ids keyed by source id. */
  turnIds: Map<string, string>;
  /** Imported item ids keyed by source id. */
  itemIds: Map<string, string>;
  /** Latest source Item revision keyed by source id. */
  itemLineage: Map<string, Item>;
  /** Imported artifact ids keyed by source id. */
  artifactIds: Map<string, string>;
  /** Imported Material ids keyed by source id. */
  materialIds: Map<string, string>;
  /** Imported Material revision ids keyed by source id. */
  materialRevisionIds: Map<string, string>;
  /** Imported AgentSession ids keyed by source id. */
  agentSessionIds: Map<string, string>;
  /** Imported approval-request ids keyed by source id. */
  approvalRequestIds: Map<string, string>;
  /** Imported AEP snapshot ids keyed by source id. */
  agentEnvironmentPackageSnapshotIds: Map<string, string>;
  /** Imported knowledge-source ids keyed by source id. */
  knowledgeSourceIds: Map<string, string>;
  /** Exact accepted Context Package references keyed by their source form. */
  contextPackageReferences: Map<string, string>;

  /** Imported worker checkpoint ids keyed by source id. */
  workerCheckpointIds: Map<string, string>;

  /** Imported Vault grant ids keyed by source id. */
  vaultGrantIds: Map<string, string>;
  /** Imported evidence bundle ids keyed by source id. */
  evidenceBundleIds: Map<string, string>;
  /** Package-scoped origin maps shared by indexed provenance, live observations and Gateway calls. */
  runtimeOriginRefsByPackageSnapshotId: Map<string, Map<string, string>>;
  /** Packages whose complete provenance index forbids additional unindexed origins. */
  completeRuntimeOriginPackages: Set<string>;
  /** Canonical knowledge ids retained by the imported workspace. */
  knowledgeIds: Set<string>;
  /** Imported presentation ids keyed by source id. */
  presentationIds: Map<string, string>;
}

/** Allocates once for each complete source owner key in this verified invocation. */
function allocateImportedEntityIds(
  kind: EntityKind,
  sourceIds: Iterable<string>
): Map<string, string> {
  const ids = new Map<string, string>();
  for (const sourceId of sourceIds)
    if (!ids.has(sourceId)) ids.set(sourceId, allocateEntityId(kind));
  return ids;
}

/**
 * Reads one verified workspace export into records ready for FsStore import.
 *
 * @param input Export root and imported workspace id.
 * @returns Parsed import snapshot with target workspace and thread ids.
 * @throws Error when export verification or record parsing fails.
 */
export function readWorkspaceImportSnapshot(
  input: ReadWorkspaceImportSnapshotInput
): WorkspaceImportSnapshot {
  for (const removedPath of [
    'records/workspace-sync-evidence-bundles.jsonl',
    'records/knowledge-context-package-traces.jsonl',
    'records/knowledge-proposals.jsonl',
    'records/knowledge-proposal-reviews.jsonl',
    ...UNSUPPORTED_WORKSPACE_EXPORT_RECORD_PATHS,
  ]) {
    if (input.verified.fileContents.has(removedPath)) {
      throw new Error(`Unsupported workspace export record path: ${removedPath}`);
    }
  }
  const report = dryRunWorkspaceImport({
    verified: input.verified,
    workspaceExists: () => false,
  });
  const sourceWorkspaceMaterials = readImportJsonl(
    input.verified.fileContents,
    'records/workspace-materials.jsonl'
  ).map((record) => ImportedWorkspaceMaterialSchema.parse(record));
  const sourceWorkspaceMaterialRevisions = readImportJsonl(
    input.verified.fileContents,
    'records/workspace-material-revisions.jsonl'
  ).map((record) => ImportedWorkspaceMaterialRevisionSchema.parse(record));
  const sourceThreadMaterialBindings = readImportJsonl(
    input.verified.fileContents,
    'records/thread-material-bindings.jsonl'
  ).map((record) => ImportedThreadMaterialBindingSchema.parse(record));
  const sourceArtifactReviews = readImportJsonl(
    input.verified.fileContents,
    'records/artifact-reviews.jsonl'
  ).map((record) => ImportedArtifactReviewSchema.parse(record));
  const context: ImportRemintContext = {
    files: input.verified.fileContents,
    binaryFiles: input.verified.binaryFileContents,
    manifestDigest: input.verified.manifestDigest,
    report,
    targetWorkspaceId: input.targetWorkspaceId,
    ...(input.targetServerId ? { targetServerId: input.targetServerId } : {}),
    sourceWorkspaceMaterials,
    sourceWorkspaceMaterialRevisions,
    sourceThreadMaterialBindings,
    sourceArtifactReviews,
    threadIds: new Map(),
    turnIds: new Map(),
    itemIds: new Map(),
    itemLineage: new Map(),
    artifactIds: new Map(),
    materialIds: allocateImportedEntityIds(
      'mat',
      sourceWorkspaceMaterials.map((material) => material.materialId)
    ),
    materialRevisionIds: allocateImportedEntityIds(
      'mrev',
      sourceWorkspaceMaterialRevisions.map((revision) =>
        materialRevisionKey(revision.materialId, revision.revisionId)
      )
    ),
    agentSessionIds: new Map(),
    approvalRequestIds: new Map(),
    agentEnvironmentPackageSnapshotIds: new Map(),
    knowledgeSourceIds: new Map(),
    contextPackageReferences: new Map(),

    workerCheckpointIds: new Map(),

    vaultGrantIds: new Map(),
    evidenceBundleIds: new Map(),
    runtimeOriginRefsByPackageSnapshotId: new Map(),
    completeRuntimeOriginPackages: new Set(),
    knowledgeIds: new Set(),
    presentationIds: new Map(),
  };
  const canonical = readCanonicalImportState(context);
  const retrievalTraces = readRetrievalTraceImportState(context);
  const workerRuntime = readWorkerRuntimeControlState(context);
  const securityRuntime = readSecurityRuntimeLedgerState(context);
  const workspaceSync = readWorkspaceSyncImportState(context);
  const workResources = readWorkResourceImportState(
    context,
    canonical,
    workspaceSync,
    retrievalTraces
  );
  const knowledgeReferenceReplacements = [
    ...context.contextPackageReferences,
    ...context.turnIds,
    ...context.itemIds,
    ...context.knowledgeSourceIds,
  ] as const;
  const knowledge = canonical.knowledge.map((entry) =>
    KnowledgeEntrySchema.parse({
      ...entry,
      ...(entry.sourceReferences
        ? {
            sourceReferences: rewritePortableReferences(
              entry.sourceReferences,
              knowledgeReferenceReplacements
            ),
          }
        : {}),
    })
  );
  const portableFileState = readPortableImportState(
    context,
    workResources.workerContextPackageFiles,
    knowledge,
    retrievalTraces.files
  );
  const importedCatalog = readImportedAgentResourceCatalog(context.files);
  const sourceArtifactIds = new Map(
    [...context.artifactIds].map(([sourceId, targetId]) => [targetId, sourceId])
  );
  const artifactPayloadFiles = new Map<string, string>();
  for (const artifact of canonical.artifacts) {
    if (artifact.content.format !== 'file') continue;
    const sourceId = sourceArtifactIds.get(artifact.id);
    const sourcePath = input.verified.artifactPayloadFiles.get(
      `artifacts/${sourceId}/versions/${artifact.version}/payload`
    );
    if (!sourceId || !sourcePath) throw new Error('Imported Artifact payload is unavailable.');
    artifactPayloadFiles.set(
      `artifacts/${artifact.id}/versions/${artifact.version}/payload`,
      sourcePath
    );
  }

  return {
    artifactPayloadFiles,
    report,
    goalState: readCurrentGoalImportState(context),
    workspace: canonical.workspace,
    threads: workResources.threads,
    turns: workResources.turns,
    knowledge,
    itemRevisions: workResources.itemRevisions,
    artifacts: canonical.artifacts,
    workspaceMaterials: workResources.workspaceMaterials,
    workspaceMaterialRevisions: workResources.workspaceMaterialRevisions,
    threadMaterialBindings: workResources.threadMaterialBindings,
    artifactReviews: workResources.artifactReviews,
    agentSessions: canonical.agentSessions,
    turnEvents: workResources.turnEvents,
    knowledgeSources: canonical.knowledgeSources,
    knowledgeSourceMaterials: canonical.knowledgeSourceMaterials,
    vaultReferences: securityRuntime.vaultReferences,
    vaultGrants: securityRuntime.vaultGrants,
    vaultInjectionPlans: securityRuntime.vaultInjectionPlans,
    vaultInjectionReceipts: securityRuntime.vaultInjectionReceipts,
    vaultUseRecords: securityRuntime.vaultUseRecords,
    auditEvents: securityRuntime.auditEvents,
    capabilityCalls: securityRuntime.capabilityCalls,
    evidenceBundles: securityRuntime.evidenceBundles,
    runtimeEvidence: securityRuntime.runtimeEvidence,
    runtimeProvenanceIndexes: securityRuntime.runtimeProvenanceIndexes,
    restrictedEvidenceFiles: securityRuntime.restrictedEvidenceFiles,
    ...readWorkObservationImportState(context),
    usageRecords: securityRuntime.usageRecords,
    dataSourceCatalog: securityRuntime.dataSourceCatalog,
    gitPushRecords: securityRuntime.gitPushRecords,
    resolvedAgentSetups: securityRuntime.resolvedAgentSetups,
    agentEnvironmentPackageSnapshots: workResources.agentEnvironmentPackageSnapshots.map(
      (record) => {
        const environmentPackage = RetainedAgentEnvironmentPackageSchema.parse(record.snapshot);
        const snapshot = {
          ...environmentPackage,
          extensions: {
            ...environmentPackage.extensions,
            openkit: {
              ...(environmentPackage.extensions.openkit as Record<string, unknown>),
              sessionWorkspace: planSessionWorkspaceMaterialization({ environmentPackage }),
            },
          },
        };
        return {
          ...record,
          contentDigest: createHash('sha256').update(JSON.stringify(snapshot)).digest('hex'),
          snapshot,
        };
      }
    ),
    workspaceRepositories: workspaceSync.workspaceRepositories,
    workspaceInputSnapshots: workResources.workspaceInputSnapshots,
    workspaceMaterializationRecords: workResources.workspaceMaterializationRecords,
    backendWorkspaceHandles: workspaceSync.backendWorkspaceHandles,
    workerOutputManifests: workspaceSync.workerOutputManifests,
    workspaceChangeSets: workspaceSync.workspaceChangeSets,
    stagedWorkspaceReviews: workspaceSync.stagedWorkspaceReviews,
    workspaceApplyPlans: workspaceSync.workspaceApplyPlans,
    workspaceApplyResults: workspaceSync.workspaceApplyResults,
    workspaceReconciliationRecords: workspaceSync.workspaceReconciliationRecords,
    workspaceQuarantineRecords: workspaceSync.workspaceQuarantineRecords,
    permissionDecisions: securityRuntime.permissionDecisions,
    workerCheckpoints: workerRuntime.workerCheckpoints,
    mcpToolSchemaSnapshots: workerRuntime.mcpToolSchemaSnapshots,
    lightApps: readOptionalImportJsonl(context.files, 'records/light-apps.jsonl'),
    lightAppDefinitions: readOptionalImportJsonl(
      context.files,
      'records/light-app-definitions.jsonl'
    ),
    lightAppRecords: readOptionalImportJsonl(context.files, 'records/light-app-records.jsonl'),
    generativePresentations: readOptionalImportJsonl(
      context.files,
      'records/generative-presentations.jsonl'
    ) as Record<string, unknown>[],
    presentationIds: context.presentationIds,
    threadIds: context.threadIds,
    turnIds: context.turnIds,
    itemIds: context.itemIds,
    agentResourceCatalog: importedCatalog.catalog,
    importedSkillPayloads: importedCatalog.payloads,
    portableFileState,
  };
}

/**
 * Reads the portable catalog projection and rejects original plugin roots or MCP package data.
 *
 * @param files Verified export file contents.
 * @returns Inactive reconstructed catalog, or null when the export predates the catalog feature.
 */
function readImportedAgentResourceCatalog(files: ReadonlyMap<string, string>): {
  catalog: ResourceCatalogDocument | null;
  payloads: PortableSkillPayload[];
} {
  for (const path of files.keys()) {
    if (
      path === 'catalog/catalog.json' ||
      path.startsWith('catalog/plugin-snapshots/') ||
      path.startsWith('catalog/mcp-data/')
    ) {
      throw new Error(`Unsupported workspace export file: ${path}.`);
    }
  }
  const text = files.get(AGENT_RESOURCE_CATALOG_EXPORT_PATH);
  if (!text) {
    return { catalog: null, payloads: [] };
  }
  const portable = readPortableAgentResourceCatalog(text);
  const payloads = new Map<string, PortableSkillPayload>();
  for (const [path, body] of files) {
    if (!path.startsWith('skill-payloads/')) {
      continue;
    }
    payloads.set(path, readPortableSkillPayload(body));
  }
  return {
    catalog: reconstructImportedWorkspaceCatalog(portable, payloads),
    payloads: [...payloads.values()],
  };
}

/**
 * Remints one Artifact and its immutable turn-output lineage.
 *
 * @param artifact Source Artifact from the verified export.
 * @param context Target workspace and canonical id maps.
 * @returns Schema-valid Artifact with target lineage.
 * @throws Error when a required source id is absent or the reminted Artifact is invalid.
 */
function remintPortableArtifact(
  artifact: Artifact,
  context: {
    readonly targetWorkspaceId: string;
    readonly artifactIds: ReadonlyMap<string, string>;
    readonly threadIds: ReadonlyMap<string, string>;
    readonly turnIds: ReadonlyMap<string, string>;
  }
): Artifact {
  return ArtifactSchema.parse({
    ...artifact,
    id: requiredMapValue(context.artifactIds, artifact.id, 'artifact'),
    workspaceId: context.targetWorkspaceId,
    threadId: artifact.threadId
      ? requiredMapValue(context.threadIds, artifact.threadId, 'thread')
      : null,
    turnId: artifact.turnId ? requiredMapValue(context.turnIds, artifact.turnId, 'turn') : null,
    origin:
      artifact.origin.kind === 'turn-output'
        ? {
            ...artifact.origin,
            threadId: requiredMapValue(context.threadIds, artifact.origin.threadId, 'thread'),
            turnId: requiredMapValue(context.turnIds, artifact.origin.turnId, 'turn'),
          }
        : artifact.origin,
  });
}

/**
 * Reconstructs the canonical workspace graph, AEP snapshots, events, and sources.
 *
 * @param context Shared import lineage and verified bytes.
 * @returns Canonical imported records.
 * @throws Error when canonical record parsing or lineage validation fails.
 */
function readCanonicalImportState(context: ImportRemintContext) {
  const { report } = context;
  if (context.files.has('records/workspace.json')) {
    throw new Error('Unsupported workspace export file: records/workspace.json.');
  }
  const exportedWorkspaceRecord = WorkspaceSystemRecordSchema.parse(
    readImportJson(context.files, 'records/workspace-record.json')
  );
  const exportedWorkspaceConfig = WorkspaceConfigSchema.parse(
    parseJsoncObject(
      requiredExportFile(context.files, 'workspace-files/config/workspace.jsonc'),
      'workspace-files/config/workspace.jsonc'
    )
  );
  if (exportedWorkspaceRecord.id !== report.manifest.workspaceId) {
    throw new Error('Workspace record id does not match the export manifest.');
  }
  const exportedThreads = readWorkspaceExportThreads(context.files);
  const threadIds = allocateImportedEntityIds(
    'th',
    exportedThreads.map((thread) => thread.id)
  );
  const targetThreadIds = new Set(threadIds.values());
  const threads = exportedThreads.map((thread) => {
    const mappedParent =
      thread.parentThreadId === undefined ? undefined : threadIds.get(thread.parentThreadId);
    if (
      thread.parentThreadId !== undefined &&
      mappedParent === undefined &&
      targetThreadIds.has(thread.parentThreadId)
    ) {
      throw new Error('Unresolved source Thread parent collides with a target Thread.');
    }
    return ThreadSchema.parse({
      ...thread,
      id: requiredMapValue(threadIds, thread.id, 'Thread'),
      workspaceId: context.targetWorkspaceId,
      // Core keeps missing or excluded parents as unresolved source lineage, never a target lookup.
      ...(thread.parentThreadId === undefined
        ? {}
        : { parentThreadId: mappedParent ?? thread.parentThreadId }),
    });
  });
  const exportedKnowledge = readImportJsonl(context.files, 'records/knowledge.jsonl').map(
    (record) => KnowledgeEntrySchema.parse(record)
  );
  const exportedTurns = readImportJsonl(context.files, 'records/turns.jsonl').map((record) =>
    TurnSchema.parse(record)
  );
  const turnIds = allocateImportedEntityIds(
    'tu',
    exportedTurns.map((turn) => turn.id)
  );
  const exportedArtifacts = readExportedArtifacts(context.files, report.manifest);
  const exportedWorkspace = WorkspaceRecordSchema.parse({
    ...exportedWorkspaceRecord,
    name: exportedWorkspaceConfig.workspace.name,
    counts: {
      threadCount: exportedThreads.length,
      artifactCount: exportedArtifacts.length,
      knowledgeEntryCount: exportedKnowledge.length,
    },
  });
  const workspace = WorkspaceRecordSchema.parse({
    ...exportedWorkspace,
    id: context.targetWorkspaceId,
    importedFrom: {
      sourceDeploymentId: report.manifest.sourceDeploymentId,
      sourceWorkspaceId: report.exportedWorkspaceId,
      exportCreatedAt: report.manifest.exportCreatedAt,
      manifestDigest: context.manifestDigest,
    },
  });
  const artifactIds = allocateImportedEntityIds(
    'ar',
    exportedArtifacts.map((artifact) => artifact.id)
  );
  const exportedAgentSessions = readImportJsonl(context.files, 'records/agent-sessions.jsonl').map(
    (record) => AgentSessionRecordSchema.parse(record) as AgentSession
  );
  const agentSessionIds = allocateImportedEntityIds(
    'as',
    exportedAgentSessions.map((session) => session.id)
  );
  const exportedItemRevisions = readImportJsonl(context.files, 'records/item-revisions.jsonl').map(
    (record) => ItemSchema.parse(record)
  );
  const unresolvedUserInputRequestIds =
    listUnresolvedUserInputRequestItemIds(exportedItemRevisions);

  if (unresolvedUserInputRequestIds.length > 0) {
    throw new Error(
      `Workspace import is blocked by unresolved user-input-request Items: ${unresolvedUserInputRequestIds.join(', ')}.`
    );
  }
  const itemIds = new Map<string, string>();
  const itemLineage = new Map<string, Item>();
  const approvalRequestIds = new Map<string, string>();
  const userInputRequestIds = new Map<string, string>();
  for (const revision of exportedItemRevisions) {
    if (!itemIds.has(revision.id)) {
      itemIds.set(
        revision.id,
        revision.type === 'artifact-reference'
          ? artifactReferenceItemId(
              requiredMapValue(artifactIds, revision.artifactId, 'artifact'),
              requiredMapValue(turnIds, revision.turnId, 'turn')
            )
          : allocateEntityId('it')
      );
    }
    itemLineage.set(revision.id, revision);
    if (
      (revision.type === 'approval-request' || revision.type === 'approval-decision') &&
      !approvalRequestIds.has(revision.approvalRequestId)
    ) {
      approvalRequestIds.set(
        revision.approvalRequestId,
        `apr_imported_${context.targetWorkspaceId}_${approvalRequestIds.size + 1}`
      );
    }
    if (
      (revision.type === 'user-input-request' || revision.type === 'user-input-response') &&
      !userInputRequestIds.has(revision.userInputRequestId)
    ) {
      userInputRequestIds.set(
        revision.userInputRequestId,
        `uir_imported_${context.targetWorkspaceId}_${userInputRequestIds.size + 1}`
      );
    }
  }
  const exportedPresentations = readOptionalImportJsonl(
    context.files,
    'records/generative-presentations.jsonl'
  );
  for (const row of exportedPresentations) {
    if (
      !row ||
      typeof row !== 'object' ||
      Array.isArray(row) ||
      typeof (row as { id?: unknown }).id !== 'string'
    ) {
      throw new Error('Invalid generative presentation export row.');
    }
    const record = row as { id: string; lineage?: { itemId?: unknown } };
    if (!context.presentationIds.has(record.id)) {
      context.presentationIds.set(record.id, allocateEntityId('pres'));
    }
    const reservedItemId = record.lineage?.itemId;
    if (typeof reservedItemId === 'string' && !itemIds.has(reservedItemId)) {
      itemIds.set(reservedItemId, allocateEntityId('it'));
    }
  }
  const exportedAgentEnvironmentPackageSnapshots = readOptionalImportJsonl(
    context.files,
    'records/agent-environment-package-snapshots.jsonl'
  ).map((record) => ExportedAgentEnvironmentPackageSnapshotSchema.parse(record));
  const agentEnvironmentPackageSnapshotIds = new Map(
    exportedAgentEnvironmentPackageSnapshots.map((record, index) => [
      record.snapshotId,
      `aepsnap_imported_${context.targetWorkspaceId}_${index + 1}`,
    ])
  );
  const agentEnvironmentPackageIds = new Map(
    exportedAgentEnvironmentPackageSnapshots.map((record, index) => [
      record.packageId,
      `aepkg_imported_${context.targetWorkspaceId}_${index + 1}`,
    ])
  );
  const agentEnvironmentPackageSnapshots = exportedAgentEnvironmentPackageSnapshots.map(
    (parsed) => {
      const originalSnapshot = z.record(z.string(), z.unknown()).parse(parsed.snapshot);
      if (
        parsed.contentDigest !==
        createHash('sha256').update(JSON.stringify(originalSnapshot)).digest('hex')
      ) {
        throw new Error(`Agent environment package snapshot digest mismatch: ${parsed.snapshotId}`);
      }
      // Refuse unsafe source evidence before normalization can hide it or remint can replace its digest.
      if (
        !isDeepStrictEqual(
          originalSnapshot,
          redactAgentEnvironmentPackageSnapshot(originalSnapshot as AgentEnvironmentPackage)
        )
      ) {
        throw new Error(`Agent environment package snapshot is not redacted: ${parsed.snapshotId}`);
      }
      const snapshot = RetainedAgentEnvironmentPackageSchema.parse(originalSnapshot);
      const scope = z.record(z.string(), z.unknown()).parse(snapshot.scope);
      if (
        parsed.workspaceId !== report.exportedWorkspaceId ||
        snapshot.snapshotId !== parsed.snapshotId ||
        snapshot.packageId !== parsed.packageId ||
        scope.workspaceId !== parsed.workspaceId ||
        scope.threadId !== parsed.threadId ||
        scope.turnId !== parsed.turnId ||
        scope.agentSessionId !== parsed.agentSessionId
      ) {
        throw new Error(
          `Agent environment package snapshot has invalid lineage: ${parsed.snapshotId}`
        );
      }

      const snapshotId = requiredMapValue(
        agentEnvironmentPackageSnapshotIds,
        parsed.snapshotId,
        'agent environment package snapshot'
      );
      const packageId = requiredMapValue(
        agentEnvironmentPackageIds,
        parsed.packageId,
        'agent environment package'
      );
      const threadId = requiredMapValue(threadIds, parsed.threadId, 'thread');
      const turnId = requiredMapValue(turnIds, parsed.turnId, 'turn');
      const agentSessionId = requiredMapValue(
        agentSessionIds,
        parsed.agentSessionId,
        'AgentSession'
      );
      const portableSnapshot = z.record(z.string(), z.unknown()).parse(
        rewriteJsonStringReferences(snapshot, [
          [parsed.snapshotId, snapshotId],
          [parsed.packageId, packageId],
          [
            workerSessionInputPaths(parsed.agentSessionId).root,
            workerSessionInputPaths(agentSessionId).root,
          ],
        ])
      );
      const rewrittenSnapshot = {
        ...portableSnapshot,
        snapshotId,
        packageId,
        scope: {
          ...scope,
          workspaceId: context.targetWorkspaceId,
          threadId,
          turnId,
          agentSessionId,
          ...(scope.itemId === undefined
            ? {}
            : {
                itemId:
                  scope.itemId === null
                    ? null
                    : requiredMapValue(itemIds, z.string().parse(scope.itemId), 'item'),
              }),
        },
      };

      return ExportedAgentEnvironmentPackageSnapshotSchema.parse({
        ...parsed,
        snapshotId,
        packageId,
        workspaceId: context.targetWorkspaceId,
        threadId,
        turnId,
        agentSessionId,
        contentDigest: createHash('sha256').update(JSON.stringify(rewrittenSnapshot)).digest('hex'),
        snapshot: rewrittenSnapshot,
      }) as ExportedAgentEnvironmentPackageSnapshot;
    }
  );
  const itemRevisions = exportedItemRevisions.map((item) => {
    const rewritten: Record<string, unknown> = {
      ...item,
      id: requiredMapValue(itemIds, item.id, 'item'),
      threadId: requiredMapValue(threadIds, item.threadId, 'thread'),
      turnId: requiredMapValue(turnIds, item.turnId, 'turn'),
      workspaceId: context.targetWorkspaceId,
      ...(item.parentItemId === undefined
        ? {}
        : {
            parentItemId:
              item.parentItemId === null
                ? null
                : requiredMapValue(itemIds, item.parentItemId, 'parent item'),
          }),
    };
    if (item.type !== 'user-input-response' && item.causationId && itemIds.has(item.causationId)) {
      rewritten.causationId = requiredMapValue(itemIds, item.causationId, 'causation item');
    }
    if (item.type === 'artifact-reference') {
      rewritten.artifactId = requiredMapValue(artifactIds, item.artifactId, 'artifact');
    } else if (item.type === 'approval-request' || item.type === 'approval-decision') {
      rewritten.approvalRequestId = requiredMapValue(
        approvalRequestIds,
        item.approvalRequestId,
        'approval request'
      );
    } else if (item.type === 'user-input-request' || item.type === 'user-input-response') {
      rewritten.userInputRequestId = requiredMapValue(
        userInputRequestIds,
        item.userInputRequestId,
        'user input request'
      );
    } else if (item.type === 'generative-ui-reference') {
      rewritten.presentationId = requiredMapValue(
        context.presentationIds,
        item.presentationId,
        'presentation'
      );
    }
    return ItemSchema.parse(rewritten);
  });
  const currentItems = new Map<string, Item>();
  for (const item of itemRevisions) {
    currentItems.set(item.id, item);
  }
  const turns = exportedTurns.map((turn) => {
    return TurnSchema.parse({
      ...turn,
      id: requiredMapValue(turnIds, turn.id, 'turn'),
      threadId: requiredMapValue(threadIds, turn.threadId, 'thread'),
      workspaceId: context.targetWorkspaceId,
      agentSessionId: turn.agentSessionId
        ? requiredMapValue(agentSessionIds, turn.agentSessionId, 'AgentSession')
        : turn.agentSessionId,
      items: turn.items.map((item) =>
        requiredMapValue(currentItems, requiredMapValue(itemIds, item.id, 'item'), 'item')
      ),
    });
  });
  const artifacts = exportedArtifacts.map((artifact) =>
    remintPortableArtifact(artifact, {
      targetWorkspaceId: context.targetWorkspaceId,
      artifactIds,
      threadIds,
      turnIds,
    })
  );
  const agentSessions = exportedAgentSessions.map(
    (session) =>
      AgentSessionRecordSchema.parse({
        ...session,
        id: requiredMapValue(agentSessionIds, session.id, 'AgentSession'),
        sandboxSummary: null,
        configVersion: null,
        environmentPackageSnapshotId: session.environmentPackageSnapshotId
          ? requiredMapValue(
              agentEnvironmentPackageSnapshotIds,
              session.environmentPackageSnapshotId,
              'agent environment package snapshot'
            )
          : null,
        threadId: session.threadId ? requiredMapValue(threadIds, session.threadId, 'thread') : null,
        // The retained native reference stays with the source Sandbox storage and its old id.
        nativeHandleDigest: null,
        retainedStorage: null,
        policySnapshotId: null,
        sessionCompatibilityKey: null,
        stale: true,
        status: 'closed',
        workspaceRoots: [],
        workspaceId: context.targetWorkspaceId,
      }) as AgentSession
  );
  const exportedEvents = readImportJsonl(context.files, 'records/turn-events.jsonl').map((record) =>
    SseEventEnvelopeSchema.parse(record)
  );
  const exportedTurnIds = new Set(exportedTurns.map((turn) => turn.id));
  if (exportedEvents.some((event) => !event.turnId || !exportedTurnIds.has(event.turnId))) {
    throw new Error('Turn event references missing exported turn.');
  }
  const exportedTurnEvents = exportedTurns.map((turn): [string, SseEventEnvelope[]] => [
    turn.id,
    exportedEvents.filter((event) => event.turnId === turn.id),
  ]);
  const importedThreads = new Map(
    exportedThreads.map((record, index) => [record.id, threads[index]!])
  );
  const importedTurns = new Map(exportedTurns.map((record, index) => [record.id, turns[index]!]));
  const importedItems = new Map(
    [...itemIds].map(([sourceId, importedId]) => [sourceId, currentItems.get(importedId) as Item])
  );
  const importedArtifacts = new Map(
    exportedArtifacts.map((record, index) => [record.id, artifacts[index]!])
  );
  const importedAgentSessions = new Map(
    exportedAgentSessions.map((record, index) => [record.id, agentSessions[index]!])
  );
  const turnEvents = exportedTurns.map((turn): [string, SseEventEnvelope[]] => [
    requiredMapValue(turnIds, turn.id, 'turn'),
    exportedEvents
      .filter((event) => event.turnId === turn.id)
      .map((event) =>
        rewritePortableTurnEvent(event, {
          workspace,
          threads: importedThreads,
          turns: importedTurns,
          items: importedItems,
          artifacts: importedArtifacts,
          agentSessions: importedAgentSessions,
          approvalRequestIds,
        })
      ),
  ]);
  const exportedKnowledgeSources = readOptionalImportJsonl(
    context.files,
    'records/knowledge-sources.jsonl'
  ).map((record) => {
    const source = KnowledgeSourceRecordSchema.parse(record);
    assertSafeWorkspacePathSegment(source.id, 'Knowledge source id');
    return source;
  });
  const knowledgeSourceIds = allocateImportedEntityIds(
    'ks',
    exportedKnowledgeSources.map((source) => source.id)
  );
  const knowledgeSources = exportedKnowledgeSources.map((parsed) =>
    KnowledgeSourceRecordSchema.parse({
      ...parsed,
      id: requiredMapValue(knowledgeSourceIds, parsed.id, 'Knowledge source'),
      originatingThreadId: parsed.originatingThreadId
        ? requiredMapValue(threadIds, parsed.originatingThreadId, 'thread')
        : null,
      originatingTurnId: parsed.originatingTurnId
        ? requiredMapValue(turnIds, parsed.originatingTurnId, 'turn')
        : null,
      uri: parsed.uri
        ? rewriteWorkspaceReference(
            parsed.uri,
            report.exportedWorkspaceId,
            context.targetWorkspaceId
          )
        : null,
      workspaceId: context.targetWorkspaceId,
    })
  );
  const knowledge = exportedKnowledge;
  parseCanonicalWorkspaceHistory({
    workspace: exportedWorkspace,
    threads: exportedThreads,
    turns: exportedTurns,
    itemRevisions: exportedItemRevisions,
    artifacts: exportedArtifacts,
    knowledgeSources: exportedKnowledgeSources,
    agentSessions: exportedAgentSessions,
    turnEvents: exportedTurnEvents,
  });
  parseCanonicalWorkspaceHistory({
    workspace,
    threads,
    turns,
    itemRevisions,
    artifacts,
    knowledgeSources,
    agentSessions,
    turnEvents,
  });
  const knowledgeSourceMaterials = exportedKnowledgeSources
    .map((source): ExportedKnowledgeSourceMaterial | null => {
      const materialPath = `sources/materials/${source.id}/content.txt`;

      return context.files.has(materialPath)
        ? {
            sourceId: requiredMapValue(knowledgeSourceIds, source.id, 'knowledge source'),
            content: requiredExportFile(context.files, materialPath),
          }
        : null;
    })
    .filter((material): material is ExportedKnowledgeSourceMaterial => material !== null);
  context.threadIds = threadIds;
  context.turnIds = turnIds;
  context.itemIds = itemIds;
  context.itemLineage = itemLineage;
  context.artifactIds = artifactIds;
  context.agentSessionIds = agentSessionIds;
  context.approvalRequestIds = approvalRequestIds;
  context.agentEnvironmentPackageSnapshotIds = agentEnvironmentPackageSnapshotIds;
  context.knowledgeSourceIds = knowledgeSourceIds;
  context.knowledgeIds = new Set(knowledge.map((entry) => entry.id));

  return {
    workspace,
    threads,
    turns,
    knowledge,
    itemRevisions,
    artifacts,
    agentSessions,
    turnEvents,
    knowledgeSources,
    knowledgeSourceMaterials,
    agentEnvironmentPackageSnapshots,
  };
}

/**
 * Reconstructs portable security, audit, capability, evidence, usage, and runtime ledgers.
 *
 * @param context Shared import lineage and verified bytes.
 * @returns Imported security and runtime ledger records.
 * @throws Error when a ledger record references missing exported state.
 */
function readSecurityRuntimeLedgerState(context: ImportRemintContext) {
  const {
    agentEnvironmentPackageSnapshotIds,
    agentSessionIds,
    approvalRequestIds,
    evidenceBundleIds,

    itemIds,
    report,
    threadIds,
    turnIds,
    workerCheckpointIds,
  } = context;
  const exportedVaultReferences = readOptionalImportJsonl(
    context.files,
    'records/vault-references.jsonl'
  ).map((record) => ExportedWorkspaceVaultReferenceSchema.parse(record));
  const vaultReferenceIds = allocateImportedEntityIds(
    'vault',
    exportedVaultReferences.map((reference) => reference.sourceReferenceId)
  );
  const vaultReferences = exportedVaultReferences.map((parsed) =>
    ImportedWorkspaceVaultReferenceSchema.parse({
      ...parsed,
      referenceId: requiredMapValue(vaultReferenceIds, parsed.sourceReferenceId, 'Vault reference'),
      ownerScope: 'workspace',
      workspaceId: context.targetWorkspaceId,
      backendLocator: null,
      status: 'unbound',
      currentVersion: 0,
      createdAt: report.manifest.exportCreatedAt,
      updatedAt: report.manifest.exportCreatedAt,
    })
  );
  const exportedVaultGrants = readOptionalImportJsonl(
    context.files,
    'records/vault-grants.jsonl'
  ).map((record) => ExportedVaultGrantSchema.parse(record));
  const vaultGrantIds = allocateImportedEntityIds(
    'grant',
    exportedVaultGrants.map((grant) => grant.grantId)
  );
  const vaultGrants = exportedVaultGrants.map((grant) =>
    ExportedVaultGrantSchema.parse({
      ...grant,
      issuance: 'imported-history',
      grantId: requiredMapValue(vaultGrantIds, grant.grantId, 'Vault grant'),
      approvalId: grant.approvalId
        ? requiredMapValue(approvalRequestIds, grant.approvalId, 'approval request')
        : null,
      targetAgentSessionId: grant.targetAgentSessionId
        ? requiredMapValue(agentSessionIds, grant.targetAgentSessionId, 'AgentSession')
        : null,
      vaultReferenceId: requiredMapValue(
        vaultReferenceIds,
        grant.vaultReferenceId,
        'vault reference'
      ),
      workspaceId: context.targetWorkspaceId,
    })
  );
  const exportedVaultInjectionPlans = readOptionalImportJsonl(
    context.files,
    'records/vault-injection-plans.jsonl'
  ).map((record) => ExportedVaultInjectionPlanSchema.parse(record));
  const vaultInjectionPlans = exportedVaultInjectionPlans.map((plan, index) => {
    const grantId = vaultGrantIds.get(plan.grantId);
    if (!grantId) {
      throw new Error(`Injection plan references missing exported vault grant: ${plan.grantId}`);
    }

    return ExportedVaultInjectionPlanSchema.parse({
      ...plan,
      planId: `plan_imported_${context.targetWorkspaceId}_${index + 1}`,
      grantId,
      packageSnapshotId: plan.packageSnapshotId
        ? requiredMapValue(
            agentEnvironmentPackageSnapshotIds,
            plan.packageSnapshotId,
            'agent environment package snapshot'
          )
        : null,
    });
  });
  const vaultInjectionPlanIds = new Map(
    exportedVaultInjectionPlans.map((plan, index) => [
      plan.planId,
      vaultInjectionPlans[index]!.planId,
    ])
  );
  const exportedVaultInjectionReceipts = readOptionalImportJsonl(
    context.files,
    'records/vault-injection-receipts.jsonl'
  ).map((record) => ExportedVaultInjectionReceiptSchema.parse(record));
  const vaultInjectionReceipts = exportedVaultInjectionReceipts.map((receipt, index) => {
    const planId = vaultInjectionPlanIds.get(receipt.planId);
    if (!planId) {
      throw new Error(
        `Injection receipt references missing exported injection plan: ${receipt.planId}`
      );
    }

    const grantId = vaultGrantIds.get(receipt.grantId);
    if (!grantId) {
      throw new Error(
        `Injection receipt references missing exported vault grant: ${receipt.grantId}`
      );
    }

    return ExportedVaultInjectionReceiptSchema.parse({
      ...receipt,
      receiptId: `receipt_imported_${context.targetWorkspaceId}_${index + 1}`,
      planId,
      grantId,
      agentSessionId: receipt.agentSessionId
        ? requiredMapValue(agentSessionIds, receipt.agentSessionId, 'AgentSession')
        : null,
    });
  });
  const vaultInjectionReceiptIds = new Map(
    exportedVaultInjectionReceipts.map((receipt, index) => [
      receipt.receiptId,
      vaultInjectionReceipts[index]!.receiptId,
    ])
  );
  const vaultUseRecords = readOptionalImportJsonl(
    context.files,
    'records/vault-use-records.jsonl'
  ).map((record) => {
    const parsed = ExportedVaultUseRecordSchema.parse(record);

    return ExportedVaultUseRecordSchema.parse({
      ...parsed,
      agentSessionId: parsed.agentSessionId
        ? requiredMapValue(agentSessionIds, parsed.agentSessionId, 'AgentSession')
        : null,
      grantId: parsed.grantId
        ? requiredMapValue(vaultGrantIds, parsed.grantId, 'vault grant')
        : null,
      planId: parsed.planId
        ? requiredMapValue(vaultInjectionPlanIds, parsed.planId, 'injection plan')
        : null,
      receiptId: parsed.receiptId
        ? requiredMapValue(vaultInjectionReceiptIds, parsed.receiptId, 'injection receipt')
        : null,
      workspaceId: context.targetWorkspaceId,
      vaultReferenceId: requiredMapValue(
        vaultReferenceIds,
        parsed.vaultReferenceId,
        'vault reference'
      ),
    });
  });
  context.vaultGrantIds = vaultGrantIds;
  const auditEvents = readOptionalImportJsonl(context.files, 'records/audit-events.jsonl').map(
    (record) => {
      const parsed = AuditEventSchema.parse(record);

      return AuditEventSchema.parse({
        ...parsed,
        threadId: parsed.threadId ? requiredMapValue(threadIds, parsed.threadId, 'thread') : null,
        turnId: parsed.turnId ? requiredMapValue(turnIds, parsed.turnId, 'turn') : null,
        itemId: parsed.itemId ? requiredMapValue(itemIds, parsed.itemId, 'item') : null,
        agentSessionId: parsed.agentSessionId
          ? requiredMapValue(agentSessionIds, parsed.agentSessionId, 'AgentSession')
          : null,
        vaultGrantId: parsed.vaultGrantId
          ? requiredMapValue(vaultGrantIds, parsed.vaultGrantId, 'vault grant')
          : null,
        workspaceId: context.targetWorkspaceId,
        resource:
          parsed.resource === `workspace:${report.exportedWorkspaceId}`
            ? `workspace:${context.targetWorkspaceId}`
            : parsed.resource?.startsWith('goal-review:')
              ? `goal-review:${parsed.resource.slice('goal-review:'.length)}`
              : parsed.resource?.startsWith('goal-verification:')
                ? `goal-verification:${parsed.resource.slice('goal-verification:'.length)}`
                : parsed.resource?.startsWith('goal-task:')
                  ? `goal-task:${parsed.resource.slice('goal-task:'.length)}`
                  : parsed.resource?.startsWith('goal:')
                    ? `goal:${parsed.resource.slice('goal:'.length)}`
                    : parsed.resource?.startsWith('worker-checkpoint:')
                      ? `worker-checkpoint:${requiredMapValue(
                          workerCheckpointIds,
                          parsed.resource.slice('worker-checkpoint:'.length),
                          'worker checkpoint'
                        )}`
                      : parsed.resource?.startsWith('vault:') &&
                          vaultReferenceIds.has(parsed.resource.slice('vault:'.length))
                        ? `vault:${requiredMapValue(
                            vaultReferenceIds,
                            parsed.resource.slice('vault:'.length),
                            'vault reference'
                          )}`
                        : parsed.resource,
      });
    }
  );
  const exportedCapabilityCalls = readOptionalImportJsonl(
    context.files,
    'records/capability-calls.jsonl'
  ).map((record) => ExportedCapabilityCallSchema.parse(record));
  const exportedEvidenceBundles = readOptionalImportJsonl(
    context.files,
    'records/evidence-bundles.jsonl'
  ).map((record) => ImportedEvidenceBundleRecordSchema.parse(record));
  const exportedRuntimeEvidence = readOptionalImportJsonl(
    context.files,
    'records/runtime-evidence.jsonl'
  ).map((record) => ImportedRuntimeEvidenceRecordSchema.parse(record));
  if (
    new Set(exportedEvidenceBundles.map((bundle) => bundle.id)).size !==
    exportedEvidenceBundles.length
  ) {
    throw new Error('Duplicate exported evidence bundle identity.');
  }
  const runtimeProvenanceIndexes = new Map<string, string>();
  const provenancePackages = new Map<string, { targetPackageSnapshotId: string; digest: string }>();
  const runtimeOriginRefsByPackageSnapshotId = context.runtimeOriginRefsByPackageSnapshotId;
  for (const bundle of exportedEvidenceBundles) {
    if (bundle.sourceKind !== 'worker-runtime-provenance-index') {
      continue;
    }
    const exportPath = `workspace-files/evidence/bundles/${bundle.id}/runtime-origin-index.jsonl`;
    const sourceText = requiredExportFile(context.files, exportPath);
    const firstLine = sourceText.trim().split('\n')[0];
    if (!firstLine) {
      throw new Error('Runtime provenance index is empty.');
    }
    const firstRow = WorkerRuntimeOriginIndexRowSchema.parse(JSON.parse(firstLine));
    const sourceLineage = firstRow.lineage;
    if (
      bundle.workspaceId !== sourceLineage.workspaceId ||
      bundle.threadId !== sourceLineage.threadId ||
      bundle.turnId !== sourceLineage.turnId ||
      bundle.agentSessionId !== sourceLineage.agentSessionId ||
      bundle.rawEvidenceRefs.length > 0 ||
      bundle.redactedEvidenceRefs.length !== 1 ||
      bundle.redactedEvidenceRefs[0]?.kind !== 'worker-runtime-provenance-index' ||
      bundle.redactedEvidenceRefs[0]?.ref !== 'runtime-origin-index.jsonl' ||
      bundle.contentDigests.length !== 1 ||
      bundle.contentDigests[0] !== digestText(sourceText)
    ) {
      throw new Error(`Runtime provenance index bundle is inconsistent: ${bundle.id}`);
    }
    const targetPackageSnapshotId = requiredMapValue(
      agentEnvironmentPackageSnapshotIds,
      sourceLineage.packageSnapshotId,
      'agent environment package snapshot'
    );
    const targetLineage = {
      workspaceId: context.targetWorkspaceId,
      threadId: requiredMapValue(threadIds, sourceLineage.threadId, 'thread'),
      turnId: requiredMapValue(turnIds, sourceLineage.turnId, 'turn'),
      agentSessionId: requiredMapValue(
        agentSessionIds,
        sourceLineage.agentSessionId,
        'AgentSession'
      ),
      packageSnapshotId: targetPackageSnapshotId,
      requestId: sourceLineage.requestId,
    };
    const reminted = remintWorkerRuntimeProvenanceIndex(sourceText, sourceLineage, targetLineage);
    const targetBundleId = createWorkerRuntimeProvenanceBundleId(
      'worker-runtime-provenance-index',
      targetPackageSnapshotId
    );
    provenancePackages.set(bundle.id, {
      targetPackageSnapshotId,
      digest: reminted.digest,
    });
    runtimeOriginRefsByPackageSnapshotId.set(
      sourceLineage.packageSnapshotId,
      new Map(reminted.runtimeOriginRefs)
    );
    context.completeRuntimeOriginPackages.add(sourceLineage.packageSnapshotId);
    runtimeProvenanceIndexes.set(targetBundleId, reminted.text);
  }
  for (const sourceIndexId of provenancePackages.keys()) {
    const linkedRuntime = exportedRuntimeEvidence.filter((runtime) =>
      runtime.evidenceBundleIds.includes(sourceIndexId)
    );
    const linkedRaw = linkedRuntime.flatMap((runtime) =>
      runtime.evidenceBundleIds.filter(
        (id) =>
          exportedEvidenceBundles.find((bundle) => bundle.id === id)?.sourceKind ===
          'worker-runtime-provenance-raw'
      )
    );
    if (
      linkedRuntime.length !== 1 ||
      linkedRaw.length !== 1 ||
      linkedRuntime[0]?.phase !== 'transcript-collection' ||
      !linkedRuntime[0]?.requiredFeatures.includes('worker.runtime-provenance.v1')
    ) {
      throw new Error('Runtime provenance bundle linkage is incomplete.');
    }
  }
  const capabilityCalls = exportedCapabilityCalls.map((parsed) => {
    const packageSnapshotId = parsed.packageSnapshotId
      ? requiredMapValue(
          agentEnvironmentPackageSnapshotIds,
          parsed.packageSnapshotId,
          'agent environment package snapshot'
        )
      : null;
    const runtimeOriginRef = parsed.runtimeOriginRef
      ? parsed.packageSnapshotId
        ? remintObservedRuntimeOrigin(context, parsed.packageSnapshotId, parsed.runtimeOriginRef)
        : undefined
      : null;
    if (parsed.runtimeOriginRef && !runtimeOriginRef) {
      throw new Error('Runtime origin reference is absent from its package normalized index.');
    }

    return ExportedCapabilityCallSchema.parse({
      ...parsed,
      threadId: parsed.threadId ? requiredMapValue(threadIds, parsed.threadId, 'thread') : null,
      turnId: parsed.turnId ? requiredMapValue(turnIds, parsed.turnId, 'turn') : null,
      itemId: parsed.itemId ? requiredMapValue(itemIds, parsed.itemId, 'item') : null,
      agentSessionId: parsed.agentSessionId
        ? requiredMapValue(agentSessionIds, parsed.agentSessionId, 'AgentSession')
        : null,
      packageSnapshotId,
      runtimeOriginRef,
      runtimeCacheLineageRef: parsed.runtimeCacheLineageRef
        ? `rcl_${createHash('sha256')
            .update(
              `runtime-cache-lineage:${context.targetWorkspaceId}:${parsed.runtimeCacheLineageRef}`
            )
            .digest('hex')
            .slice(0, 24)}`
        : null,
      workspaceId: context.targetWorkspaceId,
    });
  });
  const sourceProvenancePackages = new Map(
    readOptionalImportJsonl(context.files, 'records/agent-environment-package-snapshots.jsonl')
      .map((record) => ExportedAgentEnvironmentPackageSnapshotSchema.parse(record))
      .map((record) => [createWorkerRuntimeProvenanceEvidenceId(record.snapshotId), record])
  );
  const rawProvenancePackageIds = new Map<string, string>();
  const importedEvidenceBundleIds = new Set<string>();
  for (const [index, bundle] of exportedEvidenceBundles.entries()) {
    const indexPackage = provenancePackages.get(bundle.id);
    const pairedIndexId = exportedRuntimeEvidence
      .find((runtime) => runtime.evidenceBundleIds.includes(bundle.id))
      ?.evidenceBundleIds.find((id) => provenancePackages.has(id));
    const pairedPackage = pairedIndexId ? provenancePackages.get(pairedIndexId) : undefined;
    const provenancePackage = indexPackage ?? pairedPackage;
    let targetPackageSnapshotId = provenancePackage?.targetPackageSnapshotId;
    if (bundle.sourceKind === 'worker-runtime-provenance-raw' && !targetPackageSnapshotId) {
      const linked = exportedRuntimeEvidence.filter((record) =>
        record.evidenceBundleIds.includes(bundle.id)
      );
      const runtime = linked[0];
      const sourcePackage = runtime ? sourceProvenancePackages.get(runtime.id) : undefined;
      const sourcePackageSnapshotId = sourcePackage?.snapshotId;
      if (
        linked.length !== 1 ||
        !runtime ||
        !sourcePackageSnapshotId ||
        !sourcePackage ||
        sourcePackage.workspaceId !== bundle.workspaceId ||
        sourcePackage.threadId !== bundle.threadId ||
        sourcePackage.turnId !== bundle.turnId ||
        sourcePackage.agentSessionId !== bundle.agentSessionId ||
        sourcePackage.backendKind !== bundle.backendType ||
        !['quarantined', 'expired'].includes(bundle.importStatus) ||
        runtime.phase !== 'transcript-collection' ||
        !runtime.requiredFeatures.includes('worker.runtime-provenance.v1') ||
        runtime.outcome !== 'failed' ||
        runtime.evidenceBundleIds.length !== 1 ||
        runtime.evidenceBundleIds[0] !== bundle.id ||
        runtime.backendType !== bundle.backendType ||
        JSON.stringify(runtime.contentDigests) !== JSON.stringify(bundle.contentDigests) ||
        runtime.workspaceId !== bundle.workspaceId ||
        runtime.threadId !== bundle.threadId ||
        runtime.turnId !== bundle.turnId ||
        runtime.agentSessionId !== bundle.agentSessionId
      )
        throw new Error('Runtime provenance bundle linkage is incomplete.');
      targetPackageSnapshotId = requiredMapValue(
        agentEnvironmentPackageSnapshotIds,
        sourcePackageSnapshotId,
        'agent environment package snapshot'
      );
    }
    if (
      (bundle.sourceKind === 'worker-runtime-provenance-raw' ||
        bundle.sourceKind === 'worker-runtime-provenance-index') &&
      !targetPackageSnapshotId
    ) {
      throw new Error('Runtime provenance bundle linkage is incomplete.');
    }
    if (bundle.sourceKind === 'worker-runtime-provenance-raw' && targetPackageSnapshotId) {
      rawProvenancePackageIds.set(bundle.id, targetPackageSnapshotId);
    }
    const targetId = targetPackageSnapshotId
      ? createWorkerRuntimeProvenanceBundleId(
          bundle.sourceKind === 'worker-runtime-provenance-raw'
            ? 'worker-runtime-provenance-raw'
            : 'worker-runtime-provenance-index',
          targetPackageSnapshotId
        )
      : `evb_imported_${context.targetWorkspaceId}_${index + 1}`;
    if (importedEvidenceBundleIds.has(targetId)) {
      throw new Error('Runtime provenance bundle linkage aliases another evidence bundle.');
    }
    importedEvidenceBundleIds.add(targetId);
    evidenceBundleIds.set(bundle.id, targetId);
  }
  const evidenceBundles = exportedEvidenceBundles.map((parsed) => {
    const provenancePackage = provenancePackages.get(parsed.id);

    return EvidenceBundleRecordSchema.parse({
      ...parsed,
      id: requiredMapValue(evidenceBundleIds, parsed.id, 'evidence bundle'),
      threadId: parsed.threadId ? requiredMapValue(threadIds, parsed.threadId, 'thread') : null,
      turnId: parsed.turnId ? requiredMapValue(turnIds, parsed.turnId, 'turn') : null,
      goalId: parsed.goalId ? parsed.goalId : null,
      agentSessionId: parsed.agentSessionId
        ? requiredMapValue(agentSessionIds, parsed.agentSessionId, 'AgentSession')
        : null,
      rawEvidenceRefs: rewriteEvidenceRefs(parsed.rawEvidenceRefs, context),
      redactedEvidenceRefs: rewriteEvidenceRefs(parsed.redactedEvidenceRefs, context),
      ...(provenancePackage && parsed.sourceKind === 'worker-runtime-provenance-index'
        ? { contentDigests: [provenancePackage.digest] }
        : {}),
      workspaceId: context.targetWorkspaceId,
    });
  });
  const restrictedEvidenceFiles = new Map<string, Uint8Array>();
  const admittedPaths = new Set<string>();
  for (const bundle of exportedEvidenceBundles) {
    if (!['work-observation-body', 'worker-runtime-provenance-raw'].includes(bundle.sourceKind))
      continue;
    if (bundle.importStatus === 'expired') {
      if (bundle.rawEvidenceRefs.length || bundle.redactedEvidenceRefs.length)
        throw new Error('Expired restricted evidence retains content references.');
      continue;
    }
    if (
      bundle.sourceKind === 'work-observation-body' &&
      (bundle.importStatus !== 'promoted' ||
        bundle.rawEvidenceRefs.length !== 1 ||
        bundle.rawEvidenceRefs[0]?.ref !== 'raw/content' ||
        bundle.contentDigests.length !== 1)
    )
      throw new Error('Portable observation body is not completely published.');
    if (bundle.rawEvidenceRefs.length !== bundle.contentDigests.length)
      throw new Error('Restricted evidence file digest inventory is incomplete.');
    for (const [index, ref] of bundle.rawEvidenceRefs.entries()) {
      assertWorkspaceArchiveFilePath(ref.ref);
      const sourcePath = `workspace-files/evidence/backend/${bundle.id}/${ref.ref}`;
      const bytes = context.binaryFiles.get(sourcePath);
      const expected = bundle.contentDigests[index]!.replace(/^sha256:/, '');
      if (!bytes || createHash('sha256').update(bytes).digest('hex') !== expected)
        throw new Error(`Restricted evidence bytes are missing or invalid: ${sourcePath}`);
      admittedPaths.add(sourcePath);
      const targetId = requiredMapValue(evidenceBundleIds, bundle.id, 'evidence bundle');
      restrictedEvidenceFiles.set(`${targetId}/${ref.ref}`, bytes);
    }
  }
  for (const path of context.binaryFiles.keys()) {
    if (!admittedPaths.has(path))
      throw new Error(`Restricted evidence has no retained owner: ${path}`);
  }
  const runtimeEvidence = exportedRuntimeEvidence.map((parsed) => {
    const sourceIndexId = parsed.evidenceBundleIds.find((id) => provenancePackages.has(id));
    const provenancePackage = sourceIndexId ? provenancePackages.get(sourceIndexId) : undefined;
    const sourceIndexBundle = sourceIndexId
      ? exportedEvidenceBundles.find((bundle) => bundle.id === sourceIndexId)
      : undefined;
    const targetIndexDigest = provenancePackage?.digest;
    const targetProvenancePackageId =
      provenancePackage?.targetPackageSnapshotId ??
      parsed.evidenceBundleIds
        .map((id) => rawProvenancePackageIds.get(id))
        .find((id) => id !== undefined);

    return RuntimeEvidenceRecordSchema.parse({
      ...parsed,
      ...(targetProvenancePackageId
        ? { id: createWorkerRuntimeProvenanceEvidenceId(targetProvenancePackageId) }
        : {}),
      threadId: parsed.threadId ? requiredMapValue(threadIds, parsed.threadId, 'thread') : null,
      turnId: parsed.turnId ? requiredMapValue(turnIds, parsed.turnId, 'turn') : null,
      goalId: parsed.goalId ? parsed.goalId : null,
      taskId: parsed.taskId ? parsed.taskId : null,
      agentSessionId: parsed.agentSessionId
        ? (agentSessionIds.get(parsed.agentSessionId) ?? parsed.agentSessionId)
        : null,
      evidenceBundleIds: parsed.evidenceBundleIds.map((id) =>
        requiredMapValue(evidenceBundleIds, id, 'evidence bundle')
      ),
      contentDigests:
        targetIndexDigest && sourceIndexBundle
          ? parsed.contentDigests.map((digest) =>
              sourceIndexBundle.contentDigests.includes(digest) ? targetIndexDigest : digest
            )
          : parsed.contentDigests,
      workspaceId: context.targetWorkspaceId,
    });
  });
  const usageRecords = readOptionalImportJsonl(context.files, 'records/usage-records.jsonl').map(
    (record) => {
      const parsed = ImportedUsageRecordSchema.parse(record);

      return UsageRecordSchema.parse({
        ...parsed,
        threadId: parsed.threadId ? requiredMapValue(threadIds, parsed.threadId, 'thread') : null,
        turnId: parsed.turnId ? requiredMapValue(turnIds, parsed.turnId, 'turn') : null,
        itemId: parsed.itemId ? requiredMapValue(itemIds, parsed.itemId, 'item') : null,
        agentSessionId: parsed.agentSessionId
          ? requiredMapValue(agentSessionIds, parsed.agentSessionId, 'AgentSession')
          : null,
        workspaceId: context.targetWorkspaceId,
      });
    }
  );
  const dataSourceCatalogPath = 'records/data-sources.json';
  let dataSourceCatalog: WorkspaceDataSourceCatalog | null = null;
  if (context.files.has(dataSourceCatalogPath)) {
    const catalog = parseWorkspaceDataSourceCatalog(
      readImportJson(context.files, dataSourceCatalogPath)
    );
    dataSourceCatalog = parseWorkspaceDataSourceCatalog({
      ...catalog,
      sources: catalog.sources.map((source) => ({
        ...source,
        ...(source.vaultGrantRef
          ? {
              vaultGrantRef: requiredMapValue(vaultGrantIds, source.vaultGrantRef, 'vault grant'),
            }
          : {}),
      })),
    });
  }
  const gitPushRecords = readOptionalImportJsonl(
    context.files,
    'records/git-push-records.jsonl'
  ).map((record) => {
    const parsed = ExportedGitPushRecordSchema.parse(record);

    return ExportedGitPushRecordSchema.parse({
      ...parsed,
      approvalRowId: parsed.approvalRowId
        ? requiredMapValue(approvalRequestIds, parsed.approvalRowId, 'approval request')
        : null,
      workspaceId: context.targetWorkspaceId,
    });
  });
  const resolvedAgentSetups = readOptionalImportJsonl(
    context.files,
    'records/resolved-agent-setups.jsonl'
  ).map((record) => {
    const parsed = ExportedResolvedAgentSetupSchema.parse(record);

    return {
      id: parsed.id,
      workspaceId: context.targetWorkspaceId,
      turnId: parsed.turnId ? requiredMapValue(turnIds, parsed.turnId, 'turn') : null,
      requestId: parsed.requestId,
      agentId: parsed.agentId,
      logicalModelId: parsed.logicalModelId,
      runtimeKind: parsed.runtimeKind,
      runtimeAdapter: parsed.runtimeAdapter,
      requiredFeatures: parsed.setupRequiredFeatures,
      setup: parsed.setup,
      createdAt: parsed.createdAt,
    } as ExportedResolvedAgentSetup;
  });
  const permissionDecisions = readOptionalImportJsonl(
    context.files,
    'records/permission-decisions.jsonl'
  ).map((record) => {
    const parsed = ExportedWorkspacePermissionDecisionSchema.parse(record);

    return ExportedWorkspacePermissionDecisionSchema.parse({
      ...parsed,
      approvalId: parsed.approvalId
        ? requiredMapValue(approvalRequestIds, parsed.approvalId, 'approval request')
        : null,
      contextSummary: rewriteWorkspaceIdField(
        parsed.contextSummary,
        report.exportedWorkspaceId,
        context.targetWorkspaceId
      ),
      resourceSummary: rewriteWorkspaceIdField(
        parsed.resourceSummary,
        report.exportedWorkspaceId,
        context.targetWorkspaceId
      ),
      subjectSummary: rewriteWorkspaceIdField(
        parsed.subjectSummary,
        report.exportedWorkspaceId,
        context.targetWorkspaceId
      ),
      workspaceId: context.targetWorkspaceId,
    });
  });

  return {
    vaultReferences,
    vaultGrants,
    vaultInjectionPlans,
    vaultInjectionReceipts,
    vaultUseRecords,
    auditEvents,
    capabilityCalls,
    evidenceBundles,
    runtimeEvidence,
    runtimeProvenanceIndexes,
    restrictedEvidenceFiles,
    usageRecords,
    dataSourceCatalog,
    gitPushRecords,
    resolvedAgentSetups,
    permissionDecisions,
  };
}

/**
 * Reconstructs portable repository and workspace synchronization records.
 *
 * @param context Shared import lineage and verified bytes.
 * @returns Imported repository and workspace synchronization records.
 * @throws Error when a synchronization record references missing exported state.
 */
function readWorkspaceSyncImportState(context: ImportRemintContext) {
  const { artifactIds, evidenceBundleIds, report, vaultGrantIds } = context;
  const workspaceRepositories = readOptionalImportJsonl(
    context.files,
    'records/workspace-repositories.jsonl'
  ).map((record) => {
    const parsed = ExportedWorkspaceRepositoryResourceSchema.parse(record);
    return ExportedWorkspaceRepositoryResourceSchema.parse({
      ...parsed,
      git: {
        ...parsed.git,
        vaultGrantRef: parsed.git.vaultGrantRef
          ? requiredMapValue(vaultGrantIds, parsed.git.vaultGrantRef, 'vault grant')
          : null,
      },
    });
  });
  const workspaceInputSnapshots = readOptionalImportJsonl(
    context.files,
    'records/workspace-input-snapshots.jsonl'
  ).map((record) => {
    const parsed = WorkspaceInputSnapshotReaderSchema.parse(record);

    return WorkspaceInputSnapshotSchema.parse({
      ...parsed,
      workspaceId: context.targetWorkspaceId,
    });
  });
  const workspaceMaterializationRecords = readOptionalImportJsonl(
    context.files,
    'records/workspace-materialization-records.jsonl'
  ).map((record) => {
    const parsed = WorkspaceMaterializationRecordReaderSchema.parse(record);

    return WorkspaceMaterializationRecordSchema.parse({
      ...parsed,
      packageSnapshotId: requiredMapValue(
        context.agentEnvironmentPackageSnapshotIds,
        parsed.packageSnapshotId,
        'agent environment package snapshot'
      ),
      materializedRootRef: rewriteWorkspaceReference(
        parsed.materializedRootRef,
        report.exportedWorkspaceId,
        context.targetWorkspaceId
      ),
      workspaceId: context.targetWorkspaceId,
    });
  });
  const backendWorkspaceHandles = readOptionalImportJsonl(
    context.files,
    'records/backend-workspace-handles.jsonl'
  ).map((record) => {
    const parsed = BackendWorkspaceHandleReaderSchema.parse(record);

    return BackendWorkspaceHandleSchema.parse({
      ...parsed,
      packageSnapshotId: requiredMapValue(
        context.agentEnvironmentPackageSnapshotIds,
        parsed.packageSnapshotId,
        'agent environment package snapshot'
      ),
      transportRefs: parsed.transportRefs.map((transportRef) => ({
        ...transportRef,
        ref: rewriteWorkspaceReference(
          transportRef.ref,
          report.exportedWorkspaceId,
          context.targetWorkspaceId
        ),
      })),
      workspaceId: context.targetWorkspaceId,
    });
  });
  const workerOutputManifests = readOptionalImportJsonl(
    context.files,
    'records/worker-output-manifests.jsonl'
  ).map((record) => {
    const parsed = WorkerOutputManifestReaderSchema.parse(record);

    return WorkerOutputManifestSchema.parse({
      ...parsed,
      artifactIds: parsed.artifactIds.map((artifactId) =>
        requiredMapValue(artifactIds, artifactId, 'artifact')
      ),
      evidenceRefs: rewriteEvidenceRefs(parsed.evidenceRefs, context),
      workspaceId: context.targetWorkspaceId,
    });
  });
  const workspaceChangeSets = readOptionalImportJsonl(
    context.files,
    'records/workspace-change-sets.jsonl'
  ).map((record) => {
    const parsed = WorkspaceChangeSetReaderSchema.parse(record);

    return WorkspaceChangeSetSchema.parse({
      ...parsed,
      artifactIds: parsed.artifactIds.map((artifactId) =>
        requiredMapValue(artifactIds, artifactId, 'artifact')
      ),
      evidenceRefs: rewriteEvidenceRefs(parsed.evidenceRefs, context),
      workspaceId: context.targetWorkspaceId,
    });
  });
  const stagedWorkspaceReviews = readOptionalImportJsonl(
    context.files,
    'records/staged-workspace-reviews.jsonl'
  ).map((record) => {
    const parsed = ExportedStagedWorkspaceReviewReaderSchema.parse(record);

    return ExportedStagedWorkspaceReviewSchema.parse({
      ...parsed,
      artifactId: requiredMapValue(artifactIds, parsed.artifactId, 'artifact'),
      review: {
        ...parsed.review,
        staging: {
          ...parsed.review.staging,
          ref: rewriteWorkspaceReference(
            parsed.review.staging.ref,
            report.exportedWorkspaceId,
            context.targetWorkspaceId
          ),
        },
        workspaceId: context.targetWorkspaceId,
      },
    });
  });
  const workspaceApplyResults = readOptionalImportJsonl(
    context.files,
    'records/workspace-apply-results.jsonl'
  ).map((record) => {
    const parsed = ExportedWorkspaceApplyResultReaderSchema.parse(record);

    return ExportedWorkspaceApplyResultSchema.parse({
      ...parsed,
      workspaceId: context.targetWorkspaceId,
    });
  });
  const workspaceApplyPlans = readOptionalImportJsonl(
    context.files,
    'records/workspace-apply-plans.jsonl'
  ).map((record) => {
    const parsed = WorkspaceApplyPlanSchema.parse(record);

    return WorkspaceApplyPlanSchema.parse({
      ...parsed,
      workspaceId: context.targetWorkspaceId,
    });
  });
  const workspaceReconciliationRecords = readOptionalImportJsonl(
    context.files,
    'records/workspace-reconciliation-records.jsonl'
  ).map((record) => {
    const parsed = WorkspaceReconciliationRecordReaderSchema.parse(record);

    return WorkspaceReconciliationRecordSchema.parse({
      ...parsed,
      evidenceBundleIds: parsed.evidenceBundleIds.map((id) =>
        requiredMapValue(evidenceBundleIds, id, 'evidence bundle')
      ),
      workspaceId: context.targetWorkspaceId,
    });
  });
  const workspaceQuarantineRecords = readOptionalImportJsonl(
    context.files,
    'records/workspace-quarantine-records.jsonl'
  ).map((record) => {
    const parsed = WorkspaceQuarantineRecordSchema.parse(record);

    return WorkspaceQuarantineRecordSchema.parse({
      ...parsed,
      workspaceId: context.targetWorkspaceId,
    });
  });
  return {
    workspaceRepositories,
    workspaceInputSnapshots,
    workspaceMaterializationRecords,
    backendWorkspaceHandles,
    workerOutputManifests,
    workspaceChangeSets,
    stagedWorkspaceReviews,
    workspaceApplyPlans,
    workspaceApplyResults,
    workspaceReconciliationRecords,
    workspaceQuarantineRecords,
  };
}

/**
 * Reconstructs the accepted Material, Review, and worker Context Package import graph.
 *
 * @param context Shared import lineage and verified export bytes.
 * @param canonical Reminted canonical workspace history.
 * @param workspaceSync Reminted Workspace Sync owners referenced by work-resource records.
 * @returns Reminted work-resource rows, canonical snapshots, and portable Context Package files.
 * @throws Error when source lineage is incomplete, ambiguous, or contradictory.
 */
function readWorkResourceImportState(
  context: ImportRemintContext,
  canonical: ReturnType<typeof readCanonicalImportState>,
  workspaceSync: ReturnType<typeof readWorkspaceSyncImportState>,
  retrievalTraces: ImportedRetrievalTraceState
) {
  assertMaterialGraph(
    context.sourceWorkspaceMaterials,
    context.sourceWorkspaceMaterialRevisions,
    context.sourceThreadMaterialBindings,
    context.report.exportedWorkspaceId,
    new Set(context.threadIds.keys())
  );
  const workspaceMaterials = context.sourceWorkspaceMaterials.map((material) =>
    ImportedWorkspaceMaterialSchema.parse({
      ...material,
      workspaceId: context.targetWorkspaceId,
      materialId: requiredMapValue(context.materialIds, material.materialId, 'Material'),
      currentRevisionId: material.currentRevisionId
        ? requiredMaterialRevisionId(context, material.materialId, material.currentRevisionId)
        : null,
      lastMutationRequestId: importRequestLineage(context, material.lastMutationRequestId),
    })
  );
  const workspaceMaterialRevisions = context.sourceWorkspaceMaterialRevisions.map((revision) =>
    ImportedWorkspaceMaterialRevisionSchema.parse({
      ...revision,
      workspaceId: context.targetWorkspaceId,
      materialId: requiredMapValue(context.materialIds, revision.materialId, 'Material'),
      revisionId: requiredMaterialRevisionId(context, revision.materialId, revision.revisionId),
      parentRevisionId: revision.parentRevisionId
        ? requiredMaterialRevisionId(context, revision.materialId, revision.parentRevisionId)
        : null,
      createdByRequestId: importRequestLineage(context, revision.createdByRequestId),
    })
  );
  const threadMaterialBindings = context.sourceThreadMaterialBindings.map((binding) =>
    ImportedThreadMaterialBindingSchema.parse({
      ...binding,
      workspaceId: context.targetWorkspaceId,
      threadId: requiredMapValue(context.threadIds, binding.threadId, 'thread'),
      materialId: requiredMapValue(context.materialIds, binding.materialId, 'Material'),
      latestQueuedRevisionId: binding.latestQueuedRevisionId
        ? requiredMaterialRevisionId(context, binding.materialId, binding.latestQueuedRevisionId)
        : null,
      lastMutationRequestId: importRequestLineage(context, binding.lastMutationRequestId),
    })
  );
  assertMaterialGraph(
    workspaceMaterials,
    workspaceMaterialRevisions,
    threadMaterialBindings,
    context.targetWorkspaceId,
    new Set(canonical.threads.map((thread) => thread.id))
  );
  const itemText = new Map<string, string>();
  const threadPreviewText = new Map<string, string>();
  const tracesBySourceTurn = new Map<string, WorkerContextPackageTrace>();
  const workerContextPackageFiles = new Map<string, string>();
  const agentEnvironmentPackageSnapshots = [...canonical.agentEnvironmentPackageSnapshots];
  const workspaceInputSnapshots = [...workspaceSync.workspaceInputSnapshots];
  const workspaceMaterializationRecords = [...workspaceSync.workspaceMaterializationRecords];
  const tracePaths = [...context.files.keys()]
    .map(
      (path) =>
        [
          path,
          /^workspace-files\/threads\/([^/]+)\/turns\/([^/]+)\/context-package\.json$/.exec(path),
        ] as const
    )
    .filter((entry): entry is readonly [string, RegExpExecArray] => entry[1] !== null)
    .sort(([left], [right]) => left.localeCompare(right));
  const tracedTurnIds = new Set(tracePaths.map(([, match]) => match[2]!));
  for (const [sourceTurnId, targetTurnId] of context.turnIds) {
    const turn = canonical.turns.find((candidate) => candidate.id === targetTurnId)!;
    if ((turn.agentSessionId != null) !== tracedTurnIds.has(sourceTurnId)) {
      throw new Error(`Worker Context Package coverage is incomplete: ${sourceTurnId}`);
    }
  }
  for (const [tracePath, pathMatch] of tracePaths) {
    const sourceThreadId = pathMatch[1]!;
    const sourceTurnId = pathMatch[2]!;
    const sourceTrace = parseWorkerContextPackageTrace(
      JSON.parse(requiredExportFile(context.files, tracePath))
    );
    if (
      sourceTrace.workspaceId !== context.report.exportedWorkspaceId ||
      sourceTrace.threadId !== sourceThreadId ||
      sourceTrace.turnId !== sourceTurnId
    ) {
      throw new Error('Worker Context Package trace path lineage is contradictory.');
    }
    const sourceRetrievalReference = sourceTrace.knowledgeSelectionInput?.retrievalTraceRef ?? null;
    const targetRetrievalReference = sourceRetrievalReference
      ? requiredMapValue(
          retrievalTraces.references,
          retrievalTraceReferenceKey(sourceRetrievalReference),
          'Knowledge retrieval trace reference'
        )
      : null;
    const targetSelectedPages = sourceRetrievalReference
      ? requiredMapValue(
          retrievalTraces.selectedPages,
          retrievalTraceReferenceKey(sourceRetrievalReference),
          'Knowledge retrieval trace selection'
        )
      : new Map<string, ImportedRetrievalSelectedPage>();
    const sourceRequestItem = requiredMapValue(
      context.itemLineage,
      sourceTrace.workerRequestItemId,
      'worker request Item'
    );
    if (sourceRequestItem.type !== 'user-message') {
      throw new Error('Worker Context Package request Item has no canonical text.');
    }
    const sourcePackageRoot = `workspace-files/threads/${sourceThreadId}/turns/${sourceTurnId}/context-package`;
    const sourceManifestText = requiredExportFile(
      context.files,
      `${sourcePackageRoot}/package.json`
    );
    const originalManifest = JSON.parse(sourceManifestText);
    const sourceManifest = WorkerContextPackageManifestSchema.parse(originalManifest);
    if (canonicalJson(originalManifest) !== sourceManifestText) {
      throw new Error('Worker Context Package source manifest is not canonical.');
    }
    const knowledgeSelections = sourceTrace.knowledgeSelections.map((selection) => ({
      content: requiredExportFile(context.files, `${sourcePackageRoot}/${selection.packagePath}`),
      contentDigest: selection.contentDigest,
      knowledgePageId: selection.knowledgePageId,
      sourceRefs: selection.sourceRefs,
    }));
    const targetKnowledgeSelections = sourceTrace.knowledgeSelections.map((selection) => {
      const target = requiredMapValue(
        targetSelectedPages,
        selection.knowledgePageId,
        'Knowledge retrieval selection page'
      );
      if (
        target.sourceContentDigest !== selection.contentDigest ||
        !isDeepStrictEqual(target.sourceReferences, selection.sourceRefs)
      ) {
        throw new Error(
          'Worker Context Package Knowledge selection contradicts its retrieval trace.'
        );
      }
      return {
        content: target.content,
        contentDigest: target.contentDigest,
        knowledgePageId: selection.knowledgePageId,
        sourceRefs: target.targetSourceReferences,
      };
    });
    const sourcePackage = createWorkerContextPackageFiles({
      contextBudgetTokens: sourceManifest.contextBudgetTokens,
      includedItemIds: sourceTrace.includedItemIds,
      knowledgeSelections,
      materialSelections: sourceTrace.materialSelections.map((selection) => {
        const revision = requireMaterialRevision(
          context.sourceWorkspaceMaterialRevisions,
          selection.materialId,
          selection.revisionId
        );
        const material = requireMaterial(context.sourceWorkspaceMaterials, selection.materialId);
        return { ...selection, content: revision.content, sensitivity: material.sensitivity };
      }),
      threadId: sourceThreadId,
      turnId: sourceTurnId,
      workerRequestBytes: sourceRequestItem.text,
      workerRequestItemId: sourceTrace.workerRequestItemId,
      workspaceId: context.report.exportedWorkspaceId,
    });
    // Source annotations stay digest attributable; compare the generated package only through known facts.
    const expectedManifest = WorkerContextPackageManifestSchema.parse(
      JSON.parse(
        Buffer.from(
          sourcePackage.files.find((file) => file.path === 'package.json')!.bytes
        ).toString('utf8')
      )
    );
    // The source manifest entry covers its original bytes, not the annotation-free target projection.
    const originalInventory = sourcePackage.fileInventory.map((entry) =>
      entry.path === 'package.json'
        ? {
            ...entry,
            byteLength: Buffer.byteLength(sourceManifestText),
            contentDigest: `sha256:${createHash('sha256').update(sourceManifestText).digest('hex')}`,
          }
        : entry
    );
    if (
      !isDeepStrictEqual(sourceManifest, expectedManifest) ||
      !isDeepStrictEqual(sourceTrace.fileInventory, originalInventory)
    ) {
      throw new Error('Worker Context Package source manifest or inventory is contradictory.');
    }
    const rebuiltSourceTrace = createWorkerContextPackageTrace({
      agentSessionId: sourceTrace.agentSessionId,
      excludedItems: sourceTrace.excludedItems,
      goalId: sourceTrace.goalId,
      knowledgeExclusions: sourceTrace.knowledgeExclusions,
      knowledgeSelectionInput: sourceTrace.knowledgeSelectionInput,
      materialExclusions: sourceTrace.materialExclusions,
      packageFiles: { ...sourcePackage, fileInventory: originalInventory },
      packageSnapshotId: sourceTrace.packageSnapshotId,
      requestId: sourceTrace.requestId,
      taskId: sourceTrace.taskId,
    });
    const { contextPackageDigest: _sourceDigest, ...sourceCore } = sourceTrace;
    const { contextPackageDigest: _rebuiltDigest, ...rebuiltCore } = rebuiltSourceTrace;
    if (
      !isDeepStrictEqual(sourceCore, rebuiltCore) ||
      serializeWorkerContextPackageTrace(sourceTrace) !==
        requiredExportFile(context.files, tracePath)
    ) {
      throw new Error('Worker Context Package source trace is contradictory.');
    }
    const sourcePackagePaths = new Set<string>();
    for (const file of sourcePackage.files) {
      const path = `${sourcePackageRoot}/${file.path}`;
      sourcePackagePaths.add(path);
      if (
        file.path !== 'package.json' &&
        requiredExportFile(context.files, path) !== Buffer.from(file.bytes).toString('utf8')
      ) {
        throw new Error(`Worker Context Package source bytes are contradictory: ${file.path}`);
      }
    }
    const unexpectedSourceFile = [...context.files.keys()].find(
      (path) => path.startsWith(`${sourcePackageRoot}/`) && !sourcePackagePaths.has(path)
    );
    if (unexpectedSourceFile) {
      throw new Error(
        `Worker Context Package contains an unexpected file: ${unexpectedSourceFile}`
      );
    }

    const targetThreadId = requiredMapValue(context.threadIds, sourceThreadId, 'thread');
    const targetTurnId = requiredMapValue(context.turnIds, sourceTurnId, 'turn');
    const targetTurn = canonical.turns.find((turn) => turn.id === targetTurnId)!;
    const targetRequestItemId = requiredMapValue(
      context.itemIds,
      sourceTrace.workerRequestItemId,
      'worker request Item'
    );
    const targetRequestBytes = remintWorkerRequest(sourceRequestItem.text, context);
    itemText.set(targetRequestItemId, targetRequestBytes);
    const targetThread = canonical.threads.find((thread) => thread.id === targetThreadId)!;
    if (targetThread.preview === sourceRequestItem.text) {
      threadPreviewText.set(targetThreadId, targetRequestBytes);
    }
    const targetPackage = createWorkerContextPackageFiles({
      contextBudgetTokens: sourceManifest.contextBudgetTokens,
      includedItemIds: sourceTrace.includedItemIds.map((id) =>
        requiredMapValue(context.itemIds, id, 'included Item')
      ),
      knowledgeSelections: targetKnowledgeSelections,
      materialSelections: sourceTrace.materialSelections.map((selection) => {
        const sourceRevision = requireMaterialRevision(
          context.sourceWorkspaceMaterialRevisions,
          selection.materialId,
          selection.revisionId
        );
        const sourceMaterial = requireMaterial(
          context.sourceWorkspaceMaterials,
          selection.materialId
        );
        return {
          ...selection,
          materialId: requiredMapValue(context.materialIds, selection.materialId, 'Material'),
          revisionId: requiredMaterialRevisionId(
            context,
            selection.materialId,
            selection.revisionId
          ),
          parentRevisionId: selection.parentRevisionId
            ? requiredMaterialRevisionId(context, selection.materialId, selection.parentRevisionId)
            : null,
          bindingMutationRequestId: selection.bindingMutationRequestId
            ? importRequestLineage(context, selection.bindingMutationRequestId)
            : null,
          content: sourceRevision.content,
          sensitivity: sourceMaterial.sensitivity,
        };
      }),
      threadId: targetThreadId,
      turnId: targetTurnId,
      workerRequestBytes: targetRequestBytes,
      workerRequestItemId: targetRequestItemId,
      workspaceId: context.targetWorkspaceId,
    });
    const targetPackageSnapshotId = requiredMapValue(
      context.agentEnvironmentPackageSnapshotIds,
      sourceTrace.packageSnapshotId,
      'agent environment package snapshot'
    );
    const targetTrace = createWorkerContextPackageTrace({
      agentSessionId: requiredMapValue(
        context.agentSessionIds,
        sourceTrace.agentSessionId,
        'AgentSession'
      ),
      excludedItems: sourceTrace.excludedItems.map((exclusion) => ({
        ...exclusion,
        itemId: requiredMapValue(context.itemIds, exclusion.itemId, 'excluded Item'),
      })),
      goalId: sourceTrace.goalId ? sourceTrace.goalId : null,
      knowledgeExclusions: sourceTrace.knowledgeExclusions.map((exclusion) => {
        const target = requiredMapValue(
          targetSelectedPages,
          exclusion.knowledgePageId,
          'Knowledge retrieval exclusion page'
        );
        if (target.sourceContentDigest !== exclusion.contentDigest) {
          throw new Error(
            'Worker Context Package Knowledge exclusion contradicts its retrieval trace.'
          );
        }
        return { ...exclusion, contentDigest: target.contentDigest };
      }),
      knowledgeSelectionInput: targetRetrievalReference
        ? { retrievalTraceRef: targetRetrievalReference }
        : null,
      materialExclusions: sourceTrace.materialExclusions.map((exclusion) => ({
        ...exclusion,
        materialId: requiredMapValue(context.materialIds, exclusion.materialId, 'Material'),
        revisionId: requiredMaterialRevisionId(context, exclusion.materialId, exclusion.revisionId),
      })),
      packageFiles: targetPackage,
      packageSnapshotId: targetPackageSnapshotId,
      requestId: importRequestLineage(context, sourceTrace.requestId),
      taskId: sourceTrace.taskId ? sourceTrace.taskId : null,
    });
    context.contextPackageReferences.set(
      `context-package:${sourceTurnId}@${sourceTrace.contextPackageDigest}`,
      `context-package:${targetTurnId}@${targetTrace.contextPackageDigest}`
    );
    const targetRoot = `threads/${targetThreadId}/turns/${targetTurnId}`;
    for (const file of targetPackage.files) {
      workerContextPackageFiles.set(
        `${targetRoot}/context-package/${file.path}`,
        Buffer.from(file.bytes).toString('utf8')
      );
    }
    workerContextPackageFiles.set(
      `${targetRoot}/context-package.json`,
      serializeWorkerContextPackageTrace(targetTrace)
    );
    tracesBySourceTurn.set(sourceTurnId, sourceTrace);

    const packageIndex = agentEnvironmentPackageSnapshots.findIndex(
      (record) => record.snapshotId === targetPackageSnapshotId
    );
    if (packageIndex < 0) {
      throw new Error('Worker Context Package AEP snapshot is missing.');
    }
    const record = agentEnvironmentPackageSnapshots[packageIndex]!;
    const environmentPackage = RetainedAgentEnvironmentPackageSchema.parse(record.snapshot);
    const rewrittenEnvironmentPackage = AgentEnvironmentPackageSchema.parse({
      ...environmentPackage,
      scope: {
        ...environmentPackage.scope,
        requestId: targetTrace.requestId,
        itemId: targetRequestItemId,
      },
      workspace: {
        ...environmentPackage.workspace,
        inputs: environmentPackage.workspace.inputs.map((candidate) =>
          candidate.materialization?.slotId === 'context'
            ? buildWorkerContextPackageWorkspaceInput({
                agentSessionId: targetTrace.agentSessionId,
                packageRootDigest: targetPackage.packageRootDigest,
                threadId: targetThreadId,
                turnId: targetTurnId,
              })
            : candidate
        ),
      },
    });
    agentEnvironmentPackageSnapshots[packageIndex] = {
      ...record,
      contentDigest: createHash('sha256')
        .update(JSON.stringify(rewrittenEnvironmentPackage))
        .digest('hex'),
      snapshot: rewrittenEnvironmentPackage,
    };

    const sourceInputIndex = workspaceInputSnapshots.findIndex(
      (snapshot) => snapshot.id === sourceTrace.workspaceInputSnapshotId
    );
    const sourceMaterializationIndex = workspaceMaterializationRecords.findIndex(
      (materialization) => materialization.id === sourceTrace.workspaceMaterializationRecordId
    );
    if (sourceInputIndex < 0 || sourceMaterializationIndex < 0) {
      throw new Error('Worker Context Package workspace handoff owner is missing.');
    }
    const sourceInput = workspaceInputSnapshots[sourceInputIndex]!;
    const sourceMaterialization = workspaceMaterializationRecords[sourceMaterializationIndex]!;
    const historicalWorkerSessionId = `import-history-worker_${targetPackageSnapshotId}`;
    workspaceInputSnapshots[sourceInputIndex] = WorkspaceInputSnapshotSchema.parse({
      backend: sourceInput.backend,
      base: { commit: null, contentDigest: targetPackage.packageRootDigest },
      createdAt: targetTurn.startedAt,
      generatedFiles: [],
      id: targetTrace.workspaceInputSnapshotId,
      ignoredPaths: [],
      pathScope: [`context_${targetTurnId}`],
      resourceId: `context_${targetTurnId}`,
      resourceKind: 'filesystem',
      strategy: 'filesystem',
      workspaceId: context.targetWorkspaceId,
      writableRoots: [],
    });
    workspaceMaterializationRecords[sourceMaterializationIndex] =
      WorkspaceMaterializationRecordSchema.parse({
        backendKind: sourceMaterialization.backendKind,
        base: { commit: null, contentDigest: targetPackage.packageRootDigest },
        createdAt: targetTurn.startedAt,
        id: targetTrace.workspaceMaterializationRecordId,
        inputSnapshotId: targetTrace.workspaceInputSnapshotId,
        materializedRootRef: workerSessionInputPaths(targetTrace.agentSessionId).contextRoot,
        packageSnapshotId: targetPackageSnapshotId,
        policyDigest: createWorkerContextPackagePolicyDigest({
          backendKind: sourceMaterialization.backendKind,
          packageSnapshotId: targetPackageSnapshotId,
          requiredCapabilities: rewrittenEnvironmentPackage.backend.requiredCapabilities,
        }),
        readinessEvidence: sourceMaterialization.readinessEvidence.map((entry) =>
          entry.kind.startsWith('sandbox.') && entry.ref === sourceMaterialization.workerSessionId
            ? { ...entry, ref: historicalWorkerSessionId }
            : entry
        ),
        strategy: 'filesystem',
        workerSessionId: historicalWorkerSessionId,
        workspaceId: context.targetWorkspaceId,
      });
  }
  const orphanWorkerFile = [...context.files.keys()].find(
    (path) =>
      path.startsWith('workspace-files/threads/') &&
      !/^workspace-files\/threads\/[^/]+\/turns\/[^/]+\/observations\.jsonl$/.test(path) &&
      !/^workspace-files\/threads\/[^/]+\/(?:turns\/[^/]+\/)?retrieval-traces\/[^/]+\.json$/.test(
        path
      ) &&
      !tracePaths.some(([tracePath]) => path.startsWith(tracePath.slice(0, -'.json'.length)))
  );
  if (orphanWorkerFile) {
    throw new Error(`Worker Context Package file has no trace: ${orphanWorkerFile}`);
  }

  const threads = canonical.threads.map((thread) => {
    const preview = threadPreviewText.get(thread.id);
    return preview === undefined ? thread : ThreadSchema.parse({ ...thread, preview });
  });
  const itemRevisions = canonical.itemRevisions.map((item) =>
    itemText.has(item.id) ? ItemSchema.parse({ ...item, text: itemText.get(item.id) }) : item
  );
  const currentItems = new Map<string, Item>();
  itemRevisions.forEach((item) => {
    currentItems.set(item.id, item);
  });
  const turns = canonical.turns.map((turn) =>
    TurnSchema.parse({
      ...turn,
      items: turn.items.map((item) => requiredMapValue(currentItems, item.id, 'Item')),
    })
  );
  const turnEvents = refreshImportedTurnEventSnapshots(
    canonical.turnEvents,
    threads,
    currentItems,
    turns
  );
  const artifactReviews = context.sourceArtifactReviews.map((review) => {
    if (
      review.workspaceId !== context.report.exportedWorkspaceId ||
      review.reviewId !==
        deriveArtifactReviewId(review.workspaceId, review.artifactId, review.artifactVersion)
    ) {
      throw new Error('Artifact Review source identity is contradictory.');
    }
    const artifactId = requiredMapValue(context.artifactIds, review.artifactId, 'artifact');
    const materialProposal = review.materialProposal
      ? {
          materialId: requiredMapValue(
            context.materialIds,
            review.materialProposal.materialId,
            'Material'
          ),
          baseRevisionId: requiredMaterialRevisionId(
            context,
            review.materialProposal.materialId,
            review.materialProposal.baseRevisionId
          ),
          baseContentDigest: review.materialProposal.baseContentDigest,
        }
      : null;
    const imported = ImportedArtifactReviewSchema.parse({
      ...review,
      workspaceId: context.targetWorkspaceId,
      reviewId: deriveArtifactReviewId(
        context.targetWorkspaceId,
        artifactId,
        review.artifactVersion
      ),
      artifactId,
      sourceThreadId: review.sourceThreadId
        ? requiredMapValue(context.threadIds, review.sourceThreadId, 'thread')
        : null,
      sourceTurnId: review.sourceTurnId
        ? requiredMapValue(context.turnIds, review.sourceTurnId, 'turn')
        : null,
      materialProposal,
      decisionRequestId: review.decisionRequestId
        ? importRequestLineage(context, review.decisionRequestId)
        : null,
      followUpTurnId: review.followUpTurnId
        ? requiredMapValue(context.turnIds, review.followUpTurnId, 'follow-up turn')
        : null,
      appliedMaterialRevisionId:
        review.appliedMaterialRevisionId && review.materialProposal
          ? requiredMaterialRevisionId(
              context,
              review.materialProposal.materialId,
              review.appliedMaterialRevisionId
            )
          : review.appliedMaterialRevisionId,
    });
    assertArtifactReviewImport(
      review,
      imported,
      canonical.artifacts,
      turns,
      workspaceMaterialRevisions,
      workspaceMaterials,
      workspaceSync.stagedWorkspaceReviews,
      tracesBySourceTurn,
      context.itemLineage
    );
    return imported;
  });

  return {
    agentEnvironmentPackageSnapshots,
    artifactReviews,
    itemRevisions,
    threadMaterialBindings,
    threads,
    turnEvents,
    turns,
    workerContextPackageFiles,
    workspaceInputSnapshots,
    workspaceMaterialRevisions,
    workspaceMaterializationRecords,
    workspaceMaterials,
  };
}

/**
 * Rebinds Thread, Item, and Turn snapshots embedded in already-reminted typed events.
 *
 * @param turnEvents Imported event logs carrying target ids.
 * @param threads Current imported Threads.
 * @param items Current imported Items keyed by target id.
 * @param turns Current imported Turns.
 * @returns Event logs whose typed snapshots match current imported authority.
 * @throws Error when an embedded target Item or Turn is absent.
 */
function refreshImportedTurnEventSnapshots(
  turnEvents: readonly (readonly [string, readonly SseEventEnvelope[]])[],
  threads: readonly Thread[],
  items: ReadonlyMap<string, Item>,
  turns: readonly Turn[]
): Array<[string, SseEventEnvelope[]]> {
  const threadsById = new Map(threads.map((thread) => [thread.id, thread]));
  const turnsById = new Map(turns.map((turn) => [turn.id, turn]));
  return turnEvents.map(([turnId, events]) => [
    turnId,
    events.map((event) => {
      const data = event.data;
      if (data.type === 'thread-created' || data.type === 'thread-updated') {
        return SseEventEnvelopeSchema.parse({
          ...event,
          data: { ...data, thread: requiredMapValue(threadsById, data.thread.id, 'Thread') },
        });
      }
      if (data.type === 'item-created') {
        return SseEventEnvelopeSchema.parse({
          ...event,
          data: { ...data, item: requiredMapValue(items, data.item.id, 'Item') },
        });
      }
      if (data.type === 'item-completed') {
        const item = requiredMapValue(items, data.item.id, 'Item');
        return SseEventEnvelopeSchema.parse({ ...event, data: { ...data, itemId: item.id, item } });
      }
      if (data.type === 'turn-updated' || data.type === 'turn-completed') {
        return SseEventEnvelopeSchema.parse({
          ...event,
          data: { ...data, turn: requiredMapValue(turnsById, data.turn.id, 'Turn') },
        });
      }
      return event;
    }),
  ]);
}

/**
 * Validates one complete linear Material graph and its Thread bindings.
 *
 * @param materials Source Workspace Material owners.
 * @param revisions Source immutable Material revisions.
 * @param bindings Source Thread-to-Material bindings.
 * @param workspaceId Required source Workspace id.
 * @param threadIds Exported source Thread ids.
 * @throws Error when identity, history, digest, mutation proof, or binding lineage is invalid.
 */
function assertMaterialGraph(
  materials: readonly ImportedWorkspaceMaterial[],
  revisions: readonly ImportedWorkspaceMaterialRevision[],
  bindings: readonly ImportedThreadMaterialBinding[],
  workspaceId: string,
  threadIds: ReadonlySet<string>
): void {
  const materialIds = new Set<string>();
  const revisionKeys = new Set<string>();
  for (const material of materials) {
    if (material.workspaceId !== workspaceId || materialIds.has(material.materialId)) {
      throw new Error(`Material identity is duplicate or out of scope: ${material.materialId}`);
    }
    materialIds.add(material.materialId);
  }
  for (const revision of revisions) {
    const key = materialRevisionKey(revision.materialId, revision.revisionId);
    const material = materials.find((candidate) => candidate.materialId === revision.materialId);
    if (
      revision.workspaceId !== workspaceId ||
      revisionKeys.has(key) ||
      !material ||
      revision.mediaType !== (material.kind === 'markdown' ? 'text/markdown' : 'text/plain') ||
      `sha256:${createHash('sha256').update(revision.content).digest('hex')}` !==
        revision.contentDigest
    ) {
      throw new Error(`Material revision is contradictory: ${revision.revisionId}`);
    }
    revisionKeys.add(key);
  }
  for (const material of materials) {
    const owned = revisions.filter((revision) => revision.materialId === material.materialId);
    if (material.currentRevisionId === null) {
      if (owned.length !== 0) {
        throw new Error(
          `Material without a current revision retains history: ${material.materialId}`
        );
      }
      continue;
    }
    const byId = new Map(owned.map((revision) => [revision.revisionId, revision]));
    const roots = owned.filter((revision) => revision.parentRevisionId === null);
    const childCounts = new Map<string, number>();
    for (const revision of owned) {
      if (revision.parentRevisionId !== null) {
        if (!byId.has(revision.parentRevisionId)) {
          throw new Error(`Material revision has a missing parent: ${revision.revisionId}`);
        }
        childCounts.set(
          revision.parentRevisionId,
          (childCounts.get(revision.parentRevisionId) ?? 0) + 1
        );
      }
    }
    if (
      roots.length !== 1 ||
      [...childCounts.values()].some((count) => count !== 1) ||
      byId.get(material.currentRevisionId)?.createdByRequestId !== material.lastMutationRequestId
    ) {
      throw new Error(`Material revision graph is not linear: ${material.materialId}`);
    }
    const visited = new Set<string>();
    let revision = byId.get(material.currentRevisionId);
    while (revision) {
      if (visited.has(revision.revisionId)) {
        throw new Error(`Material revision graph contains a cycle: ${material.materialId}`);
      }
      visited.add(revision.revisionId);
      revision = revision.parentRevisionId ? byId.get(revision.parentRevisionId) : undefined;
    }
    if (visited.size !== owned.length) {
      throw new Error(`Material revision graph is disconnected: ${material.materialId}`);
    }
  }
  const bindingKeys = new Set<string>();
  const boundThreads = new Set<string>();
  for (const binding of bindings) {
    const key = `${binding.threadId}\0${binding.materialId}`;
    const material = materials.find((candidate) => candidate.materialId === binding.materialId);
    if (
      binding.workspaceId !== workspaceId ||
      bindingKeys.has(key) ||
      !threadIds.has(binding.threadId) ||
      !material ||
      (binding.latestQueuedRevisionId !== null &&
        (binding.latestQueuedRevisionId !== material.currentRevisionId ||
          !revisionKeys.has(
            materialRevisionKey(binding.materialId, binding.latestQueuedRevisionId)
          ))) ||
      (binding.bindingState === 'unbound' &&
        (binding.latestQueuedRevisionId !== null || binding.inclusionState !== 'included')) ||
      (binding.inclusionState === 'excluded' &&
        (binding.bindingState !== 'bound' || binding.latestQueuedRevisionId === null))
    ) {
      throw new Error(`Thread Material binding is contradictory: ${key}`);
    }
    bindingKeys.add(key);
    if (binding.bindingState === 'bound') {
      if (boundThreads.has(binding.threadId)) {
        throw new Error(`Thread has more than one bound Material: ${binding.threadId}`);
      }
      boundThreads.add(binding.threadId);
    }
  }
}

/**
 * Rewrites one accepted worker request without changing user-authored prose or Artifact bytes.
 *
 * @param text Serialized structured delegation or Artifact Review follow-up request.
 * @param context Shared import lineage maps.
 * @returns Serialized request with every owned reference reminted.
 * @throws Error when the request is malformed or references missing authority.
 */
function remintWorkerRequest(text: string, context: ImportRemintContext): string {
  const value = JSON.parse(text) as unknown;
  const followUp = ArtifactReviewFollowUpRequestSchema.safeParse(value);
  if (followUp.success) {
    const review = context.sourceArtifactReviews.find(
      (candidate) => candidate.reviewId === followUp.data.reviewId
    );
    if (!review) {
      throw new Error(
        `Worker request references missing Artifact Review: ${followUp.data.reviewId}`
      );
    }
    const artifactId = requiredMapValue(context.artifactIds, review.artifactId, 'artifact');
    return serializeArtifactReviewFollowUpRequest({
      ...followUp.data,
      workspaceId: context.targetWorkspaceId,
      reviewId: deriveArtifactReviewId(
        context.targetWorkspaceId,
        artifactId,
        review.artifactVersion
      ),
      artifactId,
      sourceThreadId: requiredMapValue(context.threadIds, followUp.data.sourceThreadId, 'thread'),
      sourceTurnId: requiredMapValue(context.turnIds, followUp.data.sourceTurnId, 'turn'),
      materialProposal: followUp.data.materialProposal
        ? {
            ...followUp.data.materialProposal,
            materialId: requiredMapValue(
              context.materialIds,
              followUp.data.materialProposal.materialId,
              'Material'
            ),
            baseRevisionId: requiredMaterialRevisionId(
              context,
              followUp.data.materialProposal.materialId,
              followUp.data.materialProposal.baseRevisionId
            ),
          }
        : null,
      decisionRequestId: importRequestLineage(context, followUp.data.decisionRequestId),
      workerRequestId: importRequestLineage(context, followUp.data.workerRequestId),
    });
  }
  const request = StructuredWorkerDelegationRequestSchema.parse(value);
  /**
   * Rewrites one structured request reference through the matching import authority map.
   *
   * @param kind Structured reference kind.
   * @param id Source reference identity.
   * @returns Target identity, or the unchanged id for stable or unknown reference kinds.
   * @throws Error when a reminted reference has no matching source owner.
   */
  const rewriteReference = (kind: string, id: string): string => {
    switch (kind) {
      case 'workspace':
        if (id !== context.report.exportedWorkspaceId) {
          throw new Error(`Worker request references another Workspace: ${id}`);
        }
        return context.targetWorkspaceId;
      case 'thread':
        return requiredMapValue(context.threadIds, id, 'thread');
      case 'item':
        return requiredMapValue(context.itemIds, id, 'Item');
      case 'artifact':
        return requiredMapValue(context.artifactIds, id, 'artifact');
      case 'knowledge':
        if (!context.knowledgeIds.has(id)) {
          throw new Error(`Worker request references missing knowledge: ${id}`);
        }
        return id;
      default:
        return id;
    }
  };
  return serializeStructuredWorkerDelegationRequest({
    ...request,
    contextRefs: request.contextRefs.map((reference) => ({
      ...reference,
      id: rewriteReference(reference.kind, reference.id),
    })),
    resources: request.resources.map((resource) => ({
      ...resource,
      reference: rewriteReference(resource.kind, resource.reference),
    })),
    reviewContext: request.reviewContext
      ? {
          ...request.reviewContext,
          reviewId: request.reviewContext.reviewId,
          priorTurnId: requiredMapValue(context.turnIds, request.reviewContext.priorTurnId, 'turn'),
          evidence: {
            itemIds: request.reviewContext.evidence.itemIds.map((id) =>
              requiredMapValue(context.itemIds, id, 'Item')
            ),
            artifactIds: request.reviewContext.evidence.artifactIds.map((id) =>
              requiredMapValue(context.artifactIds, id, 'artifact')
            ),
          },
        }
      : null,
  });
}

/**
 * Validates one source and reminted Artifact Review against its durable result owners.
 *
 * @param source Parsed source Artifact Review.
 * @param target Reminted target Artifact Review.
 * @param artifacts Reminted canonical Artifacts.
 * @param turns Reminted canonical Turns.
 * @param revisions Reminted Material revisions.
 * @param materials Reminted Workspace Materials.
 * @param stagedWorkspaceReviews Reminted Workspace Sync review owners.
 * @param tracesBySourceTurn Validated source S39 traces keyed by source Turn id.
 * @param sourceItems Canonical source Items keyed by source id.
 * @throws Error when source, proposal, decision, result, or follow-up lineage is contradictory.
 */
function assertArtifactReviewImport(
  source: ImportedArtifactReview,
  target: ImportedArtifactReview,
  artifacts: readonly Artifact[],
  turns: readonly Turn[],
  revisions: readonly ImportedWorkspaceMaterialRevision[],
  materials: readonly ImportedWorkspaceMaterial[],
  stagedWorkspaceReviews: readonly ExportedStagedWorkspaceReview[],
  tracesBySourceTurn: ReadonlyMap<string, WorkerContextPackageTrace>,
  sourceItems: ReadonlyMap<string, Item>
): void {
  const artifact = artifacts.find((candidate) => candidate.id === target.artifactId);
  if (!artifact || stagedWorkspaceReviews.some((review) => review.artifactId === artifact.id)) {
    throw new Error('Artifact Review conflicts with Artifact or Workspace Sync authority.');
  }
  const sourceTurn = target.sourceTurnId
    ? turns.find((turn) => turn.id === target.sourceTurnId)
    : undefined;
  if (
    (target.sourceThreadId === null) !== (target.sourceTurnId === null) ||
    (target.sourceTurnId !== null &&
      (!sourceTurn ||
        sourceTurn.threadId !== target.sourceThreadId ||
        (sourceTurn.agentId ?? null) !== target.sourceAgentId)) ||
    artifact.origin.kind !== 'turn-output' ||
    artifact.threadId !== target.sourceThreadId ||
    artifact.turnId !== target.sourceTurnId ||
    artifact.origin.threadId !== target.sourceThreadId ||
    artifact.origin.turnId !== target.sourceTurnId ||
    source.artifactVersion > artifact.version
  ) {
    throw new Error('Artifact Review source lineage is contradictory.');
  }
  if (source.decision === null) {
    if (
      source.decisionRequestId !== null ||
      artifact.version !== source.artifactVersion ||
      artifact.status !== 'ready' ||
      artifact.contentDigest !== source.contentDigest
    ) {
      throw new Error('Unresolved Artifact Review has no exact current Artifact version.');
    }
    if (target.materialProposal) {
      const material = materials.find(
        (candidate) => candidate.materialId === target.materialProposal?.materialId
      );
      const mediaFormat = material?.kind === 'markdown' ? 'markdown' : 'text';
      if (!material || artifact.content.format !== mediaFormat) {
        throw new Error('Artifact Review proposal media type is contradictory.');
      }
    }
  } else if (source.decisionRequestId === null) {
    throw new Error('Decided Artifact Review has no request lineage.');
  }
  if (source.materialProposal) {
    if (!source.sourceTurnId) {
      throw new Error('Material proposal Review has no source Turn.');
    }
    const selections = (
      tracesBySourceTurn.get(source.sourceTurnId)?.materialSelections ?? []
    ).filter(
      (selection) =>
        selection.materialId === source.materialProposal?.materialId &&
        selection.revisionId === source.materialProposal.baseRevisionId &&
        selection.contentDigest === source.materialProposal.baseContentDigest
    );
    if (selections.length !== 1) {
      throw new Error('Artifact Review Material proposal lacks one exact S39 selection.');
    }
  }
  if (target.decision === 'accepted' && target.materialProposal) {
    const applied = target.appliedMaterialRevisionId
      ? revisions.find(
          (revision) =>
            revision.materialId === target.materialProposal?.materialId &&
            revision.revisionId === target.appliedMaterialRevisionId
        )
      : undefined;
    const material = materials.find(
      (candidate) => candidate.materialId === target.materialProposal?.materialId
    );
    if (
      !applied ||
      !material ||
      applied.parentRevisionId !== target.materialProposal.baseRevisionId ||
      applied.contentDigest !== target.contentDigest ||
      applied.authorId !== target.decisionActorId ||
      applied.createdByRequestId !== target.decisionRequestId ||
      applied.createdAt !== target.decidedAt ||
      applied.mediaType !== (material.kind === 'markdown' ? 'text/markdown' : 'text/plain')
    ) {
      throw new Error('Artifact Review applied Material revision is contradictory.');
    }
  } else if (target.appliedMaterialRevisionId !== null) {
    throw new Error('Artifact Review has an invalid applied Material revision.');
  }
  if (target.decision === 'needs_refinement' || target.decision === 'redo') {
    const followUpTurn = turns.find((turn) => turn.id === target.followUpTurnId);
    const sourceTrace = source.followUpTurnId
      ? tracesBySourceTurn.get(source.followUpTurnId)
      : undefined;
    const requestItem = sourceTrace ? sourceItems.get(sourceTrace.workerRequestItemId) : undefined;
    const request =
      requestItem?.type === 'user-message'
        ? ArtifactReviewFollowUpRequestSchema.safeParse(JSON.parse(requestItem.text))
        : null;
    const proposal = request?.success ? request.data.materialProposal : null;
    const proposalMaterial = target.materialProposal
      ? materials.find((material) => material.materialId === target.materialProposal?.materialId)
      : undefined;
    const proposalMatches =
      proposal === null
        ? source.materialProposal === null
        : source.materialProposal !== null &&
          request?.success === true &&
          proposal.materialId === source.materialProposal.materialId &&
          proposal.baseRevisionId === source.materialProposal.baseRevisionId &&
          proposal.baseContentDigest === source.materialProposal.baseContentDigest &&
          proposalMaterial !== undefined &&
          request.data.artifactMediaType ===
            (proposalMaterial.kind === 'markdown' ? 'text/markdown' : 'text/plain');
    const decisionRequestId = source.decisionRequestId;
    if (
      !followUpTurn ||
      followUpTurn.id === target.sourceTurnId ||
      followUpTurn.threadId !== target.sourceThreadId ||
      (followUpTurn.agentId ?? null) !== target.sourceAgentId ||
      !sourceTrace ||
      sourceTrace.goalId !== null ||
      sourceTrace.taskId !== null ||
      !request?.success ||
      decisionRequestId === null ||
      request.data.workspaceId !== source.workspaceId ||
      request.data.reviewId !== source.reviewId ||
      request.data.artifactId !== source.artifactId ||
      request.data.artifactVersion !== source.artifactVersion ||
      request.data.contentDigest !== source.contentDigest ||
      request.data.sourceThreadId !== source.sourceThreadId ||
      request.data.sourceTurnId !== source.sourceTurnId ||
      request.data.sourceAgentId !== source.sourceAgentId ||
      !proposalMatches ||
      request.data.decision !== source.decision ||
      request.data.feedback !== source.feedback ||
      request.data.decisionRequestId !== decisionRequestId ||
      request.data.workerRequestId !== sourceTrace.requestId ||
      (!/^import-lineage:sha256:[a-f0-9]{64}$/.test(decisionRequestId) &&
        (source.followUpTurnId !==
          deriveArtifactReviewFollowUpTurnId(
            source.workspaceId,
            source.artifactId,
            source.artifactVersion,
            decisionRequestId
          ) ||
          request.data.workerRequestId !== deriveArtifactReviewWorkerRequestId(decisionRequestId)))
    ) {
      throw new Error('Artifact Review follow-up Turn lineage is contradictory.');
    }
  }
}

/**
 * Derives one reserved historical request token from exact source deployment lineage.
 *
 * @param context Shared import lineage and source manifest.
 * @param requestId Source private mutation request id.
 * @returns Deterministic non-command import lineage token.
 */
function importRequestLineage(context: ImportRemintContext, requestId: string): string {
  const digest = createHash('sha256')
    .update(context.report.manifest.sourceDeploymentId)
    .update('\0')
    .update(context.report.exportedWorkspaceId)
    .update('\0')
    .update(requestId)
    .digest('hex');
  return `import-lineage:sha256:${digest}`;
}

/**
 * Reads one required Material from a parsed row set.
 *
 * @param materials Parsed source Materials.
 * @param materialId Required source Material id.
 * @returns The unique matching Material.
 * @throws Error when the reference is missing or ambiguous.
 */
function requireMaterial(
  materials: readonly ImportedWorkspaceMaterial[],
  materialId: string
): ImportedWorkspaceMaterial {
  const matches = materials.filter((material) => material.materialId === materialId);
  if (matches.length !== 1) {
    throw new Error(`Material reference is missing or ambiguous: ${materialId}`);
  }
  return matches[0]!;
}

/**
 * Reads one required Material revision from a parsed row set.
 *
 * @param revisions Parsed source Material revisions.
 * @param materialId Owning source Material id.
 * @param revisionId Required source revision id.
 * @returns The unique matching Material revision.
 * @throws Error when the reference is missing or ambiguous.
 */
function requireMaterialRevision(
  revisions: readonly ImportedWorkspaceMaterialRevision[],
  materialId: string,
  revisionId: string
): ImportedWorkspaceMaterialRevision {
  const matches = revisions.filter(
    (revision) => revision.materialId === materialId && revision.revisionId === revisionId
  );
  if (matches.length !== 1) {
    throw new Error(`Material revision reference is missing or ambiguous: ${revisionId}`);
  }
  return matches[0]!;
}

/**
 * Reads one target revision id from its composite source identity.
 *
 * @param context Shared import lineage maps.
 * @param materialId Owning source Material id.
 * @param revisionId Source revision id.
 * @returns Reminted target revision id.
 * @throws Error when the source revision has no reminted identity.
 */
function requiredMaterialRevisionId(
  context: ImportRemintContext,
  materialId: string,
  revisionId: string
): string {
  return requiredMapValue(
    context.materialRevisionIds,
    materialRevisionKey(materialId, revisionId),
    'Material revision'
  );
}

/**
 * Builds an unambiguous Material revision map key.
 *
 * @param materialId Owning Material id.
 * @param revisionId Material revision id.
 * @returns NUL-delimited composite identity.
 */
function materialRevisionKey(materialId: string, revisionId: string): string {
  return `${materialId}\0${revisionId}`;
}

/** One reminted selected page used to keep S61 evidence and S39 bytes aligned. */
interface ImportedRetrievalSelectedPage {
  readonly content: string;
  readonly contentDigest: string;
  readonly sourceContentDigest: string;
  readonly sourceReferences: readonly string[];
  readonly targetSourceReferences: readonly string[];
}

/** Retrieval traces reminted before dependent S39 package reconstruction. */
interface ImportedRetrievalTraceState {
  readonly files: ReadonlyMap<string, KnowledgeRetrievalTrace>;
  readonly references: ReadonlyMap<string, RetrievalTraceReference>;
  readonly selectedPages: ReadonlyMap<string, ReadonlyMap<string, ImportedRetrievalSelectedPage>>;
}

/** Stable map key for one qualified retrieval-trace reference. */
function retrievalTraceReferenceKey(reference: RetrievalTraceReference): string {
  const parsed = RetrievalTraceReferenceSchema.parse(reference);
  return `${parsed.scopeId}\0${parsed.objectId}`;
}

/** Builds the already-owned id substitutions available before S39 digest reconstruction. */
function portableReferenceReplacements(
  context: ImportRemintContext
): readonly (readonly [string, string])[] {
  const replacementMap = new Map<string, string>([
    [context.report.exportedWorkspaceId, context.targetWorkspaceId],
  ]);
  for (const idMap of [
    context.contextPackageReferences,
    context.threadIds,
    context.turnIds,
    context.itemIds,
    context.artifactIds,
    context.agentSessionIds,
    context.knowledgeSourceIds,
    context.approvalRequestIds,
    context.vaultGrantIds,
  ]) {
    for (const [sourceId, targetId] of idMap) {
      const existing = replacementMap.get(sourceId);
      if (existing && existing !== targetId) {
        throw new Error(`Portable reference id is ambiguous: ${sourceId}`);
      }
      replacementMap.set(sourceId, targetId);
    }
  }
  return [...replacementMap].sort(([left], [right]) => right.length - left.length);
}

/** Remints one page collection while leaving unavailable Server or User sources source-qualified. */
function remintImportedPageScope(scopeId: string, context: ImportRemintContext): string {
  const scope = parseReferenceScope(scopeId);
  if (!scope || scope.family !== 'page') {
    throw new Error('Portable retrieval trace source scope is invalid.');
  }
  if (scope.kind === 'workspace') {
    if (scope.workspaceId !== context.report.exportedWorkspaceId) {
      throw new Error('Portable retrieval trace belongs to another Workspace source.');
    }
    return `page/workspace/${context.targetWorkspaceId}`;
  }
  return scopeId;
}

/** Remints one page reference without granting imported Server or User evidence in the target. */
function remintImportedPageReference(
  reference: { readonly scopeId: string; readonly objectId: string },
  sourceScope: string,
  targetScope: string,
  context: ImportRemintContext
): { readonly scopeId: string; readonly objectId: string } {
  if (reference.scopeId !== sourceScope) {
    throw new Error('Portable retrieval trace reference is outside its selected source.');
  }
  remintImportedPageScope(reference.scopeId, context);
  return { scopeId: targetScope, objectId: reference.objectId };
}

/** Reconstructs immutable query-owned trace files before S39 consumes their qualified references. */
function readRetrievalTraceImportState(context: ImportRemintContext): ImportedRetrievalTraceState {
  const tracePaths = [...context.files.keys()]
    .filter((path) =>
      /^workspace-files\/threads\/[^/]+\/(?:turns\/[^/]+\/)?retrieval-traces\/[^/]+\.json$/.test(
        path
      )
    )
    .sort();
  if (tracePaths.length > 0 && !context.targetServerId) {
    throw new Error('Workspace import requires the target Server identity for retrieval traces.');
  }
  const sourceTurns = new Map(
    readImportJsonl(context.files, 'records/turns.jsonl').map((record) => {
      const turn = TurnSchema.parse(record);
      return [turn.id, turn.threadId] as const;
    })
  );
  const replacements = portableReferenceReplacements(context);
  const files = new Map<string, KnowledgeRetrievalTrace>();
  const references = new Map<string, RetrievalTraceReference>();
  const selectedPages = new Map<string, ReadonlyMap<string, ImportedRetrievalSelectedPage>>();

  for (const exportPath of tracePaths) {
    const sourcePath = exportPath.slice('workspace-files/'.length);
    const { reference: sourceReference, trace: sourceTrace } = parseWorkspaceRetrievalTraceFile(
      sourcePath,
      requiredExportFile(context.files, exportPath),
      context.report.exportedWorkspaceId
    );
    if (sourceTrace.queryContext.serverId !== context.report.manifest.sourceDeploymentId) {
      throw new Error('Portable retrieval trace Server lineage is contradictory.');
    }
    const sourceOwner = parseReferenceScope(sourceReference.scopeId);
    if (!sourceOwner || sourceOwner.family !== 'retrieval-trace') {
      throw new Error('Portable retrieval trace owner is invalid.');
    }
    const targetThreadId = requiredMapValue(context.threadIds, sourceOwner.threadId, 'thread');
    let targetTurnId: string | undefined;
    if (sourceOwner.kind === 'turn') {
      if (sourceTurns.get(sourceOwner.turnId) !== sourceOwner.threadId) {
        throw new Error('Portable retrieval trace Turn owner is contradictory.');
      }
      targetTurnId = requiredMapValue(context.turnIds, sourceOwner.turnId, 'turn');
    }
    const targetReference = RetrievalTraceReferenceSchema.parse({
      scopeId: targetTurnId
        ? `retrieval-trace/turn/${context.targetWorkspaceId}/${targetThreadId}/${targetTurnId}`
        : `retrieval-trace/thread/${context.targetWorkspaceId}/${targetThreadId}`,
      objectId: sourceReference.objectId,
    });
    const targetSourceScope = remintImportedPageScope(sourceTrace.sourceScope, context);
    const expectedSourceScope =
      sourceTrace.retrievalParameters.sourceScope === 'workspace'
        ? `page/workspace/${context.report.exportedWorkspaceId}`
        : 'page/server';
    if (sourceTrace.sourceScope !== expectedSourceScope) {
      throw new Error('Portable retrieval trace source selection is contradictory.');
    }
    const targetSelections = new Map<string, ImportedRetrievalSelectedPage>();
    const selected = sourceTrace.selected.map((entry) => {
      const reference = remintImportedPageReference(
        entry.reference,
        sourceTrace.sourceScope,
        targetSourceScope,
        context
      );
      if (!sourceTrace.sourceScope.startsWith('page/workspace/')) {
        return {
          ...entry,
          reference,
          sourceReferences: rewritePortableReferences(entry.sourceReferences, replacements),
        };
      }
      if (entry.sourceReferences.some((value) => value.startsWith('context-package:'))) {
        throw new Error(
          'Portable Knowledge history requires unavailable historical notebook closure.'
        );
      }
      const pagePath = `workspace-files/knowledge/pages/${entry.reference.objectId}.md`;
      const sourceContent = requiredExportFile(context.files, pagePath);
      const sourceContentDigest = `sha256:${createHash('sha256').update(sourceContent).digest('hex')}`;
      if (sourceContentDigest !== entry.contentDigest || entry.revision !== entry.contentDigest) {
        throw new Error('Portable retrieval trace does not match its exported Knowledge Page.');
      }
      const targetContent = rewriteNativePageReferences(pagePath, sourceContent, replacements);
      const targetContentDigest = `sha256:${createHash('sha256').update(targetContent).digest('hex')}`;
      const targetSourceReferences = rewritePortableReferences(
        entry.sourceReferences,
        replacements
      );
      if (targetSelections.has(entry.reference.objectId)) {
        throw new Error('Portable retrieval trace selects one Knowledge Page more than once.');
      }
      targetSelections.set(entry.reference.objectId, {
        content: targetContent,
        contentDigest: targetContentDigest,
        sourceContentDigest,
        sourceReferences: entry.sourceReferences,
        targetSourceReferences,
      });
      return {
        ...entry,
        reference,
        revision: targetContentDigest,
        contentDigest: targetContentDigest,
        sourceReferences: targetSourceReferences,
      };
    });
    const excluded = sourceTrace.excluded.map((entry) => {
      const reference = remintImportedPageReference(
        entry.reference,
        sourceTrace.sourceScope,
        targetSourceScope,
        context
      );
      const targetSourceReferences = rewritePortableReferences(
        entry.sourceReferences,
        replacements
      );
      if (sourceTrace.sourceScope.startsWith('page/workspace/') && entry.contentDigest !== null) {
        if (entry.sourceReferences.some((value) => value.startsWith('context-package:'))) {
          throw new Error(
            'Portable Knowledge history requires unavailable historical notebook closure.'
          );
        }
        const pagePath = `workspace-files/knowledge/pages/${entry.reference.objectId}.md`;
        const sourceContent = requiredExportFile(context.files, pagePath);
        const sourceContentDigest = `sha256:${createHash('sha256').update(sourceContent).digest('hex')}`;
        if (
          sourceContentDigest !== entry.contentDigest ||
          (entry.revision !== null && entry.revision !== entry.contentDigest)
        ) {
          throw new Error(
            'Portable retrieval exclusion does not match its exported Knowledge Page.'
          );
        }
        const targetContent = rewriteNativePageReferences(pagePath, sourceContent, replacements);
        const targetContentDigest = `sha256:${createHash('sha256').update(targetContent).digest('hex')}`;
        return {
          ...entry,
          reference,
          revision: entry.revision === null ? null : targetContentDigest,
          contentDigest: targetContentDigest,
          sourceReferences: targetSourceReferences,
        };
      }
      return {
        ...entry,
        reference,
        sourceReferences: targetSourceReferences,
      };
    });
    const targetTrace = KnowledgeRetrievalTraceSchema.parse({
      ...sourceTrace,
      // The digest remains evidence of the original request; query text is intentionally absent and cannot be rehashed after owner reminting.
      requestDigest: sourceTrace.requestDigest,
      queryContext: {
        ...sourceTrace.queryContext,
        serverId: context.targetServerId,
        workspaceId: context.targetWorkspaceId,
        threadId: targetThreadId,
        ...(targetTurnId ? { turnId: targetTurnId } : { turnId: undefined }),
      },
      sourceScope: targetSourceScope,
      retrievalParameters: {
        ...sourceTrace.retrievalParameters,
        pinnedReferences: sourceTrace.retrievalParameters.pinnedReferences.map((reference) =>
          remintImportedPageReference(
            reference,
            sourceTrace.sourceScope,
            targetSourceScope,
            context
          )
        ),
      },
      selected,
      excluded,
    });
    const targetPath = retrievalTraceRelativePath(targetReference);
    parseWorkspaceRetrievalTraceFile(
      targetPath,
      serializeWorkspaceRetrievalTrace(targetTrace),
      context.targetWorkspaceId
    );
    const key = retrievalTraceReferenceKey(sourceReference);
    if (references.has(key) || files.has(targetPath)) {
      throw new Error('Portable retrieval trace identity is duplicated.');
    }
    references.set(key, targetReference);
    selectedPages.set(key, targetSelections);
    files.set(targetPath, targetTrace);
  }
  return { files, references, selectedPages };
}

/**
 * Reconstructs authoritative workspace files after every referenced id map is known.
 *
 * @param context Shared import lineage and verified bytes.
 * @returns Imported portable file state.
 * @throws Error when a portable record references missing exported state.
 */
function readPortableImportState(
  context: ImportRemintContext,
  workerContextPackageFiles: ReadonlyMap<string, string>,
  knowledge: readonly KnowledgeEntry[],
  retrievalTraceFiles: ReadonlyMap<string, KnowledgeRetrievalTrace>
): WorkspacePortableFileState {
  const portableFileState = readPortableFileStateFromExport(context);
  assertPortableKnowledgePagesMatch(portableFileState.nativeKnowledgePages, knowledge);
  return { ...portableFileState, retrievalTraceFiles, workerContextPackageFiles };
}

/**
 * Verifies a one-to-one projection between canonical Knowledge records and exact portable pages.
 *
 * @param pages Reminted portable page bytes keyed by workspace-relative path.
 * @param knowledge Canonical imported KnowledgeEntry projections.
 * @throws Error when an owned page is missing, duplicated, malformed, or contradictory.
 */
function assertPortableKnowledgePagesMatch(
  pages: ReadonlyMap<string, string>,
  knowledge: readonly KnowledgeEntry[]
): void {
  const expectedById = new Map(knowledge.map((entry) => [entry.id, entry]));
  if (expectedById.size !== knowledge.length) {
    throw new Error('Portable Knowledge Page record identity is ambiguous.');
  }
  const matchedIds = new Set<string>();

  for (const [path, content] of pages) {
    const parsed = parseOkfDocument({ path, content });
    const entryId = parsed.document
      ? stringFrontmatterField(parsed.document, 'openkit_entry_id')
      : null;
    if (!entryId) {
      continue;
    }
    if (matchedIds.has(entryId) || path !== `knowledge/pages/${entryId}.md`) {
      throw new Error(`Portable Knowledge Page identity is ambiguous: ${entryId}`);
    }

    let projected: KnowledgeEntry;
    try {
      projected = parseOwnedKnowledgeEntry(path, entryId, content);
    } catch {
      throw new Error(`Portable Knowledge Page is invalid: ${entryId}`);
    }
    const expected = expectedById.get(entryId);
    if (!expected || !knowledgeEntriesEqual(projected, expected)) {
      throw new Error(`Portable Knowledge Page contradicts its canonical record: ${entryId}`);
    }
    matchedIds.add(entryId);
  }

  const missing = knowledge.find((entry) => !matchedIds.has(entry.id));
  if (missing) {
    throw new Error(`Portable Knowledge Page is missing: ${missing.id}`);
  }
}

/**
 * Reads and remints authoritative workspace files from verified export bytes.
 *
 * @param files Exact verified export file contents.
 * @param context Canonical id maps established by the current import.
 * @returns Portable file state ready for staged publication.
 */
function readPortableFileStateFromExport(context: ImportRemintContext): WorkspacePortableFileState {
  const files = context.files;
  const replacements = portableReferenceReplacements(context);
  const observations = readImportJsonl(files, 'records/knowledge-observations.jsonl').map(
    (record) => {
      const parsed = ImportedKnowledgeObservationSchema.parse(record);
      assertPortableWorkspaceOwner(
        parsed.workspaceId,
        context.report.exportedWorkspaceId,
        'observation'
      );
      return ImportedKnowledgeObservationSchema.parse({
        ...parsed,
        workspaceId: context.targetWorkspaceId,
        sourceReferences: rewritePortableReferences(parsed.sourceReferences, replacements),
      });
    }
  );
  const claims = readImportJsonl(files, 'records/knowledge-claims.jsonl').map((record) => {
    const parsed = ImportedKnowledgeClaimSchema.parse(record);
    assertPortableWorkspaceOwner(parsed.workspaceId, context.report.exportedWorkspaceId, 'claim');
    return ImportedKnowledgeClaimSchema.parse({
      ...parsed,
      workspaceId: context.targetWorkspaceId,
      sourceReferences: rewritePortableReferences(parsed.sourceReferences, replacements),
    });
  });
  const conflicts = readImportJsonl(files, 'records/knowledge-conflicts.jsonl').map((record) => {
    const parsed = ImportedKnowledgeConflictSchema.parse(record);
    assertPortableWorkspaceOwner(
      parsed.workspaceId,
      context.report.exportedWorkspaceId,
      'conflict'
    );
    return ImportedKnowledgeConflictSchema.parse({
      ...parsed,
      workspaceId: context.targetWorkspaceId,
      subjectReferences: rewritePortableReferences(parsed.subjectReferences, replacements),
      sourceReferences: rewritePortableReferences(parsed.sourceReferences, replacements),
    });
  });
  let workspaceConfig: string | null = null;
  let workspaceSchema: string | null = null;
  const nativeKnowledgePages = new Map<string, string>();
  for (const [exportPath, content] of files) {
    if (!exportPath.startsWith('workspace-files/')) {
      continue;
    }
    const workspacePath = exportPath.slice('workspace-files/'.length);
    assertPortableWorkspaceFilePath(workspacePath);
    if (workspacePath === 'config/workspace.jsonc') {
      workspaceConfig = content;
    } else if (workspacePath === 'knowledge/schema/workspace-schema.yaml') {
      workspaceSchema = content;
    } else if (workspacePath.startsWith('knowledge/pages/')) {
      nativeKnowledgePages.set(
        workspacePath,
        rewriteNativePageReferences(workspacePath, content, replacements)
      );
    } else if (
      workspacePath.startsWith('evidence/bundles/') ||
      workspacePath.startsWith('threads/')
    ) {
    } else {
      throw new Error(`Unsupported portable workspace file: ${workspacePath}`);
    }
  }

  return {
    observations: groupPortableRecords(observations, (record) => record.observedAt),
    claims: groupPortableRecords(claims, (record) => record.createdAt),
    conflicts: groupPortableRecords(conflicts, (record) => record.resolvedAt ?? record.createdAt),
    retrievalTraceFiles: new Map(),
    workspaceConfig,
    workspaceSchema,
    nativeKnowledgePages,
    workerContextPackageFiles: new Map(),
  };
}

/** Fails closed when a portable row is owned by another source workspace. */
function assertPortableWorkspaceOwner(actual: string, expected: string, label: string): void {
  if (actual !== expected) {
    throw new Error(`Portable ${label} belongs to another workspace: ${actual}`);
  }
}

/** Rewrites known stable ids inside opaque reference strings. */
function rewritePortableReferences(
  references: readonly string[],
  replacements: readonly (readonly [string, string])[]
): string[] {
  return references.map((reference) =>
    replacements.reduce(
      (rewritten, [sourceId, targetId]) => rewritten.replaceAll(sourceId, targetId),
      reference
    )
  );
}

/** Groups append-order records by their authoritative ledger month. */
function groupPortableRecords<T>(
  records: readonly T[],
  timestamp: (record: T) => string
): ReadonlyMap<string, readonly T[]> {
  const grouped = new Map<string, T[]>();
  for (const record of records) {
    const value = timestamp(record);
    const match = /^(\d{4})-(\d{2})-/.exec(value);
    if (!match || Number(match[2]) < 1 || Number(match[2]) > 12) {
      throw new Error(`Portable ledger timestamp is invalid: ${value}`);
    }
    const month = `${match[1]}${match[2]}`;
    const rows = grouped.get(month) ?? [];
    rows.push(record);
    grouped.set(month, rows);
  }
  return grouped;
}

/** Rewrites only the structured source_refs field of one native OKF page. */
function rewriteNativePageReferences(
  path: string,
  content: string,
  replacements: readonly (readonly [string, string])[]
): string {
  const parsed = parseOkfDocument({ path, content });
  if (parsed.document?.frontmatter.source_refs === undefined) {
    return content;
  }
  const sourceReferences = parsed.document
    ? stringListFrontmatterField(parsed.document, 'source_refs')
    : null;
  if (sourceReferences === null) {
    throw new Error(`Native OKF page has invalid source_refs: ${path}`);
  }
  const rewritten = rewritePortableReferences(sourceReferences, replacements);
  if (rewritten.every((reference, index) => reference === sourceReferences[index])) {
    return content;
  }
  return updateOkfFrontmatter({ path, content, updates: { source_refs: rewritten } });
}

/**
 * Reads artifact metadata and its single canonical body file from an export tree.
 *
 * @param files Exact verified export file contents.
 * @param manifest Verified export manifest.
 * @returns Reconstructed artifacts in stable metadata-path order.
 * @throws Error when artifact paths, metadata, or body ownership are inconsistent.
 */
function readExportedArtifacts(
  files: ReadonlyMap<string, string>,
  manifest: WorkspaceExportManifest
): Artifact[] {
  const artifactPaths = manifest.contentInventory
    .map((entry) => entry.path)
    .filter((path) => path.startsWith('artifacts/'));
  const metadataPaths = artifactPaths
    .filter((path) => /^artifacts\/[^/]+\/artifact\.json$/.test(path))
    .sort();
  const expectedPaths = new Set<string>();
  const artifacts = metadataPaths.map((metadataPath) => {
    const artifactId = metadataPath.split('/')[1] as string;
    const metadata = readImportJson(files, metadataPath) as Record<string, unknown>;
    const format = z
      .enum(['markdown', 'text', 'json', 'file'])
      .parse((metadata.content as { format?: unknown } | undefined)?.format);
    if (format === 'file') {
      const artifact = ArtifactSchema.parse(metadata);
      const payloadPath = `artifacts/${artifactId}/versions/${artifact.version}/payload`;
      const payload = manifest.contentInventory.find((entry) => entry.path === payloadPath);
      if (
        artifact.id !== artifactId ||
        artifact.content.format !== 'file' ||
        !payload ||
        payload.bytes !== artifact.content.byteLength ||
        payload.digest !== artifact.contentDigest
      ) {
        throw new Error('Artifact export payload ownership is inconsistent.');
      }
      expectedPaths.add(metadataPath);
      expectedPaths.add(payloadPath);
      return artifact;
    }
    const bodyPath = `artifacts/${artifactId}/files/${artifactContentFileName(format)}`;

    expectedPaths.add(metadataPath);
    expectedPaths.add(bodyPath);
    const artifact = ArtifactSchema.parse({
      ...metadata,
      content: { format, body: requiredExportFile(files, bodyPath) },
    });
    if (artifact.id !== artifactId) {
      throw new Error(`Artifact ${artifact.id} has invalid directory lineage.`);
    }
    return artifact;
  });

  if (
    artifactPaths.length !== expectedPaths.size ||
    artifactPaths.some((path) => !expectedPaths.has(path))
  ) {
    throw new Error('Artifact export contains missing or duplicate metadata/body ownership.');
  }
  return artifacts;
}

/**
 * Rewrites every identity-bearing event payload to imported canonical records.
 *
 * @param event Exported event envelope.
 * @param records Imported canonical records keyed by source ids.
 * @returns Event envelope with rewritten direct and nested lineage.
 * @throws Error when the event references state outside the export.
 */
function rewritePortableTurnEvent(
  event: SseEventEnvelope,
  records: {
    workspace: WorkspaceRecord;
    threads: ReadonlyMap<string, Thread>;
    turns: ReadonlyMap<string, Turn>;
    items: ReadonlyMap<string, Item>;
    artifacts: ReadonlyMap<string, Artifact>;
    agentSessions: ReadonlyMap<string, AgentSession>;
    approvalRequestIds: ReadonlyMap<string, string>;
  }
): SseEventEnvelope {
  const threadId = event.threadId
    ? requiredMapValue(records.threads, event.threadId, 'thread').id
    : undefined;
  const turn = event.turnId ? records.turns.get(event.turnId) : undefined;
  if (event.turnId && !turn) {
    throw new Error(`Turn event references missing exported turn: ${event.turnId}`);
  }
  const data = event.data;
  let rewrittenData: unknown;

  switch (data.type) {
    case 'workspace-updated':
      rewrittenData = { ...data, workspace: records.workspace };
      break;
    case 'thread-created':
    case 'thread-updated':
      rewrittenData = {
        ...data,
        thread: requiredMapValue(records.threads, data.thread.id, 'thread'),
      };
      break;
    case 'turn-started':
      rewrittenData = {
        ...data,
        turnId: requiredMapValue(records.turns, data.turnId, 'turn').id,
      };
      break;
    case 'turn-updated':
    case 'turn-completed':
      rewrittenData = {
        ...data,
        turn: requiredMapValue(records.turns, data.turn.id, 'turn'),
      };
      break;
    case 'item-created':
      rewrittenData = {
        ...data,
        item: requiredMapValue(records.items, data.item.id, 'item'),
      };
      break;
    case 'item-completed': {
      const item = requiredMapValue(records.items, data.item.id, 'item');
      rewrittenData = { ...data, itemId: item.id, item };
      break;
    }
    case 'item-delta': {
      const item = requiredMapValue(records.items, data.itemId, 'item');
      if (data.deltaKind === 'artifact-updated') {
        const artifact = requiredMapValue(records.artifacts, data.artifactId, 'artifact');
        if (
          item.type !== 'artifact-reference' ||
          item.artifactId !== artifact.id ||
          item.artifactVersion !== artifact.version
        ) {
          throw new Error('Artifact update delta has contradictory artifact-reference lineage.');
        }
        rewrittenData = { ...data, itemId: item.id, artifactId: artifact.id };
      } else {
        rewrittenData = { ...data, itemId: item.id };
      }
      break;
    }
    case 'approval-requested':
    case 'approval-resolved':
      rewrittenData = {
        ...data,
        approval: {
          ...data.approval,
          id: requiredMapValue(records.approvalRequestIds, data.approval.id, 'approval request'),
          workspaceId: records.workspace.id,
          threadId: requiredMapValue(records.threads, data.approval.threadId, 'thread').id,
          turnId: requiredMapValue(records.turns, data.approval.turnId, 'turn').id,
        },
      };
      break;
    case 'agent-session-updated':
      rewrittenData = {
        ...data,
        agentSession: requiredMapValue(records.agentSessions, data.agentSession.id, 'AgentSession'),
      };
      break;
    case 'artifact-created':
    case 'artifact-updated':
      rewrittenData = {
        ...data,
        artifact: requiredMapValue(records.artifacts, data.artifact.id, 'artifact'),
      };
      break;
    case 'error':
      rewrittenData = data;
      break;
  }

  return SseEventEnvelopeSchema.parse({
    ...event,
    workspaceId: records.workspace.id,
    ...(threadId ? { threadId } : {}),
    ...(turn ? { turnId: turn.id } : {}),
    data: rewrittenData,
  });
}

/** Reads only inventoried observations and rewrites their owning identities through the import maps. */
function readWorkObservationImportState(
  context: ImportRemintContext
): Pick<WorkspaceImportSnapshot, 'turnObservations' | 'turnCaptureCoverage'> {
  const turnObservations = new Map<string, string>();
  const turnCaptureCoverage = new Map<string, CaptureCoverageBinding>();
  const expectedPaths = new Set<string>();
  const rawTurns = readImportJsonl(context.files, 'records/turns.jsonl');
  for (const value of rawTurns) {
    const raw = z
      .object({
        captureCoverage: CaptureCoverageBindingSchema.optional(),
        requiredFeatures: z.array(z.string()).optional(),
      })
      .passthrough()
      .parse(value);
    const turn = TurnSchema.parse(value);
    const targetTurnId = requiredMapValue(context.turnIds, turn.id, 'turn');
    if (raw.captureCoverage) turnCaptureCoverage.set(targetTurnId, raw.captureCoverage);
    const path = `workspace-files/threads/${turn.threadId}/turns/${turn.id}/observations.jsonl`;
    const declared = raw.requiredFeatures?.includes('openkit.work-observations.v1') ?? false;
    if (!declared && !context.files.has(path)) continue;
    if (
      !declared ||
      !context.report.manifest.requiredFeatures.includes('openkit.work-observations.v1') ||
      !raw.captureCoverage
    ) {
      throw new Error(
        'Work observations require manifest and Turn feature declarations and historical coverage.'
      );
    }
    expectedPaths.add(path);
    const rows = parsePortableWorkObservations(requiredExportFile(context.files, path), turn.id);
    const observationIds = new Map(
      rows.map((row, index) => [row.id, `obs_imported_${targetTurnId}_${index + 1}`])
    );
    const targetRows = rows.map((row) => {
      let parent: string | undefined;
      if (row.parent) {
        const observationParent = observationIds.get(row.parent);
        const itemParent = context.itemLineage.get(row.parent);
        if (observationParent && itemParent)
          throw new Error('Ambiguous work observation parent identity.');
        if (itemParent && itemParent.threadId !== turn.threadId)
          throw new Error('Work observation parent belongs to another Thread.');
        parent =
          observationParent ??
          (itemParent ? requiredMapValue(context.itemIds, row.parent, 'item') : undefined);
        if (!parent || row.parent === row.id)
          throw new Error('Work observation parent references missing or cyclic exported state.');
        const parentRow = rows.find((candidate) => candidate.id === row.parent);
        if (parentRow && parentRow.seq >= row.seq)
          throw new Error('Work observation parent must precede its child.');
      }
      const refs = row.refs?.map((ref) => remintWorkObservationReference(ref, context, turn));
      let corr = row.corr;
      const payload = { ...row.payload };
      const sourcePackages = readOptionalImportJsonl(
        context.files,
        'records/agent-environment-package-snapshots.jsonl'
      )
        .map((value) => ExportedAgentEnvironmentPackageSnapshotSchema.parse(value))
        .filter((snapshot) => snapshot.turnId === turn.id && snapshot.threadId === turn.threadId);
      if (row.type === 'env.bound') {
        assertPortableWorkspaceOwner(
          payload.workspaceId as string,
          context.report.exportedWorkspaceId,
          'env.bound'
        );
        payload.workspaceId = context.targetWorkspaceId;
      } else if (row.type === 'runtime.observed') {
        if (sourcePackages.length !== 1)
          throw new Error('Runtime observation requires one exact exported AEP.');
        const targetPackageId = requiredMapValue(
          context.agentEnvironmentPackageSnapshotIds,
          sourcePackages[0]!.snapshotId,
          'AEP snapshot'
        );
        for (const [key, prefix] of [
          ['observationId', 'obs'],
          ['sourceRef', 'rts'],
        ] as const) {
          payload[key] =
            `${prefix}_${createHash('sha256').update(`${targetPackageId}:${payload[key]}`).digest('hex').slice(0, 24)}`;
        }
      }
      const origins =
        row.type === 'runtime.observed'
          ? payload.fact
          : row.type === 'model.observed'
            ? payload
            : null;
      if (typeof origins === 'object' && origins !== null) {
        const rewritten = z.record(z.string(), z.unknown()).parse(origins);
        for (const key of ['runtimeOriginRef', 'parentRuntimeOriginRef'] as const) {
          const sourceRef = rewritten[key];
          if (typeof sourceRef === 'string') {
            if (sourcePackages.length !== 1)
              throw new Error('Work observation origin requires one exact exported AEP.');
            rewritten[key] = remintObservedRuntimeOrigin(
              context,
              sourcePackages[0]!.snapshotId,
              sourceRef
            );
          }
        }
        if (row.type === 'runtime.observed') {
          // Preserve the recovery pairing key before reminting the runtime fact identity.
          if (corr === undefined && typeof rewritten.callRef === 'string') corr = rewritten.callRef;
          const targetPackageId = requiredMapValue(
            context.agentEnvironmentPackageSnapshotIds,
            sourcePackages[0]!.snapshotId,
            'AEP snapshot'
          );
          for (const [key, prefix] of [
            ['callRef', 'rtc'],
            ['messageRef', 'rtm'],
          ] as const) {
            const sourceRef = rewritten[key];
            if (typeof sourceRef === 'string')
              rewritten[key] =
                `${prefix}_${createHash('sha256').update(`${targetPackageId}:${sourceRef}`).digest('hex').slice(0, 24)}`;
          }
          payload.fact = rewritten;
        } else Object.assign(payload, rewritten);
      }
      if (Array.isArray(payload.bodies)) {
        payload.bodies = payload.bodies.map((body: unknown) => {
          // The owner parser already validates descriptors; this projection changes only their owner id.
          if (
            typeof body !== 'object' ||
            body === null ||
            !('bundleId' in body) ||
            typeof body.bundleId !== 'string'
          )
            throw new Error('Invalid observation body descriptor.');
          const bundleId = context.evidenceBundleIds.get(body.bundleId);
          if (!bundleId) {
            if (row.type === 'content.published')
              throw new Error('Published observation body is missing its evidence owner.');
            if (!('id' in body) || typeof body.id !== 'string')
              throw new Error('Invalid expected observation body identity.');
            return {
              ...body,
              bundleId: workObservationBodyBundleId(
                context.targetWorkspaceId,
                requiredMapValue(context.threadIds, turn.threadId, 'thread'),
                targetTurnId,
                requiredMapValue(observationIds, row.id, 'observation'),
                body.id
              ),
            };
          }
          if (
            row.type === 'content.published' &&
            !row.refs?.some(
              (ref) =>
                ref.kind === 'evidence-bundle' &&
                ref.locator === body.bundleId &&
                'sha256' in body &&
                ref.digest === body.sha256
            )
          ) {
            throw new Error('Publication body descriptor contradicts its evidence reference.');
          }
          return { ...body, bundleId };
        });
      }
      return parseWorkObservationRecord({
        ...row,
        id: requiredMapValue(observationIds, row.id, 'observation'),
        turnId: targetTurnId,
        ...(corr === undefined ? {} : { corr }),
        ...(parent ? { parent } : {}),
        ...(refs ? { refs } : {}),
        payload,
      });
    });
    turnObservations.set(
      targetTurnId,
      targetRows.map((row) => `${JSON.stringify(row)}\n`).join('')
    );
  }
  for (const path of context.files.keys()) {
    if (
      path.endsWith('/observations.jsonl') &&
      path.startsWith('workspace-files/threads/') &&
      !expectedPaths.has(path)
    ) {
      throw new Error(`Work observations have no exported Turn owner: ${path}`);
    }
    if (path.startsWith('workspace-files/evidence/backend/')) {
      throw new Error('Restricted originals must use the verified binary evidence inventory.');
    }
  }
  return { turnObservations, turnCaptureCoverage };
}

/** Uses the existing provenance remint boundary for opaque origins, including captures without a complete native index. */
function remintObservedRuntimeOrigin(
  context: ImportRemintContext,
  packageSnapshotId: string,
  sourceRef: string
): string {
  const targetPackageId = requiredMapValue(
    context.agentEnvironmentPackageSnapshotIds,
    packageSnapshotId,
    'AEP snapshot'
  );
  if (!/^rto_[a-f0-9]{24}$/.test(sourceRef))
    throw new Error('Invalid portable runtime origin reference.');
  const refs =
    context.runtimeOriginRefsByPackageSnapshotId.get(packageSnapshotId) ??
    new Map<string, string>();
  const existing = refs.get(sourceRef);
  if (existing) return existing;
  if (context.completeRuntimeOriginPackages.has(packageSnapshotId))
    throw new Error('Runtime origin reference is absent from its package normalized index.');
  const sourcePackage = readOptionalImportJsonl(
    context.files,
    'records/agent-environment-package-snapshots.jsonl'
  )
    .map((value) => ExportedAgentEnvironmentPackageSnapshotSchema.parse(value))
    .find((snapshot) => snapshot.snapshotId === packageSnapshotId);
  if (
    !sourcePackage ||
    AgentEnvironmentPackageSchema.parse(
      sourcePackage.snapshot
    ).backend.requiredCapabilities.includes('worker.runtime-provenance.v1')
  ) {
    throw new Error('Required runtime provenance index is missing.');
  }
  const targetRef = `rto_${createHash('sha256').update(`${targetPackageId}:${sourceRef}`).digest('hex').slice(0, 24)}`;
  refs.set(sourceRef, targetRef);
  context.runtimeOriginRefsByPackageSnapshotId.set(packageSnapshotId, refs);
  return targetRef;
}

/** Remints an admitted scoped citation without treating a digest or coincident id as ownership. */
function remintWorkObservationReference(
  ref: WorkObservationReference,
  context: ImportRemintContext,
  turn: Turn
): WorkObservationReference {
  if (
    ref.scope.workspaceId !== context.report.exportedWorkspaceId ||
    ref.scope.deploymentId !== undefined ||
    (ref.scope.ownerScope !== undefined && ref.scope.ownerScope !== 'workspace')
  )
    return ref;
  const scope: Record<string, string> = { ...ref.scope, workspaceId: context.targetWorkspaceId };
  for (const [key, map] of [
    ['threadId', context.threadIds],
    ['turnId', context.turnIds],
    ['agentSessionId', context.agentSessionIds],
    ['packageSnapshotId', context.agentEnvironmentPackageSnapshotIds],
  ] as const) {
    const id = ref.scope[key];
    if (id !== undefined) scope[key] = requiredMapValue(map, id, key);
  }
  let locator: string;
  switch (ref.kind) {
    case 'evidence-bundle': {
      locator = requiredMapValue(context.evidenceBundleIds, ref.locator, 'evidence bundle');
      const bundle = readOptionalImportJsonl(context.files, 'records/evidence-bundles.jsonl')
        .map((record) => ImportedEvidenceBundleRecordSchema.parse(record))
        .find((record) => record.id === ref.locator);
      if (
        !bundle ||
        bundle.workspaceId !== context.report.exportedWorkspaceId ||
        (bundle.threadId !== null && bundle.threadId !== turn.threadId) ||
        (ref.edge === 'publication' &&
          (bundle.sourceKind !== 'work-observation-body' ||
            bundle.turnId !== turn.id ||
            ref.scope.pathClass !== 'backend')) ||
        (ref.digest !== undefined && !bundle.contentDigests.includes(ref.digest))
      ) {
        throw new Error(
          'Work observation evidence reference has contradictory ownership or digest.'
        );
      }
      break;
    }
    case 'artifact':
      locator = requiredMapValue(context.artifactIds, ref.locator, 'artifact');
      break;
    case 'agent-environment-package':
    case 'aep-snapshot':
      locator = requiredMapValue(
        context.agentEnvironmentPackageSnapshotIds,
        ref.locator,
        'AEP snapshot'
      );
      break;
    case 'capability-call': {
      const call = readOptionalImportJsonl(context.files, 'records/capability-calls.jsonl')
        .map((record) => ExportedCapabilityCallSchema.parse(record))
        .find((record) => record.id === ref.locator);
      if (
        !call ||
        call.workspaceId !== context.report.exportedWorkspaceId ||
        call.threadId !== turn.threadId ||
        call.turnId !== turn.id
      )
        throw new Error('Work observation capability reference has contradictory ownership.');
      locator = call.id;
      break;
    }
    default:
      throw new Error(`Unsupported in-package work observation reference: ${ref.kind}`);
  }
  return { ...ref, scope, locator };
}

/**
 * Returns one required imported value keyed by its source id.
 *
 * @param records Imported values keyed by source id.
 * @param sourceId Source id to resolve.
 * @param label Record-family label used in diagnostics.
 * @returns Imported value.
 * @throws Error when the source id was not exported.
 */
function requiredMapValue<T>(records: ReadonlyMap<string, T>, sourceId: string, label: string): T {
  const record = records.get(sourceId);
  if (record === undefined) {
    throw new Error(`${label} references missing exported state: ${sourceId}`);
  }
  return record;
}

/**
 * Rewrites portable evidence references through imported canonical lineage.
 *
 * @param refs Evidence references from an export.
 * @param context Imported canonical lineage maps.
 * @returns Evidence refs with direct workspace refs rewritten.
 */
function rewriteEvidenceRefs(
  refs: EvidenceBundleRecord['redactedEvidenceRefs'],
  context: ImportRemintContext
): EvidenceBundleRecord['redactedEvidenceRefs'] {
  return refs.map((ref) => {
    let rewritten = ref.ref;
    switch (ref.kind) {
      case 'workspace':
        if (ref.ref !== context.report.exportedWorkspaceId) {
          throw new Error(`Evidence ref references missing exported workspace: ${ref.ref}`);
        }
        rewritten = context.targetWorkspaceId;
        break;
      case 'thread':
        rewritten = requiredMapValue(context.threadIds, ref.ref, 'thread');
        break;
      case 'turn':
      case 'worker':
        rewritten = requiredMapValue(context.turnIds, ref.ref, 'turn');
        break;
      case 'goal':
        rewritten = ref.ref;
        break;
      case 'artifact':
        rewritten = requiredMapValue(context.artifactIds, ref.ref, 'artifact');
        break;
      case 'item':
        rewritten = requiredMapValue(context.itemIds, ref.ref, 'item');
        break;
      case 'agent-session':
        rewritten = requiredMapValue(context.agentSessionIds, ref.ref, 'AgentSession');
        break;
    }
    return rewritten === ref.ref ? ref : { ...ref, ref: rewritten };
  });
}

/**
 * Rewrites direct workspace URI references when an import remints the workspace id.
 *
 * @param value Reference string from an exported record.
 * @param sourceWorkspaceId Workspace id recorded in the export.
 * @param targetWorkspaceId Workspace id used for imported records.
 * @returns Reference with a rewritten workspace URI prefix when applicable.
 */
function rewriteWorkspaceReference(
  value: string,
  sourceWorkspaceId: string,
  targetWorkspaceId: string
): string {
  const sourcePrefix = `workspace://${sourceWorkspaceId}/`;

  return value.startsWith(sourcePrefix)
    ? `workspace://${targetWorkspaceId}/${value.slice(sourcePrefix.length)}`
    : value;
}

/**
 * Rewrites stable ids embedded in a redacted JSON snapshot without changing its structure.
 *
 * @param value Snapshot value to rewrite.
 * @param replacements Source and imported id pairs.
 * @returns Snapshot value with every embedded source id replaced.
 */
function rewriteJsonStringReferences(
  value: unknown,
  replacements: readonly (readonly [string, string])[]
): unknown {
  if (typeof value === 'string') {
    return replacements.reduce(
      (rewritten, [source, target]) => rewritten.replaceAll(source, target),
      value
    );
  }
  if (Array.isArray(value)) {
    return value.map((entry) => rewriteJsonStringReferences(entry, replacements));
  }
  if (typeof value === 'object' && value !== null) {
    return Object.fromEntries(
      Object.entries(value).map(([key, entry]) => [
        key,
        rewriteJsonStringReferences(entry, replacements),
      ])
    );
  }
  return value;
}

/**
 * Rewrites a top-level `workspaceId` field in redacted summary objects.
 *
 * @param value Summary value from an exported record.
 * @param sourceWorkspaceId Workspace id recorded in the export.
 * @param targetWorkspaceId Workspace id used for imported records.
 * @returns Summary with a rewritten workspace id field when applicable.
 */
function rewriteWorkspaceIdField(
  value: unknown,
  sourceWorkspaceId: string,
  targetWorkspaceId: string
): unknown {
  if (typeof value !== 'object' || value === null) {
    return value;
  }

  const record = value as Record<string, unknown>;
  return record.workspaceId === sourceWorkspaceId
    ? { ...record, workspaceId: targetWorkspaceId }
    : value;
}

/** Rejects absolute, linked-platform, and traversal-bearing portable paths. */
function assertPortableWorkspaceFilePath(path: string): void {
  if (
    path.startsWith('/') ||
    path.includes('\\') ||
    path.includes('\0') ||
    path.split('/').some((segment) => !segment || segment === '.' || segment === '..')
  ) {
    throw new Error(`Portable workspace file path is invalid: ${path}`);
  }
}

/**
 * Returns one exact file captured by export verification.
 *
 * @param files Verified export contents keyed by inventory path.
 * @param exportPath Required export-relative path.
 * @returns Verified file text.
 * @throws Error when the required path was not inventoried.
 */
function requiredExportFile(files: ReadonlyMap<string, string>, exportPath: string): string {
  const text = files.get(exportPath);
  if (text === undefined) {
    throw new Error(`Required export file is missing from inventory: ${exportPath}`);
  }
  return text;
}

/**
 * Reads one import JSON record and rejects unsupported record-level features before schema parsing.
 *
 * @param files Verified export contents keyed by inventory path.
 * @param exportPath Export-relative path used in diagnostics.
 * @returns Parsed JSON value.
 * @throws Error when the record declares required features this importer does not support.
 */
function readImportJson(files: ReadonlyMap<string, string>, exportPath: string): unknown {
  const record = JSON.parse(requiredExportFile(files, exportPath)) as unknown;
  rejectUnsupportedRecordFeatures(record, exportPath);

  return record;
}

/**
 * Parses source Threads from verified export bytes for import and current audience admission.
 *
 * @param files Exact verified export contents; source files are never reopened.
 * @returns Canonical source Threads, without reminting their identities or audience.
 * @throws Error when required Thread content or supported record semantics cannot be parsed.
 */
export function readWorkspaceExportThreads(files: ReadonlyMap<string, string>): Thread[] {
  return readImportJsonl(files, 'records/threads.jsonl').map((record) =>
    ThreadSchema.parse(record)
  );
}

/**
 * Reads one import JSONL file and rejects unsupported record-level features before schema parsing.
 *
 * @param files Verified export contents keyed by inventory path.
 * @param exportPath Export-relative path used in diagnostics.
 * @returns Parsed JSON values.
 * @throws Error when any record declares required features this importer does not support.
 */
function readImportJsonl(files: ReadonlyMap<string, string>, exportPath: string): unknown[] {
  const text = requiredExportFile(files, exportPath).trim();
  const records = text ? text.split('\n').map((line) => JSON.parse(line) as unknown) : [];
  return records.map((record, index) => {
    rejectUnsupportedRecordFeatures(record, `${exportPath}:${index + 1}`);

    return record;
  });
}

/**
 * Reads one optional import JSONL file with record-level required-feature enforcement.
 *
 * @param files Verified export contents keyed by inventory path.
 * @param exportPath Export-relative path used in diagnostics.
 * @returns Parsed JSON values, or an empty array when the file is absent.
 * @throws Error when any present record declares required features this importer does not support.
 */
function readOptionalImportJsonl(
  files: ReadonlyMap<string, string>,
  exportPath: string
): unknown[] {
  return files.has(exportPath) ? readImportJsonl(files, exportPath) : [];
}

/**
 * Rejects imported records that require semantics this importer has not explicitly implemented.
 *
 * @param record Imported raw JSON record.
 * @param exportPath Export-relative path used in diagnostics.
 * @throws Error when `requiredFeatures` is malformed or unsupported.
 */
function rejectUnsupportedRecordFeatures(record: unknown, exportPath: string): void {
  if (typeof record !== 'object' || record === null || !('requiredFeatures' in record)) {
    return;
  }

  const requiredFeatures = (record as { requiredFeatures?: unknown }).requiredFeatures;
  if (
    requiredFeatures === undefined ||
    (Array.isArray(requiredFeatures) && requiredFeatures.length === 0)
  ) {
    return;
  }
  if (
    !Array.isArray(requiredFeatures) ||
    !requiredFeatures.every(
      (feature): feature is string => typeof feature === 'string' && feature.length > 0
    )
  ) {
    throw new Error(`Invalid requiredFeatures in ${exportPath}.`);
  }

  const supportedRecordFeatures = new Set([
    'evidence.bundle.v1',
    'runtime.evidence.v1',
    'worker.runtime-provenance.v1',
    'openkit.work-observations.v1',
  ]);
  const unsupported = requiredFeatures.filter((feature) => !supportedRecordFeatures.has(feature));
  if (unsupported.length > 0) {
    throw new Error(`Unsupported requiredFeatures in ${exportPath}: ${unsupported.join(', ')}`);
  }
}

/** Computes a SHA-256 content digest for one text payload. */
function digestText(text: string): string {
  return `sha256:${createHash('sha256').update(text).digest('hex')}`;
}

/** Reconstructs ordinary checkpoints; retained Goal lineage has no deleted owner to validate. */
function readWorkerRuntimeControlState(context: ImportRemintContext) {
  const exported = readOptionalImportJsonl(context.files, 'records/worker-turn-checkpoints.jsonl')
    .map((record) => ExportedWorkerCheckpointSchema.parse(record))
    .filter((record) => record.goalId === null);
  const workerCheckpoints = exported.map((parsed) => {
    const threadId = requiredMapValue(context.threadIds, parsed.threadId, 'thread');
    const turnId = requiredMapValue(context.turnIds, parsed.turnId, 'turn');
    return ExportedWorkerCheckpointSchema.parse({
      ...parsed,
      workspaceId: context.targetWorkspaceId,
      threadId,
      turnId,
      workerSessionId:
        parsed.workerSessionId === null
          ? null
          : requiredMapValue(
              context.agentSessionIds,
              parsed.workerSessionId,
              'checkpoint AgentSession'
            ),
      checkpointId: `${context.targetWorkspaceId}:${threadId}:${turnId}`,
    });
  });
  context.workerCheckpointIds = new Map(
    exported.map((row, index) => [row.checkpointId, workerCheckpoints[index]!.checkpointId])
  );
  const mcpToolSchemaSnapshots = readOptionalImportJsonl(
    context.files,
    'records/mcp-tool-schema-snapshots.jsonl'
  ).map((record) =>
    ExportedMcpToolSchemaSnapshotSchema.parse({
      ...ExportedMcpToolSchemaSnapshotSchema.parse(record),
      workspaceId: context.targetWorkspaceId,
    })
  );
  return { workerCheckpoints, mcpToolSchemaSnapshots };
}

/** Retains immutable Plan bytes and historical ids, reminting only ordinary Workspace/Thread/Turn owners. */
function readCurrentGoalImportState(context: ImportRemintContext) {
  const text = context.files.get('records/goal-state.json');
  const shape = z.object({
    goals: z.array(GoalRecordSchema),
    cards: z.array(GoalCardSchema),
    versions: z.array(GoalPlanVersionSchema),
    tasks: z.array(GoalTaskLinkSchema),
    terminalFacts: z.array(TaskTerminalFactSchema),
  });
  const source = shape.parse(
    text ? JSON.parse(text) : { goals: [], cards: [], versions: [], tasks: [], terminalFacts: [] }
  );
  for (const goal of source.goals)
    assertPortableWorkspaceOwner(goal.workspaceId, context.report.exportedWorkspaceId, 'Goal');
  for (const fact of source.terminalFacts)
    assertPortableWorkspaceOwner(
      fact.workspaceId,
      context.report.exportedWorkspaceId,
      'Task terminal fact'
    );
  const goals = source.goals.map((goal) => ({
    ...goal,
    workspaceId: context.targetWorkspaceId,
    threadId: requiredMapValue(context.threadIds, goal.threadId, 'Coordinator Thread'),
    changeRevision: goal.changeRevision + 1,
  }));
  const ids = new Set(goals.map((goal) => goal.goalId));
  for (const record of [...source.cards, ...source.versions, ...source.tasks])
    if (!ids.has(record.goalId)) throw new Error('Imported Goal child has no exported Goal owner.');
  for (const goal of goals)
    for (const pointer of [goal.activePlanVersionId, goal.proposedPlanVersionId])
      if (
        pointer &&
        !source.versions.some(
          (version) => version.planVersionId === pointer && version.goalId === goal.goalId
        )
      )
        throw new Error('Imported Goal Plan pointer has no exact exported version.');
  for (const version of source.versions)
    if (
      JSON.stringify(version.commitment) !== version.bytes ||
      `sha256:${createHash('sha256').update(version.bytes).digest('hex')}` !== version.digest
    )
      throw new Error('Imported Plan bytes or digest changed.');
  return {
    goals,
    cards: source.cards,
    versions: source.versions,
    tasks: source.tasks.map((link) => ({
      ...link,
      threadId: context.threadIds.get(link.threadId) ?? link.threadId,
    })),
    terminalFacts: source.terminalFacts.map((fact) => ({
      ...fact,
      workspaceId: context.targetWorkspaceId,
      // Preserve missing ordinary owners as opaque lineage without inventing replacement history.
      threadId: context.threadIds.get(fact.threadId) ?? fact.threadId,
      id: context.turnIds.get(fact.id) ?? fact.id,
    })),
  };
}
