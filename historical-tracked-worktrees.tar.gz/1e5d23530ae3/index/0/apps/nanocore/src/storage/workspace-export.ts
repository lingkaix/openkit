import { createHash } from 'node:crypto';
import {
  constants,
  copyFileSync,
  lstatSync,
  mkdirSync,
  readdirSync,
  rmSync,
  writeFileSync,
} from 'node:fs';
import { dirname, join, relative, sep } from 'node:path';
import {
  parseWorkspaceDataSourceCatalog,
  parseWorkspaceExportManifest,
  type RequiredFeatureId,
  WORKSPACE_EXPORT_FORMAT_VERSION,
  WorkspaceConfigSchema,
  type WorkspaceExportManifest,
} from '@openkit/config-schema';
import {
  deriveEntityId,
  ItemSchema,
  KnowledgeEntrySchema,
  ThreadSchema,
  TurnSchema,
} from '@openkit/protocol';
import { z } from 'zod';
import type { ResolvedAgentSetupRecord } from '../agents/setup-ledger.js';
import {
  AGENT_RESOURCE_CATALOG_EXPORT_PATH,
  emptyPortableAgentResourceCatalog,
  WORKSPACE_EXPORT_CATALOG_FEATURE,
  type WorkspaceCatalogExportProjection,
} from '../catalog/catalog-portability.js';
import { parseJsoncObject } from '../config/jsonc.js';
import { artifactFilePayloadPath, verifyArtifactFilePayload } from './artifacts/file-records.js';
import {
  isSupportedWorkObservationType,
  parseWorkObservationRecord,
  type WorkObservationRecord,
} from './work-observations.js';
import { assertWorkspaceArchiveFilePath } from './workspace-archive.js';
import {
  artifactContentFileName,
  assertSafeWorkspacePathSegment,
  type CaptureCoverageBinding,
  CaptureCoverageBindingSchema,
  listUnresolvedUserInputRequestItemIds,
  measureCanonicalFile,
  parseCanonicalWorkspaceHistory,
  projectWorkspaceSystemRecord,
  readCanonicalFile,
  readCanonicalTextFile,
} from './workspace-file-records.js';
import {
  parseWorkspaceRetrievalTraceFile,
  type WorkspacePortableFileState,
  writeWorkspacePortableExportState,
} from './workspace-portable-file-state.js';

/** Exported text material captured for one workspace knowledge source. */
export interface ExportedKnowledgeSourceMaterial {
  /** Source id that owns the material. */
  sourceId: string;
  /** Captured source text content. */
  content: string;
}

/** File name for the root workspace export manifest. */
export const WORKSPACE_EXPORT_MANIFEST_FILE = 'openkit-workspace-export.json';

/** Retired record paths rejected by the current workspace export format. */
export const UNSUPPORTED_WORKSPACE_EXPORT_RECORD_PATHS = [
  'records/injection-plans.jsonl',
  'records/injection-receipts.jsonl',
  'catalog/catalog.json',
  'records/knowledge-retrieval-traces.jsonl',
] as const;

/** Workspace SQLite tables whose portable row families are covered by workspace export/import. */
export const WORKSPACE_EXPORT_PORTABLE_WORKSPACE_SQLITE_TABLES = [
  'goals',
  'goal_cards',
  'goal_plan_versions',
  'goal_card_tasks',
  'task_turn_terminal_facts',
  'artifact_reviews',
  'audit_events',
  'backend_workspace_handles',
  'capability_calls',
  'evidence_bundles',
  'generative_presentations',
  'mcp_tool_schema_snapshots',
  'permission_decisions',
  'resolved_agent_setups',
  'runtime_evidence',
  'usage_records',
  'vault_use_records',
  'worker_output_manifests',
  'workspace_apply_plans',
  'worker_turn_checkpoints',
  'workspace_apply_results',
  'workspace_change_sets',
  'workspace_input_snapshots',
  'workspace_materialization_records',
  'workspace_quarantine_records',
  'workspace_reconciliation_records',
  'staged_workspace_reviews',
  'thread_material_bindings',
  'workspace_material_revisions',
  'workspace_materials',
] as const;

/** Workspace SQLite tables intentionally excluded from portable workspace export/import. */
export const WORKSPACE_EXPORT_NON_PORTABLE_WORKSPACE_SQLITE_TABLES = [
  {
    table: 'idempotency_requests',
    reason: 'short-lived request replay state is local to the source workspace',
  },
  {
    table: 'pending_requests',
    reason:
      'pending-request lifecycle stays in the workspace database and has no portable export family',
  },
  {
    table: 'workspace_filesystem_staging_roots',
    reason: 'host-local apply staging paths are not portable export history',
  },
  {
    table: 'workspace_snapshot_collections',
    reason:
      'exact collection replay and private candidate bytes belong to the source storage attachment',
  },
  {
    table: 'workspace_snapshot_cursors',
    reason:
      'accepted snapshot and capture cursor require the source storage attachment and private scan store',
  },
] as const;

/** Input for offline workspace export verification. */
export interface VerifyWorkspaceExportTreeInput {
  /** Export root directory to verify. */
  exportRoot: string;
  /** Required-feature ids supported by the verifier. */
  supportedFeatures?: readonly string[];
}

/** Result returned by offline workspace export verification. */
export interface VerifiedWorkspaceExportTree {
  /** Parsed export manifest. */
  manifest: WorkspaceExportManifest;
  /** Exact manifest text parsed by this verification. */
  manifestText: string;
  /** Inventory files whose bytes and digests were checked. */
  checkedFiles: string[];
  /** Exact inventory file contents consumed by import after this verification. */
  fileContents: ReadonlyMap<string, string>;
  /** Exact restricted original bytes, kept separate from canonical UTF-8 records. */
  binaryFileContents: ReadonlyMap<string, Uint8Array>;
  /** Verified large Artifact payload paths, never loaded into UTF-8 or binary body maps. */
  artifactPayloadFiles: ReadonlyMap<string, string>;
  /** Digest of the exact manifest bytes parsed by this verification. */
  manifestDigest: string;
}

/** Input for writing one workspace export tree. */
export interface WriteWorkspaceExportTreeInput {
  /** Current source root required when canonical Artifacts own file-backed originals. */
  sourceWorkspaceRoot?: string;
  /** Trusted current administrator eligibility for including private project history; never caller input. */
  administratorEligible?: boolean;
  /** Export root directory to populate. */
  exportRoot: string;
  /** Stable export record id. */
  exportId: string;
  /** Source deployment id recorded in the manifest lineage. */
  sourceDeploymentId: string;
  /** Export creation timestamp. */
  createdAt: string;
  /** Workspace record to export. */
  workspace: { id: string; [key: string]: unknown };
  /** Thread records to export. */
  threads: readonly unknown[];
  /** Turn records to export. */
  turns: readonly unknown[];
  /** Knowledge records to export. */
  knowledge: readonly unknown[];
  /** Full append-order item revision history to export. */
  itemRevisions: readonly unknown[];
  /** Artifacts to export with metadata and content kept in separate files. */
  artifacts: readonly unknown[];
  /** Artifact review decisions to export. */
  artifactReviews: readonly unknown[];
  /** Raw Thread-to-Material binding owners including private request proof. */
  threadMaterialBindings: readonly unknown[];
  /** Raw immutable Material revision owners including private request proof. */
  workspaceMaterialRevisions: readonly unknown[];
  /** Raw Workspace Material owners including private request proof. */
  workspaceMaterials: readonly unknown[];
  /** Durable AgentSessions to export. */
  agentSessions: readonly unknown[];
  /** Retained turn event logs keyed by turn id. */
  turnEvents: readonly (readonly [string, readonly unknown[]])[];
  /** Authoritative workspace files not owned by canonical protocol records. */
  portableFileState?: WorkspacePortableFileState;
  /** Knowledge source identity records to export as line-oriented records. */
  knowledgeSources?: readonly unknown[];
  /** Knowledge source text materials to export as evidence files. */
  knowledgeSourceMaterials?: readonly ExportedKnowledgeSourceMaterial[];
  /** Non-secret workspace vault reference records to export. */
  vaultReferences?: readonly unknown[];
  /** Non-secret workspace vault grant records to export. */
  vaultGrants?: readonly unknown[];
  /** Non-secret injection plan records linked to workspace vault grants. */
  vaultInjectionPlans?: readonly unknown[];
  /** Non-secret injection receipt records linked to exported injection plans. */
  vaultInjectionReceipts?: readonly unknown[];
  /** Non-secret workspace vault use records to export. */
  vaultUseRecords?: readonly unknown[];
  /** Workspace-scoped audit events to export as line-oriented records. */
  auditEvents?: readonly unknown[];
  /** Workspace-scoped capability calls to export as line-oriented records. */
  capabilityCalls?: readonly unknown[];
  /** Workspace-scoped evidence bundles to export as line-oriented records. */
  evidenceBundles?: readonly unknown[];
  /** Committed restricted originals keyed by bundle id and relative evidence path. */
  restrictedEvidenceFiles?: ReadonlyMap<string, Uint8Array>;
  /** Workspace-scoped runtime evidence to export as line-oriented records. */
  runtimeEvidence?: readonly unknown[];
  /** Product-safe normalized runtime provenance indexes keyed by source bundle id. */
  runtimeProvenanceIndexes?: ReadonlyMap<string, string>;
  /** Committed Turn observation JSONL keyed by its owning Turn id. */
  turnObservations?: ReadonlyMap<string, string>;
  /** Immutable historical capture bindings, separate from public Turn projections. */
  turnCaptureCoverage?: ReadonlyMap<string, CaptureCoverageBinding>;
  /** Workspace-scoped usage records to export as line-oriented records. */
  usageRecords?: readonly unknown[];
  /** Workspace-owned data source catalog to export. */
  dataSourceCatalog?: unknown;
  /** Workspace-scoped Git push records to export as line-oriented records. */
  gitPushRecords?: readonly unknown[];
  /** Resolved agent setup records to export as line-oriented records. */
  resolvedAgentSetups?: readonly unknown[];
  /** Redacted Agent Environment Package snapshots to export as line-oriented records. */
  agentEnvironmentPackageSnapshots?: readonly unknown[];
  /** Workspace repository resources to export as unbound metadata. */
  workspaceRepositories?: readonly unknown[];
  /** Durable workspace sync input snapshots to export as line-oriented records. */
  workspaceInputSnapshots?: readonly unknown[];
  /** Durable workspace sync materialization records to export as line-oriented records. */
  workspaceMaterializationRecords?: readonly unknown[];
  /** Durable workspace sync backend handles to export as line-oriented records. */
  backendWorkspaceHandles?: readonly unknown[];
  /** Durable worker output manifests to export as line-oriented records. */
  workerOutputManifests?: readonly unknown[];
  /** Durable workspace sync change sets to export as line-oriented records. */
  workspaceChangeSets?: readonly unknown[];
  /** Durable staged workspace review rows to export as line-oriented records. */
  stagedWorkspaceReviews?: readonly unknown[];
  /** Durable workspace apply plan rows to export as line-oriented records. */
  workspaceApplyPlans?: readonly unknown[];
  /** Durable workspace apply result rows to export as line-oriented records. */
  workspaceApplyResults?: readonly unknown[];
  /** Durable workspace reconciliation rows to export as line-oriented records. */
  workspaceReconciliationRecords?: readonly unknown[];
  /** Durable workspace quarantine rows to export as line-oriented records. */
  workspaceQuarantineRecords?: readonly unknown[];
  /** Workspace-scoped permission decision rows to export as line-oriented records. */
  permissionDecisions?: readonly unknown[];
  /** Current Goal and Task-terminal records, separate from local Pending Request authority. */
  goalState?: unknown;
  /** Worker checkpoint rows to export as line-oriented records. */
  workerCheckpoints?: readonly unknown[];
  /** MCP tool schema snapshots to export as line-oriented records. */
  mcpToolSchemaSnapshots?: readonly unknown[];
  /** Portable Light App identity rows. */
  lightApps?: readonly unknown[];
  /** Portable Light App definition rows. */
  lightAppDefinitions?: readonly unknown[];
  /** Portable Light App record rows. */
  lightAppRecords?: readonly unknown[];
  /** Portable Generative UI presentation rows. */
  generativePresentations?: readonly unknown[];
  /** Portable Skill/MCP/plugin catalog projection and retained Skill payloads. */
  agentResourceCatalog?: WorkspaceCatalogExportProjection;
}

/** Input for previewing a workspace import without writing target state. */
export interface DryRunWorkspaceImportInput {
  /** Already verified export tree whose exact bytes are being previewed. */
  verified: VerifiedWorkspaceExportTree;
  /** Returns whether a workspace id already exists in the target deployment. */
  workspaceExists: (workspaceId: string) => boolean;
}

/** Result returned after verifying an export and previewing import collision handling. */
export interface WorkspaceImportDryRunReport {
  /** Operation mode marker. */
  mode: 'dry-run';
  /** Export record id from the verified manifest. */
  exportId: string;
  /** Source workspace handle used to locate the export. */
  sourceWorkspaceId: string;
  /** Workspace id recorded inside the export manifest. */
  exportedWorkspaceId: string;
  /** Verified export manifest. */
  manifest: WorkspaceExportManifest;
  /** Offline verification summary. */
  verification: {
    /** Number of checked inventory files. */
    fileCount: number;
    /** Total checked inventory bytes. */
    totalBytes: number;
    /** Checked inventory file paths. */
    checkedFiles: string[];
  };
  /** Collision preview for the exported workspace id. */
  collision:
    | { status: 'available'; workspaceId: string }
    | { status: 'collides'; workspaceId: string; suggestedWorkspaceId: string };
}

/**
 * Writes one workspace export tree and verifies the result offline.
 *
 * @param input Workspace records and export destination.
 * @returns Parsed manifest plus checked inventory paths.
 * @throws Error when the written tree fails offline verification.
 */
export function writeWorkspaceExportTree(
  input: WriteWorkspaceExportTreeInput
): VerifiedWorkspaceExportTree {
  const history = parseCanonicalWorkspaceHistory({
    workspace: input.workspace,
    threads: input.threads,
    turns: input.turns,
    itemRevisions: input.itemRevisions,
    artifacts: input.artifacts,
    knowledgeSources: input.knowledgeSources,
    agentSessions: input.agentSessions,
    turnEvents: input.turnEvents,
  });
  if (
    !input.administratorEligible &&
    history.threads.some((thread) => thread.visibility === 'private')
  ) {
    throw new Error('Private Thread history requires a separately authorized export.');
  }
  const knowledge = input.knowledge.map((record) => KnowledgeEntrySchema.parse(record));
  const portableFileState = input.portableFileState;
  if (!portableFileState?.workspaceConfig) {
    throw new Error('Workspace export requires config/workspace.jsonc.');
  }
  const workspaceConfig = WorkspaceConfigSchema.parse(
    parseJsoncObject(portableFileState.workspaceConfig, 'config/workspace.jsonc')
  );
  if (workspaceConfig.workspace.name !== history.workspace.name) {
    throw new Error('Workspace config name does not match the public Workspace projection.');
  }
  const unresolvedUserInputRequestIds = listUnresolvedUserInputRequestItemIds(
    history.itemRevisions
  );

  if (unresolvedUserInputRequestIds.length > 0) {
    throw new Error(
      `Workspace export is blocked by unresolved user-input-request Items: ${unresolvedUserInputRequestIds.join(', ')}.`
    );
  }

  for (const artifact of history.artifacts) {
    assertSafeWorkspacePathSegment(artifact.id, 'Artifact id');
  }
  for (const source of history.knowledgeSources) {
    assertSafeWorkspacePathSegment(source.id, 'Knowledge source id');
  }
  for (const material of input.knowledgeSourceMaterials ?? []) {
    assertSafeWorkspacePathSegment(material.sourceId, 'Knowledge source id');
  }

  const rootMetadata = lstatSync(input.exportRoot, { throwIfNoEntry: false });
  if (rootMetadata) {
    throw new Error(`Export root must not already exist: ${input.exportRoot}`);
  }
  const parent = dirname(input.exportRoot);
  const parentMetadata = lstatSync(parent, { throwIfNoEntry: false });
  if (!parentMetadata || parentMetadata.isSymbolicLink() || !parentMetadata.isDirectory()) {
    throw new Error(`Export root parent must be a real directory: ${parent}`);
  }
  mkdirSync(input.exportRoot);
  const publishedObservationBundles = new Set<string>();

  try {
    const recordsRoot = join(input.exportRoot, 'records');

    mkdirSync(recordsRoot, { recursive: true });
    writeJson(
      join(recordsRoot, 'workspace-record.json'),
      projectWorkspaceSystemRecord(history.workspace)
    );
    writeJsonl(join(recordsRoot, 'threads.jsonl'), history.threads);
    writeJsonl(
      join(recordsRoot, 'turns.jsonl'),
      history.turns.map((turn) => {
        const binding = input.turnCaptureCoverage?.get(turn.id);
        return {
          ...turn,
          ...(binding ? { captureCoverage: CaptureCoverageBindingSchema.parse(binding) } : {}),
          ...(input.turnObservations?.has(turn.id)
            ? { requiredFeatures: ['openkit.work-observations.v1'] }
            : {}),
        };
      })
    );
    for (const [turnId, text] of input.turnObservations ?? []) {
      const turn = history.turns.find((candidate) => candidate.id === turnId);
      if (!turn) {
        throw new Error(`Work observations reference missing exported Turn: ${turnId}`);
      }
      if (!input.turnCaptureCoverage?.has(turnId)) {
        throw new Error('Work observation export requires historical capture coverage.');
      }
      const rows = parsePortableWorkObservations(text, turnId);
      for (const row of rows) {
        for (const ref of row.refs ?? []) {
          if (
            ref.kind === 'evidence-bundle' &&
            ref.edge === 'publication' &&
            ref.scope.workspaceId === history.workspace.id
          )
            publishedObservationBundles.add(ref.locator);
        }
      }
      const path = join(
        input.exportRoot,
        'workspace-files',
        'threads',
        turn.threadId,
        'turns',
        turnId,
        'observations.jsonl'
      );
      mkdirSync(dirname(path), { recursive: true });
      writeFileSync(path, rows.length ? text.slice(0, text.lastIndexOf('\n') + 1) : '');
    }
    writeJsonl(join(recordsRoot, 'knowledge.jsonl'), knowledge);
    writeJsonl(join(recordsRoot, 'item-revisions.jsonl'), history.itemRevisions, true);
    writeJsonl(join(recordsRoot, 'artifact-reviews.jsonl'), input.artifactReviews);
    writeJsonl(join(recordsRoot, 'thread-material-bindings.jsonl'), input.threadMaterialBindings);
    writeJsonl(
      join(recordsRoot, 'workspace-material-revisions.jsonl'),
      input.workspaceMaterialRevisions
    );
    writeJsonl(join(recordsRoot, 'workspace-materials.jsonl'), input.workspaceMaterials);
    // Portable history cannot carry source-deployment attachment authority.
    writeJsonl(
      join(recordsRoot, 'agent-sessions.jsonl'),
      history.agentSessions.map((session) => ({ ...session, retainedStorage: null }))
    );
    writeJsonl(
      join(recordsRoot, 'turn-events.jsonl'),
      history.turnEvents.flatMap(([, events]) => events)
    );
    writeWorkspacePortableExportState(input.exportRoot, portableFileState);
    for (const artifact of history.artifacts) {
      const artifactRoot = join(input.exportRoot, 'artifacts', artifact.id);
      if (artifact.content.format === 'file') {
        if (!input.sourceWorkspaceRoot) throw new Error('Artifact payload source is unavailable.');
        verifyArtifactFilePayload({
          workspaceRoot: input.sourceWorkspaceRoot,
          artifactId: artifact.id,
          version: artifact.version,
          byteLength: artifact.content.byteLength,
          contentDigest: artifact.contentDigest,
        });
        const target = artifactFilePayloadPath(input.exportRoot, artifact.id, artifact.version);
        mkdirSync(dirname(target), { recursive: true });
        copyFileSync(
          artifactFilePayloadPath(input.sourceWorkspaceRoot, artifact.id, artifact.version),
          target,
          constants.COPYFILE_EXCL
        );
        writeJson(join(artifactRoot, 'artifact.json'), artifact);
        continue;
      }
      const filesRoot = join(artifactRoot, 'files');

      mkdirSync(filesRoot, { recursive: true });
      writeJson(join(artifactRoot, 'artifact.json'), {
        ...artifact,
        content: { format: artifact.content.format },
      });
      writeFileSync(
        join(filesRoot, artifactContentFileName(artifact.content.format)),
        artifact.content.body
      );
    }
    if (history.knowledgeSources.length) {
      writeJsonl(join(recordsRoot, 'knowledge-sources.jsonl'), history.knowledgeSources);
    }
    if (input.knowledgeSourceMaterials?.length) {
      const sourcesById = new Map(history.knowledgeSources.map((source) => [source.id, source]));

      for (const material of input.knowledgeSourceMaterials) {
        const path = join(
          input.exportRoot,
          'sources',
          'materials',
          material.sourceId,
          'content.txt'
        );
        const source = sourcesById.get(material.sourceId);

        if (!source) {
          throw new Error(
            `Knowledge source material references missing source: ${material.sourceId}`
          );
        }

        mkdirSync(dirname(path), { recursive: true });
        writeFileSync(path, material.content);
        const derivedPath = join(
          input.exportRoot,
          'sources',
          'derived',
          material.sourceId,
          'text.json'
        );

        mkdirSync(dirname(derivedPath), { recursive: true });
        writeJson(derivedPath, {
          id: `${material.sourceId}:text`,
          workspaceId: source.workspaceId,
          sourceId: material.sourceId,
          kind: 'text',
          path: `sources/derived/${material.sourceId}/text.json`,
          materialPath: `sources/materials/${material.sourceId}/content.txt`,
          contentDigest: source.contentDigest,
          sourceContentDigest: source.contentDigest,
          createdAt: source.createdAt,
        });
      }
    }
    if (input.auditEvents?.length) {
      writeJsonl(join(recordsRoot, 'audit-events.jsonl'), input.auditEvents);
    }
    if (input.capabilityCalls?.length) {
      writeJsonl(join(recordsRoot, 'capability-calls.jsonl'), input.capabilityCalls);
    }
    const evidenceBundles = (input.evidenceBundles ?? []).filter(
      (record) =>
        !isRecord(record) ||
        record.sourceKind !== 'work-observation-body' ||
        (typeof record.id === 'string' &&
          publishedObservationBundles.has(record.id) &&
          (record.importStatus === 'promoted' || record.importStatus === 'expired'))
    );
    if (evidenceBundles.length) {
      writeJsonl(join(recordsRoot, 'evidence-bundles.jsonl'), evidenceBundles);
    }
    for (const [path, bytes] of input.restrictedEvidenceFiles ?? []) {
      assertWorkspaceArchiveFilePath(path);
      const slash = path.indexOf('/');
      const bundleId = path.slice(0, slash);
      const ref = path.slice(slash + 1);
      const bundle = evidenceBundles.find((record) => isRecord(record) && record.id === bundleId);
      if (
        !isRestrictedPortableEvidenceBundle(bundle) ||
        bundle.importStatus === 'expired' ||
        !Array.isArray(bundle.rawEvidenceRefs) ||
        !bundle.rawEvidenceRefs.some((value) => isRecord(value) && value.ref === ref)
      ) {
        throw new Error(`Restricted export content has no retained owner: ${path}`);
      }
      const target = join(input.exportRoot, 'workspace-files', 'evidence', 'backend', path);
      mkdirSync(dirname(target), { recursive: true });
      writeFileSync(target, bytes);
    }
    if (input.runtimeEvidence?.length) {
      writeJsonl(join(recordsRoot, 'runtime-evidence.jsonl'), input.runtimeEvidence);
    }
    for (const [bundleId, text] of input.runtimeProvenanceIndexes ?? []) {
      assertSafeWorkspacePathSegment(bundleId, 'Evidence bundle id');
      const bundle = evidenceBundles.find(
        (record): record is Record<string, unknown> =>
          isRecord(record) &&
          record.id === bundleId &&
          record.sourceKind === 'worker-runtime-provenance-index'
      );
      if (
        !bundle ||
        !Array.isArray(bundle.contentDigests) ||
        bundle.contentDigests.length !== 1 ||
        bundle.contentDigests[0] !== digestText(text)
      ) {
        throw new Error(`Runtime provenance index does not match its evidence bundle: ${bundleId}`);
      }
      const path = join(
        input.exportRoot,
        'workspace-files',
        'evidence',
        'bundles',
        bundleId,
        'runtime-origin-index.jsonl'
      );
      mkdirSync(dirname(path), { recursive: true });
      writeFileSync(path, text);
    }
    if (input.usageRecords?.length) {
      writeJsonl(join(recordsRoot, 'usage-records.jsonl'), input.usageRecords);
    }
    if (input.vaultReferences?.length) {
      writeJsonl(join(recordsRoot, 'vault-references.jsonl'), input.vaultReferences);
    }
    if (input.vaultGrants?.length) {
      writeJsonl(join(recordsRoot, 'vault-grants.jsonl'), input.vaultGrants);
    }
    writeJsonl(join(recordsRoot, 'vault-injection-plans.jsonl'), input.vaultInjectionPlans ?? []);
    writeJsonl(
      join(recordsRoot, 'vault-injection-receipts.jsonl'),
      input.vaultInjectionReceipts ?? []
    );
    if (input.vaultUseRecords?.length) {
      writeJsonl(join(recordsRoot, 'vault-use-records.jsonl'), input.vaultUseRecords);
    }
    if (input.dataSourceCatalog) {
      writeJson(
        join(recordsRoot, 'data-sources.json'),
        parseWorkspaceDataSourceCatalog(input.dataSourceCatalog)
      );
    }
    if (input.gitPushRecords?.length) {
      writeJsonl(join(recordsRoot, 'git-push-records.jsonl'), input.gitPushRecords);
    }
    if (input.resolvedAgentSetups?.length) {
      writeJsonl(
        join(recordsRoot, 'resolved-agent-setups.jsonl'),
        input.resolvedAgentSetups.map(toExportedResolvedAgentSetupRecord)
      );
    }
    if (input.agentEnvironmentPackageSnapshots?.length) {
      writeJsonl(
        join(recordsRoot, 'agent-environment-package-snapshots.jsonl'),
        input.agentEnvironmentPackageSnapshots.map((value) => {
          const record = value as { snapshot?: unknown; retainedSnapshot?: unknown };
          return Object.getOwnPropertyDescriptor(record, 'retainedSnapshot')?.enumerable === false
            ? { ...record, snapshot: record.retainedSnapshot }
            : value;
        })
      );
    }
    if (input.workspaceRepositories?.length) {
      writeJsonl(join(recordsRoot, 'workspace-repositories.jsonl'), input.workspaceRepositories);
    }
    if (input.workspaceInputSnapshots?.length) {
      writeJsonl(
        join(recordsRoot, 'workspace-input-snapshots.jsonl'),
        input.workspaceInputSnapshots
      );
    }
    if (input.workspaceMaterializationRecords?.length) {
      writeJsonl(
        join(recordsRoot, 'workspace-materialization-records.jsonl'),
        input.workspaceMaterializationRecords
      );
    }
    if (input.backendWorkspaceHandles?.length) {
      writeJsonl(
        join(recordsRoot, 'backend-workspace-handles.jsonl'),
        input.backendWorkspaceHandles
      );
    }
    if (input.workerOutputManifests?.length) {
      writeJsonl(join(recordsRoot, 'worker-output-manifests.jsonl'), input.workerOutputManifests);
    }
    if (input.workspaceChangeSets?.length) {
      writeJsonl(join(recordsRoot, 'workspace-change-sets.jsonl'), input.workspaceChangeSets);
    }
    if (input.stagedWorkspaceReviews?.length) {
      writeJsonl(join(recordsRoot, 'staged-workspace-reviews.jsonl'), input.stagedWorkspaceReviews);
    }
    if (input.workspaceApplyPlans?.length) {
      writeJsonl(join(recordsRoot, 'workspace-apply-plans.jsonl'), input.workspaceApplyPlans);
    }
    if (input.workspaceApplyResults?.length) {
      writeJsonl(join(recordsRoot, 'workspace-apply-results.jsonl'), input.workspaceApplyResults);
    }
    if (input.workspaceReconciliationRecords?.length) {
      writeJsonl(
        join(recordsRoot, 'workspace-reconciliation-records.jsonl'),
        input.workspaceReconciliationRecords
      );
    }
    if (input.workspaceQuarantineRecords?.length) {
      writeJsonl(
        join(recordsRoot, 'workspace-quarantine-records.jsonl'),
        input.workspaceQuarantineRecords
      );
    }
    if (input.permissionDecisions?.length) {
      writeJsonl(join(recordsRoot, 'permission-decisions.jsonl'), input.permissionDecisions);
    }
    if (input.goalState) writeJson(join(recordsRoot, 'goal-state.json'), input.goalState);
    if (input.workerCheckpoints?.length) {
      writeJsonl(join(recordsRoot, 'worker-turn-checkpoints.jsonl'), input.workerCheckpoints);
    }
    if (input.mcpToolSchemaSnapshots?.length) {
      writeJsonl(
        join(recordsRoot, 'mcp-tool-schema-snapshots.jsonl'),
        input.mcpToolSchemaSnapshots
      );
    }
    if (input.lightApps?.length) {
      writeJsonl(join(recordsRoot, 'light-apps.jsonl'), input.lightApps);
    }
    if (input.lightAppDefinitions?.length) {
      writeJsonl(join(recordsRoot, 'light-app-definitions.jsonl'), input.lightAppDefinitions);
    }
    if (input.lightAppRecords?.length) {
      writeJsonl(join(recordsRoot, 'light-app-records.jsonl'), input.lightAppRecords);
    }
    if (input.generativePresentations?.length) {
      writeJsonl(
        join(recordsRoot, 'generative-presentations.jsonl'),
        input.generativePresentations
      );
    }
    const catalogExport = input.agentResourceCatalog ?? {
      catalog: emptyPortableAgentResourceCatalog(),
      payloads: [],
    };
    writeJson(join(recordsRoot, 'agent-resource-catalog.json'), catalogExport.catalog);
    for (const captured of catalogExport.payloads) {
      assertWorkspaceArchiveFilePath(captured.path);
      const payloadPath = join(input.exportRoot, captured.path);
      mkdirSync(dirname(payloadPath), { recursive: true });
      writeJson(payloadPath, captured.payload);
    }

    const contentInventory = listRegularExportFiles(input.exportRoot)
      .filter((path) => path !== WORKSPACE_EXPORT_MANIFEST_FILE)
      .map((path) => {
        assertWorkspaceArchiveFilePath(path);
        const filePath = join(input.exportRoot, path);
        const measured = measureCanonicalFile(filePath);
        return {
          path,
          digest: measured.contentDigest,
          bytes: measured.byteLength,
        };
      })
      .sort((left, right) => left.path.localeCompare(right.path));
    const requiredFeatures: RequiredFeatureId[] = [WORKSPACE_EXPORT_CATALOG_FEATURE];
    if (
      input.lightApps?.length ||
      input.lightAppDefinitions?.length ||
      input.lightAppRecords?.length
    ) {
      requiredFeatures.push('workspace.generative-kernel.v1');
    }
    if (input.generativePresentations?.length) {
      requiredFeatures.push('workspace.generative-ui.native-v1');
    }
    if (input.turnObservations?.size) {
      requiredFeatures.push('openkit.work-observations.v1');
    }
    const manifest: WorkspaceExportManifest = {
      schemaVersion: 1,
      recordType: 'workspace-export',
      id: input.exportId,
      ownerScope: 'workspace',
      lineage: { workspaceId: history.workspace.id },
      createdAt: input.createdAt,
      updatedAt: input.createdAt,
      contentDigest: digestText(JSON.stringify(contentInventory)),
      redactionLevel: 'metadata',
      sensitivity: 'internal',
      requiredFeatures,
      extensions: {},
      sourceDeploymentId: input.sourceDeploymentId,
      workspaceId: history.workspace.id,
      exportCreatedAt: input.createdAt,
      exportFormatVersion: WORKSPACE_EXPORT_FORMAT_VERSION,
      contentInventory,
    };

    writeJson(join(input.exportRoot, WORKSPACE_EXPORT_MANIFEST_FILE), manifest);
    return verifyWorkspaceExportTree({
      exportRoot: input.exportRoot,
      supportedFeatures: [
        WORKSPACE_EXPORT_CATALOG_FEATURE,
        'workspace.generative-kernel.v1',
        'workspace.generative-ui.native-v1',
        'openkit.work-observations.v1',
      ],
    });
  } catch (error) {
    rmSync(input.exportRoot, { recursive: true, force: true });
    throw error;
  }
}

/** Identifies the retained original families admitted by portable evidence policy. */
function isRestrictedPortableEvidenceBundle(record: unknown): record is Record<string, unknown> {
  return (
    isRecord(record) &&
    (record.sourceKind === 'worker-runtime-provenance-raw' ||
      record.sourceKind === 'work-observation-body')
  );
}

/** Validates committed portable rows through the owning schema without interpreting torn tails. */
export function parsePortableWorkObservations(
  text: string,
  turnId: string
): WorkObservationRecord[] {
  const committed = text.slice(0, text.lastIndexOf('\n') + 1);
  const rows: WorkObservationRecord[] = [];
  const ids = new Set<string>();
  for (const line of committed.split('\n').slice(0, -1)) {
    const row = parseWorkObservationRecord(JSON.parse(line));
    if (!isSupportedWorkObservationType(row.type)) {
      throw new Error(`Unsupported work observation type: ${row.type}`);
    }
    if (row.turnId !== turnId || row.seq !== rows.length + 1 || ids.has(row.id)) {
      throw new Error('Invalid portable work observation sequence or ownership.');
    }
    ids.add(row.id);
    rows.push(row);
  }
  return rows;
}

/** Returns whether one unknown value is a non-array object. */
function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/**
 * Verifies a workspace export and previews import id collision without writing state.
 *
 * @param input Export root and target workspace lookup.
 * @returns Dry-run report with verification and collision summary.
 * @throws Error when the export tree fails offline verification.
 */
export function dryRunWorkspaceImport(
  input: DryRunWorkspaceImportInput
): WorkspaceImportDryRunReport {
  const verified = input.verified;
  const workspaceId = verified.manifest.workspaceId;
  const collision = input.workspaceExists(workspaceId)
    ? {
        status: 'collides' as const,
        workspaceId,
        suggestedWorkspaceId: deriveEntityId('ws', ['imported', workspaceId, 1]),
      }
    : { status: 'available' as const, workspaceId };

  return {
    mode: 'dry-run',
    exportId: verified.manifest.id,
    sourceWorkspaceId: verified.manifest.workspaceId,
    exportedWorkspaceId: workspaceId,
    manifest: verified.manifest,
    verification: {
      fileCount: verified.checkedFiles.length,
      totalBytes: verified.manifest.contentInventory.reduce(
        (total, entry) => total + entry.bytes,
        0
      ),
      checkedFiles: verified.checkedFiles,
    },
    collision,
  };
}

/**
 * Verifies one workspace export tree without consulting source deployment state.
 *
 * @param input Export root and supported feature set.
 * @returns Parsed manifest plus checked file paths.
 * @throws Error when the manifest, inventory, digest, bytes, or file set is invalid.
 */
export function verifyWorkspaceExportTree(
  input: VerifyWorkspaceExportTreeInput
): VerifiedWorkspaceExportTree {
  const rootMetadata = lstatSync(input.exportRoot, { throwIfNoEntry: false });
  if (!rootMetadata || rootMetadata.isSymbolicLink() || !rootMetadata.isDirectory()) {
    throw new Error(`Export root must be a real directory: ${input.exportRoot}`);
  }
  const manifestPath = join(input.exportRoot, WORKSPACE_EXPORT_MANIFEST_FILE);
  const manifestText = readCanonicalTextFile(manifestPath);
  const originalManifest = JSON.parse(manifestText);
  const manifest = parseWorkspaceExportManifest(originalManifest, {
    supportedFeatures: [
      WORKSPACE_EXPORT_CATALOG_FEATURE,
      'workspace.generative-kernel.v1',
      'workspace.generative-ui.native-v1',
      'openkit.work-observations.v1',
      ...(input.supportedFeatures ?? []),
    ],
  });
  for (const entry of manifest.contentInventory) {
    if (
      /^workspace-files\/threads\/[^/]+\/turns\/[^/]+\/observations\.jsonl$/.test(entry.path) &&
      !manifest.requiredFeatures.includes('openkit.work-observations.v1')
    ) {
      throw new Error('Work observations require the portable required-feature declaration.');
    }
  }
  for (const unsupportedPath of UNSUPPORTED_WORKSPACE_EXPORT_RECORD_PATHS) {
    if (manifest.contentInventory.some((entry) => entry.path === unsupportedPath)) {
      throw new Error(`Unsupported workspace export record path: ${unsupportedPath}`);
    }
  }
  if (
    manifest.contentInventory.some(
      (entry) =>
        entry.path.startsWith('catalog/plugin-snapshots/') ||
        entry.path.startsWith('catalog/mcp-data/')
    )
  ) {
    throw new Error('Workspace export must not include original plugin roots or MCP package data.');
  }
  if (
    manifest.requiredFeatures.includes(WORKSPACE_EXPORT_CATALOG_FEATURE) &&
    !manifest.contentInventory.some((entry) => entry.path === AGENT_RESOURCE_CATALOG_EXPORT_PATH)
  ) {
    throw new Error('Workspace export is missing records/agent-resource-catalog.json.');
  }
  if (manifest.contentDigest !== digestText(JSON.stringify(originalManifest.contentInventory))) {
    throw new Error('Workspace export manifest content digest does not match its inventory.');
  }
  const expected = new Map(manifest.contentInventory.map((entry) => [entry.path, entry]));
  const fileContents = new Map<string, string>();
  const binaryFileContents = new Map<string, Uint8Array>();
  const artifactPayloadFiles = new Map<string, string>();
  const actual = listRegularExportFiles(input.exportRoot).filter(
    (path) => path !== WORKSPACE_EXPORT_MANIFEST_FILE
  );
  for (const entry of manifest.contentInventory) {
    assertWorkspaceArchiveFilePath(entry.path);
  }
  for (const path of actual) {
    assertWorkspaceArchiveFilePath(path);
  }

  for (const path of actual) {
    if (!expected.has(path)) {
      throw new Error(`Export file missing from inventory: ${path}`);
    }
  }

  for (const entry of manifest.contentInventory) {
    if (/^artifacts\/[^/]+\/versions\/[1-9][0-9]*\/payload$/.test(entry.path)) {
      const path = join(input.exportRoot, entry.path);
      const measured = measureCanonicalFile(path);
      if (measured.byteLength !== entry.bytes || measured.contentDigest !== entry.digest) {
        throw new Error('Artifact export payload integrity is inconsistent.');
      }
      artifactPayloadFiles.set(entry.path, path);
      continue;
    }
    const bytes = readCanonicalFile(join(input.exportRoot, entry.path));
    if (bytes.byteLength !== entry.bytes) {
      throw new Error(`Size mismatch for export file ${entry.path}`);
    }
    if (`sha256:${createHash('sha256').update(bytes).digest('hex')}` !== entry.digest) {
      throw new Error(`Digest mismatch for export file ${entry.path}`);
    }
    if (entry.path.startsWith('workspace-files/evidence/backend/')) {
      binaryFileContents.set(entry.path, bytes);
    } else {
      const text = bytes.toString('utf8');
      if (!Buffer.from(text).equals(bytes))
        throw new Error(`Invalid UTF-8 canonical export file: ${entry.path}`);
      fileContents.set(entry.path, text);
    }
  }
  verifyPortableRetrievalTraceFiles(fileContents, manifest.workspaceId);

  const itemRevisionText = fileContents.get('records/item-revisions.jsonl');
  const itemRevisions =
    itemRevisionText === undefined || itemRevisionText.length === 0
      ? []
      : itemRevisionText
          .trimEnd()
          .split('\n')
          .map((line) => ItemSchema.parse(JSON.parse(line)));
  const unresolvedUserInputRequestIds = listUnresolvedUserInputRequestItemIds(itemRevisions);

  if (unresolvedUserInputRequestIds.length > 0) {
    throw new Error(
      `Workspace export verification found unresolved user-input-request Items: ${unresolvedUserInputRequestIds.join(', ')}.`
    );
  }

  return {
    manifest,
    manifestText,
    checkedFiles: manifest.contentInventory.map((entry) => entry.path).sort(),
    fileContents,
    binaryFileContents,
    artifactPayloadFiles,
    manifestDigest: digestText(manifestText),
  };
}

/** Validates every query-owned trace path against the exported canonical Thread and Turn graph. */
function verifyPortableRetrievalTraceFiles(
  files: ReadonlyMap<string, string>,
  workspaceId: string
): void {
  const traceFiles = [...files].filter(([path]) => path.includes('/retrieval-traces/'));
  if (traceFiles.length === 0) return;
  const threadOwnerSchema = z
    .object({ id: ThreadSchema.shape.id, workspaceId: ThreadSchema.shape.workspaceId })
    .strip();
  const turnOwnerSchema = z
    .object({
      id: TurnSchema.shape.id,
      threadId: TurnSchema.shape.threadId,
      workspaceId: TurnSchema.shape.workspaceId,
    })
    .strip();
  const threads = readJsonlForVerification(files, 'records/threads.jsonl').map((value) =>
    threadOwnerSchema.parse(value)
  );
  const turns = readJsonlForVerification(files, 'records/turns.jsonl').map((value) =>
    turnOwnerSchema.parse(value)
  );
  const threadIds = new Set(threads.map((thread) => thread.id));
  const turnsById = new Map(turns.map((turn) => [turn.id, turn] as const));
  for (const [exportPath, text] of traceFiles) {
    const match =
      /^workspace-files\/(threads\/[^/]+\/(?:turns\/[^/]+\/)?retrieval-traces\/[^/]+\.json)$/.exec(
        exportPath
      );
    if (!match) throw new Error(`Invalid portable retrieval trace path: ${exportPath}`);
    const relativePath = match[1]!;
    parseWorkspaceRetrievalTraceFile(relativePath, text, workspaceId);
    const parts = relativePath.split('/');
    const threadId = parts[1]!;
    if (!threadIds.has(threadId)) {
      throw new Error('Portable retrieval trace has no exported Thread owner.');
    }
    if (parts[2] === 'turns') {
      const turn = turnsById.get(parts[3]!);
      if (!turn || turn.threadId !== threadId || turn.workspaceId !== workspaceId) {
        throw new Error('Portable retrieval trace has no exported Turn owner.');
      }
    }
  }
}

/** Parses one required JSONL family from the verified byte map without reopening files. */
function readJsonlForVerification(files: ReadonlyMap<string, string>, path: string): unknown[] {
  const text = files.get(path);
  if (text === undefined) throw new Error(`Workspace export is missing ${path}.`);
  return text.length === 0
    ? []
    : text
        .trimEnd()
        .split('\n')
        .map((line) => JSON.parse(line));
}

/**
 * Maps a resolved setup ledger record to its workspace export wire format.
 *
 * @param value Resolved setup ledger record.
 * @returns Export record whose runtime capability list does not collide with export feature guards.
 */
function toExportedResolvedAgentSetupRecord(value: unknown): unknown {
  const record = value as ResolvedAgentSetupRecord;

  return {
    id: record.id,
    workspaceId: record.workspaceId,
    turnId: record.turnId,
    requestId: record.requestId,
    agentId: record.agentId,
    logicalModelId: record.logicalModelId,
    runtimeKind: record.runtimeKind,
    runtimeAdapter: record.runtimeAdapter,
    setupRequiredFeatures: record.requiredFeatures,
    setup: record.setup,
    createdAt: record.createdAt,
  };
}

/**
 * Lists regular files under one export root using slash-separated relative paths.
 *
 * @param root Export root.
 * @param directory Current directory during recursion.
 * @returns Sorted relative file paths.
 */
function listRegularExportFiles(root: string, directory: string = root): string[] {
  const files: string[] = [];

  for (const entry of readdirSync(directory)) {
    const path = join(directory, entry);
    const relativePath = relative(root, path).split(sep).join('/');
    const stat = lstatSync(path);

    if (stat.isSymbolicLink()) {
      throw new Error(`Export tree must not contain symlinks: ${relativePath}`);
    }
    if (stat.isDirectory()) {
      files.push(...listRegularExportFiles(root, path));
      continue;
    }
    if (!stat.isFile()) {
      throw new Error(`Export tree contains unsupported file type: ${relativePath}`);
    }
    files.push(relativePath);
  }

  return files.sort();
}

/** Writes one JSON file with a trailing newline. */
function writeJson(path: string, value: unknown): void {
  writeFileSync(path, `${JSON.stringify(value, null, 2)}\n`);
}

/**
 * Returns one exact file captured by export verification.
 *
 * @param files Verified export contents keyed by inventory path.
 * @param exportPath Required export-relative path.
 * @returns Verified file text.
 * @throws Error when the required path was not inventoried.

/**
 * Writes line-oriented JSON records.
 *
 * @param path Destination file path.
 * @param records Records to serialize.
 * @param preserveOrder Whether append order is authoritative.
 */
function writeJsonl(path: string, records: readonly unknown[], preserveOrder = false): void {
  const ordered = preserveOrder
    ? records
    : [...records].sort((left, right) => recordSortKey(left).localeCompare(recordSortKey(right)));
  const lines = ordered.map((record) => JSON.stringify(record));
  writeFileSync(path, lines.length > 0 ? `${lines.join('\n')}\n` : '');
}

/** Returns a stable-enough sort key for exported JSONL records. */
function recordSortKey(record: unknown): string {
  if (typeof record !== 'object' || record === null) {
    return JSON.stringify(record);
  }
  if ('id' in record) {
    return String((record as { id?: unknown }).id ?? '');
  }
  if ('turnId' in record && 'sequence' in record) {
    const event = record as { turnId?: unknown; sequence?: unknown };
    return `${String(event.turnId ?? '')}:${String(event.sequence ?? '').padStart(16, '0')}`;
  }
  return JSON.stringify(record);
}

/** Computes a SHA-256 content digest for one text payload. */
function digestText(text: string): string {
  return `sha256:${createHash('sha256').update(text).digest('hex')}`;
}
