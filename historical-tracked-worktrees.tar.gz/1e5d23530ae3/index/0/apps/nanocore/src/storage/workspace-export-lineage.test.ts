import { createHash } from 'node:crypto';
import { existsSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { RuntimeEvidenceRecordSchema } from '@openkit/app-api-schemas';
import { AgentEnvironmentPackageSchema } from '@openkit/config-schema';
import { PROTOCOL_VERSION } from '@openkit/protocol';
import { describe, expect, it, vi } from 'vitest';
import {
  ArtifactReviewFollowUpRequestSchema,
  deriveArtifactReviewFollowUpTurnId,
  deriveArtifactReviewId,
  deriveArtifactReviewWorkerRequestId,
  serializeArtifactReviewFollowUpRequest,
} from '../artifact-reviews.js';
import {
  importWorkspaceCapabilityUsageLedger,
  listWorkspaceCapabilityCalls,
} from '../capability/usage-ledger.js';
import {
  buildWorkerContextPackageWorkspaceInput,
  createWorkerContextPackageFiles,
  createWorkerContextPackagePolicyDigest,
  createWorkerContextPackageTrace,
  parseWorkerContextPackageTrace,
  serializeWorkerContextPackageTrace,
} from '../context/worker-context-package.js';
import {
  createStructuredWorkerDelegationRequest,
  serializeStructuredWorkerDelegationRequest,
} from '../internal-agents/delegation.js';
import {
  importAgentEnvironmentPackageSnapshots,
  requireAgentEnvironmentPackageSnapshot,
  snapshotDigest,
} from '../runtime/aep-snapshot-ledger.js';
import {
  importMcpToolSchemaSnapshots,
  listExportableMcpToolSchemaSnapshots,
  mcpToolSchemaContentDigest,
} from '../runtime/mcp-tool-schema-snapshots.js';
import { createWorkerRuntimeProvenanceEvidenceId } from '../runtime/runtime-evidence.js';
import {
  importWorkspaceApplyResults,
  listExportableWorkspaceApplyResults,
} from '../runtime/workspace-apply-results.js';
import {
  importWorkspaceReconciliationRecords,
  listWorkspaceReconciliationRecords,
} from '../runtime/workspace-reconciliation-records.js';
import { createTestAgentSetup } from '../test-support/agent-environment.js';
import { resolveAgentEnvironmentPackage } from '../test-support/prepared-agent-environment.js';
import { openWorkspaceDb } from './db.js';
import { applyScopedMigrations } from './migrate.js';
import {
  verifyWorkspaceExportTree,
  WORKSPACE_EXPORT_MANIFEST_FILE,
  type WriteWorkspaceExportTreeInput,
  writeWorkspaceExportTree,
} from './workspace-export.js';
import {
  artifactReferenceItemId,
  parseOwnedKnowledgeEntry,
  serializeUserAuthoredKnowledgePage,
} from './workspace-file-records.js';
import {
  readWorkspaceImportSnapshot,
  verifyImportedWorkerContextPackageSnapshot,
} from './workspace-import.js';
import { writeWorkspacePortableFileState } from './workspace-portable-file-state.js';

const timestamp = '2026-07-12T00:00:00.000Z';
const source = {
  approvalId: 'apr_source',
  approvalItemId: 'it_00000000-0000-75b1-b567-8dba93fffe22',
  artifactId: 'ar_00000000-0000-7e0d-8050-96f36ec9a01f',
  goalId: 'goal_source',
  grantId: 'grant_00000000-0000-71be-bfe5-1605cc1e0b9b',
  itemId: 'it_00000000-0000-7cab-8553-ff29f1f63940',
  intentItemId: 'it_00000000-0000-7142-be4d-40072e2d9c43',
  planItemId: 'it_00000000-0000-71d5-ae7d-8065ab8c1eac',
  sessionId: 'as_00000000-0000-7d81-8a02-21a51fa74819',
  taskId: 'task_source',
  threadId: 'th_00000000-0000-76e4-9cab-bf0f18349249',
  turnId: 'tu_00000000-0000-72a5-8d51-50bb4c19b084',
  workspaceId: 'ws_00000000-0000-71b1-9af2-985861a05396',
} as const;
const targetWorkspaceId = 'ws_00000000-0000-7a88-ae6e-4c70ca9fabb5';

/** Extends fixed descriptive source objects; the declared backend summary remains an open consumed map. */
function annotateSyncSource(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(annotateSyncSource);
  if (value && typeof value === 'object')
    return Object.fromEntries([
      ...Object.entries(value).map(([key, child]) => [
        key,
        key === 'backendHandleSummary' ? child : annotateSyncSource(child),
      ]),
      ['futureAnnotation', 'portable observation'],
    ]);
  return value;
}

/** Builds one export containing every auxiliary record family that refers to canonical history. */
function createLineageExportInput(
  missing?:
    | 'aep-item'
    | 'aep-session'
    | 'capability-thread'
    | 'checkpoint-turn'
    | 'evidence-goal'
    | 'git-approval'
    | 'goal-item'
    | 'permission-approval'
    | 'repository-grant'
    | 'resolved-turn'
    | 'runtime-turn'
    | 'sync-artifact'
    | 'usage-session'
    | 'vault-approval'
    | 'vault-session',
  captureValue: 'off' | 'on' = 'off'
): WriteWorkspaceExportTreeInput {
  const agentSetup = createTestAgentSetup();
  const item = {
    id: source.itemId,
    workspaceId: source.workspaceId,
    threadId: source.threadId,
    turnId: source.turnId,
    type: 'assistant-message',
    status: 'completed',
    text: 'Portable lineage.',
    createdAt: timestamp,
    completedAt: timestamp,
  };
  const approvalItem = {
    id: source.approvalItemId,
    workspaceId: source.workspaceId,
    threadId: source.threadId,
    turnId: source.turnId,
    type: 'approval-request',
    status: 'completed',
    causationId: source.itemId,
    approvalRequestId: source.approvalId,
    title: 'Approve portable lineage',
    description: 'Approve the portable operation.',
    kind: 'permission',
    createdAt: timestamp,
    completedAt: timestamp,
  };
  const intentItem = {
    id: source.intentItemId,
    workspaceId: source.workspaceId,
    threadId: source.threadId,
    turnId: source.turnId,
    type: 'user-message',
    actor: { kind: 'user', id: 'usr_00000000-0000-7431-921d-ea7bcc58a6f2' },
    status: 'completed',
    text: 'Keep lineage portable.',
    createdAt: timestamp,
    completedAt: timestamp,
  };
  const artifact = {
    id: source.artifactId,
    workspaceId: source.workspaceId,
    threadId: source.threadId,
    turnId: source.turnId,
    kind: 'summary',
    title: 'Portable artifact',
    status: 'ready',
    summary: 'Portable artifact.',
    version: 1,
    content: { format: 'markdown', body: '# Portable' },
    contentDigest: `sha256:${createHash('sha256').update('# Portable', 'utf8').digest('hex')}`,
    lastMutationRequestId: 'request_source',
    origin: {
      kind: 'turn-output',
      threadId: source.threadId,
      turnId: source.turnId,
      requestId: 'request_source',
    },
    createdAt: timestamp,
    updatedAt: timestamp,
  };
  const artifactReferenceItem = {
    id: artifactReferenceItemId(source.artifactId, source.turnId),
    workspaceId: source.workspaceId,
    threadId: source.threadId,
    turnId: source.turnId,
    type: 'artifact-reference',
    status: 'completed',
    artifactId: artifact.id,
    artifactVersion: artifact.version,
    lastMutationRequestId: artifact.lastMutationRequestId,
    title: artifact.title,
    summary: artifact.summary,
    createdAt: timestamp,
    completedAt: timestamp,
  };
  const planItem = {
    id: source.planItemId,
    workspaceId: source.workspaceId,
    threadId: source.threadId,
    turnId: source.turnId,
    type: 'plan',
    status: 'completed',
    title: 'Portable goal plan',
    summary: 'Keep lineage portable.',
    steps: [{ id: source.taskId, title: 'Portable task', status: 'pending' }],
    createdAt: timestamp,
    completedAt: timestamp,
  };
  const turn = {
    id: source.turnId,
    workspaceId: source.workspaceId,
    threadId: source.threadId,
    triggerActor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' } as const,
    items: [item, planItem, artifactReferenceItem, approvalItem, intentItem],
    status: 'completed',
    error: null,
    configVersion: null,
    startedAt: timestamp,
    completedAt: timestamp,
    durationMs: 1,
  };
  const environmentPackage = resolveAgentEnvironmentPackage({
    captureCoverage: { scope: 'server', value: captureValue },
    agent: {
      id: 'agent_codex_host',
      name: 'Codex Agent',
      kind: 'coder',
      status: 'enabled',
      modelId: null,
      skillIds: [],
      profiles: [
        {
          id: 'default',
          displayName: 'Default',
          instructionsRef: null,
          modelId: null,
          skillIds: [],
          capabilityIds: [],
        },
      ],
      defaultProfileId: 'default',
      capabilities: [],
      sandboxSummary: null,
      config: {
        adapterType: 'codex',
        command: null,
        baseUrl: null,
        workspaceRoot: '/workspace',
        environment: {},
        capabilities: [],
      },
    },
    agentSetup,
    agentSessionId: source.sessionId,
    triggerActor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
    userId: 'usr_00000000-0000-7000-8000-000000000001',
    backend: {
      kind: 'openshell',
    },
    requestId: 'request_source',
    turn,
    turnInput: 'Verify portability.',
    workspaceCwd: '/workspace',
    workspaceRoots: [],
  });
  environmentPackage.scope.itemId =
    missing === 'aep-item' ? 'it_00000000-0000-7cd6-8d25-15aa6e49eadb' : source.itemId;
  const session = {
    id: source.sessionId,
    agentId: 'agent_codex_host',
    workspaceId: source.workspaceId,
    threadId: source.threadId,
    status: 'idle',
    message: null,
    sandboxSummary: {
      access: 'read-write',
      workspaceRootRefs: ['repo'],
      summary: 'Source host workspace.',
    },
    configVersion: 7,
    environmentPackageSnapshotId: environmentPackage.snapshotId,
    policySnapshotId: 'policy_source',
    sessionCompatibilityKey: 'sha256:source-session-compatibility',
    stale: false,
    workspaceRoots: [
      {
        id: 'repo',
        sourceKind: 'host-dir',
        sourcePath: '/private/source/workspace',
        workerPath: '/workspace/repo',
        access: 'read-write',
      },
    ],
    createdAt: timestamp,
    updatedAt: timestamp,
  };
  return {
    exportRoot: join(mkdtempSync(join(tmpdir(), 'openkit-workspace-lineage-')), 'export'),
    exportId: 'wsexp_00000000-0000-79ba-8f8a-90eaf5674095',
    sourceDeploymentId: 'dep_00000000-0000-7737-8fe7-61ca07c79d45',
    createdAt: timestamp,
    workspace: {
      id: source.workspaceId,
      name: 'Lineage workspace',
      kind: 'general',
      status: 'active',
      counts: { threadCount: 1, artifactCount: 1, knowledgeEntryCount: 0 },
      createdAt: timestamp,
      updatedAt: timestamp,
    },
    portableFileState: {
      claims: new Map(),
      conflicts: new Map(),
      nativeKnowledgePages: new Map(),
      observations: new Map(),
      retrievalTraceFiles: new Map(),
      workerContextPackageFiles: new Map(),
      workspaceConfig: JSON.stringify({
        schemaVersion: 1,
        workspace: { name: 'Lineage workspace', defaultAgentId: null },
      }),
      workspaceSchema: null,
    },
    threads: [
      {
        id: source.threadId,
        workspaceId: source.workspaceId,
        name: 'Lineage thread',
        preview: 'Lineage thread',
        entryPath: 'conversation',
        visibility: 'workspace',
        status: 'active',
        createdAt: timestamp,
        updatedAt: timestamp,
      },
    ],
    turns: [turn],
    knowledge: [],
    dataSourceCatalog: {
      schemaVersion: 1,
      requiredFeatures: [],
      extensions: {},
      sources: [
        {
          id: 'portable-repository',
          kind: 'git',
          displayName: 'Portable repository source',
          locator: { url: 'https://example.com/openkit.git' },
          access: 'read-only',
          sensitivity: 'internal',
          vaultGrantRef: source.grantId,
          allowedSlotKinds: ['worktree'],
          syncHints: {},
          status: 'active',
          requiredFeatures: [],
          extensions: {},
        },
      ],
    },
    itemRevisions: [item, planItem, artifactReferenceItem, approvalItem, intentItem],
    artifacts: [artifact],
    artifactReviews: [],
    threadMaterialBindings: [],
    workspaceMaterialRevisions: [],
    workspaceMaterials: [],
    agentSessions: [session],
    turnEvents: [],
    resolvedAgentSetups: [
      {
        id: 'ras_source',
        workspaceId: source.workspaceId,
        turnId:
          missing === 'resolved-turn' ? 'tu_00000000-0000-7577-9378-7e96d0d15fd2' : source.turnId,
        requestId: 'request_source',
        agentId: 'agent_codex_host',
        logicalModelId: agentSetup.logicalModels.preferredLogicalModelId,
        runtimeKind: 'codex',
        runtimeAdapter: 'codex-app-server',
        requiredFeatures: [],
        setup: {
          manifest: {
            id: agentSetup.manifest.id,
            requiredFeatures: agentSetup.manifest.requiredFeatures,
            runtime: agentSetup.manifest.runtime,
            sandbox: {
              credentialDeclarations: agentSetup.manifest.sandbox.credentialDeclarations,
              network: agentSetup.manifest.sandbox.network,
            },
          },
          logicalModels: {
            preferredLogicalModelId: agentSetup.logicalModels.preferredLogicalModelId,
            allowed: agentSetup.logicalModels.allowed.map((model) => ({
              id: model.id,
              capabilities: model.capabilities,
              modelFamilyId: model.modelFamilyId,
            })),
          },
        },
        createdAt: timestamp,
      },
    ],
    agentEnvironmentPackageSnapshots: [
      {
        snapshotId: environmentPackage.snapshotId,
        workspaceId: source.workspaceId,
        turnId: source.turnId,
        threadId: source.threadId,
        agentSessionId:
          missing === 'aep-session' ? 'as_00000000-0000-7fdd-8f71-4a23eb7a922b' : source.sessionId,
        agentId: environmentPackage.agent.agentId,
        packageId: environmentPackage.packageId,
        runtimeKind: environmentPackage.agent.runtimeKind,
        backendKind: environmentPackage.backend.preferred,
        contentDigest: createHash('sha256')
          .update(JSON.stringify(environmentPackage))
          .digest('hex'),
        snapshot: environmentPackage,
        createdAt: timestamp,
      },
    ],
    capabilityCalls: [
      {
        id: 'cap_00000000-0000-711a-9c64-db220d6b90dc',
        workspaceId: source.workspaceId,
        threadId:
          missing === 'capability-thread'
            ? 'th_00000000-0000-70ca-938d-c2a0530f9882'
            : source.threadId,
        turnId: source.turnId,
        itemId: source.itemId,
        agentId: 'agent_codex_host',
        agentSessionId: source.sessionId,
        requestId: null,
        sourceIds: [],
        capabilityId: 'runtime.worker_turn',
        status: 'succeeded',
        summary: 'Portable capability call.',
        errorCode: null,
        startedAt: timestamp,
        completedAt: timestamp,
        family: 'runtime',
        operation: 'worker.checkpoint.terminal',
        providerRef: null,
        serviceRef: null,
        redactionClass: 'metadata-only',
      },
    ],
    usageRecords: [
      {
        id: 'use_00000000-0000-7833-a8fc-60af429f21b9',
        workspaceId: source.workspaceId,
        responsibleUserId: 'usr_00000000-0000-7431-921d-ea7bcc58a6f2',
        threadId: source.threadId,
        turnId: source.turnId,
        itemId: source.itemId,
        capabilityCallId: 'cap_00000000-0000-711a-9c64-db220d6b90dc',
        requestId: null,
        agentId: 'agent_codex_host',
        agentSessionId:
          missing === 'usage-session'
            ? 'as_00000000-0000-7fdd-8f71-4a23eb7a922b'
            : source.sessionId,
        sourceIds: [],
        category: 'runtime',
        unit: 'sandbox_sessions',
        quantity: 1,
        modelId: null,
        providerRef: null,
        source: 'worker-checkpoint-terminal',
        recordedAt: timestamp,
      },
    ],
    evidenceBundles: [
      {
        id: 'evb_source',
        workspaceId: source.workspaceId,
        threadId: source.threadId,
        goalId: missing === 'evidence-goal' ? 'goal_missing' : source.goalId,
        turnId: source.turnId,
        agentSessionId: source.sessionId,
        backendType: 'openshell',
        sourceKind: 'worker',
        summary: 'Portable evidence bundle.',
        rawEvidenceRefs: [
          { kind: 'thread', ref: source.threadId },
          { kind: 'turn', ref: source.turnId },
          {
            kind: 'goal',
            ref: missing === 'evidence-goal' ? 'goal_missing' : source.goalId,
          },
          { kind: 'artifact', ref: source.artifactId },
        ],
        redactedEvidenceRefs: [{ kind: 'worker', ref: source.turnId }],
        contentDigests: ['sha256:evidence'],
        retentionClass: 'turn-evidence',
        sensitivityClass: 'product-safe',
        importStatus: 'verified',
        requiredFeatures: ['evidence.bundle.v1'],
        createdAt: timestamp,
      },
    ],
    runtimeEvidence: [
      {
        id: 'rte_source',
        workspaceId: source.workspaceId,
        threadId: source.threadId,
        turnId:
          missing === 'runtime-turn' ? 'tu_00000000-0000-7577-9378-7e96d0d15fd2' : source.turnId,
        goalId: source.goalId,
        taskId: null,
        agentSessionId: source.sessionId,
        backendType: 'openshell',
        backendVersion: null,
        placement: 'local',
        phase: 'teardown',
        summary: 'Portable runtime evidence.',
        policyDigest: null,
        workerImage: null,
        sandboxSummary: null,
        capabilitySummary: null,
        uploadManifest: [],
        downloadManifest: [],
        transcriptSummary: null,
        workspaceChangeSummary: null,
        controlSummary: null,
        outcome: 'succeeded',
        exitCode: 0,
        signal: null,
        stopReason: 'completed',
        errorCode: null,
        errorMessage: null,
        redactedStdoutSummary: null,
        redactedStderrSummary: null,
        evidenceBundleIds: [],
        contentDigests: ['sha256:runtime'],
        requiredFeatures: ['runtime.evidence.v1'],
        createdAt: timestamp,
        startedAt: timestamp,
        completedAt: timestamp,
        collectedAt: timestamp,
      },
    ],
    workerCheckpoints: [
      {
        checkpointId: `${source.workspaceId}:${source.threadId}:${source.turnId}`,
        workspaceId: source.workspaceId,
        threadId: source.threadId,
        turnId:
          missing === 'checkpoint-turn' ? 'tu_00000000-0000-7577-9378-7e96d0d15fd2' : source.turnId,
        goalId: null,
        taskId: null,
        requestId: 'request_source',
        requestInputHash: 'sha256:request-source',
        stage: 'running_worker',
        iteration: 1,
        workerSessionId: missing ? null : source.sessionId,
        contextDigest: 'sha256:context',
        stopReason: null,
        diagnosticsSummary: null,
        replayInstruction: false,
        createdAt: timestamp,
        updatedAt: timestamp,
      },
    ],
    gitPushRecords: [
      {
        id: 'gpr_source',
        workspaceId: source.workspaceId,
        repositoryResourceId: 'repo_source',
        approvalRowId: missing === 'git-approval' ? 'apr_missing' : source.approvalId,
        policyDecisionId: 'pd_00000000-0000-71e9-8af0-d6fdfffbf30e',
        actorId: 'usr_00000000-0000-7000-8000-000000000001',
        remoteSummary: 'Portable repository origin',
        sourceRef: 'HEAD',
        targetBranch: 'main',
        commitIds: ['abc123'],
        reviewIds: [],
        remoteHeadBefore: 'abc000',
        remoteHeadAfter: 'abc123',
        outcome: 'pushed',
        errorSummary: null,
        createdAt: timestamp,
        updatedAt: timestamp,
        requestId: '00000000-0000-4000-8000-000000000001',
      },
    ],
    permissionDecisions: [
      {
        action: 'runtime.launch',
        approvalId: missing === 'permission-approval' ? 'apr_missing' : source.approvalId,
        auditEventId: null,
        contextSummary: {},
        createdAt: timestamp,
        decisionId: 'pd_00000000-0000-71e9-8af0-d6fdfffbf30e',
        enforcementPoint: 'worker.launch',
        ownerScope: 'workspace',
        policyEngineVersion: 'nanocore-policy:v1',
        policySnapshotId: 'policy_source',
        reasonCode: 'approved',
        requiredApprovalKind: 'permission',
        resourceSummary: {},
        result: 'allow',
        subjectSummary: {},
        workspaceId: source.workspaceId,
      },
    ],
    workspaceRepositories: [
      {
        resourceId: 'repo_source',
        type: 'git_repository',
        displayName: 'Portable repository',
        git: {
          authorEmail: null,
          authorName: null,
          allowedPushTargets: ['main'],
          commitOnApply: true,
          protectedBranchPatterns: ['main'],
          requireReviewLinkage: true,
          stagingStrategy: 'staging-root',
          vaultGrantRef:
            missing === 'repository-grant'
              ? 'grant_00000000-0000-7278-b714-46e2d53cb316'
              : source.grantId,
        },
        createdAt: timestamp,
        updatedAt: timestamp,
      },
    ],
    workerOutputManifests: [
      {
        id: 'wom_source',
        workspaceId: source.workspaceId,
        materializationRecordId: 'wmr_source',
        inputSnapshotId: 'wis_source',
        workerSessionId: 'worker_source',
        backendKind: 'openshell',
        strategy: 'git',
        changedPaths: [],
        artifactIds: [
          missing === 'sync-artifact'
            ? 'ar_00000000-0000-7aa2-bfd7-c36b2d13b35a'
            : source.artifactId,
        ],
        logRefs: [],
        testOutputRefs: [],
        ignoredOutputs: [],
        evidenceRefs: [{ kind: 'worker', ref: source.turnId }],
        collectedAt: timestamp,
      },
    ],
    workspaceChangeSets: [
      {
        id: 'wcs_source',
        materializationRecordId: 'wmr_source',
        inputSnapshotId: 'wis_source',
        workspaceId: source.workspaceId,
        resourceId: 'repo_source',
        strategy: 'git',
        base: { commit: 'abc000', contentDigest: null },
        head: { commit: 'abc123', contentDigest: null },
        changedPaths: [],
        patch: null,
        bundle: null,
        artifactIds: [
          missing === 'sync-artifact'
            ? 'ar_00000000-0000-7aa2-bfd7-c36b2d13b35a'
            : source.artifactId,
        ],
        evidenceRefs: [{ kind: 'worker', ref: source.turnId }],
        redaction: { status: 'no-sensitive-content-found', notes: [] },
        createdAt: timestamp,
      },
    ],
    vaultReferences: [
      {
        sourceReferenceId: 'vault_00000000-0000-7845-abcc-649025182be0',
        displayName: 'Portable secret',
        secretKind: 'api-key',
        backendKind: 'encrypted-file',
        createdAt: timestamp,
        updatedAt: timestamp,
      },
    ],
    vaultGrants: [
      {
        grantId: source.grantId,
        issuance: 'target',
        vaultReferenceId: 'vault_00000000-0000-7845-abcc-649025182be0',
        ownerScope: 'workspace',
        workspaceId: source.workspaceId,
        userId: null,
        subjectSummary: null,
        targetAgentId: null,
        targetAgentSessionId:
          missing === 'vault-session'
            ? 'as_00000000-0000-7fdd-8f71-4a23eb7a922b'
            : source.sessionId,
        targetCapabilityId: null,
        allowedInjectionPaths: [],
        lifetime: 'agent-session',
        policyDecisionId: null,
        approvalId: missing === 'vault-approval' ? 'apr_missing' : source.approvalId,
        status: 'active',
        createdAt: timestamp,
        expiresAt: null,
      },
    ],
  };
}

/**
 * Writes and reads one export through the public portability boundary.
 *
 * @param input Complete source export fixture.
 * @returns Reminted import snapshot.
 * @throws Error when export or import validation rejects the fixture.
 */
function importLineage(input: WriteWorkspaceExportTreeInput) {
  const verified = writeWorkspaceExportTree(input);
  return readWorkspaceImportSnapshot({
    verified,
    targetWorkspaceId,
    targetServerId: 'dep_00000000-0000-7000-8000-000000000002',
  });
}

/**
 * Builds one complete source Material, Review, and S39 portability graph.
 *
 * @param followUp Optional exact Artifact Review follow-up fixture.
 * @returns Complete export fixture covering the accepted work-resource lineage.
 * @throws Error when the structured worker request or package fixture cannot be built.
 */
function createWorkResourceLineageExportInput(followUp?: {
  artifactMediaType?: 'text/markdown' | 'text/plain' | 'application/json';
  decisionRequestId?: string;
}): WriteWorkspaceExportTreeInput {
  const input = createLineageExportInput();
  const materialId = 'mat_00000000-0000-7807-b767-6378f3fcdcf3';
  const baseRevisionId = 'mrev_00000000-0000-72e5-99f1-5042ef903012';
  const appliedRevisionId = 'mrev_00000000-0000-713f-80f9-10c92c9be966';
  const baseContent = '# Portable base\n';
  const appliedContent = '# Portable\n';
  const baseContentDigest = `sha256:${createHash('sha256').update(baseContent).digest('hex')}`;
  const appliedContentDigest = `sha256:${createHash('sha256').update(appliedContent).digest('hex')}`;
  const knowledgePageId = 'knowledge_portable_source';
  const knowledgeContent = '# Retained portable knowledge\n\nUse the retained package bytes.\n';
  const knowledgeContentDigest = `sha256:${createHash('sha256')
    .update(knowledgeContent)
    .digest('hex')}`;
  const knowledgeSourceRefs = ['https://example.com/retained-portable-knowledge'];
  const retrievalTraceId = 'krt_00000000-0000-780e-b78f-51422afca1e9';
  const workerRequest = serializeStructuredWorkerDelegationRequest(
    createStructuredWorkerDelegationRequest({
      acceptanceCriteria: ['Preserve the portable Material graph.'],
      constraints: { maxContextTokens: 4_096, maxWorkerIterations: 1 },
      contextRefs: [
        { kind: 'workspace', id: source.workspaceId },
        { kind: 'thread', id: source.threadId },
      ],
      escalationConditions: [],
      expectedArtifacts: [{ kind: 'artifact', description: 'Portable proposal.' }],
      objective: 'Produce one portable Material proposal.',
      resources: [{ kind: 'artifact', reference: source.artifactId, reason: 'Proposal output.' }],
      reviewContext: null,
      reviewPolicy: {
        instructions: 'Review the exact proposal.',
        required: true,
        reviewers: ['human'],
      },
      verification: [{ kind: 'manual', description: 'Inspect the imported graph.' }],
    })
  );
  input.threads = input.threads.map((thread) => ({ ...thread, preview: workerRequest }));
  const sourceThread = input.threads[0]!;
  const requestItem = {
    ...(input.itemRevisions.find(
      (candidate) => (candidate as { id?: string }).id === source.itemId
    ) as Record<string, unknown>),
    type: 'user-message',
    actor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
    text: workerRequest,
  };
  input.itemRevisions = input.itemRevisions.map((candidate) =>
    (candidate as { id?: string }).id === source.itemId ? requestItem : candidate
  );
  input.turns = input.turns.map((candidate) => ({
    ...(candidate as Record<string, unknown>),
    agentId: 'agent_codex_host',
    agentSessionId: source.sessionId,
    items: (candidate as { items: Array<Record<string, unknown>> }).items.map((item) =>
      item.id === source.itemId ? requestItem : item
    ),
  }));
  input.turnEvents = [
    [
      source.turnId,
      [
        {
          protocolVersion: PROTOCOL_VERSION,
          event: 'thread.created',
          sequence: 1,
          requestId: null,
          timestamp,
          workspaceId: source.workspaceId,
          threadId: source.threadId,
          turnId: source.turnId,
          data: { type: 'thread-created', thread: sourceThread },
        },
        {
          protocolVersion: PROTOCOL_VERSION,
          event: 'thread.updated',
          sequence: 2,
          requestId: null,
          timestamp,
          workspaceId: source.workspaceId,
          threadId: source.threadId,
          turnId: source.turnId,
          data: { type: 'thread-updated', thread: sourceThread },
        },
        {
          protocolVersion: PROTOCOL_VERSION,
          event: 'item.completed',
          sequence: 3,
          requestId: null,
          timestamp,
          workspaceId: source.workspaceId,
          threadId: source.threadId,
          turnId: source.turnId,
          data: { type: 'item-completed', itemId: source.itemId, item: requestItem },
        },
        {
          protocolVersion: PROTOCOL_VERSION,
          event: 'item.delta',
          sequence: 4,
          requestId: null,
          timestamp,
          workspaceId: source.workspaceId,
          threadId: source.threadId,
          turnId: source.turnId,
          data: {
            type: 'item-delta',
            itemId: artifactReferenceItemId(source.artifactId, source.turnId),
            itemType: 'artifact-reference',
            deltaKind: 'artifact-updated',
            artifactId: source.artifactId,
          },
        },
      ],
    ],
  ];
  const packageFiles = createWorkerContextPackageFiles({
    contextBudgetTokens: 4_096,
    includedItemIds: [source.itemId],
    knowledgeSelections: [
      {
        content: knowledgeContent,
        contentDigest: knowledgeContentDigest,
        knowledgePageId,
        sourceRefs: knowledgeSourceRefs,
      },
    ],
    materialSelections: [
      {
        bindingMutationRequestId: 'request_material_bind',
        content: baseContent,
        contentDigest: baseContentDigest,
        inclusionReason: 'thread_binding',
        materialId,
        mediaType: 'text/markdown',
        parentRevisionId: null,
        revisionId: baseRevisionId,
        sensitivity: 'internal',
      },
    ],
    threadId: source.threadId,
    turnId: source.turnId,
    workerRequestBytes: workerRequest,
    workerRequestItemId: source.itemId,
    workspaceId: source.workspaceId,
  });
  const snapshotRecord = input.agentEnvironmentPackageSnapshots?.[0];
  if (!snapshotRecord) {
    throw new Error('Work-resource fixture requires one AEP snapshot.');
  }
  const sourceSnapshot = AgentEnvironmentPackageSchema.parse(snapshotRecord.snapshot);
  const snapshot = AgentEnvironmentPackageSchema.parse({
    ...sourceSnapshot,
    workspace: {
      ...sourceSnapshot.workspace,
      inputs: [
        buildWorkerContextPackageWorkspaceInput({
          agentSessionId: source.sessionId,
          packageRootDigest: packageFiles.packageRootDigest,
          threadId: source.threadId,
          turnId: source.turnId,
        }),
      ],
    },
  });
  input.agentEnvironmentPackageSnapshots = [
    {
      ...snapshotRecord,
      contentDigest: createHash('sha256').update(JSON.stringify(snapshot)).digest('hex'),
      snapshot,
    },
  ];
  const trace = createWorkerContextPackageTrace({
    agentSessionId: source.sessionId,
    excludedItems: [],
    goalId: null,
    knowledgeSelectionInput: {
      retrievalTraceRef: {
        scopeId: `retrieval-trace/turn/${source.workspaceId}/${source.threadId}/${source.turnId}`,
        objectId: retrievalTraceId,
      },
    },
    packageFiles,
    packageSnapshotId: snapshot.snapshotId,
    requestId: 'request_source',
    taskId: null,
  });
  const workspaceInputSnapshot = {
    backend: {
      capabilitySummary: [...snapshot.backend.requiredCapabilities],
      kind: 'openshell' as const,
      label: 'openshell worker backend',
    },
    base: { commit: null, contentDigest: packageFiles.packageRootDigest },
    createdAt: timestamp,
    generatedFiles: [],
    id: trace.workspaceInputSnapshotId,
    ignoredPaths: [],
    pathScope: [`context_${source.turnId}`],
    resourceId: `context_${source.turnId}`,
    resourceKind: 'filesystem' as const,
    strategy: 'filesystem' as const,
    workspaceId: source.workspaceId,
    writableRoots: [],
  };
  const workerSessionId = 'worker_source';
  input.workspaceInputSnapshots = [workspaceInputSnapshot];
  input.workspaceMaterializationRecords = [
    {
      backendKind: 'openshell',
      base: workspaceInputSnapshot.base,
      createdAt: timestamp,
      id: trace.workspaceMaterializationRecordId,
      inputSnapshotId: trace.workspaceInputSnapshotId,
      materializedRootRef: `/openkit/sessions/${source.sessionId}/context`,
      packageSnapshotId: snapshot.snapshotId,
      policyDigest: createWorkerContextPackagePolicyDigest({
        backendKind: 'openshell',
        packageSnapshotId: snapshot.snapshotId,
        requiredCapabilities: snapshot.backend.requiredCapabilities,
      }),
      readinessEvidence: [
        { kind: 'backend.ready', ref: 'version:0.0.80' },
        { kind: 'sandbox.created', ref: workerSessionId },
      ],
      strategy: 'filesystem',
      workerSessionId,
      workspaceId: source.workspaceId,
    },
  ];
  input.workspaceMaterials = [
    {
      createdAt: timestamp,
      currentRevisionId: appliedRevisionId,
      kind: 'markdown',
      lastMutationRequestId: 'request_review_accept',
      materialId,
      sensitivity: 'internal',
      title: 'Portable Material',
      updatedAt: timestamp,
      workspaceId: source.workspaceId,
    },
  ];
  input.workspaceMaterialRevisions = [
    {
      authorId: 'usr_00000000-0000-7000-8000-000000000001',
      content: baseContent,
      contentDigest: baseContentDigest,
      createdAt: timestamp,
      createdByRequestId: 'request_material_base',
      materialId,
      mediaType: 'text/markdown',
      parentRevisionId: null,
      revisionId: baseRevisionId,
      workspaceId: source.workspaceId,
    },
    {
      authorId: 'usr_00000000-0000-7000-8000-000000000001',
      content: appliedContent,
      contentDigest: appliedContentDigest,
      createdAt: timestamp,
      createdByRequestId: 'request_review_accept',
      materialId,
      mediaType: 'text/markdown',
      parentRevisionId: baseRevisionId,
      revisionId: appliedRevisionId,
      workspaceId: source.workspaceId,
    },
  ];
  input.threadMaterialBindings = [
    {
      bindingState: 'bound',
      createdAt: timestamp,
      inclusionState: 'included',
      lastMutationRequestId: 'request_review_accept',
      latestQueuedRevisionId: appliedRevisionId,
      materialId,
      threadId: source.threadId,
      updatedAt: timestamp,
      workspaceId: source.workspaceId,
    },
  ];
  input.artifactReviews = [
    {
      appliedMaterialRevisionId: appliedRevisionId,
      artifactId: source.artifactId,
      artifactVersion: 1,
      contentDigest: appliedContentDigest,
      createdAt: timestamp,
      decidedAt: timestamp,
      decision: 'accepted',
      decisionActorId: 'usr_00000000-0000-7000-8000-000000000001',
      decisionRequestId: 'request_review_accept',
      feedback: null,
      followUpTurnId: null,
      materialProposal: { materialId, baseRevisionId, baseContentDigest },
      reviewId: deriveArtifactReviewId(source.workspaceId, source.artifactId, 1),
      sourceAgentId: 'agent_codex_host',
      sourceThreadId: source.threadId,
      sourceTurnId: source.turnId,
      workspaceId: source.workspaceId,
    },
  ];
  input.portableFileState = {
    claims: new Map(),
    conflicts: new Map(),
    nativeKnowledgePages: new Map([[`knowledge/pages/${knowledgePageId}.md`, knowledgeContent]]),
    observations: new Map(),
    retrievalTraceFiles: new Map([
      [
        `threads/${source.threadId}/turns/${source.turnId}/retrieval-traces/${retrievalTraceId}.json`,
        {
          caller: 'task-mode',
          createdAt: timestamp,
          excluded: [],
          notebookRevision: null,
          queryContext: {
            serverId: 'dep_00000000-0000-7737-8fe7-61ca07c79d45',
            workspaceId: source.workspaceId,
            actor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
            threadId: source.threadId,
            turnId: source.turnId,
          },
          requestDigest: `sha256:${createHash('sha256')
            .update('portable Knowledge retrieval')
            .digest('hex')}`,
          retrievalParameters: {
            limit: 5,
            pinnedReferences: [],
            states: ['active'],
            sourceScope: 'workspace',
          },
          selected: [
            {
              contentDigest: knowledgeContentDigest,
              reference: {
                scopeId: `page/workspace/${source.workspaceId}`,
                objectId: knowledgePageId,
              },
              revision: knowledgeContentDigest,
              sourceReferences: knowledgeSourceRefs,
            },
          ],
          sourceScope: `page/workspace/${source.workspaceId}`,
          traceId: retrievalTraceId,
        },
      ],
    ]),
    workerContextPackageFiles: new Map([
      ...packageFiles.files.map(
        (file) =>
          [
            `threads/${source.threadId}/turns/${source.turnId}/context-package/${file.path}`,
            Buffer.from(file.bytes).toString('utf8'),
          ] as const
      ),
      [
        `threads/${source.threadId}/turns/${source.turnId}/context-package.json`,
        serializeWorkerContextPackageTrace(trace),
      ],
    ]),
    workspaceConfig: JSON.stringify({
      schemaVersion: 1,
      workspace: { name: 'Lineage workspace', defaultAgentId: null },
    }),
    workspaceSchema: null,
  };
  if (followUp) {
    const decisionRequestId = followUp.decisionRequestId ?? 'request_review_redo';
    const prefixedImportRequest = decisionRequestId.startsWith('import-lineage:');
    const followUpTurnId = prefixedImportRequest
      ? 'tu_00000000-0000-79a4-aa5f-28ed1f60437c'
      : deriveArtifactReviewFollowUpTurnId(
          source.workspaceId,
          source.artifactId,
          1,
          decisionRequestId
        );
    const workerRequestId = prefixedImportRequest
      ? 'request_follow_up_source'
      : deriveArtifactReviewWorkerRequestId(decisionRequestId);
    const followUpItemId = 'it_00000000-0000-7698-af18-5a72021d626f';
    const followUpRequest = serializeArtifactReviewFollowUpRequest({
      kind: 'artifact-review-follow-up',
      workspaceId: source.workspaceId,
      reviewId: deriveArtifactReviewId(source.workspaceId, source.artifactId, 1),
      artifactId: source.artifactId,
      artifactVersion: 1,
      contentDigest: appliedContentDigest,
      artifactContent: appliedContent,
      artifactMediaType: followUp.artifactMediaType ?? 'text/markdown',
      sourceThreadId: source.threadId,
      sourceTurnId: source.turnId,
      sourceAgentId: 'agent_codex_host',
      materialProposal: { materialId, baseRevisionId, baseContentDigest },
      decision: 'redo',
      feedback: 'Try again.',
      decisionRequestId,
      workerRequestId,
    });
    const followUpItem = {
      id: followUpItemId,
      workspaceId: source.workspaceId,
      threadId: source.threadId,
      turnId: followUpTurnId,
      type: 'user-message',
      status: 'completed',
      actor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
      text: followUpRequest,
      createdAt: timestamp,
      completedAt: timestamp,
    };
    input.itemRevisions = [...input.itemRevisions, followUpItem];
    input.turns = [
      ...input.turns,
      {
        id: followUpTurnId,
        workspaceId: source.workspaceId,
        threadId: source.threadId,
        triggerActor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
        items: [followUpItem],
        status: 'completed',
        error: null,
        configVersion: null,
        agentId: 'agent_codex_host',
        agentSessionId: source.sessionId,
        startedAt: timestamp,
        completedAt: timestamp,
        durationMs: 1,
      },
    ];
    const followUpPackage = createWorkerContextPackageFiles({
      contextBudgetTokens: 4_096,
      includedItemIds: [followUpItemId],
      materialSelections: [
        {
          bindingMutationRequestId: 'request_material_bind',
          content: baseContent,
          contentDigest: baseContentDigest,
          inclusionReason: 'thread_binding',
          materialId,
          mediaType: 'text/markdown',
          parentRevisionId: null,
          revisionId: baseRevisionId,
          sensitivity: 'internal',
        },
      ],
      threadId: source.threadId,
      turnId: followUpTurnId,
      workerRequestBytes: followUpRequest,
      workerRequestItemId: followUpItemId,
      workspaceId: source.workspaceId,
    });
    const followUpSnapshot = AgentEnvironmentPackageSchema.parse({
      ...snapshot,
      snapshotId: 'aepsnap_follow_up_source',
      packageId: 'aepkg_follow_up_source',
      scope: {
        ...snapshot.scope,
        requestId: workerRequestId,
        itemId: followUpItemId,
        turnId: followUpTurnId,
      },
      workspace: {
        ...snapshot.workspace,
        inputs: [
          buildWorkerContextPackageWorkspaceInput({
            agentSessionId: source.sessionId,
            packageRootDigest: followUpPackage.packageRootDigest,
            threadId: source.threadId,
            turnId: followUpTurnId,
          }),
        ],
      },
    });
    input.agentEnvironmentPackageSnapshots = [
      ...(input.agentEnvironmentPackageSnapshots ?? []),
      {
        ...snapshotRecord,
        snapshotId: followUpSnapshot.snapshotId,
        packageId: followUpSnapshot.packageId,
        turnId: followUpTurnId,
        contentDigest: createHash('sha256').update(JSON.stringify(followUpSnapshot)).digest('hex'),
        snapshot: followUpSnapshot,
      },
    ];
    const followUpTrace = createWorkerContextPackageTrace({
      agentSessionId: source.sessionId,
      excludedItems: [],
      goalId: null,
      packageFiles: followUpPackage,
      packageSnapshotId: followUpSnapshot.snapshotId,
      requestId: workerRequestId,
      taskId: null,
    });
    const followUpInputSnapshot = {
      ...workspaceInputSnapshot,
      base: { commit: null, contentDigest: followUpPackage.packageRootDigest },
      id: followUpTrace.workspaceInputSnapshotId,
      pathScope: [`context_${followUpTurnId}`],
      resourceId: `context_${followUpTurnId}`,
    };
    input.workspaceInputSnapshots = [
      ...(input.workspaceInputSnapshots ?? []),
      followUpInputSnapshot,
    ];
    input.workspaceMaterializationRecords = [
      ...(input.workspaceMaterializationRecords ?? []),
      {
        ...(input.workspaceMaterializationRecords?.[0] as Record<string, unknown>),
        base: followUpInputSnapshot.base,
        id: followUpTrace.workspaceMaterializationRecordId,
        inputSnapshotId: followUpTrace.workspaceInputSnapshotId,
        packageSnapshotId: followUpSnapshot.snapshotId,
        policyDigest: createWorkerContextPackagePolicyDigest({
          backendKind: 'openshell',
          packageSnapshotId: followUpSnapshot.snapshotId,
          requiredCapabilities: followUpSnapshot.backend.requiredCapabilities,
        }),
        readinessEvidence: [
          { kind: 'backend.ready', ref: 'version:0.0.80' },
          { kind: 'sandbox.created', ref: 'worker_follow_up_source' },
        ],
        workerSessionId: 'worker_follow_up_source',
      },
    ];
    input.workspaceMaterials = input.workspaceMaterials.map((material) => ({
      ...(material as Record<string, unknown>),
      currentRevisionId: baseRevisionId,
      lastMutationRequestId: 'request_material_base',
    }));
    input.workspaceMaterialRevisions = [input.workspaceMaterialRevisions[0]!];
    input.threadMaterialBindings = input.threadMaterialBindings.map((binding) => ({
      ...(binding as Record<string, unknown>),
      latestQueuedRevisionId: baseRevisionId,
      lastMutationRequestId: 'request_material_base',
    }));
    input.artifactReviews = input.artifactReviews.map((review) => ({
      ...(review as Record<string, unknown>),
      appliedMaterialRevisionId: null,
      decision: 'redo',
      decisionRequestId,
      feedback: 'Try again.',
      followUpTurnId,
    }));
    for (const file of followUpPackage.files) {
      input.portableFileState.workerContextPackageFiles.set(
        `threads/${source.threadId}/turns/${followUpTurnId}/context-package/${file.path}`,
        Buffer.from(file.bytes).toString('utf8')
      );
    }
    input.portableFileState.workerContextPackageFiles.set(
      `threads/${source.threadId}/turns/${followUpTurnId}/context-package.json`,
      serializeWorkerContextPackageTrace(followUpTrace)
    );
  }
  return input;
}

describe('workspace auxiliary lineage reminting', () => {
  it('imports annotated synchronization source rows and reopens their normalized target history', () => {
    const input = createLineageExportInput();
    const base = { commit: 'abc000', contentDigest: null };
    input.workspaceInputSnapshots = [
      {
        id: 'wis_source',
        workspaceId: source.workspaceId,
        resourceId: 'repo_source',
        resourceKind: 'git_repository',
        strategy: 'git',
        pathScope: ['src'],
        writableRoots: ['src'],
        ignoredPaths: [],
        generatedFiles: [{ id: 'generated', target: 'src/generated.txt' }],
        base,
        backend: { kind: 'openshell', label: 'Worker', capabilitySummary: [] },
        createdAt: timestamp,
      },
    ];
    input.workspaceMaterializationRecords = [
      {
        id: 'wmr_source',
        inputSnapshotId: 'wis_source',
        workspaceId: source.workspaceId,
        backendKind: 'openshell',
        packageSnapshotId: input.agentEnvironmentPackageSnapshots![0]!.snapshotId,
        workerSessionId: 'worker_source',
        strategy: 'git',
        materializedRootRef: `workspace:${source.workspaceId}/staging`,
        base,
        policyDigest: 'sha256:policy',
        readinessEvidence: [{ kind: 'backend.ready', ref: 'version:1' }],
        createdAt: timestamp,
      },
    ];
    input.backendWorkspaceHandles = [
      {
        id: 'bwh_source',
        workspaceId: source.workspaceId,
        materializationRecordId: 'wmr_source',
        backendKind: 'openshell',
        packageSnapshotId: input.agentEnvironmentPackageSnapshots![0]!.snapshotId,
        workerSessionId: 'worker_source',
        transportRefs: [{ kind: 'workspace', ref: `workspace:${source.workspaceId}/staging` }],
        cleanupStatus: 'pending',
        retention: 'until-reconciliation',
        createdAt: timestamp,
        updatedAt: timestamp,
      },
    ];
    input.stagedWorkspaceReviews = [
      {
        artifactId: source.artifactId,
        patchPayload: null,
        review: {
          id: 'swr_source',
          workspaceId: source.workspaceId,
          changeSetId: 'wcs_source',
          staging: {
            strategy: 'git_worktree',
            ref: `workspace:${source.workspaceId}/staging`,
            branch: null,
          },
          status: 'pending',
          diffSummary: { filesChanged: 0, additions: 0, deletions: 0 },
          riskSummary: 'No risks',
          validation: [{ command: 'pnpm test', status: 'passed', ref: null }],
          actionCenterRowId: 'acr_source',
          createdAt: timestamp,
          updatedAt: timestamp,
        },
      },
    ];
    input.workspaceApplyResults = [
      {
        id: 'war_source',
        workspaceId: source.workspaceId,
        reviewId: 'swr_source',
        changeSetId: 'wcs_source',
        status: 'applied',
        appliedPaths: ['src/file.ts'],
        skippedPaths: [],
        conflictRecords: [],
        verification: [{ command: 'pnpm test', status: 'passed', ref: null }],
        commitIds: [],
        appliedAt: timestamp,
        requestId: 'request_apply_source',
      },
    ];
    input.workspaceReconciliationRecords = [
      {
        id: 'wrr_source',
        workspaceId: source.workspaceId,
        triggerReason: 'restart',
        affectedRecordIds: ['wmr_source', 'bwh_source'],
        backendHandleSummary: { handleId: 'bwh_source' },
        backendReachability: { status: 'unknown', checkedAt: timestamp, detail: null },
        collectedOutputManifestIds: ['wom_source'],
        evidenceBundleIds: ['evb_source'],
        stateBefore: 'ready',
        stateAfter: 'requires-human',
        quarantineRefs: [],
        requiredHumanDecision: 'inspect',
        retentionDecision: 'retain-backend',
        startedAt: timestamp,
        finishedAt: null,
      },
    ];
    const families = [
      ['workspaceInputSnapshots', 'workspace-input-snapshots'],
      ['workspaceMaterializationRecords', 'workspace-materialization-records'],
      ['backendWorkspaceHandles', 'backend-workspace-handles'],
      ['workerOutputManifests', 'worker-output-manifests'],
      ['workspaceChangeSets', 'workspace-change-sets'],
      ['stagedWorkspaceReviews', 'staged-workspace-reviews'],
      ['workspaceApplyResults', 'workspace-apply-results'],
      ['workspaceReconciliationRecords', 'workspace-reconciliation-records'],
    ] as const;
    // The untouched producer-shaped export establishes that this graph is admissible before annotations.
    importLineage(input);
    input.exportRoot = join(mkdtempSync(join(tmpdir(), 'openkit-extended-sync-export-')), 'export');
    for (const [property] of families) input[property] = input[property]!.map(annotateSyncSource);
    const verified = writeWorkspaceExportTree(input);
    const originalBytes = families.map(([, file]) =>
      readFileSync(join(input.exportRoot, `records/${file}.jsonl`), 'utf8')
    );
    const imported = readWorkspaceImportSnapshot({ verified, targetWorkspaceId });
    for (const [property] of families) {
      expect(imported[property]).toHaveLength(1);
      expect(JSON.stringify(imported[property])).not.toContain('futureAnnotation');
    }
    expect(imported.workspaceMaterializationRecords[0]!.packageSnapshotId).toBe(
      imported.agentEnvironmentPackageSnapshots[0]!.snapshotId
    );
    expect(imported.backendWorkspaceHandles[0]!.packageSnapshotId).toBe(
      imported.agentEnvironmentPackageSnapshots[0]!.snapshotId
    );
    expect(imported.agentEnvironmentPackageSnapshots[0]!.snapshotId).not.toBe(
      input.agentEnvironmentPackageSnapshots![0]!.snapshotId
    );
    const targetRoot = mkdtempSync(join(tmpdir(), 'openkit-import-sync-target-'));
    let db = openWorkspaceDb(targetRoot, targetWorkspaceId);
    try {
      applyScopedMigrations(db);
      importWorkspaceApplyResults(db, imported.workspaceApplyResults);
      importWorkspaceReconciliationRecords(db, imported.workspaceReconciliationRecords);
      db.sqlite.close();
      db = openWorkspaceDb(targetRoot, targetWorkspaceId);
      expect(listExportableWorkspaceApplyResults(db, targetWorkspaceId)).toEqual(
        imported.workspaceApplyResults
      );
      expect(listWorkspaceReconciliationRecords(db, targetWorkspaceId)).toEqual(
        imported.workspaceReconciliationRecords
      );
    } finally {
      db.sqlite.close();
    }
    for (const [index, [, file]] of families.entries())
      expect(readFileSync(join(input.exportRoot, `records/${file}.jsonl`), 'utf8')).toBe(
        originalBytes[index]
      );
  });

  it('refuses ordinary export containing private Thread history before collecting portable content', () => {
    const input = createLineageExportInput();
    input.threads = input.threads.map((thread) => ({
      ...(thread as Record<string, unknown>),
      visibility: 'private',
      privateOwnerUserId: 'usr_00000000-0000-7000-8000-000000000002',
    }));
    expect(() => writeWorkspaceExportTree(input)).toThrow(
      'Private Thread history requires a separately authorized export.'
    );
  });

  it('inventories Turn observations and remints observation and Item anchors without rewriting content identities', () => {
    const input = createLineageExportInput();
    const rows = [
      {
        v: 1,
        type: 'runtime.observed',
        id: 'observation_source',
        ts: timestamp,
        seq: 1,
        obs: 'sidecar',
        turnId: source.turnId,
        parent: source.itemId,
        corr: 'call_source',
        payload: {
          observationId: 'observation_source',
          sourceRef: 'source_1',
          sourceSequence: 1,
          observedAt: timestamp,
          fact: { kind: 'origin', phase: 'started', runtimeOriginRef: `rto_${'a'.repeat(24)}` },
          content: { state: 'off' },
        },
      },
      {
        v: 1,
        type: 'runtime.observed',
        id: 'observation_followup',
        ts: timestamp,
        seq: 2,
        obs: 'sidecar',
        turnId: source.turnId,
        parent: 'observation_source',
        corr: 'call_source',
        payload: {
          observationId: 'observation_followup',
          sourceRef: 'source_1',
          sourceSequence: 2,
          observedAt: timestamp,
          fact: { kind: 'origin', phase: 'running', runtimeOriginRef: `rto_${'a'.repeat(24)}` },
          content: { state: 'off' },
        },
      },
    ];
    const externalRefs = [
      {
        kind: 'sandbox-image',
        scope: { ownerScope: 'server', deploymentId: 'dep_00000000-0000-7eae-88cf-8a657760c635' },
        locator: 'sha256:source-image',
        edge: 'association',
      },
      {
        kind: 'artifact',
        scope: {
          workspaceId: source.workspaceId,
          deploymentId: 'dep_00000000-0000-7eae-88cf-8a657760c635',
        },
        locator: source.artifactId,
        edge: 'association',
      },
    ];
    const text = `${rows.map((row) => JSON.stringify({ ...row, refs: externalRefs })).join('\n')}\n`;
    const verified = writeWorkspaceExportTree({
      ...input,
      turnCaptureCoverage: new Map([[source.turnId, { scope: 'server', value: 'off' }]]),
      turnObservations: new Map([[source.turnId, text]]),
    });
    const path = `workspace-files/threads/${source.threadId}/turns/${source.turnId}/observations.jsonl`;
    expect(verified.fileContents.get(path)).toBe(text);
    const imported = readWorkspaceImportSnapshot({ verified, targetWorkspaceId });
    const targetTurnId = imported.turnIds.get(source.turnId)!;
    expect(imported.turnCaptureCoverage.get(targetTurnId)).toEqual({
      scope: 'server',
      value: 'off',
    });
    const observations = imported.turnObservations.get(targetTurnId)!;
    const [first, second] = observations
      .trim()
      .split('\n')
      .map((line) => JSON.parse(line));
    expect(first).toMatchObject({
      turnId: targetTurnId,
      parent: imported.itemIds.get(source.itemId),
      corr: 'call_source',
      payload: {
        ...rows[0]!.payload,
        observationId: expect.stringMatching(/^obs_[a-f0-9]{24}$/),
        sourceRef: expect.stringMatching(/^rts_[a-f0-9]{24}$/),
        fact: {
          ...rows[0]!.payload.fact,
          runtimeOriginRef: `rto_${createHash('sha256')
            .update(
              `${imported.agentEnvironmentPackageSnapshots[0]!.snapshotId}:rto_${'a'.repeat(24)}`
            )
            .digest('hex')
            .slice(0, 24)}`,
        },
      },
    });
    expect(first.refs).toEqual(externalRefs);
    expect(first.payload.sourceRef).not.toBe(rows[0]!.payload.sourceRef);
    expect(second.payload.sourceRef).toBe(first.payload.sourceRef);
    expect(second.payload.observationId).not.toBe(first.payload.observationId);
    expect(first.id).not.toBe(rows[0]!.id);
    expect(second).toMatchObject({ parent: first.id, turnId: targetTurnId, seq: 2 });
    expect(second.id).not.toBe(rows[1]!.id);
  });

  it('shares one exact child-origin remint with Gateway calls without a provenance index', () => {
    const input = createLineageExportInput();
    const packageSnapshotId = input.agentEnvironmentPackageSnapshots![0]!.snapshotId;
    const rootRef = `rto_${'a'.repeat(24)}`;
    const childRef = `rto_${'b'.repeat(24)}`;
    input.capabilityCalls = input.capabilityCalls!.map((call) => ({
      ...(call as Record<string, unknown>),
      packageSnapshotId,
      runtimeOriginRef: childRef,
    }));
    const row = {
      v: 1,
      id: 'child_observation',
      type: 'runtime.observed',
      ts: timestamp,
      seq: 1,
      obs: 'sidecar',
      turnId: source.turnId,
      payload: {
        observationId: 'child_observation',
        sourceRef: 'source_1',
        sourceSequence: 1,
        observedAt: timestamp,
        fact: {
          kind: 'origin',
          phase: 'started',
          runtimeOriginRef: childRef,
          parentRuntimeOriginRef: rootRef,
        },
        content: { state: 'off' },
      },
    };
    const verified = writeWorkspaceExportTree({
      ...input,
      turnCaptureCoverage: new Map([[source.turnId, { scope: 'server', value: 'off' }]]),
      turnObservations: new Map([[source.turnId, `${JSON.stringify(row)}\n`]]),
    });
    const imported = readWorkspaceImportSnapshot({ verified, targetWorkspaceId });
    expect(imported.runtimeProvenanceIndexes.size).toBe(0);
    const targetPackageId = imported.agentEnvironmentPackageSnapshots[0]!.snapshotId;
    const expectedRef = (ref: string) =>
      `rto_${createHash('sha256').update(`${targetPackageId}:${ref}`).digest('hex').slice(0, 24)}`;
    const observation = JSON.parse(
      imported.turnObservations.get(imported.turnIds.get(source.turnId)!)!.trim()
    );
    expect(observation.payload.fact).toMatchObject({
      runtimeOriginRef: expectedRef(childRef),
      parentRuntimeOriginRef: expectedRef(rootRef),
    });
    expect(imported.capabilityCalls[0]).toMatchObject({
      runtimeOriginRef: expectedRef(childRef),
      packageSnapshotId: targetPackageId,
    });
  });

  it('retains restricted observation bytes while reminting their exact publication references', () => {
    const input = createLineageExportInput(undefined, 'on');
    const bytes = Buffer.from('  original é\n');
    const digest = createHash('sha256').update(bytes).digest('hex');
    input.evidenceBundles = [
      {
        id: 'evb_observation',
        workspaceId: source.workspaceId,
        threadId: source.threadId,
        turnId: source.turnId,
        goalId: null,
        agentSessionId: null,
        backendType: 'internal',
        sourceKind: 'work-observation-body',
        summary: 'Restricted observation content.',
        rawEvidenceRefs: [{ kind: 'work-observation-body', ref: 'raw/content' }],
        redactedEvidenceRefs: [],
        contentDigests: [digest],
        retentionClass: 'restricted-raw',
        sensitivityClass: 'restricted',
        importStatus: 'promoted',
        requiredFeatures: ['evidence.bundle.v1', 'openkit.work-observations.v1'],
        createdAt: timestamp,
      },
    ];
    const initial = {
      v: 1,
      id: 'observation_initial',
      type: 'runtime.observed',
      ts: timestamp,
      seq: 1,
      obs: 'sidecar',
      turnId: source.turnId,
      payload: {
        observationId: 'observation_initial',
        sourceRef: 'source_1',
        sourceSequence: 1,
        observedAt: timestamp,
        fact: {
          kind: 'assistant',
          phase: 'completed',
          runtimeOriginRef: null,
          messageRef: 'message_1',
          representation: 'snapshot',
        },
        content: {
          state: 'expected',
          sha256: `sha256:${digest}`,
          bytes: Buffer.byteLength('  original é\n'),
          mediaType: 'text/plain',
          boundary: 'assistant.text',
          chunkCount: 1,
        },
      },
    };
    const row = {
      v: 1,
      id: 'observation_body',
      type: 'content.published',
      ts: timestamp,
      seq: 2,
      obs: 'sidecar',
      turnId: source.turnId,
      parent: initial.id,
      refs: [
        {
          kind: 'evidence-bundle',
          scope: { workspaceId: source.workspaceId, pathClass: 'backend' },
          locator: 'evb_observation',
          digest,
          edge: 'publication',
        },
      ],
      payload: {
        bodies: [
          {
            id: 'body_1',
            bundleId: 'evb_observation',
            sha256: digest,
            bytes: Buffer.byteLength('  original é\n'),
            mediaType: 'text/plain',
            boundary: 'assistant.text',
          },
        ],
      },
    };
    const verified = writeWorkspaceExportTree({
      ...input,
      restrictedEvidenceFiles: new Map([['evb_observation/raw/content', bytes]]),
      turnCaptureCoverage: new Map([[source.turnId, { scope: 'server', value: 'on' }]]),
      turnObservations: new Map([
        [source.turnId, `${JSON.stringify(initial)}\n${JSON.stringify(row)}\n`],
      ]),
    });
    expect(verified.manifest.requiredFeatures).toContain('openkit.work-observations.v1');
    expect(
      verified.binaryFileContents.get(
        'workspace-files/evidence/backend/evb_observation/raw/content'
      )
    ).toEqual(bytes);
    const imported = readWorkspaceImportSnapshot({ verified, targetWorkspaceId });
    const bundle = imported.evidenceBundles[0]!;
    expect(bundle).toMatchObject({
      importStatus: 'promoted',
      rawEvidenceRefs: [{ kind: 'work-observation-body', ref: 'raw/content' }],
      redactedEvidenceRefs: [],
      contentDigests: [digest],
    });
    expect(bundle.id).not.toBe('evb_observation');
    expect(imported.restrictedEvidenceFiles.get(`${bundle.id}/raw/content`)).toEqual(bytes);
    const targetTurnId = imported.turnIds.get(source.turnId)!;
    const observation = JSON.parse(
      imported.turnObservations.get(targetTurnId)!.trim().split('\n')[1]!
    );
    expect(observation.refs).toEqual([
      {
        ...row.refs[0],
        locator: bundle.id,
        scope: { workspaceId: targetWorkspaceId, pathClass: 'backend' },
      },
    ]);
  });

  it.each([
    'parent',
    'sequence',
    'turn',
    'bundle',
    'type',
  ] as const)('rejects invalid observation %s instead of silently dropping or rebinding it', (defect) => {
    const input = createLineageExportInput();
    const row = {
      v: 1,
      id: 'observation_source',
      type: defect === 'type' ? 'future.unknown' : 'runtime.observed',
      ts: timestamp,
      seq: defect === 'sequence' ? 2 : 1,
      obs: 'sidecar',
      turnId: defect === 'turn' ? 'tu_00000000-0000-7577-9378-7e96d0d15fd2' : source.turnId,
      parent: defect === 'parent' ? 'missing-parent' : source.itemId,
      ...(defect === 'bundle'
        ? {
            refs: [
              {
                kind: 'evidence-bundle',
                scope: { workspaceId: source.workspaceId, pathClass: 'backend' },
                locator: 'evb_missing',
                edge: 'association',
              },
            ],
          }
        : {}),
      payload: {
        observationId: 'observation_source',
        sourceRef: 'source_1',
        sourceSequence: 1,
        observedAt: timestamp,
        fact: { kind: 'origin', phase: 'started', runtimeOriginRef: null },
        content: { state: 'off' },
      },
    };
    expect(() => {
      const verified = writeWorkspaceExportTree({
        ...input,
        turnCaptureCoverage: new Map([[source.turnId, { scope: 'server', value: 'off' }]]),
        turnObservations: new Map([[source.turnId, `${JSON.stringify(row)}\n`]]),
      });
      readWorkspaceImportSnapshot({ verified, targetWorkspaceId });
    }).toThrow(
      {
        parent: /parent references missing/,
        sequence: /sequence or ownership/,
        turn: /sequence or ownership/,
        bundle: /evidence bundle references missing/,
        type: /Unsupported work observation type/,
      }[defect]
    );
  });
  it('remints accepted Knowledge Page Context Package references with the imported digest', () => {
    const input = createWorkResourceLineageExportInput();
    const sourceTraceText = [...input.portableFileState!.workerContextPackageFiles.entries()].find(
      ([path]) => path.endsWith('/context-package.json')
    )?.[1];
    const sourceTrace = parseWorkerContextPackageTrace(JSON.parse(sourceTraceText ?? '{}'));
    const knowledge = {
      id: 'mem_1',
      kind: 'task-summary' as const,
      title: 'Portable work history',
      content: 'Reuse the accepted Context Package.',
      sourceReferences: [`context-package:${source.turnId}@${sourceTrace.contextPackageDigest}`],
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    input.knowledge = [knowledge];
    input.workspace = {
      ...input.workspace,
      counts: { ...input.workspace.counts, knowledgeEntryCount: 1 },
    };
    input.portableFileState!.nativeKnowledgePages.set(
      `knowledge/pages/${knowledge.id}.md`,
      serializeUserAuthoredKnowledgePage(knowledge)
        .replace(
          `source_refs: ${JSON.stringify(knowledge.sourceReferences)}`,
          `source_refs:\n  - ${JSON.stringify(knowledge.sourceReferences[0])}`
        )
        .replace(
          'scope: "workspace"',
          'scope: "workspace"\nsources:\n  - id: retained-source\n    credibility:\n      author: human:owner'
        )
    );

    const imported = importLineage(input);
    const targetTraceText = [
      ...imported.portableFileState.workerContextPackageFiles.entries(),
    ].find(([path]) => path.endsWith('/context-package.json'))?.[1];
    const targetTrace = parseWorkerContextPackageTrace(JSON.parse(targetTraceText ?? '{}'));
    const expectedReference = `context-package:${targetTrace.turnId}@${targetTrace.contextPackageDigest}`;
    const [pagePath, pageContent] = [
      ...imported.portableFileState.nativeKnowledgePages.entries(),
    ].find(([path]) => path === `knowledge/pages/${knowledge.id}.md`)!;

    expect(targetTrace.contextPackageDigest).not.toBe(sourceTrace.contextPackageDigest);
    expect(imported.knowledge[0]?.sourceReferences).toEqual([expectedReference]);
    expect(parseOwnedKnowledgeEntry(pagePath, knowledge.id, pageContent).sourceReferences).toEqual([
      expectedReference,
    ]);
    expect(pageContent).toContain(
      'sources:\n  - id: retained-source\n    credibility:\n      author: human:owner'
    );
  });

  it('admits populated portable runtime and MCP descriptions, remints core and reopens exact target packages', () => {
    const input = createWorkResourceLineageExportInput();
    const tools = [{ name: 'inspect', inputSchema: { type: 'object', properties: {} } }];
    const sourceExport = writeWorkspaceExportTree({
      ...input,
      runtimeEvidence: input.runtimeEvidence?.map((row) => ({
        ...RuntimeEvidenceRecordSchema.parse(row),
        uploadManifest: [
          {
            path: 'upload.txt',
            size: 6,
            digest: `sha256:${createHash('sha256').update('upload').digest('hex')}`,
          },
        ],
        downloadManifest: [
          {
            path: 'download.txt',
            size: 8,
            digest: `sha256:${createHash('sha256').update('download').digest('hex')}`,
          },
        ],
      })),
      mcpToolSchemaSnapshots: [
        {
          capturedAt: timestamp,
          catalogEntryId: 'mcp_source',
          contentDigest: mcpToolSchemaContentDigest(tools),
          schemaSnapshotId: 'mcp_snapshot_source',
          serverVersion: '1.0.0',
          source: 'live',
          sourceRef: null,
          tools,
          workspaceId: source.workspaceId,
        },
      ],
    });
    const manifestPath = join(input.exportRoot, WORKSPACE_EXPORT_MANIFEST_FILE);
    const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'));
    const canonical = (value: unknown): string => {
      const sort = (entry: unknown): unknown => {
        if (Array.isArray(entry)) return entry.map(sort);
        if (entry && typeof entry === 'object')
          return Object.fromEntries(
            Object.entries(entry)
              .sort(([a], [b]) => a.localeCompare(b))
              .map(([key, item]) => [key, sort(item)])
          );
        return entry;
      };
      return JSON.stringify(sort(value));
    };
    const packagePath = `workspace-files/threads/${source.threadId}/turns/${source.turnId}/context-package/package.json`;
    const tracePath = `workspace-files/threads/${source.threadId}/turns/${source.turnId}/context-package.json`;
    const packageManifest = JSON.parse(readFileSync(join(input.exportRoot, packagePath), 'utf8'));
    packageManifest.annotation = { '10': 'ten', '2': 'two' };
    packageManifest.materialSelections[0].annotation = 'source Material selection';
    packageManifest.knowledgeSelections[0].annotation = 'source Knowledge selection';
    const packageBytes = canonical(packageManifest);
    const sourceTrace = JSON.parse(readFileSync(join(input.exportRoot, tracePath), 'utf8'));
    sourceTrace.annotation = 'source trace';
    sourceTrace.materialSelections[0].annotation = 'source selection';
    sourceTrace.knowledgeSelections[0].annotation = 'source Knowledge';
    sourceTrace.knowledgeSelectionInput.annotation = 'source retrieval';
    const packageEntry = sourceTrace.fileInventory.find(
      (entry: { path: string }) => entry.path === 'package.json'
    );
    packageEntry.byteLength = Buffer.byteLength(packageBytes);
    packageEntry.contentDigest = `sha256:${createHash('sha256').update(packageBytes).digest('hex')}`;
    const { contextPackageDigest: _originalDigest, ...traceWithoutDigest } = sourceTrace;
    sourceTrace.contextPackageDigest = `ctxpkg_sha256_${createHash('sha256').update(canonical(traceWithoutDigest)).digest('hex')}`;
    const packageRootDigest = `sha256:${createHash('sha256').update(canonical(sourceTrace.fileInventory)).digest('hex')}`;
    for (const [path, bytes] of [
      [packagePath, packageBytes],
      [tracePath, canonical(sourceTrace)],
    ]) {
      writeFileSync(join(input.exportRoot, path!), bytes!);
      const entry = manifest.contentInventory.find(
        (entry: { path: string }) => entry.path === path
      );
      entry.bytes = Buffer.byteLength(bytes!);
      entry.digest = `sha256:${createHash('sha256').update(bytes!).digest('hex')}`;
    }
    const paths = [
      'records/workspace-materials.jsonl',
      'records/workspace-material-revisions.jsonl',
      'records/thread-material-bindings.jsonl',
      'records/artifact-reviews.jsonl',
      'records/agent-environment-package-snapshots.jsonl',
      'records/resolved-agent-setups.jsonl',
      'records/worker-turn-checkpoints.jsonl',
      'records/mcp-tool-schema-snapshots.jsonl',
      'records/capability-calls.jsonl',
      'records/evidence-bundles.jsonl',
      'records/runtime-evidence.jsonl',
      'records/usage-records.jsonl',
      'records/workspace-repositories.jsonl',
      'records/workspace-input-snapshots.jsonl',
      'records/workspace-materialization-records.jsonl',
    ];
    const changed: string[] = [];
    for (const path of paths) {
      const entry = manifest.contentInventory.find(
        (entry: { path: string }) => entry.path === path
      );
      if (!entry) continue;
      const rows = readFileSync(join(input.exportRoot, path), 'utf8')
        .trim()
        .split('\n')
        .filter(Boolean)
        .map((text) => JSON.parse(text));
      if (rows.length === 0) continue;
      for (const row of rows) {
        if (row.base) row.base.contentDigest = packageRootDigest;
        else row.annotation = 'portable';
        if (row.git) row.git.annotation = 'archived repository configuration';
        for (const tool of row.tools ?? []) tool.annotation = 'descriptive Tool snapshot';
        if (row.materialProposal) row.materialProposal.annotation = 'proposal';
        for (const ref of row.redactedEvidenceRefs ?? []) ref.annotation = 'reference';
        for (const ref of row.rawEvidenceRefs ?? []) ref.annotation = 'reference';
        for (const ref of row.uploadManifest ?? []) ref.annotation = 'upload';
        for (const ref of row.downloadManifest ?? []) ref.annotation = 'download';
        if (row.snapshot) {
          row.snapshot.workspace.inputs.find(
            (input: { materialization?: { slotId: string } }) =>
              input.materialization?.slotId === 'context'
          ).materialization.contentDigest = packageRootDigest;
          row.snapshot.control.transcript.annotation = 'transcript';
          row.snapshot.scope.annotation = JSON.parse('{"__proto__":"inert"}');
          row.snapshot.scope.triggerActor.annotation = 'actor';
          row.snapshot.agent.annotation = 'agent';
          row.contentDigest = snapshotDigest(row.snapshot);
        }
      }
      const text = `${rows.map((row) => JSON.stringify(row)).join('\n')}\n`;
      writeFileSync(join(input.exportRoot, path), text);
      entry.bytes = Buffer.byteLength(text);
      entry.digest = `sha256:${createHash('sha256').update(text).digest('hex')}`;
      changed.push(path);
    }
    expect(changed).toEqual(paths);
    manifest.contentDigest = `sha256:${createHash('sha256').update(JSON.stringify(manifest.contentInventory)).digest('hex')}`;
    writeFileSync(manifestPath, JSON.stringify(manifest));
    const verified = verifyWorkspaceExportTree({ exportRoot: input.exportRoot });
    expect(verified.manifest.contentDigest).not.toBe(sourceExport.manifest.contentDigest);
    const targetRoot = mkdtempSync(join(tmpdir(), 'openkit-extended-portable-target-'));
    const targetWorkspaceRoot = join(targetRoot, 'workspaces', targetWorkspaceId);
    const snapshotFile = join(
      input.exportRoot,
      'records/agent-environment-package-snapshots.jsonl'
    );
    const safeSnapshotBytes = readFileSync(snapshotFile, 'utf8');
    const safeManifestBytes = readFileSync(manifestPath, 'utf8');
    const safeSnapshotDigest = JSON.parse(safeSnapshotBytes.trim()).contentDigest;
    expect(verified.manifestDigest).toBe(
      `sha256:${createHash('sha256').update(safeManifestBytes).digest('hex')}`
    );
    try {
      for (const annotation of [
        '/Users/synthetic/private-location',
        'runtime://synthetic/private-ref',
        JSON.parse('{"__proto__":"runtime://synthetic/private-ref"}'),
      ]) {
        const unsafeRows = safeSnapshotBytes
          .trim()
          .split('\n')
          .map((text) => JSON.parse(text));
        const unsafeRecord = unsafeRows[0]!;
        unsafeRecord.snapshot.scope.annotation = annotation;
        unsafeRecord.contentDigest = snapshotDigest(unsafeRecord.snapshot);
        const unsafeSnapshotBytes = `${unsafeRows.map((row) => JSON.stringify(row)).join('\n')}\n`;
        const unsafeManifest = JSON.parse(safeManifestBytes);
        const entry = unsafeManifest.contentInventory.find(
          (entry: { path: string }) =>
            entry.path === 'records/agent-environment-package-snapshots.jsonl'
        );
        entry.bytes = Buffer.byteLength(unsafeSnapshotBytes);
        entry.digest = `sha256:${createHash('sha256').update(unsafeSnapshotBytes).digest('hex')}`;
        unsafeManifest.contentDigest = `sha256:${createHash('sha256').update(JSON.stringify(unsafeManifest.contentInventory)).digest('hex')}`;
        const unsafeManifestBytes = JSON.stringify(unsafeManifest);
        writeFileSync(snapshotFile, unsafeSnapshotBytes);
        writeFileSync(manifestPath, unsafeManifestBytes);
        const unsafeVerified = verifyWorkspaceExportTree({ exportRoot: input.exportRoot });
        expect(snapshotDigest(unsafeRecord.snapshot)).toBe(unsafeRecord.contentDigest);
        expect(unsafeVerified.manifestDigest).toBe(
          `sha256:${createHash('sha256').update(unsafeManifestBytes).digest('hex')}`
        );
        expect
          .soft(() =>
            readWorkspaceImportSnapshot({
              verified: unsafeVerified,
              targetWorkspaceId,
              targetServerId: 'dep_00000000-0000-7000-8000-000000000002',
            })
          )
          .toThrow('Agent environment package snapshot is not redacted');
        expect(existsSync(targetWorkspaceRoot)).toBe(false);
        expect(readFileSync(snapshotFile, 'utf8')).toBe(unsafeSnapshotBytes);
        expect(readFileSync(manifestPath, 'utf8')).toBe(unsafeManifestBytes);
        expect(snapshotDigest(JSON.parse(readFileSync(snapshotFile, 'utf8').trim()).snapshot)).toBe(
          unsafeRecord.contentDigest
        );
      }
    } finally {
      // Restore the independently admitted safe fixture, never a redacted/rehashed unsafe source.
      writeFileSync(snapshotFile, safeSnapshotBytes);
      writeFileSync(manifestPath, safeManifestBytes);
    }
    const imported = readWorkspaceImportSnapshot({
      verified,
      targetWorkspaceId,
      targetServerId: 'dep_00000000-0000-7000-8000-000000000002',
    });
    expect(JSON.stringify(imported)).not.toContain('annotation');
    expect(imported.artifactReviews[0]?.materialProposal).not.toHaveProperty('annotation');
    expect(imported.workspaceMaterials[0]).not.toHaveProperty('annotation');
    expect(imported.agentEnvironmentPackageSnapshots[0]!.snapshot.scope).not.toHaveProperty(
      'annotation'
    );
    const db = openWorkspaceDb(targetRoot, targetWorkspaceId);
    applyScopedMigrations(db);
    importAgentEnvironmentPackageSnapshots(db, imported.agentEnvironmentPackageSnapshots);
    importMcpToolSchemaSnapshots(db, imported.mcpToolSchemaSnapshots);
    const record = imported.agentEnvironmentPackageSnapshots[0]!;
    writeWorkspacePortableFileState(targetWorkspaceRoot, imported.portableFileState);
    verifyImportedWorkerContextPackageSnapshot(imported, targetWorkspaceRoot);
    db.sqlite.close();
    const reopened = openWorkspaceDb(targetRoot, targetWorkspaceId);
    try {
      const read = requireAgentEnvironmentPackageSnapshot(
        reopened,
        targetWorkspaceId,
        record.snapshotId
      );
      expect(read.contentDigest).toBe(snapshotDigest(read.retainedSnapshot));
      expect(read.snapshot).toEqual(record.snapshot);
      const [mcp] = listExportableMcpToolSchemaSnapshots(reopened, targetWorkspaceId);
      expect(mcp?.tools).toEqual(tools);
      expect(JSON.stringify(mcp)).not.toContain('annotation');
      expect(mcp?.contentDigest).toBe(mcpToolSchemaContentDigest(tools));
      expect(mcp?.contentDigest).toBe(imported.mcpToolSchemaSnapshots[0]!.contentDigest);
      const stored = reopened.sqlite
        .prepare(
          'SELECT tools_json, content_digest FROM mcp_tool_schema_snapshots WHERE snapshot_id = ?'
        )
        .get(mcp!.schemaSnapshotId) as { tools_json: string; content_digest: string };
      expect(JSON.parse(stored.tools_json)).toEqual(tools);
      expect(stored.tools_json).not.toContain('annotation');
      expect(stored.content_digest).toBe(mcpToolSchemaContentDigest(JSON.parse(stored.tools_json)));
      verifyImportedWorkerContextPackageSnapshot(imported, targetWorkspaceRoot);
    } finally {
      reopened.sqlite.close();
    }
    for (const [path, text] of imported.portableFileState.workerContextPackageFiles) {
      expect(readFileSync(join(targetWorkspaceRoot, path), 'utf8')).toBe(text);
    }
    expect(readFileSync(snapshotFile, 'utf8')).toBe(safeSnapshotBytes);
    expect(readFileSync(manifestPath, 'utf8')).toBe(safeManifestBytes);
    expect(JSON.parse(readFileSync(snapshotFile, 'utf8').trim()).contentDigest).toBe(
      safeSnapshotDigest
    );
    expect(snapshotDigest(JSON.parse(readFileSync(snapshotFile, 'utf8').trim()).snapshot)).toBe(
      safeSnapshotDigest
    );
  });

  it('remints one complete Material, Review, and S39 imported-history graph', () => {
    const input = createWorkResourceLineageExportInput();
    const sourceRetrievalTrace = [...input.portableFileState!.retrievalTraceFiles.values()][0]!;
    const imported = importLineage(input);
    const material = imported.workspaceMaterials[0];
    const revisions = imported.workspaceMaterialRevisions;
    const binding = imported.threadMaterialBindings[0];
    const review = imported.artifactReviews[0];
    const traceText = [...imported.portableFileState.workerContextPackageFiles.entries()].find(
      ([path]) => path.endsWith('/context-package.json')
    )?.[1];
    const trace = parseWorkerContextPackageTrace(JSON.parse(traceText ?? '{}'));
    const [retrievalTracePath, retrievalTrace] = [
      ...imported.portableFileState.retrievalTraceFiles.entries(),
    ][0]!;
    const stagedRoot = mkdtempSync(join(tmpdir(), 'openkit-imported-history-package-'));
    writeWorkspacePortableFileState(stagedRoot, imported.portableFileState);
    expect(() => verifyImportedWorkerContextPackageSnapshot(imported, stagedRoot)).not.toThrow();

    expect(material?.workspaceId).toBe(targetWorkspaceId);
    expect(material?.materialId).not.toBe('mat_00000000-0000-7807-b767-6378f3fcdcf3');
    expect(revisions).toHaveLength(2);
    expect(revisions[0]?.content).toBe('# Portable base\n');
    expect(revisions[1]).toMatchObject({
      materialId: material?.materialId,
      parentRevisionId: revisions[0]?.revisionId,
    });
    expect(material?.currentRevisionId).toBe(revisions[1]?.revisionId);
    expect(binding).toMatchObject({
      materialId: material?.materialId,
      threadId: imported.threads[0]?.id,
      latestQueuedRevisionId: revisions[1]?.revisionId,
    });
    expect(review).toMatchObject({
      appliedMaterialRevisionId: revisions[1]?.revisionId,
      artifactId: imported.artifacts[0]?.id,
      materialProposal: {
        baseRevisionId: revisions[0]?.revisionId,
        materialId: material?.materialId,
      },
      reviewId: deriveArtifactReviewId(targetWorkspaceId, imported.artifacts[0]!.id, 1),
      sourceAgentId: 'agent_codex_host',
      sourceThreadId: imported.threads[0]?.id,
      sourceTurnId: imported.turns[0]?.id,
      workspaceId: targetWorkspaceId,
    });
    expect(material?.lastMutationRequestId).toBe(review?.decisionRequestId);
    expect(revisions[1]?.createdByRequestId).toBe(review?.decisionRequestId);
    expect(binding?.lastMutationRequestId).toBe(review?.decisionRequestId);
    expect(review?.decisionRequestId).toMatch(/^import-lineage:sha256:[a-f0-9]{64}$/);
    expect(retrievalTracePath).toBe(
      `threads/${imported.threads[0]?.id}/turns/${imported.turns[0]?.id}/retrieval-traces/${sourceRetrievalTrace.traceId}.json`
    );
    expect(retrievalTrace).toMatchObject({
      traceId: sourceRetrievalTrace.traceId,
      requestDigest: sourceRetrievalTrace.requestDigest,
      queryContext: {
        serverId: 'dep_00000000-0000-7000-8000-000000000002',
        workspaceId: targetWorkspaceId,
        threadId: imported.threads[0]?.id,
        turnId: imported.turns[0]?.id,
      },
      sourceScope: `page/workspace/${targetWorkspaceId}`,
      selected: [
        expect.objectContaining({
          reference: {
            scopeId: `page/workspace/${targetWorkspaceId}`,
            objectId: 'knowledge_portable_source',
          },
        }),
      ],
    });
    expect(trace).toMatchObject({
      agentSessionId: imported.agentSessions[0]?.id,
      contextPackageId: `ctxpkg_${imported.turns[0]?.id}`,
      knowledgeSelectionInput: {
        retrievalTraceRef: {
          scopeId: `retrieval-trace/turn/${targetWorkspaceId}/${imported.threads[0]?.id}/${imported.turns[0]?.id}`,
          objectId: 'krt_00000000-0000-780e-b78f-51422afca1e9',
        },
      },
      knowledgeSelections: [
        {
          contentDigest: `sha256:${createHash('sha256')
            .update('# Retained portable knowledge\n\nUse the retained package bytes.\n')
            .digest('hex')}`,
          knowledgePageId: 'knowledge_portable_source',
          packagePath: 'knowledge/pages/knowledge_portable_source.md',
          sourceRefs: ['https://example.com/retained-portable-knowledge'],
        },
      ],
      materialSelections: [
        {
          materialId: material?.materialId,
          revisionId: revisions[0]?.revisionId,
        },
      ],
      packageSnapshotId: imported.agentEnvironmentPackageSnapshots[0]?.snapshotId,
      requestId: expect.stringMatching(/^import-lineage:sha256:[a-f0-9]{64}$/),
      threadId: imported.threads[0]?.id,
      turnId: imported.turns[0]?.id,
      workerRequestItemId: imported.turns[0]?.items[0]?.id,
      workspaceId: targetWorkspaceId,
      workspaceInputSnapshotId: imported.workspaceInputSnapshots[0]?.id,
      workspaceMaterializationRecordId: imported.workspaceMaterializationRecords[0]?.id,
    });
    const requestText =
      imported.turns[0]?.items[0]?.type === 'user-message' ? imported.turns[0].items[0].text : null;
    expect(trace.requestId).not.toBe('request_source');
    expect(imported.threads[0]?.preview).toBe(requestText);
    expect(requestText).toContain(targetWorkspaceId);
    expect(requestText).toContain(imported.threads[0]?.id);
    expect(requestText).not.toContain(source.workspaceId);
    expect(requestText).not.toContain(source.threadId);
    expect(imported.turnEvents[0]?.[1][0]?.data).toEqual({
      type: 'thread-created',
      thread: imported.threads[0],
    });
    expect(imported.turnEvents[0]?.[1][1]?.data).toEqual({
      type: 'thread-updated',
      thread: imported.threads[0],
    });
    expect(imported.workspaceMaterializationRecords[0]?.workerSessionId).toBe(
      `import-history-worker_${trace.packageSnapshotId}`
    );
    expect([...imported.portableFileState.workerContextPackageFiles.keys()]).toEqual(
      expect.arrayContaining([
        `threads/${trace.threadId}/turns/${trace.turnId}/context-package.json`,
        `threads/${trace.threadId}/turns/${trace.turnId}/context-package/package.json`,
      ])
    );
    expect(imported.portableFileState.nativeKnowledgePages).toEqual(
      new Map([
        [
          'knowledge/pages/knowledge_portable_source.md',
          '# Retained portable knowledge\n\nUse the retained package bytes.\n',
        ],
      ])
    );
    expect(
      imported.portableFileState.workerContextPackageFiles.get(
        `threads/${trace.threadId}/turns/${trace.turnId}/context-package/knowledge/pages/knowledge_portable_source.md`
      )
    ).toBe('# Retained portable knowledge\n\nUse the retained package bytes.\n');
    expect(imported.turnEvents[0]?.[1][2]?.data).toMatchObject({
      itemId: imported.turns[0]?.items[0]?.id,
      item: imported.turns[0]?.items[0],
    });
    expect(imported.turnEvents[0]?.[1][3]?.data).toMatchObject({
      type: 'item-delta',
      itemId: imported.artifacts[0]
        ? artifactReferenceItemId(imported.artifacts[0].id, imported.turns[0]!.id)
        : undefined,
      artifactId: imported.artifacts[0]?.id,
    });

    const reExported = writeWorkspaceExportTree({
      agentEnvironmentPackageSnapshots: imported.agentEnvironmentPackageSnapshots,
      agentSessions: imported.agentSessions,
      artifactReviews: imported.artifactReviews,
      artifacts: imported.artifacts,
      createdAt: timestamp,
      exportId: 'wsexp_00000000-0000-75d0-b908-ecd78e49177b',
      exportRoot: join(mkdtempSync(join(tmpdir(), 'openkit-reexported-history-')), 'export'),
      itemRevisions: imported.itemRevisions,
      knowledge: imported.knowledge,
      portableFileState: imported.portableFileState,
      sourceDeploymentId: 'dep_00000000-0000-7000-8000-000000000002',
      threadMaterialBindings: imported.threadMaterialBindings,
      threads: imported.threads,
      turnEvents: imported.turnEvents,
      turns: imported.turns,
      workspace: imported.workspace,
      workspaceInputSnapshots: imported.workspaceInputSnapshots,
      workspaceMaterialRevisions: imported.workspaceMaterialRevisions,
      workspaceMaterializationRecords: imported.workspaceMaterializationRecords,
      workspaceMaterials: imported.workspaceMaterials,
    });
    for (const [path, bytes] of reExported.fileContents) {
      if (path.includes('/retrieval-traces/') && path.endsWith('.json')) {
        expect(JSON.parse(bytes).queryContext.serverId).toBe(
          reExported.manifest.sourceDeploymentId
        );
      }
    }
    const reimported = readWorkspaceImportSnapshot({
      verified: reExported,
      targetWorkspaceId: 'ws_00000000-0000-75c2-b6dd-fdd26f61df2a',
      targetServerId: 'server_reimport_target',
    });
    const reimportedRoot = mkdtempSync(join(tmpdir(), 'openkit-reimported-history-package-'));
    writeWorkspacePortableFileState(reimportedRoot, reimported.portableFileState);
    expect(() =>
      verifyImportedWorkerContextPackageSnapshot(reimported, reimportedRoot)
    ).not.toThrow();
    expect(reimported.workspaceMaterialRevisions).toHaveLength(
      imported.workspaceMaterialRevisions.length
    );
    const importedBase = imported.workspaceMaterialRevisions.find(
      (revision) => revision.parentRevisionId === null
    );
    const reimportedBase = reimported.workspaceMaterialRevisions.find(
      (revision) => revision.parentRevisionId === null
    );
    expect(importedBase).toBeDefined();
    expect(reimportedBase).toBeDefined();
    expect(reimportedBase?.content).toBe(importedBase!.content);
    const importedChild = imported.workspaceMaterialRevisions.find(
      (revision) => revision.parentRevisionId === importedBase!.revisionId
    );
    const reimportedChild = reimported.workspaceMaterialRevisions.find(
      (revision) => revision.parentRevisionId === reimportedBase!.revisionId
    );
    expect(importedChild).toBeDefined();
    expect(reimportedChild?.content).toBe(importedChild!.content);
    expect(
      [...reimported.portableFileState.workerContextPackageFiles.entries()].find(([path]) =>
        path.endsWith('/context-package.json')
      )?.[1]
    ).toContain('import-lineage:sha256:');
  });

  it('preserves a Thread preview that is not the exact traced worker request', () => {
    const input = createWorkResourceLineageExportInput();
    const preview = `User note: ${input.threads[0]!.preview}`;
    input.threads = input.threads.map((thread) => ({ ...thread, preview }));
    input.turnEvents = input.turnEvents.map(([turnId, events]) => [
      turnId,
      events.map((event) =>
        event.data.type === 'thread-created' || event.data.type === 'thread-updated'
          ? { ...event, data: { ...event.data, thread: { ...event.data.thread, preview } } }
          : event
      ),
    ]);

    const imported = importLineage(input);

    expect(imported.threads[0]?.preview).toBe(preview);
    expect(imported.turnEvents[0]?.[1][0]?.data).toEqual({
      type: 'thread-created',
      thread: imported.threads[0],
    });
    expect(imported.turnEvents[0]?.[1][1]?.data).toEqual({
      type: 'thread-updated',
      thread: imported.threads[0],
    });
  });

  it('preserves compatible Artifact Review follow-up media through remint', () => {
    const imported = importLineage(createWorkResourceLineageExportInput({}));
    const review = imported.artifactReviews[0]!;
    const turn = imported.turns.find((candidate) => candidate.id === review.followUpTurnId);
    const item = turn?.items[0];
    const request = ArtifactReviewFollowUpRequestSchema.parse(
      JSON.parse(item?.type === 'user-message' ? item.text : '{}')
    );

    expect(request.artifactMediaType).toBe('text/markdown');
    expect(request.materialProposal?.materialId).toBe(imported.workspaceMaterials[0]?.materialId);
    expect(request.decisionRequestId).toMatch(/^import-lineage:sha256:[a-f0-9]{64}$/);
  });

  it('rejects an artifact update delta detached from its artifact-reference Item', () => {
    const input = createWorkResourceLineageExportInput();
    const content = '# Independently valid Artifact';
    const contentDigest = `sha256:${createHash('sha256').update(content).digest('hex')}`;
    input.artifacts = [
      ...input.artifacts,
      {
        id: 'ar_00000000-0000-7dcf-9e49-194b732024ae',
        workspaceId: source.workspaceId,
        threadId: null,
        turnId: null,
        kind: 'summary',
        title: 'Other Artifact',
        status: 'ready',
        summary: null,
        version: 1,
        content: { format: 'markdown', body: content },
        contentDigest,
        lastMutationRequestId: 'request_other_artifact',
        origin: {
          kind: 'imported',
          sourceKind: 'direct-import',
          sourceId: 'request_other_artifact',
          sourceDigest: contentDigest,
          actor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
          requestId: 'request_other_artifact',
          recordedAt: timestamp,
        },
        createdAt: timestamp,
        updatedAt: timestamp,
      },
    ];
    input.turnEvents = input.turnEvents.map(([turnId, events]) => [
      turnId,
      events.map((event) =>
        event.data.type === 'item-delta' && event.data.deltaKind === 'artifact-updated'
          ? {
              ...event,
              data: { ...event.data, artifactId: 'ar_00000000-0000-7dcf-9e49-194b732024ae' },
            }
          : event
      ),
    ]);

    expect(() => importLineage(input)).toThrow(
      'Artifact update delta has contradictory artifact-reference lineage.'
    );
  });

  it.each([
    {
      name: 'forked Material history',
      alter: (input: WriteWorkspaceExportTreeInput) => {
        input.workspaceMaterialRevisions = [
          ...(input.workspaceMaterialRevisions ?? []),
          {
            ...(input.workspaceMaterialRevisions?.[1] as Record<string, unknown>),
            revisionId: 'mrev_00000000-0000-7269-8285-6d92cf591190',
          },
        ];
      },
    },
    {
      name: 'digest-invalid revision',
      alter: (input: WriteWorkspaceExportTreeInput) => {
        input.workspaceMaterialRevisions = (input.workspaceMaterialRevisions ?? []).map(
          (revision, index) =>
            index === 1
              ? { ...(revision as Record<string, unknown>), content: 'Changed.' }
              : revision
        );
      },
    },
    {
      name: 'dangling Review result',
      alter: (input: WriteWorkspaceExportTreeInput) => {
        input.artifactReviews = (input.artifactReviews ?? []).map((review) => ({
          ...(review as Record<string, unknown>),
          appliedMaterialRevisionId: 'mrev_00000000-0000-7dd6-ad6d-05f41582f248',
        }));
      },
    },
    {
      name: 'Material mutation proof detached from its current revision',
      alter: (input: WriteWorkspaceExportTreeInput) => {
        input.workspaceMaterials = (input.workspaceMaterials ?? []).map((material) => ({
          ...(material as Record<string, unknown>),
          lastMutationRequestId: 'request_other',
        }));
      },
    },
    {
      name: 'stale bound Material queue',
      alter: (input: WriteWorkspaceExportTreeInput) => {
        input.threadMaterialBindings = (input.threadMaterialBindings ?? []).map((binding) => ({
          ...(binding as Record<string, unknown>),
          latestQueuedRevisionId: 'mrev_00000000-0000-72e5-99f1-5042ef903012',
        }));
      },
    },
    {
      name: 'future decided Review version',
      alter: (input: WriteWorkspaceExportTreeInput) => {
        input.artifactReviews = (input.artifactReviews ?? []).map((review) => ({
          ...(review as Record<string, unknown>),
          reviewId: deriveArtifactReviewId(source.workspaceId, source.artifactId, 2),
          artifactVersion: 2,
        }));
      },
    },
    {
      name: 'media-incompatible Review follow-up proposal',
      createInput: () => createWorkResourceLineageExportInput({ artifactMediaType: 'text/plain' }),
      error: 'Artifact Review follow-up Turn lineage is contradictory.',
      alter: () => undefined,
    },
    {
      name: 'malformed import-lineage follow-up request',
      createInput: () =>
        createWorkResourceLineageExportInput({
          decisionRequestId: 'import-lineage:not-a-digest',
        }),
      error: 'Artifact Review follow-up Turn lineage is contradictory.',
      alter: () => undefined,
    },
    {
      name: 'self-referential Review follow-up Turn',
      alter: (input: WriteWorkspaceExportTreeInput) => {
        input.artifactReviews = (input.artifactReviews ?? []).map((review) => ({
          ...(review as Record<string, unknown>),
          appliedMaterialRevisionId: null,
          decision: 'redo',
          feedback: 'Try again.',
          followUpTurnId: source.turnId,
        }));
      },
    },
    {
      name: 'untraced sibling Review follow-up Turn',
      alter: (input: WriteWorkspaceExportTreeInput) => {
        input.turns = [
          ...input.turns,
          {
            ...(input.turns[0] as Record<string, unknown>),
            agentSessionId: null,
            id: 'tu_00000000-0000-77d9-ad4d-ea2f2a5f70aa',
            items: [],
          },
        ];
        input.artifactReviews = (input.artifactReviews ?? []).map((review) => ({
          ...(review as Record<string, unknown>),
          appliedMaterialRevisionId: null,
          decision: 'redo',
          feedback: 'Try again.',
          followUpTurnId: 'tu_00000000-0000-77d9-ad4d-ea2f2a5f70aa',
        }));
      },
    },
    {
      name: 'media-incompatible unresolved proposal',
      alter: (input: WriteWorkspaceExportTreeInput) => {
        const baseRevision = input.workspaceMaterialRevisions?.[0] as Record<string, unknown>;
        input.workspaceMaterialRevisions = [baseRevision];
        input.workspaceMaterials = (input.workspaceMaterials ?? []).map((material) => ({
          ...(material as Record<string, unknown>),
          currentRevisionId: 'mrev_00000000-0000-72e5-99f1-5042ef903012',
          lastMutationRequestId: baseRevision.createdByRequestId,
        }));
        input.threadMaterialBindings = (input.threadMaterialBindings ?? []).map((binding) => ({
          ...(binding as Record<string, unknown>),
          latestQueuedRevisionId: 'mrev_00000000-0000-72e5-99f1-5042ef903012',
        }));
        input.artifacts = input.artifacts.map((artifact) => ({
          ...(artifact as Record<string, unknown>),
          content: { format: 'text', body: '# Portable' },
        }));
        input.artifactReviews = (input.artifactReviews ?? []).map((review) => ({
          ...(review as Record<string, unknown>),
          decision: null,
          decisionActorId: null,
          decisionRequestId: null,
          decidedAt: null,
          appliedMaterialRevisionId: null,
        }));
      },
    },
    {
      name: 'missing S39 package for a worker Turn',
      alter: (input: WriteWorkspaceExportTreeInput) => {
        input.artifactReviews = [];
        input.portableFileState = {
          ...input.portableFileState!,
          workerContextPackageFiles: new Map(),
        };
      },
    },
  ])('rejects a $name before target writes', (testCase) => {
    const input =
      'createInput' in testCase ? testCase.createInput() : createWorkResourceLineageExportInput();
    testCase.alter(input);

    if ('error' in testCase) {
      expect(() => importLineage(input)).toThrow(testCase.error);
    } else {
      expect(() => importLineage(input)).toThrow();
    }
  });

  it.each([
    ['aep-item', 'it_00000000-0000-7cd6-8d25-15aa6e49eadb'],
    ['aep-session', /lineage|as_missing/i],
    ['capability-thread', 'th_00000000-0000-70ca-938d-c2a0530f9882'],
    ['checkpoint-turn', 'tu_00000000-0000-7577-9378-7e96d0d15fd2'],
    ['git-approval', 'apr_missing'],
    ['permission-approval', 'apr_missing'],
    ['repository-grant', 'grant_00000000-0000-7278-b714-46e2d53cb316'],
    ['resolved-turn', 'tu_00000000-0000-7577-9378-7e96d0d15fd2'],
    ['runtime-turn', 'tu_00000000-0000-7577-9378-7e96d0d15fd2'],
    ['sync-artifact', 'ar_00000000-0000-7aa2-bfd7-c36b2d13b35a'],
    ['usage-session', 'as_00000000-0000-7fdd-8f71-4a23eb7a922b'],
    ['vault-approval', 'apr_missing'],
    ['vault-session', 'as_00000000-0000-7fdd-8f71-4a23eb7a922b'],
  ] as const)('fails closed when %s references state outside the export', (missing, error) => {
    expect(() => importLineage(createLineageExportInput(missing))).toThrow(error);
  });

  it('exports and remints exact binary runtime provenance alongside its product-safe index', () => {
    const input = createLineageExportInput();
    const packageSnapshotId = input.agentEnvironmentPackageSnapshots![0]!.snapshotId;
    const rawBundleId = 'evb_runtime_raw_source';
    const indexBundleId = 'evb_runtime_index_source';
    const runtimeEvidenceId = 'rte_runtime_source';
    const rawBytes = Buffer.from([0, 255, 128, 10, 13, 0, 254]);
    const rawDigest = `sha256:${createHash('sha256').update(rawBytes).digest('hex')}`;
    const rawPath = `workspace-files/evidence/backend/${rawBundleId}/raw/native-canary.bin`;
    const sourceOriginRef = `rto_${'a'.repeat(24)}`;
    const sourceTurnRef = `rtt_${'b'.repeat(24)}`;
    const indexText = `${JSON.stringify({
      lineage: {
        workspaceId: source.workspaceId,
        threadId: source.threadId,
        turnId: source.turnId,
        agentSessionId: source.sessionId,
        packageSnapshotId,
        requestId: 'request_source',
      },
      streamRef: 'stream-0000.jsonl',
      frameSequence: 0,
      byteOffset: 0,
      byteLength: 24,
      frameSha256: `sha256:${'1'.repeat(64)}`,
      eventKind: 'thread.started',
      parseStatus: 'parsed',
      runtimeOriginRef: sourceOriginRef,
      parentRuntimeOriginRef: null,
      runtimeTurnRef: sourceTurnRef,
      runtimeRole: 'worker',
      runtimeDepth: 0,
    })}\n`;
    const indexDigest = `sha256:${createHash('sha256').update(indexText).digest('hex')}`;
    input.evidenceBundles = [
      {
        id: rawBundleId,
        workspaceId: source.workspaceId,
        threadId: source.threadId,
        goalId: null,
        turnId: source.turnId,
        agentSessionId: source.sessionId,
        backendType: 'openshell',
        sourceKind: 'worker-runtime-provenance-raw',
        summary: 'Restricted runtime provenance.',
        rawEvidenceRefs: [
          { kind: 'worker-runtime-provenance-stream', ref: 'raw/native-canary.bin' },
        ],
        redactedEvidenceRefs: [],
        contentDigests: [rawDigest],
        retentionClass: 'restricted-raw',
        sensitivityClass: 'restricted',
        importStatus: 'promoted',
        requiredFeatures: ['worker.runtime-provenance.v1'],
        createdAt: timestamp,
      },
      {
        id: indexBundleId,
        workspaceId: source.workspaceId,
        threadId: source.threadId,
        goalId: null,
        turnId: source.turnId,
        agentSessionId: source.sessionId,
        backendType: 'openshell',
        sourceKind: 'worker-runtime-provenance-index',
        summary: 'Product-safe runtime provenance.',
        rawEvidenceRefs: [],
        redactedEvidenceRefs: [
          { kind: 'worker-runtime-provenance-index', ref: 'runtime-origin-index.jsonl' },
        ],
        contentDigests: [indexDigest],
        retentionClass: 'turn-evidence',
        sensitivityClass: 'product-safe',
        importStatus: 'promoted',
        requiredFeatures: ['worker.runtime-provenance.v1'],
        createdAt: timestamp,
      },
    ];
    input.runtimeEvidence = [
      {
        id: runtimeEvidenceId,
        workspaceId: source.workspaceId,
        threadId: source.threadId,
        turnId: source.turnId,
        goalId: null,
        taskId: null,
        agentSessionId: source.sessionId,
        backendType: 'openshell',
        backendVersion: '0.0.80',
        placement: 'local',
        phase: 'transcript-collection',
        summary: 'Portable runtime provenance.',
        policyDigest: null,
        workerImage: null,
        sandboxSummary: null,
        capabilitySummary: null,
        uploadManifest: [],
        downloadManifest: [],
        transcriptSummary: null,
        workspaceChangeSummary: null,
        controlSummary: null,
        outcome: 'succeeded',
        exitCode: null,
        signal: null,
        stopReason: null,
        errorCode: null,
        errorMessage: null,
        redactedStdoutSummary: null,
        redactedStderrSummary: null,
        evidenceBundleIds: [rawBundleId, indexBundleId],
        contentDigests: [rawDigest, indexDigest],
        requiredFeatures: ['worker.runtime-provenance.v1'],
        createdAt: timestamp,
        startedAt: null,
        completedAt: null,
        collectedAt: timestamp,
      },
    ];
    input.runtimeProvenanceIndexes = new Map([[indexBundleId, indexText]]);
    input.restrictedEvidenceFiles = new Map([[`${rawBundleId}/raw/native-canary.bin`, rawBytes]]);
    const sourceCacheLineageRef = `rcl_${'c'.repeat(24)}`;
    input.capabilityCalls = [
      {
        ...(input.capabilityCalls?.[0] as Record<string, unknown>),
        packageSnapshotId,
        runtimeOriginRef: sourceOriginRef,
        runtimeCacheLineageRef: sourceCacheLineageRef,
      },
      {
        ...(input.capabilityCalls?.[0] as Record<string, unknown>),
        id: 'cap_00000000-0000-7571-b976-68dc4eb78315',
        packageSnapshotId,
        runtimeOriginRef: sourceOriginRef,
        runtimeCacheLineageRef: sourceCacheLineageRef,
      },
    ];

    const verified = writeWorkspaceExportTree(input);
    const exportedBundles = readFileSync(
      join(input.exportRoot, 'records', 'evidence-bundles.jsonl'),
      'utf8'
    )
      .trim()
      .split('\n')
      .map((line) => JSON.parse(line) as Record<string, unknown>);
    expect(exportedBundles.find((bundle) => bundle.id === rawBundleId)).toMatchObject({
      id: rawBundleId,
      importStatus: 'promoted',
      rawEvidenceRefs: [{ kind: 'worker-runtime-provenance-stream', ref: 'raw/native-canary.bin' }],
      redactedEvidenceRefs: [],
      contentDigests: [rawDigest],
    });
    expect(verified.binaryFileContents.get(rawPath)).toEqual(rawBytes);
    expect(readFileSync(join(input.exportRoot, rawPath))).toEqual(rawBytes);
    expect(
      verified.manifest.contentInventory.find((entry) => entry.path === rawPath)
    ).toMatchObject({
      bytes: rawBytes.byteLength,
      digest: rawDigest,
    });
    expect(
      verified.fileContents.get(
        `workspace-files/evidence/bundles/${indexBundleId}/runtime-origin-index.jsonl`
      )
    ).toBe(indexText);
    const missingBinary = new Map(verified.binaryFileContents);
    missingBinary.delete(rawPath);
    expect(() =>
      readWorkspaceImportSnapshot({
        verified: { ...verified, binaryFileContents: missingBinary },
        targetWorkspaceId,
      })
    ).toThrow(/Restricted evidence bytes are missing or invalid/);
    const tamperedBinary = new Map(verified.binaryFileContents);
    tamperedBinary.set(rawPath, Buffer.from([0]));
    expect(() =>
      readWorkspaceImportSnapshot({
        verified: { ...verified, binaryFileContents: tamperedBinary },
        targetWorkspaceId,
      })
    ).toThrow(/Restricted evidence bytes are missing or invalid/);

    const imported = readWorkspaceImportSnapshot({
      verified,
      targetWorkspaceId,
    }) as ReturnType<typeof readWorkspaceImportSnapshot> & {
      runtimeProvenanceIndexes: ReadonlyMap<string, string>;
    };
    const importedRawBundle = imported.evidenceBundles.find(
      (bundle) => bundle.sourceKind === 'worker-runtime-provenance-raw'
    );
    const importedIndexBundle = imported.evidenceBundles.find(
      (bundle) => bundle.sourceKind === 'worker-runtime-provenance-index'
    );
    expect(importedRawBundle).toMatchObject({
      importStatus: 'promoted',
      rawEvidenceRefs: [{ kind: 'worker-runtime-provenance-stream', ref: 'raw/native-canary.bin' }],
      contentDigests: [rawDigest],
    });
    expect(importedRawBundle?.id).not.toBe(rawBundleId);
    expect(
      imported.restrictedEvidenceFiles.get(`${importedRawBundle?.id}/raw/native-canary.bin`)
    ).toEqual(rawBytes);
    expect(importedIndexBundle?.id).not.toBe(indexBundleId);
    expect(imported.runtimeEvidence[0]?.id).not.toBe(runtimeEvidenceId);
    expect(imported.runtimeEvidence[0]?.evidenceBundleIds).toEqual([
      importedRawBundle?.id,
      importedIndexBundle?.id,
    ]);
    const importedIndexText = imported.runtimeProvenanceIndexes.get(importedIndexBundle?.id ?? '');
    expect(importedIndexText).not.toContain(source.workspaceId);
    expect(importedIndexText).not.toContain(source.threadId);
    expect(importedIndexText).not.toContain(source.turnId);
    expect(importedIndexText).not.toContain(source.sessionId);
    expect(importedIndexText).not.toContain(packageSnapshotId);
    expect(importedIndexText).not.toContain(sourceOriginRef);
    expect(importedIndexText).not.toContain(sourceTurnRef);
    const importedIndexRow = JSON.parse(importedIndexText?.trim() ?? '{}') as {
      lineage?: { packageSnapshotId?: string };
      runtimeOriginRef?: string;
      runtimeTurnRef?: string;
    };
    expect(importedIndexRow.runtimeTurnRef).toMatch(/^rtt_[a-f0-9]{24}$/);
    expect(imported.capabilityCalls[0]).toMatchObject({
      packageSnapshotId: importedIndexRow.lineage?.packageSnapshotId,
      runtimeOriginRef: importedIndexRow.runtimeOriginRef,
    });
    expect(imported.capabilityCalls[0]?.runtimeCacheLineageRef).toMatch(/^rcl_[a-f0-9]{24}$/);
    expect(imported.capabilityCalls[0]?.runtimeCacheLineageRef).not.toBe(sourceCacheLineageRef);
    expect(imported.capabilityCalls[1]?.runtimeCacheLineageRef).toBe(
      imported.capabilityCalls[0]?.runtimeCacheLineageRef
    );
    expect(importedIndexBundle?.contentDigests).toEqual([
      `sha256:${createHash('sha256')
        .update(importedIndexText ?? '')
        .digest('hex')}`,
    ]);

    const failedRaw = writeWorkspaceExportTree({
      ...input,
      exportRoot: join(mkdtempSync(join(tmpdir(), 'openkit-provenance-failed-')), 'export'),
      evidenceBundles: [
        { ...(input.evidenceBundles![0] as Record<string, unknown>), importStatus: 'quarantined' },
      ],
      runtimeEvidence: [
        {
          ...(input.runtimeEvidence![0] as Record<string, unknown>),
          id: createWorkerRuntimeProvenanceEvidenceId(packageSnapshotId),
          evidenceBundleIds: [rawBundleId],
          contentDigests: [rawDigest],
          outcome: 'failed',
          errorCode: 'worker_runtime_provenance_invalid',
          errorMessage: 'Worker runtime provenance verification failed.',
        },
      ],
      runtimeProvenanceIndexes: new Map(),
      capabilityCalls: createLineageExportInput().capabilityCalls,
    });
    expect(failedRaw.binaryFileContents.get(rawPath)).toEqual(rawBytes);
    const importedFailed = readWorkspaceImportSnapshot({
      verified: failedRaw,
      targetWorkspaceId: 'ws_00000000-0000-7aa7-be6a-dcdb6a885d4a',
    });
    const importedFailedRaw = importedFailed.evidenceBundles.find(
      (bundle) => bundle.sourceKind === 'worker-runtime-provenance-raw'
    )!;
    expect(importedFailed.evidenceBundles).toHaveLength(1);
    expect(importedFailedRaw.importStatus).toBe('quarantined');
    expect(importedFailedRaw.id).not.toBe(rawBundleId);
    expect(importedFailed.runtimeEvidence[0]?.evidenceBundleIds).toEqual([importedFailedRaw.id]);
    expect(
      importedFailed.restrictedEvidenceFiles.get(`${importedFailedRaw.id}/raw/native-canary.bin`)
    ).toEqual(rawBytes);
    const mismatchedOwnerFiles = new Map(failedRaw.fileContents);
    for (const path of ['records/evidence-bundles.jsonl', 'records/runtime-evidence.jsonl']) {
      const record = JSON.parse(mismatchedOwnerFiles.get(path)!) as Record<string, unknown>;
      mismatchedOwnerFiles.set(path, `${JSON.stringify({ ...record, agentSessionId: null })}\n`);
    }
    expect(() =>
      readWorkspaceImportSnapshot({
        verified: { ...failedRaw, fileContents: mismatchedOwnerFiles },
        targetWorkspaceId: 'ws_00000000-0000-70ec-b895-5081a8a2dcea',
      })
    ).toThrow(/Runtime provenance bundle linkage is incomplete/);
    for (const mismatch of [
      { backendType: 'other-backend' },
      { contentDigests: [`sha256:${'f'.repeat(64)}`] },
    ]) {
      const fileContents = new Map(failedRaw.fileContents);
      const path = 'records/runtime-evidence.jsonl';
      const record = JSON.parse(fileContents.get(path)!) as Record<string, unknown>;
      fileContents.set(path, `${JSON.stringify({ ...record, ...mismatch })}\n`);
      expect(() =>
        readWorkspaceImportSnapshot({
          verified: { ...failedRaw, fileContents },
          targetWorkspaceId: 'ws_00000000-0000-7545-858a-3d46b350bbc3',
        })
      ).toThrow(/Runtime provenance bundle linkage is incomplete/);
    }
    const duplicateRawId = 'evb_runtime_raw_source_duplicate';
    const duplicateFiles = new Map(failedRaw.fileContents);
    const rawRecord = JSON.parse(duplicateFiles.get('records/evidence-bundles.jsonl')!) as Record<
      string,
      unknown
    >;
    duplicateFiles.set(
      'records/evidence-bundles.jsonl',
      `${JSON.stringify(rawRecord)}\n${JSON.stringify({ ...rawRecord, id: duplicateRawId })}\n`
    );
    const runtimeRecord = JSON.parse(
      duplicateFiles.get('records/runtime-evidence.jsonl')!
    ) as Record<string, unknown>;
    duplicateFiles.set(
      'records/runtime-evidence.jsonl',
      `${JSON.stringify({
        ...runtimeRecord,
        evidenceBundleIds: [rawBundleId, duplicateRawId],
        contentDigests: [rawDigest, rawDigest],
      })}\n`
    );
    const duplicateBinary = new Map(failedRaw.binaryFileContents);
    duplicateBinary.set(
      `workspace-files/evidence/backend/${duplicateRawId}/raw/native-canary.bin`,
      rawBytes
    );
    expect(() =>
      readWorkspaceImportSnapshot({
        verified: {
          ...failedRaw,
          fileContents: duplicateFiles,
          binaryFileContents: duplicateBinary,
        },
        targetWorkspaceId: 'ws_00000000-0000-7f94-8d9a-a38dbeb79435',
      })
    ).toThrow(/Runtime provenance bundle linkage is incomplete/);

    const unlinkedRoot = join(
      mkdtempSync(join(tmpdir(), 'openkit-workspace-provenance-unlinked-')),
      'export'
    );
    const unlinked = writeWorkspaceExportTree({
      ...input,
      exportRoot: unlinkedRoot,
      runtimeEvidence: [],
    });
    expect(() =>
      readWorkspaceImportSnapshot({
        verified: unlinked,
        targetWorkspaceId: 'ws_00000000-0000-7643-964e-afa983ac66f6',
      })
    ).toThrow(/runtime provenance.*link/i);

    const alternateImport = readWorkspaceImportSnapshot({
      verified,
      targetWorkspaceId: 'ws_00000000-0000-7f0d-9740-60fe82c12b26',
    });
    expect(alternateImport.capabilityCalls[0]?.runtimeCacheLineageRef).not.toBe(
      imported.capabilityCalls[0]?.runtimeCacheLineageRef
    );

    const unmatchedRoot = join(
      mkdtempSync(join(tmpdir(), 'openkit-workspace-provenance-unmatched-')),
      'export'
    );
    const unmatched = writeWorkspaceExportTree({
      ...input,
      exportRoot: unmatchedRoot,
      capabilityCalls: [
        {
          ...(input.capabilityCalls?.[0] as Record<string, unknown>),
          runtimeOriginRef: `rto_${'f'.repeat(24)}`,
        },
      ],
    });
    expect(() =>
      readWorkspaceImportSnapshot({
        verified: unmatched,
        targetWorkspaceId: 'ws_00000000-0000-7655-ba52-0131487ca8c0',
      })
    ).toThrow(/runtime origin.*normalized index/i);
  });
});

// This fixture supplies confirmed image evidence; the production resolver and subject checks still run.
vi.mock('../runtime/agent-environment.js', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../runtime/agent-environment.js')>();
  const { withTestPreparedNativeEnvironment } = await import(
    '../test-support/native-environment.js'
  );
  return withTestPreparedNativeEnvironment(actual);
});

describe('slice 1d portable call fields', () => {
  it('preserves route extensions and present or absent system-prompt digests through archive export and import', () => {
    const input = createLineageExportInput();
    const digest = `sha256:${'b'.repeat(64)}`;
    const lineage = {
      logicalModelId: 'tier',
      entries: [
        {
          kind: 'attempt',
          routeMemberId: 'primary',
          providerProfileId: 'profile',
          providerModel: 'native',
          selectionReason: 'primary',
          attemptOrder: 0,
          retryIndex: 0,
          outputBegan: true,
          terminalResult: 'succeeded',
          usageRecordIds: ['use_00000000-0000-7833-a8fc-60af429f21b9'],
        },
      ],
    };
    input.capabilityCalls = [
      {
        ...input.capabilityCalls![0],
        capabilityId: 'llm.responses',
        family: 'llm',
        systemPromptDigest: digest,
        extensions: {
          'openkit.gateway/routeLineage': lineage,
          'future.example/evidence': { label: 'retained' },
        },
      },
      { ...input.capabilityCalls![0], id: 'cap_00000000-0000-7ff2-b713-d35db1d00ca0' },
    ];
    const sourceDb = openWorkspaceDb(
      mkdtempSync(join(tmpdir(), 'gateway-call-source-')),
      source.workspaceId
    );
    try {
      applyScopedMigrations(sourceDb);
      importWorkspaceCapabilityUsageLedger({
        workspaceDb: sourceDb,
        capabilityCalls: input.capabilityCalls as never,
        usageRecords: [],
      });
      sourceDb.sqlite
        .prepare('UPDATE capability_calls SET extensions_json = ? WHERE call_id = ?')
        .run(
          JSON.stringify({
            'openkit.gateway/routeLineage': lineage,
            'future.example/evidence': { label: 'retained' },
          }),
          'cap_00000000-0000-711a-9c64-db220d6b90dc'
        );
      input.capabilityCalls = listWorkspaceCapabilityCalls(sourceDb, source.workspaceId);
    } finally {
      sourceDb.sqlite.close();
    }
    const exportRoot = join(mkdtempSync(join(tmpdir(), 'gateway-call-export-')), 'export');
    const verified = writeWorkspaceExportTree({ ...input, exportRoot });
    const snapshot = readWorkspaceImportSnapshot({ verified, targetWorkspaceId });
    const db = openWorkspaceDb(
      mkdtempSync(join(tmpdir(), 'gateway-call-import-')),
      targetWorkspaceId
    );
    try {
      applyScopedMigrations(db);
      importWorkspaceCapabilityUsageLedger({
        workspaceDb: db,
        capabilityCalls: snapshot.capabilityCalls,
        usageRecords: snapshot.usageRecords,
      });
      const imported = listWorkspaceCapabilityCalls(db, targetWorkspaceId);
      expect(
        imported.find((call) => call.id === 'cap_00000000-0000-711a-9c64-db220d6b90dc')
      ).toMatchObject({
        systemPromptDigest: digest,
        extensions: {
          'openkit.gateway/routeLineage': lineage,
          'future.example/evidence': { label: 'retained' },
        },
      });
      expect(
        imported.find((call) => call.id === 'cap_00000000-0000-7ff2-b713-d35db1d00ca0')
      ).not.toHaveProperty('systemPromptDigest');
      expect(
        imported.find((call) => call.id === 'cap_00000000-0000-7ff2-b713-d35db1d00ca0')
      ).not.toHaveProperty('extensions');
      const row = db.sqlite
        .prepare(
          'SELECT system_prompt_digest, extensions_json FROM capability_calls WHERE call_id = ?'
        )
        .get('cap_00000000-0000-711a-9c64-db220d6b90dc') as {
        system_prompt_digest: string;
        extensions_json: string;
      };
      expect(row.system_prompt_digest).toBe(digest);
      expect(JSON.parse(row.extensions_json)).toEqual({
        'openkit.gateway/routeLineage': lineage,
        'future.example/evidence': { label: 'retained' },
      });
    } finally {
      db.sqlite.close();
    }
  });
});

it('carries current Goal records through portability without changing approved bytes or restoring grants', () => {
  const input = createLineageExportInput();
  const goalThread = 'th_00000000-0000-720d-b93a-e3ab6e5c756b';
  const commitment = {
    intentBasis: { revision: 0, intent: 'Review the schema' },
    cards: [{ cardId: 'gc_portable', revision: 0, description: 'Review', priority: 0 }],
    permittedAdjustments: 'Review only',
    completionEvidence: ['Review evidence'],
    boundaries: 'No publication',
  };
  const bytes = JSON.stringify(commitment);
  const digest = `sha256:${createHash('sha256').update(bytes).digest('hex')}`;
  input.threads = [
    ...input.threads,
    { ...(input.threads[0] as Record<string, unknown>), id: goalThread, name: 'Goal Coordinator' },
  ];
  input.goalState = {
    goals: [
      {
        goalId: 'g_portable',
        workspaceId: source.workspaceId,
        threadId: goalThread,
        responsibleUserId: 'usr_00000000-0000-7431-921d-ea7bcc58a6f2',
        responsibleActorContext: {
          kind: 'session',
          userId: 'usr_00000000-0000-7431-921d-ea7bcc58a6f2',
        },
        intent: 'Review current schema',
        intentRevision: 1,
        intentHistory: [
          {
            revision: 0,
            intent: 'Review the schema',
            actorId: 'usr_00000000-0000-7431-921d-ea7bcc58a6f2',
            at: timestamp,
          },
          {
            revision: 1,
            intent: 'Review current schema',
            actorId: 'usr_00000000-0000-7431-921d-ea7bcc58a6f2',
            at: timestamp,
          },
        ],
        activePlanVersionId: 'gp_portable',
        proposedPlanVersionId: null,
        disposition: null,
        changeRevision: 5,
        consideredRevision: 5,
        createdAt: timestamp,
        updatedAt: timestamp,
      },
    ],
    cards: [
      {
        cardId: 'gc_portable',
        goalId: 'g_portable',
        description: 'Review current schema',
        priority: 0,
        revision: 1,
        cancelled: false,
        cancellationReason: null,
        createdAt: timestamp,
        updatedAt: timestamp,
      },
    ],
    versions: [
      {
        planVersionId: 'gp_portable',
        goalId: 'g_portable',
        sequence: 1,
        bytes,
        digest,
        commitment,
        pendingRequestId: 'ap_source_grant',
        createdAt: timestamp,
      },
    ],
    tasks: [
      {
        goalId: 'g_portable',
        cardId: 'gc_portable',
        threadId: source.threadId,
        planVersionId: 'gp_portable',
        cardRevision: 0,
        admittedAt: timestamp,
      },
    ],
    terminalFacts: [],
  };
  const imported = importLineage(input);
  expect(imported.goalState.versions[0]!.bytes).toBe(bytes);
  expect(imported.goalState.versions[0]!.digest).toBe(digest);
  expect(imported.goalState.goals[0]).toMatchObject({
    workspaceId: targetWorkspaceId,
    intentRevision: 1,
    activePlanVersionId: 'gp_portable',
    changeRevision: 6,
    consideredRevision: 5,
  });
  expect(imported.goalState.goals[0]!.threadId).toBe(imported.threadIds.get(goalThread));
  expect(imported.goalState.tasks[0]!.threadId).toBe(imported.threadIds.get(source.threadId));
  expect(imported.goalState.cards[0]!.revision).toBe(1);
  expect('pendingRequests' in imported.goalState).toBe(false);
  // Lost ordinary history remains missing; its committed result must still be portable.
  const absentFact = {
    id: 'tu_00000000-0000-70da-9270-28693b06ee06',
    workspaceId: source.workspaceId,
    threadId: 'th_00000000-0000-749e-a37d-2ae7769a39a8',
    status: 'failed',
    error: { code: 'worker_failed', message: 'Retained failure' },
    completedAt: timestamp,
    durationMs: 0,
  };
  input.goalState = {
    ...(input.goalState as Record<string, unknown>),
    terminalFacts: [absentFact],
  };
  const absentHistory = importLineage({
    ...input,
    exportRoot: join(mkdtempSync(join(tmpdir(), 'goal-absent-task-')), 'export'),
  });
  expect(absentHistory.goalState.terminalFacts[0]).toEqual({
    ...absentFact,
    workspaceId: targetWorkspaceId,
  });
  expect(absentHistory.threadIds.has(absentFact.threadId)).toBe(false);
  expect(absentHistory.turnIds.has(absentFact.id)).toBe(false);
  input.goalState = {
    ...(input.goalState as Record<string, unknown>),
    terminalFacts: [{ ...absentFact, workspaceId: 'ws_00000000-0000-7f9c-aa14-53566c621405' }],
  };
  expect(() =>
    importLineage({
      ...input,
      exportRoot: join(mkdtempSync(join(tmpdir(), 'goal-foreign-task-')), 'export'),
    })
  ).toThrow('Task terminal fact');
});
