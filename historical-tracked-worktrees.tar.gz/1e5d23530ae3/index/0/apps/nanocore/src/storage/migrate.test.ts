import {
  existsSync,
  mkdirSync,
  mkdtempSync,
  readdirSync,
  readFileSync,
  writeFileSync,
} from 'node:fs';
import { tmpdir } from 'node:os';
import { join, relative, sep } from 'node:path';
import Database from 'better-sqlite3';
import { describe, expect, it } from 'vitest';
import { BootConfigError } from '../config/mode';
import { readNanoHostThreadAgentSessionBinding } from '../runtime/nanohost-harness-records.js';
import { testEntityId } from '../test-support/entity-ids.js';
import { recordWorkspaceOwnerMembership } from '../workspace-membership';
import { openCoreDb, openUserDb, openWorkspaceDb } from './db';
import { coreDbPath, workspaceDbPath } from './fs-layout';
import {
  applyMigrations,
  applyNativeScopeMigrations,
  applyScopedMigrations,
  listAppliedMigrationIds,
  listAppliedNativeMigrationIds,
  type StorageMigrationScope,
} from './migrate';

const CORE_TABLES = [
  '__drizzle_migrations',
  'account',
  'agent_session_runtime_binding_image_digests',
  'agent_session_runtime_bindings',
  'audit_events',
  'boot_audit_events',
  'harness_instance_records',
  'idempotency_requests',
  'nanohost_integration_identities',
  'nanohost_runtime_targets',
  'nanohost_transport_tokens',
  'openkit_access_tokens',
  'permission_decisions',
  'sandbox_runtime_records',
  'scheduler_admission_entries',
  'server_settings',
  'session',
  'users',
  'vault_admin_audit_events',
  'vault_grants',
  'vault_injection_plans',
  'vault_injection_receipts',
  'vault_references',
  'vault_use_records',
  'verification',
  'worker_backend_sessions',
  'worker_control_records',
  'worker_control_rejected_evidence',
  'worker_control_sequence_fingerprints',
  'worker_image_settlements',
  'worker_storage_bindings',
  'worker_storage_contributors',
  'workspace_invitations',
  'workspace_members',
  'workspace_registry',
];

const WORKSPACE_TABLES = [
  '__drizzle_migrations',
  'artifact_reviews',
  'audit_events',
  'backend_workspace_handles',
  'capability_calls',
  'evidence_bundles',
  'generative_presentations',
  'goal_card_tasks',
  'goal_cards',
  'goal_plan_versions',
  'goals',
  'idempotency_requests',
  'mcp_tool_schema_snapshots',
  'pending_requests',
  'permission_decisions',
  'resolved_agent_setups',
  'runtime_evidence',
  'staged_workspace_reviews',
  'task_turn_terminal_facts',
  'thread_material_bindings',
  'usage_records',
  'vault_use_records',
  'worker_output_manifests',
  'worker_turn_checkpoints',
  'workspace_apply_plans',
  'workspace_apply_results',
  'workspace_change_sets',
  'workspace_filesystem_staging_roots',
  'workspace_input_snapshots',
  'workspace_material_revisions',
  'workspace_materialization_records',
  'workspace_materials',
  'workspace_quarantine_records',
  'workspace_reconciliation_records',
  'workspace_snapshot_collections',
  'workspace_snapshot_cursors',
];

/**
 * Creates an isolated data root for database setup tests.
 *
 * @returns Absolute temporary data-root path.
 */
function createDataRoot(): string {
  return mkdtempSync(join(tmpdir(), 'openkit-migrate-'));
}

/**
 * Recursively lists repository source files under one directory.
 *
 * @param root Root directory to scan.
 * @returns Absolute file paths.
 */
function listSourceFiles(root: string): string[] {
  const entries = readdirSync(root, { withFileTypes: true });
  const files: string[] = [];

  for (const entry of entries) {
    const path = join(root, entry.name);

    if (entry.isDirectory()) {
      files.push(...listSourceFiles(path));
      continue;
    }

    if (entry.isFile() && path.endsWith('.ts')) {
      files.push(path);
    }
  }

  return files;
}

/**
 * Lists non-SQLite-internal table names in stable order.
 *
 * @param db Database wrapper with a raw SQLite connection.
 * @returns Table names.
 */
function listTableNames(db: { sqlite: { prepare: (sql: string) => { all: () => unknown[] } } }) {
  return db.sqlite
    .prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'")
    .all()
    .map((row) => (row as { name: string }).name)
    .sort();
}

/**
 * Lists applied native migration ids for one scope.
 *
 * @param db Database wrapper with a raw SQLite connection.
 * @param scope Journal scope.
 * @param migrationsFolder Optional explicit journal folder.
 * @returns Applied setup ids.
 */
function listMigrationIds(
  db: { sqlite: Database.Database },
  scope: StorageMigrationScope,
  migrationsFolder?: string
) {
  return listAppliedNativeMigrationIds(db.sqlite, scope, migrationsFolder);
}

/**
 * Lists column names for one table.
 *
 * @param db Database wrapper with a raw SQLite connection.
 * @param tableName Table to inspect.
 * @returns Column names.
 */
function listColumnNames(
  db: { sqlite: { prepare: (sql: string) => { all: () => unknown[] } } },
  tableName: string
) {
  return db.sqlite
    .prepare(`PRAGMA table_info(${tableName})`)
    .all()
    .map((row) => (row as { name: string }).name);
}

describe('database setup', () => {
  it('applies the Core setup idempotently', () => {
    const dataRoot = createDataRoot();
    const coreDb = openCoreDb(dataRoot);

    try {
      applyMigrations(coreDb);
      const beforeTables = listTableNames(coreDb);
      applyMigrations(coreDb);

      expect(
        readdirSync(join(process.cwd(), 'drizzle', 'core')).filter((name) => name.endsWith('.sql'))
      ).toEqual(['0000_setup.sql', '0001_concurrent_turn_capacity.sql']);
      expect(
        ['app', 'core', 'user', 'workspace'].every((scope) =>
          existsSync(join(process.cwd(), 'drizzle', scope, 'meta', '_journal.json'))
        )
      ).toBe(true);
      expect(listAppliedMigrationIds(coreDb)).toEqual([
        'core_0000_setup',
        'core_0001_concurrent_turn_capacity',
      ]);
      expect(listTableNames(coreDb)).toEqual(beforeTables);
      expect(listTableNames(coreDb)).toEqual(expect.arrayContaining(CORE_TABLES));
      for (const retired of [
        'scheduler_capacity_records',
        'scheduler_placement_plans',
        'scheduler_session_leases',
        'scheduler_worker_pools',
        'scheduler_supply_refresh_declarations',
      ])
        expect(listTableNames(coreDb)).not.toContain(retired);
      expect(listColumnNames(coreDb, 'users')).toEqual([
        'id',
        'display_name',
        'email',
        'email_verified',
        'image',
        'created_at',
        'updated_at',
        'kind',
        'last_seen_at',
        'status',
        'disabled_at',
      ]);
      expect(listColumnNames(coreDb, 'audit_events')).toEqual(
        expect.arrayContaining(['actor_json', 'subject_json', 'resource_revision'])
      );
      expect(listColumnNames(coreDb, 'idempotency_requests')).toEqual([
        'request_key',
        'command_name',
        'request_id',
        'scope_json',
        'input_hash',
        'response_kind',
        'response_id',
        'response_json',
        'created_at',
        'expires_at',
      ]);
      expect(listColumnNames(coreDb, 'worker_storage_bindings')).toEqual([
        'storage_ref',
        'runtime_target_id',
        'deployment_id',
        'workspace_id',
        'scope_digest',
        'layout_digest',
        'layout_family',
        'layout_version',
        'platform_os',
        'platform_architecture',
        'owner_uid',
        'owner_gid',
        'working_directory',
        'targets_json',
        'revision',
        'attachment_generation',
        'state',
        'current_agent_session_id',
        'current_thread_id',
        'current_work_slot_ref',
        'current_sandbox_binding_ref',
        'created_at',
        'updated_at',
        'purged_at',
      ]);
      expect(listColumnNames(coreDb, 'workspace_registry')).toEqual([
        'workspace_id',
        'owner_user_id',
        'status',
        'revision',
        'created_at',
        'updated_at',
      ]);
      expect(listColumnNames(coreDb, 'workspace_members')).toEqual([
        'workspace_id',
        'user_id',
        'status',
        'access_level',
        'invitation_id',
        'joined_at',
        'removed_at',
        'revision',
        'created_at',
        'updated_at',
      ]);
      expect(listColumnNames(coreDb, 'workspace_invitations')).toEqual([
        'invitation_id',
        'workspace_id',
        'invitee_user_id',
        'proposed_access_level',
        'inviter_user_id',
        'status',
        'expires_at',
        'accepted_at',
        'declined_at',
        'revoked_at',
        'revision',
        'created_at',
        'updated_at',
      ]);
      expect(listColumnNames(coreDb, 'openkit_access_tokens')).toEqual([
        'token_id',
        'token_hash',
        'owner_user_id',
        'scope',
        'workspace_ids_json',
        'status',
        'issued_at',
        'expires_at',
        'revoked_at',
        'predecessor_token_id',
        'rotated_grace_expires_at',
        'last_used_at',
        'last_used_channel',
        'last_used_source',
      ]);
      /**
       * S-2b-1 Unit 2: durable NanoHost transport Token metadata projection.
       * Covered by the current Core setup.
       */
      expect(listColumnNames(coreDb, 'nanohost_transport_tokens')).toEqual([
        'token_id',
        'token_hash',
        'owner_nanohost_identity_id',
        'token_type',
        'scope',
        'deployment_id',
        'status',
        'issued_at',
        'expires_at',
        'revoked_at',
        'predecessor_token_id',
        'rotation_overlap_expires_at',
        'responsible_server_admin_actor_id',
        'last_used_at',
        'last_used_channel',
        'last_used_source',
      ]);
      expect(listColumnNames(coreDb, 'nanohost_integration_identities')).toEqual([
        'identity_id',
        'deployment_id',
        'status',
        'created_at',
        'decommissioned_at',
      ]);
      expect(listColumnNames(coreDb, 'nanohost_runtime_targets')).toEqual([
        'target_id',
        'identity_id',
        'deployment_id',
        'connection_generation',
        'predecessor_fenced',
        'ready',
        'fresh_empty',
        'physical_epoch',
        'observed_at',
        'slot_count',
        'last_fresh_ready_at',
      ]);
      expect(listColumnNames(coreDb, 'sandbox_runtime_records')).toEqual([
        'sandbox_runtime_id',
        'runtime_target_id',
        'origin_physical_epoch',
        'sandbox_binding_ref',
        'sandbox_integration_binding_ref',
        'sandbox_compatibility_key',
        'image_digest',
        'environment_class',
        'max_open_sessions',
        'max_harnesses',
        'max_active_turns',
        'lifecycle_state',
        'health_state',
        'drain_state',
        'cleanup_state',
        'created_at',
        'updated_at',
      ]);
      expect(listColumnNames(coreDb, 'harness_instance_records')).toEqual([
        'harness_instance_id',
        'sandbox_runtime_id',
        'harness_binding_ref',
        'harness_compatibility_key',
        'runtime_family',
        'adapter_id',
        'adapter_version',
        'protocol_version',
        'capabilities_json',
        'max_open_sessions',
        'max_active_turns',
        'open_session_count',
        'active_turn_count',
        'lifecycle_state',
        'drain_state',
        'next_sequence',
        'operation_state',
        'operation_id',
        'operation_sequence',
        'operation',
        'command_body_json',
        'command_fingerprint',
        'result_json',
        'result_fingerprint',
        'created_at',
        'updated_at',
      ]);
      expect(listColumnNames(coreDb, 'agent_session_runtime_bindings')).toEqual([
        'agent_session_runtime_binding_id',
        'harness_instance_id',
        'agent_session_id',
        'workspace_id',
        'thread_id',
        'agent_session_compatibility_key',
        'effective_setup_generation',
        'native_handle_state',
        'native_handle_digest',
        'lifecycle_state',
        'current_turn_id',
        'current_attempt_id',
        'next_turn_sequence',
        'cleanup_state',
        'created_at',
        'updated_at',
        'image_digest',
        'native_environment_json',
        'native_environment_applied',
        'inference_loopback_credential_digest',
        'capability_loopback_credential_digest',
        'runtime_env_check_versions_json',
      ]);
      expect(listColumnNames(coreDb, 'agent_session_runtime_binding_image_digests')).toEqual([
        'agent_session_runtime_binding_id',
        'image_digest',
        'copied_at',
      ]);
      const attemptColumns = listColumnNames(coreDb, 'scheduler_execution_attempts');
      expect(attemptColumns).toEqual(expect.arrayContaining(['attempt_id', 'turn_id', 'phase']));
      expect(attemptColumns).not.toEqual(
        expect.arrayContaining(['worker_control_token', 'worker_inference_token'])
      );
      expect(listColumnNames(coreDb, 'scheduler_admission_entries')).toEqual(
        expect.arrayContaining([
          'queue_entry_id',
          'request_id',
          'trigger_actor_json',
          'server_admin_token_id',
          'workspace_id',
          'thread_id',
          'turn_id',
          'turn_input',
          'worker_storage_choice_json',
          'requested_agent_id',
          'status',
        ])
      );
      expect(listColumnNames(coreDb, 'worker_backend_sessions')).toEqual([
        'attempt_id',
        'workspace_id',
        'thread_id',
        'turn_id',
        'agent_session_id',
        'package_snapshot_id',
        'backend_kind',
        'deployment_id',
        'backend_version',
        'worker_image',
        'cell_target_id',
        'placement',
        'gateway_name',
        'gateway_endpoint',
        'backend_session_id',
        'staging_directory_ref',
        'transient_provider_instance_id',
        'workspace_handoff_state',
        'state',
        'physical_cleaned_at',
        'created_at',
        'updated_at',
        'runtime_target_id',
        'origin_physical_epoch',
        'backend_lineage_json',
        'sandbox_binding_ref',
      ]);
      const backendProjectionColumns = coreDb.sqlite
        .prepare('PRAGMA table_info(worker_backend_sessions)')
        .all() as Array<{ name: string; notnull: 0 | 1 }>;
      expect(
        Object.fromEntries(
          backendProjectionColumns
            .filter(({ name }) =>
              [
                'runtime_target_id',
                'backend_lineage_json',
                'sandbox_binding_ref',
                'worker_image',
                'cell_target_id',
                'placement',
                'gateway_name',
                'gateway_endpoint',
              ].includes(name)
            )
            .map(({ name, notnull }) => [name, notnull === 0])
        )
      ).toEqual({
        backend_lineage_json: true,
        cell_target_id: true,
        gateway_endpoint: true,
        gateway_name: true,
        placement: true,
        runtime_target_id: true,
        sandbox_binding_ref: true,
        worker_image: true,
      });
      expect(
        backendProjectionColumns.find(({ name }) => name === 'origin_physical_epoch')?.notnull
      ).toBe(1);
      coreDb.sqlite
        .prepare(
          `INSERT INTO worker_backend_sessions (
             attempt_id, workspace_id, thread_id, turn_id, agent_session_id,
             package_snapshot_id, backend_kind, deployment_id, backend_version,
             worker_image, cell_target_id, placement, gateway_name, gateway_endpoint,
             backend_session_id, origin_physical_epoch, staging_directory_ref, transient_provider_instance_id,
             workspace_handoff_state, state, created_at, updated_at
           ) VALUES (
             'lease-setup-writer', 'ws-setup-writer', 'thread-setup-writer',
             'turn-setup-writer', 'session-setup-writer', 'aepsnap-setup-writer',
             'openshell', 'deployment-setup-writer', '0.0.80',
             'openkit/worker:test', 'cell-setup-writer', 'local', 'openshell', NULL,
             'sandbox-setup-writer', ?, 'server/runtime/setup-writer', NULL,
             'pending', 'materializing',
             '2026-08-10T00:00:00.000Z', '2026-08-10T00:00:00.000Z'
           )`
        )
        .run('a'.repeat(64));
      expect(
        coreDb.sqlite
          .prepare(
            `SELECT runtime_target_id AS runtimeTargetId,
                    backend_lineage_json AS backendLineageJson,
                    sandbox_binding_ref AS sandboxBindingRef
             FROM worker_backend_sessions
             WHERE attempt_id = 'lease-setup-writer'`
          )
          .get()
      ).toEqual({
        backendLineageJson: null,
        runtimeTargetId: null,
        sandboxBindingRef: null,
      });
      expect(listTableNames(coreDb)).not.toContain('workspace_repository_resources');
      expect(coreDbPath(dataRoot)).toMatch(/server\/db\/core\.sqlite$/);
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('applies the User and Workspace setup sections idempotently', () => {
    const dataRoot = createDataRoot();
    const userDb = openUserDb(dataRoot, 'usr_00000000-0000-7e68-8ab1-8dcac1be1b5b');
    const workspaceDb = openWorkspaceDb(dataRoot, testEntityId('ws', 'workspace_1'));

    try {
      applyScopedMigrations(userDb);
      applyScopedMigrations(userDb);
      applyScopedMigrations(workspaceDb);
      applyScopedMigrations(workspaceDb);

      expect(listMigrationIds(userDb, 'user')).toEqual(['user_0000_setup']);
      expect(listTableNames(userDb)).toEqual(['__drizzle_migrations', 'idempotency_requests']);
      expect(listMigrationIds(workspaceDb, 'workspace')).toEqual(['workspace_0000_setup']);
      expect(listTableNames(workspaceDb)).toEqual(WORKSPACE_TABLES);
      const idempotencyRequestColumns = [
        'request_key',
        'command_name',
        'request_id',
        'scope_json',
        'input_hash',
        'response_kind',
        'response_id',
        'response_json',
        'created_at',
        'expires_at',
      ];
      expect(listColumnNames(userDb, 'idempotency_requests')).toEqual(idempotencyRequestColumns);
      expect(listColumnNames(workspaceDb, 'idempotency_requests')).toEqual(
        idempotencyRequestColumns
      );
      expect(listColumnNames(workspaceDb, 'capability_calls')).toEqual([
        'call_id',
        'workspace_id',
        'thread_id',
        'turn_id',
        'item_id',
        'agent_id',
        'agent_session_id',
        'request_id',
        'source_ids_json',
        'capability_id',
        'family',
        'operation',
        'status',
        'summary',
        'provider_ref',
        'service_ref',
        'redaction_class',
        'error_code',
        'started_at',
        'completed_at',
        'package_snapshot_id',
        'schema_snapshot_id',
        'runtime_origin_ref',
        'runtime_cache_lineage_ref',
        'system_prompt_digest',
        'extensions_json',
      ]);
      expect(listColumnNames(workspaceDb, 'usage_records')).toEqual([
        'usage_id',
        'workspace_id',
        'thread_id',
        'turn_id',
        'item_id',
        'capability_call_id',
        'request_id',
        'agent_id',
        'agent_session_id',
        'source_ids_json',
        'category',
        'unit',
        'quantity',
        'model_id',
        'provider_ref',
        'source',
        'recorded_at',
        'responsible_user_id',
      ]);
      expect(listColumnNames(workspaceDb, 'goal_review_records')).toEqual([]);
      expect(listColumnNames(workspaceDb, 'workspace_repository_resources')).toEqual([]);
      expect(listColumnNames(workspaceDb, 'worker_turn_checkpoints')).toEqual([
        'checkpoint_id',
        'workspace_id',
        'thread_id',
        'turn_id',
        'goal_id',
        'task_id',
        'request_id',
        'request_input_hash',
        'stage',
        'iteration',
        'worker_session_id',
        'context_digest',
        'stop_reason',
        'diagnostics_summary',
        'replay_instruction',
        'created_at',
        'updated_at',
      ]);
      expect(listTableNames(workspaceDb)).not.toContain('session');
      expect(workspaceDbPath(dataRoot, 'workspace_1')).toMatch(
        /workspaces\/workspace_1\/db\/workspace\.sqlite$/
      );
    } finally {
      workspaceDb.sqlite.close();
      userDb.sqlite.close();
    }
  });

  it('links access-token owners to canonical users', () => {
    const dataRoot = createDataRoot();
    const coreDb = openCoreDb(dataRoot);

    try {
      applyMigrations(coreDb);

      const foreignKeys = coreDb.sqlite
        .prepare('PRAGMA foreign_key_list(openkit_access_tokens)')
        .all() as Array<{ from: string; on_delete: string; table: string; to: string }>;

      expect(foreignKeys).toContainEqual(
        expect.objectContaining({
          from: 'owner_user_id',
          on_delete: 'CASCADE',
          table: 'users',
          to: 'id',
        })
      );
    } finally {
      coreDb.sqlite.close();
    }
  });

  it.each([
    ['workspace_registry', 'owner_user_id'],
    ['workspace_members', 'user_id'],
  ] as const)('restricts user deletion through %s.%s', (tableName, columnName) => {
    const dataRoot = createDataRoot();
    const coreDb = openCoreDb(dataRoot);

    try {
      applyMigrations(coreDb);

      const foreignKeys = coreDb.sqlite
        .prepare(`PRAGMA foreign_key_list(${tableName})`)
        .all() as Array<{
        from: string;
        on_delete: string;
        table: string;
        to: string;
      }>;

      expect(foreignKeys).toContainEqual(
        expect.objectContaining({
          from: columnName,
          on_delete: 'RESTRICT',
          table: 'users',
          to: 'id',
        })
      );
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('enforces invitation lifecycle, invitee retention, and lookup indexes', () => {
    const dataRoot = createDataRoot();
    const coreDb = openCoreDb(dataRoot);

    try {
      applyMigrations(coreDb);
      const now = Date.now();
      const createdAt = '2026-07-19T00:00:00.000Z';
      coreDb.sqlite
        .prepare(
          `INSERT INTO users (
            id, display_name, email, email_verified, created_at, updated_at, kind
          ) VALUES
            ('usr_00000000-0000-7011-88df-c2b1e8466b6f', 'Owner', 'owner@example.com', false, ?, ?, 'human'),
            ('usr_00000000-0000-7a9e-8345-2bce44a3dce0', 'Invitee', 'invitee@example.com', false, ?, ?, 'human')`
        )
        .run(now, now, now, now);
      recordWorkspaceOwnerMembership({
        coreDb,
        ownerUserId: 'usr_00000000-0000-7011-88df-c2b1e8466b6f',
        workspaceId: 'ws_00000000-0000-7c1f-9bfb-ef82611610b6',
      });
      const insertInvitation = coreDb.sqlite.prepare(
        `INSERT INTO workspace_invitations (
          invitation_id, workspace_id, invitee_user_id, proposed_access_level,
          inviter_user_id, status, expires_at, accepted_at, declined_at, revoked_at,
          revision, created_at, updated_at
        ) VALUES (
          ?, 'ws_00000000-0000-7c1f-9bfb-ef82611610b6', 'usr_00000000-0000-7a9e-8345-2bce44a3dce0', 'editor', 'usr_00000000-0000-7011-88df-c2b1e8466b6f', ?,
          '2026-07-26T00:00:00.000Z', ?, NULL, NULL, 1, ?, ?
        )`
      );

      expect(() =>
        insertInvitation.run(
          'inv_00000000-0000-73d7-b2e3-893276fb5645',
          'accepted',
          null,
          createdAt,
          createdAt
        )
      ).toThrow();

      insertInvitation.run(
        'inv_00000000-0000-7193-8d2d-2af4371e1697',
        'pending',
        null,
        createdAt,
        createdAt
      );

      expect(() =>
        insertInvitation.run(
          'inv_00000000-0000-7ee2-bd01-709c0aef6e0e',
          'pending',
          null,
          createdAt,
          createdAt
        )
      ).toThrow();
      expect(() =>
        coreDb.sqlite
          .prepare('DELETE FROM users WHERE id = ?')
          .run('usr_00000000-0000-7a9e-8345-2bce44a3dce0')
      ).toThrow();
      expect(
        coreDb.sqlite
          .prepare(
            `SELECT name
             FROM sqlite_master
             WHERE type = 'index'
               AND tbl_name = 'workspace_invitations'
               AND sql IS NOT NULL
             ORDER BY name`
          )
          .all()
          .map((row) => (row as { name: string }).name)
      ).toEqual([
        'workspace_invitations_invitee_idx',
        'workspace_invitations_pending_idx',
        'workspace_invitations_workspace_idx',
      ]);
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('does not upgrade a predecessor migration ledger', () => {
    const dataRoot = createDataRoot();
    const coreDb = openCoreDb(dataRoot);

    try {
      coreDb.sqlite.exec(
        'CREATE TABLE schema_migrations (id text PRIMARY KEY NOT NULL, applied_at text NOT NULL)'
      );
      coreDb.sqlite
        .prepare('INSERT INTO schema_migrations (id, applied_at) VALUES (?, ?)')
        .run('core_predecessor_setup', '2026-08-29T00:00:00.000Z');

      expect(() => applyMigrations(coreDb)).toThrow(/schema_migrations.*already exists/);
      expect(listTableNames(coreDb)).toEqual(['schema_migrations']);
      expect(
        coreDb.sqlite.prepare('SELECT id FROM schema_migrations ORDER BY id').pluck().all()
      ).toEqual(['core_predecessor_setup']);
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('keeps schema mutation SQL inside the committed setup or exact cold cutover', () => {
    const sourceRoot = join(process.cwd(), 'src');
    const schemaMutationPattern = new RegExp(
      `\\b(?:${['CREATE', 'ALTER', 'DROP'].join('|')})\\s+TABLE\\b`,
      'i'
    );
    const offenders = listSourceFiles(sourceRoot)
      .filter((path) => !path.endsWith('migrate.test.ts'))
      .filter((path) => !path.endsWith(`generative-kernel${sep}native.ts`))
      .filter((path) => !path.endsWith(`storage${sep}physical-epoch-cutover.ts`))
      .filter((path) => !path.endsWith(`storage${sep}physical-epoch-cutover.test.ts`))
      // Accepted Goal removal uses one one-way cutover and its populated migration fixture.
      .filter((path) => !path.endsWith(`storage${sep}goal-cutover.ts`))
      .filter((path) => !path.endsWith(`storage${sep}goal-cutover-migration.test.ts`))
      // Accepted host retirement follows the same named, populated one-way cutover boundary.
      .filter((path) => !path.endsWith(`storage${sep}host-repository-cutover.ts`))
      .filter((path) => !path.endsWith(`storage${sep}host-repository-cutover.test.ts`))
      .filter((path) => schemaMutationPattern.test(readFileSync(path, 'utf8')))
      .map((path) => relative(process.cwd(), path));

    expect(offenders).toEqual([]);
  });
});

describe('native Drizzle migrate', () => {
  it('carries retained Sandbox, Harness and binding rows through the concurrent-Turn journal', () => {
    const journal = JSON.parse(
      readFileSync(join(process.cwd(), 'drizzle/core/meta/_journal.json'), 'utf8')
    ) as { entries: Array<{ tag: string; when: number }> };
    const setup = journal.entries[0]!;
    const folder = createNativeJournalFolder([
      { ...setup, sql: readFileSync(join(process.cwd(), `drizzle/core/${setup.tag}.sql`), 'utf8') },
    ]);
    const coreDb = openCoreDb(folder);
    const sqlite = coreDb.sqlite;
    sqlite.pragma('foreign_keys = ON');
    try {
      applyNativeScopeMigrations(sqlite, 'core', folder);
      // Seed every required predecessor field without using the new runtime's defaults.
      const insert = (table: string, values: Record<string, string | number>) => {
        const columns = sqlite.pragma(`table_info(${table})`) as Array<{
          name: string;
          type: string;
          notnull: number;
          dflt_value: unknown;
        }>;
        const row = Object.fromEntries(
          columns
            .filter(
              (column) =>
                Object.hasOwn(values, column.name) || (column.notnull && column.dflt_value === null)
            )
            .map((column) => [
              column.name,
              values[column.name] ?? (column.type === 'INTEGER' ? 1 : `${table}:${column.name}`),
            ])
        );
        sqlite
          .prepare(
            `INSERT INTO ${table} (${Object.keys(row).join(',')}) VALUES (${Object.keys(row)
              .map(() => '?')
              .join(',')})`
          )
          .run(...Object.values(row));
      };
      insert('nanohost_runtime_targets', { target_id: 'retained-target' });
      insert('sandbox_runtime_records', {
        sandbox_runtime_id: 'retained-sandbox',
        runtime_target_id: 'retained-target',
        max_open_sessions: 8,
        max_harnesses: 8,
        max_active_turns: 1,
      });
      insert('harness_instance_records', {
        harness_instance_id: 'retained-harness',
        sandbox_runtime_id: 'retained-sandbox',
        max_open_sessions: 8,
        max_active_turns: 1,
        active_turn_count: 1,
        open_session_count: 1,
        next_sequence: 7,
        command_body_json: '{"retained":"command"}',
        result_json: '{"retained":"receipt"}',
      });
      insert('agent_session_runtime_bindings', {
        agent_session_runtime_binding_id: 'retained-binding',
        harness_instance_id: 'retained-harness',
        agent_session_id: testEntityId('as', 'retained-session'),
        workspace_id: testEntityId('ws', 'retained-workspace'),
        thread_id: testEntityId('th', 'retained-thread'),
        current_turn_id: testEntityId('tu', 'retained-turn'),
        current_attempt_id: testEntityId('attempt', 'retained-attempt'),
        native_handle_digest: 'a'.repeat(64),
        next_turn_sequence: 3,
      });
      const names = [
        'sandbox_runtime_records',
        'harness_instance_records',
        'agent_session_runtime_bindings',
      ];
      const before = names.map((name) => sqlite.prepare(`SELECT * FROM ${name}`).all());
      const indices = names.map((name) => sqlite.pragma(`index_list(${name})`));
      const binding = readNanoHostThreadAgentSessionBinding(coreDb, {
        workspaceId: testEntityId('ws', 'retained-workspace'),
        threadId: testEntityId('th', 'retained-thread'),
      });
      expect(binding).toEqual({ agentSessionId: testEntityId('as', 'retained-session') });
      expect(() =>
        sqlite.exec('UPDATE sandbox_runtime_records SET max_active_turns = 8')
      ).toThrow();
      for (const entry of journal.entries.slice(1))
        appendNativeJournalEntry(folder, {
          ...entry,
          sql: readFileSync(join(process.cwd(), `drizzle/core/${entry.tag}.sql`), 'utf8'),
        });
      applyNativeScopeMigrations(sqlite, 'core', folder);
      const after = names.map((name) => sqlite.prepare(`SELECT * FROM ${name}`).all());
      expect(after).toEqual(before);
      expect(sqlite.pragma('foreign_key_check')).toEqual([]);
      expect(sqlite.pragma('foreign_keys', { simple: true })).toBe(1);
      expect(names.map((name) => sqlite.pragma(`index_list(${name})`))).toEqual(indices);
      expect(
        readNanoHostThreadAgentSessionBinding(coreDb, {
          workspaceId: testEntityId('ws', 'retained-workspace'),
          threadId: testEntityId('th', 'retained-thread'),
        })
      ).toEqual(binding);
      applyNativeScopeMigrations(sqlite, 'core', folder);
      expect(names.map((name) => sqlite.prepare(`SELECT * FROM ${name}`).all())).toEqual(after);
      expect(countNativeLedgerRows(sqlite)).toBe(journal.entries.length);
      expect(() =>
        sqlite.exec('UPDATE sandbox_runtime_records SET max_active_turns = 8')
      ).not.toThrow();
      expect(() =>
        sqlite.exec(
          'UPDATE harness_instance_records SET max_active_turns = 8, active_turn_count = 8'
        )
      ).not.toThrow();
      expect(() =>
        sqlite.exec('UPDATE sandbox_runtime_records SET max_active_turns = 0')
      ).toThrow();
      expect(() =>
        sqlite.exec('UPDATE harness_instance_records SET active_turn_count = 9')
      ).toThrow();
    } finally {
      sqlite.close();
    }
  });

  it('applies a second pending SQL file exactly once', () => {
    const folder = createNativeJournalFolder([
      {
        tag: '0000_setup',
        when: 1000,
        sql: 'CREATE TABLE t0 (id text PRIMARY KEY NOT NULL);',
      },
    ]);
    const dbPath = join(folder, 'db.sqlite');
    const first = new Database(dbPath);
    applyNativeScopeMigrations(first, 'core', folder);
    first.prepare('INSERT INTO t0 (id) VALUES (?)').run('retained');
    first.close();

    appendNativeJournalEntry(folder, {
      tag: '0001_pending',
      when: 2000,
      sql: 'CREATE TABLE t1 (id text PRIMARY KEY NOT NULL);',
    });
    const sqlite = new Database(dbPath);

    try {
      applyNativeScopeMigrations(sqlite, 'core', folder);
      applyNativeScopeMigrations(sqlite, 'core', folder);

      expect(listAppliedNativeMigrationIds(sqlite, 'core', folder)).toEqual([
        'core_0000_setup',
        'core_0001_pending',
      ]);
      expect(countNativeLedgerRows(sqlite)).toBe(2);
      expect(listTableNames({ sqlite })).toEqual(['__drizzle_migrations', 't0', 't1']);
      expect(sqlite.prepare('SELECT id FROM t0 ORDER BY id').pluck().all()).toEqual(['retained']);
    } finally {
      sqlite.close();
    }
  });

  it('rolls back an atomic pending batch when a later SQL file fails', () => {
    const folder = createNativeJournalFolder([
      {
        tag: '0000_setup',
        when: 1000,
        sql: 'CREATE TABLE t0 (id text PRIMARY KEY NOT NULL);',
      },
      {
        tag: '0001_pending',
        when: 2000,
        sql: 'CREATE TABLE t1 (id text PRIMARY KEY NOT NULL);\n--> statement-breakpoint\nCREATE TABLE t1 (id text PRIMARY KEY NOT NULL);',
      },
    ]);
    const sqlite = new Database(join(folder, 'db.sqlite'));

    try {
      expect(() => applyNativeScopeMigrations(sqlite, 'core', folder)).toThrow(BootConfigError);
      expect(listAppliedNativeMigrationIds(sqlite, 'core', folder)).toEqual([]);
      expect(countNativeLedgerRows(sqlite)).toBe(0);
      expect(listTableNames({ sqlite })).toEqual(['__drizzle_migrations']);
    } finally {
      sqlite.close();
    }
  });

  it('keeps earlier exact native rows when a later pending SQL file fails', () => {
    const folder = createNativeJournalFolder([
      {
        tag: '0000_setup',
        when: 1000,
        sql: 'CREATE TABLE t0 (id text PRIMARY KEY NOT NULL);',
      },
    ]);
    const sqlite = new Database(join(folder, 'db.sqlite'));

    try {
      applyNativeScopeMigrations(sqlite, 'core', folder);
      appendNativeJournalEntry(folder, {
        tag: '0001_pending',
        when: 2000,
        sql: 'CREATE TABLE t1 (id text PRIMARY KEY NOT NULL);\n--> statement-breakpoint\nCREATE TABLE t1 (id text PRIMARY KEY NOT NULL);',
      });

      expect(() => applyNativeScopeMigrations(sqlite, 'core', folder)).toThrow(BootConfigError);
      expect(listAppliedNativeMigrationIds(sqlite, 'core', folder)).toEqual(['core_0000_setup']);
      expect(countNativeLedgerRows(sqlite)).toBe(1);
      expect(listTableNames({ sqlite })).toEqual(['__drizzle_migrations', 't0']);
    } finally {
      sqlite.close();
    }
  });

  it('applies each scope journal only to that scope database', () => {
    const coreFolder = createNativeJournalFolder([
      {
        tag: '0000_setup',
        when: 1000,
        sql: 'CREATE TABLE core_only (id text PRIMARY KEY NOT NULL);',
      },
    ]);
    const userFolder = createNativeJournalFolder([
      {
        tag: '0000_setup',
        when: 1000,
        sql: 'CREATE TABLE user_only (id text PRIMARY KEY NOT NULL);',
      },
    ]);
    const coreSqlite = new Database(join(coreFolder, 'db.sqlite'));
    const userSqlite = new Database(join(userFolder, 'db.sqlite'));

    try {
      applyNativeScopeMigrations(coreSqlite, 'core', coreFolder);
      applyNativeScopeMigrations(userSqlite, 'user', userFolder);

      expect(listTableNames({ sqlite: coreSqlite })).toEqual(['__drizzle_migrations', 'core_only']);
      expect(listTableNames({ sqlite: userSqlite })).toEqual(['__drizzle_migrations', 'user_only']);
      expect(listAppliedNativeMigrationIds(coreSqlite, 'core', coreFolder)).toEqual([
        'core_0000_setup',
      ]);
      expect(listAppliedNativeMigrationIds(userSqlite, 'user', userFolder)).toEqual([
        'user_0000_setup',
      ]);
    } finally {
      userSqlite.close();
      coreSqlite.close();
    }
  });

  it('fails closed when a journal entry has no SQL file', () => {
    const folder = createNativeJournalFolder([
      {
        tag: '0000_setup',
        when: 1000,
      },
    ]);
    const sqlite = new Database(join(folder, 'db.sqlite'));

    try {
      expect(() => applyNativeScopeMigrations(sqlite, 'core', folder)).toThrow(
        /Missing core native Drizzle SQL/
      );
      expect(listAppliedNativeMigrationIds(sqlite, 'core', folder)).toEqual([]);
    } finally {
      sqlite.close();
    }
  });

  it('fails closed when native journal metadata is corrupt', () => {
    const folder = createNativeJournalFolder([
      {
        tag: '0000_setup',
        when: 1000,
        sql: 'CREATE TABLE t0 (id text PRIMARY KEY NOT NULL);',
      },
    ]);
    writeFileSync(join(folder, 'meta', '_journal.json'), '{"version":"7","dialect":"sqlite"}\n');
    const sqlite = new Database(join(folder, 'db.sqlite'));

    try {
      expect(() => listAppliedNativeMigrationIds(sqlite, 'core', folder)).toThrow(
        /Corrupt native Drizzle journal/
      );
    } finally {
      sqlite.close();
    }
  });

  it('does not infer applied native ids from the maximum ledger timestamp', () => {
    const folder = createNativeJournalFolder([
      {
        tag: '0000_setup',
        when: 1000,
        sql: 'CREATE TABLE t0 (id text PRIMARY KEY NOT NULL);',
      },
    ]);
    const sqlite = new Database(join(folder, 'db.sqlite'));

    try {
      applyNativeScopeMigrations(sqlite, 'core', folder);
      appendNativeJournalEntry(folder, {
        tag: '0001_pending',
        when: 2000,
        sql: 'CREATE TABLE t1 (id text PRIMARY KEY NOT NULL);',
      });
      sqlite
        .prepare('INSERT INTO __drizzle_migrations (hash, created_at) VALUES (?, ?)')
        .run('unmatched-native-row', 999999);

      expect(listAppliedNativeMigrationIds(sqlite, 'core', folder)).toEqual(['core_0000_setup']);
    } finally {
      sqlite.close();
    }
  });
});

/**
 * Creates one native Drizzle journal folder for migrate tests.
 *
 * @param entries Journal entries. Omit `sql` to leave the referenced file missing.
 * @returns Absolute journal folder path.
 */
function createNativeJournalFolder(
  entries: ReadonlyArray<{ readonly tag: string; readonly when: number; readonly sql?: string }>
): string {
  const dir = mkdtempSync(join(tmpdir(), 'openkit-native-migrate-'));
  mkdirSync(join(dir, 'meta'));
  writeNativeJournal(dir, entries);
  for (const entry of entries) {
    if (entry.sql !== undefined) {
      writeFileSync(join(dir, `${entry.tag}.sql`), entry.sql);
    }
  }
  return dir;
}

/**
 * Appends one journal entry and optional SQL file to an existing native folder.
 *
 * @param folder Native journal folder.
 * @param entry Journal entry to append.
 */
function appendNativeJournalEntry(
  folder: string,
  entry: { readonly tag: string; readonly when: number; readonly sql?: string }
): void {
  const journalPath = join(folder, 'meta', '_journal.json');
  const journal = JSON.parse(readFileSync(journalPath, 'utf8')) as {
    entries: Array<{ idx: number; tag: string; when: number }>;
  };
  writeNativeJournal(folder, [
    ...journal.entries.map((existing) => ({ tag: existing.tag, when: existing.when })),
    entry,
  ]);
  if (entry.sql !== undefined) {
    writeFileSync(join(folder, `${entry.tag}.sql`), entry.sql);
  }
}

/**
 * Writes `_journal.json` for the supplied entries.
 *
 * @param folder Native journal folder.
 * @param entries Journal entries.
 */
function writeNativeJournal(
  folder: string,
  entries: ReadonlyArray<{ readonly tag: string; readonly when: number }>
): void {
  writeFileSync(
    join(folder, 'meta', '_journal.json'),
    `${JSON.stringify({
      dialect: 'sqlite',
      entries: entries.map((entry, idx) => ({
        breakpoints: true,
        idx,
        tag: entry.tag,
        version: '6',
        when: entry.when,
      })),
      version: '7',
    })}\n`
  );
}

/**
 * Counts native Drizzle ledger rows.
 *
 * @param sqlite Open SQLite connection.
 * @returns Ledger row count, or 0 when the table is absent.
 */
function countNativeLedgerRows(sqlite: Database.Database): number {
  const table = sqlite
    .prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = ?")
    .get('__drizzle_migrations');
  if (!table) {
    return 0;
  }
  return Number(sqlite.prepare('SELECT COUNT(*) FROM __drizzle_migrations').pluck().get());
}
