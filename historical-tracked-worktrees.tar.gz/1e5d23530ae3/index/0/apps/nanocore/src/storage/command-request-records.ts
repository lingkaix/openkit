import { existsSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import {
  ArtifactIdSchema,
  ArtifactReviewIdSchema,
  InvitationIdSchema,
  KnowledgeClaimIdSchema,
  KnowledgeConflictIdSchema,
  KnowledgeObservationIdSchema,
  KnowledgeReviewIdSchema,
  KnowledgeSourceIdSchema,
  MaterialIdSchema,
  MaterialRevisionIdSchema,
  PresentationIdSchema,
  ThreadIdSchema,
  TurnIdSchema,
  UserIdSchema,
  WorkerStorageTargetIdSchema,
  WorkspaceIdSchema,
} from '@openkit/protocol';
import Database from 'better-sqlite3';
import { z } from 'zod';
import { KernelCommandError } from '../generative-kernel/errors.js';
import type {
  CommandRequestName,
  CommandRequestRecord,
  CommandRequestResponse,
  CommandRequestResponseKind,
  CommandRequestScope,
  ConversationCommandReceiptMetadata,
} from '../lib/store.js';
import type { AppDb } from './app-db.js';
import { lightAppDbPath, openExistingAppDb } from './app-db.js';
import {
  type CoreDb,
  openCoreDb,
  openUserDb,
  openWorkspaceDb,
  type UserDb,
  type WorkspaceDb,
} from './db.js';
import { coreDbPath, resolveDataRootPath, userDbPath, workspaceDbPath } from './fs-layout.js';
import { applyMigrations, applyScopedMigrations } from './migrate.js';

/** Raw SQLite row for one command idempotency request. */
type CommandRequestRow = {
  readonly key: string;
  readonly command: CommandRequestName;
  readonly requestId: string;
  readonly scopeJson: string;
  readonly inputHash: string;
  readonly responseKind: CommandRequestResponseKind;
  readonly responseId: string;
  readonly responseJson: string | null;
  readonly createdAt: string;
  readonly expiresAt: string;
};

/** Scoped database that can own command idempotency requests. */
type CommandRequestDb = CoreDb | UserDb | WorkspaceDb | AppDb;

/** Exact physical owner selected by one command request scope. */
type CommandRequestOwner =
  | { readonly scope: 'core' }
  | { readonly scope: 'user'; readonly userId: string }
  | { readonly scope: 'workspace'; readonly workspaceId: string }
  | { readonly scope: 'app'; readonly workspaceId: string; readonly appId: string };

/** Closed schema for the sole extra metadata allowed on a command receipt. */
const ConversationCommandReceiptMetadataSchema = z
  .object({
    targetRef: z.string().min(1),
    logicalModelId: z.string().min(1).nullable(),
    receivingWorkspaceId: WorkspaceIdSchema,
    receivingThreadId: ThreadIdSchema,
    downstream: z
      .discriminatedUnion('kind', [
        z.object({ kind: z.literal('task'), turnId: TurnIdSchema }).strict(),
        z
          .object({
            kind: z.literal('goal'),
            goalId: z.string().min(1),
            turnId: TurnIdSchema,
          })
          .strict(),
      ])
      .nullable(),
    resultKind: z.enum([
      'knowledge-answer',
      'provider-answer',
      'clarification',
      'task-handoff',
      'goal-handoff',
      'worker-turn',
      'goal-intent',
      'goal-steering',
      'refused',
    ]),
    status: z.union([z.literal(200), z.literal(202)]),
  })
  .strict();

/** Retained descriptive metadata is normalized without relaxing current receipt emission. */
const ConversationCommandReceiptMetadataReaderSchema =
  ConversationCommandReceiptMetadataSchema.extend({
    downstream: z
      .discriminatedUnion('kind', [
        ConversationCommandReceiptMetadataSchema.shape.downstream.unwrap().options[0].strip(),
        ConversationCommandReceiptMetadataSchema.shape.downstream.unwrap().options[1].strip(),
      ])
      .nullable(),
  }).strip();

/** The response discriminator selects its declared entity owner; other owners keep opaque keys. */
const COMMAND_RESPONSE_ID_SCHEMAS: Record<CommandRequestResponseKind, z.ZodType<string> | null> = {
  workspace: WorkspaceIdSchema,
  workspace_invitation: InvitationIdSchema,
  workspace_member: null,
  workspace_recovery: WorkspaceIdSchema,
  workspace_deletion: null,
  user: UserIdSchema,
  knowledge: null,
  knowledge_source: KnowledgeSourceIdSchema,
  knowledge_observation: KnowledgeObservationIdSchema,
  knowledge_claim: KnowledgeClaimIdSchema,
  knowledge_conflict: KnowledgeConflictIdSchema,
  thread: ThreadIdSchema,
  turn: TurnIdSchema,
  approval: null,
  pending_request: null,
  git_push_record: null,
  artifact: ArtifactIdSchema,
  artifact_review: ArtifactReviewIdSchema,
  workspace_sync_review: null,
  knowledge_proposal: null,
  knowledge_proposal_review: KnowledgeReviewIdSchema,
  goal: null,
  goal_plan: null,
  goal_review: null,
  pending_user_turn: null,
  steering_terminal_outcome: null,
  material: MaterialIdSchema,
  material_revision: MaterialRevisionIdSchema,
  thread_material_binding: MaterialIdSchema,
  light_app: null,
  light_app_record: null,
  light_app_batch: null,
  generative_presentation: PresentationIdSchema,
  worker_environment: WorkerStorageTargetIdSchema,
};

const COMMAND_REQUEST_SELECT = `SELECT
  request_key AS key,
  command_name AS command,
  request_id AS requestId,
  scope_json AS scopeJson,
  input_hash AS inputHash,
  response_kind AS responseKind,
  response_id AS responseId,
  response_json AS responseJson,
  created_at AS createdAt,
  expires_at AS expiresAt
FROM idempotency_requests`;

/**
 * Validates kind-named response pointers, rejects unsupported fields and validates bounded Chat metadata.
 *
 * @param command Command that owns the receipt.
 * @param response Candidate response pointer.
 * @returns Exact normalized response pointer safe for memory and SQLite persistence.
 * @throws Error when fields or Chat metadata exceed the accepted receipt contract.
 */
export function normalizeCommandRequestResponse(
  command: CommandRequestName,
  response: CommandRequestResponse
): CommandRequestResponse {
  if (Object.keys(response).some((key) => !['kind', 'id', 'conversationMetadata'].includes(key))) {
    throw new Error('Command receipt response contains unsupported fields.');
  }
  if (!Object.hasOwn(COMMAND_RESPONSE_ID_SCHEMAS, response.kind)) {
    throw new Error('Command receipt response kind is unsupported.');
  }
  COMMAND_RESPONSE_ID_SCHEMAS[response.kind]?.parse(response.id);
  if (response.conversationMetadata === undefined) {
    return { kind: response.kind, id: response.id };
  }
  if (command !== 'conversation.submit') {
    throw new Error('Only conversation.submit may store extra command receipt metadata.');
  }
  const parsed = ConversationCommandReceiptMetadataSchema.safeParse(response.conversationMetadata);
  if (!parsed.success) {
    throw new Error('conversation.submit command receipt metadata is invalid.');
  }
  return { kind: response.kind, id: response.id, conversationMetadata: parsed.data };
}

/**
 * Stores one command idempotency request in its owning scoped database.
 *
 * @param dataRoot Data root that owns the databases.
 * @param record Command request record to store.
 * @throws Error when the scope has no exact Core, User, or Workspace owner.
 */
export function recordCommandRequestRecord(dataRoot: string, record: CommandRequestRecord): void {
  const owner = commandRequestOwner(record.scope);
  const response = normalizeCommandRequestResponse(record.command, record.response);

  if (owner.scope === 'workspace' && !workspaceRecordExists(dataRoot, owner.workspaceId)) {
    throw new Error(`Workspace not found: ${owner.workspaceId}`);
  }
  if (owner.scope === 'app' && !workspaceRecordExists(dataRoot, owner.workspaceId)) {
    throw new Error(`Workspace not found: ${owner.workspaceId}`);
  }

  const db = openCommandRequestDb(dataRoot, owner);

  try {
    recordCommandRequestRecordInDb(db, { ...record, response });
  } finally {
    db.sqlite.close();
  }
}

/**
 * Stores one command request through an already open scoped database.
 *
 * @param db Open database that owns the request scope.
 * @param record Complete command request record.
 */
export function recordCommandRequestRecordInDb(
  db: CommandRequestDb,
  record: CommandRequestRecord
): void {
  assertCommandRequestDbOwner(db, record.scope);
  const response = normalizeCommandRequestResponse(record.command, record.response);
  const previous = db.sqlite
    .prepare(`${COMMAND_REQUEST_SELECT} WHERE request_key = ?`)
    .get(record.key) as CommandRequestRow | undefined;
  let responseJson =
    response.conversationMetadata === undefined
      ? null
      : JSON.stringify(response.conversationMetadata);
  if (
    previous?.responseJson &&
    previous.command === record.command &&
    previous.inputHash === record.inputHash &&
    previous.scopeJson === JSON.stringify(record.scope) &&
    previous.responseKind === response.kind &&
    previous.responseId === response.id
  ) {
    const retained = mapCommandRequestRow(previous);
    if (JSON.stringify(retained.response) === JSON.stringify(response))
      responseJson = previous.responseJson;
  }
  db.sqlite
    .prepare(
      `INSERT OR REPLACE INTO idempotency_requests (
        request_key,
        command_name,
        request_id,
        scope_json,
        input_hash,
        response_kind,
        response_id,
        response_json,
        created_at,
        expires_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      record.key,
      record.command,
      record.requestId,
      JSON.stringify(record.scope),
      record.inputHash,
      response.kind,
      response.id,
      responseJson,
      record.createdAt,
      record.expiresAt
    );
  pruneCommandRequestRecords(db, new Date().toISOString());
}

/**
 * Gets one active command idempotency request from its owning scoped database.
 *
 * @param dataRoot Data root that owns the databases.
 * @param scope Exact Core, User, or Workspace request owner.
 * @param key Stable command request key.
 * @param referenceTime Current ISO timestamp used for expiry.
 * @returns Stored active request, or null.
 * @throws Error when the scope has no exact Core, User, or Workspace owner.
 */
export function getCommandRequestRecord(
  dataRoot: string,
  scope: CommandRequestScope,
  key: string,
  referenceTime: string
): CommandRequestRecord | null {
  const owner = commandRequestOwner(scope);

  if (owner.scope === 'workspace' && !workspaceRecordExists(dataRoot, owner.workspaceId)) {
    return null;
  }
  if (owner.scope === 'app' && !workspaceRecordExists(dataRoot, owner.workspaceId)) {
    return null;
  }

  const path =
    owner.scope === 'core'
      ? coreDbPath(dataRoot)
      : owner.scope === 'user'
        ? userDbPath(dataRoot, owner.userId)
        : owner.scope === 'app'
          ? lightAppDbPath(dataRoot, owner.workspaceId, owner.appId)
          : workspaceDbPath(dataRoot, owner.workspaceId);

  if (!existsSync(path)) {
    return null;
  }

  const db = openCommandRequestDb(dataRoot, owner);

  try {
    return getCommandRequestRecordFromDb(db, key, referenceTime);
  } finally {
    db.sqlite.close();
  }
}

/**
 * Returns whether one Workspace has the current canonical record and rejects the retired name.
 *
 * @param dataRoot Data root that owns the Workspace.
 * @param workspaceId Workspace identity to inspect.
 * @returns Whether the current canonical record exists.
 */
function workspaceRecordExists(dataRoot: string, workspaceId: string): boolean {
  const workspaceRoot = resolveDataRootPath(dataRoot, 'workspaces', workspaceId);
  const retiredPath = join(workspaceRoot, 'workspace.json');
  if (existsSync(retiredPath)) {
    throw new Error(`Unsupported canonical workspace file workspace.json: ${workspaceId}.`);
  }
  return existsSync(join(workspaceRoot, 'workspace-record.json'));
}

/**
 * Reads one active command request through an already open scoped database.
 *
 * @param db Open database that owns the request scope.
 * @param key Stable command request key.
 * @param referenceTime Current ISO timestamp used for expiry.
 * @returns Stored active request, or null.
 */
export function getCommandRequestRecordFromDb(
  db: CommandRequestDb,
  key: string,
  referenceTime: string
): CommandRequestRecord | null {
  pruneCommandRequestRecords(db, referenceTime);
  const row = db.sqlite.prepare(`${COMMAND_REQUEST_SELECT} WHERE request_key = ?`).get(key) as
    | CommandRequestRow
    | undefined;

  if (!row) {
    return null;
  }

  const record = mapCommandRequestRow(row);
  assertCommandRequestDbOwner(db, record.scope);
  if (db.scope === 'app' && record.expiresAt <= referenceTime) {
    throw new KernelCommandError(
      'recovery_required',
      'The original request requires recovery and cannot be replayed.'
    );
  }
  return record;
}

/** Reads retained receipts on the caller's scoped connection without migration, pruning, or another write connection. */
export function readCommandRequestRecordsFromSqlite(
  sqlite: Database.Database
): CommandRequestRecord[] {
  return (sqlite.prepare(COMMAND_REQUEST_SELECT).all() as CommandRequestRow[]).map(
    mapCommandRequestRow
  );
}

/** Read-only inventory of command receipts, including expired rows. */
export type DurableCommandRequestRead =
  | { readonly records: readonly CommandRequestRecord[]; readonly status: 'readable' }
  | { readonly status: 'unreadable' };

/**
 * Reads every existing command receipt without pruning, migrating, or creating a database.
 *
 * Expired rows remain visible so cleanup cannot treat a pruned receipt as absent provenance.
 *
 * @param dataRoot Data root whose existing Core, User, and Workspace databases should be read.
 * @returns Receipt rows, or `unreadable` when a database or row cannot be read.
 */
export function readDurableCommandRequestRecords(dataRoot: string): DurableCommandRequestRead {
  try {
    const records: CommandRequestRecord[] = [];
    for (const path of existingCommandRequestDatabasePaths(dataRoot)) {
      const sqlite = new Database(path, { fileMustExist: true, readonly: true });
      try {
        const table = sqlite
          .prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = ?")
          .get('idempotency_requests') as { name: string } | undefined;
        if (!table) {
          return { status: 'unreadable' };
        }
        const rows = sqlite
          .prepare(`${COMMAND_REQUEST_SELECT} ORDER BY created_at ASC, request_key ASC`)
          .all() as CommandRequestRow[];
        for (const row of rows) {
          records.push(mapCommandRequestRow(row));
        }
      } finally {
        sqlite.close();
      }
    }
    records.sort(
      (left, right) =>
        left.createdAt.localeCompare(right.createdAt) || left.key.localeCompare(right.key)
    );
    return { records, status: 'readable' };
  } catch {
    return { status: 'unreadable' };
  }
}

/**
 * Lists database files that already exist for command receipts.
 *
 * @param dataRoot Data root to inspect.
 * @returns Existing Core, User, and Workspace database paths.
 * @throws Error when a scanned directory contains a symbolic link.
 */
function existingCommandRequestDatabasePaths(dataRoot: string): string[] {
  const paths: string[] = [];
  const corePath = coreDbPath(dataRoot);
  if (existsSync(corePath)) {
    paths.push(corePath);
  }
  const usersRoot = resolveDataRootPath(dataRoot, 'users');
  if (existsSync(usersRoot)) {
    for (const entry of readdirSync(usersRoot, { withFileTypes: true }).sort((left, right) =>
      left.name.localeCompare(right.name)
    )) {
      if (entry.isSymbolicLink()) {
        throw new Error('Command receipt user directory is symbolic.');
      }
      if (!entry.isDirectory()) continue;
      const path = userDbPath(dataRoot, entry.name);
      if (existsSync(path)) paths.push(path);
    }
  }
  const workspacesRoot = resolveDataRootPath(dataRoot, 'workspaces');
  if (existsSync(workspacesRoot)) {
    for (const entry of readdirSync(workspacesRoot, { withFileTypes: true }).sort((left, right) =>
      left.name.localeCompare(right.name)
    )) {
      if (entry.isSymbolicLink()) {
        throw new Error('Command receipt workspace directory is symbolic.');
      }
      if (!entry.isDirectory() || entry.name === '.staging') continue;
      const path = workspaceDbPath(dataRoot, entry.name);
      if (existsSync(path)) paths.push(path);
    }
  }
  return paths;
}

/**
 * Lists active User- and Workspace-owned command requests in deterministic order.
 *
 * @param dataRoot Data root that owns the databases.
 * @param referenceTime Current ISO timestamp used for expiry.
 * @returns Active command request records.
 */
export function listCommandRequestRecords(
  dataRoot: string,
  referenceTime: string
): CommandRequestRecord[] {
  const owners: CommandRequestOwner[] = [];
  const usersRoot = resolveDataRootPath(dataRoot, 'users');
  const workspacesRoot = resolveDataRootPath(dataRoot, 'workspaces');

  if (existsSync(usersRoot)) {
    for (const entry of readdirSync(usersRoot, { withFileTypes: true }).sort((left, right) =>
      left.name.localeCompare(right.name)
    )) {
      if (entry.isDirectory() && existsSync(userDbPath(dataRoot, entry.name))) {
        owners.push({ scope: 'user', userId: entry.name });
      }
    }
  }

  if (existsSync(workspacesRoot)) {
    for (const entry of readdirSync(workspacesRoot, { withFileTypes: true }).sort((left, right) =>
      left.name.localeCompare(right.name)
    )) {
      if (
        entry.isDirectory() &&
        entry.name !== '.staging' &&
        existsSync(workspaceDbPath(dataRoot, entry.name))
      ) {
        owners.push({ scope: 'workspace', workspaceId: entry.name });
      }
    }
  }

  const records = owners.flatMap((owner) => {
    const db = openCommandRequestDb(dataRoot, owner);

    try {
      pruneCommandRequestRecords(db, referenceTime);
      return (
        db.sqlite
          .prepare(`${COMMAND_REQUEST_SELECT} ORDER BY created_at ASC, request_key ASC`)
          .all() as CommandRequestRow[]
      ).map((row) => {
        const record = mapCommandRequestRow(row);
        assertCommandRequestDbOwner(db, record.scope);
        return record;
      });
    } finally {
      db.sqlite.close();
    }
  });

  return records.sort(
    (left, right) =>
      left.createdAt.localeCompare(right.createdAt) || left.key.localeCompare(right.key)
  );
}

/**
 * Opens and migrates the database that owns one command request scope.
 *
 * @param dataRoot Data root that owns the database.
 * @param owner Exact Core, User, or Workspace database owner.
 * @returns Open migrated scoped database.
 */
function openCommandRequestDb(dataRoot: string, owner: CommandRequestOwner): CommandRequestDb {
  if (owner.scope === 'app') {
    return openExistingAppDb(dataRoot, owner.workspaceId, owner.appId);
  }
  const db =
    owner.scope === 'core'
      ? openCoreDb(dataRoot)
      : owner.scope === 'user'
        ? openUserDb(dataRoot, owner.userId)
        : openWorkspaceDb(dataRoot, owner.workspaceId);

  if (db.scope === 'core') {
    applyMigrations(db);
  } else {
    applyScopedMigrations(db);
  }
  return db;
}

/**
 * Selects one exact durable owner from a command request scope.
 *
 * @param scope Non-secret command scope identifiers.
 * @returns Exact Core, User, or Workspace database owner.
 * @throws Error when the scope names zero or multiple owners.
 */
function commandRequestOwner(scope: CommandRequestScope): CommandRequestOwner {
  const coreId = scope.coreId;
  const userId = scope.userId;
  const workspaceId = scope.workspaceId;
  const appId = scope.appId;

  if (
    coreId === 'server' &&
    userId === undefined &&
    workspaceId === undefined &&
    appId === undefined
  ) {
    return { scope: 'core' };
  }
  if (coreId === undefined && userId && workspaceId === undefined && appId === undefined) {
    return { scope: 'user', userId };
  }
  if (coreId === undefined && workspaceId && userId === undefined && appId) {
    return { scope: 'app', workspaceId, appId };
  }
  if (coreId === undefined && workspaceId && userId === undefined && appId === undefined) {
    return { scope: 'workspace', workspaceId };
  }

  throw new Error(
    'Command request scope must name exactly one Core, User, Workspace, or App owner.'
  );
}

/**
 * Verifies that one open database matches a command request's authoritative scope.
 *
 * @param db Open Core, User, or Workspace database.
 * @param scope Command request scope stored in or destined for that database.
 * @throws Error when the request scope selects a different durable owner.
 */
function assertCommandRequestDbOwner(db: CommandRequestDb, scope: CommandRequestScope): void {
  const owner = commandRequestOwner(scope);

  if (db.scope === 'core' && owner.scope === 'core') {
    return;
  }
  if (db.scope === 'user' && owner.scope === 'user' && owner.userId === db.userId) {
    return;
  }
  if (
    db.scope === 'workspace' &&
    owner.scope === 'workspace' &&
    owner.workspaceId === db.workspaceId
  ) {
    return;
  }
  if (
    db.scope === 'app' &&
    owner.scope === 'app' &&
    owner.workspaceId === db.workspaceId &&
    owner.appId === db.appId
  ) {
    return;
  }

  throw new Error('Command request scope does not match its owning database.');
}

/**
 * Removes expired command requests from one open database.
 *
 * @param db Scoped database to prune.
 * @param referenceTime Current ISO timestamp used for expiry.
 */
function pruneCommandRequestRecords(db: CommandRequestDb, referenceTime: string): void {
  if (db.scope === 'app') {
    return;
  }
  if (db.scope === 'core' || db.scope === 'user') {
    db.sqlite.prepare('DELETE FROM idempotency_requests WHERE expires_at <= ?').run(referenceTime);
    return;
  }

  db.sqlite.prepare('DELETE FROM idempotency_requests WHERE expires_at <= ?').run(referenceTime);
}

/**
 * Maps one raw SQLite row to the public command request record.
 *
 * @param row Raw SQLite row.
 * @returns Command request record.
 */
function mapCommandRequestRow(row: CommandRequestRow): CommandRequestRecord {
  return {
    key: row.key,
    command: row.command,
    requestId: row.requestId,
    scope: JSON.parse(row.scopeJson) as CommandRequestScope,
    inputHash: row.inputHash,
    response: normalizeCommandRequestResponse(row.command, {
      kind: row.responseKind,
      id: row.responseId,
      ...(row.responseJson === null
        ? {}
        : { conversationMetadata: readConversationMetadata(row.responseJson) }),
    }),
    createdAt: row.createdAt,
    expiresAt: row.expiresAt,
  };
}

/** Reads only the retained metadata core before exact response-pointer validation. */
function readConversationMetadata(json: string): ConversationCommandReceiptMetadata {
  const result = ConversationCommandReceiptMetadataReaderSchema.safeParse(JSON.parse(json));
  if (!result.success) throw new Error('conversation.submit command receipt metadata is invalid.');
  return result.data;
}
