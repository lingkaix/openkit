import { createHash, randomUUID } from 'node:crypto';
import {
  closeSync,
  constants,
  existsSync,
  fchmodSync,
  fstatSync,
  fsyncSync,
  lstatSync,
  mkdirSync,
  openSync,
  readdirSync,
  readFileSync,
  readSync,
  renameSync,
  rmSync,
  writeFileSync,
  writeSync,
} from 'node:fs';
import * as fsPromises from 'node:fs/promises';
import { basename, dirname, isAbsolute, join, relative, resolve, sep } from 'node:path';
import { isDeepStrictEqual } from 'node:util';
import {
  KnowledgeManagerDraftedProposalSchema,
  KnowledgeProposalPageIdSchema,
  KnowledgeProposalReviewSchema,
  KnowledgeSourceSchema,
  MaterializedWorkspaceRootSchema,
} from '@openkit/app-api-schemas';
import { parseRecordEnvelope, WorkspaceConfigSchema } from '@openkit/config-schema';
import {
  ActorRefSchema,
  AgentSandboxSummarySchema,
  AgentSessionSchema,
  ApprovalDecisionItemSchema,
  ArtifactFileContentSchema,
  ArtifactInlineContentSchema,
  ArtifactOriginSchema,
  ArtifactSchema,
  deriveEntityId,
  entityIdPattern,
  GitFailureExplanationReaderSchema,
  ItemSchema,
  isEntityId,
  KnowledgeEntrySchema,
  SseEventEnvelopeSchema,
  ThreadSchema,
  TurnSchema,
  UserActorRefSchema,
  UserInputResponseItemSchema,
  UserMessageItemSchema,
  WorkerStorageTargetIdSchema,
  WorkspaceIdSchema,
  WorkspaceRecordSchema,
} from '@openkit/protocol';
import {
  type CaptureCoverageBinding,
  CaptureCoverageBindingSchema,
} from '@openkit/worker-protocol';
import Database from 'better-sqlite3';
import { applyEdits, modify } from 'jsonc-parser';
import { z } from 'zod';
import { parseJsoncObject } from '../config/jsonc.js';
import {
  DEFAULT_WORKSPACE_KNOWLEDGE_SCHEMA_TEXT,
  DEFAULT_WORKSPACE_KNOWLEDGE_SCHEMA_VERSION,
  parseOkfDocument,
  stringFrontmatterField,
  stringListFrontmatterField,
  updateOkfFrontmatter,
} from '../knowledge/okf.js';
import type {
  AgentSession,
  KnowledgeProposalRecord,
  KnowledgeProposalReviewRecord,
  KnowledgeSourceRecord,
} from '../lib/store.js';
import { artifactFilePayloadPath, verifyArtifactFilePayload } from './artifacts/file-records.js';
import { reserveCanonicalFileWrite } from './canonical-write-capacity.js';
import {
  coreDbPath,
  ensureLayoutDirectories,
  ensureWorkspaceLayoutRoot,
} from './fs-layout.js';

type WorkspaceRecord = import('zod').infer<typeof WorkspaceRecordSchema>;
type KnowledgeEntry = import('zod').infer<typeof KnowledgeEntrySchema>;
type Thread = import('zod').infer<typeof ThreadSchema>;
type Turn = import('zod').infer<typeof TurnSchema>;
type Item = import('zod').infer<typeof ItemSchema>;
type Artifact = import('zod').infer<typeof ArtifactSchema>;
type SseEventEnvelope = import('zod').infer<typeof SseEventEnvelopeSchema>;

/** Admission-time resolved capture pair stored on turn.json. */
export type { CaptureCoverageBinding };
/** Admission-time resolved capture pair stored on turn.json. */
export { CaptureCoverageBindingSchema };

const THREAD_ENTRY_REQUIRED_FEATURE = 'openkit.thread-entry.v1' as const;
const THREAD_VISIBILITY_REQUIRED_FEATURE = 'openkit.thread-visibility.v1' as const;
const THREAD_REQUIRED_FEATURES = [
  THREAD_ENTRY_REQUIRED_FEATURE,
  THREAD_VISIBILITY_REQUIRED_FEATURE,
];

const CanonicalTimestampSchema = z.string().datetime();
const retainedProposal = Symbol('retainedKnowledgeProposal');
/** Retained attribution is descriptive; all actor branches and accountability fields remain closed. */
export const ActorRefReaderSchema = z.union(ActorRefSchema.options.map((schema) => schema.strip()));
/** Canonical Item reader keeps the fixed approval actor and its grant refinement. */
const retainedItemSchemas = ItemSchema.options.map((schema) => {
  if (schema === UserMessageItemSchema)
    return UserMessageItemSchema.extend({ actor: ActorRefReaderSchema });
  if (schema === UserInputResponseItemSchema)
    return UserInputResponseItemSchema.extend({ actor: UserActorRefSchema.strip() });
  if (schema === ApprovalDecisionItemSchema)
    return ApprovalDecisionItemSchema.safeExtend({
      actor: z.union([
        ApprovalDecisionItemSchema.shape.actor.options[0].strip(),
        ApprovalDecisionItemSchema.shape.actor.options[1].strip(),
      ]),
    });
  return schema;
});
/** The producer's nonempty branch set keeps discriminator dispatch at the retained boundary. */
const ItemReaderSchema = z.discriminatedUnion('type', [
  retainedItemSchemas[0]!,
  ...retainedItemSchemas.slice(1),
]);
/** Retained Turn reader normalizes attribution and Items before relationship validation. */
export const TurnReaderSchema = TurnSchema.safeExtend({
  triggerActor: ActorRefReaderSchema,
  items: z.array(ItemReaderSchema),
  error: TurnSchema.shape.error
    .unwrap()
    .extend({ explanation: GitFailureExplanationReaderSchema.optional() })
    .nullable(),
});
/** Imported-origin attribution is a historical fact, never current import authority. */
const ArtifactReaderSchema = ArtifactSchema.safeExtend({
  origin: z.discriminatedUnion('kind', [
    ArtifactOriginSchema.options[0],
    ArtifactOriginSchema.options[1].extend({ actor: ActorRefReaderSchema }).strip(),
  ]),
});
/** Retained event snapshots use the same historical readers before exact envelope validation. */
const SseEventReaderSchema = z.preprocess((value) => {
  if (typeof value !== 'object' || value === null || !('data' in value)) return value;
  const data = value.data;
  if (typeof data !== 'object' || data === null) return value;
  const normalized = { ...data } as Record<string, unknown>;
  switch (normalized.type) {
    case 'workspace-updated':
      normalized.workspace = WorkspaceRecordSchema.strip().parse(normalized.workspace);
      break;
    case 'turn-updated':
    case 'turn-completed':
      normalized.turn = TurnReaderSchema.parse(normalized.turn);
      break;
    case 'item-created':
    case 'item-completed':
      normalized.item = ItemReaderSchema.parse(normalized.item);
      break;
    case 'artifact-created':
    case 'artifact-updated':
      normalized.artifact = ArtifactReaderSchema.parse(normalized.artifact);
      break;
  }
  return { ...value, data: normalized };
}, SseEventEnvelopeSchema);
export const WorkspaceSystemRecordSchema = WorkspaceRecordSchema.omit({
  name: true,
  counts: true,
}).strip();
export const KnowledgeProposalRecordSchema = KnowledgeManagerDraftedProposalSchema.omit({
  status: true,
})
  .extend({
    id: z.string().regex(/^kp_[a-f0-9]{64}$/),
    producer: ActorRefReaderSchema,
  })
  .strip();
export const KnowledgeProposalReviewRecordSchema = KnowledgeProposalReviewSchema.extend({
  reviewId: z.string().regex(entityIdPattern('kr')),
  actor: ActorRefReaderSchema,
})
  .strip()
  .superRefine((review, context) => {
    const accepted = review.decision === 'accepted';
    if (accepted !== (review.targetAbsentAtDecision === true)) {
      context.addIssue({
        code: 'custom',
        message: 'Only an accepted review may record target absence.',
        path: ['targetAbsentAtDecision'],
      });
    }
  });
/** Retained Review reader validates ordered decision core and identities without descriptive annotations. */
export const KnowledgeProposalReviewFileSchema = z
  .object({
    proposalId: z.string().regex(/^kp_[a-f0-9]{64}$/),
    workspaceId: WorkspaceIdSchema,
    decisions: z.array(KnowledgeProposalReviewRecordSchema).min(1),
  })
  .strip()
  .superRefine((file, context) => {
    const requestIds = new Set<string>();
    const reviewIds = new Set<string>();
    let terminal = false;

    for (const [index, review] of file.decisions.entries()) {
      const expectedReviewId = deriveEntityId('kr', {
        ownerScope: { kind: 'workspace', workspaceId: file.workspaceId },
        proposalId: file.proposalId,
        requestId: review.requestId,
      });
      if (
        review.proposalId !== file.proposalId ||
        review.workspaceId !== file.workspaceId ||
        review.reviewId !== expectedReviewId ||
        requestIds.has(review.requestId) ||
        reviewIds.has(review.reviewId) ||
        terminal
      ) {
        context.addIssue({
          code: 'custom',
          message: 'Knowledge Proposal review history is not append-only canonical history.',
          path: ['decisions', index],
        });
      }
      requestIds.add(review.requestId);
      reviewIds.add(review.reviewId);
      terminal ||= review.decision === 'accepted' || review.decision === 'rejected';
    }
  });
export const KnowledgeSourceRecordSchema = KnowledgeSourceSchema.extend({
  capturedAt: CanonicalTimestampSchema,
  createdAt: CanonicalTimestampSchema,
  updatedAt: CanonicalTimestampSchema,
}).strip();
/** Private historical attachment provenance; current admission remains with WorkerStorageBinding. */
export const AgentSessionRetainedStorageSchema = z
  .object({
    storageRef: WorkerStorageTargetIdSchema,
    workSlotRef: z.string().regex(/^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/),
  })
  .strip();

/** Canonical AgentSession record schema shared with workspace portability. */
export const AgentSessionRecordSchema = AgentSessionSchema.extend({
  sandboxSummary: AgentSandboxSummarySchema.extend({
    workspaceRootRefs: z.array(z.string().min(1)),
  })
    .strip()
    .nullable(),
  createdAt: CanonicalTimestampSchema,
  updatedAt: CanonicalTimestampSchema,
  configVersion: z.number().int().positive().nullable(),
  environmentPackageSnapshotId: z.string().min(1).nullable(),
  /** Actual admitted attachment, persisted before native open and immutable for this AgentSession. */
  retainedStorage: AgentSessionRetainedStorageSchema.nullable().default(null),
  /**
   * Resume digest: the native handle digest of the ready proof NanoCore accepted for this
   * AgentSession's binding. With the record's own id as locator it forms the resume pair a
   * successor presents; null means no accepted ready proof. The field is an additive extension,
   * so a record written before it existed reads as having no proof.
   */
  nativeHandleDigest: z
    .string()
    .regex(/^[0-9a-f]{64}$/)
    .nullable()
    .default(null),
  policySnapshotId: z.string().min(1).nullable(),
  sessionCompatibilityKey: z.string().min(1).nullable(),
  stale: z.boolean(),
  workspaceRoots: z.array(
    z.union(MaterializedWorkspaceRootSchema.options.map((schema) => schema.strip()))
  ),
}).strip();

const TERMINAL_AGENT_SESSION_STATUSES = new Set<AgentSession['status']>([
  'interrupted',
  'failed',
  'closed',
]);

/** Returns whether one AgentSession status remains current for its Thread. */
export function isCurrentAgentSessionStatus(status: AgentSession['status']): boolean {
  return !TERMINAL_AGENT_SESSION_STATUSES.has(status);
}

/** Maximum canonical replay window retained in memory after reload. */
export const TURN_STREAM_EVENT_WINDOW_SIZE = 100;

/**
 * Derives the stable Item identity for one Artifact and communicating Turn.
 *
 * @param artifactId Artifact communicated by the Item.
 * @param turnId Turn that owns the Item.
 * @returns Stable non-secret Item id.
 */
export function artifactReferenceItemId(artifactId: string, turnId: string): string {
  return deriveEntityId('it', [artifactId, turnId]);
}

/**
 * Lists unresolved user-input request Item ids from the latest canonical revisions.
 *
 * @param itemRevisions Full append-order Item revision history.
 * @returns Sorted request Item ids without a completed response in the same Turn lineage.
 */
export function listUnresolvedUserInputRequestItemIds(itemRevisions: readonly Item[]): string[] {
  const currentItems = new Map<string, Item>();

  for (const item of itemRevisions) {
    currentItems.set(item.id, item);
  }

  const completedResponses = new Set(
    [...currentItems.values()]
      .filter(
        (item): item is Extract<Item, { type: 'user-input-response' }> =>
          item.type === 'user-input-response' && item.status === 'completed'
      )
      .map((item) =>
        JSON.stringify([
          item.workspaceId,
          item.threadId,
          item.turnId,
          item.userInputRequestId,
          item.actor.id,
        ])
      )
  );

  return [...currentItems.values()]
    .filter(
      (item): item is Extract<Item, { type: 'user-input-request' }> =>
        item.type === 'user-input-request' &&
        !completedResponses.has(
          JSON.stringify([
            item.workspaceId,
            item.threadId,
            item.turnId,
            item.userInputRequestId,
            item.responsibleUserId,
          ])
        )
    )
    .map((item) => item.id)
    .sort();
}

/**
 * Rejects a valid revision that rewrites immutable human attribution.
 *
 * @param previous Previous canonical Item revision.
 * @param next Proposed later revision for the same Item.
 * @throws Error when actor, responsible user, or command causation changes.
 */
export function assertImmutableItemAttribution(previous: Item, next: Item): void {
  const actorChanged =
    ((previous.type === 'user-message' && next.type === 'user-message') ||
      (previous.type === 'approval-decision' && next.type === 'approval-decision') ||
      (previous.type === 'user-input-response' && next.type === 'user-input-response')) &&
    JSON.stringify(previous.actor) !== JSON.stringify(next.actor);
  const responsibleUserChanged =
    previous.type === 'user-input-request' &&
    next.type === 'user-input-request' &&
    previous.responsibleUserId !== next.responsibleUserId;
  const causationChanged =
    ((previous.type === 'approval-decision' && next.type === 'approval-decision') ||
      (previous.type === 'user-input-response' && next.type === 'user-input-response')) &&
    previous.causationId !== next.causationId;

  if (actorChanged || responsibleUserChanged || causationChanged) {
    throw new Error(`Item attribution cannot change: ${next.id}.`);
  }
}

/**
 * Parses and validates the canonical record graph shared by persistence and portability.
 *
 * @param input Raw workspace history and optional app-local record families.
 * @returns Parsed records with verified ownership, identity, revision, and event lineage.
 * @throws Error when records collide, disagree, or reference missing workspace state.
 */
export function parseCanonicalWorkspaceHistory(input: {
  workspace: unknown;
  threads: readonly unknown[];
  turns: readonly unknown[];
  itemRevisions: readonly unknown[];
  artifacts: readonly unknown[];
  knowledgeProposals?: readonly unknown[] | undefined;
  knowledgeProposalReviews?: readonly unknown[] | undefined;
  knowledgeSources?: readonly unknown[] | undefined;
  agentSessions: readonly unknown[];
  turnEvents: readonly (readonly [string, readonly unknown[]])[];
}): {
  workspace: WorkspaceRecord;
  threads: Thread[];
  turns: Turn[];
  itemRevisions: Item[];
  artifacts: Artifact[];
  knowledgeProposals: KnowledgeProposalRecord[];
  knowledgeProposalReviews: KnowledgeProposalReviewRecord[];
  knowledgeSources: KnowledgeSourceRecord[];
  agentSessions: AgentSession[];
  turnEvents: Array<[string, SseEventEnvelope[]]>;
} {
  const workspace = WorkspaceRecordSchema.strip().parse(input.workspace);
  const threads = input.threads.map((record) => ThreadSchema.parse(record));
  const turns = input.turns.map((record) => TurnReaderSchema.parse(record));
  const itemRevisions = input.itemRevisions.map((record) => ItemReaderSchema.parse(record));
  const artifacts = input.artifacts.map((record) => ArtifactReaderSchema.parse(record));
  const knowledgeProposals = (input.knowledgeProposals ?? []).map((record) =>
    parseRetainedKnowledgeProposal(record)
  );
  const knowledgeProposalReviews = (input.knowledgeProposalReviews ?? []).map((record) =>
    KnowledgeProposalReviewRecordSchema.parse(record)
  );
  const knowledgeSources = (input.knowledgeSources ?? []).map((record) =>
    KnowledgeSourceRecordSchema.parse(record)
  );
  const agentSessions = input.agentSessions.map(
    (record) => AgentSessionRecordSchema.parse(record) as AgentSession
  );
  const turnEvents = input.turnEvents.map(
    ([turnId, events]) =>
      [turnId, events.map((event) => SseEventReaderSchema.parse(event))] as [
        string,
        SseEventEnvelope[],
      ]
  );
  const threadIds = new Set<string>();
  const turnIds = new Set<string>();
  const artifactIds = new Set<string>();
  const proposalIds = new Set<string>();
  const proposalReviewIds = new Set<string>();
  const sourceIds = new Set<string>();
  const sessionIds = new Set<string>();
  const threadsById = new Map<string, Thread>();
  const turnsById = new Map<string, Turn>();
  const artifactsById = new Map<string, Artifact>();
  const proposalsById = new Map<string, KnowledgeProposalRecord>();
  const proposalReviewsById = new Map<string, KnowledgeProposalReviewRecord[]>();
  const sessionsById = new Map<string, AgentSession>();
  const currentSessionByThreadId = new Map<string, string>();
  const itemOrder: string[] = [];
  const latestItems = new Map<string, Item>();

  for (const thread of threads) {
    claimGlobalId(threadIds, thread.id, 'thread');
    if (thread.workspaceId !== workspace.id) {
      throw new Error(`Thread ${thread.id} has invalid lineage.`);
    }
    threadsById.set(thread.id, thread);
  }
  for (const turn of turns) {
    claimGlobalId(turnIds, turn.id, 'turn');
    const thread = threadsById.get(turn.threadId);
    if (!thread || turn.workspaceId !== workspace.id || thread.workspaceId !== workspace.id) {
      throw new Error(`Turn ${turn.id} has invalid lineage.`);
    }
    turnsById.set(turn.id, turn);
  }
  for (const item of itemRevisions) {
    const turn = turnsById.get(item.turnId);
    const previous = latestItems.get(item.id);
    if (
      !turn ||
      item.workspaceId !== workspace.id ||
      item.threadId !== turn.threadId ||
      (previous &&
        (previous.workspaceId !== item.workspaceId ||
          previous.threadId !== item.threadId ||
          previous.turnId !== item.turnId ||
          previous.type !== item.type ||
          previous.createdAt !== item.createdAt))
    ) {
      throw new Error(`Item revision ${item.id} has invalid lineage.`);
    }
    if (previous) {
      assertImmutableItemAttribution(previous, item);
    }
    if (!previous) {
      itemOrder.push(item.id);
    }
    latestItems.set(item.id, item);
  }
  for (const turn of turns) {
    const expectedItems = itemOrder
      .map((itemId) => latestItems.get(itemId) as Item)
      .filter((item) => item.turnId === turn.id);
    if (
      new Set(turn.items.map((item) => item.id)).size !== turn.items.length ||
      turn.items.length !== expectedItems.length ||
      turn.items.some(
        (item, index) => JSON.stringify(item) !== JSON.stringify(expectedItems[index])
      )
    ) {
      throw new Error('Turn items must equal the latest canonical item revisions.');
    }
  }
  const artifactReferences = new Map<
    string,
    Array<Extract<Item, { type: 'artifact-reference' }>>
  >();
  const artifactReferenceTurns = new Set<string>();
  for (const item of latestItems.values()) {
    if (item.type !== 'artifact-reference') {
      continue;
    }
    const turnKey = JSON.stringify([item.artifactId, item.turnId]);
    if (artifactReferenceTurns.has(turnKey)) {
      throw new Error(
        `Artifact ${item.artifactId} has duplicate artifact-reference Items for Turn ${item.turnId}.`
      );
    }
    artifactReferenceTurns.add(turnKey);
    artifactReferences.set(item.artifactId, [
      ...(artifactReferences.get(item.artifactId) ?? []),
      item,
    ]);
  }
  for (const artifact of artifacts) {
    claimGlobalId(artifactIds, artifact.id, 'artifact');
    const thread = artifact.threadId ? threadsById.get(artifact.threadId) : null;
    const turn = artifact.turnId ? turnsById.get(artifact.turnId) : null;
    const references = artifactReferences.get(artifact.id) ?? [];
    const liveReferences = references.filter((reference) => reference.status !== 'declined');
    const completedReferences = liveReferences.filter(
      (reference) => reference.status === 'completed'
    );
    const producingReferences = completedReferences.filter(
      (reference) =>
        artifact.origin.kind === 'turn-output' &&
        reference.turnId === artifact.origin.turnId &&
        reference.artifactVersion === 1 &&
        reference.lastMutationRequestId === artifact.origin.requestId
    );
    const currentReferences = completedReferences.filter(
      (reference) =>
        reference.artifactVersion === artifact.version &&
        reference.lastMutationRequestId === artifact.lastMutationRequestId &&
        reference.title === artifact.title &&
        reference.summary === artifact.summary
    );
    const requiresCurrentReference = artifact.origin.kind === 'turn-output' || artifact.version > 1;
    // File identity is verified against its version-owned payload when loaded or
    // transferred; this record-only validator has no source filesystem authority.
    const contentDigest =
      artifact.content.format === 'file'
        ? artifact.contentDigest
        : `sha256:${createHash('sha256').update(artifact.content.body, 'utf8').digest('hex')}`;
    if (
      artifact.workspaceId !== workspace.id ||
      artifact.contentDigest !== contentDigest ||
      (artifact.threadId === null) !== (artifact.turnId === null) ||
      (artifact.threadId !== null && !thread) ||
      (artifact.turnId !== null &&
        (!turn ||
          artifact.threadId !== turn.threadId ||
          artifact.workspaceId !== turn.workspaceId)) ||
      (artifact.origin.kind === 'turn-output' && producingReferences.length !== 1) ||
      currentReferences.length > 1 ||
      (requiresCurrentReference && currentReferences.length !== 1)
    ) {
      throw new Error(`Artifact ${artifact.id} has invalid artifact-reference lineage.`);
    }
    artifactsById.set(artifact.id, artifact);
  }
  for (const references of artifactReferences.values()) {
    for (const reference of references) {
      if (reference.status === 'declined') {
        continue;
      }
      const artifact = artifactsById.get(reference.artifactId);
      const turn = turnsById.get(reference.turnId);
      if (reference.id !== artifactReferenceItemId(reference.artifactId, reference.turnId)) {
        throw new Error(
          `Artifact reference ${reference.id} does not use its deterministic identity.`
        );
      }
      if (
        !artifact ||
        reference.workspaceId !== artifact.workspaceId ||
        !turn ||
        turn.workspaceId !== artifact.workspaceId ||
        reference.threadId !== turn.threadId ||
        reference.artifactVersion > artifact.version
      ) {
        throw new Error(`Artifact reference ${reference.id} has invalid lineage.`);
      }
    }
  }
  for (const proposal of knowledgeProposals) {
    claimGlobalId(proposalIds, proposal.id, 'knowledge proposal');
    if (proposal.workspaceId !== workspace.id) {
      throw new Error(`Knowledge proposal ${proposal.id} has invalid lineage.`);
    }
    proposalsById.set(proposal.id, proposal);
  }
  for (const review of knowledgeProposalReviews) {
    claimGlobalId(proposalReviewIds, review.reviewId, 'knowledge proposal review');
    const proposal = proposalsById.get(review.proposalId);
    const proposalDigest = proposal
      ? `sha256:${createHash('sha256')
          .update(serializeKnowledgeProposalRecord(proposal), 'utf8')
          .digest('hex')}`
      : null;
    if (
      !proposal ||
      review.workspaceId !== workspace.id ||
      review.knowledgePageId !== proposal.knowledgePageId ||
      review.contentDigest !== proposal.contentDigest ||
      review.proposalDigest !== proposalDigest
    ) {
      throw new Error(`Knowledge proposal review ${review.reviewId} has invalid lineage.`);
    }
    proposalReviewsById.set(review.proposalId, [
      ...(proposalReviewsById.get(review.proposalId) ?? []),
      review,
    ]);
  }
  for (const [proposalId, decisions] of proposalReviewsById) {
    KnowledgeProposalReviewFileSchema.parse({ proposalId, workspaceId: workspace.id, decisions });
  }
  for (const source of knowledgeSources) {
    claimGlobalId(sourceIds, source.id, 'knowledge source');
    const thread = source.originatingThreadId ? threadsById.get(source.originatingThreadId) : null;
    const turn = source.originatingTurnId ? turnsById.get(source.originatingTurnId) : null;
    if (
      source.workspaceId !== workspace.id ||
      (source.originatingThreadId !== null && !thread) ||
      (source.originatingTurnId !== null && (!turn || turn.threadId !== source.originatingThreadId))
    ) {
      throw new Error(`Knowledge source ${source.id} has invalid lineage.`);
    }
  }
  for (const session of agentSessions) {
    claimGlobalId(sessionIds, session.id, 'AgentSession');
    if (
      session.workspaceId !== workspace.id ||
      session.threadId === null ||
      !threadsById.has(session.threadId)
    ) {
      throw new Error(`AgentSession ${session.id} has invalid lineage.`);
    }
    if (isCurrentAgentSessionStatus(session.status)) {
      const currentSessionId = currentSessionByThreadId.get(session.threadId);
      if (currentSessionId) {
        throw new Error(
          `Thread ${session.threadId} has duplicate current AgentSessions: ${currentSessionId}, ${session.id}.`
        );
      }
      currentSessionByThreadId.set(session.threadId, session.id);
    }
    sessionsById.set(session.id, session);
  }
  const eventTurnIds = new Set<string>();
  for (const [turnId, events] of turnEvents) {
    const turn = turnsById.get(turnId);
    if (!turn || eventTurnIds.has(turnId)) {
      throw new Error(`Turn events reference missing or duplicate canonical turn: ${turnId}`);
    }
    eventTurnIds.add(turnId);
    const turnItemIds = new Set(turn.items.map((item) => item.id));
    for (const [index, event] of events.entries()) {
      if (
        event.sequence !== index + 1 ||
        event.workspaceId !== workspace.id ||
        event.threadId !== turn.threadId ||
        event.turnId !== turn.id
      ) {
        throw new Error(`Turn event ${event.event} has invalid lineage for ${turnId}.`);
      }
      assertTurnEventPayloadLineage(event, workspace.id, turn.threadId, turn.id, turnItemIds);
      if (
        (event.data.type === 'agent-session-updated' &&
          !sessionsById.has(event.data.agentSession.id)) ||
        ((event.data.type === 'artifact-created' || event.data.type === 'artifact-updated') &&
          !artifactsById.has(event.data.artifact.id)) ||
        (event.data.type === 'item-delta' &&
          event.data.deltaKind === 'artifact-updated' &&
          !artifactsById.has(event.data.artifactId))
      ) {
        throw new Error(`Turn event ${event.event} references missing canonical state.`);
      }
    }
  }

  return {
    workspace,
    threads,
    turns,
    itemRevisions,
    artifacts,
    knowledgeProposals,
    knowledgeProposalReviews,
    knowledgeSources,
    agentSessions,
    turnEvents,
  };
}

/**
 * Rejects an identifier that cannot be used as one canonical path segment.
 *
 * @param value Candidate path segment.
 * @param label Human-readable identifier label.
 * @throws Error when the value is empty, special, or contains a path separator.
 */
export function assertSafeWorkspacePathSegment(value: string, label: string): void {
  if (
    value.length === 0 ||
    value === '.' ||
    value === '..' ||
    value.includes('/') ||
    value.includes('\\') ||
    value.includes('\0')
  ) {
    throw new Error(`${label} must be a safe path segment.`);
  }
}

/**
 * Resolves one schema-valid Knowledge Page id below the canonical pages root.
 *
 * @param workspaceRoot Published workspace root.
 * @param knowledgePageId Slash-separated Knowledge Page id.
 * @param createParents Whether missing safe parent directories may be created.
 * @returns Canonical page path, or null when a read-only parent is absent.
 */
function resolveWorkspaceKnowledgePagePath(
  workspaceRoot: string,
  knowledgePageId: string,
  createParents: boolean
): string | null {
  const parsedId = KnowledgeProposalPageIdSchema.parse(knowledgePageId);
  const segments = parsedId.split('/');
  const pagesRoot = join(workspaceRoot, 'knowledge', 'pages');

  for (const path of [workspaceRoot, join(workspaceRoot, 'knowledge'), pagesRoot]) {
    assertCanonicalDirectory(path);
  }
  for (const segment of segments) {
    assertSafeWorkspacePathSegment(segment, 'Knowledge Page id segment');
  }

  const target = resolve(pagesRoot, ...segments.slice(0, -1), `${segments.at(-1)!}.md`);
  const targetRelative = relative(resolve(pagesRoot), target);
  if (
    targetRelative === '..' ||
    targetRelative.startsWith(`..${sep}`) ||
    isAbsolute(targetRelative)
  ) {
    throw new Error('Knowledge Page path escapes the canonical pages root.');
  }

  let parent = pagesRoot;
  for (const segment of segments.slice(0, -1)) {
    parent = join(parent, segment);
    const metadata = lstatSync(parent, { throwIfNoEntry: false });
    if (!metadata) {
      if (!createParents) {
        return null;
      }
      ensureCanonicalDirectory(parent);
      continue;
    }
    assertCanonicalDirectory(parent);
  }

  return target;
}

/**
 * Reads one canonical Knowledge Page without following symbolic links.
 *
 * @param workspaceRoot Published workspace root.
 * @param knowledgePageId Slash-separated Knowledge Page id.
 * @returns Exact UTF-8 page bytes, or null when the page is absent.
 */
export function readWorkspaceKnowledgePage(
  workspaceRoot: string,
  knowledgePageId: string
): string | null {
  const path = resolveWorkspaceKnowledgePagePath(workspaceRoot, knowledgePageId, false);
  if (!path || !lstatSync(path, { throwIfNoEntry: false })) {
    return null;
  }
  return readCanonicalTextFile(path);
}

/**
 * Deletes one canonical knowledge page before its in-memory owner is removed.
 *
 * @param workspaceRoot Published workspace root.
 * @param knowledgeEntryId Knowledge entry id to delete.
 */
export function deleteWorkspaceKnowledgeRecord(
  workspaceRoot: string,
  knowledgeEntryId: string
): void {
  const path = resolveWorkspaceKnowledgePagePath(workspaceRoot, knowledgeEntryId, false);
  if (!path || !lstatSync(path, { throwIfNoEntry: false })) {
    return;
  }
  assertCanonicalRegularFile(path);
  rmSync(path);
}

/**
 * Reads one canonical UTF-8 file without following a symbolic link.
 *
 * @param path Canonical file path.
 * @returns Complete UTF-8 file content.
 * @throws Error when the path is a symbolic link or not a regular file.
 */
export function readCanonicalTextFile(path: string): string {
  return readCanonicalFile(path).toString('utf8');
}

/**
 * Reads one canonical file buffer through a no-follow regular-file descriptor.
 *
 * @param path Canonical file path.
 * @returns Complete file bytes.
 * @throws Error when the path is a symbolic link or not a regular file.
 */
export function readCanonicalFile(path: string): Buffer {
  assertCanonicalRegularFile(path);
  let descriptor: number;

  try {
    descriptor = openSync(path, constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK);
  } catch (error) {
    throwCanonicalLinkError(path, error);
  }

  try {
    if (!fstatSync(descriptor).isFile()) {
      throw new Error(`Canonical path must be a regular file: ${path}.`);
    }
    return readFileSync(descriptor);
  } finally {
    closeSync(descriptor);
  }
}

/** Complete canonical file records for one workspace. */
export interface WorkspaceFileRecords {
  /** Workspace metadata. */
  readonly workspace: WorkspaceRecord;
  /** Protocol knowledge entries represented by owned OKF pages. */
  readonly knowledge: readonly KnowledgeEntry[];
  /** Workspace threads. */
  readonly threads: readonly Thread[];
  /** Workspace turns with reconstructed current items. */
  readonly turns: readonly Turn[];
  /** Full append-order item revision history. */
  readonly itemRevisions: readonly Item[];
  /** Workspace artifacts with reconstructed content bodies. */
  readonly artifacts: readonly Artifact[];
  /** Knowledge proposals. */
  readonly knowledgeProposals: readonly KnowledgeProposalRecord[];
  /** Knowledge proposal review decisions. */
  readonly knowledgeProposalReviews: readonly KnowledgeProposalReviewRecord[];
  /** Knowledge source registry records. */
  readonly knowledgeSources: readonly KnowledgeSourceRecord[];
  /** Durable AgentSessions. */
  readonly agentSessions: readonly AgentSession[];
  /** Retained turn event windows keyed by turn id. */
  readonly streamEvents: readonly (readonly [string, readonly SseEventEnvelope[]])[];
  /** Admission-time capture pairs keyed by Turn id; omitted Turns were never recorded. */
  readonly turnCaptureCoverage?: ReadonlyMap<string, CaptureCoverageBinding>;
}

/** One published Turn identity read without repairing canonical files. */
export interface PublishedTurnIdentity {
  readonly threadId: string;
  readonly turnId: string;
  readonly workspaceId: string;
}

/** Read-only result of scanning published Turn files. */
export type PublishedTurnIdentityRead =
  | { readonly status: 'readable'; readonly turns: readonly PublishedTurnIdentity[] }
  | { readonly status: 'unreadable' };

/** Read-only result of scanning published AgentSession ids. */
export type PublishedAgentSessionIdRead =
  | { readonly sessionIds: readonly string[]; readonly status: 'readable' }
  | { readonly status: 'unreadable' };

/**
 * Reads published Turn identities without creating layout, rewriting Thread envelopes, or repairing history.
 *
 * @param dataRoot Data root whose workspace tree should be inspected.
 * @returns Turn identities whose file lineage matches their directories, or `unreadable` when a Turn file is missing or corrupt.
 */
export function readPublishedTurnIdentities(dataRoot: string): PublishedTurnIdentityRead {
  try {
    const turns: PublishedTurnIdentity[] = [];
    const workspacesRoot = join(dataRoot, 'workspaces');
    for (const workspaceId of listDirectoryNames(workspacesRoot)) {
      if (workspaceId === '.staging') continue;
      const workspaceRoot = join(workspacesRoot, workspaceId);
      const workspaceRecord = WorkspaceSystemRecordSchema.parse(
        readJson(join(workspaceRoot, 'workspace-record.json'))
      );
      if (workspaceRecord.id !== workspaceId) {
        return { status: 'unreadable' };
      }
      const threadsRoot = join(workspaceRoot, 'threads');
      for (const threadId of listDirectoryNames(threadsRoot)) {
        const threadPath = join(threadsRoot, threadId, 'thread.json');
        const thread = parseCanonicalThreadRecord(
          readJson(threadPath),
          workspaceId,
          threadId,
          () => {
            throw new Error(
              'Read-only history inspection does not migrate a Thread visibility envelope.'
            );
          }
        );
        if (thread.id !== threadId || thread.workspaceId !== workspaceId) {
          return { status: 'unreadable' };
        }
        const turnsRoot = join(threadsRoot, threadId, 'turns');
        for (const turnId of listDirectoryNames(turnsRoot)) {
          readPublishedTurnRecord(turnsRoot, workspaceId, threadId, turnId);
          turns.push({ threadId, turnId, workspaceId });
        }
      }
    }
    return { status: 'readable', turns };
  } catch {
    return { status: 'unreadable' };
  }
}

/**
 * Validates one published Turn and its Item log without rewriting canonical files.
 *
 * @param turnsRoot Thread turns directory.
 * @param workspaceId Owning Workspace id.
 * @param threadId Owning Thread id.
 * @param turnId Turn directory id.
 * @throws Error when the Turn schema, lineage, or Item history cannot be read.
 */
function readPublishedTurnRecord(
  turnsRoot: string,
  workspaceId: string,
  threadId: string,
  turnId: string
): void {
  const turnPath = join(turnsRoot, turnId, 'turn.json');
  if (!existsSync(turnPath)) {
    throw new Error(`Canonical turn directory is missing turn.json: ${turnId}.`);
  }
  const rawTurn = readJson(turnPath) as Record<string, unknown>;
  if (rawTurn.items !== undefined && (!Array.isArray(rawTurn.items) || rawTurn.items.length > 0)) {
    throw new Error(`Canonical turn metadata must not embed items: ${turnId}.`);
  }
  if (rawTurn.captureCoverage !== undefined) {
    const parsedCoverage = CaptureCoverageBindingSchema.safeParse(rawTurn.captureCoverage);
    if (!parsedCoverage.success) {
      throw new Error(
        `Canonical turn metadata has an invalid capture coverage binding: ${turnId}.`
      );
    }
  }
  const turnWithoutItems = TurnReaderSchema.parse({ ...rawTurn, items: [] });
  if (
    turnWithoutItems.id !== turnId ||
    turnWithoutItems.workspaceId !== workspaceId ||
    turnWithoutItems.threadId !== threadId
  ) {
    throw new Error(`Turn record ${turnWithoutItems.id} has invalid lineage.`);
  }
  const itemsPath = join(turnsRoot, turnId, 'items.jsonl');
  if (!existsSync(itemsPath)) {
    throw new Error(`Canonical turn directory is missing items.jsonl: ${turnId}.`);
  }
  const items = readPublishedItemRevisions(itemsPath, workspaceId, threadId, turnId);
  TurnReaderSchema.parse({ ...turnWithoutItems, items });
}

/**
 * Reads Item revisions with the canonical JSONL rules and does not repair the file.
 *
 * An incomplete final fragment is ignored. A completed malformed row is rejected.
 *
 * @param path Item JSONL path.
 * @param workspaceId Owning Workspace id.
 * @param threadId Owning Thread id.
 * @param turnId Owning Turn id.
 * @returns Current Item projection in first-seen order.
 */
function readPublishedItemRevisions(
  path: string,
  workspaceId: string,
  threadId: string,
  turnId: string
): Item[] {
  const order: string[] = [];
  const items = new Map<string, Item>();
  for (const value of readDurableCanonicalJsonLines(path)) {
    const item = ItemReaderSchema.parse(value);
    const previous = items.get(item.id);
    if (item.workspaceId !== workspaceId || item.threadId !== threadId || item.turnId !== turnId) {
      throw new Error(`Item record ${item.id} has invalid lineage.`);
    }
    if (previous && (item.type !== previous.type || item.createdAt !== previous.createdAt)) {
      throw new Error(`Item revision changed immutable identity: ${item.id}.`);
    }
    if (previous) {
      assertImmutableItemAttribution(previous, item);
    }
    if (!items.has(item.id)) {
      order.push(item.id);
    }
    items.set(item.id, item);
  }
  return order.map((itemId) => items.get(itemId) as Item);
}

/**
 * Reads published AgentSession ids without repairing session records.
 *
 * @param dataRoot Data root that owns the Workspace.
 * @param workspaceId Workspace whose runtime session directory should be inspected.
 * @returns Session ids, or `unreadable` when a session directory cannot be proved.
 */
export function readPublishedAgentSessionIds(
  dataRoot: string,
  workspaceId: string
): PublishedAgentSessionIdRead {
  try {
    const root = join(dataRoot, 'workspaces', workspaceId, 'runtime', 'agent-sessions');
    const sessionIds: string[] = [];
    for (const sessionId of listDirectoryNames(root)) {
      const sessionPath = join(root, sessionId, 'session.json');
      if (!existsSync(sessionPath)) {
        return { status: 'unreadable' };
      }
      const session = AgentSessionRecordSchema.parse(readJson(sessionPath));
      if (
        session.id !== sessionId ||
        session.workspaceId !== workspaceId ||
        !session.threadId ||
        !existsSync(
          join(dataRoot, 'workspaces', workspaceId, 'threads', session.threadId, 'thread.json')
        )
      ) {
        return { status: 'unreadable' };
      }
      sessionIds.push(session.id);
    }
    return { sessionIds, status: 'readable' };
  } catch {
    return { status: 'unreadable' };
  }
}

/**
 * Loads every published workspace from canonical file records.
 *
 * @param dataRoot Data root that owns the Workspace tree.
 * @returns Canonical workspace records in workspace-directory order.
 * @throws Error when record lineage is invalid or a global id collides.
 */
export function loadWorkspaceFileRecords(dataRoot: string): WorkspaceFileRecords[] {
  const workspacesRoot = ensureLayoutDirectories(dataRoot).workspaces;
  assertCanonicalDirectory(workspacesRoot);
  const records = listDirectoryNames(workspacesRoot)
    .filter((name) => name !== '.staging')
    .map((workspaceId) => {
      assertSafeWorkspacePathSegment(workspaceId, 'Workspace id');
      return loadWorkspace(join(workspacesRoot, workspaceId), workspaceId, dataRoot);
    });
  const threadIds = new Set<string>();
  const turnIds = new Set<string>();
  const itemIds = new Set<string>();
  const artifactIds = new Set<string>();
  const proposalIds = new Set<string>();
  const sourceIds = new Set<string>();
  const agentSessionIds = new Set<string>();

  for (const workspaceRecords of records) {
    for (const thread of workspaceRecords.threads) {
      claimGlobalId(threadIds, thread.id, 'thread');
    }
    for (const turn of workspaceRecords.turns) {
      claimGlobalId(turnIds, turn.id, 'turn');
      for (const item of turn.items) {
        claimGlobalId(itemIds, item.id, 'item');
      }
    }
    for (const artifact of workspaceRecords.artifacts) {
      claimGlobalId(artifactIds, artifact.id, 'artifact');
    }
    for (const proposal of workspaceRecords.knowledgeProposals) {
      claimGlobalId(proposalIds, proposal.id, 'knowledge proposal');
    }
    for (const source of workspaceRecords.knowledgeSources) {
      claimGlobalId(sourceIds, source.id, 'knowledge source');
    }
    for (const session of workspaceRecords.agentSessions) {
      claimGlobalId(agentSessionIds, session.id, 'AgentSession');
    }
  }

  return records;
}

/** Discards abandoned private staging at Store startup, before any live admission. Read-only canonical inspection must never delete a concurrent capture. */
export function discardAbandonedWorkspaceStaging(dataRoot: string): void {
  const root = ensureLayoutDirectories(dataRoot).workspaces;
  assertCanonicalDirectory(root);
  rmSync(join(root, '.staging'), { recursive: true, force: true });
}

/**
 * Writes one workspace's mutable canonical file records under a resolved root.
 *
 * @param workspaceRoot Resolved workspace root.
 * @param records Current workspace records.
 * @param updateWorkspaceConfigName Whether Core may refresh its owned config name.
 * @param exactKnowledgePageBytes Final validated direct-edit bytes keyed by Page id.
 */
export function writeWorkspaceFileRecords(
  workspaceRoot: string,
  records: WorkspaceFileRecords,
  updateWorkspaceConfigName = false,
  exactKnowledgePageBytes: ReadonlyMap<string, string> = new Map()
): void {
  assertSafeWorkspaceFileRecordIds(records);
  assertExistingWorkspaceDirectoryParents(workspaceRoot);
  ensureWorkspaceLayoutRoot(workspaceRoot);
  assertExistingWorkspaceDirectoryParents(workspaceRoot);
  const pagesRoot = join(workspaceRoot, 'knowledge', 'pages');
  ensureCanonicalDirectory(pagesRoot);
  ensureRootKnowledgeIndex(pagesRoot);
  writeWorkspaceMetadata(workspaceRoot, records.workspace, updateWorkspaceConfigName);
  writeThreads(workspaceRoot, records);
  writeKnowledge(workspaceRoot, records, exactKnowledgePageBytes);
  writeSources(workspaceRoot, records);
  writeArtifacts(workspaceRoot, records);
  writeAgentSessions(workspaceRoot, records);
}

/**
 * Appends one full item revision to its owning turn log.
 *
 * @param workspaceRoot Resolved workspace root.
 * @param item Item revision to append.
 */
export function appendWorkspaceItemRevision(workspaceRoot: string, item: Item): void {
  const parsed = ItemSchema.parse(item);

  assertSafeWorkspacePathSegment(parsed.id, 'Item id');
  assertSafeWorkspacePathSegment(parsed.threadId, 'Item thread id');
  assertSafeWorkspacePathSegment(parsed.turnId, 'Item turn id');
  const path = join(
    workspaceRoot,
    'threads',
    parsed.threadId,
    'turns',
    parsed.turnId,
    'items.jsonl'
  );

  for (const parent of [
    workspaceRoot,
    join(workspaceRoot, 'threads'),
    join(workspaceRoot, 'threads', parsed.threadId),
    join(workspaceRoot, 'threads', parsed.threadId, 'turns'),
    dirname(path),
  ]) {
    assertCanonicalDirectory(parent);
  }
  appendCanonicalTextFile(path, `${JSON.stringify(parsed)}\n`);
}

/**
 * Appends one validated event envelope to its owning turn event log.
 *
 * @param workspaceRoot Resolved workspace root.
 * @param event Event envelope to append.
 */
export function appendWorkspaceTurnEvent(workspaceRoot: string, event: SseEventEnvelope): void {
  const parsed = SseEventEnvelopeSchema.parse(event);

  if (!parsed.threadId || !parsed.turnId) {
    throw new Error('Turn event storage requires thread and turn lineage.');
  }
  assertSafeWorkspacePathSegment(parsed.threadId, 'Event thread id');
  assertSafeWorkspacePathSegment(parsed.turnId, 'Event turn id');

  const path = join(
    workspaceRoot,
    'threads',
    parsed.threadId,
    'turns',
    parsed.turnId,
    'runtime',
    'events.jsonl'
  );

  for (const parent of [
    workspaceRoot,
    join(workspaceRoot, 'threads'),
    join(workspaceRoot, 'threads', parsed.threadId),
    join(workspaceRoot, 'threads', parsed.threadId, 'turns'),
    join(workspaceRoot, 'threads', parsed.threadId, 'turns', parsed.turnId),
  ]) {
    assertCanonicalDirectory(parent);
  }
  ensureCanonicalDirectory(dirname(path));
  appendCanonicalTextFile(path, `${JSON.stringify(parsed)}\n`);
}

/**
 * Loads one workspace and every owned record family.
 *
 * @param workspaceRoot Published workspace root.
 * @param workspaceId Workspace directory id.
 * @returns Loaded canonical workspace records.
 */
function loadWorkspace(
  workspaceRoot: string,
  workspaceId: string,
  dataRoot: string
): WorkspaceFileRecords {
  assertExistingWorkspaceDirectoryParents(workspaceRoot);
  const retiredWorkspacePath = join(workspaceRoot, 'workspace.json');
  const workspacePath = join(workspaceRoot, 'workspace-record.json');
  const workspaceConfigPath = join(workspaceRoot, 'config', 'workspace.jsonc');

  if (existsSync(retiredWorkspacePath)) {
    throw new Error(`Unsupported canonical workspace file workspace.json: ${workspaceId}.`);
  }
  if (!existsSync(workspacePath)) {
    throw new Error(
      `Canonical workspace directory is missing workspace-record.json: ${workspaceId}.`
    );
  }
  if (!existsSync(workspaceConfigPath)) {
    throw new Error(
      `Canonical workspace directory is missing config/workspace.jsonc: ${workspaceId}.`
    );
  }

  const workspaceRecord = WorkspaceSystemRecordSchema.parse(readJson(workspacePath));
  const workspaceConfig = WorkspaceConfigSchema.parse(
    parseJsoncObject(readCanonicalTextFile(workspaceConfigPath), workspaceConfigPath)
  );

  if (workspaceRecord.id !== workspaceId) {
    throw new Error(
      `Workspace record ${workspaceRecord.id} does not match its directory ${workspaceId}.`
    );
  }

  const threads: Thread[] = [];
  const turns: Turn[] = [];
  const itemRevisions: Item[] = [];
  const streamEvents: Array<readonly [string, readonly SseEventEnvelope[]]> = [];
  const turnCaptureCoverage = new Map<string, CaptureCoverageBinding>();
  const threadsRoot = join(workspaceRoot, 'threads');

  for (const threadId of listDirectoryNames(threadsRoot)) {
    const threadPath = join(threadsRoot, threadId, 'thread.json');

    if (!existsSync(threadPath)) {
      throw new Error(`Canonical thread directory is missing thread.json: ${threadId}.`);
    }

    const rawThread = readJson(threadPath);
    const thread = parseCanonicalThreadRecord(rawThread, workspaceId, threadId, () =>
      classifyThreadVisibilityCutover(dataRoot, workspaceRoot, workspaceRecord.kind, threadId)
    );
    if (
      !isCanonicalThreadEnvelope(rawThread) ||
      !(rawThread as { requiredFeatures: string[] }).requiredFeatures.includes(
        THREAD_VISIBILITY_REQUIRED_FEATURE
      )
    ) {
      writeJsonAtomic(threadPath, projectCanonicalThreadRecord(thread));
    }

    if (thread.id !== threadId || thread.workspaceId !== workspaceId) {
      throw new Error(`Thread record ${thread.id} has invalid workspace or directory lineage.`);
    }

    threads.push(thread);
    const turnsRoot = join(threadsRoot, threadId, 'turns');

    for (const turnId of listDirectoryNames(turnsRoot)) {
      const turnPath = join(turnsRoot, turnId, 'turn.json');

      if (!existsSync(turnPath)) {
        throw new Error(`Canonical turn directory is missing turn.json: ${turnId}.`);
      }

      const rawTurn = readJson(turnPath) as Record<string, unknown>;
      if (
        rawTurn.items !== undefined &&
        (!Array.isArray(rawTurn.items) || rawTurn.items.length > 0)
      ) {
        throw new Error(`Canonical turn metadata must not embed items: ${turnId}.`);
      }
      if (rawTurn.captureCoverage !== undefined) {
        const parsedCoverage = CaptureCoverageBindingSchema.safeParse(rawTurn.captureCoverage);
        if (!parsedCoverage.success) {
          throw new Error(
            `Canonical turn metadata has an invalid capture coverage binding: ${turnId}.`
          );
        }
        turnCaptureCoverage.set(turnId, parsedCoverage.data);
      }
      const turnWithoutItems = TurnReaderSchema.parse({ ...rawTurn, items: [] });

      if (
        turnWithoutItems.id !== turnId ||
        turnWithoutItems.workspaceId !== workspaceId ||
        turnWithoutItems.threadId !== threadId
      ) {
        throw new Error(`Turn record ${turnWithoutItems.id} has invalid lineage.`);
      }

      const itemsPath = join(turnsRoot, turnId, 'items.jsonl');
      if (!existsSync(itemsPath)) {
        throw new Error(`Canonical turn directory is missing items.jsonl: ${turnId}.`);
      }

      const loadedItems = loadItemRevisions(itemsPath, workspaceId, threadId, turnId);
      const turn = TurnReaderSchema.parse({ ...turnWithoutItems, items: loadedItems.current });
      const runtimeRoot = join(turnsRoot, turnId, 'runtime');
      if (lstatSync(runtimeRoot, { throwIfNoEntry: false })) {
        assertCanonicalDirectory(runtimeRoot);
      }
      const events = readWorkspaceTurnEvents(workspaceRoot, turn);

      itemRevisions.push(...loadedItems.revisions);
      turns.push(turn);
      streamEvents.push([turnId, events]);
    }
  }

  const threadIds = new Set(threads.map((thread) => thread.id));
  const turnsById = new Map(turns.map((turn) => [turn.id, turn]));
  const artifacts = loadArtifacts(workspaceRoot, workspaceId, threadIds, turnsById);
  const knowledge = loadKnowledge(workspaceRoot);
  const knowledgeProposals = loadKnowledgeProposals(workspaceRoot, workspaceId);
  const knowledgeProposalReviews = loadKnowledgeProposalReviews(
    workspaceRoot,
    workspaceId,
    new Map(knowledgeProposals.map((proposal) => [proposal.id, proposal]))
  );
  const knowledgeSources = loadKnowledgeSources(workspaceRoot, workspaceId, threadIds, turnsById);
  const agentSessions = loadAgentSessions(workspaceRoot, workspaceId, threadIds);
  const workspace = WorkspaceRecordSchema.parse({
    ...workspaceRecord,
    name: workspaceConfig.workspace.name,
    counts: {
      threadCount: threads.length,
      artifactCount: artifacts.length,
      knowledgeEntryCount: knowledge.length,
    },
  });
  const history = parseCanonicalWorkspaceHistory({
    workspace,
    threads,
    turns,
    itemRevisions,
    artifacts,
    knowledgeProposals,
    knowledgeProposalReviews,
    knowledgeSources,
    agentSessions,
    turnEvents: streamEvents,
  });

  return {
    workspace: history.workspace,
    knowledge,
    threads: history.threads,
    turns: history.turns,
    itemRevisions: history.itemRevisions,
    artifacts: history.artifacts,
    knowledgeProposals: history.knowledgeProposals,
    knowledgeProposalReviews: history.knowledgeProposalReviews,
    knowledgeSources: history.knowledgeSources,
    agentSessions: history.agentSessions,
    streamEvents: history.turnEvents.map(([turnId, events]) => [
      turnId,
      events.slice(-TURN_STREAM_EVENT_WINDOW_SIZE),
    ]),
    turnCaptureCoverage,
  };
}

/** Writes the system Workspace record and the field-preserving editable Workspace config. */
function writeWorkspaceMetadata(
  workspaceRoot: string,
  workspace: WorkspaceRecord,
  updateWorkspaceConfigName: boolean
): void {
  const retiredWorkspacePath = join(workspaceRoot, 'workspace.json');
  const workspaceRecordPath = join(workspaceRoot, 'workspace-record.json');
  const workspaceConfigPath = join(workspaceRoot, 'config', 'workspace.jsonc');

  if (existsSync(retiredWorkspacePath)) {
    throw new Error(`Unsupported canonical workspace file workspace.json: ${workspace.id}.`);
  }

  const configExists = existsSync(workspaceConfigPath);
  if (existsSync(workspaceRecordPath) && !configExists) {
    throw new Error(
      `Canonical workspace directory is missing config/workspace.jsonc: ${workspace.id}.`
    );
  }

  if (!configExists) {
    writeJsonAtomic(workspaceConfigPath, {
      schemaVersion: 1,
      workspace: {
        name: workspace.name,
        defaultAgentId: null,
      },
    });
  } else if (updateWorkspaceConfigName) {
    const source = readCanonicalTextFile(workspaceConfigPath);
    const config = WorkspaceConfigSchema.parse(parseJsoncObject(source, workspaceConfigPath));
    if (config.workspace.name !== workspace.name) {
      const updated = applyEdits(
        source,
        modify(source, ['workspace', 'name'], workspace.name, {
          formattingOptions: { insertSpaces: true, tabSize: 2 },
        })
      );
      WorkspaceConfigSchema.parse(parseJsoncObject(updated, workspaceConfigPath));
      writeFileAtomic(workspaceConfigPath, updated);
    }
  }

  writeOwnedDescriptiveJson(
    workspaceRecordPath,
    projectWorkspaceSystemRecord(workspace),
    WorkspaceSystemRecordSchema
  );
}

/**
 * Projects one public Workspace read model into its system-owned canonical record.
 *
 * @param workspace Joined public Workspace read model.
 * @returns System-owned Workspace record without editable or derived fields.
 */
export function projectWorkspaceSystemRecord(workspace: WorkspaceRecord) {
  return WorkspaceSystemRecordSchema.parse({
    id: workspace.id,
    kind: workspace.kind,
    status: workspace.status,
    importedFrom: workspace.importedFrom,
    createdAt: workspace.createdAt,
    updatedAt: workspace.updatedAt,
  });
}

/**
 * Reads one turn's complete canonical event history.
 *
 * @param workspaceRoot Owning workspace root.
 * @param turn Turn whose validated event log should be read.
 * @returns Every event from sequence one in append order.
 */
export function readWorkspaceTurnEvents(workspaceRoot: string, turn: Turn): SseEventEnvelope[] {
  assertSafeWorkspacePathSegment(turn.threadId, 'Event thread id');
  assertSafeWorkspacePathSegment(turn.id, 'Event turn id');
  return loadTurnEvents(
    join(workspaceRoot, 'threads', turn.threadId, 'turns', turn.id, 'runtime', 'events.jsonl'),
    turn.workspaceId,
    turn.threadId,
    turn.id,
    new Set(turn.items.map((item) => item.id))
  );
}

/**
 * Loads the latest revision for each item while preserving first-id order.
 *
 * @param path Item JSONL path.
 * @param workspaceId Expected workspace id.
 * @param threadId Expected thread id.
 * @param turnId Expected turn id.
 * @returns Latest item revisions.
 */
function loadItemRevisions(
  path: string,
  workspaceId: string,
  threadId: string,
  turnId: string
): { current: Item[]; revisions: Item[] } {
  const order: string[] = [];
  const items = new Map<string, Item>();
  const revisions: Item[] = [];

  for (const value of readCanonicalJsonLines(path, true)) {
    const item = ItemReaderSchema.parse(value);
    const previous = items.get(item.id);

    if (item.workspaceId !== workspaceId || item.threadId !== threadId || item.turnId !== turnId) {
      throw new Error(`Item record ${item.id} has invalid lineage.`);
    }
    if (previous && (item.type !== previous.type || item.createdAt !== previous.createdAt)) {
      throw new Error(`Item revision changed immutable identity: ${item.id}.`);
    }
    if (previous) {
      assertImmutableItemAttribution(previous, item);
    }
    if (!items.has(item.id)) {
      order.push(item.id);
    }
    items.set(item.id, item);
    revisions.push(item);
  }

  return { current: order.map((itemId) => items.get(itemId) as Item), revisions };
}

/**
 * Loads and validates the retained event window for one turn.
 *
 * @param path Event JSONL path.
 * @param workspaceId Expected workspace id.
 * @param threadId Expected thread id.
 * @param turnId Expected turn id.
 * @param itemIds Item ids owned by the turn.
 * @returns Every event envelope in append order.
 */
function loadTurnEvents(
  path: string,
  workspaceId: string,
  threadId: string,
  turnId: string,
  itemIds: ReadonlySet<string>
): SseEventEnvelope[] {
  const events = readCanonicalJsonLines(path, true).map((value) =>
    SseEventReaderSchema.parse(value)
  );

  for (const [index, event] of events.entries()) {
    if (
      event.workspaceId !== workspaceId ||
      event.threadId !== threadId ||
      event.turnId !== turnId
    ) {
      throw new Error(`Turn event ${event.event} has invalid lineage for ${turnId}.`);
    }
    assertTurnEventPayloadLineage(event, workspaceId, threadId, turnId, itemIds);
    const expectedSequence = index + 1;
    if (event.sequence !== expectedSequence) {
      throw new Error(
        `Turn event sequence must be contiguous from 1 for ${turnId}; expected ${expectedSequence}, received ${event.sequence}.`
      );
    }
  }

  return events;
}

/**
 * Verifies that identity-bearing event payloads match their owning turn log.
 *
 * @param event Validated event envelope.
 * @param workspaceId Owning workspace id.
 * @param threadId Owning thread id.
 * @param turnId Owning turn id.
 * @param itemIds Item ids owned by the turn.
 * @throws Error when a nested payload crosses canonical lineage.
 */
export function assertTurnEventPayloadLineage(
  event: SseEventEnvelope,
  workspaceId: string,
  threadId: string,
  turnId: string,
  itemIds: ReadonlySet<string>
): void {
  const data = event.data;
  let valid = true;

  switch (data.type) {
    case 'workspace-updated':
      valid = data.workspace.id === workspaceId;
      break;
    case 'thread-created':
    case 'thread-updated':
      valid = data.thread.workspaceId === workspaceId && data.thread.id === threadId;
      break;
    case 'turn-started':
      valid = data.turnId === turnId;
      break;
    case 'turn-updated':
    case 'turn-completed':
      valid =
        data.turn.workspaceId === workspaceId &&
        data.turn.threadId === threadId &&
        data.turn.id === turnId;
      break;
    case 'item-created':
      valid =
        data.item.workspaceId === workspaceId &&
        data.item.threadId === threadId &&
        data.item.turnId === turnId &&
        itemIds.has(data.item.id);
      break;
    case 'item-completed':
      valid =
        data.item.workspaceId === workspaceId &&
        data.item.threadId === threadId &&
        data.item.turnId === turnId &&
        data.itemId === data.item.id &&
        itemIds.has(data.item.id);
      break;
    case 'item-delta':
      valid = itemIds.has(data.itemId);
      break;
    case 'approval-requested':
    case 'approval-resolved':
      valid =
        data.approval.workspaceId === workspaceId &&
        data.approval.threadId === threadId &&
        data.approval.turnId === turnId;
      break;
    case 'agent-session-updated':
      valid =
        data.agentSession.workspaceId === workspaceId && data.agentSession.threadId === threadId;
      break;
    case 'artifact-created':
    case 'artifact-updated':
      valid =
        data.artifact.workspaceId === workspaceId &&
        data.artifact.threadId === threadId &&
        data.artifact.turnId === turnId;
      break;
    case 'error':
      break;
  }

  if (!valid) {
    throw new Error(`Turn event ${event.event} has invalid nested payload lineage for ${turnId}.`);
  }
}

/**
 * Parses one owned Knowledge Page into its protocol projection.
 *
 * @param path Canonical page path used for validation diagnostics.
 * @param knowledgePageId Expected bundle-relative page id.
 * @param content Exact page bytes.
 * @returns Parsed Knowledge entry projection.
 * @throws Error when the file is not a valid owned page for the expected id.
 */
export function parseOwnedKnowledgeEntry(
  path: string,
  knowledgePageId: string,
  content: string
): KnowledgeEntry {
  const parsed = parseOkfDocument({ path, content });
  const id = parsed.document ? stringFrontmatterField(parsed.document, 'openkit_entry_id') : null;

  if (!parsed.ok || id !== knowledgePageId || parsed.document.conceptId !== knowledgePageId) {
    throw new Error(`Knowledge page ${knowledgePageId} is not a valid owned record.`);
  }

  const sourceReferences = stringListFrontmatterField(parsed.document, 'source_refs');
  if (parsed.document.frontmatter.source_refs !== undefined && sourceReferences === null) {
    throw new Error(`Knowledge page ${knowledgePageId} has invalid source_refs.`);
  }
  return KnowledgeEntrySchema.parse({
    id,
    kind: requiredFrontmatterString(parsed.document, 'openkit_entry_kind', path),
    title: requiredFrontmatterString(parsed.document, 'title', path),
    content: trimCanonicalMarkdownBody(parsed.document.body),
    ...(sourceReferences && sourceReferences.length > 0 ? { sourceReferences } : {}),
    createdAt: requiredFrontmatterString(parsed.document, 'created_at', path),
    updatedAt: requiredFrontmatterString(parsed.document, 'updated_at', path),
  });
}

/**
 * Compares two canonical KnowledgeEntry projections while normalizing absent empty sources.
 *
 * @param left First KnowledgeEntry projection.
 * @param right Second KnowledgeEntry projection.
 * @returns True when every authoritative protocol field is equal.
 */
export function knowledgeEntriesEqual(left: KnowledgeEntry, right: KnowledgeEntry): boolean {
  const leftReferences = left.sourceReferences ?? [];
  const rightReferences = right.sourceReferences ?? [];
  return (
    left.id === right.id &&
    left.kind === right.kind &&
    left.title === right.title &&
    left.content === right.content &&
    left.createdAt === right.createdAt &&
    left.updatedAt === right.updatedAt &&
    leftReferences.length === rightReferences.length &&
    leftReferences.every((reference, index) => reference === rightReferences[index])
  );
}

/**
 * Lists bundle-relative Knowledge Page ids without following directory links.
 *
 * @param pagesRoot Current canonical directory to inspect.
 * @param prefix Bundle-relative directory prefix.
 * @returns Sorted page ids below the directory.
 */
export function listKnowledgePageIds(pagesRoot: string, prefix = ''): string[] {
  const direct = listFileNames(pagesRoot)
    .filter((name) => name.endsWith('.md') && name !== 'index.md' && name !== 'log.md')
    .map((name) => `${prefix}${name.slice(0, -'.md'.length)}`);
  const nested = listDirectoryNames(pagesRoot).flatMap((name) =>
    listKnowledgePageIds(join(pagesRoot, name), `${prefix}${name}/`)
  );

  const ids = [...direct, ...nested].sort();
  for (const id of ids) {
    if (!KnowledgeProposalPageIdSchema.safeParse(id).success) {
      throw new Error(`Knowledge Page id is invalid: ${id}.`);
    }
  }
  return ids;
}

/**
 * Loads owned protocol knowledge pages.
 *
 * @param workspaceRoot Published workspace root.
 * @returns Knowledge entries in file-name order.
 */
function loadKnowledge(workspaceRoot: string): KnowledgeEntry[] {
  const pagesRoot = join(workspaceRoot, 'knowledge', 'pages');
  const entries: KnowledgeEntry[] = [];

  for (const knowledgePageId of listKnowledgePageIds(pagesRoot)) {
    const path = join(pagesRoot, `${knowledgePageId}.md`);
    const content = readCanonicalTextFile(path);
    const parsed = parseOkfDocument({ path, content });
    const id = parsed.document ? stringFrontmatterField(parsed.document, 'openkit_entry_id') : null;

    if (!id) {
      continue;
    }
    entries.push(parseOwnedKnowledgeEntry(path, knowledgePageId, content));
  }

  return entries;
}

/**
 * Serializes one immutable Knowledge Proposal owner without review state.
 *
 * @param proposal Proposal tuple to serialize.
 * @returns Exact canonical proposal-file bytes.
 */
export function serializeKnowledgeProposalRecord(proposal: KnowledgeProposalRecord): string {
  const retained = (
    proposal as KnowledgeProposalRecord & {
      [retainedProposal]?: { bytes: string; core: KnowledgeProposalRecord };
    }
  )[retainedProposal];
  if (retained && isDeepStrictEqual(retained.core, KnowledgeProposalRecordSchema.parse(proposal)))
    return retained.bytes;
  return [
    '---',
    'type: "proposal"',
    'operation: "create"',
    `knowledge_page_id: ${JSON.stringify(proposal.knowledgePageId)}`,
    `content_digest: ${JSON.stringify(proposal.contentDigest)}`,
    `source_references: ${JSON.stringify(proposal.sourceReferences)}`,
    `rationale: ${JSON.stringify(proposal.rationale)}`,
    `confidence: ${JSON.stringify(proposal.confidence)}`,
    'review_required: true',
    `producer: ${JSON.stringify(proposal.producer)}`,
    `created_at: ${JSON.stringify(proposal.createdAt)}`,
    '---',
    proposal.canonicalPageBytes,
  ].join('\n');
}

/**
 * Loads knowledge proposal Markdown records.
 *
 * @param workspaceRoot Published workspace root.
 * @param workspaceId Owning workspace id.
 * @returns Knowledge proposals in file-name order.
 */
function loadKnowledgeProposals(
  workspaceRoot: string,
  workspaceId: string
): KnowledgeProposalRecord[] {
  const root = join(workspaceRoot, 'knowledge', 'proposals');

  return listFileNames(root)
    .filter((name) => name.endsWith('.md'))
    .map((fileName) => {
      const path = join(root, fileName);
      const content = readCanonicalTextFile(path);
      const parsed = parseOkfDocument({ path, content });

      if (!parsed.ok) {
        throw new Error(`Knowledge proposal ${fileName} is invalid.`);
      }

      const id = fileName.slice(0, -'.md'.length);
      const sourceReferences = stringListFrontmatterField(parsed.document, 'source_references');
      const producerValue = parsed.document.frontmatter.producer;
      const confidenceValue = parsed.document.frontmatter.confidence;
      if (
        parsed.document.frontmatter.type !== 'proposal' ||
        parsed.document.frontmatter.operation !== 'create' ||
        parsed.document.frontmatter.review_required !== true ||
        sourceReferences === null ||
        typeof producerValue !== 'object' ||
        producerValue === null ||
        typeof confidenceValue !== 'number'
      ) {
        throw new Error(`Knowledge proposal ${id} has invalid immutable metadata.`);
      }

      const proposal = KnowledgeProposalRecordSchema.parse({
        id,
        workspaceId,
        operation: 'create',
        knowledgePageId: requiredFrontmatterString(parsed.document, 'knowledge_page_id', path),
        canonicalPageBytes: parsed.document.body,
        contentDigest: requiredFrontmatterString(parsed.document, 'content_digest', path),
        sourceReferences,
        rationale: requiredFrontmatterString(parsed.document, 'rationale', path),
        confidence: confidenceValue,
        producer: producerValue,
        createdAt: requiredFrontmatterString(parsed.document, 'created_at', path),
      });
      const candidateDigest = `sha256:${createHash('sha256')
        .update(proposal.canonicalPageBytes, 'utf8')
        .digest('hex')}`;
      if (proposal.contentDigest !== candidateDigest) {
        throw new Error(`Knowledge proposal ${id} does not preserve its canonical bytes.`);
      }
      Object.defineProperty(proposal, retainedProposal, {
        value: { bytes: content, core: structuredClone(proposal) },
      });
      return proposal;
    });
}

/**
 * Loads knowledge proposal review JSON records.
 *
 * @param workspaceRoot Published workspace root.
 * @param workspaceId Owning workspace id.
 * @param proposalsById Known proposals by id.
 * @returns Proposal reviews in file-name order.
 */
function loadKnowledgeProposalReviews(
  workspaceRoot: string,
  workspaceId: string,
  proposalsById: ReadonlyMap<string, KnowledgeProposalRecord>
): KnowledgeProposalReviewRecord[] {
  const root = join(workspaceRoot, 'knowledge', 'reviews');

  return listFileNames(root)
    .filter((name) => name.endsWith('.json'))
    .flatMap((fileName) => {
      const reviewFile = KnowledgeProposalReviewFileSchema.parse(readJson(join(root, fileName)));
      const proposal = proposalsById.get(reviewFile.proposalId);

      if (
        fileName !== `${reviewFile.proposalId}.json` ||
        reviewFile.workspaceId !== workspaceId ||
        !proposal
      ) {
        throw new Error(`Knowledge proposal review ${fileName} has invalid lineage.`);
      }

      const proposalDigest = `sha256:${createHash('sha256')
        .update(serializeKnowledgeProposalRecord(proposal), 'utf8')
        .digest('hex')}`;
      for (const review of reviewFile.decisions) {
        if (
          review.proposalDigest !== proposalDigest ||
          review.knowledgePageId !== proposal.knowledgePageId ||
          review.contentDigest !== proposal.contentDigest
        ) {
          throw new Error(`Knowledge proposal review ${review.reviewId} has invalid lineage.`);
        }
      }
      return reviewFile.decisions;
    });
}

/**
 * Loads knowledge source registry JSON records.
 *
 * @param workspaceRoot Published workspace root.
 * @param workspaceId Owning workspace id.
 * @param threadIds Known thread ids.
 * @param turnsById Known turns by id.
 * @returns Knowledge source records in file-name order.
 */
function loadKnowledgeSources(
  workspaceRoot: string,
  workspaceId: string,
  threadIds: ReadonlySet<string>,
  turnsById: ReadonlyMap<string, Turn>
): KnowledgeSourceRecord[] {
  const root = join(workspaceRoot, 'sources', 'registry');
  const sources = listFileNames(root)
    .filter((name) => name.endsWith('.json'))
    .map((fileName) => {
      const source = KnowledgeSourceRecordSchema.parse(readJson(join(root, fileName)));

      if (
        fileName !== `${source.id}.json` ||
        source.workspaceId !== workspaceId ||
        (source.originatingThreadId !== null && !threadIds.has(source.originatingThreadId)) ||
        (source.originatingTurnId !== null &&
          turnsById.get(source.originatingTurnId)?.threadId !== source.originatingThreadId)
      ) {
        throw new Error(`Knowledge source ${fileName} has invalid lineage.`);
      }

      return source;
    });

  const sourceIds = new Set(sources.map((source) => source.id));
  for (const ownedRoot of [
    join(workspaceRoot, 'sources', 'materials'),
    join(workspaceRoot, 'sources', 'derived'),
  ]) {
    for (const sourceId of listDirectoryNames(ownedRoot)) {
      if (!sourceIds.has(sourceId)) {
        throw new Error(`Source directory has no registry record: ${sourceId}.`);
      }
    }
  }

  return sources;
}

/**
 * Loads artifacts and reconstructs their content bodies.
 *
 * @param workspaceRoot Published workspace root.
 * @param workspaceId Owning workspace id.
 * @param threadIds Known thread ids.
 * @param turnsById Known turns by id.
 * @returns Artifacts in directory-name order.
 */
function loadArtifacts(
  workspaceRoot: string,
  workspaceId: string,
  threadIds: ReadonlySet<string>,
  turnsById: ReadonlyMap<string, Turn>
): Artifact[] {
  const root = join(workspaceRoot, 'artifacts');

  return listDirectoryNames(root).map((artifactId) => {
    const artifactRoot = join(root, artifactId);
    const metadataPath = join(artifactRoot, 'artifact.json');

    if (!existsSync(metadataPath)) {
      throw new Error(`Canonical artifact directory is missing artifact.json: ${artifactId}.`);
    }

    const metadata = readJson(metadataPath) as Record<string, unknown>;
    const metadataContent = metadata.content as { body?: unknown; format?: unknown } | undefined;
    const format = metadataContent?.format;

    if (metadataContent && Object.hasOwn(metadataContent, 'body')) {
      throw new Error(`Canonical artifact metadata must not embed content body: ${artifactId}.`);
    }

    if (format !== 'markdown' && format !== 'text' && format !== 'json' && format !== 'file') {
      throw new Error(`Artifact ${artifactId} has an invalid content format.`);
    }

    if (format !== 'file') assertCanonicalDirectory(join(artifactRoot, 'files'));
    const artifact = ArtifactReaderSchema.parse({
      ...metadata,
      content:
        format === 'file'
          ? metadataContent
          : {
              ...metadataContent,
              format,
              body: readCanonicalTextFile(
                join(artifactRoot, 'files', artifactContentFileName(format))
              ),
            },
    });
    if (artifact.content.format === 'file') {
      verifyArtifactFilePayload({
        workspaceRoot,
        artifactId: artifact.id,
        version: artifact.version,
        byteLength: artifact.content.byteLength,
        contentDigest: artifact.contentDigest,
      });
    }

    if (
      artifact.id !== artifactId ||
      artifact.workspaceId !== workspaceId ||
      (artifact.threadId !== null && !threadIds.has(artifact.threadId)) ||
      (artifact.turnId !== null && turnsById.get(artifact.turnId)?.threadId !== artifact.threadId)
    ) {
      throw new Error(`Artifact ${artifactId} has invalid lineage.`);
    }

    return artifact;
  });
}

/**
 * Loads durable AgentSession JSON records.
 *
 * @param workspaceRoot Published workspace root.
 * @param workspaceId Owning workspace id.
 * @param threadIds Known thread ids.
 * @returns AgentSessions in directory-name order.
 */
function loadAgentSessions(
  workspaceRoot: string,
  workspaceId: string,
  threadIds: ReadonlySet<string>
): AgentSession[] {
  const root = join(workspaceRoot, 'runtime', 'agent-sessions');

  return listDirectoryNames(root).map((sessionId) => {
    const sessionPath = join(root, sessionId, 'session.json');

    if (!existsSync(sessionPath)) {
      throw new Error(`Canonical AgentSession directory is missing session.json: ${sessionId}.`);
    }

    const session = AgentSessionRecordSchema.parse(readJson(sessionPath)) as AgentSession;

    if (
      session.id !== sessionId ||
      session.workspaceId !== workspaceId ||
      !session.threadId ||
      !threadIds.has(session.threadId)
    ) {
      throw new Error(`AgentSession ${sessionId} has invalid lineage.`);
    }

    return session;
  });
}

/**
 * Validates every record id used to derive a canonical file or directory path.
 *
 * @param records Workspace records about to be published.
 * @throws Error when an id is not a safe canonical owner path.
 */
function assertSafeWorkspaceFileRecordIds(records: WorkspaceFileRecords): void {
  assertSafeWorkspacePathSegment(records.workspace.id, 'Workspace id');
  for (const thread of records.threads) {
    assertSafeWorkspacePathSegment(thread.id, 'Thread id');
  }
  for (const turn of records.turns) {
    assertSafeWorkspacePathSegment(turn.id, 'Turn id');
    assertSafeWorkspacePathSegment(turn.threadId, 'Turn thread id');
    for (const item of turn.items) {
      assertSafeWorkspacePathSegment(item.id, 'Item id');
      assertSafeWorkspacePathSegment(item.threadId, 'Item thread id');
      assertSafeWorkspacePathSegment(item.turnId, 'Item turn id');
    }
  }
  for (const item of records.itemRevisions) {
    assertSafeWorkspacePathSegment(item.id, 'Item id');
    assertSafeWorkspacePathSegment(item.threadId, 'Item thread id');
    assertSafeWorkspacePathSegment(item.turnId, 'Item turn id');
  }
  for (const entry of records.knowledge) {
    for (const segment of KnowledgeProposalPageIdSchema.parse(entry.id).split('/')) {
      assertSafeWorkspacePathSegment(segment, 'Knowledge entry id segment');
    }
  }
  for (const proposal of records.knowledgeProposals) {
    assertSafeWorkspacePathSegment(proposal.id, 'Knowledge proposal id');
  }
  for (const review of records.knowledgeProposalReviews) {
    assertSafeWorkspacePathSegment(review.proposalId, 'Knowledge proposal review id');
  }
  for (const source of records.knowledgeSources) {
    assertSafeWorkspacePathSegment(source.id, 'Knowledge source id');
  }
  for (const artifact of records.artifacts) {
    assertSafeWorkspacePathSegment(artifact.id, 'Artifact id');
  }
  for (const session of records.agentSessions) {
    assertSafeWorkspacePathSegment(session.id, 'AgentSession id');
  }
}

/**
 * Rejects canonical directory parents that would redirect writes through a link.
 *
 * @param workspaceRoot Resolved workspace root.
 * @throws Error when an existing canonical directory parent is a link or non-directory.
 */
function assertExistingWorkspaceDirectoryParents(workspaceRoot: string): void {
  for (const path of [
    workspaceRoot,
    join(workspaceRoot, 'threads'),
    join(workspaceRoot, 'knowledge'),
    join(workspaceRoot, 'sources'),
    join(workspaceRoot, 'artifacts'),
    join(workspaceRoot, 'reviews'),
    join(workspaceRoot, 'runtime'),
    join(workspaceRoot, 'runtime', 'agent-sessions'),
  ]) {
    if (lstatSync(path, { throwIfNoEntry: false })) {
      assertCanonicalDirectory(path);
    }
  }
}

/** Classifies predecessor records from owned Quick Chat identity or formal Task/Goal inception lineage. */
function classifyThreadVisibilityCutover(
  dataRoot: string,
  workspaceRoot: string,
  kind: WorkspaceRecord['kind'],
  threadId: string
): Pick<Thread, 'visibility' | 'privateOwnerUserId'> {
  if (kind === 'quick-chat') {
    const workspaceId = basename(workspaceRoot);
    const candidates = new Set(listDirectoryNames(join(dataRoot, 'users')));
    if (existsSync(coreDbPath(dataRoot))) {
      const database = new Database(coreDbPath(dataRoot), { readonly: true, fileMustExist: true });
      try {
        for (const row of database.prepare('SELECT id FROM users').all() as Array<{ id: string }>)
          candidates.add(row.id);
      } finally {
        database.close();
      }
    }
    for (const userId of candidates) {
      if (isEntityId('usr', userId) && workspaceId === deriveEntityId('ws', ['quick_chat', userId]))
        return { visibility: 'private', privateOwnerUserId: userId };
    }
    throw new Error('Thread visibility cutover requires the canonical Quick Chat owner.');
  }
  const turnsRoot = join(workspaceRoot, 'threads', threadId, 'turns');
  const turns = listDirectoryNames(turnsRoot).map((id) =>
    TurnReaderSchema.parse({ ...(readJson(join(turnsRoot, id, 'turn.json')) as object), items: [] })
  );
  const firstTurn = turns.sort(
    (left, right) =>
      (left.startedAt ?? '').localeCompare(right.startedAt ?? '') || left.id.localeCompare(right.id)
  )[0];
  if (turns.length > 0 && turns.every((turn) => turn.agentId)) return { visibility: 'workspace' };
  if (!firstTurn?.startedAt || turns[1]?.startedAt === firstTurn.startedAt) {
    throw new Error(
      'Thread visibility cutover requires explicit classification of ambiguous project history.'
    );
  }
  if (firstTurn.agentId) return { visibility: 'workspace' };
  throw new Error(
    'Thread visibility cutover requires explicit classification of ambiguous project history.'
  );
}

/** Parses current audience-gated records or explicitly classifies a validated predecessor once. */
function parseCanonicalThreadRecord(
  input: unknown,
  workspaceId: string,
  threadId: string,
  classify: () => Pick<Thread, 'visibility' | 'privateOwnerUserId'>
): Thread {
  const raw = typeof input === 'object' && input !== null ? (input as Record<string, unknown>) : {};
  const enveloped = looksLikeThreadEnvelope(input);
  if (!enveloped && ('entryPath' in raw || 'visibility' in raw || 'privateOwnerUserId' in raw)) {
    throw new Error(`Thread metadata requires its canonical envelope: ${threadId}.`);
  }
  const envelope = enveloped
    ? parseRecordEnvelope(input, { supportedFeatures: THREAD_REQUIRED_FEATURES })
    : null;
  if (
    envelope &&
    (envelope.schemaVersion !== 1 ||
      envelope.recordType !== 'thread' ||
      envelope.ownerScope !== 'workspace' ||
      envelope.id !== threadId ||
      envelope.lineage.workspaceId !== workspaceId ||
      envelope.lineage.threadId !== threadId ||
      !envelope.requiredFeatures.includes(THREAD_ENTRY_REQUIRED_FEATURE))
  ) {
    throw new Error(`Canonical Thread envelope has invalid ownership or lineage: ${threadId}.`);
  }
  if (envelope?.requiredFeatures.includes(THREAD_VISIBILITY_REQUIRED_FEATURE)) {
    const thread = ThreadSchema.parse(input);
    if (envelope.contentDigest !== canonicalThreadContentDigest(thread))
      throw new Error(`Canonical Thread envelope content digest does not match: ${threadId}.`);
    return thread;
  }
  if ('visibility' in raw || 'privateOwnerUserId' in raw)
    throw new Error('Thread visibility requires its required feature.');
  // Validate predecessor fields and digest without audience authority; apply all Thread refinements after classification.
  const oldPayload = z
    .object(ThreadSchema.shape)
    .omit({ visibility: true, privateOwnerUserId: true })
    .parse({
      ...raw,
      entryPath: enveloped ? raw.entryPath : 'conversation',
    });
  if (
    envelope &&
    envelope.contentDigest !==
      `sha256:${createHash('sha256').update(JSON.stringify(oldPayload)).digest('hex')}`
  )
    throw new Error(`Canonical Thread envelope content digest does not match: ${threadId}.`);
  return ThreadSchema.parse({ ...oldPayload, ...classify() });
}

/** Projects one Thread into its authority-gated canonical record envelope. */
function projectCanonicalThreadRecord(
  threadInput: Thread,
  previous?: unknown
): Record<string, unknown> {
  const thread = ThreadSchema.parse(threadInput);
  let preserved: Record<string, unknown> = {};
  if (looksLikeThreadEnvelope(previous)) {
    preserved = parseRecordEnvelope(previous, {
      supportedFeatures: THREAD_REQUIRED_FEATURES,
    });
  }
  return {
    ...preserved,
    ...thread,
    schemaVersion: 1,
    recordType: 'thread',
    ownerScope: 'workspace',
    lineage: { workspaceId: thread.workspaceId, threadId: thread.id },
    contentDigest: canonicalThreadContentDigest(thread),
    redactionLevel: 'none',
    sensitivity: thread.visibility,
    requiredFeatures: THREAD_REQUIRED_FEATURES,
    extensions:
      typeof preserved.extensions === 'object' && preserved.extensions !== null
        ? preserved.extensions
        : {},
  };
}

/** Computes the stable content digest over the strict current Thread payload. */
function canonicalThreadContentDigest(thread: Thread): string {
  return `sha256:${createHash('sha256')
    .update(JSON.stringify(ThreadSchema.parse(thread)))
    .digest('hex')}`;
}

/** Returns whether a record claims any canonical envelope discriminator. */
function looksLikeThreadEnvelope(input: unknown): input is Record<string, unknown> {
  return (
    typeof input === 'object' &&
    input !== null &&
    ['schemaVersion', 'recordType', 'ownerScope', 'lineage', 'requiredFeatures'].some(
      (field) => field in input
    )
  );
}

/** Returns whether a record is an already gated canonical Thread envelope. */
function isCanonicalThreadEnvelope(input: unknown): boolean {
  return looksLikeThreadEnvelope(input);
}

/**
 * Publishes one absent record directory by renaming a same-filesystem staging directory.
 *
 * A crash before the rename leaves only `workspaces/.staging`, which the next load deletes.
 * Callers update an existing destination in place. This function does not delete a destination.
 *
 * @param workspaceRoot Resolved workspace root. Staging is created beside that root.
 * @param destination Absent canonical directory.
 * @param writeContents Writes the complete directory under the staging path.
 */
function publishNewRecordDirectory(
  workspaceRoot: string,
  destination: string,
  writeContents: (directory: string) => void
): void {
  const stagingRoot = join(dirname(workspaceRoot), '.staging', `record-${randomUUID()}`);
  const stagingParent = dirname(stagingRoot);

  mkdirSync(stagingParent, { recursive: true });
  assertCanonicalDirectory(stagingParent);
  try {
    mkdirSync(stagingRoot, { mode: 0o700 });
    assertCanonicalDirectory(stagingRoot);
    writeContents(stagingRoot);
    publishCanonicalPath(stagingRoot, destination);
  } catch (error) {
    rmSync(stagingRoot, { recursive: true, force: true });
    throw error;
  }
}

/**
 * Writes one Turn directory's metadata, item log, and optional event log.
 *
 * @param turnRoot Existing Turn directory, either canonical or staged.
 * @param turn Turn record to write.
 * @param records Workspace records that own the Turn's items and events.
 */
function writeTurnDirectory(turnRoot: string, turn: Turn, records: WorkspaceFileRecords): void {
  const itemsPath = join(turnRoot, 'items.jsonl');
  const eventsPath = join(turnRoot, 'runtime', 'events.jsonl');
  const runtimeRoot = dirname(eventsPath);

  ensureCanonicalDirectory(turnRoot);
  const turnPath = join(turnRoot, 'turn.json');
  const previousRaw = existsSync(turnPath)
    ? (readJson(turnPath) as Record<string, unknown>)
    : undefined;
  const previousCoverage =
    previousRaw?.captureCoverage === undefined
      ? undefined
      : CaptureCoverageBindingSchema.parse(previousRaw.captureCoverage);
  const nextCoverage = records.turnCaptureCoverage?.get(turn.id);
  if (
    previousCoverage !== undefined &&
    nextCoverage !== undefined &&
    !isDeepStrictEqual(previousCoverage, nextCoverage)
  ) {
    throw new Error(`Turn ${turn.id} capture coverage binding is recovery_required.`);
  }
  const captureCoverage = nextCoverage ?? previousCoverage;
  writeOwnedDescriptiveJson(
    turnPath,
    {
      ...turn,
      items: [],
      ...(captureCoverage ? { captureCoverage } : {}),
      ...(previousRaw?.requiredFeatures ? { requiredFeatures: previousRaw.requiredFeatures } : {}),
    },
    TurnReaderSchema.safeExtend({
      captureCoverage: CaptureCoverageBindingSchema.optional(),
      requiredFeatures: z.array(z.literal('openkit.work-observations.v1')).optional(),
    })
  );
  const revisions = records.itemRevisions.filter((item) => item.turnId === turn.id);
  const itemLogMetadata = lstatSync(itemsPath, { throwIfNoEntry: false });
  if (!itemLogMetadata) {
    writeFileAtomic(
      itemsPath,
      revisions.map((item) => JSON.stringify(item)).join('\n') + (revisions.length ? '\n' : '')
    );
  } else {
    assertCanonicalRegularFile(itemsPath);
  }
  ensureCanonicalDirectory(runtimeRoot);
  const eventLogMetadata = lstatSync(eventsPath, { throwIfNoEntry: false });
  if (!eventLogMetadata) {
    const events = records.streamEvents.find(([turnId]) => turnId === turn.id)?.[1] ?? [];
    if (events.length > 0) {
      writeFileAtomic(eventsPath, `${events.map((event) => JSON.stringify(event)).join('\n')}\n`);
    }
  } else {
    assertCanonicalRegularFile(eventsPath);
  }
}

/** Publishes one complete new file-backed Artifact directory through the existing P01 tree owner. The exact payload and descriptor are staged together, so process loss cannot expose a canonical directory with missing metadata. No reference Item or command receipt is written here. */
export function publishArtifactFileRecord(input: {
  readonly workspaceRoot: string;
  readonly artifact: Artifact;
  readonly payloadPath: string;
}): void {
  if (input.artifact.content.format !== 'file') throw new Error('A file descriptor is required.');
  const destination = artifactFilePayloadPath(
    input.workspaceRoot,
    input.artifact.id,
    input.artifact.version
  );
  const artifactRoot = join(input.workspaceRoot, 'artifacts', input.artifact.id);
  ensureCanonicalDirectory(dirname(artifactRoot));
  if (lstatSync(artifactRoot, { throwIfNoEntry: false }))
    throw new Error('The immutable Artifact already exists.');
  publishNewRecordDirectory(input.workspaceRoot, artifactRoot, (stage) => {
    const payload = join(stage, 'versions', String(input.artifact.version), 'payload');
    ensureCanonicalDirectory(dirname(payload));
    publishCanonicalPath(input.payloadPath, payload);
    writeArtifactDirectory(stage, input.artifact);
  });
  // Keep the path guard above coupled to the same immutable owner spelling.
  assertCanonicalRegularFile(destination);
}

/**
 * Writes one Artifact directory's metadata and body.
 *
 * @param artifactRoot Existing Artifact directory, either canonical or staged.
 * @param artifact Artifact record to write.
 */
function writeArtifactDirectory(artifactRoot: string, artifact: Artifact): void {
  if (artifact.content.format === 'file') {
    ensureCanonicalDirectory(artifactRoot);
    const payload = join(artifactRoot, 'versions', String(artifact.version), 'payload');
    assertCanonicalRegularFile(payload);
    if (lstatSync(payload).size !== artifact.content.byteLength) {
      throw new Error('The Artifact file payload length is inconsistent.');
    }
    writeOwnedDescriptiveJson(join(artifactRoot, 'artifact.json'), artifact, ArtifactReaderSchema);
    return;
  }
  const filesRoot = join(artifactRoot, 'files');
  const contentFileName = artifactContentFileName(artifact.content.format);

  ensureCanonicalDirectory(artifactRoot);
  ensureCanonicalDirectory(filesRoot);
  for (const staleFileName of ['content.md', 'content.txt', 'content.json']) {
    if (staleFileName !== contentFileName) {
      rmSync(join(filesRoot, staleFileName), { force: true });
    }
  }
  writeOwnedDescriptiveJson(
    join(artifactRoot, 'artifact.json'),
    {
      ...artifact,
      content: { format: artifact.content.format },
    },
    z.object({
      ...ArtifactReaderSchema.shape,
      content: z.union([
        ArtifactInlineContentSchema.omit({ body: true }),
        ArtifactFileContentSchema,
      ]),
    })
  );
  writeFileAtomic(join(filesRoot, contentFileName), artifact.content.body);
}

/**
 * Writes one new Thread directory, including `thread.json`, `turns/`, and every Turn.
 *
 * @param threadRoot Existing staging directory that will become the Thread directory.
 * @param thread Thread record to write.
 * @param threadTurns Turns that belong to this Thread.
 * @param records Workspace records that own those Turns.
 */
function writeStagedThreadDirectory(
  threadRoot: string,
  thread: Thread,
  threadTurns: readonly Turn[],
  records: WorkspaceFileRecords
): void {
  writeJsonAtomic(join(threadRoot, 'thread.json'), projectCanonicalThreadRecord(thread));
  const turnsRoot = join(threadRoot, 'turns');
  ensureCanonicalDirectory(turnsRoot);
  for (const turn of threadTurns) {
    writeTurnDirectory(join(turnsRoot, turn.id), turn, records);
  }
}

/**
 * Writes changed canonical Thread bytes and Turn metadata while preserving append-only logs.
 *
 * @param workspaceRoot Resolved workspace root.
 * @param records Current workspace records.
 */
function writeThreads(workspaceRoot: string, records: WorkspaceFileRecords): void {
  const root = join(workspaceRoot, 'threads');
  const expectedThreadIds = new Set(records.threads.map((thread) => thread.id));

  ensureCanonicalDirectory(root);
  removeStaleDirectories(root, expectedThreadIds);

  for (const thread of records.threads) {
    const threadRoot = join(root, thread.id);
    const turnsRoot = join(threadRoot, 'turns');
    const threadTurns = records.turns.filter((turn) => turn.threadId === thread.id);
    const expectedTurnIds = new Set(threadTurns.map((turn) => turn.id));

    if (!lstatSync(threadRoot, { throwIfNoEntry: false })) {
      publishNewRecordDirectory(workspaceRoot, threadRoot, (stage) => {
        writeStagedThreadDirectory(stage, thread, threadTurns, records);
      });
      continue;
    }
    ensureCanonicalDirectory(threadRoot);
    // Preparing turnsRoot also commits threadRoot after an unacknowledged file rename.
    ensureCanonicalDirectory(turnsRoot);
    const threadPath = join(threadRoot, 'thread.json');
    const previousBytes = existsSync(threadPath) ? readCanonicalFile(threadPath) : undefined;
    const previous =
      previousBytes === undefined ? undefined : JSON.parse(previousBytes.toString('utf8'));
    removeStaleDirectories(turnsRoot, expectedTurnIds);

    for (const turn of threadTurns) {
      const turnRoot = join(turnsRoot, turn.id);
      if (lstatSync(turnRoot, { throwIfNoEntry: false })) {
        writeTurnDirectory(turnRoot, turn, records);
        continue;
      }
      publishNewRecordDirectory(workspaceRoot, turnRoot, (stage) => {
        writeTurnDirectory(stage, turn, records);
      });
    }
    const nextBytes = Buffer.from(
      `${JSON.stringify(projectCanonicalThreadRecord(thread, previous), null, 2)}\n`
    );
    if (!previousBytes?.equals(nextBytes)) writeFileAtomic(threadPath, nextBytes);
  }
}

/**
 * Serializes one direct user-authored Knowledge Page into its canonical bytes.
 *
 * @param entry Knowledge entry projection to serialize.
 * @returns Exact canonical Markdown bytes written to the Knowledge Store.
 */
export function serializeUserAuthoredKnowledgePage(entry: KnowledgeEntry): string {
  return [
    '---',
    'type: "KnowledgePage"',
    `title: ${JSON.stringify(entry.title)}`,
    `schema_version: ${JSON.stringify(DEFAULT_WORKSPACE_KNOWLEDGE_SCHEMA_VERSION)}`,
    'openkit_status: "active"',
    'status: "stable"',
    'scope: "workspace"',
    `source_refs: ${JSON.stringify(entry.sourceReferences ?? [])}`,
    'review_state: "user-authored"',
    'sensitivity: "normal"',
    'freshness: "current"',
    `openkit_entry_kind: ${JSON.stringify(entry.kind)}`,
    `created_at: ${JSON.stringify(entry.createdAt)}`,
    `updated_at: ${JSON.stringify(entry.updatedAt)}`,
    `openkit_entry_id: ${JSON.stringify(entry.id)}`,
    '---',
    entry.content,
    '',
  ].join('\n');
}

/**
 * Produces final direct-edit bytes while retaining metadata outside the managed edit fields.
 *
 * @param path Canonical page path used for YAML diagnostics.
 * @param content Current exact Knowledge Page bytes.
 * @param entry Updated protocol projection.
 * @returns One final candidate byte sequence for validation and persistence.
 */
export function updateUserAuthoredKnowledgePage(
  path: string,
  content: string,
  entry: KnowledgeEntry
): string {
  return updateOkfFrontmatter({
    path,
    content,
    updates: {
      title: entry.title,
      review_state: 'user-authored',
      updated_at: entry.updatedAt,
    },
    body: `${entry.content}\n`,
  });
}

/**
 * Writes owned knowledge pages, proposals, and reviews.
 *
 * @param workspaceRoot Resolved workspace root.
 * @param records Current workspace records.
 * @param exactKnowledgePageBytes Final validated direct-edit bytes keyed by Page id.
 */
function writeKnowledge(
  workspaceRoot: string,
  records: WorkspaceFileRecords,
  exactKnowledgePageBytes: ReadonlyMap<string, string>
): void {
  const schemaRoot = join(workspaceRoot, 'knowledge', 'schema');
  const pagesRoot = join(workspaceRoot, 'knowledge', 'pages');
  const proposalsRoot = join(workspaceRoot, 'knowledge', 'proposals');
  const reviewsRoot = join(workspaceRoot, 'knowledge', 'reviews');
  const expectedPages = new Set(records.knowledge.map((entry) => entry.id));
  const expectedProposals = new Set(records.knowledgeProposals.map((record) => `${record.id}.md`));
  const expectedReviews = new Set(
    records.knowledgeProposalReviews.map((record) => `${record.proposalId}.json`)
  );
  const proposalsById = new Map(records.knowledgeProposals.map((record) => [record.id, record]));
  const acceptedProposalByPage = new Map<string, KnowledgeProposalRecord>();
  const reviewsByProposal = new Map<string, KnowledgeProposalReviewRecord[]>();

  for (const review of records.knowledgeProposalReviews) {
    reviewsByProposal.set(review.proposalId, [
      ...(reviewsByProposal.get(review.proposalId) ?? []),
      review,
    ]);
    if (review.decision === 'accepted') {
      const proposal = proposalsById.get(review.proposalId);
      if (proposal) {
        acceptedProposalByPage.set(proposal.knowledgePageId, proposal);
      }
    }
  }

  ensureCanonicalDirectory(schemaRoot);
  ensureCanonicalDirectory(pagesRoot);
  ensureCanonicalDirectory(proposalsRoot);
  ensureCanonicalDirectory(reviewsRoot);
  const schemaPath = join(schemaRoot, 'workspace-schema.yaml');
  const schemaMetadata = lstatSync(schemaPath, { throwIfNoEntry: false });

  if (schemaMetadata) {
    assertCanonicalRegularFile(schemaPath);
  } else {
    writeFileAtomic(schemaPath, DEFAULT_WORKSPACE_KNOWLEDGE_SCHEMA_TEXT);
  }

  removeStaleFiles(proposalsRoot, expectedProposals, '.md');
  const existingProposals = new Map(
    loadKnowledgeProposals(workspaceRoot, records.workspace.id).map((proposal) => [
      proposal.id,
      proposal,
    ])
  );
  for (const proposal of records.knowledgeProposals) {
    const previous = existingProposals.get(proposal.id);
    if (previous) {
      if (
        !isDeepStrictEqual(
          KnowledgeProposalRecordSchema.parse(previous),
          KnowledgeProposalRecordSchema.parse(proposal)
        )
      )
        throw new Error(`Knowledge proposal ${proposal.id} changed immutable content.`);
      continue;
    }
    writeFileAtomic(
      join(proposalsRoot, `${proposal.id}.md`),
      serializeKnowledgeProposalRecord(proposal)
    );
  }

  removeStaleFiles(reviewsRoot, expectedReviews, '.json');
  for (const [proposalId, decisions] of reviewsByProposal) {
    writeOwnedDescriptiveJson(
      join(reviewsRoot, `${proposalId}.json`),
      { proposalId, workspaceId: decisions[0]!.workspaceId, decisions },
      KnowledgeProposalReviewFileSchema
    );
  }

  for (const knowledgePageId of listKnowledgePageIds(pagesRoot)) {
    if (expectedPages.has(knowledgePageId)) {
      continue;
    }
    const path = join(pagesRoot, `${knowledgePageId}.md`);
    const parsed = parseOkfDocument({ path, content: readCanonicalTextFile(path) });
    if (parsed.document && stringFrontmatterField(parsed.document, 'openkit_entry_id')) {
      deleteWorkspaceKnowledgeRecord(workspaceRoot, knowledgePageId);
    }
  }

  for (const entry of records.knowledge) {
    const exactContent = exactKnowledgePageBytes.get(entry.id);
    const path = resolveWorkspaceKnowledgePagePath(workspaceRoot, entry.id, true);
    if (!path) {
      throw new Error(`Knowledge Page parent could not be created: ${entry.id}.`);
    }
    if (exactContent !== undefined) {
      writeFileAtomic(path, exactContent);
      continue;
    }

    const proposal = acceptedProposalByPage.get(entry.id);
    const currentPageBytes = readWorkspaceKnowledgePage(workspaceRoot, entry.id);
    let currentEntry: KnowledgeEntry | null = null;
    if (currentPageBytes !== null) {
      try {
        currentEntry = parseOwnedKnowledgeEntry(
          `knowledge/pages/${entry.id}.md`,
          entry.id,
          currentPageBytes
        );
      } catch {
        currentEntry = null;
      }
    }
    const proposalEntry = proposal
      ? parseOwnedKnowledgeEntry(
          `knowledge/pages/${proposal.knowledgePageId}.md`,
          proposal.knowledgePageId,
          proposal.canonicalPageBytes
        )
      : null;
    const content =
      currentEntry && knowledgeEntriesEqual(currentEntry, entry)
        ? currentPageBytes!
        : proposalEntry && knowledgeEntriesEqual(proposalEntry, entry) && currentPageBytes === null
          ? proposal!.canonicalPageBytes
          : serializeUserAuthoredKnowledgePage(entry);
    writeFileAtomic(path, content);
  }
}

/** Normalizes a Proposal without losing its already verified immutable source bytes. */
function parseRetainedKnowledgeProposal(value: unknown): KnowledgeProposalRecord {
  const proposal = KnowledgeProposalRecordSchema.parse(value);
  if (typeof value === 'object' && value !== null) {
    const retained = (value as { [retainedProposal]?: unknown })[retainedProposal];
    if (retained) Object.defineProperty(proposal, retainedProposal, { value: retained });
  }
  return proposal;
}

/** Ensures the bundle-root v0.2 index without maintaining human-authored navigation. */
function ensureRootKnowledgeIndex(pagesRoot: string): void {
  const path = join(pagesRoot, 'index.md');
  const metadata = lstatSync(path, { throwIfNoEntry: false });
  if (!metadata) {
    const links = [
      ...listFileNames(pagesRoot)
        .filter((name) => name.endsWith('.md') && name !== 'index.md' && name !== 'log.md')
        .map((name) => [name.slice(0, -3), name] as const),
      ...listDirectoryNames(pagesRoot).map((name) => [name, `${name}/`] as const),
    ].map(
      ([title, target]) =>
        `* [${title.replaceAll('\\', '\\\\').replaceAll('[', '\\[').replaceAll(']', '\\]')}](<${encodeURI(target)}>)`
    );
    writeFileAtomic(
      path,
      `---\nokf_version: "0.2"\n---\n# Knowledge${links.length > 0 ? `\n\n${links.join('\n')}` : ''}\n`
    );
    return;
  }
  assertCanonicalRegularFile(path);
  const content = readCanonicalTextFile(path);
  if (!content.startsWith('---')) {
    const candidate = `---\nokf_version: "0.2"\n---\n${content}`;
    if (!parseOkfDocument({ path: 'knowledge/pages/index.md', content: candidate }).ok) {
      throw new Error('Knowledge bundle root index body is invalid.');
    }
    writeFileAtomic(path, candidate);
    return;
  }
  const parsed = parseOkfDocument({ path: 'knowledge/pages/index.md', content });
  if (!parsed.ok || parsed.document.frontmatter.okf_version !== '0.2') {
    throw new Error('Knowledge bundle root index must declare okf_version "0.2".');
  }
}

/**
 * Writes source registry records and removes stale owned source directories.
 *
 * @param workspaceRoot Resolved workspace root.
 * @param records Current workspace records.
 */
function writeSources(workspaceRoot: string, records: WorkspaceFileRecords): void {
  const registryRoot = join(workspaceRoot, 'sources', 'registry');
  const materialsRoot = join(workspaceRoot, 'sources', 'materials');
  const derivedRoot = join(workspaceRoot, 'sources', 'derived');
  const expectedFiles = new Set(records.knowledgeSources.map((source) => `${source.id}.json`));
  const expectedIds = new Set(records.knowledgeSources.map((source) => source.id));

  ensureCanonicalDirectory(registryRoot);
  ensureCanonicalDirectory(materialsRoot);
  ensureCanonicalDirectory(derivedRoot);
  removeStaleFiles(registryRoot, expectedFiles, '.json');
  removeStaleDirectories(materialsRoot, expectedIds);
  removeStaleDirectories(derivedRoot, expectedIds);
  for (const source of records.knowledgeSources) {
    writeOwnedDescriptiveJson(
      join(registryRoot, `${source.id}.json`),
      source,
      KnowledgeSourceRecordSchema
    );
  }
}

/**
 * Writes artifact metadata and bodies.
 *
 * @param workspaceRoot Resolved workspace root.
 * @param records Current workspace records.
 */
function writeArtifacts(workspaceRoot: string, records: WorkspaceFileRecords): void {
  const artifactsRoot = join(workspaceRoot, 'artifacts');
  const expectedArtifactIds = new Set(records.artifacts.map((artifact) => artifact.id));

  ensureCanonicalDirectory(artifactsRoot);
  removeStaleDirectories(artifactsRoot, expectedArtifactIds);

  for (const artifact of records.artifacts) {
    const artifactRoot = join(artifactsRoot, artifact.id);
    if (lstatSync(artifactRoot, { throwIfNoEntry: false })) {
      writeArtifactDirectory(artifactRoot, artifact);
      continue;
    }
    publishNewRecordDirectory(workspaceRoot, artifactRoot, (stage) => {
      writeArtifactDirectory(stage, artifact);
    });
  }
}

/**
 * Writes durable AgentSession records and removes stale session directories.
 *
 * @param workspaceRoot Resolved workspace root.
 * @param records Current workspace records.
 */
function writeAgentSessions(workspaceRoot: string, records: WorkspaceFileRecords): void {
  const root = join(workspaceRoot, 'runtime', 'agent-sessions');
  const expectedIds = new Set(records.agentSessions.map((session) => session.id));

  ensureCanonicalDirectory(root);
  removeStaleDirectories(root, expectedIds);
  for (const session of records.agentSessions) {
    const sessionRoot = join(root, session.id);
    if (lstatSync(sessionRoot, { throwIfNoEntry: false })) {
      ensureCanonicalDirectory(sessionRoot);
      writeOwnedDescriptiveJson(
        join(sessionRoot, 'session.json'),
        session,
        AgentSessionRecordSchema
      );
      continue;
    }
    publishNewRecordDirectory(workspaceRoot, sessionRoot, (stage) => {
      ensureCanonicalDirectory(stage);
      writeOwnedDescriptiveJson(join(stage, 'session.json'), session, AgentSessionRecordSchema);
    });
  }
}

/**
 * Returns the canonical content file for one artifact format.
 *
 * @param format Artifact content format.
 * @returns Artifact content file name.
 */
export function artifactContentFileName(format: Artifact['content']['format']): string {
  return format === 'markdown' ? 'content.md' : format === 'text' ? 'content.txt' : 'content.json';
}

/**
 * Reads one JSON file.
 *
 * @param path JSON file path.
 * @returns Parsed JSON value.
 */
function readJson(path: string): unknown {
  return JSON.parse(readCanonicalTextFile(path)) as unknown;
}

/**
 * Reads canonical JSONL rows without repairing an incomplete tail or appending a newline.
 *
 * @param path JSONL file path.
 * @returns Parsed completed rows.
 * @throws Error when a newline-terminated row is malformed.
 */
function readDurableCanonicalJsonLines(path: string): unknown[] {
  const content = readCanonicalFile(path);
  const values: unknown[] = [];
  let rowStart = 0;
  for (let index = 0; index < content.length; index += 1) {
    if (content[index] !== 0x0a) continue;
    const row = content.subarray(rowStart, index);
    if (row.length > 0) {
      values.push(JSON.parse(row.toString('utf8')) as unknown);
    }
    rowStart = index + 1;
  }
  if (rowStart < content.length) {
    const finalRowText = content.subarray(rowStart).toString('utf8');
    try {
      values.push(JSON.parse(finalRowText) as unknown);
    } catch (error) {
      if (!isIncompleteJsonFragment(error, finalRowText)) {
        throw error;
      }
    }
  }
  return values;
}

/**
 * Reads non-empty JSONL rows from one optional file.
 *
 * @param path JSONL file path.
 * @param repairFinalFragment Whether to drop one syntactically incomplete final fragment.
 * @returns Parsed row values.
 */
export function readCanonicalJsonLines(path: string, repairFinalFragment = false): unknown[] {
  const metadata = lstatSync(path, { throwIfNoEntry: false });

  if (!metadata) {
    return [];
  }

  const content = readCanonicalFile(path);
  const values: unknown[] = [];
  let rowStart = 0;

  for (let index = 0; index < content.length; index += 1) {
    if (content[index] !== 0x0a) {
      continue;
    }
    const row = content.subarray(rowStart, index);
    if (row.length > 0) {
      values.push(JSON.parse(row.toString('utf8')) as unknown);
    }
    rowStart = index + 1;
  }

  if (rowStart < content.length) {
    const finalRow = content.subarray(rowStart);
    const finalRowText = finalRow.toString('utf8');
    try {
      values.push(JSON.parse(finalRowText) as unknown);
    } catch (error) {
      if (!repairFinalFragment || !isIncompleteJsonFragment(error, finalRowText)) {
        throw error;
      }
      writeFileAtomic(path, content.subarray(0, rowStart));
      return values;
    }

    if (repairFinalFragment) {
      writeFileAtomic(path, Buffer.concat([content, Buffer.from('\n')]));
    }
  }

  return values;
}

/**
 * Distinguishes an interrupted JSON tail from a complete malformed token.
 *
 * @param error JSON parser error.
 * @param fragment Unterminated final row text.
 * @returns True only when parsing stopped at the physical end of the fragment.
 */
function isIncompleteJsonFragment(error: unknown, fragment: string): boolean {
  if (!(error instanceof SyntaxError)) {
    return false;
  }
  if (/unexpected end|unterminated/i.test(error.message)) {
    return true;
  }
  const position = /position (\d+)/i.exec(error.message)?.[1];
  return position !== undefined && Number(position) >= fragment.length;
}

/**
 * Ensures an existing append log ends at a complete newline-delimited record.
 *
 * @param path Canonical append-log path.
 */
function normalizeAppendBoundary(path: string): void {
  const metadata = lstatSync(path, { throwIfNoEntry: false });

  if (!metadata) {
    return;
  }

  assertCanonicalRegularFile(path);
  const descriptor = openSync(
    path,
    constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK
  );
  let incomplete = false;
  try {
    const current = fstatSync(descriptor);
    if (!current.isFile()) throw new Error(`Canonical path must be a regular file: ${path}.`);
    // Completed logs need only their last byte; full parsing is reserved for tail recovery.
    if (current.size > 0) {
      const tail = Buffer.allocUnsafe(1);
      if (readSync(descriptor, tail, 0, 1, current.size - 1) !== 1)
        throw new Error(`Canonical append boundary could not be read: ${path}.`);
      incomplete = tail[0] !== 0x0a;
    }
  } finally {
    closeSync(descriptor);
  }
  if (incomplete) {
    readCanonicalJsonLines(path, true);
  }
}

/**
 * Appends canonical text without following a symbolic-link target.
 *
 * @param path Target append-log path.
 * @param content Complete text to append.
 */
export function appendCanonicalTextFile(path: string, content: string): void {
  const bytes = Buffer.from(content);
  const reservation = reserveCanonicalFileWrite(bytes.byteLength);
  let descriptor: number | undefined;
  let safeToRelease = true;
  try {
    normalizeAppendBoundary(path);
    const metadata = lstatSync(path, { throwIfNoEntry: false });
    if (metadata) assertCanonicalRegularFile(path);
    try {
      descriptor = openSync(
        path,
        constants.O_WRONLY |
          constants.O_APPEND |
          constants.O_CREAT |
          constants.O_NOFOLLOW |
          constants.O_NONBLOCK,
        0o600
      );
    } catch (error) {
      throwCanonicalLinkError(path, error);
    }
    safeToRelease = false;
    if (!fstatSync(descriptor).isFile())
      throw new Error(`Canonical path must be a regular file: ${path}.`);
    let offset = 0;
    while (offset < bytes.length) {
      const written = writeSync(descriptor, bytes, offset, bytes.length - offset);
      if (written <= 0) throw new Error(`Canonical append made no progress: ${path}.`);
      reservation?.recordWritten(written);
      offset += written;
    }
    fsyncSync(descriptor);
    closeSync(descriptor);
    descriptor = undefined;
    syncCanonicalDirectory(dirname(path));
    reservation?.assertAvailable();
    safeToRelease = true;
  } finally {
    try {
      if (descriptor !== undefined) closeSync(descriptor);
    } finally {
      if (safeToRelease) reservation?.release();
    }
  }
}

/**
 * Writes text through a same-directory temporary file and atomic rename.
 *
 * @param path Target file path.
 * @param content Complete file content.
 * @param mode Exact replacement mode when supplied; otherwise the private writer default.
 */
export function writeFileAtomic(path: string, content: string | Uint8Array, mode?: number): void {
  const byteLength = typeof content === 'string' ? Buffer.byteLength(content) : content.byteLength;
  const reservation = reserveCanonicalFileWrite(byteLength);
  const temporaryPath = join(dirname(path), `.${basename(path)}.${randomUUID()}.tmp`);
  let safeToRelease = false;
  let attemptedOpen = false;
  let temporaryOwned = false;
  try {
    ensureCanonicalDirectory(dirname(path), 0o777);
    if (lstatSync(path, { throwIfNoEntry: false })) assertCanonicalRegularFile(path);
    attemptedOpen = true;
    const descriptor = openSync(
      temporaryPath,
      constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW,
      mode ?? 0o600
    );
    temporaryOwned = true;
    try {
      writeFileSync(descriptor, content);
      reservation?.recordWritten(byteLength);
      if (mode !== undefined) fchmodSync(descriptor, mode);
      fsyncSync(descriptor);
    } finally {
      closeSync(descriptor);
    }
    renameSync(temporaryPath, path);
    syncCanonicalDirectory(dirname(path));
    reservation?.assertAvailable();
    safeToRelease = true;
  } catch (error) {
    if (temporaryOwned) {
      rmSync(temporaryPath, { force: true });
      safeToRelease = true;
    } else {
      // A refused path caused no effect.
      // A failed exclusive open has no ownership proof; retain capacity and preserve the unowned file.
      safeToRelease = !attemptedOpen;
    }
    throw error;
  } finally {
    if (safeToRelease) reservation?.release();
  }
}

/** Measures one regular file's exact size and digest without materializing its body. */
export function measureCanonicalFile(path: string): { byteLength: number; contentDigest: string } {
  const descriptor = openSync(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    return measureCanonicalFileDescriptor(descriptor);
  } finally {
    closeSync(descriptor);
  }
}

/** Measures an open no-follow regular file while preserving its offset for a later stream. */
export function measureCanonicalFileDescriptor(descriptor: number): {
  byteLength: number;
  contentDigest: string;
} {
  const before = fstatSync(descriptor, { bigint: true });
  if (!before.isFile() || before.size > BigInt(Number.MAX_SAFE_INTEGER)) {
    throw new Error('The canonical file cannot be measured.');
  }
  const hash = createHash('sha256');
  const buffer = Buffer.allocUnsafe(65_536);
  let byteLength = 0;
  while (byteLength < Number(before.size)) {
    const count = readSync(
      descriptor,
      buffer,
      0,
      Math.min(buffer.byteLength, Number(before.size) - byteLength),
      byteLength
    );
    if (count === 0) break;
    byteLength += count;
    hash.update(buffer.subarray(0, count));
  }
  const after = fstatSync(descriptor, { bigint: true });
  if (
    BigInt(byteLength) !== before.size ||
    before.size !== after.size ||
    before.mtimeNs !== after.mtimeNs ||
    before.ctimeNs !== after.ctimeNs
  ) {
    throw new Error('The canonical file changed during integrity verification.');
  }
  return { byteLength, contentDigest: `sha256:${hash.digest('hex')}` };
}

/** Preserves owned annotations while replacing known fields; append-order arrays retain their member annotations. */
export function preserveDescriptiveRecord(raw: unknown, previous: unknown, next: unknown): unknown {
  if (Array.isArray(next)) {
    return next.map((value, index) =>
      preserveDescriptiveRecord(
        Array.isArray(raw) ? raw[index] : undefined,
        Array.isArray(previous) ? previous[index] : undefined,
        value
      )
    );
  }
  if (
    typeof next !== 'object' ||
    next === null ||
    typeof raw !== 'object' ||
    raw === null ||
    Array.isArray(raw) ||
    typeof previous !== 'object' ||
    previous === null ||
    Array.isArray(previous)
  )
    return next;
  const old = previous as Record<string, unknown>;
  const replacement = next as Record<string, unknown>;
  if (['kind', 'type', 'id'].some((key) => old[key] !== undefined && old[key] !== replacement[key]))
    return next;
  const retained = { ...raw } as Record<string, unknown>;
  for (const key of Object.keys(old)) delete retained[key];
  for (const [key, value] of Object.entries(replacement))
    Object.defineProperty(retained, key, {
      value: preserveDescriptiveRecord((raw as Record<string, unknown>)[key], old[key], value),
      enumerable: true,
      writable: true,
      configurable: true,
    });
  return retained;
}

/** Validates an existing owned record before preserving annotations on its normal rewrite. */
function writeOwnedDescriptiveJson(path: string, next: unknown, schema: z.ZodType): void {
  const previous = existsSync(path) ? readJson(path) : undefined;
  const core = schema.parse(next);
  const oldCore = previous === undefined ? undefined : schema.parse(previous);
  if (previous !== undefined && isDeepStrictEqual(oldCore, core)) return;
  writeJsonAtomic(path, preserveDescriptiveRecord(previous, oldCore, core));
}

/**
 * Writes formatted JSON through an atomic same-directory rename.
 *
 * @param path Target JSON path.
 * @param value JSON-compatible record.
 */
function writeJsonAtomic(path: string, value: unknown): void {
  writeFileAtomic(path, `${JSON.stringify(value, null, 2)}\n`);
}

/**
 * Lists direct child directory names in stable order.
 *
 * @param path Parent path.
 * @returns Sorted directory names.
 */
function listDirectoryNames(path: string): string[] {
  const metadata = lstatSync(path, { throwIfNoEntry: false });

  if (!metadata) {
    return [];
  }
  assertCanonicalDirectory(path);

  const names: string[] = [];
  for (const entry of readdirSync(path, { withFileTypes: true })) {
    if (entry.isSymbolicLink()) {
      throw new Error(
        `Canonical directory must not contain a symbolic link: ${join(path, entry.name)}.`
      );
    }
    if (entry.isDirectory()) {
      names.push(entry.name);
    }
  }
  return names.sort();
}

/**
 * Lists direct child file names in stable order.
 *
 * @param path Parent path.
 * @returns Sorted file names.
 */
function listFileNames(path: string): string[] {
  const metadata = lstatSync(path, { throwIfNoEntry: false });

  if (!metadata) {
    return [];
  }
  assertCanonicalDirectory(path);

  const names: string[] = [];
  for (const entry of readdirSync(path, { withFileTypes: true })) {
    if (entry.isSymbolicLink()) {
      throw new Error(
        `Canonical directory must not contain a symbolic link: ${join(path, entry.name)}.`
      );
    }
    if (entry.isFile()) {
      names.push(entry.name);
    }
  }
  return names.sort();
}

/**
 * Verifies that one canonical path is a regular file rather than a link.
 *
 * @param path Canonical file path.
 * @throws Error when the path is a symbolic link or not a regular file.
 */
function assertCanonicalRegularFile(path: string): void {
  const metadata = lstatSync(path);

  if (metadata.isSymbolicLink()) {
    throw new Error(`Canonical path must not be a symbolic link: ${path}.`);
  }
  if (!metadata.isFile()) {
    throw new Error(`Canonical path must be a regular file: ${path}.`);
  }
}

/**
 * Verifies that one canonical path is a real directory rather than a link.
 *
 * @param path Canonical directory path.
 * @throws Error when the path is a symbolic link or not a directory.
 */
export function assertCanonicalDirectory(path: string): void {
  const metadata = lstatSync(path);

  if (metadata.isSymbolicLink()) {
    throw new Error(`Canonical path must not be a symbolic link: ${path}.`);
  }
  if (!metadata.isDirectory()) {
    throw new Error(`Canonical path must be a directory: ${path}.`);
  }
}

/**
 * Creates a canonical directory and any missing parents without an existing redirect.
 *
 * @param path Canonical directory path beneath the caller's validated boundary.
 * @param mode Creation permissions, subject to the process umask.
 * @throws Error when the existing or created path is not a real directory.
 */
export function ensureCanonicalDirectory(path: string, mode = 0o700): void {
  const metadata = lstatSync(path, { throwIfNoEntry: false });

  if (metadata) {
    assertCanonicalDirectory(path);
    syncCanonicalDirectory(dirname(path));
    return;
  }

  // A visible parent can remain after its creation was not durably acknowledged.
  ensureCanonicalDirectory(dirname(path), mode);
  assertCanonicalDirectory(dirname(path));
  mkdirSync(path, { mode });
  assertCanonicalDirectory(path);
  syncCanonicalDirectory(dirname(path));
}

/** Synchronizes a verified directory entry before acknowledging publication. */
export function syncCanonicalDirectory(path: string): void {
  assertCanonicalDirectory(path);
  const descriptor = openSync(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    fsyncSync(descriptor);
  } finally {
    closeSync(descriptor);
  }
}

/** Synchronizes complete staged bytes and child entries before their containing tree is published. */
export function syncCanonicalTree(path: string): void {
  const metadata = lstatSync(path);
  if (metadata.isDirectory()) {
    for (const entry of readdirSync(path)) syncCanonicalTree(join(path, entry));
    syncCanonicalDirectory(path);
    return;
  }
  assertCanonicalRegularFile(path);
  const descriptor = openSync(
    path,
    constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK
  );
  try {
    if (!fstatSync(descriptor).isFile())
      throw new Error(`Canonical path must be a regular file: ${path}.`);
    fsyncSync(descriptor);
  } finally {
    closeSync(descriptor);
  }
}

/** Publishes a complete staged file or tree and commits both sides of a cross-parent rename. */
export function publishCanonicalPath(staged: string, destination: string): void {
  syncCanonicalTree(staged);
  renameSync(staged, destination);
  syncCanonicalDirectory(dirname(destination));
  if (dirname(staged) !== dirname(destination)) syncCanonicalDirectory(dirname(staged));
}

/** Synchronizes one directory without blocking asynchronous file collection or following a link. */
export async function syncCanonicalDirectoryAsync(path: string): Promise<void> {
  const descriptor = await fsPromises.open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    if (!(await descriptor.stat()).isDirectory())
      throw new Error(`Canonical path must be a directory: ${path}.`);
    await descriptor.sync();
  } finally {
    await descriptor.close();
  }
}

/** Creates missing asynchronous publication parents and commits their entries before use. */
export async function ensureCanonicalDirectoryAsync(path: string): Promise<void> {
  const metadata = await fsPromises.lstat(path).catch((error: NodeJS.ErrnoException) => {
    if (error.code === 'ENOENT') return null;
    throw error;
  });
  if (!metadata) {
    // Commit each parent before creating children so a failed retry has one entry to verify.
    await ensureCanonicalDirectoryAsync(dirname(path));
    try {
      await fsPromises.mkdir(path);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'EEXIST') throw error;
    }
  }
  const current = metadata ?? (await fsPromises.lstat(path));
  if (!current.isDirectory() || current.isSymbolicLink())
    throw new Error(`Canonical path must be a directory: ${path}.`);
  await syncCanonicalDirectoryAsync(dirname(path));
}

/** Synchronizes a complete asynchronous staging tree, with child entries committed before their parents. */
export async function syncCanonicalTreeAsync(path: string): Promise<void> {
  const metadata = await fsPromises.lstat(path);
  if (metadata.isDirectory()) {
    for (const entry of await fsPromises.readdir(path))
      await syncCanonicalTreeAsync(join(path, entry));
    await syncCanonicalDirectoryAsync(path);
    return;
  }
  if (!metadata.isFile() || metadata.isSymbolicLink())
    throw new Error(`Canonical path must be a regular file: ${path}.`);
  const descriptor = await fsPromises.open(
    path,
    constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK
  );
  try {
    if (!(await descriptor.stat()).isFile())
      throw new Error(`Canonical path must be a regular file: ${path}.`);
    await descriptor.sync();
  } finally {
    await descriptor.close();
  }
}

/** Publishes staged asynchronous bytes and commits the destination and any distinct source parent. */
export async function publishCanonicalPathAsync(
  staged: string,
  destination: string
): Promise<void> {
  await syncCanonicalTreeAsync(staged);
  await fsPromises.rename(staged, destination);
  await syncCanonicalDirectoryAsync(dirname(destination));
  if (dirname(staged) !== dirname(destination)) await syncCanonicalDirectoryAsync(dirname(staged));
}

/**
 * Preserves a useful canonical-path error when a no-follow open rejects a link race.
 *
 * @param path Canonical file path.
 * @param error Native open error.
 * @throws The native error, or a canonical symbolic-link error for ELOOP.
 */
function throwCanonicalLinkError(path: string, error: unknown): never {
  if (typeof error === 'object' && error !== null && 'code' in error && error.code === 'ELOOP') {
    throw new Error(`Canonical path must not be a symbolic link: ${path}.`, { cause: error });
  }
  throw error;
}

/**
 * Removes unexpected direct child directories.
 *
 * @param root Parent directory.
 * @param expectedNames Directory names to retain.
 */
function removeStaleDirectories(root: string, expectedNames: ReadonlySet<string>): void {
  for (const name of listDirectoryNames(root)) {
    if (!expectedNames.has(name)) {
      rmSync(join(root, name), { recursive: true, force: true });
    }
  }
}

/**
 * Removes unexpected owned files with one suffix.
 *
 * @param root Parent directory.
 * @param expectedNames File names to retain.
 * @param suffix Owned file suffix.
 */
function removeStaleFiles(root: string, expectedNames: ReadonlySet<string>, suffix: string): void {
  for (const name of listFileNames(root)) {
    if (name.endsWith(suffix) && !expectedNames.has(name)) {
      rmSync(join(root, name), { force: true });
    }
  }
}

/**
 * Claims one id inside a globally keyed in-memory record family.
 *
 * @param ids Already claimed ids.
 * @param id Candidate id.
 * @param family Human-readable record family.
 * @throws Error when the id already belongs to another canonical record.
 */
function claimGlobalId(ids: Set<string>, id: string, family: string): void {
  if (ids.has(id)) {
    throw new Error(`Duplicate global ${family} id: ${id}.`);
  }
  ids.add(id);
}

/**
 * Reads one required string frontmatter field.
 *
 * @param document Parsed OKF document.
 * @param field Required field name.
 * @param path Source Markdown path.
 * @returns Non-empty string field.
 */
function requiredFrontmatterString(
  document: Parameters<typeof stringFrontmatterField>[0],
  field: string,
  path: string
): string {
  const value = stringFrontmatterField(document, field);

  if (!value) {
    throw new Error(`Canonical Markdown record ${path} is missing ${field}.`);
  }

  return value;
}

/**
 * Removes the single formatting newline added after a canonical Markdown body.
 *
 * @param body Parsed Markdown body.
 * @returns Original record body.
 */
function trimCanonicalMarkdownBody(body: string): string {
  return body.endsWith('\n') ? body.slice(0, -1) : body;
}
