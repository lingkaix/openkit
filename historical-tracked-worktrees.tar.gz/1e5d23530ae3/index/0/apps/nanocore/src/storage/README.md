# Storage

This directory owns NanoCore's physical data-root layout, ownership-scoped SQLite databases, canonical workspace file records, migrations, integrity validation, derived indexes, backup, export, and import mechanics.

## Source Of Truth

| Scope or record family | Durable owner |
| --- | --- |
| Server control state, authentication, scheduler records | `server/db/core.sqlite` |
| User-scoped command idempotency | `users/<userId>/db/user.sqlite` |
| Workspace-scoped ledgers and transactional recovery | `workspaces/<workspaceId>/db/workspace.sqlite` |
| Workspace, thread, turn, item, artifact, knowledge, source, session, and runtime transcript history | Canonical files under the owning workspace tree |
| Search, readiness, and dashboard indexes | Rebuildable files under `indexes/` or derived SQLite tables |

One record family must have one durable authority. Do not add aggregate workspace snapshots, dual file-and-SQLite payload ownership, newest-file recovery, or runtime resource serialization.

## Boundaries

- `fs-layout.ts` owns safe paths and accepted directory placement. `ensureLayout` verifies the ownership tree, database placement, canonical envelopes, and layout marker at boot and during stopped-process migration. Request paths use directory preparation without tree verification; `ensureWorkspaceLayout` creates only the root and Workspace directories needed by its caller.
- `db.ts` and `migrate.ts` own database opening, integrity validation, and native per-scope Drizzle journals under `drizzle/{core,user,workspace,app}`.
- Authoritative SQLite integrity failure stops boot and leaves the original database file unchanged; only derived indexes may rebuild automatically.
- `workspace-file-records.ts` owns canonical workspace record serialization and boot loading. Predecessor Threads validate the shared Thread fields and original envelope digest before the existing audience classifier runs. The final classified record must pass all current Thread constraints; validation never supplies a placeholder User. Store Review verification, observation Turn bindings and retained Audit attribution reuse its descriptive readers.
- `workspace-file-records.ts` also ensures the OKF v0.2 bundle-root `knowledge/pages/index.md` once, preserves valid authored index bytes, and writes the same final Knowledge Page candidate bytes that direct-edit validation accepted.
- `command-request-records.ts` owns scope-homed SQLite command idempotency; process-local duplicate collapse remains in `../runtime/idempotent-command.ts`.
- `../workspace-materials.ts` owns exactly the three app-local Material tables and their same-transaction command mutations; worker delivery, Artifact Review, and portable graph rewriting remain with their later S16 stages.
- `workspace-export.ts` owns the V3 export tree, manifest, exact-byte inventory, and offline verification.
- `workspace-archive.ts` owns strict USTAR path representability shared by export creation, offline verification, and archive production, plus bounded one-shot extraction into private request-local staging.
- `workspace-import.ts` parses only verified bytes, validates and remints the import graph, and reconstructs importable records. It remints `env.bound.payload.workspaceId` to the imported Workspace identity while `importedFrom` preserves source provenance. Package version, prompt and Tool digests, and `turn.reap` correlation remain unchanged. When a runtime row lacks header correlation, import preserves its source call reference in `corr` before reminting the fact identity, keeping recovery joins inside the reminted group.
- Native Knowledge Page import remints string-only `source_refs` through the parsed YAML document so block sequences and unknown nested metadata survive.
- `workspace-portable-file-state.ts` owns portable Knowledge maintenance ledgers, workspace config and schema, native OKF pages, query-owned S61 retrieval files, and retained S39 worker Context Package files. It has no Knowledge retrieval ledger reader or writer. Ordinary portable trace projections contain only normalized owned fields; ignored local annotations remain in immutable source bytes and are not forwarded into exports or target effects. `retrieval-traces.ts` alone publishes live immutable trace files by same-directory temporary file and rename, preserving an existing target as a conflict.
- Standalone Knowledge context traces and materializations are unsupported; worker delivery belongs only to the S39 Context Package owner.
- `workspace-transfer-routes.ts` coordinates public requests, staged workspace publication, the Core database transaction, and synchronous compensation when Core replay fails. Archive download streams every inventoried original in 64 KiB chunks with exact size and digest checks. Response cancellation closes the original through the same stream pipeline.
- `index-rebuild.ts` rebuilds the three non-lexical files `knowledge-links.json`, `knowledge-validation.json`, and `knowledge-source-refs.json`. Boot retains structurally valid files and rebuilds missing or invalid sets. Rebuild preserves the separately owned `indexes/retrieval/` directory and never migrates old lexical index data. The old mixed `search.json`, JSON term postings and TypeScript scorer are removed.
- Governed Knowledge retrieval uses the supervised kernel through `retrieval-knowledge-adapter.ts`. Current source and output audiences precede generation access; complete lexical enumeration precedes disposition and budgeting. Exact current page bytes and metadata are checked before returning results or writing one trace. Changed bytes or eligibility fail the request. The current file-backed owner and content-digest trace do not provide the pre-existing, unimplemented Git notebook history contract.
- Knowledge Page enumeration excludes `index.md` and `log.md` at every bundle depth while native portability keeps every Markdown file byte-for-byte.
- Secret material belongs to `../vault/` backends and credential consumers; storage may retain only explicitly allowed non-secret metadata and redacted evidence.
- The NanoHost-private attempt projection is the narrow exception for worker route authentication: it retains exactly three nullable lowercase SHA-256 projections for the control, inference, and capability families, never a raw token or a derived sandbox-binding credential.

`work-observations.ts` is the entry point for Turn observation append, validated reads and safe timeline projection using the shared App API presentation bounds. It validates immutable capture admission and separates expected facts from successful evidence publication. `../evidence-bundles.ts` owns restricted body staging, retention and expiry; callers never construct content paths or store bodies in control receipts. Portable consumers reuse the observation parser and existing exact reference maps.

`AssistantSkillAdmissionSchema` and `AssistantSkillAdmission` in `work-observations.ts` define the minimal canonical `env.bound.payload.assistantSkillAdmission` for trusted #144 producers. Retained rows may omit it; omission does not mean an empty selection. Strict identity tuples carry the source catalog revision and sorted unique Skill IDs with equal version/content digests, without Skill text or paths. Export and repeated import preserve these historical source values while reminting owned lineage; they never resolve or activate target resources. The existing whole-row conflict rule prevents later enrichment or replacement, and Timeline does not expose the tuple. The [Work Data Retention Format](../../../../docs/specs/20260921-work_data_retention_format.md#environment-binding-and-cause) owns this evidence contract; the model-capture owner commits the complete environment before dispatch.

Observation appends reuse a database-lifetime, process-local identity/sequence projection of the validated ledger. File replacement, size or nanosecond modification/change-time differences reopen it with full validation; reads always validate canonical bytes. State advances only after file and directory synchronization succeeds and keeps emitted bytes independent of producer-owned objects. Fresh-line fsync also commits any recovered truncation; exact replays still synchronize before acknowledgement. Complete canonical append logs check only their final byte, while incomplete tails retain full recovery validation. No cache is a durable authority or tamper-proofing mechanism.

Timeline coverage remains partial when a collection gap follows observed runtime activity; unsupported or unavailable collection without observed activity remains unavailable.

`work-observation-recovery.ts` appends `turn.reap` after restart recovery terminalizes a Turn it owns. It uses the historical capture binding and durable completion timestamp, pairs gateway attempts through their request parentage and runtime tool phases through observed opaque call references, and preserves the first committed snapshot on retry. Never-recorded Turns are skipped; ledger read or append failures propagate through the existing scheduler recovery retry loop. The observation records the Core recovery decision without concluding that an unresolved external effect did not happen.

## File Record Rules

- Writers store DATA_ROOT-relative path references. User and authored content may mention an absolute data root; layout verification does not scan text for that substring.
- Replace JSON records through a same-directory temporary file and rename.
- `writeFileAtomic` synchronizes replacement bytes and any caller-selected mode before rename, then synchronizes the parent directory. Callers retain their existing default modes. Vault keeps its separate no-follow writer and redacted errors with the same commit order.
- Existing Thread records skip file publication only when their complete projected canonical bytes match the current file. Changed bytes retain the durable writer; canonical validation, annotations and directory synchronization still run, including retries after a failed rename acknowledgement.
- Directory preparation commits each parent entry before creating a child. Retries synchronize existing components left visible by failed creation. Vault initialization also completes the store-directory commit after authenticating a visible header.
- `publishCanonicalPath` and its asynchronous counterpart synchronize complete staged file or tree contents, with child directories before parents, before rename. They synchronize the destination parent and any distinct staging parent before success. Snapshot, Workspace, rollback and runtime evidence publishers use this shared boundary; exact evidence replay retries synchronization after an interrupted acknowledgement.
- Bounded filesystem faults verify prior readable authority before publication, explicit failure after rename, and exact replay. These checks do not simulate a physical power loss or prove hardware cache behavior.
- Append item and event revisions to JSONL; readers select the latest item revision by id and preserve event sequence.
- Fail closed on malformed canonical records, invalid lineage, unsupported required features, path escapes, and legacy authority files.
- Descriptive history readers normalize root and nested annotations before returning known fields. Normal canonical rewrites preserve owned annotations, immutable Knowledge Proposal bytes and append-only Item/Review history; Knowledge ledger source annotations remain non-enumerable beside their normalized read model. Observation ingress persists its parsed payload, and unchanged receipt rewrites retain the original metadata JSON. Shared producer and instruction assertions remain exact.
- Export V3 preserves complete canonical history and exact portable file bytes; predecessor formats are rejected.
- Portable evidence keeps admitted restricted originals as verified binary bytes under their EvidenceBundle, separate from canonical UTF-8 records. Import remints owner references, preserves body digests and retention, and stages bytes before publishing the Workspace. Unpublished observation chunks and expired body bytes stay excluded.
- Current Goal portability retains intent history, card revisions, exact immutable Plan bytes and pointers, Task admission citations and Task terminal facts in `records/goal-state.json`. Import remints Workspace, Thread and Turn owners, keeps immutable Plan identities and bytes, binds responsibility to the importing actor and imports no grants. Retired Goal-owned rows are absent; shared historical Goal ids remain opaque lineage.
- Import writes the complete workspace tree and workspace database under `.staging`, publishes with one same-filesystem rename inside the Core transaction, and removes the published workspace when synchronous Core replay fails; this is coordinated rollback, not crash-atomic filesystem and SQLite commit.
- Fresh general and Quick Chat Workspaces initialize the complete scoped migration journal in their staged database before publication. Scoped discovery excludes `.staging`; a published Workspace with a missing database remains discoverable and its existing-only open fails without creating a replacement.
- Deletion removes the canonical file or directory so restart cannot resurrect stale state.

## Verification

The accepted [Knowledge retrieval contract](../../../../docs/specs/20260703-knowledge_store_implementation.md#retrieval-pipeline) separates Memory and Knowledge, uses Core Protocol's path-qualified references and publishes one immutable trace file under its querying Thread/Turn. Threadless direct User App calls publish no trace. The governed path uses qualified pins and query-owned files; no Workspace JSONL trace remains. The retrieval publisher alone writes query-owned trace files; no manifest array, compatibility reader, second writer or private Memory union is permitted. Ordinary portable export applies current containing-record and source access. The deletion lifecycle instead uses its exact verified deletion request authority after ordinary Workspace authority closes; its recovery export preserves normalized trace evidence through the same portable file owner.

Run focused layout, migration, database, canonical reload, index rebuild, export, import, integrity failure, and backup tests for the changed owner, followed by the package gates in the [NanoCore source guide](../README.md).

## Related Design

- [Storage](../../../../docs/core/storage.md)
- [Storage Layout And Record Ownership](../../../../docs/specs/20260703-storage_layout_record_ownership.md)
- [Schema Evolution Record Envelope](../../../../docs/specs/20260703-schema_evolution_record_envelope.md)

Data-root initialization seeds an empty editable `config/model-catalog.jsonc` alongside the other root config templates when absent and preserves administrator-authored contents.

Pending requests live in the Workspace SQLite `pending_requests` family. Canonical load, command replay, publication recovery, and attention reads share the validator in `../runtime/pending-requests.ts`; contradictory rows remain inspect-only while valid siblings stay usable. `command-request-records.ts` exposes a read-only receipt scan on the caller's existing scoped connection so validation inside a request transaction never opens a second migration or pruning writer.

Snapshot cursors and exact collection receipts (including private candidate bytes) are operational state bound to the source storage attachment and NanoHost scan store. Complete same-deployment backup retains them; portable Workspace export carries the existing output manifests, change sets, reviews, and apply history without importing live scan or replay authority.

Scheduler admission rows carry optional canonical `reasoning_effort` through delayed Worker dispatch. The pre-release Core baseline includes this nullable column; absent values project as an omitted preference. Work observation sampling uses the shared Protocol effort validator rather than a second enum.

Retained scheduler storage selection, backend image lineage, and Worker storage targets permit descriptive additions at their existing readers. Reads preserve the durable JSON bytes and return only validated known fields; unknown core or required semantics remain refusals. Authored storage-selection commands remain exact.

CapabilityCall archives use the ledger’s canonical extension validation to preserve safe stored namespaces across scope remapping and import. Live protocol and App audit projections retain their stricter unknown-namespace omission; this does not add an archive format or a second persistence path.

Workspace migrations drop retired host repository and Git push tables after replaying unchanged historical setup DDL. No schema module or live repository store remains; archive codecs validate historical metadata without restoring authority.

`data-root-admin-operations.ts` joins `backup.create`, `backup.verify` and `storage.layout-report` to the existing hot-backup, inventory verifier and layout owners without HTTP context. The common definition projections enforce current deployment-administrator admission; local backup handles, SQLite coverage and recovery limits remain with the storage owner.

`workspace-transfer-operations.ts` joins the three server-managed JSON transfer definitions to the existing verified-tree export, collision-preview and staged-publication owners in `workspace-transfer-routes.ts`. The archive streaming registrar continues to use those owners without a JSON adapter.

Server-managed export handles use `canReadWorkspaceExport` to require both current source Workspace export authority and the authenticated creator recorded by the existing storage call and usage ledger. Missing or contradictory attribution refuses the handle. Private history in the verified export also requires the creator's current administrator eligibility for every consuming path; the guard reuses the import owner's Thread parser over verified bytes. The JSON native join supplies trusted current administrator eligibility for private project history; clients cannot select it. Archive bindings retain their existing streaming and byte-handling owners.

Deleted-Workspace recovery reuses `importVerifiedWorkspace` with a trusted internal recovery owner taken from the verified deployment-local tombstone. Receipt and audit actor attribution remains the actual recovery caller, while registry, owner membership and imported Goal responsibility publication restores the original active owner. Ordinary portable import retains its importing-user ownership rule; no public input can select the recovery owner.

Data-root administration and Workspace transfer handlers expose inferred exact-key operation joins. Their existing backup verification and staged-publication fallbacks use safe typed operation errors; common framing never identifies storage boundary subclasses. Storage ownership, compensation and retained bytes are unchanged.

AgentSession canonical records retain private `retainedStorage` association and slot provenance beside native proof. Absent facts remain readable. Portable export clears this source-deployment fact and import independently clears it; same-deployment backup retains canonical record bytes. See [AgentSession Continuity](../../../../docs/specs/20260704-agent_session_continuity.md) for the owning lifecycle.

The three `workspace.archive-*` definitions retain the existing streaming routes, archive admission, staging, commitment and recovery owner. Web Portability and the administrator CLI consume these streams without JSON-encoding archive bytes. Remote MCP omits and refuses the definitions before archive processing.

Canonical Artifact publication uses `canonical-write-capacity.ts` to scope the existing `artifacts/file-admission.ts` owner to synchronous replacement and append writes. Each write reserves its exact serialized bytes before the temporary file or append effect, converts accepted bytes to occupied disk, and releases after completion or proved cleanup. Descriptive JSON uses its final preserved serialization, so unknown retained fields are counted when a changed core rewrites them. Equal cores still skip writes. The scope includes compensation and reference/event appends and cannot contain asynchronous work. It grants no authorization, rollback or file/SQLite atomicity. Unproved cleanup and incomplete appends keep remaining capacity for the existing recovery owner. Run `src/storage/canonical-write-capacity.test.ts` and `src/storage/canonical-write-capacity-faults.test.ts` for retained-record, concurrency and failure regressions.

Abandoned `workspaces/.staging` cleanup runs explicitly in the server startup recovery phase before dispatch and upload admission. Loading canonical records or constructing another `FsStore` is a read operation and never removes a live request stage. Stopped offline tools must use their own explicit cleanup authority; a reader does not infer abandonment.

The identifier cutover allocates each eligible import target once per complete source owner key in the verified invocation, including Material revision compound keys. References reuse those maps; Artifact-reference Items and Artifact Reviews retain their declared deterministic names. Receiving-Thread parents map with the Thread graph. No map is recreated to repair a process crash. Export accounting derives its call identity from the retained export id and reuses the full measurement tuple; export access proves that tuple and the verified inventory without reconstructing usage ids. Deletion recovery export authority reconstructs only its accepted request-bound UUIDv5 id and retains the exact manifest digest check.

Default Provider configuration seeding replaces each template Vault placeholder with one independent canonical candidate before its first file publication. Existing files and their recorded references remain unchanged on later layout checks. Inactive examples carry only candidates and supply no Vault authority.

Physical Epoch and Workspace storage conversions allocate one shared canonical `drb` UUIDv7 before copying their external predecessor backup. Their manifests and migration reports retain that allocation; deployment and capture times remain separate facts. Allocation failure preserves predecessor bytes and publishes no backup or staging. Cold and hot backup writers admit supplied `drb` and `dep` identifiers before changing backup bytes. Run `src/storage/data-root-backup.test.ts`, `src/storage/physical-epoch-cutover.test.ts` and `src/storage/workspace-storage-migration.test.ts` for these boundaries.
