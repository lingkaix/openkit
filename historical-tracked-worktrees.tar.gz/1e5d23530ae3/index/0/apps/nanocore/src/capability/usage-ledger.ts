import {
  type ActorRef,
  allocateEntityId,
  type CapabilityCall,
  CapabilityCallExtensionsSchema,
  CapabilityCallSchema,
  type GatewayRouteLineageEntry,
  GatewayRouteLineageEntrySchema,
  RequestIdSchema,
  responsibleUserIdForActor,
  type UsageRecord,
  UsageRecordSchema,
} from '@openkit/protocol';
import { z } from 'zod';
import { recordWorkspaceAuditEvent } from '../audit-events.js';
import { WorkerRawOutputStateSchema } from '../runtime/worker-raw-output.js';
import type { WorkspaceDb } from '../storage/db.js';
import type { CapabilityCallFamily } from '../storage/schema/index.js';

type CapabilityCallRow = {
  call_id: string;
  workspace_id: string;
  thread_id: string | null;
  turn_id: string | null;
  item_id: string | null;
  agent_id: string | null;
  agent_session_id: string | null;
  package_snapshot_id: string | null;
  schema_snapshot_id: string | null;
  runtime_origin_ref: string | null;
  runtime_cache_lineage_ref: string | null;
  request_id: string | null;
  source_ids_json: string;
  capability_id: string;
  family: string;
  operation: string;
  summary: string | null;
  provider_ref: string | null;
  service_ref: string | null;
  redaction_class: string;
  status: string;
  error_code: string | null;
  started_at: string | null;
  completed_at: string | null;
  system_prompt_digest: string | null;
  extensions_json: string | null;
};

/** Storage/export-only validation preserves other canonical namespaces; live protocol projections still strip them. */
export const CanonicalCapabilityCallExtensionsSchema = CapabilityCallExtensionsSchema.extend({
  'openkit.worker/rawOutput': WorkerRawOutputStateSchema.optional(),
}).catchall(z.unknown());

/** Exportable capability call ledger record. */
export interface CapabilityCallLedgerRecord extends CapabilityCall {
  /** Canonical optional content for storage and archives, never a live protocol projection. */
  extensions?: z.infer<typeof CanonicalCapabilityCallExtensionsSchema> | undefined;
  /** Capability family used by gateway dispatch and idempotency. */
  family: CapabilityCallFamily;
  /** Gateway operation used by idempotency. */
  operation: string;
  /** Redacted provider reference. */
  providerRef: string | null;
  /** Redacted service reference. */
  serviceRef: string | null;
  /** Redaction class applied by the producer. */
  redactionClass: string;
}

/** Gateway call context accepted by the shared capability usage ledger. */
export interface GatewayCallContext {
  /** Workspace that owns the call. */
  workspaceId: string;
  /** Process-local authority actor for linked usage attribution. */
  authorityActor: ActorRef | null;
  /** Thread lineage when available. */
  threadId?: string | null;
  /** Turn lineage when available. */
  turnId?: string | null;
  /** Item lineage when available. */
  itemId?: string | null;
  /** Agent lineage when available. */
  agentId?: string | null;
  /** AgentSession lineage when available. */
  agentSessionId?: string | null;
  /** Agent Environment Package snapshot that authorized the call. */
  packageSnapshotId?: string | null;
  /** Schema snapshot used to validate a schema-bound call. */
  schemaSnapshotId?: string | null;
  /** Product-safe runtime origin correlation reference. */
  runtimeOriginRef?: string | null;
  /** Product-safe runtime cache-lineage correlation reference. */
  runtimeCacheLineageRef?: string | null;
  /** Request id used for idempotency when available. */
  requestId?: string | null;
  /** Workspace data source ids touched by this call. */
  sourceIds?: readonly string[];
  /** Capability family. */
  family: CapabilityCallFamily;
  /** Gateway operation. */
  operation: string;
  /** Product capability id. */
  capabilityId: string;
  /** Redacted summary. */
  summary?: string | null;
  /** Redacted provider reference. */
  providerRef?: string | null;
  /** Redacted service reference. */
  serviceRef?: string | null;
  /** Redaction class applied by the producer. */
  redactionClass: string;
}

/** Input for starting one capability call. */
export interface StartCapabilityCallInput extends GatewayCallContext {
  /** Workspace-scoped database handle. */
  workspaceDb: WorkspaceDb;
  /** Stable call id for deterministic tests. */
  callId?: string;
  /** Start time. */
  now?: Date;
}

/** Started capability call summary returned to producers. */
export interface StartedCapabilityCall {
  /** Durable call id. */
  id: string;
  /** Whether this invocation created the durable call row. */
  inserted: boolean;
  /** Gateway call context copied from the stored row. */
  context: GatewayCallContext;
}

/** Usage measurement input linked to one call. */
export interface UsageMeasurementInput {
  /** Stable usage record id for deterministic tests. */
  usageId?: string;
  /** Usage category. */
  category: UsageRecord['category'];
  /** Usage unit. */
  unit: UsageRecord['unit'];
  /** Measured quantity. */
  quantity: number;
  /** LLM model id when applicable. */
  modelId?: string | null;
  /** Provider reference when applicable. */
  providerRef?: string | null;
  /** Measurement source. */
  source?: string | null;
}

/** Trusted command lineage for audit only, separate from capability-call idempotency. */
export interface CapabilityAuditLineage {
  /** Admitted command request ID retained when the call has no per-invocation request ID. */
  readonly commandRequestId: string;
}

/** Input for recording usage rows for one capability call. */
export interface RecordUsageInput {
  /** Workspace-scoped database handle. */
  workspaceDb: WorkspaceDb;
  /** Started call returned by startCapabilityCall. */
  call: StartedCapabilityCall;
  /** Usage rows to record. */
  records: UsageMeasurementInput[];
  /** Trusted command lineage for the audit event if usage recording fails. */
  auditLineage?: CapabilityAuditLineage | undefined;
  /** Recording time. */
  now?: Date;
}

/** Input for finishing one capability call. */
export interface FinishCapabilityCallInput {
  /** Workspace-scoped database handle. */
  workspaceDb: WorkspaceDb;
  /** Durable call id. */
  callId: string;
  /** Terminal status. */
  status: Exclude<CapabilityCall['status'], 'queued' | 'running'>;
  /** Stable error code for non-success terminal calls. */
  errorCode?: string | null;
  /** Trusted command lineage for audit only; never copied into the call row. */
  auditLineage?: CapabilityAuditLineage | undefined;
  /** Completion time. */
  now?: Date;
}

/** Input for binding a running call to its observed schema snapshot. */
export interface StampCapabilityCallSchemaSnapshotInput {
  /** Workspace-scoped database handle. */
  readonly workspaceDb: WorkspaceDb;
  /** Durable running capability call id. */
  readonly callId: string;
  /** Stable schema snapshot id used for validation. */
  readonly schemaSnapshotId: string;
}

/** Input for recovering non-terminal capability calls after restart. */
export interface RecoverRunningCapabilityCallsInput {
  /** Workspace-scoped database handle. */
  workspaceDb: WorkspaceDb;
  /** Recovery time. */
  now?: Date;
}

/**
 * Returns a capability-ledger-safe request id.
 *
 * @param requestId Caller-supplied request id.
 * @returns UUID request id accepted by protocol capability schemas, or null.
 */
export function normalizeCapabilityRequestId(requestId: string | null | undefined): string | null {
  const parsed = RequestIdSchema.safeParse(requestId);

  return parsed.success ? parsed.data : null;
}

/**
 * Starts one durable capability call before upstream contact.
 *
 * @param input Gateway call context and database handle.
 * @returns Durable call summary.
 */
export function startCapabilityCall(input: StartCapabilityCallInput): StartedCapabilityCall {
  const {
    workspaceDb: _workspaceDb,
    now: _now,
    callId: _callId,
    authorityActor: _authorityActor,
    ...safeInput
  } = input;
  assertNoUnsafeLedgerValue(safeInput);

  const startedAt = (input.now ?? new Date()).toISOString();
  const callId = input.callId ?? allocateEntityId('cap');
  const protocolCall = CapabilityCallSchema.parse({
    id: callId,
    workspaceId: input.workspaceId,
    threadId: input.threadId ?? null,
    turnId: input.turnId ?? null,
    itemId: input.itemId ?? null,
    agentId: input.agentId ?? null,
    agentSessionId: input.agentSessionId ?? null,
    packageSnapshotId: input.packageSnapshotId ?? null,
    schemaSnapshotId: input.schemaSnapshotId ?? null,
    runtimeOriginRef: input.runtimeOriginRef ?? null,
    runtimeCacheLineageRef: input.runtimeCacheLineageRef ?? null,
    requestId: input.requestId ?? null,
    sourceIds: normalizeSourceIds(input.sourceIds),
    capabilityId: input.capabilityId,
    status: 'running',
    summary: input.summary ?? null,
    errorCode: null,
    startedAt,
    completedAt: null,
  });

  const insertion = input.workspaceDb.sqlite
    .prepare(
      `INSERT OR IGNORE INTO capability_calls (
        call_id,
        workspace_id,
        thread_id,
        turn_id,
        item_id,
        agent_id,
        agent_session_id,
        request_id,
        source_ids_json,
        capability_id,
        family,
        operation,
        status,
        summary,
        provider_ref,
        service_ref,
        redaction_class,
        error_code,
        started_at,
        completed_at,
        package_snapshot_id,
        schema_snapshot_id,
        runtime_origin_ref,
        runtime_cache_lineage_ref
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      protocolCall.id,
      protocolCall.workspaceId,
      protocolCall.threadId,
      protocolCall.turnId,
      protocolCall.itemId,
      protocolCall.agentId,
      protocolCall.agentSessionId,
      protocolCall.requestId,
      sourceIdsJson(protocolCall.sourceIds),
      protocolCall.capabilityId,
      input.family,
      input.operation,
      protocolCall.status,
      protocolCall.summary,
      input.providerRef ?? null,
      input.serviceRef ?? null,
      input.redactionClass,
      protocolCall.errorCode,
      protocolCall.startedAt,
      protocolCall.completedAt,
      protocolCall.packageSnapshotId,
      protocolCall.schemaSnapshotId,
      protocolCall.runtimeOriginRef,
      protocolCall.runtimeCacheLineageRef
    );

  const stored = findCapabilityCallByIdOrIdempotency(input.workspaceDb, { ...input, callId });
  assertMatchingCapabilityCallAttribution(stored, protocolCall, input);

  return {
    id: stored.call_id,
    inserted: insertion.changes === 1,
    context: {
      agentId: stored.agent_id,
      agentSessionId: stored.agent_session_id,
      authorityActor: input.authorityActor,
      capabilityId: stored.capability_id,
      family: stored.family as CapabilityCallFamily,
      itemId: stored.item_id,
      operation: stored.operation,
      packageSnapshotId: stored.package_snapshot_id,
      schemaSnapshotId: stored.schema_snapshot_id,
      providerRef: stored.provider_ref,
      redactionClass: stored.redaction_class,
      requestId: stored.request_id,
      runtimeCacheLineageRef: stored.runtime_cache_lineage_ref,
      runtimeOriginRef: stored.runtime_origin_ref,
      serviceRef: stored.service_ref,
      sourceIds: parseSourceIdsJson(stored.source_ids_json),
      summary: stored.summary,
      threadId: stored.thread_id,
      turnId: stored.turn_id,
      workspaceId: stored.workspace_id,
    },
  };
}

/**
 * Records measured usage linked to a started capability call.
 *
 * @param input Usage rows, durable call summary and optional command audit lineage.
 * @returns Retained IDs, including existing equivalent measurements, in input order.
 */
export function recordUsage(input: RecordUsageInput): string[] {
  const ids: string[] = [];
  const recordedAt = (input.now ?? new Date()).toISOString();

  try {
    for (const record of input.records) {
      assertNoUnsafeLedgerValue(record);

      const usage = UsageRecordSchema.parse({
        id: record.usageId ?? allocateEntityId('use'),
        workspaceId: input.call.context.workspaceId,
        responsibleUserId: input.call.context.authorityActor
          ? responsibleUserIdForActor(input.call.context.authorityActor)
          : null,
        threadId: input.call.context.threadId ?? null,
        turnId: input.call.context.turnId ?? null,
        itemId: input.call.context.itemId ?? null,
        capabilityCallId: input.call.id,
        requestId: input.call.context.requestId ?? null,
        agentId: input.call.context.agentId ?? null,
        agentSessionId: input.call.context.agentSessionId ?? null,
        sourceIds: normalizeSourceIds(input.call.context.sourceIds),
        category: record.category,
        unit: record.unit,
        quantity: record.quantity,
        modelId: record.modelId ?? null,
        providerRef: record.providerRef ?? input.call.context.providerRef ?? null,
        source: record.source ?? null,
        recordedAt,
      });

      const equivalent = hasEquivalentUsageRecord(input.workspaceDb, usage);
      ids.push(equivalent ?? usage.id);
      if (equivalent) continue;

      input.workspaceDb.sqlite
        .prepare(
          `INSERT INTO usage_records (
            usage_id,
            workspace_id,
            thread_id,
            turn_id,
            item_id,
            capability_call_id,
            request_id,
            agent_id,
            agent_session_id,
            responsible_user_id,
            source_ids_json,
            category,
            unit,
            quantity,
            model_id,
            provider_ref,
            source,
            recorded_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          usage.id,
          usage.workspaceId,
          usage.threadId,
          usage.turnId,
          usage.itemId,
          usage.capabilityCallId,
          usage.requestId,
          usage.agentId,
          usage.agentSessionId,
          usage.responsibleUserId,
          sourceIdsJson(usage.sourceIds),
          usage.category,
          usage.unit,
          usage.quantity,
          usage.modelId,
          usage.providerRef,
          usage.source,
          usage.recordedAt
        );
    }
  } catch (error) {
    try {
      finishCapabilityCall({
        auditLineage: input.auditLineage,
        workspaceDb: input.workspaceDb,
        callId: input.call.id,
        errorCode: 'usage_record_failed',
        status: 'failed',
      });
    } catch {}
    throw error;
  }
  return ids;
}

/**
 * Checks whether a retry already recorded the same usage measurement for a call.
 *
 * @param workspaceDb Workspace-scoped database handle.
 * @param usage Protocol-validated usage row.
 * @returns The retained measurement ID when an equivalent record is already stored.
 */
function hasEquivalentUsageRecord(
  workspaceDb: WorkspaceDb,
  usage: UsageRecord
): string | undefined {
  const row = workspaceDb.sqlite
    .prepare(
      `SELECT usage_id FROM usage_records
       WHERE capability_call_id IS ?
         AND category = ?
         AND unit = ?
         AND quantity = ?
         AND model_id IS ?
         AND provider_ref IS ?
         AND source IS ?
         AND source_ids_json = ?
       LIMIT 1`
    )
    .get(
      usage.capabilityCallId,
      usage.category,
      usage.unit,
      usage.quantity,
      usage.modelId,
      usage.providerRef,
      usage.source,
      sourceIdsJson(usage.sourceIds)
    ) as { usage_id: string } | undefined;

  return row?.usage_id;
}

/**
 * Marks one capability call terminal.
 *
 * @param input Terminal status and optional trusted command lineage for audit.
 */
export function finishCapabilityCall(input: FinishCapabilityCallInput): void {
  const now = input.now ?? new Date();
  const completedAt = now.toISOString();

  input.workspaceDb.sqlite
    .transaction(() => {
      const call = findCapabilityCallById(input.workspaceDb, input.callId);
      if (!call || call.completed_at) {
        return;
      }
      const auditRequestId =
        call.request_id ??
        (input.auditLineage === undefined
          ? null
          : RequestIdSchema.parse(input.auditLineage.commandRequestId));
      capabilityCallFromRow({
        ...call,
        completed_at: completedAt,
        error_code: input.errorCode ?? null,
        status: input.status,
      });
      const result = input.workspaceDb.sqlite
        .prepare(
          `UPDATE capability_calls
           SET status = ?, error_code = ?, completed_at = ?
           WHERE call_id = ? AND completed_at IS NULL`
        )
        .run(input.status, input.errorCode ?? null, completedAt, input.callId);
      if (result.changes !== 1) {
        throw new Error(`Capability call changed concurrently: ${input.callId}`);
      }

      recordWorkspaceAuditEvent({
        action: 'capability.finish',
        agentId: call.agent_id,
        agentSessionId: call.agent_session_id,
        capabilityCallId: call.call_id,
        category: 'capability',
        errorCode: input.errorCode ?? null,
        itemId: call.item_id,
        now,
        occurredAt: now,
        outcome: capabilityAuditOutcome(input.status),
        requestId: auditRequestId,
        resource: `capability:${call.capability_id}`,
        severity: capabilityAuditSeverity(input.status),
        summary: capabilityAuditSummary(input.status, call, input.errorCode ?? null),
        threadId: call.thread_id,
        turnId: call.turn_id,
        workspaceDb: input.workspaceDb,
        workspaceId: call.workspace_id,
      });
    })
    .immediate();
}

/** Binds one running call to exactly one schema snapshot before its effect. */
export function stampCapabilityCallSchemaSnapshot(
  input: StampCapabilityCallSchemaSnapshotInput
): void {
  const parsed = CapabilityCallSchema.shape.schemaSnapshotId.unwrap().parse(input.schemaSnapshotId);
  const result = input.workspaceDb.sqlite
    .prepare(
      `UPDATE capability_calls
       SET schema_snapshot_id = ?
       WHERE call_id = ? AND status = 'running' AND schema_snapshot_id IS NULL`
    )
    .run(parsed, input.callId);
  if (result.changes === 1) return;
  const stored = findCapabilityCallById(input.workspaceDb, input.callId);
  if (stored?.schema_snapshot_id !== parsed) {
    throw new Error(`Capability call schema snapshot conflicts: ${input.callId}`);
  }
}

/**
 * Terminates non-terminal capability calls left behind by a prior process.
 *
 * @param input Workspace database and recovery time.
 * @returns Number of recovered calls.
 */
export function recoverRunningCapabilityCalls(input: RecoverRunningCapabilityCallsInput): number {
  const now = input.now ?? new Date();
  const calls = input.workspaceDb.sqlite
    .prepare('SELECT * FROM capability_calls WHERE status = ?')
    .all('running') as CapabilityCallRow[];

  for (const call of calls) {
    finishCapabilityCall({
      callId: call.call_id,
      errorCode: 'capability_call_recovered_after_restart',
      now,
      status: 'unknown',
      workspaceDb: input.workspaceDb,
    });
  }

  return calls.length;
}

/**
 * Lists workspace capability calls as exportable records.
 *
 * @param workspaceDb Workspace database that owns the ledger rows.
 * @param workspaceId Workspace id to export.
 * @returns Capability call records in stable storage order.
 */
export function listWorkspaceCapabilityCalls(
  workspaceDb: WorkspaceDb,
  workspaceId: string
): CapabilityCallLedgerRecord[] {
  return workspaceDb.sqlite
    .prepare(
      `SELECT * FROM capability_calls
       WHERE workspace_id = ?
       ORDER BY started_at, call_id`
    )
    .all(workspaceId)
    .map(capabilityCallFromRow);
}

/**
 * Lists workspace usage records as protocol records.
 *
 * @param workspaceDb Workspace database that owns the usage rows.
 * @param workspaceId Workspace id to export.
 * @returns Usage records in stable storage order.
 */
export function listWorkspaceUsageRecords(
  workspaceDb: WorkspaceDb,
  workspaceId: string
): UsageRecord[] {
  return workspaceDb.sqlite
    .prepare(
      `SELECT * FROM usage_records
       WHERE workspace_id = ?
       ORDER BY recorded_at, usage_id`
    )
    .all(workspaceId)
    .map(usageRecordFromRow);
}

/** Latest current-session LLM usage joined to a family=llm capability call. */
export interface CurrentAgentSessionLlmUsage {
  /** Capability call that attributed the usage. */
  readonly capabilityCallId: string;
  /** Last attributed logical model id. */
  readonly modelId: string;
  /** Usage recording timestamp. */
  readonly recordedAt: string;
  /** Exact Turn id recorded on the usage and capability call. */
  readonly turnId: string;
}

/**
 * Reads the most recent category=llm usage for one current AgentSession joined to a family=llm call.
 *
 * @param workspaceDb Workspace database that owns the ledger rows.
 * @param input Exact Workspace, Thread, and current AgentSession lineage.
 * @returns Latest matching usage, or null when attribution is absent.
 */
export function readLatestCurrentAgentSessionLlmUsage(
  workspaceDb: WorkspaceDb,
  input: {
    readonly agentSessionId: string;
    readonly threadId: string;
    readonly workspaceId: string;
  }
): CurrentAgentSessionLlmUsage | null {
  const row = workspaceDb.sqlite
    .prepare(
      `SELECT
         usage.capability_call_id AS capability_call_id,
         usage.model_id AS model_id,
         usage.recorded_at AS recorded_at,
         usage.turn_id AS turn_id
       FROM usage_records usage
       INNER JOIN capability_calls call ON call.call_id = usage.capability_call_id
       WHERE usage.workspace_id = ?
         AND usage.thread_id = ?
         AND usage.agent_session_id = ?
         AND usage.category = 'llm'
         AND usage.model_id IS NOT NULL
         AND usage.model_id != ''
         AND usage.turn_id IS NOT NULL
         AND call.family = 'llm'
         AND call.workspace_id = usage.workspace_id
         AND call.thread_id = usage.thread_id
         AND call.turn_id = usage.turn_id
         AND call.agent_session_id = usage.agent_session_id
       ORDER BY usage.recorded_at DESC, usage.usage_id DESC
       LIMIT 1`
    )
    .get(input.workspaceId, input.threadId, input.agentSessionId) as
    | {
        readonly capability_call_id: string;
        readonly model_id: string;
        readonly recorded_at: string;
        readonly turn_id: string;
      }
    | undefined;

  if (!row) {
    return null;
  }

  return {
    capabilityCallId: row.capability_call_id,
    modelId: row.model_id,
    recordedAt: row.recorded_at,
    turnId: row.turn_id,
  };
}

/**
 * Imports exported workspace capability usage rows into the target workspace database.
 *
 * @param input Target database and already remapped ledger records.
 */
export function importWorkspaceCapabilityUsageLedger(input: {
  workspaceDb: WorkspaceDb;
  capabilityCalls: readonly CapabilityCallLedgerRecord[];
  usageRecords: readonly UsageRecord[];
}): void {
  for (const call of input.capabilityCalls) {
    insertCapabilityCall(input.workspaceDb, call);
  }
  for (const usage of input.usageRecords) {
    insertUsageRecord(input.workspaceDb, usage);
  }
}

/**
 * Reads one capability call row by id.
 *
 * @param workspaceDb Workspace-scoped database handle.
 * @param callId Capability call id.
 * @returns Stored row when present.
 */
function findCapabilityCallById(
  workspaceDb: WorkspaceDb,
  callId: string
): CapabilityCallRow | undefined {
  return workspaceDb.sqlite
    .prepare('SELECT * FROM capability_calls WHERE call_id = ?')
    .get(callId) as CapabilityCallRow | undefined;
}

/** Inserts one exportable capability call record. */
function insertCapabilityCall(workspaceDb: WorkspaceDb, call: CapabilityCallLedgerRecord): void {
  workspaceDb.sqlite
    .prepare(
      `INSERT INTO capability_calls (
        call_id,
        workspace_id,
        thread_id,
        turn_id,
        item_id,
        agent_id,
        agent_session_id,
        request_id,
        source_ids_json,
        capability_id,
        family,
        operation,
        status,
        summary,
        provider_ref,
        service_ref,
        redaction_class,
        error_code,
        started_at,
        completed_at,
        package_snapshot_id,
        schema_snapshot_id,
        runtime_origin_ref,
        runtime_cache_lineage_ref,
        system_prompt_digest,
        extensions_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      call.id,
      call.workspaceId,
      call.threadId,
      call.turnId,
      call.itemId,
      call.agentId,
      call.agentSessionId,
      call.requestId,
      sourceIdsJson(call.sourceIds),
      call.capabilityId,
      call.family,
      call.operation,
      call.status,
      call.summary,
      call.providerRef,
      call.serviceRef,
      call.redactionClass,
      call.errorCode,
      call.startedAt,
      call.completedAt,
      call.packageSnapshotId,
      call.schemaSnapshotId,
      call.runtimeOriginRef,
      call.runtimeCacheLineageRef,
      call.systemPromptDigest ?? null,
      call.extensions === undefined
        ? null
        : JSON.stringify(CanonicalCapabilityCallExtensionsSchema.parse(call.extensions))
    );
}

/** Inserts one protocol usage record. */
function insertUsageRecord(workspaceDb: WorkspaceDb, usage: UsageRecord): void {
  workspaceDb.sqlite
    .prepare(
      `INSERT INTO usage_records (
        usage_id,
        workspace_id,
        thread_id,
        turn_id,
        item_id,
        capability_call_id,
        request_id,
        agent_id,
        agent_session_id,
        responsible_user_id,
        source_ids_json,
        category,
        unit,
        quantity,
        model_id,
        provider_ref,
        source,
        recorded_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      usage.id,
      usage.workspaceId,
      usage.threadId,
      usage.turnId,
      usage.itemId,
      usage.capabilityCallId,
      usage.requestId,
      usage.agentId,
      usage.agentSessionId,
      usage.responsibleUserId,
      sourceIdsJson(usage.sourceIds),
      usage.category,
      usage.unit,
      usage.quantity,
      usage.modelId,
      usage.providerRef,
      usage.source,
      usage.recordedAt
    );
}

/** Converts one stored capability call row into an exportable record. */
function capabilityCallFromRow(row: unknown): CapabilityCallLedgerRecord {
  const call = row as CapabilityCallRow;
  const extensions =
    call.extensions_json === null
      ? undefined
      : CanonicalCapabilityCallExtensionsSchema.parse(JSON.parse(call.extensions_json));
  const protocolCall = CapabilityCallSchema.parse({
    id: call.call_id,
    workspaceId: call.workspace_id,
    threadId: call.thread_id,
    turnId: call.turn_id,
    itemId: call.item_id,
    agentId: call.agent_id,
    agentSessionId: call.agent_session_id,
    packageSnapshotId: call.package_snapshot_id,
    schemaSnapshotId: call.schema_snapshot_id,
    runtimeOriginRef: call.runtime_origin_ref,
    runtimeCacheLineageRef: call.runtime_cache_lineage_ref,
    requestId: call.request_id,
    sourceIds: parseSourceIdsJson(call.source_ids_json),
    capabilityId: call.capability_id,
    status: call.status,
    summary: call.summary,
    errorCode: call.error_code,
    startedAt: call.started_at,
    completedAt: call.completed_at,
    ...(call.system_prompt_digest === null
      ? {}
      : { systemPromptDigest: call.system_prompt_digest }),
    ...(extensions === undefined ? {} : { extensions }),
  });

  return {
    ...protocolCall,
    ...(extensions === undefined ? {} : { extensions }),
    family: call.family as CapabilityCallFamily,
    operation: call.operation,
    providerRef: call.provider_ref,
    serviceRef: call.service_ref,
    redactionClass: call.redaction_class,
  };
}

/** Converts one stored usage row into a protocol usage record. */
function usageRecordFromRow(row: unknown): UsageRecord {
  const usage = row as Record<string, unknown>;

  return UsageRecordSchema.parse({
    id: usage.usage_id,
    workspaceId: usage.workspace_id,
    threadId: usage.thread_id,
    turnId: usage.turn_id,
    itemId: usage.item_id,
    capabilityCallId: usage.capability_call_id,
    requestId: usage.request_id,
    agentId: usage.agent_id,
    agentSessionId: usage.agent_session_id,
    responsibleUserId: usage.responsible_user_id,
    sourceIds: parseSourceIdsJson(String(usage.source_ids_json ?? '[]')),
    category: usage.category,
    unit: usage.unit,
    quantity: usage.quantity,
    modelId: usage.model_id,
    providerRef: usage.provider_ref,
    source: usage.source,
    recordedAt: usage.recorded_at,
  });
}

/**
 * Produces a stable source id list.
 *
 * @param sourceIds Candidate source ids.
 * @returns Deduplicated sorted source ids.
 */
function normalizeSourceIds(sourceIds: readonly string[] | null | undefined): string[] {
  return [...new Set(sourceIds ?? [])].filter((sourceId) => sourceId.length > 0).sort();
}

/**
 * Serializes source ids for SQLite storage.
 *
 * @param sourceIds Source ids to serialize.
 * @returns Stable JSON string.
 */
function sourceIdsJson(sourceIds: readonly string[] | null | undefined): string {
  return JSON.stringify(normalizeSourceIds(sourceIds));
}

/**
 * Parses stored source ids.
 *
 * @param value Stored JSON value.
 * @returns Source id list.
 */
function parseSourceIdsJson(value: string | null | undefined): string[] {
  if (!value) {
    return [];
  }

  try {
    const parsed = JSON.parse(value) as unknown;
    return Array.isArray(parsed)
      ? normalizeSourceIds(
          parsed.filter((sourceId): sourceId is string => typeof sourceId === 'string')
        )
      : [];
  } catch {
    return [];
  }
}

/**
 * Maps a terminal capability status to audit severity.
 *
 * @param status Terminal capability status.
 * @returns Audit severity.
 */
function capabilityAuditSeverity(
  status: FinishCapabilityCallInput['status']
): 'info' | 'warning' | 'error' {
  if (status === 'succeeded') {
    return 'info';
  }

  return status === 'failed' || status === 'timed-out' ? 'error' : 'warning';
}

/** Maps the Core terminal status into the independently owned audit outcome. */
function capabilityAuditOutcome(
  status: FinishCapabilityCallInput['status']
): Parameters<typeof recordWorkspaceAuditEvent>[0]['outcome'] {
  if (status === 'succeeded' || status === 'denied' || status === 'unknown') {
    return status;
  }
  if (status === 'failed' || status === 'timed-out') {
    return 'failed';
  }
  return 'cancelled';
}

/**
 * Builds a redacted terminal capability audit summary.
 *
 * @param status Terminal capability status.
 * @param call Stored capability call row.
 * @param errorCode Stable error code when present.
 * @returns Redacted audit summary.
 */
function capabilityAuditSummary(
  status: FinishCapabilityCallInput['status'],
  call: CapabilityCallRow,
  errorCode: string | null
): string {
  if (status === 'succeeded') {
    return `Capability call succeeded: ${call.summary ?? call.capability_id}`;
  }

  return `Capability call ${status}: ${errorCode ?? call.capability_id}`;
}

/**
 * Reads one started call by explicit id or idempotency tuple.
 *
 * @param workspaceDb Workspace-scoped database handle.
 * @param input Original start input.
 * @returns Stored capability call row.
 */
function findCapabilityCallByIdOrIdempotency(
  workspaceDb: WorkspaceDb,
  input: StartCapabilityCallInput
): CapabilityCallRow {
  if (input.requestId) {
    const storedByRequest = workspaceDb.sqlite
      .prepare(
        `SELECT * FROM capability_calls
         WHERE workspace_id = ?
           AND request_id = ?
           AND family = ?
           AND operation = ?
         ORDER BY started_at
         LIMIT 1`
      )
      .get(input.workspaceId, input.requestId, input.family, input.operation) as
      | CapabilityCallRow
      | undefined;

    if (storedByRequest) {
      return storedByRequest;
    }
  }

  if (input.callId) {
    const storedById = findCapabilityCallById(workspaceDb, input.callId);

    if (
      storedById &&
      storedById.workspace_id === input.workspaceId &&
      storedById.request_id === (input.requestId ?? null) &&
      storedById.family === input.family &&
      storedById.operation === input.operation
    ) {
      return storedById;
    }
  }

  throw new Error('Capability call was not stored.');
}

/**
 * Rejects replay when immutable effect attribution differs from the stored call.
 *
 * @param stored Existing capability-call row selected by the idempotency key.
 * @param incoming Protocol-validated incoming capability call.
 * @param input Ledger-only attribution supplied by the producer.
 */
function assertMatchingCapabilityCallAttribution(
  stored: CapabilityCallRow,
  incoming: CapabilityCall,
  input: StartCapabilityCallInput
): void {
  if (
    stored.capability_id !== incoming.capabilityId ||
    stored.thread_id !== incoming.threadId ||
    stored.turn_id !== incoming.turnId ||
    stored.item_id !== incoming.itemId ||
    stored.agent_id !== incoming.agentId ||
    stored.agent_session_id !== incoming.agentSessionId ||
    stored.package_snapshot_id !== incoming.packageSnapshotId ||
    stored.schema_snapshot_id !== incoming.schemaSnapshotId ||
    stored.runtime_origin_ref !== incoming.runtimeOriginRef ||
    stored.runtime_cache_lineage_ref !== incoming.runtimeCacheLineageRef ||
    sourceIdsJson(parseSourceIdsJson(stored.source_ids_json)) !==
      sourceIdsJson(incoming.sourceIds) ||
    stored.provider_ref !== (input.providerRef ?? null) ||
    stored.service_ref !== (input.serviceRef ?? null) ||
    stored.redaction_class !== input.redactionClass
  ) {
    throw new Error('Capability call attribution conflicts with the existing request.');
  }
}

/**
 * Fails closed when an attempted ledger payload contains obvious raw sensitive or payload fields.
 *
 * @param value Value to inspect recursively.
 */
function assertNoUnsafeLedgerValue(value: unknown): void {
  const unsafeKey = findUnsafeLedgerKey(value);

  if (unsafeKey) {
    throw new Error('Capability usage ledger values must be redacted before recording.');
  }
}

/**
 * Finds an unsafe field name in a would-be ledger value.
 *
 * @param value Value to inspect recursively.
 * @returns Unsafe key when present.
 */
function findUnsafeLedgerKey(value: unknown): string | null {
  if (!value || typeof value !== 'object') {
    return null;
  }

  for (const [key, nested] of Object.entries(value)) {
    if (/(prompt|argument|result|secret|token|credential|password|cache[_-]?key)/i.test(key)) {
      return key;
    }

    const nestedKey = findUnsafeLedgerKey(nested);

    if (nestedKey) {
      return nestedKey;
    }
  }

  return null;
}

/** Existing call and Workspace authority supplied to the shared Gateway dispatcher. */
export interface GatewayCallLedgerBinding {
  readonly workspaceDb: WorkspaceDb;
  readonly call: StartedCapabilityCall;
}

/** Appends or settles one entry atomically; the open logical call remains the sole owner. */
export function writeGatewayRouteLineage(
  input: GatewayCallLedgerBinding & {
    readonly logicalModelId: string;
    readonly entry: GatewayRouteLineageEntry;
    readonly entryIndex?: number;
  }
): number {
  return input.workspaceDb.sqlite.transaction(() => {
    const row = findCapabilityCallById(input.workspaceDb, input.call.id);
    if (!row || row.status !== 'running')
      throw new Error('Gateway lineage requires its running CapabilityCall.');
    const extensions = CanonicalCapabilityCallExtensionsSchema.parse(
      row.extensions_json === null ? {} : JSON.parse(row.extensions_json)
    );
    const lineage = extensions['openkit.gateway/routeLineage'] ?? {
      logicalModelId: input.logicalModelId,
      entries: [],
    };
    if (lineage.logicalModelId !== input.logicalModelId)
      throw new Error('Gateway lineage logical model conflicts.');
    const index = input.entryIndex ?? lineage.entries.length;
    if (index > lineage.entries.length || index < 0)
      throw new Error('Gateway lineage entry is missing.');
    lineage.entries[index] = GatewayRouteLineageEntrySchema.parse(input.entry);
    extensions['openkit.gateway/routeLineage'] = lineage;
    input.workspaceDb.sqlite
      .prepare('UPDATE capability_calls SET extensions_json = ? WHERE call_id = ?')
      .run(JSON.stringify(extensions), input.call.id);
    return index;
  })();
}

/** Caller request identities are single-use across running and terminal Gateway calls. */
export function hasCapabilityCallRequestId(
  workspaceDb: WorkspaceDb,
  workspaceId: string,
  requestId: string
): boolean {
  return !!workspaceDb.sqlite
    .prepare('SELECT 1 FROM capability_calls WHERE workspace_id = ? AND request_id = ? LIMIT 1')
    .get(workspaceId, requestId);
}
