import { mkdtempSync, readdirSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, relative } from 'node:path';

import { ApiErrorSchema, PROTOCOL_VERSION } from '@openkit/protocol';
import { describe, expect, it } from 'vitest';
import { openCoreDb } from '../storage/db.js';
import { applyMigrations } from '../storage/migrate.js';
import { createApp } from '../test-support/app.js';
import { actorFromSession } from './identity.js';
import type { BetterAuthServer } from './middleware.js';

/**
 * Lists TypeScript source files recursively.
 *
 * @param root Directory to scan.
 * @returns Absolute TypeScript file paths.
 */
function listSourceFiles(root: string): string[] {
  const files: string[] = [];

  for (const entry of readdirSync(root, { withFileTypes: true })) {
    const path = join(root, entry.name);

    if (entry.isDirectory()) {
      files.push(...listSourceFiles(path));
      continue;
    }

    if (entry.isFile() && path.endsWith('.ts')) {
      files.push(path);
    }
  }

  return files;
}

/**
 * Creates a minimal Better Auth stub for server-mode middleware tests.
 *
 * @param session Session payload returned by getSession.
 * @returns Better Auth-compatible test double.
 */
function createAuthStub(
  session: Awaited<ReturnType<BetterAuthServer['api']['getSession']>>
): BetterAuthServer {
  return {
    api: {
      getSession: async () => session,
    },
    handler: async () => Response.json({ status: 'auth-ok' }),
  };
}

describe('server-mode auth middleware', () => {
  it('rejects protected API routes without a session', async () => {
    const app = createApp({ auth: createAuthStub(null), mode: 'server' });
    const res = await app.request('/api/openapi.json');

    expect(res.status).toBe(401);
    expect(ApiErrorSchema.parse(await res.json())).toEqual({
      protocolVersion: PROTOCOL_VERSION,
      code: 'core.auth.unauthenticated',
      message: 'Authentication required.',
    });
  });

  it('allows protected API routes with a valid session', async () => {
    const app = createApp({
      auth: createAuthStub({
        session: { id: 'session_1' },
        user: { id: 'usr_00000000-0000-7e68-8ab1-8dcac1be1b5b' },
      }),
      mode: 'server',
    });
    const res = await app.request('/api/openapi.json');

    expect(res.status).toBe(200);
  });

  it('rejects a valid Better Auth session when its canonical user is disabled', async () => {
    const coreDb = openCoreDb(mkdtempSync(join(tmpdir(), 'openkit-disabled-session-')));

    try {
      applyMigrations(coreDb);
      const now = Date.now();
      coreDb.sqlite
        .prepare(
          `INSERT INTO users (
            id, display_name, email, email_verified, image, created_at, updated_at, kind,
            last_seen_at, status, disabled_at
          ) VALUES (?, 'Disabled', 'disabled@example.com', false, NULL, ?, ?, 'human', NULL,
            'disabled', '2026-07-19T01:02:03.000Z')`
        )
        .run('usr_00000000-0000-7e63-b85a-c188de8ee1c3', now, now);
      const app = createApp({
        auth: createAuthStub({
          session: { id: 'session_disabled' },
          user: { id: 'usr_00000000-0000-7e63-b85a-c188de8ee1c3' },
        }),
        coreDb,
        mode: 'server',
      });

      expect((await app.request('/api/openapi.json')).status).toBe(401);
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('protects every public LLM Gateway route before request parsing', async () => {
    const app = createApp({ auth: createAuthStub(null), mode: 'server' });

    for (const request of [
      { path: '/v1/models' },
      {
        path: '/v1/chat/completions',
        init: { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{' },
      },
      {
        path: '/v1/responses',
        init: { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{' },
      },
    ]) {
      const res = await app.request(request.path, request.init);

      expect(res.status).toBe(401);
      await expect(res.json()).resolves.toMatchObject({ code: 'core.auth.unauthenticated' });
    }
  });

  it('keeps LLM Gateway routes usable for authenticated server actors and local mode', async () => {
    const serverApp = createApp({
      auth: createAuthStub({
        session: { id: 'session_1' },
        user: { id: 'usr_00000000-0000-7e68-8ab1-8dcac1be1b5b' },
      }),
      mode: 'server',
    });
    const localApp = createApp({ mode: 'local' });

    expect((await serverApp.request('/v1/models')).status).toBe(200);
    expect((await localApp.request('/v1/models')).status).toBe(200);
  });

  it('keeps reduced public meta, health, and Better Auth routes open', async () => {
    const app = createApp({ auth: createAuthStub(null), mode: 'server' });

    const metaRes = await app.request('/api/meta');
    const healthRes = await app.request('/api/health');
    const authRes = await app.request('/api/auth/ok');

    expect(metaRes.status).toBe(200);
    expect(await metaRes.json()).toEqual({
      protocolVersion: '0.6.0',
      capabilities: [],
      eventFamilies: [],
    });
    expect(healthRes.status).toBe(200);
    expect(authRes.status).toBe(200);
  });

  it('maps Better Auth sessions through the identity facade', () => {
    expect(actorFromSession({ user: { id: 'usr_00000000-0000-7e68-8ab1-8dcac1be1b5b' } })).toEqual({
      userId: 'usr_00000000-0000-7e68-8ab1-8dcac1be1b5b',
      kind: 'session',
    });
  });

  it('keeps Better Auth imports isolated to auth modules', () => {
    const sourceRoot = join(process.cwd(), 'src');
    const offenders = listSourceFiles(sourceRoot)
      .filter((path) => !relative(sourceRoot, path).startsWith('auth/'))
      .filter((path) => /from ['"]@?better-auth/.test(readFileSync(path, 'utf8')))
      .map((path) => relative(process.cwd(), path));

    expect(offenders).toEqual([]);
  });
});
