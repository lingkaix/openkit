import { OPERATION_DEFINITIONS } from '@openkit/app-api-schemas';
import { type ActorRef, responsibleUserIdForActor, WorkspaceIdSchema } from '@openkit/protocol';
import type { Context, Hono } from 'hono';
import { HTTPException } from 'hono/http-exception';
import { z } from 'zod';

import { asApiError } from '../api-errors.js';
import type { FsStore } from '../lib/store.js';
import { APP_OPENAPI_ROUTE_METHODS, createAppOpenApiDocument } from '../openapi.js';
import { evaluateWorkspaceRoleAccess, type ProductOperation } from '../policy/workspace-access.js';
import {
  findSchedulerAdmissionForTurn,
  findSchedulerAdmissionForWorkerLineage,
  type SchedulerAdmissionEntryRecord,
  type SchedulerExecutionLineage,
} from '../scheduler-records.js';
import type { CoreDb } from '../storage/db.js';
import {
  ensureUserQuickChatWorkspace,
  listActiveWorkspaceIds,
  listActiveWorkspaceIdsForActor,
  resolveWorkspaceRole,
  type WorkspaceRole,
} from '../workspace-membership.js';
import type { WorkspaceMutationAdmission } from '../workspace-mutation-admission.js';
import { evaluateOpenKitAccessTokenUsability } from './access-token.js';
import {
  listOpenKitAccessTokenRecords,
  resolveSessionDeploymentAdminTokenId,
} from './access-token-store.js';
import type { Actor } from './identity.js';
import type { AuthVariables } from './middleware.js';
import {
  PUBLIC_OPERATION_ACCESS,
  type PublicOperationAccess,
  type WorkspaceOperationAccess,
} from './operation-access.js';
import { isThreadIdVisible } from './thread-visibility.js';
import { isCanonicalUserActive } from './user-lifecycle.js';

const GatewayWorkspaceAttributionSchema = z
  .object({
    metadata: z
      .object({
        openkit: z
          .object({
            workspaceId: WorkspaceIdSchema.optional(),
          })
          .passthrough()
          .optional(),
      })
      .passthrough()
      .optional(),
  })
  .passthrough();

/** Authorized Workspace context exposed to one guarded handler. */
export type WorkspaceAccess =
  | {
      /** Single-Workspace authorization result. */
      readonly kind: 'workspace';
      /** Canonical authorized Workspace id. */
      readonly workspaceId: string;
      /** Effective fixed role derived from current Core facts. */
      readonly effectiveRole: WorkspaceRole;
      /** Product operation allowed by the policy adapter. */
      readonly policyOperation: ProductOperation;
    }
  | {
      /** Multi-Workspace collection authorization result. */
      readonly kind: 'workspace-set';
      /** Canonical authorized Workspace ids. */
      readonly workspaceIds: string[];
      /** Product operation allowed for every returned Workspace. */
      readonly policyOperation: ProductOperation;
    };

/** Dependencies for exact public-operation authorization guards. */
export interface RegisterOperationAccessGuardsInput {
  /** Hono app receiving guards before public handlers are registered. */
  readonly app: Hono<{ Variables: AuthVariables }>;
  /** Core database owning Workspace registry and membership authority. */
  readonly coreDb: CoreDb;
  /** Derives the built-in Quick Chat Workspace for one canonical user. */
  readonly quickChatWorkspaceIdForUser: (userId: string) => string;
  /** Existing Workspace record owner used for opaque child lineage. */
  readonly store: FsStore;
  /** Process-local owner that fences ordinary Workspace mutations during deletion. */
  readonly workspaceMutationAdmission: WorkspaceMutationAdmission;
}

/** Current non-secret deployment-administrator authority proved from durable Token state. */
export interface CurrentDeploymentAdminAuthority {
  /** Token id that currently grants server administration, absent only in local mode. */
  readonly tokenId: string | null;
  /** Canonical user that owns the authority. */
  readonly userId: string;
}

/** Raised when an operation has no current usable deployment-administrator authority. */
export class DeploymentAdminRequiredError extends Error {
  public constructor() {
    super('Current deployment administrator authority is required.');
    this.name = 'DeploymentAdminRequiredError';
  }
}

/**
 * Rechecks current deployment-administrator authority from durable user and Token owners.
 *
 * @param coreDb Core identity and Token authority.
 * @param actor Authenticated request actor whose authority must still be usable.
 * @param now Current time for Token expiration and rotation-grace evaluation.
 * @returns Current non-secret administrator authority.
 * @throws DeploymentAdminRequiredError when the actor or its current Token authority is unusable.
 */
export function requireCurrentDeploymentAdmin(
  coreDb: CoreDb,
  actor: Actor | undefined,
  now = new Date()
): CurrentDeploymentAdminAuthority {
  if (!actor || !isCanonicalUserActive(coreDb, actor.userId)) {
    throw new DeploymentAdminRequiredError();
  }
  if (actor.kind === 'local') {
    return { tokenId: null, userId: actor.userId };
  }
  if (actor.kind === 'session') {
    const tokenId = resolveSessionDeploymentAdminTokenId(coreDb, actor.userId, now);
    if (tokenId) {
      return { tokenId, userId: actor.userId };
    }
    throw new DeploymentAdminRequiredError();
  }
  const token = actor.tokenId
    ? listOpenKitAccessTokenRecords(coreDb).find((candidate) => candidate.tokenId === actor.tokenId)
    : undefined;
  if (
    token?.ownerUserId === actor.userId &&
    token.scope === 'server-admin' &&
    actor.tokenScope === 'server-admin' &&
    evaluateOpenKitAccessTokenUsability(token, now).usable
  ) {
    return { tokenId: token.tokenId, userId: actor.userId };
  }
  throw new DeploymentAdminRequiredError();
}

/** One exact method and Hono path owned by a catalog operation. */
interface OperationRoute {
  /** Explicit access declaration for the operation. */
  readonly access: PublicOperationAccess;
  /** Uppercase HTTP method. */
  readonly method: string;
  /** Canonical App operation id or direct route key. */
  readonly operationKey: string;
  /** Hono path with colon-prefixed parameters. */
  readonly path: string;
}

/** One successful single-Workspace policy result. */
interface AuthorizedWorkspace {
  /** Effective fixed role. */
  readonly effectiveRole: WorkspaceRole;
  /** Canonical Workspace id. */
  readonly workspaceId: string;
}

/**
 * Registers exact catalog-driven authorization guards before public handlers.
 *
 * @param input Existing authorization, storage, and lineage owners.
 * @throws When catalog metadata cannot be mapped to one unique canonical route.
 */
export function registerOperationAccessGuards(input: RegisterOperationAccessGuardsInput): void {
  const routesByPath = new Map<string, Map<string, OperationRoute>>();

  for (const route of guardedOperationRoutes()) {
    const methods = routesByPath.get(route.path) ?? new Map<string, OperationRoute>();
    if (methods.has(route.method)) {
      throw new Error(`Duplicate guarded public route: ${route.method} ${route.path}.`);
    }
    methods.set(route.method, route);
    routesByPath.set(route.path, methods);
  }

  for (const [path, methods] of routesByPath) {
    input.app.use(path, async (context, next) => {
      const route = methods.get(context.req.method.toUpperCase());
      if (!route) {
        await next();
        return;
      }

      const denied = await authorizeOperation(context, route, input);
      if (denied) {
        return denied;
      }
      const access = context.get('workspaceAccess');
      const workspaceId = access?.kind === 'workspace' ? access.workspaceId : null;
      if (!workspaceId) {
        await next();
        return;
      }
      if (input.workspaceMutationAdmission.isClosed(workspaceId)) {
        return workspaceAccessDenied();
      }
      if (!route.access.mutating) {
        await next();
        return;
      }
      const release = input.workspaceMutationAdmission.enter(workspaceId);
      if (!release) {
        return workspaceAccessDenied();
      }
      try {
        await next();
      } finally {
        release();
      }
    });
  }
}

/**
 * Requires a handler-owned child to belong to its already authorized Workspace.
 *
 * @param access Central authorization result from request context.
 * @param actualWorkspaceId Workspace id read from the child record owner, or null when its scoped owner cannot distinguish missing from mismatched lineage.
 * @throws HTTPException carrying the uniform Workspace access denial response on mismatch.
 */
export function assertAuthorizedWorkspaceLineage(
  access: WorkspaceAccess | undefined,
  actualWorkspaceId: string | null
): asserts access is Extract<WorkspaceAccess, { kind: 'workspace' }> {
  if (access?.kind !== 'workspace' || access.workspaceId !== actualWorkspaceId) {
    throw new HTTPException(403, { res: workspaceAccessDenied() });
  }
}

/**
 * Evaluates an additional Workspace through the same actor and policy intersection as a guarded request.
 *
 * @param coreDb Core Workspace authority.
 * @param actor Authenticated request actor.
 * @param workspaceId Canonical Workspace id.
 * @param access Exact product operation and mutation posture.
 * @returns True only when the central Workspace predicate allows the operation.
 */
export function isWorkspaceOperationAuthorized(
  coreDb: CoreDb,
  actor: Actor,
  workspaceId: string,
  access: Pick<PublicOperationAccess, 'mutating' | 'policyOperation'> & {
    readonly authentication?: PublicOperationAccess['authentication'];
  }
): boolean {
  return authorizeWorkspace(coreDb, actor, workspaceId, access) !== null;
}

/**
 * Composes current Workspace authority from one actor, fixed role, policy operation, and caller-owned effect authority.
 *
 * @param coreDb Core Workspace authority.
 * @param workspaceId Canonical target Workspace id.
 * @param actor Immutable actor responsible for the effect.
 * @param operation Concrete product operation, including unknown values that must fail closed.
 * @param effectAuthority Whether the caller's existing effect-specific authority remains valid.
 * @param requestActor Optional authenticating request actor; a presented usable server-admin bearer grants owner authority without membership.
 * @returns The current effective Workspace role, or null when any authority component denies the effect.
 */
export function currentWorkspaceAuthority(
  coreDb: CoreDb,
  workspaceId: string,
  actor: ActorRef,
  operation: string,
  effectAuthority: boolean,
  requestActor?: Actor
): WorkspaceRole | null {
  if (!effectAuthority) {
    return null;
  }
  if (requestActor?.kind === 'token' && requestActor.tokenScope === 'server-admin') {
    if (
      actor.kind !== 'user' ||
      actor.id !== requestActor.userId ||
      !isUsablePresentedServerAdminToken(coreDb, requestActor) ||
      !isActiveRegisteredWorkspace(coreDb, workspaceId)
    ) {
      return null;
    }
    const role: WorkspaceRole = 'owner';
    return evaluateWorkspaceRoleAccess({ operation, role }).effect === 'allow' ? role : null;
  }
  const responsibleUserId = responsibleUserIdForActor(actor);
  if (!responsibleUserId) {
    return null;
  }
  const role = resolveWorkspaceRole(coreDb, workspaceId, responsibleUserId);
  if (!role || evaluateWorkspaceRoleAccess({ operation, role }).effect !== 'allow') {
    return null;
  }
  return role;
}

/**
 * Rechecks one durable admission's presented administrator token before a scheduler or Worker effect.
 *
 * @param coreDb Core Workspace and Token authority.
 * @param admission Exact originating admission context.
 * @param operation Product operation being attempted now.
 * @param effectAuthority Caller-owned effect authority.
 * @returns Current Workspace role, or null if a recorded token is no longer usable.
 */
export function currentSchedulerAdmissionWorkspaceAuthority(
  coreDb: CoreDb,
  admission: Pick<
    SchedulerAdmissionEntryRecord,
    'workspaceId' | 'triggerActor' | 'serverAdminTokenId'
  >,
  operation: string,
  effectAuthority: boolean
): WorkspaceRole | null {
  if (admission.serverAdminTokenId === null) {
    return currentWorkspaceAuthority(
      coreDb,
      admission.workspaceId,
      admission.triggerActor,
      operation,
      effectAuthority
    );
  }
  if (admission.serverAdminTokenId.length === 0 || admission.triggerActor.kind !== 'user') {
    return null;
  }
  const requestActor: Actor = {
    kind: 'token',
    tokenId: admission.serverAdminTokenId,
    tokenScope: 'server-admin',
    userId: admission.triggerActor.id,
  };
  return currentWorkspaceAuthority(
    coreDb,
    admission.workspaceId,
    admission.triggerActor,
    operation,
    effectAuthority,
    requestActor
  );
}

/**
 * Rechecks current authority from the exact lease and package that own a Worker effect.
 *
 * @param coreDb Core Workspace, lease, and Token authority.
 * @param lineage Worker package lineage and its immutable trigger actor.
 * @param operation Product operation being attempted now.
 * @param effectAuthority Caller-owned effect authority.
 * @returns Current Workspace role, or null when lineage or current authority is invalid.
 */
export function currentWorkerLineageWorkspaceAuthority(
  coreDb: CoreDb,
  lineage: SchedulerExecutionLineage & { readonly triggerActor: ActorRef },
  operation: string,
  effectAuthority: boolean
): WorkspaceRole | null {
  const admission = findSchedulerAdmissionForWorkerLineage(coreDb, lineage);
  if (!admission || !sameActorRef(admission.triggerActor, lineage.triggerActor)) {
    return null;
  }
  return currentSchedulerAdmissionWorkspaceAuthority(coreDb, admission, operation, effectAuthority);
}

/**
 * Rechecks a product Turn's exact live admission before its Worker lease is created.
 *
 * @param coreDb Core Workspace and admission authority.
 * @param lineage Exact product Turn and trigger actor.
 * @param operation Product operation being attempted now.
 * @param effectAuthority Caller-owned effect authority.
 * @returns Current Workspace role, or null when the live admission or actor differs.
 */
export function currentScheduledTurnWorkspaceAuthority(
  coreDb: CoreDb,
  lineage: {
    readonly workspaceId: string;
    readonly threadId: string;
    readonly turnId: string;
    readonly triggerActor: ActorRef;
  },
  operation: string,
  effectAuthority: boolean
): WorkspaceRole | null {
  const admission = findSchedulerAdmissionForTurn(coreDb, lineage);
  if (!admission || !sameActorRef(admission.triggerActor, lineage.triggerActor)) {
    return null;
  }
  return currentSchedulerAdmissionWorkspaceAuthority(coreDb, admission, operation, effectAuthority);
}

/** Compares immutable ActorRef fields without relying on JSON key order. */
function sameActorRef(left: ActorRef, right: ActorRef): boolean {
  return (
    left.kind === right.kind &&
    left.id === right.id &&
    (left.kind === 'user' ||
      (right.kind !== 'user' && left.responsibleUserId === right.responsibleUserId))
  );
}

/**
 * Authorizes one exact catalog operation and installs its bounded context result.
 *
 * @param context Authenticated Hono request context.
 * @param route Exact catalog route and access metadata.
 * @param input Existing authorization and lineage owners.
 * @returns Uniform denial response, or null after successful authorization.
 */
async function authorizeOperation(
  context: Context<{ Variables: AuthVariables }>,
  route: OperationRoute,
  input: RegisterOperationAccessGuardsInput
): Promise<Response | null> {
  const actor = context.get('actor');
  if (!actor) {
    return workspaceAccessDenied();
  }

  if (route.access.scope === 'user') {
    if (route.access.authentication === 'canonical-user') {
      return isCanonicalUserOperationAuthorized(input.coreDb, actor)
        ? null
        : workspaceAccessDenied();
    }
    return authorizeGatewayOperation(context, actor, route.access, input.coreDb);
  }
  if (route.access.scope !== 'workspace') {
    return null;
  }
  if (route.access.authentication === 'deployment-admin') {
    try {
      requireCurrentDeploymentAdmin(input.coreDb, actor);
    } catch (error) {
      if (error instanceof DeploymentAdminRequiredError) {
        return workspaceAccessDenied();
      }
      throw error;
    }
  }

  return authorizeWorkspaceOperation(context, actor, { ...route, access: route.access }, input);
}

/** Reuses canonical-user admission, including current administrator eligibility, without Workspace membership. */
export function isCanonicalUserOperationAuthorized(coreDb: CoreDb, actor: Actor): boolean {
  if (!isCanonicalUserActive(coreDb, actor.userId)) return false;
  return (
    actor.kind === 'local' ||
    actor.kind === 'session' ||
    isCurrentDeploymentAdministrator(coreDb, actor)
  );
}

/**
 * Applies optional public Gateway attribution without inventing a top-level fallback.
 *
 * @param context Authenticated Gateway request context.
 * @param actor Authenticated request actor.
 * @param access Gateway operation metadata.
 * @param coreDb Core Workspace authority.
 * @returns Uniform denial response, or null after successful optional attribution.
 */
async function authorizeGatewayOperation(
  context: Context<{ Variables: AuthVariables }>,
  actor: Actor,
  access: Extract<PublicOperationAccess, { authentication: 'gateway-actor' }>,
  coreDb: CoreDb
): Promise<Response | null> {
  const workspaceId = await gatewayWorkspaceId(context);
  if (workspaceId === null) {
    return workspaceAccessDenied();
  }
  if (workspaceId === undefined) {
    return actor.kind === 'local' ||
      actor.kind === 'session' ||
      (actor.kind === 'token' && actor.tokenScope === 'server-admin')
      ? null
      : workspaceAccessDenied();
  }

  const authorized = authorizeWorkspace(coreDb, actor, workspaceId, access);
  if (!authorized) {
    return workspaceAccessDenied();
  }
  context.set('workspaceAccess', {
    ...authorized,
    kind: 'workspace',
    policyOperation: access.policyOperation,
  });
  return null;
}

/**
 * Resolves and authorizes one direct Workspace operation.
 *
 * @param context Authenticated request context.
 * @param actor Authenticated request actor.
 * @param route Exact operation route.
 * @param input Existing authorization and lineage owners.
 * @returns Uniform denial response, or null after successful authorization.
 */
async function authorizeWorkspaceOperation(
  context: Context<{ Variables: AuthVariables }>,
  actor: Actor,
  route: OperationRoute & { readonly access: WorkspaceOperationAccess },
  input: RegisterOperationAccessGuardsInput
): Promise<Response | null> {
  if (route.access.resolver === 'authorized-workspace-set') {
    if (readonlyTokenCannotMutate(actor, route.access)) {
      return workspaceAccessDenied();
    }
    const workspaceIds = authorizedWorkspaceSet(
      input.coreDb,
      actor,
      route.access,
      input.workspaceMutationAdmission
    );
    context.set('workspaceAccess', {
      kind: 'workspace-set',
      policyOperation: route.access.policyOperation,
      workspaceIds,
    });
    return null;
  }

  const workspaceId = await resolveWorkspaceId(context, actor, route, input);
  if (!workspaceId) {
    return workspaceAccessDenied();
  }
  const authorized = authorizeWorkspace(input.coreDb, actor, workspaceId, route.access);
  if (
    !authorized ||
    (route.access.resolver === 'actor-quick-chat-workspace' && authorized.effectiveRole !== 'owner')
  ) {
    return workspaceAccessDenied();
  }
  context.set('workspaceAccess', {
    ...authorized,
    kind: 'workspace',
    policyOperation: route.access.policyOperation,
  });
  return denyIfThreadInaccessible(context, actor, input, authorized.workspaceId);
}

/** Checks current original-owner or administrator authority; the deletion owner still requires the exact recorded request. */
export function hasWorkspaceDeletionRetryAuthority(
  coreDb: CoreDb,
  actor: Actor,
  workspaceId: string
): boolean {
  if (!isCanonicalUserActive(coreDb, actor.userId) || !isUsablePresentedAccessToken(coreDb, actor))
    return false;
  if (actor.kind === 'token' && !isUsablePresentedServerAdminToken(coreDb, actor)) {
    if (actor.tokenScope !== 'workspace' || !actor.tokenWorkspaceIds?.includes(workspaceId)) {
      return false;
    }
  }
  const row = coreDb.sqlite
    .prepare(
      `SELECT registry.owner_user_id AS ownerUserId, registry.status, users.status AS userStatus
       FROM workspace_registry AS registry
       INNER JOIN users ON users.id = registry.owner_user_id
       WHERE registry.workspace_id = ?`
    )
    .get(workspaceId) as
    | { ownerUserId: string; status: 'active' | 'deleting' | 'deleted'; userStatus: string }
    | undefined;
  return (
    (row?.ownerUserId === actor.userId || isCurrentDeploymentAdministrator(coreDb, actor)) &&
    row?.userStatus === 'active' &&
    (row.status === 'deleting' || row.status === 'deleted')
  );
}

/**
 * Resolves one operation's Workspace through its declared owner shape.
 * A usable administrator bearer establishes only its own actor-derived Quick Chat home.
 *
 * @param context Authenticated request context.
 * @param actor Authenticated request actor.
 * @param route Exact Workspace operation route.
 * @param input Existing lineage owners.
 * @returns Canonical Workspace id, or null when exact lineage cannot be established.
 */
async function resolveWorkspaceId(
  context: Context<{ Variables: AuthVariables }>,
  actor: Actor,
  route: OperationRoute & { readonly access: WorkspaceOperationAccess },
  input: RegisterOperationAccessGuardsInput
): Promise<string | null> {
  try {
    switch (route.access.resolver) {
      case 'actor-quick-chat-workspace':
        if (isUsablePresentedServerAdminToken(input.coreDb, actor)) {
          ensureUserQuickChatWorkspace({
            coreDb: input.coreDb,
            store: input.store,
            userId: actor.userId,
          });
        }
        return input.quickChatWorkspaceIdForUser(actor.userId);
      case 'body-workspace':
      case 'opaque-child-workspace':
        // These migrated selectors are admitted by native operation invocation.
        return null;
      case 'path-workspace':
      case 'workspace-child-lineage':
        return nonempty(context.req.param('workspaceId'));
      case 'authorized-workspace-set':
        return null;
    }
  } catch {
    return null;
  }
}

/**
 * Authorizes one Workspace against current membership, credential, and policy facts.
 *
 * @param coreDb Core Workspace authority.
 * @param actor Authenticated request actor.
 * @param workspaceId Canonical target Workspace id.
 * @param access Exact operation metadata.
 * @returns Authorized Workspace and effective role, or null on any denial.
 */
export function authorizeWorkspace(
  coreDb: CoreDb,
  actor: Actor,
  workspaceId: string,
  access: Pick<PublicOperationAccess, 'mutating' | 'policyOperation'> & {
    readonly authentication?: PublicOperationAccess['authentication'];
  }
): AuthorizedWorkspace | null {
  if (readonlyTokenCannotMutate(actor, access)) {
    return null;
  }
  if (isCurrentDeploymentAdministrator(coreDb, actor)) {
    if (!isActiveRegisteredWorkspace(coreDb, workspaceId)) {
      return null;
    }
    return { effectiveRole: 'owner', workspaceId };
  }
  if (!isUsablePresentedAccessToken(coreDb, actor)) {
    return null;
  }
  if (!tokenIncludesWorkspace(actor, workspaceId, access.authentication)) {
    return null;
  }
  const effectiveRole = currentWorkspaceAuthority(
    coreDb,
    workspaceId,
    { kind: 'user', id: actor.userId },
    access.policyOperation,
    true
  );
  if (!effectiveRole) {
    return null;
  }
  return { effectiveRole, workspaceId };
}

/**
 * Applies Thread audience after current Workspace eligibility for any addressed existing Thread.
 *
 * Missing, corrupt, Workspace-mismatched, and inaccessible Threads fail as the same 404 before disclosure or effect. The check is independent of the catalog policy operation, including writes.
 *
 * @param context Authenticated request context.
 * @param actor Authenticated request actor.
 * @param input Existing lineage owners.
 * @param workspaceId Already authorized Workspace id.
 * @returns Uniform Thread-not-found response, or null when the operation does not address a Thread or the actor may see it.
 */
function denyIfThreadInaccessible(
  context: Context<{ Variables: AuthVariables }>,
  actor: Actor,
  input: RegisterOperationAccessGuardsInput,
  workspaceId: string
): Response | null {
  const threadId = nonempty(context.req.param('threadId'));
  if (threadId === null) {
    return null;
  }
  if (isThreadIdVisible(input.store, workspaceId, threadId, actor.userId)) {
    return null;
  }
  return threadNotFound();
}

/**
 * Reads optional Workspace attribution only from `metadata.openkit.workspaceId`.
 *
 * @param context Public Gateway request context.
 * @returns Canonical Workspace id, undefined when absent, or null when malformed.
 */
async function gatewayWorkspaceId(
  context: Context<{ Variables: AuthVariables }>
): Promise<string | null | undefined> {
  const parsed = GatewayWorkspaceAttributionSchema.safeParse(
    await context.req.raw
      .clone()
      .json()
      .catch(() => null)
  );
  return parsed.success ? parsed.data.metadata?.openkit?.workspaceId : null;
}

/**
 * True when the actor is a presented usable server-admin bearer token.
 *
 * Session-derived deployment administration does not qualify; only the bearer itself does.
 *
 * @param coreDb Core identity and Token authority.
 * @param actor Authenticated request actor.
 * @param now Current time for Token usability evaluation.
 * @returns True only for a usable presented server-admin Token actor.
 */
export function isUsablePresentedServerAdminToken(
  coreDb: CoreDb,
  actor: Actor,
  now = new Date()
): boolean {
  return (
    actor.kind === 'token' &&
    actor.tokenScope === 'server-admin' &&
    isUsablePresentedAccessToken(coreDb, actor, now)
  );
}

/**
 * Rechecks current presented OpenKit access-token usability from durable Token state.
 *
 * Session and local actors have no bearer to revalidate here. A presented workspace or
 * workspace-readonly Token must still match its owner, exact scope, and current usability.
 *
 * @param coreDb Core identity and Token authority.
 * @param actor Authenticated request actor.
 * @param now Current time for Token usability evaluation.
 * @returns True when the actor is not a bearer, or when the presented Token remains usable.
 */
function isUsablePresentedAccessToken(coreDb: CoreDb, actor: Actor, now = new Date()): boolean {
  if (actor.kind !== 'token') {
    return true;
  }
  if (!actor.tokenId || !actor.tokenScope) {
    return false;
  }
  if (!isCanonicalUserActive(coreDb, actor.userId)) {
    return false;
  }
  const token = listOpenKitAccessTokenRecords(coreDb).find(
    (candidate) => candidate.tokenId === actor.tokenId
  );
  return (
    token?.ownerUserId === actor.userId &&
    token.scope === actor.tokenScope &&
    evaluateOpenKitAccessTokenUsability(token, now).usable
  );
}

/**
 * True when the Workspace registry currently marks the id as active.
 *
 * @param coreDb Core Workspace authority.
 * @param workspaceId Canonical Workspace id.
 * @returns True only for an active registry row.
 */
function isActiveRegisteredWorkspace(coreDb: CoreDb, workspaceId: string): boolean {
  const row = coreDb.sqlite
    .prepare('SELECT status FROM workspace_registry WHERE workspace_id = ?')
    .get(workspaceId) as { status: string } | undefined;
  return row?.status === 'active';
}

/**
 * Checks one token's exact Workspace binding while leaving session and local actors unbounded.
 *
 * @param actor Authenticated request actor.
 * @param workspaceId Canonical target Workspace id.
 * @returns True when the actor's credential may address the Workspace.
 */
function tokenIncludesWorkspace(
  actor: Actor,
  workspaceId: string,
  authentication: PublicOperationAccess['authentication']
): boolean {
  if (actor.kind !== 'token') {
    return true;
  }
  if (actor.tokenScope === 'server-admin') {
    return authentication === 'deployment-admin';
  }
  if (actor.tokenScope !== 'workspace' && actor.tokenScope !== 'workspace-readonly') {
    return false;
  }
  return actor.tokenWorkspaceIds?.includes(workspaceId) === true;
}

/**
 * Checks the catalog mutation posture against a readonly token.
 *
 * @param actor Authenticated request actor.
 * @param access Exact operation metadata.
 * @returns True when a readonly credential cannot invoke the declared mutation.
 */
function readonlyTokenCannotMutate(
  actor: Actor,
  access: Pick<PublicOperationAccess, 'mutating'>
): boolean {
  return actor.kind === 'token' && actor.tokenScope === 'workspace-readonly' && access.mutating;
}

/**
 * Maps retained routes to guards. Canonical operation routes perform native admission, including bounded streaming metadata.
 *
 * @returns Unique retained non-server operation routes.
 * @throws When a catalog operation has no canonical route owner.
 */
function guardedOperationRoutes(): OperationRoute[] {
  const appRoutes = appOperationRoutes();
  const routes: OperationRoute[] = [];

  for (const [operationKey, access] of Object.entries(PUBLIC_OPERATION_ACCESS)) {
    if (
      access.scope === 'server' ||
      (Object.hasOwn(OPERATION_DEFINITIONS, operationKey) &&
        OPERATION_DEFINITIONS[operationKey as keyof typeof OPERATION_DEFINITIONS].binding ===
          'json')
    ) {
      continue;
    }
    const direct = directOperationRoute(operationKey);
    const route = direct ?? appRoutes.get(operationKey);
    if (!route) {
      throw new Error(`Public operation has no canonical route: ${operationKey}.`);
    }
    // Canonical operation routes admit their parsed selectors before reading a body stream.
    // Retained archive paths continue to use the guards below.
    if (route.path === `/api/app/operations/${operationKey}`) continue;
    routes.push({ ...route, access, operationKey });
  }
  return routes;
}

/**
 * Builds canonical App operation routes from the OpenAPI owner.
 *
 * @returns Operation id to method and Hono path mapping.
 * @throws When the OpenAPI owner contains a duplicate operation id.
 */
function appOperationRoutes(): Map<string, Pick<OperationRoute, 'method' | 'path'>> {
  const routes = new Map<string, Pick<OperationRoute, 'method' | 'path'>>();
  const document = createAppOpenApiDocument();

  for (const [openApiPath, pathItem] of Object.entries(document.paths)) {
    for (const method of APP_OPENAPI_ROUTE_METHODS) {
      const operation = (pathItem as Readonly<Record<string, unknown>>)[method];
      if (!operation || typeof operation !== 'object' || Array.isArray(operation)) {
        continue;
      }
      const operationId = (operation as Readonly<Record<string, unknown>>).operationId;
      if (typeof operationId !== 'string' || routes.has(operationId)) {
        throw new Error(`Invalid or duplicate App operation id at ${method} ${openApiPath}.`);
      }
      routes.set(operationId, {
        method: method.toUpperCase(),
        path: openApiPath.replace(/\{([A-Za-z0-9_]+)\}/g, ':$1'),
      });
    }
  }
  return routes;
}

/**
 * Parses an explicit direct route key from the catalog.
 *
 * @param operationKey Catalog operation key.
 * @returns Direct method and Hono path, or null for an App operation id.
 */
function directOperationRoute(
  operationKey: string
): Pick<OperationRoute, 'method' | 'path'> | null {
  const match = /^([A-Z]+) (\/.*)$/.exec(operationKey);
  return match ? { method: match[1] ?? '', path: match[2] ?? '' } : null;
}

/**
 * Normalizes one required route-derived identifier.
 *
 * @param value Raw route parameter.
 * @returns Non-empty value, or null.
 */
function nonempty(value: string | undefined): string | null {
  return value && value.length > 0 ? value : null;
}

/** Returns the uniform non-enumerating Workspace access failure. */
function workspaceAccessDenied(): Response {
  return asApiError('Workspace access denied.', 'workspace_access_denied', 403);
}

/** Returns the uniform missing-or-inaccessible Thread failure. */
function threadNotFound(): Response {
  return asApiError('Thread not found.', 'not_found', 404);
}

/** Checks the existing current-administrator owner without treating unpresented Tokens as authority. */
export function isCurrentDeploymentAdministrator(coreDb: CoreDb, actor: Actor): boolean {
  try {
    requireCurrentDeploymentAdmin(coreDb, actor);
    return true;
  } catch (error) {
    if (error instanceof DeploymentAdminRequiredError) return false;
    throw error;
  }
}

/** Candidate-first collection admission shared by catalog guards and native operation invocation. */
export function authorizedWorkspaceSet(
  coreDb: CoreDb,
  actor: Actor,
  access: Pick<PublicOperationAccess, 'mutating' | 'policyOperation'>,
  admission: WorkspaceMutationAdmission
): string[] {
  const candidates = isCurrentDeploymentAdministrator(coreDb, actor)
    ? listActiveWorkspaceIds(coreDb)
    : listActiveWorkspaceIdsForActor(coreDb, actor.userId);
  return candidates.filter(
    (workspaceId) =>
      !admission.isClosed(workspaceId) &&
      authorizeWorkspace(coreDb, actor, workspaceId, access) !== null
  );
}
