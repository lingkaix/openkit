import { allocateEntityId } from '@openkit/protocol';
import { recordServerAuditEvent } from '../audit-events.js';
import type { Actor } from '../auth/identity.js';
import type { CoreDb } from '../storage/db.js';
import type { VaultBackendKind } from './vault-backend.js';

/** Input for recording one server-owned vault admin audit event. */
export interface RecordVaultAdminAuditEventInput {
  /** Server-scope database that owns the event. */
  readonly coreDb: CoreDb;
  /** Stable audit event id for deterministic tests. */
  readonly auditEventId?: string;
  /** Actor that requested the admin operation. */
  readonly actor?: Actor;
  /** Stable admin action name. */
  readonly action:
    | `vault.workspace_${'create' | 'rotate' | 'revoke' | 'grant' | 'revoke-grant' | 'narrow-grant'}`
    | 'vault.unlock'
    | 'vault.lock'
    | 'vault.bootstrap_codex_auth_json'
    | 'vault.set_provider_api_key'
    | 'vault.rebind_workspace_reference';
  /** Event outcome. */
  readonly outcome: 'succeeded' | 'failed' | 'denied';
  /** Event severity. */
  readonly severity?: 'info' | 'warning' | 'error';
  /** Redacted event summary. */
  readonly summary: string;
  /** Stable error code when applicable. */
  readonly errorCode?: string | null;
  /** Backend kind administered by the action. */
  readonly backendKind: VaultBackendKind;
  /** Exact affected Workspace when the administrative effect is Workspace-scoped. */
  readonly workspaceId?: string;
  /** Grant created by the administrative effect, when applicable. */
  readonly vaultGrantId?: string;
  /** Exact redacted source resource, including a replaced grant when applicable. */
  readonly resource?: string;
  /** Event creation time. */
  readonly now?: Date;
}

/**
 * Records one durable server-scope vault admin audit event.
 *
 * @param input Vault admin audit event input.
 */
export function recordVaultAdminAuditEvent(input: RecordVaultAdminAuditEventInput): void {
  const auditEventId = input.auditEventId ?? allocateEntityId('aud');
  const severity = input.severity ?? (input.outcome === 'succeeded' ? 'info' : 'warning');
  const now = input.now ?? new Date();

  input.coreDb.sqlite
    .prepare(
      `INSERT INTO vault_admin_audit_events (
        audit_event_id,
        actor_user_id,
        actor_kind,
        action,
        outcome,
        severity,
        summary,
        error_code,
        backend_kind,
        created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      auditEventId,
      input.actor?.userId ?? null,
      input.actor?.kind ?? null,
      input.action,
      input.outcome,
      severity,
      input.summary,
      input.errorCode ?? null,
      input.backendKind,
      now.toISOString()
    );

  recordServerAuditEvent({
    actor: input.actor ? { kind: 'user', id: input.actor.userId } : null,
    action: input.action,
    auditEventId,
    category: 'system',
    coreDb: input.coreDb,
    errorCode: input.errorCode ?? null,
    now,
    outcome: input.outcome,
    resource: input.resource ?? `vault:${input.backendKind}`,
    workspaceId: input.workspaceId ?? null,
    vaultGrantId: input.vaultGrantId ?? null,
    severity,
    summary: input.summary,
  });
}
