import { existsSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { VaultBackendError } from './vault-backend.js';
import { createVaultUnlockState } from './vault-unlock-state.js';

describe('vault unlock state', () => {
  it('starts locked, unlocks an encrypted-file backend, and locks again', () => {
    const storeDir = mkdtempSync(join(tmpdir(), 'openkit-vault-unlock-'));
    const masterKey = Buffer.alloc(32, 9);
    const state = createVaultUnlockState({
      backendKind: 'encrypted-file',
      storeDir,
    });

    expect(state.backend().health()).toEqual({
      diagnostic: 'Vault backend is locked.',
      kind: 'encrypted-file',
      state: 'locked',
    });
    expect(() =>
      state.backend().resolve({ referenceId: 'vault_00000000-0000-7f73-bffa-d96a61ee4d70' })
    ).toThrow('vault-locked');

    const unlocked = state.unlock({
      masterKey,
    });

    expect(unlocked.health()).toEqual({
      diagnostic: 'encrypted-file vault backend is unlocked',
      kind: 'encrypted-file',
      state: 'available',
    });

    unlocked.store({
      material: 'ghp_live_secret',
      metadata: { ownerScope: 'server' },
      referenceId: 'vault_00000000-0000-7f73-bffa-d96a61ee4d70',
    });
    expect(
      Buffer.from(
        state.backend().resolve({ referenceId: 'vault_00000000-0000-7f73-bffa-d96a61ee4d70' })
      ).toString('utf8')
    ).toBe('ghp_live_secret');

    const locked = state.lock();

    expect(locked.health()).toEqual({
      diagnostic: 'Vault backend is locked.',
      kind: 'encrypted-file',
      state: 'locked',
    });
    expect(() =>
      state.backend().resolve({ referenceId: 'vault_00000000-0000-7f73-bffa-d96a61ee4d70' })
    ).toThrow('vault-locked');

    let retainedBackendFailure: unknown;

    try {
      unlocked.resolve({ referenceId: 'vault_00000000-0000-7f73-bffa-d96a61ee4d70' });
    } catch (error) {
      retainedBackendFailure = error;
    }

    expect(retainedBackendFailure).toBeInstanceOf(VaultBackendError);
    expect(unlocked.health()).toMatchObject({ state: 'locked' });
    expect(() =>
      unlocked.store({
        material: 'must_not_write',
        metadata: { ownerScope: 'server' },
        referenceId: 'vault_00000000-0000-7128-98c2-a63082444bec',
      })
    ).toThrow('vault-locked');
    expect(
      existsSync(join(storeDir, 'entries', 'vault_00000000-0000-7128-98c2-a63082444bec'))
    ).toBe(false);
    expect(String(retainedBackendFailure)).not.toContain(storeDir);
    expect(String(retainedBackendFailure)).not.toContain(masterKey.toString('base64'));
    expect(String(retainedBackendFailure)).not.toContain(masterKey.toString('hex'));
    expect(String(retainedBackendFailure)).not.toContain('ghp_live_secret');
  });

  it('keeps the current backend usable when a replacement unlock fails', () => {
    const storeDir = mkdtempSync(join(tmpdir(), 'openkit-vault-unlock-'));
    const masterKey = Buffer.alloc(32, 9);
    const wrongKey = Buffer.alloc(32, 8);
    const state = createVaultUnlockState({ backendKind: 'encrypted-file', storeDir });
    const currentBackend = state.unlock({ masterKey });

    currentBackend.store({
      material: 'ghp_live_secret',
      metadata: { ownerScope: 'server' },
      referenceId: 'vault_00000000-0000-7f73-bffa-d96a61ee4d70',
    });

    let replacement: ReturnType<typeof state.unlock> | undefined;
    let failure: unknown;

    try {
      replacement = state.unlock({ masterKey: wrongKey });
    } catch (error) {
      failure = error;
    }

    expect(replacement).toBeUndefined();
    expect(failure).toBeInstanceOf(VaultBackendError);
    expect(state.backend()).toBe(currentBackend);
    expect(
      Buffer.from(
        state.backend().resolve({ referenceId: 'vault_00000000-0000-7f73-bffa-d96a61ee4d70' })
      ).toString('utf8')
    ).toBe('ghp_live_secret');
    expect(String(failure)).not.toContain(storeDir);
    expect(String(failure)).not.toContain(wrongKey.toString('base64'));
    expect(String(failure)).not.toContain(wrongKey.toString('hex'));
    expect(String(failure)).not.toContain('ghp_live_secret');
  });

  it('rejects invalid encrypted-file unlock keys without keeping an available backend', () => {
    const state = createVaultUnlockState({
      backendKind: 'encrypted-file',
      storeDir: mkdtempSync(join(tmpdir(), 'openkit-vault-unlock-')),
    });

    expect(() => state.unlock({ masterKey: Buffer.alloc(16, 9) })).toThrow(
      'Vault unlock key must contain exactly 32 bytes.'
    );
    expect(state.backend().health()).toMatchObject({
      state: 'locked',
    });
  });
});
