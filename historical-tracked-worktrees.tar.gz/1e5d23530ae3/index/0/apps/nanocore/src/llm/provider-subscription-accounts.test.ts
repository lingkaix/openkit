// openkit-test-platform: posix
import { randomUUID } from 'node:crypto';
import {
  closeSync,
  existsSync,
  lstatSync,
  mkdirSync,
  mkdtempSync,
  openSync,
  readdirSync,
  readFileSync,
  renameSync,
  rmSync,
  symlinkSync,
  unlinkSync,
  writeFileSync,
} from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import {
  type AuthInteraction,
  fauxAssistantMessage,
  fauxProvider,
  fauxText,
  type MutableModels,
  type OAuthCredential,
  type StreamOptions,
} from '@earendil-works/pi-ai';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { listWorkspaceCapabilityCalls } from '../capability/usage-ledger.js';
import { createRuntimeConfigManager, loadRuntimeConfig } from '../config/runtime-config.js';
import type { ResolvedLLMProviderConfig } from '../providers/llm-config.js';
import { ProviderRegistry } from '../providers/registry.js';
import { WorkerControlGateway } from '../runtime/worker-control-gateway.js';
import { createSchedulerAdmissionEntry } from '../scheduler-records.js';
import type { CoreDb } from '../storage/db.js';
import { openCoreDb, openWorkspaceDb } from '../storage/db.js';
import { applyMigrations } from '../storage/migrate.js';
import { createTestAgentSetup } from '../test-support/agent-environment.js';
import { createApp } from '../test-support/app.js';
import { createDemoStore } from '../test-support/demo-store.js';
import { testEntityId } from '../test-support/entity-ids.js';
import { recordTestExecutionAttempt } from '../test-support/execution-attempt.js';
import { ensureLocalUser } from '../test-support/local-user.js';
import { operationRequest } from '../test-support/operation-request.js';
import { resolveAgentEnvironmentPackage } from '../test-support/prepared-agent-environment.js';
import { type VaultBackend, VaultBackendError } from '../vault/vault-backend.js';
import { createVaultGrant } from '../vault/vault-grants.js';
import {
  createVaultReference,
  getVaultReference,
  revokeVaultReference,
} from '../vault/vault-references.js';
import type { VaultUnlockState } from '../vault/vault-unlock-state.js';
import { createVaultUnlockState } from '../vault/vault-unlock-state.js';
import { listVaultUseRecords } from '../vault/vault-use-records.js';
import { createVaultInjectionPlan } from '../vault-injection-plans.js';
import { createVaultInjectionReceipt } from '../vault-injection-receipts.js';
import { recordWorkspaceOwnerMembership } from '../workspace-membership.js';
import { dispatchLogicalModel } from './gateway-routes.js';
import { resolveLogicalModel, resolveLogicalModelCatalog } from './logical-models.js';
import { PiAiGatewayClient } from './pi-ai-client.js';
import { LLMGatewayProviderDispatcher } from './provider-dispatcher.js';
import {
  ProviderSubscriptionAccountError,
  ProviderSubscriptionAccountManager,
  type ProviderSubscriptionAccountPair,
  type ProviderSubscriptionAccountSnapshot,
  type ProviderSubscriptionPairHandle,
} from './provider-subscription-accounts.js';

const durability = vi.hoisted(() => ({
  paths: new Map<number, string>(),
  events: [] as Array<{
    op: 'sync' | 'rename';
    path: string;
    from?: string;
    directory?: boolean;
    mode?: number;
  }>,
  fail: undefined as ((path: string, directory: boolean) => boolean) | undefined,
}));

vi.mock('node:fs', async (importOriginal) => {
  const actual = await importOriginal<typeof import('node:fs')>();
  return {
    ...actual,
    openSync: ((...args: Parameters<typeof actual.openSync>) => {
      const descriptor = actual.openSync(...args);
      durability.paths.set(descriptor, String(args[0]));
      return descriptor;
    }) as typeof actual.openSync,
    closeSync: ((descriptor: number) => {
      durability.paths.delete(descriptor);
      return actual.closeSync(descriptor);
    }) as typeof actual.closeSync,
    fsyncSync: ((descriptor: number) => {
      const path = durability.paths.get(descriptor) ?? '<untracked>';
      const directory = actual.fstatSync(descriptor).isDirectory();
      durability.events.push({
        op: 'sync',
        path,
        directory,
        mode: actual.fstatSync(descriptor).mode & 0o777,
      });
      if (durability.fail?.(path, directory)) throw new Error('Injected publication sync failure');
      return actual.fsyncSync(descriptor);
    }) as typeof actual.fsyncSync,
    renameSync: ((
      from: Parameters<typeof actual.renameSync>[0],
      to: Parameters<typeof actual.renameSync>[1]
    ) => {
      durability.events.push({ op: 'rename', from: String(from), path: String(to) });
      return actual.renameSync(from, to);
    }) as typeof actual.renameSync,
  };
});

const DEFAULT_TIME = '2026-07-23T00:00:00.000Z';
const PERSISTENCE_ERROR = {
  code: 'provider_subscription_persistence_failed',
  message: 'Provider subscription persistence failed.',
} as const;
const PROJECTION_ERROR = {
  code: 'provider_subscription_projection_failed',
  message: 'Provider subscription projection failed.',
} as const;
const SLOT_ERROR = {
  code: 'provider_subscription_account_slot_invalid',
  message: 'Account slot id is invalid.',
} as const;
const PROVIDER_ERROR = {
  code: 'provider_subscription_provider_not_found',
  message: 'Subscription provider not found.',
} as const;
const LOCKED_ERROR = {
  code: 'provider_subscription_vault_locked',
  message: 'Provider subscription Vault is locked.',
} as const;
const ACCOUNT_EXISTS_ERROR = {
  code: 'provider_subscription_account_exists',
  message: 'Provider subscription account already exists.',
} as const;
const ACCOUNT_NOT_FOUND_ERROR = {
  code: 'provider_subscription_account_not_found',
  message: 'Provider subscription account not found.',
} as const;
const LOGIN_ACTIVE_ERROR = {
  code: 'provider_subscription_login_active',
  message: 'A login interaction is already active for this account.',
} as const;
const PROVIDER_UNAVAILABLE_ERROR = {
  code: 'provider_subscription_provider_unavailable',
  message: 'Subscription provider is unavailable.',
} as const;
const VAULT_UNAVAILABLE_ERROR = {
  code: 'provider_subscription_vault_unavailable',
  message: 'Provider subscription Vault is unavailable.',
} as const;
const LOGIN_ERROR_MESSAGE = 'Provider subscription login failed.';

/** One strict durable account record used by direct authority fixtures. */
interface AccountRecord {
  /** Durable schema discriminator. */
  readonly schemaVersion: 1;
  /** Subscription provider that owns the account. */
  readonly subscriptionProviderId: ProviderSubscriptionAccountPair['subscriptionProviderId'];
  /** Provider-scoped account slot id. */
  readonly accountSlotId: string;
  /** Immutable creation timestamp. */
  readonly createdAt: string;
  /** Monotonic last-update timestamp. */
  readonly updatedAt: string;
  /** Optional operator-supplied display name. */
  readonly displayName?: string;
  /** Optional internal Vault reference binding. */
  readonly vaultReferenceId?: string;
  /** Optional safe provider-derived account label. */
  readonly accountLabel?: string;
  /** Optional safe provider-derived plan label. */
  readonly planLabel?: string;
  /** Sanitized lifecycle projection. */
  readonly status: 'logged_out' | 'pending' | 'logged_in' | 'unavailable' | 'error';
  /** Required only for unavailable and error projections. */
  readonly message?: string;
}

/** Mutable deterministic clock queue owned by one test fixture. */
interface TestClock {
  /** Returns the next queued timestamp or the most recently selected timestamp. */
  readonly now: () => string;
  /** Replaces the queue and fallback timestamp for the next operation. */
  readonly use: (...timestamps: string[]) => void;
}

/** Real Core, Vault, filesystem, and manager fixture used by every manager test. */
interface ProviderSubscriptionFixture {
  /** Temporary NanoCore data root. */
  readonly dataRoot: string;
  /** Migrated Core database under the data root. */
  readonly coreDb: CoreDb;
  /** Real encrypted-file Vault unlock state. */
  readonly vaultState: VaultUnlockState;
  /** Manager under test. */
  readonly manager: ProviderSubscriptionAccountManager;
  /** Creates a fresh process-local manager generation over the same durable authorities. */
  readonly createManager: () => ProviderSubscriptionAccountManager;
  /** Deterministic operation clock. */
  readonly clock: TestClock;
  /** Queues deterministic fresh Vault reference ids. */
  readonly queueReferenceIds: (...referenceIds: string[]) => void;
  /** Returns the dynamically selected backend. */
  readonly backend: () => VaultBackend;
  /** Returns how many times the manager requested the dynamic backend. */
  readonly backendGetterCalls: () => number;
  /** Clears the manager backend-getter call counter. */
  readonly resetBackendGetterCalls: () => void;
  /** Replaces or clears the test-only dynamic backend projection. */
  readonly replaceBackend: (backend?: VaultBackend) => void;
  /** Closes the database and removes the temporary data root. */
  readonly close: () => void;
}

/** Exact raw authority snapshot used to prove failed reads do not repair state. */
interface AuthoritySnapshot {
  /** Raw provider-subscription filesystem tree. */
  readonly accountTree: readonly [string, string][];
  /** Generic Core Vault reference rows. */
  readonly coreReferences: readonly Record<string, unknown>[];
  /** Non-secret encrypted-file Vault inventory. */
  readonly vaultInventory: ReturnType<VaultBackend['listReferences']>;
}

/** One externally released promise gate for deterministic concurrency tests. */
interface DeferredGate {
  /** Promise awaited by gated work. */
  readonly promise: Promise<void>;
  /** Releases the waiting promise. */
  readonly resolve: () => void;
}

/** Public device-code state owned by one manager login interaction. */
interface ManagerLoginInteraction {
  /** OpenKit-owned process-local identifier. */
  readonly interactionId: string;
  /** Only accepted login mode. */
  readonly mode: 'device_code';
  /** Provider-owned device user code. */
  readonly userCode: string;
  /** Sanitized absolute provider verification URL. */
  readonly verificationUrl: string;
  /** Optional provider-derived expiry timestamp. */
  readonly expiresAt?: string;
}

/** Sanitized manager status with one optional process-local interaction. */
type ManagerLifecycleSnapshot = ProviderSubscriptionAccountSnapshot & {
  /** Present only while the exact login interaction is active. */
  readonly interaction?: ManagerLoginInteraction;
};

/** Focused lifecycle surface moving interaction state into the existing manager pair owner. */
interface ManagerLifecycleOperations {
  /** Starts one pair-scoped stock-provider device-code login. */
  readonly startLogin: (pair: ProviderSubscriptionAccountPair) => Promise<ManagerLifecycleSnapshot>;
  /** Cancels and settles the exact active interaction. */
  readonly cancelLogin: (
    pair: ProviderSubscriptionAccountPair,
    interactionId: string
  ) => Promise<ManagerLifecycleSnapshot>;
  /** Returns durable status plus manager-owned process-local state. */
  readonly getStatus: (pair: ProviderSubscriptionAccountPair) => Promise<ManagerLifecycleSnapshot>;
  /** Settles active login and removes the latest credential. */
  readonly logout: (pair: ProviderSubscriptionAccountPair) => Promise<ManagerLifecycleSnapshot>;
}

const fixtures = new Set<ProviderSubscriptionFixture>();
const extraTemporaryRoots = new Set<string>();

afterEach(() => {
  vi.useRealTimers();
  vi.restoreAllMocks();
  vi.unstubAllEnvs();

  for (const fixture of fixtures) {
    fixture.close();
  }
  fixtures.clear();

  for (const root of extraTemporaryRoots) {
    rmSync(root, { force: true, recursive: true });
  }
  extraTemporaryRoots.clear();
});

/**
 * Creates one provider-slot pair.
 *
 * @param accountSlotId Provider-scoped slot id.
 * @param subscriptionProviderId Subscription provider id.
 * @returns Exact pair input for manager operations.
 */
function accountPair(
  accountSlotId: string,
  subscriptionProviderId: ProviderSubscriptionAccountPair['subscriptionProviderId'] = 'openai-codex'
): ProviderSubscriptionAccountPair {
  return { accountSlotId, subscriptionProviderId };
}

/**
 * Creates one deterministic timestamp queue.
 *
 * @returns Mutable queue-backed test clock.
 */
function createTestClock(): TestClock {
  let fallback = DEFAULT_TIME;
  let queue: string[] = [];

  return {
    now: () => queue.shift() ?? fallback,
    use: (...timestamps) => {
      if (timestamps.length === 0) {
        throw new Error('A deterministic fixture timestamp is required.');
      }
      queue = [...timestamps];
      fallback = timestamps.at(-1) ?? fallback;
    },
  };
}

/**
 * Creates one migrated Core database and unlocked encrypted-file Vault fixture.
 *
 * @returns Real provider-subscription manager fixture.
 */
function createFixture(): ProviderSubscriptionFixture {
  const dataRoot = mkdtempSync(join(tmpdir(), 'openkit-provider-subscription-'));
  const coreDb = openCoreDb(dataRoot);
  applyMigrations(coreDb);
  const clock = createTestClock();
  const vaultState = createVaultUnlockState({
    backendKind: 'encrypted-file',
    now: clock.now,
    storeDir: join(dataRoot, 'server', 'vault'),
  });
  vaultState.unlock({ masterKey: Buffer.alloc(32, 23) });
  const referenceIds: string[] = [];
  let replacementBackend: VaultBackend | undefined;
  let backendGetterCallCount = 0;
  const backend = (): VaultBackend => replacementBackend ?? vaultState.backend();
  const managerBackend = (): VaultBackend => {
    backendGetterCallCount += 1;
    return backend();
  };
  /** Creates one uncached manager generation over the fixture authorities. */
  const createManager = (): ProviderSubscriptionAccountManager =>
    new ProviderSubscriptionAccountManager({
      coreDb,
      createReferenceId: () => {
        const referenceId = referenceIds.shift();
        if (!referenceId) {
          throw new Error('A deterministic fixture reference id is required.');
        }
        return referenceId;
      },
      now: clock.now,
      vaultBackend: managerBackend,
    });
  const manager = createManager();
  const fixture: ProviderSubscriptionFixture = {
    backend,
    backendGetterCalls: () => backendGetterCallCount,
    clock,
    close: () => {
      if (coreDb.sqlite.open) {
        coreDb.sqlite.close();
      }
      rmSync(dataRoot, { force: true, recursive: true });
    },
    coreDb,
    createManager,
    dataRoot,
    manager,
    queueReferenceIds: (...ids) => referenceIds.push(...ids),
    replaceBackend: (next) => {
      replacementBackend = next;
    },
    resetBackendGetterCalls: () => {
      backendGetterCallCount = 0;
    },
    vaultState,
  };

  assertFrozenManagerSurface(manager);
  fixtures.add(fixture);
  return fixture;
}

/**
 * Freezes the manager methods and typed pair-handle surface required by WP2.
 *
 * @param manager Manager instance whose public methods must remain present.
 */
function assertFrozenManagerSurface(manager: ProviderSubscriptionAccountManager): void {
  const methods = [
    manager.createAccount,
    manager.updateAccount,
    manager.deleteAccount,
    manager.listAccounts,
    manager.getPairHandle,
    manager.reconcileAccount,
    manager.reconcileAll,
  ];
  const handleType: ProviderSubscriptionPairHandle | undefined = undefined;

  expect(methods).toHaveLength(7);
  void handleType;
}

/**
 * Returns the exact durable account directory.
 *
 * @param dataRoot NanoCore data root.
 * @param pair Provider-slot pair.
 * @returns Exact provider account directory path.
 */
function accountDirectory(dataRoot: string, pair: ProviderSubscriptionAccountPair): string {
  return join(
    dataRoot,
    'server',
    'files',
    'provider-subscriptions',
    pair.subscriptionProviderId,
    'accounts',
    pair.accountSlotId
  );
}

/**
 * Returns the exact durable account record path.
 *
 * @param dataRoot NanoCore data root.
 * @param pair Provider-slot pair.
 * @returns Exact account.json path.
 */
function accountPath(dataRoot: string, pair: ProviderSubscriptionAccountPair): string {
  return join(accountDirectory(dataRoot, pair), 'account.json');
}

/**
 * Creates a strict unbound account record for direct authority fixtures.
 *
 * @param pair Provider-slot pair.
 * @param overrides Explicit record overrides.
 * @returns Strict version-1 account record.
 */
function validAccountRecord(
  pair: ProviderSubscriptionAccountPair,
  overrides: Partial<AccountRecord> = {}
): AccountRecord {
  return {
    accountSlotId: pair.accountSlotId,
    createdAt: DEFAULT_TIME,
    schemaVersion: 1,
    status: 'logged_out',
    subscriptionProviderId: pair.subscriptionProviderId,
    updatedAt: DEFAULT_TIME,
    ...overrides,
  };
}

/**
 * Writes raw bytes to one direct account authority path.
 *
 * @param dataRoot NanoCore data root.
 * @param pair Provider-slot pair.
 * @param bytes Exact bytes to write.
 */
function writeRawAccount(
  dataRoot: string,
  pair: ProviderSubscriptionAccountPair,
  bytes: string | Uint8Array
): void {
  mkdirSync(accountDirectory(dataRoot, pair), { recursive: true });
  writeFileSync(accountPath(dataRoot, pair), bytes);
}

/**
 * Writes one JSON account authority record.
 *
 * @param dataRoot NanoCore data root.
 * @param pair Provider-slot pair.
 * @param record JSON value to serialize.
 */
function writeAccountJson(
  dataRoot: string,
  pair: ProviderSubscriptionAccountPair,
  record: unknown
): void {
  writeRawAccount(dataRoot, pair, `${JSON.stringify(record, null, 2)}\n`);
}

/**
 * Reads one account authority as parsed JSON.
 *
 * @param dataRoot NanoCore data root.
 * @param pair Provider-slot pair.
 * @returns Parsed account record.
 */
function readAccountJson(
  dataRoot: string,
  pair: ProviderSubscriptionAccountPair
): Record<string, unknown> {
  return JSON.parse(readFileSync(accountPath(dataRoot, pair), 'utf8')) as Record<string, unknown>;
}

/**
 * Reads the account subtree as stable relative-path and base64-byte pairs.
 *
 * @param dataRoot NanoCore data root.
 * @returns Stable raw account subtree snapshot.
 */
function readAccountTree(dataRoot: string): readonly [string, string][] {
  const root = join(dataRoot, 'server', 'files', 'provider-subscriptions');
  const rows: Array<[string, string]> = [];

  /**
   * Walks one non-symlink directory without following external targets.
   *
   * @param directory Directory to inspect.
   * @param relativeDirectory Relative directory used in snapshot keys.
   */
  function walk(directory: string, relativeDirectory: string): void {
    for (const name of readdirSync(directory).sort()) {
      const path = join(directory, name);
      const relativePath = join(relativeDirectory, name);
      const stat = lstatSync(path);

      if (stat.isSymbolicLink()) {
        rows.push([relativePath, `symlink:${readFileSync(path, 'utf8')}`]);
      } else if (stat.isDirectory()) {
        rows.push([`${relativePath}/`, 'directory']);
        walk(path, relativePath);
      } else {
        rows.push([relativePath, readFileSync(path).toString('base64')]);
      }
    }
  }

  if (existsSync(root)) {
    walk(root, '.');
  }
  return rows;
}

/**
 * Reads all three durable authorities except append-only audit evidence.
 *
 * @param fixture Real manager fixture.
 * @returns Stable account, Core-reference, and Vault inventory snapshot.
 */
function authoritySnapshot(fixture: ProviderSubscriptionFixture): AuthoritySnapshot {
  const coreReferences = fixture.coreDb.sqlite
    .prepare('SELECT * FROM vault_references ORDER BY reference_id ASC')
    .all() as Record<string, unknown>[];

  return {
    accountTree: readAccountTree(fixture.dataRoot),
    coreReferences,
    vaultInventory: fixture.backend().listReferences(),
  };
}

/**
 * Captures and verifies one typed fixed-message manager error.
 *
 * @param operation Operation expected to reject.
 * @param expected Stable error code and fixed message.
 * @returns Captured typed error.
 */
async function expectAccountError(
  operation: () => Promise<unknown>,
  expected: { readonly code: string; readonly message: string }
): Promise<ProviderSubscriptionAccountError> {
  let failure: unknown;

  try {
    await operation();
  } catch (error) {
    failure = error;
  }

  expect(failure).toBeInstanceOf(ProviderSubscriptionAccountError);
  expect(failure).toMatchObject(expected);
  expect((failure as Error).message).toBe(expected.message);
  return failure as ProviderSubscriptionAccountError;
}

/**
 * Creates a complete OAuth credential with provider-private extra fields.
 *
 * @param suffix Stable value suffix.
 * @returns Complete OAuth credential fixture.
 */
function oauthCredential(suffix: string): OAuthCredential {
  return {
    access: `access-${suffix}`,
    accountId: `account-${suffix}`,
    expires: Date.parse('2027-08-23T00:00:00.000Z'),
    refresh: `refresh-${suffix}`,
    scope: ['openid', 'profile'],
    type: 'oauth',
  };
}

/**
 * Creates the exact generic Core row required by one provider-subscription reference.
 *
 * @param fixture Real manager fixture.
 * @param referenceId Vault reference id.
 */
function createExactCoreReference(fixture: ProviderSubscriptionFixture, referenceId: string): void {
  createVaultReference(fixture.coreDb, {
    backendKind: 'encrypted-file',
    backendLocator: `encrypted-file://server/vault/${referenceId}`,
    displayName: 'Provider subscription credential',
    now: fixture.clock.now,
    ownerScope: 'server',
    referenceId,
    secretKind: 'provider-subscription-oauth',
  });
}

/**
 * Creates one exact live account, Core row, and encrypted-file credential.
 *
 * @param fixture Real manager fixture.
 * @param pair Provider-slot pair.
 * @param referenceId Vault reference id.
 * @param credential OAuth credential material.
 */
function createLivePair(
  fixture: ProviderSubscriptionFixture,
  pair: ProviderSubscriptionAccountPair,
  referenceId: string,
  credential: OAuthCredential = oauthCredential(referenceId)
): void {
  writeAccountJson(
    fixture.dataRoot,
    pair,
    validAccountRecord(pair, {
      status: 'logged_in',
      vaultReferenceId: referenceId,
    })
  );
  createExactCoreReference(fixture, referenceId);
  fixture.backend().store({
    material: JSON.stringify(credential),
    metadata: {
      ownerScope: 'server',
      providerSubscriptionAccount: pair,
    },
    referenceId,
  });
}

/**
 * Creates one exact live authority triple with caller-selected stored material.
 *
 * @param fixture Real manager fixture.
 * @param pair Provider-slot pair.
 * @param referenceId Vault reference id.
 * @param material Exact material string stored only by the encrypted-file backend.
 */
function createLiveMaterialPair(
  fixture: ProviderSubscriptionFixture,
  pair: ProviderSubscriptionAccountPair,
  referenceId: string,
  material: string
): void {
  writeAccountJson(
    fixture.dataRoot,
    pair,
    validAccountRecord(pair, { status: 'logged_in', vaultReferenceId: referenceId })
  );
  createExactCoreReference(fixture, referenceId);
  fixture.backend().store({
    material,
    metadata: { ownerScope: 'server', providerSubscriptionAccount: pair },
    referenceId,
  });
}

/**
 * Converts one live pair into immutable completed tombstone history.
 *
 * @param fixture Real manager fixture.
 * @param pair Provider-slot pair.
 * @param referenceId Vault reference id.
 */
function createCompletedHistory(
  fixture: ProviderSubscriptionFixture,
  pair: ProviderSubscriptionAccountPair,
  referenceId: string
): void {
  createLivePair(fixture, pair, referenceId);
  fixture.backend().revoke({ referenceId });
  revokeVaultReference(fixture.coreDb, { now: fixture.clock.now, referenceId });
  rmSync(accountDirectory(fixture.dataRoot, pair), { force: true, recursive: true });
}

/**
 * Replaces selected generic Core reference fields for a failed-closed fixture.
 *
 * @param fixture Real manager fixture.
 * @param referenceId Vault reference id.
 * @param assignments SQL assignment fragment containing test-owned literals only.
 */
function mutateCoreReference(
  fixture: ProviderSubscriptionFixture,
  referenceId: string,
  assignments: string
): void {
  fixture.coreDb.sqlite
    .prepare(`UPDATE vault_references SET ${assignments} WHERE reference_id = ?`)
    .run(referenceId);
}

/**
 * Deletes one generic Core reference row for a missing-authority fixture.
 *
 * @param fixture Real manager fixture.
 * @param referenceId Vault reference id.
 */
function deleteCoreReference(fixture: ProviderSubscriptionFixture, referenceId: string): void {
  fixture.coreDb.sqlite
    .prepare('DELETE FROM vault_references WHERE reference_id = ?')
    .run(referenceId);
}

/**
 * Creates an account and stores its first OAuth credential through the real manager handle.
 *
 * @param fixture Real manager fixture.
 * @param pair Provider-slot pair.
 * @param referenceId Deterministic fresh Vault reference id.
 * @param credential OAuth credential to persist.
 * @returns Cached pair handle used for the store.
 */
async function createStoredPair(
  fixture: ProviderSubscriptionFixture,
  pair: ProviderSubscriptionAccountPair,
  referenceId: string,
  credential: OAuthCredential = oauthCredential(referenceId)
): Promise<ProviderSubscriptionPairHandle> {
  fixture.queueReferenceIds(referenceId);
  await fixture.manager.createAccount(pair);
  const handle = await fixture.manager.getPairHandle(pair);
  await handle.credentials.modify(pair.subscriptionProviderId, async () => credential);
  return handle;
}

/**
 * Creates generic Vault grant, injection-plan, and receipt dependents for one reference.
 *
 * @param fixture Real manager fixture.
 * @param referenceId Vault reference id.
 * @param suffix Stable dependent-record suffix.
 */
function createReferenceCascade(
  fixture: ProviderSubscriptionFixture,
  referenceId: string,
  suffix: string
): void {
  const grantId = testEntityId('grant', `grant_${suffix}`);
  const planId = `plan_${suffix}`;

  createVaultGrant(fixture.coreDb, {
    allowedInjectionPaths: ['runtime-file'],
    grantId,
    lifetime: 'turn',
    ownerScope: 'workspace',
    vaultReferenceId: referenceId,
    workspaceId: 'ws_00000000-0000-73c3-900f-8d310e4ba201',
  });
  createVaultInjectionPlan(fixture.coreDb, {
    backendCapabilityRequirement: 'encrypted-file:resolve',
    expirationBehavior: 'delete-on-turn-end',
    grantId,
    injectionVisibility: 'runtime-file',
    planId,
    redactionRule: 'path-only',
    revocationBehavior: 'mark-session-stale',
    targetPath: `/openkit/secrets/${suffix}`,
  });
  createVaultInjectionReceipt(fixture.coreDb, {
    agentSessionId: testEntityId('as', `session_${suffix}`),
    backendSummary: `encrypted-file:${referenceId}:v1`,
    grantId,
    injectedAt: DEFAULT_TIME,
    planId,
    receiptId: `receipt_${suffix}`,
    revocationStatus: 'active',
  });
}

/**
 * Reads the exact cascade statuses for one test-owned dependent set.
 *
 * @param fixture Real manager fixture.
 * @param suffix Stable dependent-record suffix.
 * @returns Grant, plan, and receipt status projection.
 */
function readCascadeStatuses(
  fixture: ProviderSubscriptionFixture,
  suffix: string
): { readonly grant: string; readonly plan: string; readonly receipt: string } {
  const grantId = testEntityId('grant', `grant_${suffix}`);
  const planId = `plan_${suffix}`;
  const receiptId = `receipt_${suffix}`;
  const grant = fixture.coreDb.sqlite
    .prepare('SELECT status FROM vault_grants WHERE grant_id = ?')
    .get(grantId) as { readonly status: string };
  const plan = fixture.coreDb.sqlite
    .prepare('SELECT status FROM vault_injection_plans WHERE plan_id = ?')
    .get(planId) as { readonly status: string };
  const receipt = fixture.coreDb.sqlite
    .prepare('SELECT revocation_status FROM vault_injection_receipts WHERE receipt_id = ?')
    .get(receiptId) as { readonly revocation_status: string };

  return {
    grant: grant.status,
    plan: plan.status,
    receipt: receipt.revocation_status,
  };
}

/**
 * Creates one manually released promise gate.
 *
 * @returns Deferred gate for deterministic mutation ordering.
 */
function deferredGate(): DeferredGate {
  let release: (() => void) | undefined;
  const promise = new Promise<void>((resolve) => {
    release = resolve;
  });

  return {
    promise,
    resolve: () => release?.(),
  };
}

/**
 * Views the manager through the focused lifecycle methods required by the accepted repair.
 *
 * @param manager Provider-subscription manager under test.
 * @returns Expected manager-owned login, status, cancellation, and logout surface.
 */
function lifecycleOperations(
  manager: ProviderSubscriptionAccountManager
): ManagerLifecycleOperations {
  return manager as unknown as ManagerLifecycleOperations;
}

/**
 * Returns the pair's stock provider-owned OAuth implementation.
 *
 * @param handle Existing pair-scoped Models handle.
 * @param pair Provider-slot identity selecting the stock provider.
 * @returns Provider OAuth implementation used directly by manager login.
 */
function requireProviderOAuth(
  handle: ProviderSubscriptionPairHandle,
  pair: ProviderSubscriptionAccountPair
) {
  const oauth = handle.models.getProvider(pair.subscriptionProviderId)?.auth.oauth;
  if (!oauth) {
    throw new Error(`Fixture provider has no OAuth login: ${pair.subscriptionProviderId}`);
  }
  return oauth;
}

/**
 * Captures console arguments without serializing or emitting them.
 *
 * @param captured Destination rows for intercepted console arguments.
 * @returns Console-compatible capture callback.
 */
function captureConsole(captured: unknown[][]): (...args: unknown[]) => void {
  return (...args) => captured.push(args);
}

/**
 * Projects every own Error property, including non-enumerable fields and nested causes.
 *
 * @param error Arbitrary thrown value to serialize as redaction evidence.
 * @returns Complete recursively serializable error projection.
 */
function completeErrorProjection(error: unknown): unknown {
  if (!(error instanceof Error)) {
    return error;
  }

  const projection: Record<string, unknown> = {};
  const record = error as unknown as Record<string, unknown>;
  for (const name of Object.getOwnPropertyNames(error)) {
    projection[name] = record[name];
  }
  for (const [name, value] of Object.entries(error)) {
    projection[name] = value;
  }
  if ('cause' in error) {
    projection.cause = completeErrorProjection(error.cause);
  }
  return projection;
}

/**
 * Finds literal UTF-8 canary byte sequences in regular files without decoding ciphertext.
 *
 * @param dataRoot Data root to scan recursively.
 * @param canaries Literal canary strings that must not be present.
 * @returns Relative file and canary pairs for every literal byte match.
 */
function findLiteralCanaryBytes(dataRoot: string, canaries: readonly string[]): string[] {
  const matches: string[] = [];

  /**
   * Scans one directory without following symbolic links.
   *
   * @param directory Absolute directory to inspect.
   * @param relativeDirectory Relative directory used in findings.
   */
  function scan(directory: string, relativeDirectory: string): void {
    for (const name of readdirSync(directory).sort()) {
      const path = join(directory, name);
      const relativePath = join(relativeDirectory, name);
      const stat = lstatSync(path);

      if (stat.isDirectory()) {
        scan(path, relativePath);
        continue;
      }
      if (!stat.isFile()) {
        continue;
      }

      const bytes = readFileSync(path);
      for (const canary of canaries) {
        if (bytes.includes(Buffer.from(canary, 'utf8'))) {
          matches.push(`${relativePath}:${canary}`);
        }
      }
    }
  }

  scan(dataRoot, '.');
  return matches;
}

/** Writes real bound and independent Provider tiers for availability observations. */
function writeAvailabilitySupply(fixture: ProviderSubscriptionFixture): void {
  const configRoot = join(fixture.dataRoot, 'config');
  mkdirSync(join(configRoot, 'providers'), { recursive: true });
  writeFileSync(
    join(configRoot, 'providers', 'bound.provider.jsonc'),
    JSON.stringify({
      id: 'bound',
      displayName: 'Bound',
      kind: 'oauth',
      vendor: 'openai-codex',
      models: ['gpt-5.1'],
      extensions: { openkit: { subscriptionAccount: { accountSlotId: 'availability' } } },
    })
  );
  writeFileSync(
    join(configRoot, 'providers', 'independent.provider.jsonc'),
    JSON.stringify({
      id: 'independent',
      displayName: 'Independent',
      kind: 'local',
      vendor: 'openai',
      models: ['gpt-5.1'],
    })
  );
  writeFileSync(
    join(configRoot, 'gateway.jsonc'),
    JSON.stringify({
      schemaVersion: 1,
      logicalModels: [
        {
          id: 'bound-tier',
          displayName: 'Bound',
          contextManagement: [{ type: 'compaction', compactThreshold: 8_000 }],
          routes: [{ id: 'bound-route', providerProfileId: 'bound', providerModel: 'gpt-5.1' }],
        },
        {
          id: 'independent-tier',
          displayName: 'Independent',
          contextManagement: [{ type: 'compaction', compactThreshold: 8_000 }],
          routes: [
            { id: 'independent-route', providerProfileId: 'independent', providerModel: 'gpt-5.1' },
          ],
        },
      ],
    })
  );
}

describe('ProviderSubscriptionAccountManager', () => {
  it('deletes a bound slot without rewriting its profile or logical routes', async () => {
    const fixture = createFixture();
    const pair = accountPair('availability');
    await createStoredPair(fixture, pair, 'vault_00000000-0000-7932-8b35-9939dfc7ad68');
    writeAvailabilitySupply(fixture);
    const paths = ['providers/bound.provider.jsonc', 'gateway.jsonc'].map((path) =>
      join(fixture.dataRoot, 'config', path)
    );
    const before = paths.map((path) => readFileSync(path));
    await fixture.manager.deleteAccount(pair);
    expect(paths.map((path) => readFileSync(path))).toEqual(before);
    expect(
      existsSync(
        join(
          fixture.dataRoot,
          'server/files/provider-subscriptions',
          pair.subscriptionProviderId,
          'accounts',
          pair.accountSlotId,
          'account.json'
        )
      )
    ).toBe(false);
    expect(
      getVaultReference(fixture.coreDb, 'vault_00000000-0000-7932-8b35-9939dfc7ad68')?.status
    ).toBe('revoked');
  });

  it('reads live Gateway availability without resolving secrets or writing Vault-use records', async () => {
    const fixture = createFixture();
    try {
      await createStoredPair(
        fixture,
        accountPair('availability'),
        'vault_00000000-0000-703a-aeb4-741e70ca0b46'
      );
      writeAvailabilitySupply(fixture);
      const before = listVaultUseRecords(fixture.coreDb);
      const resolves = vi.spyOn(fixture.backend(), 'resolve');
      const manager = createRuntimeConfigManager({
        dataRoot: fixture.dataRoot,
        subscriptionAccounts: fixture.manager,
      });
      const app = createApp({
        dataRoot: fixture.dataRoot,
        coreDb: fixture.coreDb,
        runtimeConfigManager: manager,
        providerSubscriptionAccountManager: fixture.manager,
      });
      const discovery = await app.request('/v1/models');
      expect(discovery.status).toBe(200);
      expect(await discovery.json()).toMatchObject({
        data: expect.arrayContaining([expect.objectContaining({ id: 'bound-tier' })]),
      });
      const snapshot = manager.current();
      expect(
        resolveLogicalModel(
          snapshot.gatewayConfig,
          snapshot.providerRegistry,
          'bound-tier',
          fixture.manager
        )
      ).toMatchObject({ routes: [{ available: true }] });
      expect(manager.reload({ mode: 'safe' }).status).toBe('applied');
      expect(listVaultUseRecords(fixture.coreDb)).toEqual(before);
      expect(resolves).not.toHaveBeenCalled();
    } finally {
      fixture.close();
    }
  });

  it('keeps independent tiers discoverable and dispatchable when one account is corrupt', async () => {
    const fixture = createFixture();
    try {
      const pair = accountPair('availability');
      await createStoredPair(fixture, pair, 'vault_00000000-0000-737c-8912-8e1270803e33');
      writeAvailabilitySupply(fixture);
      writeFileSync(accountPath(fixture.dataRoot, pair), '{ corrupt account');
      const dispatched = vi.fn(async () => ({
        id: 'independent-result',
        object: 'chat.completion',
        created: 1,
        model: 'gpt-5.1',
        choices: [
          {
            index: 0,
            message: { role: 'assistant', content: 'independent' },
            finish_reason: 'stop',
          },
        ],
      }));
      const manager = createRuntimeConfigManager({
        dataRoot: fixture.dataRoot,
        subscriptionAccounts: fixture.manager,
      });
      const app = createApp({
        dataRoot: fixture.dataRoot,
        coreDb: fixture.coreDb,
        providerSubscriptionAccountManager: fixture.manager,
        runtimeConfigManager: manager,
        llmGatewayDispatcher: {
          createChatCompletion: dispatched,
        } as unknown as LLMGatewayProviderDispatcher,
      });
      const discovery = await app.request('/v1/models');
      expect(discovery.status).toBe(200);
      expect(await discovery.json()).toMatchObject({
        data: [expect.objectContaining({ id: 'independent-tier' })],
      });
      const response = await app.request('/v1/chat/completions', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          model: 'independent-tier',
          messages: [{ role: 'user', content: 'hello' }],
        }),
      });
      expect(response.status).toBe(200);
      expect(dispatched).toHaveBeenCalledTimes(1);
      expect(fixture.manager.gatewayUnavailableReason(pair)).toBe(
        'subscription_account_integrity_unavailable'
      );
      await expect(fixture.manager.getStatus(pair)).rejects.toMatchObject({
        code: 'provider_subscription_persistence_failed',
      });
    } finally {
      fixture.close();
    }
  });

  it('omits pre-owner subscription warnings but marks logged-out production supply unavailable', async () => {
    const fixture = createFixture();
    try {
      const pair = accountPair('availability');
      await fixture.manager.createAccount(pair);
      writeAvailabilitySupply(fixture);
      const boot = loadRuntimeConfig(fixture.dataRoot);
      expect(
        boot.diagnostics.filter((diagnostic) => diagnostic.code === 'gateway.unavailable_member')
      ).toEqual([]);
      expect(
        resolveLogicalModel(
          boot.gatewayConfig,
          boot.providerRegistry,
          'bound-tier',
          fixture.manager
        )
      ).toMatchObject({
        routes: [{ available: false, unavailableReason: 'subscription_account_logged_out' }],
      });
    } finally {
      fixture.close();
    }
  });

  it('projects absent and logged-out Gateway accounts without creating a pair handle', async () => {
    const fixture = createFixture();
    try {
      const pair = accountPair('gateway');
      const configRoot = join(fixture.dataRoot, 'config');
      mkdirSync(join(configRoot, 'providers'), { recursive: true });
      writeFileSync(
        join(configRoot, 'providers', 'bound.provider.jsonc'),
        JSON.stringify({
          id: 'bound',
          displayName: 'Bound',
          kind: 'oauth',
          vendor: 'openai-codex',
          models: ['gpt-5.1'],
          extensions: { openkit: { subscriptionAccount: { accountSlotId: pair.accountSlotId } } },
        })
      );
      writeFileSync(
        join(configRoot, 'gateway.jsonc'),
        JSON.stringify({
          schemaVersion: 1,
          logicalModels: [
            {
              id: 'retained',
              displayName: 'Retained',
              contextManagement: [{ type: 'compaction', compactThreshold: 8_000 }],
              routes: [
                { id: 'account-route', providerProfileId: 'bound', providerModel: 'gpt-5.1' },
              ],
            },
          ],
        })
      );
      const checkSnapshot = (reason: string) => {
        const snapshot = loadRuntimeConfig(fixture.dataRoot, {
          subscriptionAccounts: fixture.manager,
        });
        expect(snapshot.diagnostics).toContainEqual(
          expect.objectContaining({
            code: 'gateway.unavailable_member',
            severity: 'warning',
            message: `Logical model route account-route is unavailable: ${reason}.`,
          })
        );
        const [model] = resolveLogicalModelCatalog(
          snapshot.gatewayConfig,
          snapshot.providerRegistry,
          fixture.manager
        );
        expect(model).toMatchObject({
          id: 'retained',
          routes: [{ available: false, unavailableReason: reason }],
        });
      };
      expect(fixture.manager.gatewayUnavailableReason(pair)).toBe('subscription_account_absent');
      checkSnapshot('subscription_account_absent');
      await fixture.manager.createAccount(pair);
      expect(fixture.manager.gatewayUnavailableReason(pair)).toBe(
        'subscription_account_logged_out'
      );
      checkSnapshot('subscription_account_logged_out');
      fixture.queueReferenceIds('vault_00000000-0000-7856-bb50-e3f9342f4e6a');
      const handle = await fixture.manager.getPairHandle(pair);
      await handle.credentials.modify(pair.subscriptionProviderId, async () =>
        oauthCredential('gateway-live')
      );
      const before = readFileSync(accountPath(fixture.dataRoot, pair), 'utf8');
      expect(fixture.manager.gatewayUnavailableReason(pair)).toBeNull();
      expect(readFileSync(accountPath(fixture.dataRoot, pair), 'utf8')).toBe(before);
      fixture.vaultState.lock();
      expect(fixture.manager.gatewayUnavailableReason(pair)).toBe('subscription_vault_unavailable');
    } finally {
      fixture.close();
    }
  });

  it('strictly creates and updates safe account metadata through monotonic atomic replacement', async () => {
    const fixture = createFixture();
    const pair = accountPair('team_a');
    fixture.clock.use('2026-07-23T01:00:00.000Z');

    const created: ProviderSubscriptionAccountSnapshot = await fixture.manager.createAccount({
      ...pair,
      displayName: 'Team A',
    });
    const exactPath = join(
      fixture.dataRoot,
      'server',
      'files',
      'provider-subscriptions',
      'openai-codex',
      'accounts',
      'team_a',
      'account.json'
    );
    const createdBytes = readFileSync(exactPath, 'utf8');
    const createdRecord = readAccountJson(fixture.dataRoot, pair);

    expect(accountPath(fixture.dataRoot, pair)).toBe(exactPath);
    expect(created).toEqual({
      accountSlotId: 'team_a',
      createdAt: '2026-07-23T01:00:00.000Z',
      displayName: 'Team A',
      status: 'logged_out',
      subscriptionProviderId: 'openai-codex',
      updatedAt: '2026-07-23T01:00:00.000Z',
    });
    expect(createdRecord).toEqual({
      accountSlotId: 'team_a',
      createdAt: '2026-07-23T01:00:00.000Z',
      displayName: 'Team A',
      schemaVersion: 1,
      status: 'logged_out',
      subscriptionProviderId: 'openai-codex',
      updatedAt: '2026-07-23T01:00:00.000Z',
    });
    expect(JSON.stringify(created)).not.toMatch(
      /vaultReferenceId|vault_reference|encrypted-file:\/\//
    );

    const oldDescriptor = openSync(exactPath, 'r');
    fixture.clock.use('2026-07-22T23:00:00.000Z');
    const regressedClockUpdate = await fixture.manager.updateAccount(pair, {
      displayName: 'Team A renamed',
    });

    try {
      expect(readFileSync(oldDescriptor, 'utf8')).toBe(createdBytes);
    } finally {
      closeSync(oldDescriptor);
    }
    expect(readFileSync(exactPath, 'utf8')).not.toBe(createdBytes);
    expect(regressedClockUpdate).toMatchObject({
      createdAt: '2026-07-23T01:00:00.000Z',
      displayName: 'Team A renamed',
      updatedAt: '2026-07-23T01:00:00.000Z',
    });

    fixture.clock.use('2026-07-23T02:00:00.000Z');
    const advanced = await fixture.manager.updateAccount(pair, { displayName: 'Team A final' });
    const listed = await fixture.manager.listAccounts('openai-codex');

    expect(advanced).toMatchObject({
      createdAt: '2026-07-23T01:00:00.000Z',
      displayName: 'Team A final',
      updatedAt: '2026-07-23T02:00:00.000Z',
    });
    expect(listed).toEqual([advanced]);
    expect(JSON.stringify([created, regressedClockUpdate, advanced, listed])).not.toMatch(
      /vaultReferenceId|vault_reference|encrypted-file:\/\//
    );
  });

  describe('invalid records, raw bytes, paths, symlinks, and residue', () => {
    const invalidRecords: Array<{
      readonly name: string;
      readonly pair: ProviderSubscriptionAccountPair;
      readonly record: unknown;
    }> = [
      {
        name: 'unknown field',
        pair: accountPair('unknown_field'),
        record: { ...validAccountRecord(accountPair('unknown_field')), unknown: true },
      },
      {
        name: 'schema scalar',
        pair: accountPair('bad_schema'),
        record: { ...validAccountRecord(accountPair('bad_schema')), schemaVersion: 2 },
      },
      {
        name: 'timestamp scalar',
        pair: accountPair('bad_time'),
        record: { ...validAccountRecord(accountPair('bad_time')), createdAt: '2026-07-23' },
      },
      {
        name: 'invalid status',
        pair: accountPair('bad_status'),
        record: { ...validAccountRecord(accountPair('bad_status')), status: 'signed_in' },
      },
      {
        name: 'null optional scalar',
        pair: accountPair('null_label'),
        record: { ...validAccountRecord(accountPair('null_label')), displayName: null },
      },
      {
        name: 'wrong optional scalar',
        pair: accountPair('wrong_label'),
        record: { ...validAccountRecord(accountPair('wrong_label')), displayName: 42 },
      },
      {
        name: 'empty display name',
        pair: accountPair('empty_label'),
        record: { ...validAccountRecord(accountPair('empty_label')), displayName: '' },
      },
      {
        name: 'oversized Unicode display name',
        pair: accountPair('wide_label'),
        record: { ...validAccountRecord(accountPair('wide_label')), displayName: 'é'.repeat(129) },
      },
      {
        name: 'invalid Unicode scalar',
        pair: accountPair('invalid_unicode'),
        record: {
          ...validAccountRecord(accountPair('invalid_unicode')),
          displayName: '\ud800',
        },
      },
      {
        name: 'invalid account label',
        pair: accountPair('bad_account_label'),
        record: {
          ...validAccountRecord(accountPair('bad_account_label')),
          accountLabel: '',
        },
      },
      {
        name: 'wrong account label scalar',
        pair: accountPair('wrong_account_label'),
        record: {
          ...validAccountRecord(accountPair('wrong_account_label')),
          accountLabel: 7,
        },
      },
      {
        name: 'invalid plan label',
        pair: accountPair('bad_plan_label'),
        record: {
          ...validAccountRecord(accountPair('bad_plan_label')),
          planLabel: '\udfff',
        },
      },
      {
        name: 'oversized plan label',
        pair: accountPair('wide_plan_label'),
        record: {
          ...validAccountRecord(accountPair('wide_plan_label')),
          planLabel: 'p'.repeat(257),
        },
      },
      {
        name: 'unsafe reference scalar',
        pair: accountPair('bad_reference'),
        record: {
          ...validAccountRecord(accountPair('bad_reference')),
          vaultReferenceId: '../vault-secret',
        },
      },
      {
        name: 'null reference scalar',
        pair: accountPair('null_reference'),
        record: {
          ...validAccountRecord(accountPair('null_reference')),
          vaultReferenceId: null,
        },
      },
      {
        name: 'forbidden status message',
        pair: accountPair('forbidden_message'),
        record: {
          ...validAccountRecord(accountPair('forbidden_message')),
          message: 'not allowed',
        },
      },
      {
        name: 'missing status message',
        pair: accountPair('missing_message'),
        record: { ...validAccountRecord(accountPair('missing_message')), status: 'error' },
      },
      {
        name: 'oversized status message',
        pair: accountPair('wide_message'),
        record: {
          ...validAccountRecord(accountPair('wide_message')),
          message: 'x'.repeat(1_025),
          status: 'unavailable',
        },
      },
      {
        name: 'wrong message scalar',
        pair: accountPair('wrong_message'),
        record: {
          ...validAccountRecord(accountPair('wrong_message')),
          message: 12,
          status: 'error',
        },
      },
      {
        name: 'provider path mismatch',
        pair: accountPair('provider_mismatch'),
        record: {
          ...validAccountRecord(accountPair('provider_mismatch')),
          subscriptionProviderId: 'xai',
        },
      },
      {
        name: 'slot path mismatch',
        pair: accountPair('slot_mismatch'),
        record: {
          ...validAccountRecord(accountPair('slot_mismatch')),
          accountSlotId: 'another_slot',
        },
      },
    ];

    it.each(invalidRecords)('rejects invalid record: $name without repair', async (invalid) => {
      const fixture = createFixture();
      writeAccountJson(fixture.dataRoot, invalid.pair, invalid.record);
      const before = authoritySnapshot(fixture);

      await expectAccountError(
        () => fixture.manager.listAccounts('openai-codex'),
        PERSISTENCE_ERROR
      );
      expect(authoritySnapshot(fixture), invalid.name).toEqual(before);
    });

    const malformedUtf8Pair = accountPair('bad_utf8');
    const malformedUtf8Prefix = Buffer.from(
      `{"schemaVersion":1,"subscriptionProviderId":"openai-codex","accountSlotId":"bad_utf8","createdAt":"${DEFAULT_TIME}","updatedAt":"${DEFAULT_TIME}","displayName":"`
    );
    const malformedUtf8Suffix = Buffer.from('","status":"logged_out"}');
    const oversizedPair = accountPair('oversized_file');
    const otherwiseValidJson = JSON.stringify(validAccountRecord(oversizedPair));
    const rawCases: Array<{
      readonly bytes: Uint8Array;
      readonly name: string;
      readonly pair: ProviderSubscriptionAccountPair;
    }> = [
      {
        bytes: Buffer.concat([malformedUtf8Prefix, Buffer.from([0xc3, 0x28]), malformedUtf8Suffix]),
        name: 'malformed UTF-8 inside valid JSON structure',
        pair: malformedUtf8Pair,
      },
      {
        bytes: Buffer.from(`${otherwiseValidJson}${' '.repeat(16_385)}`),
        name: 'otherwise-valid oversized JSON',
        pair: oversizedPair,
      },
    ];

    it.each(rawCases)('rejects raw bytes: $name without repair', async (rawCase) => {
      const fixture = createFixture();
      writeRawAccount(fixture.dataRoot, rawCase.pair, rawCase.bytes);
      const before = authoritySnapshot(fixture);

      await expectAccountError(
        () => fixture.manager.listAccounts('openai-codex'),
        PERSISTENCE_ERROR
      );
      expect(authoritySnapshot(fixture), rawCase.name).toEqual(before);
    });

    it('rejects symlinked account records without repair', async () => {
      const symlinkFixture = createFixture();
      const symlinkPair = accountPair('symlink_record');
      const externalRoot = mkdtempSync(join(tmpdir(), 'openkit-provider-subscription-external-'));
      extraTemporaryRoots.add(externalRoot);
      const externalPath = join(externalRoot, 'account.json');
      const externalBytes = `${JSON.stringify(validAccountRecord(symlinkPair))}\n`;
      mkdirSync(accountDirectory(symlinkFixture.dataRoot, symlinkPair), { recursive: true });
      writeFileSync(externalPath, externalBytes);
      symlinkSync(externalPath, accountPath(symlinkFixture.dataRoot, symlinkPair));
      const symlinkBefore = authoritySnapshot(symlinkFixture);

      await expectAccountError(
        () => symlinkFixture.manager.listAccounts('openai-codex'),
        PERSISTENCE_ERROR
      );
      expect(lstatSync(accountPath(symlinkFixture.dataRoot, symlinkPair)).isSymbolicLink()).toBe(
        true
      );
      expect(readFileSync(externalPath, 'utf8')).toBe(externalBytes);
      expect(authoritySnapshot(symlinkFixture)).toEqual(symlinkBefore);
    });

    it('rejects symlinked account directories without repair', async () => {
      const slotSymlinkFixture = createFixture();
      const slotSymlinkPair = accountPair('symlink_slot');
      const slotSymlinkExternalRoot = mkdtempSync(
        join(tmpdir(), 'openkit-provider-subscription-slot-external-')
      );
      extraTemporaryRoots.add(slotSymlinkExternalRoot);
      const slotSymlinkExternalPath = join(slotSymlinkExternalRoot, 'account.json');
      const slotSymlinkExternalBytes = `${JSON.stringify(validAccountRecord(slotSymlinkPair))}\n`;
      mkdirSync(join(accountDirectory(slotSymlinkFixture.dataRoot, slotSymlinkPair), '..'), {
        recursive: true,
      });
      writeFileSync(slotSymlinkExternalPath, slotSymlinkExternalBytes);
      symlinkSync(
        slotSymlinkExternalRoot,
        accountDirectory(slotSymlinkFixture.dataRoot, slotSymlinkPair)
      );
      const slotSymlinkCoreBefore = slotSymlinkFixture.coreDb.sqlite
        .prepare('SELECT * FROM vault_references ORDER BY reference_id ASC')
        .all();
      const slotSymlinkVaultBefore = slotSymlinkFixture.backend().listReferences();

      await expectAccountError(
        () => slotSymlinkFixture.manager.listAccounts('openai-codex'),
        PERSISTENCE_ERROR
      );
      expect(
        lstatSync(accountDirectory(slotSymlinkFixture.dataRoot, slotSymlinkPair)).isSymbolicLink()
      ).toBe(true);
      expect(readFileSync(slotSymlinkExternalPath, 'utf8')).toBe(slotSymlinkExternalBytes);
      expect(
        slotSymlinkFixture.coreDb.sqlite
          .prepare('SELECT * FROM vault_references ORDER BY reference_id ASC')
          .all()
      ).toEqual(slotSymlinkCoreBefore);
      expect(slotSymlinkFixture.backend().listReferences()).toEqual(slotSymlinkVaultBefore);
    });

    it('rejects directory residue without repair', async () => {
      const residueFixture = createFixture();
      const residuePair = accountPair('directory_residue');
      mkdirSync(accountDirectory(residueFixture.dataRoot, residuePair), { recursive: true });
      writeFileSync(
        join(accountDirectory(residueFixture.dataRoot, residuePair), 'residue.txt'),
        'keep'
      );
      const residueBefore = authoritySnapshot(residueFixture);

      await expectAccountError(
        () => residueFixture.manager.listAccounts('openai-codex'),
        PERSISTENCE_ERROR
      );
      expect(authoritySnapshot(residueFixture)).toEqual(residueBefore);
    });

    it('rejects escaping account paths without repair', async () => {
      const pathFixture = createFixture();
      const pathBefore = authoritySnapshot(pathFixture);

      await expectAccountError(
        () =>
          pathFixture.manager.createAccount({
            accountSlotId: '../escape',
            subscriptionProviderId: 'openai-codex',
          }),
        SLOT_ERROR
      );
      await expectAccountError(
        () =>
          pathFixture.manager.createAccount({
            accountSlotId: '/tmp/escape',
            subscriptionProviderId: 'openai-codex',
          }),
        SLOT_ERROR
      );
      expect(authoritySnapshot(pathFixture)).toEqual(pathBefore);
    });
  });

  describe('pair authority classification', () => {
    const validCases: Array<{
      readonly name: string;
      readonly pair: ProviderSubscriptionAccountPair;
      readonly prepare: (
        fixture: ProviderSubscriptionFixture,
        pair: ProviderSubscriptionAccountPair
      ) => void;
      readonly expected: readonly Partial<ProviderSubscriptionAccountSnapshot>[];
    }> = [
      {
        expected: [],
        name: 'clean absence',
        pair: accountPair('clean_absence'),
        prepare: () => {},
      },
      {
        expected: [],
        name: 'completed histories',
        pair: accountPair('completed_histories'),
        prepare: (fixture, pair) => {
          createCompletedHistory(fixture, pair, 'vault_00000000-0000-758f-8b5e-f60cf57cb185');
          createCompletedHistory(fixture, pair, 'vault_00000000-0000-7307-8f04-cb493e5503eb');
        },
      },
      {
        expected: [{ accountSlotId: 'unbound', status: 'logged_out' }],
        name: 'unbound account',
        pair: accountPair('unbound'),
        prepare: (fixture, pair) => {
          writeAccountJson(fixture.dataRoot, pair, validAccountRecord(pair));
        },
      },
      {
        expected: [{ accountSlotId: 'live', status: 'logged_in' }],
        name: 'live account',
        pair: accountPair('live'),
        prepare: (fixture, pair) => {
          createLivePair(fixture, pair, 'vault_00000000-0000-7d72-9297-fbfffc9a831d');
        },
      },
    ];

    it.each(validCases)('classifies valid authority: $name', async (validCase) => {
      const fixture = createFixture();
      validCase.prepare(fixture, validCase.pair);
      const before = authoritySnapshot(fixture);
      const accounts = await fixture.manager.listAccounts('openai-codex');

      expect(accounts, validCase.name).toEqual(
        validCase.expected.map((expected) =>
          expect.objectContaining({
            subscriptionProviderId: 'openai-codex',
            ...expected,
          })
        )
      );
      expect(authoritySnapshot(fixture), validCase.name).toEqual(before);
    });

    const invalidCases: Array<{
      readonly name: string;
      readonly pair: ProviderSubscriptionAccountPair;
      readonly prepare: (
        fixture: ProviderSubscriptionFixture,
        pair: ProviderSubscriptionAccountPair
      ) => void;
    }> = [
      {
        name: 'ambiguous bound plus zero',
        pair: accountPair('ambiguous'),
        prepare: (fixture, pair) => {
          writeAccountJson(
            fixture.dataRoot,
            pair,
            validAccountRecord(pair, {
              vaultReferenceId: 'vault_00000000-0000-78c0-9ebb-5ccf1170e4c4',
            })
          );
          createExactCoreReference(fixture, 'vault_00000000-0000-78c0-9ebb-5ccf1170e4c4');
        },
      },
      {
        name: 'current tombstone',
        pair: accountPair('current_tombstone'),
        prepare: (fixture, pair) => {
          createLivePair(fixture, pair, 'vault_00000000-0000-7884-8d99-170b285a4d4a');
          fixture.backend().revoke({ referenceId: 'vault_00000000-0000-7884-8d99-170b285a4d4a' });
        },
      },
      {
        name: 'invalid completed history',
        pair: accountPair('invalid_history'),
        prepare: (fixture, pair) => {
          createCompletedHistory(fixture, pair, 'vault_00000000-0000-7732-8819-318a6ca800a3');
          mutateCoreReference(
            fixture,
            'vault_00000000-0000-7732-8819-318a6ca800a3',
            "status = 'active'"
          );
        },
      },
      {
        name: 'extra live reference',
        pair: accountPair('extra_live'),
        prepare: (fixture, pair) => {
          createLivePair(fixture, pair, 'vault_00000000-0000-7148-94cf-173991b1ac7e');
          createExactCoreReference(fixture, 'vault_00000000-0000-7671-80a7-055a099db178');
          fixture.backend().store({
            material: JSON.stringify(oauthCredential('extra-live-r2')),
            metadata: { ownerScope: 'server', providerSubscriptionAccount: pair },
            referenceId: 'vault_00000000-0000-7671-80a7-055a099db178',
          });
        },
      },
      {
        name: 'live orphan',
        pair: accountPair('orphan'),
        prepare: (fixture, pair) => {
          createLivePair(fixture, pair, 'vault_00000000-0000-7437-9883-74fba0368dbd');
          rmSync(accountDirectory(fixture.dataRoot, pair), { force: true, recursive: true });
        },
      },
      {
        name: 'corrupt record',
        pair: accountPair('corrupt'),
        prepare: (fixture, pair) => {
          writeAccountJson(fixture.dataRoot, pair, {
            ...validAccountRecord(pair),
            residue: true,
          });
        },
      },
    ];

    it.each(invalidCases)('rejects invalid authority: $name', async (invalidCase) => {
      const fixture = createFixture();
      invalidCase.prepare(fixture, invalidCase.pair);
      const before = authoritySnapshot(fixture);

      await expectAccountError(
        () => fixture.manager.listAccounts('openai-codex'),
        PERSISTENCE_ERROR
      );
      expect(authoritySnapshot(fixture), invalidCase.name).toEqual(before);
    });

    const coreViolations: Array<{
      readonly name: string;
      readonly mutate: (fixture: ProviderSubscriptionFixture, referenceId: string) => void;
    }> = [
      { name: 'missing row', mutate: deleteCoreReference },
      {
        name: 'wrong version',
        mutate: (fixture, referenceId) =>
          mutateCoreReference(fixture, referenceId, 'current_version = 2'),
      },
      {
        name: 'wrong status',
        mutate: (fixture, referenceId) =>
          mutateCoreReference(fixture, referenceId, "status = 'revoked'"),
      },
      {
        name: 'wrong reference identity',
        mutate: (fixture, referenceId) =>
          mutateCoreReference(fixture, referenceId, `reference_id = '${referenceId}_other'`),
      },
      {
        name: 'wrong owner scope',
        mutate: (fixture, referenceId) =>
          mutateCoreReference(fixture, referenceId, "owner_scope = 'workspace'"),
      },
      {
        name: 'wrong workspace scope identity',
        mutate: (fixture, referenceId) =>
          mutateCoreReference(
            fixture,
            referenceId,
            "workspace_id = 'ws_00000000-0000-769e-b6a6-c9fdf1f7d7d9'"
          ),
      },
      {
        name: 'wrong user scope identity',
        mutate: (fixture, referenceId) =>
          mutateCoreReference(
            fixture,
            referenceId,
            "user_id = 'usr_00000000-0000-7a95-af2d-863b23e018b3'"
          ),
      },
      {
        name: 'wrong display label',
        mutate: (fixture, referenceId) =>
          mutateCoreReference(fixture, referenceId, "display_name = 'Wrong label'"),
      },
      {
        name: 'wrong secret kind',
        mutate: (fixture, referenceId) =>
          mutateCoreReference(fixture, referenceId, "secret_kind = 'provider-api-key'"),
      },
      {
        name: 'wrong backend kind',
        mutate: (fixture, referenceId) =>
          mutateCoreReference(fixture, referenceId, "backend_kind = 'wrong-backend'"),
      },
      {
        name: 'wrong backend locator',
        mutate: (fixture, referenceId) =>
          mutateCoreReference(fixture, referenceId, "backend_locator = 'encrypted-file:wrong'"),
      },
    ];

    // Live bindings and completed histories have independent authority checks and test budgets.
    it.each(
      coreViolations.flatMap((violation, index) => [
        { ...violation, authority: 'live' as const, index },
        { ...violation, authority: 'history' as const, index },
      ])
    )('rejects $authority Core authority: $name', async (violation) => {
      const fixture = createFixture();
      const pair = accountPair(`${violation.authority}_core_${violation.index}`);
      const referenceId = testEntityId('vault', `${violation.authority}_core_r${violation.index}`);
      if (violation.authority === 'live') {
        createLivePair(fixture, pair, referenceId);
      } else {
        createCompletedHistory(fixture, pair, referenceId);
      }
      if (violation.authority === 'history' && violation.name === 'wrong status') {
        mutateCoreReference(fixture, referenceId, "status = 'active'");
      } else {
        violation.mutate(fixture, referenceId);
      }
      const before = authoritySnapshot(fixture);

      await expectAccountError(
        () => fixture.manager.listAccounts('openai-codex'),
        PERSISTENCE_ERROR
      );
      expect(authoritySnapshot(fixture), `${violation.authority} ${violation.name}`).toEqual(
        before
      );
    });

    // Keep both ordered pairs in one fixture: list failure must not return the preceding valid pair.
    it('rejects a mixed provider list without partial results', async () => {
      const allOrNothing = createFixture();
      const goodPair = accountPair('a_good');
      const badPair = accountPair('z_bad');
      writeAccountJson(allOrNothing.dataRoot, goodPair, validAccountRecord(goodPair));
      writeAccountJson(
        allOrNothing.dataRoot,
        badPair,
        validAccountRecord(badPair, {
          vaultReferenceId: 'vault_00000000-0000-7186-9211-c4d61fd1701b',
        })
      );
      createExactCoreReference(allOrNothing, 'vault_00000000-0000-7186-9211-c4d61fd1701b');
      const allOrNothingBefore = authoritySnapshot(allOrNothing);

      await expectAccountError(
        () => allOrNothing.manager.listAccounts('openai-codex'),
        PERSISTENCE_ERROR
      );
      expect(authoritySnapshot(allOrNothing)).toEqual(allOrNothingBefore);
    });
  });

  it('commits an initial OAuth credential in binding-Core-Vault order and rejects reused Core rows', async () => {
    const fixture = createFixture();
    const pair = accountPair('initial_store');
    fixture.queueReferenceIds('vault_00000000-0000-74ca-9472-d99dcaf4497c');
    await fixture.manager.createAccount({ ...pair, displayName: 'Initial Store' });
    const backend = fixture.backend();
    const realStore = backend.store.bind(backend);
    const observedOrder: string[] = [];

    expect(
      getVaultReference(fixture.coreDb, 'vault_00000000-0000-74ca-9472-d99dcaf4497c')
    ).toBeNull();
    fixture.coreDb.sqlite.function('observe_initial_binding', () => {
      expect(readAccountJson(fixture.dataRoot, pair)).toMatchObject({
        vaultReferenceId: 'vault_00000000-0000-74ca-9472-d99dcaf4497c',
      });
      observedOrder.push('binding-before-core');
      return 1;
    });
    fixture.coreDb.sqlite.exec(
      "CREATE TEMP TRIGGER observe_initial_core_insert\n      BEFORE INSERT ON vault_references\n      FOR EACH ROW\n      WHEN NEW.reference_id = 'vault_00000000-0000-74ca-9472-d99dcaf4497c'\n      BEGIN\n        SELECT observe_initial_binding();\n      END"
    );

    vi.spyOn(backend, 'store').mockImplementation((input) => {
      const coreAtStore = getVaultReference(fixture.coreDb, input.referenceId);

      expect(coreAtStore).toMatchObject({
        backendKind: 'encrypted-file',
        backendLocator: 'encrypted-file://server/vault/vault_00000000-0000-74ca-9472-d99dcaf4497c',
        currentVersion: 1,
        displayName: 'Provider subscription credential',
        ownerScope: 'server',
        referenceId: 'vault_00000000-0000-74ca-9472-d99dcaf4497c',
        secretKind: 'provider-subscription-oauth',
        status: 'active',
        userId: null,
        workspaceId: null,
      });
      observedOrder.push('vault-after-core');
      return realStore(input);
    });

    const handle: ProviderSubscriptionPairHandle = await fixture.manager.getPairHandle(pair);
    const credential = oauthCredential('initial');
    const stored = await handle.credentials.modify('openai-codex', async (current) => {
      expect(current).toBeUndefined();
      return credential;
    });

    expect(stored).toEqual(credential);
    expect(observedOrder).toEqual(['binding-before-core', 'vault-after-core']);
    expect(readAccountJson(fixture.dataRoot, pair)).toMatchObject({
      status: 'logged_in',
      vaultReferenceId: 'vault_00000000-0000-74ca-9472-d99dcaf4497c',
    });
    expect(
      getVaultReference(fixture.coreDb, 'vault_00000000-0000-74ca-9472-d99dcaf4497c')
    ).toMatchObject({
      backendKind: 'encrypted-file',
      backendLocator: 'encrypted-file://server/vault/vault_00000000-0000-74ca-9472-d99dcaf4497c',
      currentVersion: 1,
      displayName: 'Provider subscription credential',
      ownerScope: 'server',
      referenceId: 'vault_00000000-0000-74ca-9472-d99dcaf4497c',
      secretKind: 'provider-subscription-oauth',
      status: 'active',
      userId: null,
      workspaceId: null,
    });
    expect(backend.listReferences()).toEqual([
      expect.objectContaining({
        backendKind: 'encrypted-file',
        currentVersion: 1,
        ownerScope: 'server',
        providerSubscriptionAccount: pair,
        referenceId: 'vault_00000000-0000-74ca-9472-d99dcaf4497c',
        revoked: false,
        versionCount: 1,
      }),
    ]);
    expect(JSON.stringify(await fixture.manager.listAccounts('openai-codex'))).not.toContain(
      'vault_00000000-0000-74ca-9472-d99dcaf4497c'
    );

    const reusedFixture = createFixture();
    const reusedPair = accountPair('reused_core');
    reusedFixture.queueReferenceIds('vault_00000000-0000-7bc1-9737-fc66c69d2cfc');
    await reusedFixture.manager.createAccount(reusedPair);
    createExactCoreReference(reusedFixture, 'vault_00000000-0000-7bc1-9737-fc66c69d2cfc');
    const reusedCoreBefore = getVaultReference(
      reusedFixture.coreDb,
      'vault_00000000-0000-7bc1-9737-fc66c69d2cfc'
    );
    const reusedBackend = reusedFixture.backend();
    const reusedStore = vi.spyOn(reusedBackend, 'store');
    const reusedHandle = await reusedFixture.manager.getPairHandle(reusedPair);

    await expectAccountError(
      () =>
        reusedHandle.credentials.modify('openai-codex', async (current) => {
          expect(current).toBeUndefined();
          return oauthCredential('must-not-store');
        }),
      PERSISTENCE_ERROR
    );
    expect(readAccountJson(reusedFixture.dataRoot, reusedPair)).toMatchObject({
      vaultReferenceId: 'vault_00000000-0000-7bc1-9737-fc66c69d2cfc',
    });
    expect(
      getVaultReference(reusedFixture.coreDb, 'vault_00000000-0000-7bc1-9737-fc66c69d2cfc')
    ).toEqual(reusedCoreBefore);
    expect(reusedStore).not.toHaveBeenCalled();
    expect(reusedBackend.listReferences()).toEqual([]);

    const failedStoreFixture = createFixture();
    const failedStorePair = accountPair('failed_initial_store');
    failedStoreFixture.queueReferenceIds('vault_00000000-0000-796c-aace-24efd1eba4ae');
    await failedStoreFixture.manager.createAccount(failedStorePair);
    const failedStoreHandle = await failedStoreFixture.manager.getPairHandle(failedStorePair);
    const failedStoreBackend = failedStoreFixture.backend();
    const persistenceFailureCanary = 'raw-backend-persistence-canary';
    const rawPersistenceFailure = Object.assign(
      new Error(`${persistenceFailureCanary}-message`, {
        cause: new Error(`${persistenceFailureCanary}-cause`),
      }),
      { providerBody: `${persistenceFailureCanary}-enumerable` }
    );
    const failedStoreSpy = vi.spyOn(failedStoreBackend, 'store').mockImplementationOnce(() => {
      throw rawPersistenceFailure;
    });

    const failedStoreError = await expectAccountError(
      () =>
        failedStoreHandle.credentials.modify('openai-codex', async () =>
          oauthCredential('failed-initial')
        ),
      PERSISTENCE_ERROR
    );
    expect(JSON.stringify(completeErrorProjection(failedStoreError))).not.toContain(
      persistenceFailureCanary
    );
    expect(readAccountJson(failedStoreFixture.dataRoot, failedStorePair)).toMatchObject({
      status: 'logged_out',
      vaultReferenceId: 'vault_00000000-0000-796c-aace-24efd1eba4ae',
    });
    expect(
      getVaultReference(failedStoreFixture.coreDb, 'vault_00000000-0000-796c-aace-24efd1eba4ae')
    ).toMatchObject({
      currentVersion: 1,
      status: 'active',
    });
    expect(failedStoreBackend.listReferences()).toEqual([]);

    const failedStoreManager = failedStoreFixture.createManager();
    const failedStoreFreshHandle = await failedStoreManager.getPairHandle(failedStorePair);
    const ambiguousBefore = authoritySnapshot(failedStoreFixture);
    failedStoreFixture.queueReferenceIds('vault_00000000-0000-796c-aace-24efd1eba4ae');

    for (const operation of [
      () =>
        failedStoreFreshHandle.credentials.modify('openai-codex', async () =>
          oauthCredential('must-not-reuse')
        ),
      () => failedStoreFreshHandle.credentials.delete('openai-codex'),
      () => failedStoreManager.reconcileAccount(failedStorePair),
      () => failedStoreManager.createAccount(failedStorePair),
    ]) {
      await expectAccountError(operation, PERSISTENCE_ERROR);
      expect(authoritySnapshot(failedStoreFixture)).toEqual(ambiguousBefore);
    }
    expect(failedStoreSpy).toHaveBeenCalledTimes(1);

    const committedStoreFixture = createFixture();
    const committedStorePair = accountPair('committed_initial_store');
    committedStoreFixture.queueReferenceIds('vault_00000000-0000-7d5b-9359-5d1ad65e5b8a');
    await committedStoreFixture.manager.createAccount(committedStorePair);
    const committedStoreHandle =
      await committedStoreFixture.manager.getPairHandle(committedStorePair);
    const committedStoreBackend = committedStoreFixture.backend();
    const realCommittedStore = committedStoreBackend.store.bind(committedStoreBackend);
    const committedStoreSpy = vi
      .spyOn(committedStoreBackend, 'store')
      .mockImplementationOnce((input) => {
        realCommittedStore(input);
        throw new Error('injected post-commit store failure');
      });
    const committedCredential = oauthCredential('committed-initial');

    await expectAccountError(
      () =>
        committedStoreHandle.credentials.modify('openai-codex', async () => committedCredential),
      PERSISTENCE_ERROR
    );
    expect(readAccountJson(committedStoreFixture.dataRoot, committedStorePair)).toMatchObject({
      status: 'logged_out',
      vaultReferenceId: 'vault_00000000-0000-7d5b-9359-5d1ad65e5b8a',
    });
    expect(committedStoreBackend.listReferences()).toEqual([
      expect.objectContaining({
        currentVersion: 1,
        referenceId: 'vault_00000000-0000-7d5b-9359-5d1ad65e5b8a',
        revoked: false,
      }),
    ]);

    const committedStoreManager = committedStoreFixture.createManager();
    const committedFreshHandle = await committedStoreManager.getPairHandle(committedStorePair);
    const reconciled = await committedStoreManager.reconcileAccount(committedStorePair);

    expect(reconciled).toMatchObject({ status: 'logged_in' });
    expect(JSON.stringify(reconciled)).not.toContain('vault_00000000-0000-7d5b-9359-5d1ad65e5b8a');
    expect(committedStoreSpy).toHaveBeenCalledTimes(1);
    await expect(committedFreshHandle.credentials.read('openai-codex')).resolves.toEqual(
      committedCredential
    );

    const projectionFixture = createFixture();
    const projectionPair = accountPair('post_store_projection');
    projectionFixture.queueReferenceIds('vault_00000000-0000-70e6-9cea-826b52206198');
    await projectionFixture.manager.createAccount(projectionPair);
    const projectionHandle = await projectionFixture.manager.getPairHandle(projectionPair);
    const projectionBackend = projectionFixture.backend();
    const realProjectionStore = projectionBackend.store.bind(projectionBackend);
    const projectionAccountDirectory = accountDirectory(projectionFixture.dataRoot, projectionPair);
    const parkedProjectionAccountDirectory = `${projectionAccountDirectory}.parked`;

    vi.spyOn(projectionBackend, 'store').mockImplementationOnce((input) => {
      const entry = realProjectionStore(input);
      renameSync(projectionAccountDirectory, parkedProjectionAccountDirectory);
      writeFileSync(projectionAccountDirectory, 'projection blocker', { mode: 0o600 });
      return entry;
    });

    await expectAccountError(
      () =>
        projectionHandle.credentials.modify('openai-codex', async () =>
          oauthCredential('post-store-projection')
        ),
      PROJECTION_ERROR
    );
    unlinkSync(projectionAccountDirectory);
    renameSync(parkedProjectionAccountDirectory, projectionAccountDirectory);
    expect(await projectionFixture.manager.reconcileAccount(projectionPair)).toMatchObject({
      status: 'logged_in',
    });
  });

  it('repairs lower positive Core versions stepwise and fails closed on ahead or mismatched reconciliation', async () => {
    const repairFixture = createFixture();
    const repairPair = accountPair('repair_one');
    await createStoredPair(repairFixture, repairPair, 'vault_00000000-0000-7e18-868c-b624f7ce0203');
    repairFixture.backend().rotate({
      material: JSON.stringify(oauthCredential('repair-v2')),
      referenceId: 'vault_00000000-0000-7e18-868c-b624f7ce0203',
    });
    writeAccountJson(
      repairFixture.dataRoot,
      repairPair,
      validAccountRecord(repairPair, {
        message: 'Safe stale projection.',
        status: 'unavailable',
        vaultReferenceId: 'vault_00000000-0000-7e18-868c-b624f7ce0203',
      })
    );

    const repaired = await repairFixture.manager.reconcileAccount(repairPair);

    expect(repaired).toEqual({
      accountSlotId: 'repair_one',
      createdAt: DEFAULT_TIME,
      status: 'logged_in',
      subscriptionProviderId: 'openai-codex',
      updatedAt: DEFAULT_TIME,
    });
    expect(
      getVaultReference(repairFixture.coreDb, 'vault_00000000-0000-7e18-868c-b624f7ce0203')
    ).toMatchObject({
      currentVersion: 2,
      status: 'active',
    });
    expect(readAccountJson(repairFixture.dataRoot, repairPair)).toEqual({
      accountSlotId: 'repair_one',
      createdAt: DEFAULT_TIME,
      schemaVersion: 1,
      status: 'logged_in',
      subscriptionProviderId: 'openai-codex',
      updatedAt: DEFAULT_TIME,
      vaultReferenceId: 'vault_00000000-0000-7e18-868c-b624f7ce0203',
    });
    expect(JSON.stringify(repaired)).not.toContain('vault_00000000-0000-7e18-868c-b624f7ce0203');

    const equalBefore = authoritySnapshot(repairFixture);
    const equal = await repairFixture.manager.reconcileAll();

    expect(equal).toEqual([repaired]);
    expect(authoritySnapshot(repairFixture)).toEqual(equalBefore);

    const catchupFixture = createFixture();
    const catchupPair = accountPair('repair_two_steps');
    await createStoredPair(
      catchupFixture,
      catchupPair,
      'vault_00000000-0000-7625-902f-23c3e8ad21a0'
    );
    catchupFixture.backend().rotate({
      material: JSON.stringify(oauthCredential('repair-two-steps-v2')),
      referenceId: 'vault_00000000-0000-7625-902f-23c3e8ad21a0',
    });
    catchupFixture.backend().rotate({
      material: JSON.stringify(oauthCredential('repair-two-steps-v3')),
      referenceId: 'vault_00000000-0000-7625-902f-23c3e8ad21a0',
    });
    writeAccountJson(
      catchupFixture.dataRoot,
      catchupPair,
      validAccountRecord(catchupPair, {
        message: 'Safe stale projection.',
        status: 'unavailable',
        vaultReferenceId: 'vault_00000000-0000-7625-902f-23c3e8ad21a0',
      })
    );
    catchupFixture.coreDb.sqlite.exec(
      "CREATE TEMP TRIGGER reject_direct_version_jump\n      BEFORE UPDATE OF current_version ON vault_references\n      FOR EACH ROW\n      WHEN OLD.reference_id = 'vault_00000000-0000-7625-902f-23c3e8ad21a0'\n        AND OLD.current_version = 1\n        AND NEW.current_version = 3\n      BEGIN\n        SELECT RAISE(FAIL, 'direct version jump rejected');\n      END"
    );

    const caughtUp = await catchupFixture.manager.reconcileAccount(catchupPair);

    expect(caughtUp).toMatchObject({ status: 'logged_in' });
    expect(
      getVaultReference(catchupFixture.coreDb, 'vault_00000000-0000-7625-902f-23c3e8ad21a0')
    ).toMatchObject({
      currentVersion: 3,
      status: 'active',
    });
    expect(catchupFixture.backend().listReferences()).toEqual([
      expect.objectContaining({
        currentVersion: 3,
        referenceId: 'vault_00000000-0000-7625-902f-23c3e8ad21a0',
        versionCount: 3,
      }),
    ]);

    const projectionFixture = createFixture();
    const projectionPair = accountPair('post_rotate_projection');
    const projectionHandle = await createStoredPair(
      projectionFixture,
      projectionPair,
      'vault_00000000-0000-7b9d-a719-036501daa980'
    );
    const rotatedProjectionCredential = oauthCredential('post-rotate-projection-v2');
    projectionFixture.coreDb.sqlite.exec(
      "CREATE TEMP TRIGGER fail_post_rotate_core_projection\n      BEFORE UPDATE OF current_version ON vault_references\n      FOR EACH ROW\n      WHEN OLD.reference_id = 'vault_00000000-0000-7b9d-a719-036501daa980'\n        AND OLD.current_version = 1\n        AND NEW.current_version = 2\n      BEGIN\n        SELECT RAISE(FAIL, 'injected post-rotate Core projection failure');\n      END"
    );

    await expectAccountError(
      () =>
        projectionHandle.credentials.modify(
          'openai-codex',
          async () => rotatedProjectionCredential
        ),
      PROJECTION_ERROR
    );
    expect(
      getVaultReference(projectionFixture.coreDb, 'vault_00000000-0000-7b9d-a719-036501daa980')
    ).toMatchObject({
      currentVersion: 1,
      status: 'active',
    });
    expect(projectionFixture.backend().listReferences()).toEqual([
      expect.objectContaining({
        currentVersion: 2,
        referenceId: 'vault_00000000-0000-7b9d-a719-036501daa980',
        revoked: false,
      }),
    ]);
    projectionFixture.coreDb.sqlite.exec('DROP TRIGGER fail_post_rotate_core_projection');
    expect(await projectionFixture.manager.reconcileAccount(projectionPair)).toMatchObject({
      status: 'logged_in',
    });
    expect(
      getVaultReference(projectionFixture.coreDb, 'vault_00000000-0000-7b9d-a719-036501daa980')
    ).toMatchObject({
      currentVersion: 2,
      status: 'active',
    });
    await expect(projectionHandle.credentials.read('openai-codex')).resolves.toEqual(
      rotatedProjectionCredential
    );

    const invalidCases: Array<{
      readonly name: string;
      readonly prepare: (
        fixture: ProviderSubscriptionFixture,
        pair: ProviderSubscriptionAccountPair,
        referenceId: string
      ) => void;
    }> = [
      {
        name: 'Core is N+1',
        prepare: (fixture, _pair, referenceId) => {
          mutateCoreReference(fixture, referenceId, 'current_version = 2');
        },
      },
      {
        name: 'Core identity mismatch',
        prepare: (fixture, _pair, referenceId) => {
          mutateCoreReference(fixture, referenceId, "display_name = 'Wrong credential label'");
        },
      },
    ];

    for (const [index, invalidCase] of invalidCases.entries()) {
      const fixture = createFixture();
      const pair = accountPair(`reconcile_invalid_${index}`);
      const referenceId = testEntityId('vault', `reconcile_invalid_r${index}`);
      await createStoredPair(fixture, pair, referenceId);
      invalidCase.prepare(fixture, pair, referenceId);
      const before = authoritySnapshot(fixture);

      await expectAccountError(() => fixture.manager.reconcileAccount(pair), PERSISTENCE_ERROR);
      expect(authoritySnapshot(fixture), invalidCase.name).toEqual(before);
    }
  });

  it('continues tombstoned credential and account removal and recreates only with a fresh reference', async () => {
    const credentialFixture = createFixture();
    const pair = accountPair('delete_and_recreate');
    const originalHandle = await createStoredPair(
      credentialFixture,
      pair,
      'vault_00000000-0000-714b-90e0-ad74e40d0547',
      oauthCredential('delete-r1')
    );
    createReferenceCascade(
      credentialFixture,
      'vault_00000000-0000-714b-90e0-ad74e40d0547',
      'credential_delete'
    );
    const backend = credentialFixture.backend();
    const realRevoke = backend.revoke.bind(backend);
    const revokeCalls: string[] = [];

    vi.spyOn(backend, 'revoke').mockImplementation((input) => {
      revokeCalls.push(input.referenceId);
      expect(readAccountJson(credentialFixture.dataRoot, pair)).toMatchObject({
        vaultReferenceId: input.referenceId,
      });
      expect(getVaultReference(credentialFixture.coreDb, input.referenceId)).toMatchObject({
        status: 'active',
      });
      return realRevoke(input);
    });
    credentialFixture.coreDb.sqlite.exec(`CREATE TEMP TRIGGER fail_credential_delete_cascade
      BEFORE UPDATE OF status ON vault_grants
      FOR EACH ROW
      WHEN OLD.grant_id = '${testEntityId('grant', 'grant_credential_delete')}'
        AND OLD.status = 'active'
        AND NEW.status = 'revoked'
      BEGIN
        SELECT RAISE(FAIL, 'injected credential delete cascade failure');
      END`);

    await expectAccountError(
      () => originalHandle.credentials.delete('openai-codex'),
      PERSISTENCE_ERROR
    );
    expect(revokeCalls).toEqual(['vault_00000000-0000-714b-90e0-ad74e40d0547']);
    expect(backend.listReferences()).toEqual([
      expect.objectContaining({
        referenceId: 'vault_00000000-0000-714b-90e0-ad74e40d0547',
        revoked: true,
      }),
    ]);
    expect(
      getVaultReference(credentialFixture.coreDb, 'vault_00000000-0000-714b-90e0-ad74e40d0547')
    ).toMatchObject({
      currentVersion: 1,
      status: 'active',
    });
    expect(readCascadeStatuses(credentialFixture, 'credential_delete')).toEqual({
      grant: 'active',
      plan: 'active',
      receipt: 'active',
    });
    expect(readAccountJson(credentialFixture.dataRoot, pair)).toMatchObject({
      vaultReferenceId: 'vault_00000000-0000-714b-90e0-ad74e40d0547',
    });

    credentialFixture.coreDb.sqlite.exec('DROP TRIGGER fail_credential_delete_cascade');
    await originalHandle.credentials.delete('openai-codex');

    expect(revokeCalls).toEqual(['vault_00000000-0000-714b-90e0-ad74e40d0547']);
    expect(
      getVaultReference(credentialFixture.coreDb, 'vault_00000000-0000-714b-90e0-ad74e40d0547')
    ).toMatchObject({
      currentVersion: 1,
      status: 'revoked',
    });
    expect(readCascadeStatuses(credentialFixture, 'credential_delete')).toEqual({
      grant: 'revoked',
      plan: 'revoked',
      receipt: 'stale-session',
    });
    expect(readAccountJson(credentialFixture.dataRoot, pair)).toEqual({
      accountSlotId: 'delete_and_recreate',
      createdAt: DEFAULT_TIME,
      schemaVersion: 1,
      status: 'logged_out',
      subscriptionProviderId: 'openai-codex',
      updatedAt: DEFAULT_TIME,
    });

    await credentialFixture.manager.deleteAccount(pair);
    expect(existsSync(accountDirectory(credentialFixture.dataRoot, pair))).toBe(false);
    const historicalCore = getVaultReference(
      credentialFixture.coreDb,
      'vault_00000000-0000-714b-90e0-ad74e40d0547'
    );
    const historicalVault = backend
      .listReferences()
      .find((entry) => entry.referenceId === 'vault_00000000-0000-714b-90e0-ad74e40d0547');

    credentialFixture.queueReferenceIds('vault_00000000-0000-71d6-9dc8-b788d619dcc5');
    await credentialFixture.manager.createAccount(pair);
    const freshHandle = await credentialFixture.manager.getPairHandle(pair);
    await freshHandle.credentials.modify('openai-codex', async () => oauthCredential('delete-r2'));

    expect(readAccountJson(credentialFixture.dataRoot, pair)).toMatchObject({
      status: 'logged_in',
      vaultReferenceId: 'vault_00000000-0000-71d6-9dc8-b788d619dcc5',
    });
    expect(
      getVaultReference(credentialFixture.coreDb, 'vault_00000000-0000-714b-90e0-ad74e40d0547')
    ).toEqual(historicalCore);
    expect(
      backend
        .listReferences()
        .find((entry) => entry.referenceId === 'vault_00000000-0000-714b-90e0-ad74e40d0547')
    ).toEqual(historicalVault);
    expect(
      getVaultReference(credentialFixture.coreDb, 'vault_00000000-0000-71d6-9dc8-b788d619dcc5')
    ).toMatchObject({
      currentVersion: 1,
      status: 'active',
    });
    expect(backend.listReferences()).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          referenceId: 'vault_00000000-0000-714b-90e0-ad74e40d0547',
          revoked: true,
        }),
        expect.objectContaining({
          referenceId: 'vault_00000000-0000-71d6-9dc8-b788d619dcc5',
          revoked: false,
        }),
      ])
    );

    const revokedCredentialFixture = createFixture();
    const revokedCredentialPair = accountPair('credential_revoked_prefix');
    const revokedCredentialHandle = await createStoredPair(
      revokedCredentialFixture,
      revokedCredentialPair,
      'vault_00000000-0000-77e9-8488-0253ad6dc8ef'
    );
    createReferenceCascade(
      revokedCredentialFixture,
      'vault_00000000-0000-77e9-8488-0253ad6dc8ef',
      'credential_revoked'
    );
    revokedCredentialFixture
      .backend()
      .revoke({ referenceId: 'vault_00000000-0000-77e9-8488-0253ad6dc8ef' });
    revokeVaultReference(revokedCredentialFixture.coreDb, {
      referenceId: 'vault_00000000-0000-77e9-8488-0253ad6dc8ef',
    });
    const credentialRetryWrites = [
      vi.spyOn(revokedCredentialFixture.backend(), 'store'),
      vi.spyOn(revokedCredentialFixture.backend(), 'rotate'),
      vi.spyOn(revokedCredentialFixture.backend(), 'revoke'),
    ];

    await revokedCredentialHandle.credentials.delete('openai-codex');

    for (const write of credentialRetryWrites) {
      expect(write).not.toHaveBeenCalled();
    }
    expect(readAccountJson(revokedCredentialFixture.dataRoot, revokedCredentialPair)).toEqual({
      accountSlotId: 'credential_revoked_prefix',
      createdAt: DEFAULT_TIME,
      schemaVersion: 1,
      status: 'logged_out',
      subscriptionProviderId: 'openai-codex',
      updatedAt: DEFAULT_TIME,
    });
    expect(readCascadeStatuses(revokedCredentialFixture, 'credential_revoked')).toEqual({
      grant: 'revoked',
      plan: 'revoked',
      receipt: 'stale-session',
    });

    const accountDeleteFixture = createFixture();
    const accountDeletePair = accountPair('account_delete_tombstone');
    await createStoredPair(
      accountDeleteFixture,
      accountDeletePair,
      'vault_00000000-0000-7896-a380-266fe3139fc2'
    );
    createReferenceCascade(
      accountDeleteFixture,
      'vault_00000000-0000-7896-a380-266fe3139fc2',
      'account_delete'
    );
    accountDeleteFixture
      .backend()
      .revoke({ referenceId: 'vault_00000000-0000-7896-a380-266fe3139fc2' });
    revokeVaultReference(accountDeleteFixture.coreDb, {
      referenceId: 'vault_00000000-0000-7896-a380-266fe3139fc2',
    });
    const accountRetryWrites = [
      vi.spyOn(accountDeleteFixture.backend(), 'store'),
      vi.spyOn(accountDeleteFixture.backend(), 'rotate'),
      vi.spyOn(accountDeleteFixture.backend(), 'revoke'),
    ];

    await accountDeleteFixture.manager.deleteAccount(accountDeletePair);

    for (const write of accountRetryWrites) {
      expect(write).not.toHaveBeenCalled();
    }
    expect(existsSync(accountDirectory(accountDeleteFixture.dataRoot, accountDeletePair))).toBe(
      false
    );
    expect(
      getVaultReference(accountDeleteFixture.coreDb, 'vault_00000000-0000-7896-a380-266fe3139fc2')
    ).toMatchObject({
      currentVersion: 1,
      status: 'revoked',
    });
    expect(readCascadeStatuses(accountDeleteFixture, 'account_delete')).toEqual({
      grant: 'revoked',
      plan: 'revoked',
      receipt: 'stale-session',
    });
    expect(accountDeleteFixture.backend().listReferences()).toEqual([
      expect.objectContaining({
        referenceId: 'vault_00000000-0000-7896-a380-266fe3139fc2',
        revoked: true,
      }),
    ]);

    const laggedCredentialFixture = createFixture();
    const laggedCredentialPair = accountPair('lagged_credential_delete');
    const laggedCredentialHandle = await createStoredPair(
      laggedCredentialFixture,
      laggedCredentialPair,
      'vault_00000000-0000-725b-9c05-795eea4c7e9f'
    );
    const laggedCredentialBackend = laggedCredentialFixture.backend();
    laggedCredentialBackend.rotate({
      material: JSON.stringify(oauthCredential('lagged-credential-v2')),
      referenceId: 'vault_00000000-0000-725b-9c05-795eea4c7e9f',
    });
    laggedCredentialBackend.rotate({
      material: JSON.stringify(oauthCredential('lagged-credential-v3')),
      referenceId: 'vault_00000000-0000-725b-9c05-795eea4c7e9f',
    });
    laggedCredentialFixture.coreDb.sqlite.exec(
      "CREATE TEMP TRIGGER reject_lagged_direct_jump\n      BEFORE UPDATE OF current_version ON vault_references\n      FOR EACH ROW\n      WHEN OLD.reference_id = 'vault_00000000-0000-725b-9c05-795eea4c7e9f'\n        AND OLD.current_version = 1\n        AND NEW.current_version = 3\n      BEGIN\n        SELECT RAISE(FAIL, 'direct lagged credential version jump rejected');\n      END"
    );
    const realLaggedCredentialRevoke = laggedCredentialBackend.revoke.bind(laggedCredentialBackend);
    const laggedCredentialRevoke = vi
      .spyOn(laggedCredentialBackend, 'revoke')
      .mockImplementation((input) => {
        expect(getVaultReference(laggedCredentialFixture.coreDb, input.referenceId)).toMatchObject({
          currentVersion: 3,
          status: 'active',
        });
        return realLaggedCredentialRevoke(input);
      });

    try {
      await laggedCredentialHandle.credentials.delete('openai-codex');
    } finally {
      laggedCredentialFixture.coreDb.sqlite.exec('DROP TRIGGER reject_lagged_direct_jump');
    }
    expect(laggedCredentialRevoke).toHaveBeenCalledTimes(1);
    expect(
      getVaultReference(
        laggedCredentialFixture.coreDb,
        'vault_00000000-0000-725b-9c05-795eea4c7e9f'
      )
    ).toMatchObject({
      currentVersion: 3,
      status: 'revoked',
    });
    expect(laggedCredentialBackend.listReferences()).toEqual([
      expect.objectContaining({
        currentVersion: 3,
        referenceId: 'vault_00000000-0000-725b-9c05-795eea4c7e9f',
        revoked: true,
      }),
    ]);
    expect(readAccountJson(laggedCredentialFixture.dataRoot, laggedCredentialPair)).toMatchObject({
      status: 'logged_out',
    });

    const laggedAccountFixture = createFixture();
    const laggedAccountPair = accountPair('lagged_account_delete');
    await createStoredPair(
      laggedAccountFixture,
      laggedAccountPair,
      'vault_00000000-0000-7913-a948-75d42085943e'
    );
    const laggedAccountBackend = laggedAccountFixture.backend();
    laggedAccountBackend.rotate({
      material: JSON.stringify(oauthCredential('lagged-account-v2')),
      referenceId: 'vault_00000000-0000-7913-a948-75d42085943e',
    });
    const realLaggedAccountRevoke = laggedAccountBackend.revoke.bind(laggedAccountBackend);
    const laggedAccountRevoke = vi
      .spyOn(laggedAccountBackend, 'revoke')
      .mockImplementation((input) => {
        expect(getVaultReference(laggedAccountFixture.coreDb, input.referenceId)).toMatchObject({
          currentVersion: 2,
          status: 'active',
        });
        return realLaggedAccountRevoke(input);
      });

    await laggedAccountFixture.manager.deleteAccount(laggedAccountPair);
    expect(laggedAccountRevoke).toHaveBeenCalledTimes(1);
    expect(existsSync(accountDirectory(laggedAccountFixture.dataRoot, laggedAccountPair))).toBe(
      false
    );
    expect(
      getVaultReference(laggedAccountFixture.coreDb, 'vault_00000000-0000-7913-a948-75d42085943e')
    ).toMatchObject({
      currentVersion: 2,
      status: 'revoked',
    });
    expect(laggedAccountBackend.listReferences()).toEqual([
      expect.objectContaining({
        currentVersion: 2,
        referenceId: 'vault_00000000-0000-7913-a948-75d42085943e',
        revoked: true,
      }),
    ]);

    const failedCatchupFixture = createFixture();
    const failedCatchupPair = accountPair('failed_delete_catchup');
    const failedCatchupHandle = await createStoredPair(
      failedCatchupFixture,
      failedCatchupPair,
      'vault_00000000-0000-7a1d-9d63-ff006a833ab7'
    );
    failedCatchupFixture.backend().rotate({
      material: JSON.stringify(oauthCredential('failed-delete-catchup-v2')),
      referenceId: 'vault_00000000-0000-7a1d-9d63-ff006a833ab7',
    });
    failedCatchupFixture.coreDb.sqlite.exec(
      "CREATE TEMP TRIGGER fail_delete_core_catchup\n      BEFORE UPDATE OF current_version ON vault_references\n      FOR EACH ROW\n      WHEN OLD.reference_id = 'vault_00000000-0000-7a1d-9d63-ff006a833ab7'\n      BEGIN\n        SELECT RAISE(FAIL, 'injected delete catch-up failure');\n      END"
    );
    const failedCatchupRevoke = vi.spyOn(failedCatchupFixture.backend(), 'revoke');
    const failedCatchupBefore = authoritySnapshot(failedCatchupFixture);

    await expectAccountError(
      () => failedCatchupHandle.credentials.delete('openai-codex'),
      PERSISTENCE_ERROR
    );
    expect(failedCatchupRevoke).not.toHaveBeenCalled();
    expect(authoritySnapshot(failedCatchupFixture)).toEqual(failedCatchupBefore);
  });

  it('implements the exact pair-scoped stock CredentialStore contract without hidden resolution', async () => {
    const foreignFixture = createFixture();
    const foreignPair = accountPair('foreign_guard');
    await foreignFixture.manager.createAccount(foreignPair);
    const foreignHandle = await foreignFixture.manager.getPairHandle(foreignPair);
    writeAccountJson(foreignFixture.dataRoot, foreignPair, {
      ...validAccountRecord(foreignPair),
      corrupt: true,
    });
    const corruptAccountBytes = readFileSync(accountPath(foreignFixture.dataRoot, foreignPair));
    const poisonedBackend = foreignFixture.backend();
    const backendSpies = [
      vi.spyOn(poisonedBackend, 'health').mockImplementation(() => {
        throw new Error('foreign provider reached backend health');
      }),
      vi.spyOn(poisonedBackend, 'listReferences').mockImplementation(() => {
        throw new Error('foreign provider reached backend inventory');
      }),
      vi.spyOn(poisonedBackend, 'resolve').mockImplementation(() => {
        throw new Error('foreign provider reached backend resolve');
      }),
      vi.spyOn(poisonedBackend, 'store').mockImplementation(() => {
        throw new Error('foreign provider reached backend store');
      }),
      vi.spyOn(poisonedBackend, 'rotate').mockImplementation(() => {
        throw new Error('foreign provider reached backend rotate');
      }),
      vi.spyOn(poisonedBackend, 'revoke').mockImplementation(() => {
        throw new Error('foreign provider reached backend revoke');
      }),
    ];
    foreignFixture.replaceBackend(poisonedBackend);
    foreignFixture.coreDb.sqlite.close();
    foreignFixture.resetBackendGetterCalls();
    let foreignCallbackCalled = false;

    for (const operation of [
      () => foreignHandle.credentials.read('xai'),
      () =>
        foreignHandle.credentials.modify('xai', async () => {
          foreignCallbackCalled = true;
          return oauthCredential('foreign');
        }),
      () => foreignHandle.credentials.delete('xai'),
    ]) {
      await expectAccountError(operation, PROVIDER_ERROR);
    }
    expect(foreignCallbackCalled).toBe(false);
    expect(foreignFixture.backendGetterCalls()).toBe(0);
    expect(readFileSync(accountPath(foreignFixture.dataRoot, foreignPair))).toEqual(
      corruptAccountBytes
    );
    for (const backendSpy of backendSpies) {
      expect(backendSpy).not.toHaveBeenCalled();
    }

    const missingFixture = createFixture();
    const missingPair = accountPair('missing_credential');
    await missingFixture.manager.createAccount(missingPair);
    const missingHandle = await missingFixture.manager.getPairHandle(missingPair);
    const missingBefore = authoritySnapshot(missingFixture);

    await expect(missingHandle.credentials.read('openai-codex')).resolves.toBeUndefined();
    await expect(missingHandle.credentials.delete('openai-codex')).resolves.toBeUndefined();
    expect(authoritySnapshot(missingFixture)).toEqual(missingBefore);

    const fixture = createFixture();
    const pair = accountPair('credential_contract');
    fixture.queueReferenceIds('vault_00000000-0000-7e4b-a9df-97cdf108637a');
    await fixture.manager.createAccount(pair);
    const handle = await fixture.manager.getPairHandle(pair);
    const backend = fixture.backend();
    const realResolve = backend.resolve.bind(backend);
    const resolve = vi.spyOn(backend, 'resolve');
    const resolvedMaterialBuffers: Uint8Array[] = [];
    resolve.mockImplementation((input) => {
      const material = realResolve(input);

      expect(material).toBeInstanceOf(Uint8Array);
      resolvedMaterialBuffers.push(material as Uint8Array);
      return material;
    });

    await expect(handle.credentials.list()).resolves.toEqual([]);
    expect(resolve).not.toHaveBeenCalled();

    const completeCredential = oauthCredential('complete-extra-fields');
    await expect(
      handle.credentials.modify('openai-codex', async (current) => {
        expect(current).toBeUndefined();
        return completeCredential;
      })
    ).resolves.toEqual(completeCredential);
    await expect(handle.credentials.list()).resolves.toEqual([
      { providerId: 'openai-codex', type: 'oauth' },
    ]);
    expect(resolve).not.toHaveBeenCalled();
    await expect(handle.credentials.read('openai-codex')).resolves.toEqual(completeCredential);
    expect(resolvedMaterialBuffers).toHaveLength(1);
    expect.soft(resolvedMaterialBuffers[0]?.every((byte) => byte === 0)).toBe(true);

    const undefinedBefore = authoritySnapshot(fixture);
    await expect(
      handle.credentials.modify('openai-codex', async (current) => {
        expect(current).toEqual(completeCredential);
        return undefined;
      })
    ).resolves.toEqual(completeCredential);
    expect(resolvedMaterialBuffers).toHaveLength(2);
    expect.soft(resolvedMaterialBuffers[1]?.every((byte) => byte === 0)).toBe(true);
    expect(authoritySnapshot(fixture)).toEqual(undefinedBefore);

    const replacementCredential = oauthCredential('complete-replacement');
    await expect(
      handle.credentials.modify('openai-codex', async (current) => {
        expect(current).toEqual(completeCredential);
        return replacementCredential;
      })
    ).resolves.toEqual(replacementCredential);
    expect(
      getVaultReference(fixture.coreDb, 'vault_00000000-0000-7e4b-a9df-97cdf108637a')
    ).toMatchObject({
      currentVersion: 2,
      status: 'active',
    });
    expect(backend.listReferences()).toEqual([
      expect.objectContaining({
        currentVersion: 2,
        referenceId: 'vault_00000000-0000-7e4b-a9df-97cdf108637a',
        revoked: false,
      }),
    ]);
    expect(resolvedMaterialBuffers).toHaveLength(3);
    expect(resolvedMaterialBuffers[2]?.every((byte) => byte === 0)).toBe(true);

    const updaterFailure = new Error('updater rejection must propagate unchanged');
    const updaterFailureBefore = authoritySnapshot(fixture);
    await expect(
      handle.credentials.modify('openai-codex', async () => {
        throw updaterFailure;
      })
    ).rejects.toBe(updaterFailure);
    expect(authoritySnapshot(fixture)).toEqual(updaterFailureBefore);

    const apiKeyBefore = authoritySnapshot(fixture);
    await expectAccountError(
      () =>
        handle.credentials.modify(
          'openai-codex',
          async () => ({ key: 'api-key-write-must-fail', type: 'api_key' }) as never
        ),
      PERSISTENCE_ERROR
    );
    expect(authoritySnapshot(fixture)).toEqual(apiKeyBefore);

    const siblingFixture = createFixture();
    const siblingTargetPair = accountPair('sibling_target');
    const siblingTargetHandle = await createStoredPair(
      siblingFixture,
      siblingTargetPair,
      'vault_00000000-0000-7fe9-881b-5d9cd6b1e92c'
    );
    const corruptSiblingPair = accountPair('corrupt_sibling');
    await siblingFixture.manager.createAccount(corruptSiblingPair);
    writeAccountJson(siblingFixture.dataRoot, corruptSiblingPair, {
      ...validAccountRecord(corruptSiblingPair),
      corrupt: true,
    });
    const siblingResolve = vi.spyOn(siblingFixture.backend(), 'resolve');
    const siblingBefore = authoritySnapshot(siblingFixture);

    await expect(siblingTargetHandle.credentials.list()).resolves.toEqual([
      { providerId: 'openai-codex', type: 'oauth' },
    ]);
    expect(siblingResolve).not.toHaveBeenCalled();
    expect(authoritySnapshot(siblingFixture)).toEqual(siblingBefore);

    const inventoryFixture = createFixture();
    const inventoryPair = accountPair('inventory_owner');
    const inventoryHandle = await createStoredPair(
      inventoryFixture,
      inventoryPair,
      'vault_00000000-0000-78d9-8a93-45e55f0d69c2'
    );
    const orphanPair = accountPair('inventory_orphan');
    createExactCoreReference(inventoryFixture, 'vault_00000000-0000-7d62-bbbc-80393536f030');
    inventoryFixture.backend().store({
      material: JSON.stringify(oauthCredential('inventory-orphan')),
      metadata: { ownerScope: 'server', providerSubscriptionAccount: orphanPair },
      referenceId: 'vault_00000000-0000-7d62-bbbc-80393536f030',
    });
    const inventoryResolve = vi.spyOn(inventoryFixture.backend(), 'resolve');
    const inventoryBefore = authoritySnapshot(inventoryFixture);

    await expectAccountError(() => inventoryHandle.credentials.list(), PERSISTENCE_ERROR);
    expect(inventoryResolve).not.toHaveBeenCalled();
    expect(authoritySnapshot(inventoryFixture)).toEqual(inventoryBefore);

    const malformedCases = [
      {
        material: JSON.stringify({ key: 'api-key-must-not-be-accepted', type: 'api_key' }),
        name: 'api_key material',
      },
      {
        material: JSON.stringify({ access: 'missing-refresh', expires: 1, type: 'oauth' }),
        name: 'malformed OAuth material',
      },
    ];

    for (const [index, malformedCase] of malformedCases.entries()) {
      const malformedFixture = createFixture();
      const malformedPair = accountPair(`malformed_material_${index}`);
      createLiveMaterialPair(
        malformedFixture,
        malformedPair,
        testEntityId('vault', `malformed_material_r${index}`),
        malformedCase.material
      );
      const malformedHandle = await malformedFixture.manager.getPairHandle(malformedPair);
      const before = authoritySnapshot(malformedFixture);

      await expectAccountError(
        () => malformedHandle.credentials.read('openai-codex'),
        PERSISTENCE_ERROR
      );
      expect(authoritySnapshot(malformedFixture), malformedCase.name).toEqual(before);
    }

    const deepEqualReplacement: OAuthCredential = {
      ...replacementCredential,
      scope: [...(replacementCredential.scope ?? [])],
    };
    expect(deepEqualReplacement).toEqual(replacementCredential);
    expect(deepEqualReplacement).not.toBe(replacementCredential);
    await expect(
      handle.credentials.modify('openai-codex', async (current) => {
        expect(current).toEqual(replacementCredential);
        return deepEqualReplacement;
      })
    ).resolves.toEqual(deepEqualReplacement);
    expect(
      getVaultReference(fixture.coreDb, 'vault_00000000-0000-7e4b-a9df-97cdf108637a')
    ).toMatchObject({
      currentVersion: 3,
      status: 'active',
    });
  });

  it('serializes same-pair refresh and delete while allowing cross-pair progress and fresh generations', async () => {
    const fixture = createFixture();
    const firstPair = accountPair('shared_slot', 'openai-codex');
    const secondPair = accountPair('shared_slot', 'xai');
    const firstHandle = await createStoredPair(
      fixture,
      firstPair,
      'vault_00000000-0000-7127-8fee-0fd1850e0940',
      oauthCredential('serialized-a-v1')
    );
    const secondHandle = await createStoredPair(
      fixture,
      secondPair,
      'vault_00000000-0000-7c73-9db2-b7d9ce679998',
      oauthCredential('concurrent-b-v1')
    );
    const refreshEntered = deferredGate();
    const releaseRefresh = deferredGate();
    const events: string[] = [];
    const firstBackend = fixture.backend();
    const realRevoke = firstBackend.revoke.bind(firstBackend);

    vi.spyOn(firstBackend, 'revoke').mockImplementation((input) => {
      events.push(`revoke:${input.referenceId}`);
      expect(firstBackend.listReferences()).toContainEqual(
        expect.objectContaining({
          currentVersion: 3,
          referenceId: 'vault_00000000-0000-7127-8fee-0fd1850e0940',
          revoked: false,
          versionCount: 3,
        })
      );
      expect(
        getVaultReference(fixture.coreDb, 'vault_00000000-0000-7127-8fee-0fd1850e0940')
      ).toMatchObject({
        currentVersion: 3,
        status: 'active',
      });
      return realRevoke(input);
    });

    const refresh = firstHandle.credentials.modify('openai-codex', async (current) => {
      events.push('refresh:start');
      expect(current).toEqual(oauthCredential('serialized-a-v1'));
      refreshEntered.resolve();
      await releaseRefresh.promise;
      events.push('refresh:end');
      return oauthCredential('serialized-a-v2');
    });
    await refreshEntered.promise;

    let secondModifyCallbackCalled = false;
    const secondSamePairModify = firstHandle.credentials.modify('openai-codex', async (current) => {
      secondModifyCallbackCalled = true;
      events.push('second-modify');
      expect(current).toEqual(oauthCredential('serialized-a-v2'));
      return oauthCredential('serialized-a-v3');
    });
    let deleteSettled = false;
    const deletion = firstHandle.credentials.delete('openai-codex').finally(() => {
      deleteSettled = true;
    });
    let resurrectionCallbackCalled = false;
    const queuedResurrection = firstHandle.credentials.modify('openai-codex', async () => {
      resurrectionCallbackCalled = true;
      return oauthCredential('must-not-resurrect');
    });
    const crossPair = secondHandle.credentials.modify('xai', async (current) => {
      events.push('cross-pair');
      expect(current).toEqual(oauthCredential('concurrent-b-v1'));
      return oauthCredential('concurrent-b-v2');
    });

    await expect(crossPair).resolves.toEqual(oauthCredential('concurrent-b-v2'));
    expect(events).toEqual(['refresh:start', 'cross-pair']);
    expect(deleteSettled).toBe(false);
    expect(secondModifyCallbackCalled).toBe(false);
    expect(resurrectionCallbackCalled).toBe(false);

    releaseRefresh.resolve();
    await expect(refresh).resolves.toEqual(oauthCredential('serialized-a-v2'));
    await expect(secondSamePairModify).resolves.toEqual(oauthCredential('serialized-a-v3'));
    await deletion;
    await expectAccountError(() => queuedResurrection, PERSISTENCE_ERROR);

    expect(resurrectionCallbackCalled).toBe(false);
    expect(events).toEqual([
      'refresh:start',
      'cross-pair',
      'refresh:end',
      'second-modify',
      'revoke:vault_00000000-0000-7127-8fee-0fd1850e0940',
    ]);
    expect(firstBackend.listReferences()).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          currentVersion: 3,
          referenceId: 'vault_00000000-0000-7127-8fee-0fd1850e0940',
          revoked: true,
          versionCount: 3,
        }),
        expect.objectContaining({
          currentVersion: 2,
          referenceId: 'vault_00000000-0000-7c73-9db2-b7d9ce679998',
          revoked: false,
          versionCount: 2,
        }),
      ])
    );
    expect(
      getVaultReference(fixture.coreDb, 'vault_00000000-0000-7127-8fee-0fd1850e0940')
    ).toMatchObject({
      currentVersion: 3,
      status: 'revoked',
    });

    await fixture.manager.deleteAccount(firstPair);
    fixture.queueReferenceIds('vault_00000000-0000-7788-bd5b-b7b57dea1648');
    await fixture.manager.createAccount(firstPair);
    const freshHandle = await fixture.manager.getPairHandle(firstPair);

    expect(freshHandle).not.toBe(firstHandle);
    expect(freshHandle.credentials).not.toBe(firstHandle.credentials);
    expect(freshHandle.models).not.toBe(firstHandle.models);
    await expect(
      freshHandle.credentials.modify('openai-codex', async () => oauthCredential('fresh-r2'))
    ).resolves.toEqual(oauthCredential('fresh-r2'));
    await expect(freshHandle.credentials.read('openai-codex')).resolves.toEqual(
      oauthCredential('fresh-r2')
    );
    const staleBefore = authoritySnapshot(fixture);
    let staleCallbackCalled = false;

    for (const staleOperation of [
      () => firstHandle.credentials.read('openai-codex'),
      () =>
        firstHandle.credentials.modify('openai-codex', async () => {
          staleCallbackCalled = true;
          return oauthCredential('stale-write');
        }),
      () => firstHandle.credentials.delete('openai-codex'),
    ]) {
      await expectAccountError(staleOperation, PERSISTENCE_ERROR);
      expect(authoritySnapshot(fixture)).toEqual(staleBefore);
    }
    await expect(firstHandle.models.checkAuth('openai-codex')).rejects.toThrow();
    expect(staleCallbackCalled).toBe(false);
    expect(authoritySnapshot(fixture)).toEqual(staleBefore);
    expect(readAccountJson(fixture.dataRoot, firstPair)).toMatchObject({
      status: 'logged_in',
      vaultReferenceId: 'vault_00000000-0000-7788-bd5b-b7b57dea1648',
    });

    const boundFixture = createFixture();
    const boundPair = accountPair('queued_bound_delete');
    const boundHandle = await createStoredPair(
      boundFixture,
      boundPair,
      'vault_00000000-0000-7f08-b0f9-22238b3dbff1',
      oauthCredential('queued-bound-v1')
    );
    const boundRefreshEntered = deferredGate();
    const releaseBoundRefresh = deferredGate();
    const boundRevoke = vi.spyOn(boundFixture.backend(), 'revoke');
    const rotatedBoundCredential = oauthCredential('queued-bound-v2');
    const boundRefresh = boundHandle.credentials.modify(
      boundPair.subscriptionProviderId,
      async (current) => {
        expect(current).toEqual(oauthCredential('queued-bound-v1'));
        boundRefreshEntered.resolve();
        await releaseBoundRefresh.promise;
        return rotatedBoundCredential;
      }
    );
    await boundRefreshEntered.promise;
    const boundDeletion = boundFixture.manager.deleteAccount(boundPair);
    releaseBoundRefresh.resolve();
    await boundRefresh;
    await expect(boundDeletion).resolves.toBeUndefined();
    expect(boundRevoke).toHaveBeenCalledOnce();
    expect(
      getVaultReference(boundFixture.coreDb, 'vault_00000000-0000-7f08-b0f9-22238b3dbff1')
    ).toMatchObject({
      currentVersion: 2,
      status: 'revoked',
    });
    expect(
      existsSync(
        join(
          boundFixture.dataRoot,
          'server/files/provider-subscriptions',
          boundPair.subscriptionProviderId,
          'accounts',
          boundPair.accountSlotId,
          'account.json'
        )
      )
    ).toBe(false);
  });

  it('caches one provider-only stock Models generation per pair and follows dynamic Vault replacement', async () => {
    const fixture = createFixture();
    const legacyRoot = mkdtempSync(join(tmpdir(), 'openkit-legacy-codex-home-'));
    extraTemporaryRoots.add(legacyRoot);
    writeFileSync(
      join(legacyRoot, 'auth.json'),
      JSON.stringify({
        'openai-codex': oauthCredential('legacy-file-must-be-ignored'),
      })
    );
    vi.stubEnv('CODEX_HOME', legacyRoot);
    vi.stubEnv('OPENAI_API_KEY', 'ambient-openai-key-must-be-ignored');
    vi.stubEnv('XAI_API_KEY', 'ambient-xai-key-must-be-ignored');

    const xaiPair = accountPair('xai_primary', 'xai');
    const secondXaiPair = accountPair('xai_secondary', 'xai');
    const codexPair = accountPair('codex_primary');
    await fixture.manager.createAccount(xaiPair);
    await fixture.manager.createAccount(secondXaiPair);
    await fixture.manager.createAccount(codexPair);

    const xaiHandle = await fixture.manager.getPairHandle(xaiPair);
    const cachedXaiHandle = await fixture.manager.getPairHandle(xaiPair);
    const secondXaiHandle = await fixture.manager.getPairHandle(secondXaiPair);
    const codexHandle = await fixture.manager.getPairHandle(codexPair);

    expect(cachedXaiHandle).toBe(xaiHandle);
    expect(cachedXaiHandle.credentials).toBe(xaiHandle.credentials);
    expect(cachedXaiHandle.models).toBe(xaiHandle.models);
    expect(xaiHandle.models.getProviders().map((provider) => provider.id)).toEqual(['xai']);
    expect(codexHandle.models.getProviders().map((provider) => provider.id)).toEqual([
      'openai-codex',
    ]);
    expect(secondXaiHandle).not.toBe(xaiHandle);
    expect(secondXaiHandle.credentials).not.toBe(xaiHandle.credentials);
    expect(secondXaiHandle.models).not.toBe(xaiHandle.models);
    expect(codexHandle.models).not.toBe(xaiHandle.models);
    await expect(xaiHandle.models.checkAuth('xai')).resolves.toBeUndefined();
    await expect(codexHandle.models.checkAuth('openai-codex')).resolves.toBeUndefined();

    fixture.queueReferenceIds('vault_00000000-0000-70d2-9b5d-c428a8891741');
    const codexCredential = oauthCredential('dynamic-backend-codex');
    await codexHandle.credentials.modify('openai-codex', async (current) => {
      expect(current).toBeUndefined();
      return codexCredential;
    });
    await expect(codexHandle.models.checkAuth('openai-codex')).resolves.toEqual({
      source: 'OAuth',
      type: 'oauth',
    });
    const codexAuth = await codexHandle.models.getAuth('openai-codex');
    expect(codexAuth).toMatchObject({ source: 'OAuth' });
    expect(JSON.stringify(codexAuth)).toContain(codexCredential.access);

    const dynamicBackend = fixture.vaultState.backend();
    const listReferenceInputs: unknown[] = [];
    const listReplacementBackend: VaultBackend = {
      health: () => dynamicBackend.health(),
      kind: dynamicBackend.kind,
      listReferences: (input) => {
        listReferenceInputs.push(input);
        return dynamicBackend.listReferences(input);
      },
      resolve: (input) => dynamicBackend.resolve(input),
      revoke: (input) => dynamicBackend.revoke(input),
      rotate: (input) => dynamicBackend.rotate(input),
      store: (input) => dynamicBackend.store(input),
    };

    fixture.resetBackendGetterCalls();
    fixture.replaceBackend(listReplacementBackend);
    await expect(xaiHandle.credentials.list()).resolves.toEqual([]);
    expect(listReferenceInputs).not.toEqual([]);
    const afterList = fixture.backendGetterCalls();
    expect(afterList).toBeGreaterThan(0);

    fixture.queueReferenceIds('vault_00000000-0000-7f14-80e1-b9ad27e4a521');
    const credential = oauthCredential('dynamic-backend');
    const initialStoreInputs: unknown[] = [];
    const storeReplacementBackend: VaultBackend = {
      health: () => dynamicBackend.health(),
      kind: dynamicBackend.kind,
      listReferences: (input) => dynamicBackend.listReferences(input),
      resolve: (input) => dynamicBackend.resolve(input),
      revoke: (input) => dynamicBackend.revoke(input),
      rotate: (input) => dynamicBackend.rotate(input),
      store: (input) => {
        initialStoreInputs.push(input);
        return dynamicBackend.store(input);
      },
    };

    fixture.replaceBackend(storeReplacementBackend);
    await xaiHandle.credentials.modify('xai', async () => credential);
    expect(initialStoreInputs).toEqual([
      expect.objectContaining({ referenceId: 'vault_00000000-0000-7f14-80e1-b9ad27e4a521' }),
    ]);
    const afterInitialStore = fixture.backendGetterCalls();
    expect(afterInitialStore).toBeGreaterThan(afterList);

    await expect(xaiHandle.models.checkAuth('xai')).resolves.toEqual({
      source: 'OAuth',
      type: 'oauth',
    });
    const afterCheckAuth = fixture.backendGetterCalls();
    expect(afterCheckAuth).toBeGreaterThan(afterInitialStore);
    const auth = await xaiHandle.models.getAuth('xai');

    expect(auth).toMatchObject({ source: 'OAuth' });
    expect(JSON.stringify(auth)).toContain(credential.access);
    await expect(secondXaiHandle.models.checkAuth('xai')).resolves.toBeUndefined();
    await expect(secondXaiHandle.models.getAuth('xai')).resolves.toBeUndefined();
    const afterGetAuth = fixture.backendGetterCalls();
    expect(afterGetAuth).toBeGreaterThan(afterCheckAuth);

    const rotatedCredential = oauthCredential('dynamic-backend-v2');
    const rotationInputs: unknown[] = [];
    const rotationReplacementBackend: VaultBackend = {
      health: () => dynamicBackend.health(),
      kind: dynamicBackend.kind,
      listReferences: (input) => dynamicBackend.listReferences(input),
      resolve: (input) => dynamicBackend.resolve(input),
      revoke: (input) => dynamicBackend.revoke(input),
      rotate: (input) => {
        rotationInputs.push(input);
        return dynamicBackend.rotate(input);
      },
      store: (input) => dynamicBackend.store(input),
    };

    fixture.replaceBackend(rotationReplacementBackend);
    await xaiHandle.credentials.modify('xai', async (current) => {
      expect(current).toEqual(credential);
      return rotatedCredential;
    });
    expect(rotationInputs).toEqual([
      expect.objectContaining({ referenceId: 'vault_00000000-0000-7f14-80e1-b9ad27e4a521' }),
    ]);
    const afterRotation = fixture.backendGetterCalls();
    expect(afterRotation).toBeGreaterThan(afterGetAuth);
    await expect(xaiHandle.credentials.read('xai')).resolves.toEqual(rotatedCredential);
    const afterRead = fixture.backendGetterCalls();
    expect(afterRead).toBeGreaterThan(afterRotation);

    fixture.replaceBackend();
    fixture.vaultState.lock();
    await expectAccountError(() => xaiHandle.credentials.read('xai'), LOCKED_ERROR);
    const afterLockedRead = fixture.backendGetterCalls();
    expect(afterLockedRead).toBeGreaterThan(afterRead);
    fixture.vaultState.unlock({ masterKey: Buffer.alloc(32, 23) });
    const unlockedBackend = fixture.vaultState.backend();
    const replacementResolve = vi.spyOn(unlockedBackend, 'resolve');
    const replacementRevoke = vi.spyOn(unlockedBackend, 'revoke');
    const replacementBackend: VaultBackend = {
      health: unlockedBackend.health.bind(unlockedBackend),
      kind: unlockedBackend.kind,
      listReferences: unlockedBackend.listReferences.bind(unlockedBackend),
      resolve: (input) => unlockedBackend.resolve(input),
      revoke: (input) => unlockedBackend.revoke(input),
      rotate: unlockedBackend.rotate.bind(unlockedBackend),
      store: unlockedBackend.store.bind(unlockedBackend),
    };
    fixture.replaceBackend(replacementBackend);

    expect(await fixture.manager.getPairHandle(xaiPair)).toBe(xaiHandle);
    await expect(xaiHandle.credentials.read('xai')).resolves.toEqual(rotatedCredential);
    expect(replacementResolve).toHaveBeenCalled();
    const afterReplacementRead = fixture.backendGetterCalls();
    expect(afterReplacementRead).toBeGreaterThan(afterLockedRead);
    await xaiHandle.credentials.delete('xai');
    expect(replacementRevoke).toHaveBeenCalledTimes(1);
    expect(fixture.backendGetterCalls()).toBeGreaterThan(afterReplacementRead);
    await expect(xaiHandle.models.checkAuth('xai')).resolves.toBeUndefined();
    await expect(secondXaiHandle.models.checkAuth('xai')).resolves.toBeUndefined();
    expect(codexHandle.models.getProviders().map((provider) => provider.id)).toEqual([
      'openai-codex',
    ]);
  });

  it('emits exact lifecycle success and failure evidence while plaintext canaries stay encrypted', async () => {
    const fixture = createFixture();
    const pair = accountPair('audit_lifecycle');
    const accessCanary = 'access-canary-never-plaintext';
    const refreshCanary = 'refresh-canary-never-plaintext';
    const accountCanary = 'acct_00000000-0000-7fd8-9675-4a16f2592128';
    const emailCanary = 'raw-email-canary@example.invalid';
    const upstreamCanary = 'upstream-body-canary-never-plaintext';
    const logCanary = 'log-canary-never-plaintext';
    const pathCanary = fixture.dataRoot;
    const canaries = [
      accessCanary,
      refreshCanary,
      accountCanary,
      emailCanary,
      upstreamCanary,
      pathCanary,
      logCanary,
    ];
    const capturedConsole: unknown[][] = [];
    const consoleCapture = captureConsole(capturedConsole);
    vi.spyOn(console, 'debug').mockImplementation(consoleCapture);
    vi.spyOn(console, 'error').mockImplementation(consoleCapture);
    vi.spyOn(console, 'info').mockImplementation(consoleCapture);
    vi.spyOn(console, 'log').mockImplementation(consoleCapture);
    vi.spyOn(console, 'warn').mockImplementation(consoleCapture);
    fixture.queueReferenceIds('vault_00000000-0000-76b6-bb44-69ed58d73f3b');

    const created = await fixture.manager.createAccount({ ...pair, displayName: 'Audit Slot' });
    const updated = await fixture.manager.updateAccount(pair, {
      displayName: 'Audit Slot Renamed',
    });
    const handle = await fixture.manager.getPairHandle(pair);
    const firstCredential: OAuthCredential = {
      access: accessCanary,
      accountId: accountCanary,
      email: emailCanary,
      expires: Date.parse('2026-08-23T00:00:00.000Z'),
      logHint: logCanary,
      pathHint: pathCanary,
      refresh: refreshCanary,
      type: 'oauth',
      upstreamBody: upstreamCanary,
    };
    await handle.credentials.modify('openai-codex', async () => firstCredential);
    const firstEntry = join(
      fixture.dataRoot,
      'server',
      'vault',
      'entries',
      'vault_00000000-0000-76b6-bb44-69ed58d73f3b',
      '1.enc'
    );

    expect(existsSync(firstEntry)).toBe(true);
    expect(findLiteralCanaryBytes(fixture.dataRoot, canaries)).toEqual([]);

    const rotatedCredential: OAuthCredential = {
      ...firstCredential,
      access: `${accessCanary}-rotated`,
      expires: Date.parse('2026-09-23T00:00:00.000Z'),
      refresh: `${refreshCanary}-rotated`,
    };
    await handle.credentials.modify('openai-codex', async (current) => {
      expect(current).toEqual(firstCredential);
      return rotatedCredential;
    });
    expect(fixture.backend().listReferences()).toEqual([
      expect.objectContaining({
        currentVersion: 2,
        referenceId: 'vault_00000000-0000-76b6-bb44-69ed58d73f3b',
        revoked: false,
        versionCount: 2,
      }),
    ]);
    expect(findLiteralCanaryBytes(fixture.dataRoot, canaries)).toEqual([]);

    const duplicateError = await expectAccountError(
      () => fixture.manager.createAccount(pair),
      ACCOUNT_EXISTS_ERROR
    );
    fixture.vaultState.lock();
    const lockedError = await expectAccountError(
      () => fixture.manager.reconcileAccount(pair),
      LOCKED_ERROR
    );
    fixture.vaultState.unlock({ masterKey: Buffer.alloc(32, 23) });
    await expect(handle.credentials.read('openai-codex')).resolves.toEqual(rotatedCredential);
    const reconciled = await fixture.manager.reconcileAccount(pair);
    const listed = await fixture.manager.listAccounts('openai-codex');
    const safeError = await expectAccountError(
      () => handle.credentials.read(`foreign-${upstreamCanary}`),
      PROVIDER_ERROR
    );
    await handle.credentials.delete('openai-codex');
    expect(findLiteralCanaryBytes(fixture.dataRoot, canaries)).toEqual([]);
    await fixture.manager.deleteAccount(pair);

    const expectedActions = [
      'provider_subscription.account.create',
      'provider_subscription.account.update',
      'provider_subscription.account.delete',
      'provider_subscription.credential.store',
      'provider_subscription.credential.rotate',
      'provider_subscription.credential.revoke',
      'provider_subscription.reconcile',
    ];
    const expectedSummaries: Record<string, string> = {
      'provider_subscription.account.create': 'Provider subscription account created.',
      'provider_subscription.account.delete': 'Provider subscription account deleted.',
      'provider_subscription.account.update': 'Provider subscription account updated.',
      'provider_subscription.credential.revoke': 'Provider subscription credential revoked.',
      'provider_subscription.credential.rotate': 'Provider subscription credential rotated.',
      'provider_subscription.credential.store': 'Provider subscription credential stored.',
      'provider_subscription.reconcile': 'Provider subscription account reconciled.',
    };
    const allAuditRows = fixture.coreDb.sqlite
      .prepare('SELECT rowid, * FROM audit_events ORDER BY rowid ASC')
      .all() as Array<{
      readonly action: string;
      readonly error_code: string | null;
      readonly outcome: string;
      readonly resource: string | null;
      readonly rowid: number;
      readonly summary: string;
      readonly [key: string]: unknown;
    }>;
    expect(
      allAuditRows.every(
        (row) => row.action === 'vault.resolve' || expectedActions.includes(row.action)
      )
    ).toBe(true);
    const providerAuditRows = allAuditRows.filter((row) => row.action !== 'vault.resolve');
    for (const row of providerAuditRows) {
      expect(row).toMatchObject({
        actor_json: null,
        agent_id: null,
        agent_session_id: null,
        capability_call_id: null,
        category: 'system',
        item_id: null,
        permission_decision_id: null,
        protocol_version: null,
        request_id: null,
        resource_revision: null,
        severity: row.outcome === 'succeeded' ? 'info' : 'error',
        subject_json: null,
        thread_id: null,
        turn_id: null,
        vault_grant_id: null,
        workspace_id: null,
      });
    }
    const lifecycleProjection = providerAuditRows.map((row) => ({
      action: row.action,
      error_code: row.error_code,
      outcome: row.outcome,
      resource: row.resource,
      summary: row.summary,
    }));

    expect([...new Set(providerAuditRows.map((row) => row.action))].sort()).toEqual(
      [...expectedActions].sort()
    );
    expect(lifecycleProjection).toEqual([
      {
        action: 'provider_subscription.account.create',
        error_code: null,
        outcome: 'succeeded',
        resource: 'provider-subscription:openai-codex:audit_lifecycle',
        summary: expectedSummaries['provider_subscription.account.create'],
      },
      {
        action: 'provider_subscription.account.update',
        error_code: null,
        outcome: 'succeeded',
        resource: 'provider-subscription:openai-codex:audit_lifecycle',
        summary: expectedSummaries['provider_subscription.account.update'],
      },
      {
        action: 'provider_subscription.credential.store',
        error_code: null,
        outcome: 'succeeded',
        resource: 'provider-subscription:openai-codex:audit_lifecycle',
        summary: expectedSummaries['provider_subscription.credential.store'],
      },
      {
        action: 'provider_subscription.credential.rotate',
        error_code: null,
        outcome: 'succeeded',
        resource: 'provider-subscription:openai-codex:audit_lifecycle',
        summary: expectedSummaries['provider_subscription.credential.rotate'],
      },
      {
        action: 'provider_subscription.account.create',
        error_code: ACCOUNT_EXISTS_ERROR.code,
        outcome: 'failed',
        resource: 'provider-subscription:openai-codex:audit_lifecycle',
        summary: 'Provider subscription account creation failed.',
      },
      {
        action: 'provider_subscription.reconcile',
        error_code: LOCKED_ERROR.code,
        outcome: 'failed',
        resource: 'provider-subscription:openai-codex:audit_lifecycle',
        summary: 'Provider subscription account reconciliation failed.',
      },
      {
        action: 'provider_subscription.reconcile',
        error_code: null,
        outcome: 'succeeded',
        resource: 'provider-subscription:openai-codex:audit_lifecycle',
        summary: expectedSummaries['provider_subscription.reconcile'],
      },
      {
        action: 'provider_subscription.credential.revoke',
        error_code: null,
        outcome: 'succeeded',
        resource: 'provider-subscription:openai-codex:audit_lifecycle',
        summary: expectedSummaries['provider_subscription.credential.revoke'],
      },
      {
        action: 'provider_subscription.account.delete',
        error_code: null,
        outcome: 'succeeded',
        resource: 'provider-subscription:openai-codex:audit_lifecycle',
        summary: expectedSummaries['provider_subscription.account.delete'],
      },
    ]);
    const forbiddenLifecycleValues = [
      ...canaries,
      'vault_00000000-0000-76b6-bb44-69ed58d73f3b',
      'encrypted-file://',
    ];
    for (const forbidden of forbiddenLifecycleValues) {
      expect(JSON.stringify(providerAuditRows)).not.toContain(forbidden);
    }
    for (const canary of canaries) {
      expect(JSON.stringify(allAuditRows)).not.toContain(canary);
    }

    const vaultResolveRows = allAuditRows.filter((row) => row.action === 'vault.resolve');
    const vaultUseRows = listVaultUseRecords(fixture.coreDb);

    expect(vaultResolveRows).toHaveLength(3);
    expect(vaultUseRows).toHaveLength(3);
    expect(vaultUseRows.map((row) => row.materialVersion).sort()).toEqual([1, 2, 2]);
    expect(new Set(vaultUseRows.map((row) => row.auditEventId))).toEqual(
      new Set(vaultResolveRows.map((row) => row.audit_event_id))
    );
    for (const use of vaultUseRows) {
      expect(use).toEqual({
        agentSessionId: null,
        auditEventId: expect.stringMatching(/^aud_/),
        backendKind: 'encrypted-file',
        capabilityCallId: null,
        failureCode: null,
        grantId: null,
        materialVersion: expect.any(Number),
        outcome: 'succeeded',
        ownerScope: 'server',
        planId: null,
        receiptId: null,
        resolvingPath: 'provider',
        usedAt: DEFAULT_TIME,
        useId: expect.any(String),
        vaultReferenceId: 'vault_00000000-0000-76b6-bb44-69ed58d73f3b',
        workspaceId: null,
      });
      expect(vaultResolveRows.find((row) => row.audit_event_id === use.auditEventId)).toMatchObject(
        {
          action: 'vault.resolve',
          audit_event_id: use.auditEventId,
          category: 'system',
          error_code: null,
          outcome: 'succeeded',
          resource: 'vault:vault_00000000-0000-76b6-bb44-69ed58d73f3b',
          severity: 'info',
          summary: 'Vault reference resolved.',
        }
      );
    }
    expect(fixture.backend().listReferences()).toEqual([
      expect.objectContaining({
        currentVersion: 2,
        referenceId: 'vault_00000000-0000-76b6-bb44-69ed58d73f3b',
        revoked: true,
        versionCount: 2,
      }),
    ]);

    const safeProjection = JSON.stringify({
      created,
      duplicateError: completeErrorProjection(duplicateError),
      error: completeErrorProjection(safeError),
      listed,
      lockedError: completeErrorProjection(lockedError),
      reconciled,
      updated,
    });
    const evidenceProjection = JSON.stringify({
      capturedConsole,
      providerAuditRows,
      vaultResolveRows,
      vaultUseRows,
    });

    for (const canary of [...canaries, 'vault_00000000-0000-76b6-bb44-69ed58d73f3b']) {
      expect(safeProjection).not.toContain(canary);
    }
    for (const canary of canaries) {
      expect(evidenceProjection).not.toContain(canary);
    }
    expect(capturedConsole).toEqual([]);
    expect(findLiteralCanaryBytes(fixture.dataRoot, canaries)).toEqual([]);

    const revokeFailureFixture = createFixture();
    const revokeFailurePair = accountPair('revoke_resolve_failure');
    const revokeFailureHandle = await createStoredPair(
      revokeFailureFixture,
      revokeFailurePair,
      'vault_00000000-0000-7015-8bb3-3f408ad37ef5'
    );
    const revokeFailureBackend = revokeFailureFixture.backend();
    const revokeFailureCanary = 'raw-revoke-resolve-failure-canary';
    const revokeFailureResolve = vi
      .spyOn(revokeFailureBackend, 'resolve')
      .mockImplementationOnce(() => {
        throw new Error(revokeFailureCanary);
      });
    const revokeFailureRevoke = vi.spyOn(revokeFailureBackend, 'revoke');
    const revokeFailureBefore = authoritySnapshot(revokeFailureFixture);
    const revokeFailureError = await expectAccountError(
      () => revokeFailureHandle.credentials.delete('openai-codex'),
      PERSISTENCE_ERROR
    );

    expect(revokeFailureResolve).toHaveBeenCalledTimes(1);
    expect(revokeFailureRevoke).not.toHaveBeenCalled();
    expect(authoritySnapshot(revokeFailureFixture)).toEqual(revokeFailureBefore);
    const revokeFailureAudit = revokeFailureFixture.coreDb.sqlite
      .prepare(
        `SELECT rowid, *
         FROM audit_events
         WHERE action = 'provider_subscription.credential.revoke'
         ORDER BY rowid DESC
         LIMIT 1`
      )
      .get();
    expect.soft(revokeFailureAudit).toMatchObject({
      action: 'provider_subscription.credential.revoke',
      error_code: PERSISTENCE_ERROR.code,
      outcome: 'failed',
      resource: 'provider-subscription:openai-codex:revoke_resolve_failure',
      severity: 'error',
      summary: 'Provider subscription credential revocation failed.',
    });
    expect(
      JSON.stringify({
        audit: revokeFailureAudit,
        error: completeErrorProjection(revokeFailureError),
      })
    ).not.toContain(revokeFailureCanary);

    const rawAuditFixture = createFixture();
    const rawAuditPair = accountPair('raw_audit_insert');
    await rawAuditFixture.manager.createAccount(rawAuditPair);
    const rawAuditCanary = 'raw-audit-insert-failure-canary';
    rawAuditFixture.coreDb.sqlite.exec(`CREATE TEMP TRIGGER fail_raw_audit_insert
      BEFORE INSERT ON audit_events
      FOR EACH ROW
      BEGIN
        SELECT RAISE(FAIL, '${rawAuditCanary}');
      END`);

    let rawAuditError: unknown;
    try {
      await rawAuditFixture.manager.updateAccount(rawAuditPair, { displayName: 'Still Safe' });
    } catch (error) {
      rawAuditError = error;
    }
    expect.soft(rawAuditError).toBeInstanceOf(ProviderSubscriptionAccountError);
    expect.soft(rawAuditError).toMatchObject(PERSISTENCE_ERROR);
    expect.soft((rawAuditError as Error | undefined)?.message).toBe(PERSISTENCE_ERROR.message);
    rawAuditFixture.coreDb.sqlite.exec('DROP TRIGGER fail_raw_audit_insert');
    const injectedFailureCanaries = [revokeFailureCanary, rawAuditCanary];
    const injectedFailureEvidence = JSON.stringify({
      capturedConsole,
      rawAuditError: completeErrorProjection(rawAuditError),
      revokeFailureAudit,
      revokeFailureError: completeErrorProjection(revokeFailureError),
    });
    for (const canary of injectedFailureCanaries) {
      expect.soft(injectedFailureEvidence).not.toContain(canary);
    }
    expect.soft(capturedConsole).toEqual([]);
    for (const root of [revokeFailureFixture.dataRoot, rawAuditFixture.dataRoot]) {
      expect.soft(findLiteralCanaryBytes(root, injectedFailureCanaries)).toEqual([]);
    }
  });

  it('fails both pre-accept provider terminal outcomes without credential or authority writes', async () => {
    for (const outcome of ['reject', 'resolve'] as const) {
      const fixture = createFixture();
      const pair = accountPair(`pre_accept_${outcome}`);
      await fixture.manager.createAccount(pair);
      const handle = await fixture.manager.getPairHandle(pair);
      const oauth = requireProviderOAuth(handle, pair);
      const modify = vi.spyOn(handle.credentials, 'modify');
      const canary = `raw-pre-accept-${outcome}-canary`;
      const before = authoritySnapshot(fixture);

      vi.spyOn(oauth, 'login').mockImplementation(async () => {
        if (outcome === 'reject') {
          throw new Error(canary);
        }
        return oauthCredential(canary);
      });

      const failure = await expectAccountError(
        () => lifecycleOperations(fixture.manager).startLogin(pair),
        PROVIDER_UNAVAILABLE_ERROR
      );

      expect(modify).not.toHaveBeenCalled();
      expect(authoritySnapshot(fixture)).toEqual(before);
      expect(JSON.stringify(completeErrorProjection(failure))).not.toContain(canary);
    }
  });

  it('admits one simultaneous start and projects accepted success or failure through manager state', async () => {
    const fixture = createFixture();
    const pair = accountPair('simultaneous_start');
    fixture.queueReferenceIds('vault_00000000-0000-7adf-a277-d0b2ab14f0a1');
    await fixture.manager.createAccount(pair);
    const handle = await fixture.manager.getPairHandle(pair);
    const oauth = requireProviderOAuth(handle, pair);
    const modelsLogin = vi.spyOn(handle.models, 'login');
    const releaseLogin = deferredGate();
    const credentialStored = deferredGate();
    const credential = oauthCredential('simultaneous-success');
    const realModify = handle.credentials.modify.bind(handle.credentials);
    const modify = vi
      .spyOn(handle.credentials, 'modify')
      .mockImplementation(async (providerId, update) => {
        const result = await realModify(providerId, update);
        credentialStored.resolve();
        return result;
      });

    vi.spyOn(oauth, 'login').mockImplementation(async (interaction: AuthInteraction) => {
      interaction.notify({
        type: 'device_code',
        userCode: 'SIMULTANEOUS',
        verificationUri: 'https://login.example.test/simultaneous',
      });
      await releaseLogin.promise;
      return credential;
    });

    const lifecycle = lifecycleOperations(fixture.manager);
    const starts = await Promise.allSettled([
      lifecycle.startLogin(pair),
      lifecycle.startLogin(pair),
    ]);
    const accepted = starts.filter(
      (result): result is PromiseFulfilledResult<ManagerLifecycleSnapshot> =>
        result.status === 'fulfilled'
    );
    const rejected = starts.filter(
      (result): result is PromiseRejectedResult => result.status === 'rejected'
    );

    expect(accepted).toHaveLength(1);
    expect(accepted[0]?.value).toMatchObject({
      interaction: {
        mode: 'device_code',
        userCode: 'SIMULTANEOUS',
        verificationUrl: 'https://login.example.test/simultaneous',
      },
      status: 'pending',
    });
    expect(rejected).toHaveLength(1);
    expect(rejected[0]?.reason).toBeInstanceOf(ProviderSubscriptionAccountError);
    expect(rejected[0]?.reason).toMatchObject(LOGIN_ACTIVE_ERROR);

    releaseLogin.resolve();
    await credentialStored.promise;
    await expect(handle.credentials.read(pair.subscriptionProviderId)).resolves.toEqual(credential);
    await expect(lifecycle.getStatus(pair)).resolves.toMatchObject({ status: 'logged_in' });
    expect(modify).toHaveBeenCalledTimes(1);
    expect(modelsLogin).not.toHaveBeenCalled();

    const failureFixture = createFixture();
    const failurePair = accountPair('accepted_failure');
    await failureFixture.manager.createAccount(failurePair);
    const failureHandle = await failureFixture.manager.getPairHandle(failurePair);
    const failureOAuth = requireProviderOAuth(failureHandle, failurePair);
    const failureModify = vi.spyOn(failureHandle.credentials, 'modify');
    const canary = 'raw-accepted-provider-failure-canary';
    const failureBefore = authoritySnapshot(failureFixture);

    vi.spyOn(failureOAuth, 'login').mockImplementation(async (interaction: AuthInteraction) => {
      interaction.notify({
        type: 'device_code',
        userCode: 'FAIL-LATER',
        verificationUri: 'https://login.example.test/fail-later',
      });
      throw new Error(canary);
    });

    const failureLifecycle = lifecycleOperations(failureFixture.manager);
    await expect(failureLifecycle.startLogin(failurePair)).resolves.toMatchObject({
      status: 'pending',
    });
    const failureStatus = await failureLifecycle.getStatus(failurePair);

    expect(failureStatus).toMatchObject({
      message: LOGIN_ERROR_MESSAGE,
      status: 'error',
    });
    expect(JSON.stringify(failureStatus)).not.toContain(canary);
    expect(failureModify).not.toHaveBeenCalled();
    expect(authoritySnapshot(failureFixture)).toEqual(failureBefore);
  });

  it('linearizes delete against start and keeps cancellation settling until stale completion is inert', async () => {
    const deleteFirstFixture = createFixture();
    const deleteFirstPair = accountPair('delete_first');
    await deleteFirstFixture.manager.createAccount(deleteFirstPair);
    const deleteFirstLifecycle = lifecycleOperations(deleteFirstFixture.manager);
    const deletion = deleteFirstFixture.manager.deleteAccount(deleteFirstPair);
    const lateStart = deleteFirstLifecycle.startLogin(deleteFirstPair);

    await expect(deletion).resolves.toBeUndefined();
    await expectAccountError(() => lateStart, ACCOUNT_NOT_FOUND_ERROR);

    const fixture = createFixture();
    const pair = accountPair('start_first', 'xai');
    await fixture.manager.createAccount(pair);
    const handle = await fixture.manager.getPairHandle(pair);
    const oauth = requireProviderOAuth(handle, pair);
    const modelsLogin = vi.spyOn(handle.models, 'login');
    const releaseProvider = deferredGate();
    const modifyEntered = deferredGate();
    const releaseModify = deferredGate();
    const updaterResults = vi.fn();
    const aborted = deferredGate();
    const realModify = handle.credentials.modify.bind(handle.credentials);
    const modify = vi
      .spyOn(handle.credentials, 'modify')
      .mockImplementation(async (providerId, update) => {
        modifyEntered.resolve();
        await releaseModify.promise;
        return realModify(providerId, async () => {
          const result = await update(oauthCredential('cancelled-existing'));
          updaterResults(result);
          return result;
        });
      });
    vi.spyOn(oauth, 'login').mockImplementation(async (interaction: AuthInteraction) => {
      interaction.signal?.addEventListener('abort', aborted.resolve, { once: true });
      interaction.notify({
        type: 'device_code',
        userCode: 'CANCEL-LATE',
        verificationUri: 'https://login.example.test/cancel-late',
      });
      await releaseProvider.promise;
      return oauthCredential('cancelled-late-success');
    });

    const lifecycle = lifecycleOperations(fixture.manager);
    const pending = await lifecycle.startLogin(pair);
    expect(pending).toMatchObject({ status: 'pending' });
    const pendingDeletion = fixture.manager.deleteAccount(pair);
    await aborted.promise;
    releaseProvider.resolve();
    await modifyEntered.promise;
    await expectAccountError(() => lifecycle.startLogin(pair), LOGIN_ACTIVE_ERROR);
    releaseModify.resolve();
    await expect(pendingDeletion).resolves.toBeUndefined();
    expect(modify).toHaveBeenCalledTimes(1);
    expect(modelsLogin).not.toHaveBeenCalled();
    expect(
      existsSync(
        join(
          fixture.dataRoot,
          'server/files/provider-subscriptions',
          pair.subscriptionProviderId,
          'accounts',
          pair.accountSlotId,
          'account.json'
        )
      )
    ).toBe(false);
    expect(fixture.backend().listReferences()).toEqual([]);
    expect(updaterResults.mock.calls).toEqual([[undefined]]);
  });

  it('rejects invalid account authority before cancelling login', async () => {
    const fixture = createFixture();
    const pair = accountPair('login_invalid_delete');
    await fixture.manager.createAccount(pair);
    const handle = await fixture.manager.getPairHandle(pair);
    const oauth = requireProviderOAuth(handle, pair);
    const aborted = vi.fn();
    vi.spyOn(oauth, 'login').mockImplementation(async (interaction: AuthInteraction) => {
      interaction.notify({
        type: 'device_code',
        userCode: 'INVALID-DELETE',
        verificationUri: 'https://login.example.test/invalid-delete',
      });
      return new Promise<OAuthCredential>((_resolve, reject) => {
        interaction.signal?.addEventListener('abort', () => reject(aborted()), { once: true });
      });
    });
    await expect(lifecycleOperations(fixture.manager).startLogin(pair)).resolves.toMatchObject({
      status: 'pending',
    });
    writeAccountJson(
      fixture.dataRoot,
      pair,
      validAccountRecord(pair, { vaultReferenceId: 'vault_00000000-0000-779b-80eb-ff407b303de3' })
    );
    createExactCoreReference(fixture, 'vault_00000000-0000-779b-80eb-ff407b303de3');
    await expectAccountError(() => fixture.manager.deleteAccount(pair), PERSISTENCE_ERROR);
    expect(aborted).not.toHaveBeenCalled();
  });

  it('rejects invalid account authority before cancelling an accepted login', async () => {
    const fixture = createFixture();
    const pair = accountPair('login_invalid_cancel');
    await fixture.manager.createAccount(pair);
    const handle = await fixture.manager.getPairHandle(pair);
    const oauth = requireProviderOAuth(handle, pair);
    const aborted = vi.fn();
    vi.spyOn(oauth, 'login').mockImplementation(async (interaction: AuthInteraction) => {
      interaction.notify({
        type: 'device_code',
        userCode: 'INVALID-CANCEL',
        verificationUri: 'https://login.example.test/invalid-cancel',
      });
      return new Promise<OAuthCredential>((_resolve, reject) => {
        interaction.signal?.addEventListener('abort', () => reject(aborted()), { once: true });
      });
    });
    const lifecycle = lifecycleOperations(fixture.manager);
    const pending = await lifecycle.startLogin(pair);
    writeAccountJson(
      fixture.dataRoot,
      pair,
      validAccountRecord(pair, { vaultReferenceId: 'vault_00000000-0000-752d-9b1d-28eb30b15d0f' })
    );
    createExactCoreReference(fixture, 'vault_00000000-0000-752d-9b1d-28eb30b15d0f');

    await expectAccountError(
      () => lifecycle.cancelLogin(pair, pending.interaction?.interactionId ?? ''),
      PERSISTENCE_ERROR
    );
    expect(aborted).not.toHaveBeenCalled();
  });

  it('lets admitted refresh finish before logout and blocks starts until logout settlement', async () => {
    const refreshFixture = createFixture();
    const refreshPair = accountPair('refresh_then_logout');
    const refreshHandle = await createStoredPair(
      refreshFixture,
      refreshPair,
      'vault_00000000-0000-75fe-a5d1-ee3d06f1606a',
      oauthCredential('refresh-v1')
    );
    const refreshEntered = deferredGate();
    const releaseRefresh = deferredGate();
    const events: string[] = [];
    const backend = refreshFixture.backend();
    const realRevoke = backend.revoke.bind(backend);

    vi.spyOn(backend, 'revoke').mockImplementation((input) => {
      events.push('logout:revoke');
      expect(backend.listReferences()).toContainEqual(
        expect.objectContaining({
          currentVersion: 2,
          referenceId: 'vault_00000000-0000-75fe-a5d1-ee3d06f1606a',
          revoked: false,
        })
      );
      return realRevoke(input);
    });

    const refresh = refreshHandle.credentials.modify(
      refreshPair.subscriptionProviderId,
      async (current) => {
        events.push('refresh:start');
        expect(current).toEqual(oauthCredential('refresh-v1'));
        refreshEntered.resolve();
        await releaseRefresh.promise;
        events.push('refresh:end');
        return oauthCredential('refresh-v2');
      }
    );
    await refreshEntered.promise;
    let logoutSettled = false;
    const logout = lifecycleOperations(refreshFixture.manager)
      .logout(refreshPair)
      .finally(() => {
        logoutSettled = true;
      });

    expect(logoutSettled).toBe(false);
    expect(events).toEqual(['refresh:start']);
    releaseRefresh.resolve();
    await expect(refresh).resolves.toEqual(oauthCredential('refresh-v2'));
    await expect(logout).resolves.toMatchObject({ status: 'logged_out' });
    expect(events).toEqual(['refresh:start', 'refresh:end', 'logout:revoke']);
    await expect(
      refreshHandle.credentials.read(refreshPair.subscriptionProviderId)
    ).resolves.toBeUndefined();

    const settlingFixture = createFixture();
    const settlingPair = accountPair('logout_settling');
    await settlingFixture.manager.createAccount(settlingPair);
    const settlingHandle = await settlingFixture.manager.getPairHandle(settlingPair);
    const settlingOAuth = requireProviderOAuth(settlingHandle, settlingPair);
    const releaseProvider = deferredGate();
    const aborted = deferredGate();
    const settlingBefore = authoritySnapshot(settlingFixture);

    vi.spyOn(settlingOAuth, 'login').mockImplementation(async (interaction: AuthInteraction) => {
      interaction.signal?.addEventListener('abort', aborted.resolve, { once: true });
      interaction.notify({
        type: 'device_code',
        userCode: 'LOGOUT-LATE',
        verificationUri: 'https://login.example.test/logout-late',
      });
      await releaseProvider.promise;
      return oauthCredential('logout-late-success');
    });

    const settlingLifecycle = lifecycleOperations(settlingFixture.manager);
    await expect(settlingLifecycle.startLogin(settlingPair)).resolves.toMatchObject({
      status: 'pending',
    });
    const settlingLogout = settlingLifecycle.logout(settlingPair);
    await aborted.promise;
    await expectAccountError(() => settlingLifecycle.startLogin(settlingPair), LOGIN_ACTIVE_ERROR);
    releaseProvider.resolve();

    await expect(settlingLogout).resolves.toMatchObject({ status: 'logged_out' });
    await expect(
      settlingHandle.credentials.read(settlingPair.subscriptionProviderId)
    ).resolves.toBeUndefined();
    expect(authoritySnapshot(settlingFixture)).toEqual(settlingBefore);
  });

  it('rejects invalid account authority before aborting login or invoking Models logout', async () => {
    const invalidLogoutFixture = createFixture();
    const invalidLogoutPair = accountPair('login_invalid_logout');
    await invalidLogoutFixture.manager.createAccount(invalidLogoutPair);
    const invalidLogoutHandle = await invalidLogoutFixture.manager.getPairHandle(invalidLogoutPair);
    const invalidLogoutOAuth = requireProviderOAuth(invalidLogoutHandle, invalidLogoutPair);
    const invalidLogoutAbort = vi.fn();
    const invalidModelsLogout = vi.spyOn(invalidLogoutHandle.models, 'logout');
    vi.spyOn(invalidLogoutOAuth, 'login').mockImplementation(
      async (interaction: AuthInteraction) => {
        interaction.notify({
          type: 'device_code',
          userCode: 'INVALID-LOGOUT',
          verificationUri: 'https://login.example.test/invalid-logout',
        });
        return new Promise<OAuthCredential>((_resolve, reject) => {
          interaction.signal?.addEventListener('abort', () => reject(invalidLogoutAbort()), {
            once: true,
          });
        });
      }
    );
    await expect(
      lifecycleOperations(invalidLogoutFixture.manager).startLogin(invalidLogoutPair)
    ).resolves.toMatchObject({ status: 'pending' });
    writeAccountJson(
      invalidLogoutFixture.dataRoot,
      invalidLogoutPair,
      validAccountRecord(invalidLogoutPair, {
        vaultReferenceId: 'vault_00000000-0000-708a-80e9-c7af21ac9e04',
      })
    );
    createExactCoreReference(invalidLogoutFixture, 'vault_00000000-0000-708a-80e9-c7af21ac9e04');

    await expectAccountError(
      () => lifecycleOperations(invalidLogoutFixture.manager).logout(invalidLogoutPair),
      PERSISTENCE_ERROR
    );
    expect(invalidLogoutAbort).not.toHaveBeenCalled();
    expect(invalidModelsLogout).not.toHaveBeenCalled();
  });

  it.each([
    {
      backendCode: 'vault-locked',
      expected: LOCKED_ERROR,
      slot: 'logout_locked',
    },
    {
      backendCode: 'backend-unavailable',
      expected: VAULT_UNAVAILABLE_ERROR,
      slot: 'logout_unavailable',
    },
  ] as const)('maps stock Models logout $backendCode failures without changing authority', async (failure) => {
    const fixture = createFixture();
    const pair = accountPair(failure.slot);
    await createStoredPair(fixture, pair, testEntityId('vault', `${failure.slot}_r1`));
    const revoke = vi.spyOn(fixture.backend(), 'revoke').mockImplementation(() => {
      throw new VaultBackendError(failure.backendCode, 'Private backend failure.');
    });
    const before = authoritySnapshot(fixture);

    await expectAccountError(
      () => lifecycleOperations(fixture.manager).logout(pair),
      failure.expected
    );
    expect(revoke).toHaveBeenCalledTimes(1);
    expect(authoritySnapshot(fixture)).toEqual(before);
  });

  it('continues logout from a current credential tombstone without retrying Vault writes', async () => {
    const tombstoneFixture = createFixture();
    const tombstonePair = accountPair('logout_current_tombstone');
    const tombstoneHandle = await createStoredPair(
      tombstoneFixture,
      tombstonePair,
      'vault_00000000-0000-7c8b-811e-ddce0e3ef567'
    );
    tombstoneFixture
      .backend()
      .revoke({ referenceId: 'vault_00000000-0000-7c8b-811e-ddce0e3ef567' });
    const tombstoneRetryWrites = [
      vi.spyOn(tombstoneFixture.backend(), 'store'),
      vi.spyOn(tombstoneFixture.backend(), 'rotate'),
      vi.spyOn(tombstoneFixture.backend(), 'revoke'),
    ];

    await expect(
      lifecycleOperations(tombstoneFixture.manager).logout(tombstonePair)
    ).resolves.toMatchObject({ status: 'logged_out' });
    for (const write of tombstoneRetryWrites) {
      expect(write).not.toHaveBeenCalled();
    }
    expect(readAccountJson(tombstoneFixture.dataRoot, tombstonePair)).toEqual({
      accountSlotId: 'logout_current_tombstone',
      createdAt: DEFAULT_TIME,
      schemaVersion: 1,
      status: 'logged_out',
      subscriptionProviderId: 'openai-codex',
      updatedAt: DEFAULT_TIME,
    });
    expect(
      getVaultReference(tombstoneFixture.coreDb, 'vault_00000000-0000-7c8b-811e-ddce0e3ef567')
    ).toMatchObject({
      currentVersion: 1,
      status: 'revoked',
    });
    await expect(
      tombstoneHandle.credentials.read(tombstonePair.subscriptionProviderId)
    ).resolves.toBeUndefined();
  });
});

describe('same-credential inference observations', () => {
  it.each([
    'openai-codex',
    'xai',
  ] as const)('records and clears only the exact %s account and version', async (subscriptionProviderId) => {
    const fixture = createFixture();
    const pair = { subscriptionProviderId, accountSlotId: 'observed' };
    const handle = await createStoredPair(
      fixture,
      pair,
      'vault_00000000-0000-71b0-bf66-b1dd14f78f14'
    );
    const presented = (await handle.resolveInferenceAuth())?.presented;
    expect(presented).toBeDefined();
    const before = authoritySnapshot(fixture);
    await handle.observeInference(
      presented!,
      { kind: 'auth_rejected', settled: true, status: 401 },
      Date.now() + 1000
    );
    expect(await handle.getObservation()).toMatchObject({
      accessRejected: { observedAt: DEFAULT_TIME },
    });
    expect(await fixture.manager.getStatus(pair)).toMatchObject({ status: 'logged_in' });
    expect(authoritySnapshot(fixture)).toEqual(before);
    await handle.observeInference(presented!, {
      kind: 'quota_exhausted',
      settled: true,
      providerCode: 'insufficient_quota',
    });
    expect(await handle.getObservation()).toMatchObject({
      accessRejected: { observedAt: DEFAULT_TIME },
      quotaExhausted: { observedAt: DEFAULT_TIME },
    });
    await handle.observeInference(presented!, { kind: 'cancelled', settled: false });
    expect(await handle.getObservation()).toMatchObject({
      accessRejected: { observedAt: DEFAULT_TIME },
      quotaExhausted: { observedAt: DEFAULT_TIME },
    });
    await handle.observeInference(presented!, undefined);
    expect(await handle.getObservation()).toEqual({
      quotaExhausted: { observedAt: DEFAULT_TIME },
    });
    await handle.observeQuota(presented!.version, 'temporarily_unavailable');
    expect(await handle.getObservation()).toMatchObject({
      quotaExhausted: { observedAt: DEFAULT_TIME },
    });
    await handle.observeQuota(presented!.version, 'available');
    expect(await handle.getObservation()).toBeUndefined();
    await handle.observeInference(
      presented!,
      { kind: 'auth_rejected', settled: true, status: 401 },
      Date.now() + 1000
    );
    await handle.observeInference(presented!, { kind: 'quota_exhausted', settled: true });
    const restarted = await fixture.createManager().getPairHandle(pair);
    expect(await restarted.getObservation()).toBeUndefined();
    await handle.credentials.modify(subscriptionProviderId, async () =>
      oauthCredential('observed-v2')
    );
    expect(await handle.getObservation()).toBeUndefined();
    await handle.observeInference(
      presented!,
      { kind: 'auth_rejected', settled: true, status: 401 },
      Date.now() + 1000
    );
    await handle.observeInference(presented!, { kind: 'quota_exhausted', settled: true });
    expect(await handle.getObservation()).toBeUndefined();
    const replacement = (await handle.resolveInferenceAuth())?.presented;
    await handle.observeInference(
      replacement!,
      { kind: 'auth_rejected', settled: true, status: 401 },
      Date.now() + 1000
    );
    await fixture.manager.logout(pair);
    expect(await handle.getObservation()).toBeUndefined();
  });

  it.each([
    'openai-codex',
    'xai',
  ] as const)('suppresses late, cancelled, dependency and entitlement failures for %s', async (subscriptionProviderId) => {
    const fixture = createFixture();
    const pair = { subscriptionProviderId, accountSlotId: 'bounded' };
    const handle = await createStoredPair(
      fixture,
      pair,
      'vault_00000000-0000-71df-b932-d8881f195c73'
    );
    const presented = (await handle.resolveInferenceAuth())?.presented;
    for (const failure of [
      { kind: 'auth_rejected', settled: true, status: 403 },
      { kind: 'auth_rejected', settled: false },
      { kind: 'unknown', settled: true, status: 403 },
      { kind: 'provider_unavailable', settled: false },
      { kind: 'refused', settled: true },
    ] as const) {
      await handle.observeInference(presented!, failure, Date.now() + 1000);
      expect(await handle.getObservation()).toBeUndefined();
    }
    await handle.observeInference(
      presented!,
      { kind: 'auth_rejected', settled: true, status: 401 },
      Date.now() - 1
    );
    expect(await handle.getObservation()).toBeUndefined();
    const controller = new AbortController();
    controller.abort();
    await handle.observeInference(
      presented!,
      { kind: 'auth_rejected', settled: true, status: 401 },
      Date.now() + 1000,
      controller.signal
    );
    expect(await handle.getObservation()).toBeUndefined();
    const read = vi.spyOn(handle.credentials, 'read').mockImplementation(async () => {
      throw new Error('store unavailable');
    });
    await handle.observeInference(
      presented!,
      { kind: 'auth_rejected', settled: true, status: 401 },
      Date.now() + 1000
    );
    read.mockRestore();
    expect(await handle.getObservation()).toBeUndefined();
    const other = await createStoredPair(
      fixture,
      { subscriptionProviderId, accountSlotId: 'other' },
      'vault_00000000-0000-758e-b93d-9fe38f0ea41e'
    );
    expect(await other.getObservation()).toBeUndefined();
    await fixture.manager.deleteAccount(pair);
    expect(await handle.getObservation()).toBeUndefined();
  });
});

describe('inference rejection deadline', () => {
  it.each([
    'openai-codex',
    'xai',
  ] as const)('discards a %s recheck completing after the explicit absolute deadline', async (subscriptionProviderId) => {
    const fixture = createFixture();
    const handle = await createStoredPair(
      fixture,
      { subscriptionProviderId, accountSlotId: 'deadline' },
      'vault_00000000-0000-76c6-8ece-b9022b70274b'
    );
    const presented = (await handle.resolveInferenceAuth())?.presented;
    vi.useFakeTimers();
    try {
      const original = handle.credentials.read.bind(handle.credentials);
      vi.spyOn(handle.credentials, 'read').mockImplementation(async (id) => {
        await new Promise((resolve) => setTimeout(resolve, 50));
        return original(id);
      });
      const check = handle.observeInference(
        presented!,
        { kind: 'auth_rejected', settled: true, status: 401 },
        Date.now() + 20
      );
      await vi.advanceTimersByTimeAsync(21);
      await check;
      expect(await handle.getObservation()).toBeUndefined();
      await vi.advanceTimersByTimeAsync(100);
      expect(await handle.getObservation()).toBeUndefined();
    } finally {
      vi.useRealTimers();
    }
  });
});

describe('subscription-backed synthetic inference observations', () => {
  it.each([
    'openai-codex',
    'xai',
  ] as const)('records real %s quota failure and clears only on accepted access', async (subscriptionProviderId) => {
    const fixture = createFixture();
    const pair = { subscriptionProviderId, accountSlotId: 'inference' };
    const handle = await createStoredPair(
      fixture,
      pair,
      'vault_00000000-0000-70aa-931b-65de83f63bd8'
    );
    const models = handle.models as MutableModels;
    const stock = models.getProvider(subscriptionProviderId)!;
    const faux = fauxProvider({
      provider: subscriptionProviderId,
      api: subscriptionProviderId === 'openai-codex' ? 'openai-responses' : 'openai-completions',
      models: [{ id: 'gpt-test' }],
    });
    models.setProvider({ ...faux.provider, auth: stock.auth });
    const provider = {
      id: 'subscription',
      adapterId: subscriptionProviderId,
      subscriptionProviderId,
      accountSlotId: pair.accountSlotId,
      backend: 'pi-ai',
      apiKey: null,
      requiresApiKey: false,
      baseUrl: null,
      displayName: 'Subscription',
      models: ['gpt-test'],
      gatewayCapabilities: { chatCompletions: 'native', responses: 'bridged' },
    } as ResolvedLLMProviderConfig;
    const client = new PiAiGatewayClient();
    const presented = (await handle.resolveInferenceAuth())?.presented;
    await handle.observeInference(
      presented!,
      { kind: 'auth_rejected', settled: true, status: 401 },
      Date.now() + 1000
    );
    const before = authoritySnapshot(fixture);
    faux.setResponses([
      fauxAssistantMessage([], { stopReason: 'error', errorMessage: 'insufficient_quota' }),
    ]);
    await expect(
      client.createChatCompletion(
        provider,
        { model: 'gpt-test', messages: [{ role: 'user', content: 'hello' }] },
        undefined,
        {},
        models
      )
    ).rejects.toMatchObject({ failure: { kind: 'quota_exhausted' } });
    expect(await handle.getObservation()).toMatchObject({
      accessRejected: { observedAt: DEFAULT_TIME },
      quotaExhausted: { observedAt: DEFAULT_TIME },
    });
    const controller = new AbortController();
    faux.setResponses([fauxAssistantMessage([fauxText('accepted')])]);
    await expect(
      client.createChatCompletion(
        provider,
        { model: 'gpt-test', messages: [] },
        () => controller.abort(),
        { signal: controller.signal },
        models
      )
    ).rejects.toBeDefined();
    expect(await handle.getObservation()).toMatchObject({
      accessRejected: { observedAt: DEFAULT_TIME },
      quotaExhausted: { observedAt: DEFAULT_TIME },
    });
    faux.setResponses([fauxAssistantMessage([fauxText('accepted')])]);
    const stream = await client.createChatCompletionStream(
      provider,
      { model: 'gpt-test', messages: [], stream: true },
      undefined,
      {},
      models
    );
    await new Response(stream).text();
    expect(await handle.getObservation()).toEqual({
      quotaExhausted: { observedAt: DEFAULT_TIME },
    });
    expect(await fixture.manager.getStatus(pair)).toMatchObject({ status: 'logged_in' });
    expect(authoritySnapshot(fixture)).toEqual(before);
  });
});

describe('captured inference rejection and routing', () => {
  it.each([
    'openai-codex',
    'xai',
  ] as const)('checks the actual %s rejected inference snapshot with an explicit deadline', async (subscriptionProviderId) => {
    const fixture = createFixture();
    const pair = { subscriptionProviderId, accountSlotId: 'actual' };
    const handle = await createStoredPair(
      fixture,
      pair,
      'vault_00000000-0000-788b-b7fb-294f007fb845'
    );
    const models = handle.models as MutableModels;
    const stock = models.getProvider(subscriptionProviderId)!;
    const faux = fauxProvider({
      provider: subscriptionProviderId,
      api: 'openai-completions',
      models: [{ id: 'gpt-test' }],
    });
    models.setProvider({ ...faux.provider, auth: stock.auth });
    const observed = vi.spyOn(handle, 'observeInference');
    let bearer: string | undefined;
    faux.setResponses([
      (_context, options) => {
        bearer = options.apiKey;
        return Object.assign(
          fauxAssistantMessage([], { stopReason: 'error', errorMessage: 'invalid_token' }),
          { status: 401 }
        );
      },
    ]);
    const provider = {
      id: 'actual',
      adapterId: subscriptionProviderId,
      subscriptionProviderId,
      accountSlotId: pair.accountSlotId,
      backend: 'pi-ai',
      apiKey: null,
      requiresApiKey: false,
      baseUrl: null,
      displayName: 'Actual',
      models: ['gpt-test'],
      gatewayCapabilities: { chatCompletions: 'native', responses: 'bridged' },
    } as ResolvedLLMProviderConfig;
    await expect(
      new PiAiGatewayClient().createChatCompletion(
        provider,
        { model: 'gpt-test', messages: [] },
        undefined,
        {},
        models
      )
    ).rejects.toMatchObject({
      failure: { kind: 'auth_rejected', settled: true, status: 401 },
    });
    expect(observed).toHaveBeenCalledTimes(1);
    const [presented, failure] = observed.mock.calls[0]!;
    expect(presented.auth.apiKey).toBe(bearer);
    // Direct proof checks reuse the captured auth independently of route deadline forwarding.
    await handle.observeInference(presented, failure, Date.now() + 1000);
    expect(await handle.getObservation()).toMatchObject({
      accessRejected: { observedAt: DEFAULT_TIME },
    });
    const read = vi
      .spyOn(handle.credentials, 'read')
      .mockRejectedValue(new Error('local store failure'));
    await handle.observeInference(presented, failure, Date.now() + 1000);
    read.mockRestore();
    expect(await handle.getObservation()).toMatchObject({
      accessRejected: { observedAt: DEFAULT_TIME },
    });
    // Rotation of identical bytes is nevertheless a new material version.
    await handle.credentials.modify(subscriptionProviderId, async (current) => current!);
    expect(await handle.getObservation()).toBeUndefined();
    await handle.observeInference(presented, failure, Date.now() + 1000);
    expect(await handle.getObservation()).toBeUndefined();
  });

  it('preserves authored order and primary eligibility with rejection and exhausted quota', async () => {
    const fixture = createFixture();
    const pair = accountPair('availability');
    const handle = await createStoredPair(
      fixture,
      pair,
      'vault_00000000-0000-75c8-89e4-e659a8f043ef'
    );
    writeAvailabilitySupply(fixture);
    const gatewayPath = join(fixture.dataRoot, 'config/gateway.jsonc');
    const config = JSON.parse(readFileSync(gatewayPath, 'utf8'));
    config.logicalModels[0].routes.push({
      id: 'authored-backup',
      providerProfileId: 'independent',
      providerModel: 'gpt-5.1',
    });
    writeFileSync(gatewayPath, JSON.stringify(config));
    const bytes = readFileSync(gatewayPath);
    const snapshot = loadRuntimeConfig(fixture.dataRoot);
    const resolve = () =>
      resolveLogicalModel(
        snapshot.gatewayConfig,
        snapshot.providerRegistry,
        'bound-tier',
        fixture.manager
      )!;
    const before = resolve().routes.map((route) => ({ id: route.id, available: route.available }));
    const presented = (await handle.resolveInferenceAuth())?.presented;
    await handle.observeInference(
      presented!,
      { kind: 'auth_rejected', settled: true, status: 401 },
      Date.now() + 1000
    );
    await handle.observeInference(presented!, { kind: 'quota_exhausted', settled: true });
    expect(resolve().routes.map((route) => ({ id: route.id, available: route.available }))).toEqual(
      before
    );
    const order: string[] = [];
    await dispatchLogicalModel({
      logicalModel: resolve(),
      signal: new AbortController().signal,
      providerSubscriptionAccountManager: fixture.manager,
      resolveGatewayProvider: (id, model) =>
        ({
          id,
          adapterId: 'openai-codex',
          subscriptionProviderId: id === 'bound' ? 'openai-codex' : undefined,
          accountSlotId: id === 'bound' ? pair.accountSlotId : undefined,
          models: [model],
          backend: 'pi-ai',
          apiKey: null,
          requiresApiKey: false,
          gatewayCapabilities: { chatCompletions: 'native', responses: 'native' },
        }) as ResolvedLLMProviderConfig,
      attempt: async ({ provider }) => {
        order.push(provider.id);
        if (provider.id === 'bound')
          throw Object.assign(new Error('quota'), {
            failure: { kind: 'quota_exhausted', settled: true },
          });
        return 'accepted';
      },
    });
    expect(order).toEqual(['bound', 'independent']);
    expect(readFileSync(gatewayPath)).toEqual(bytes);
  });
});

describe('pair proof dependency exclusions', () => {
  it('retains Codex OAuth, bearer and account equality and suppresses missing or invalid rechecks', async () => {
    const fixture = createFixture();
    const handle = await createStoredPair(
      fixture,
      accountPair('proof'),
      'vault_00000000-0000-79ad-822b-45a1c4d88ec0'
    );
    const presented = (await handle.resolveInferenceAuth())?.presented;
    const original = await handle.credentials.read('openai-codex');
    for (const current of [
      undefined,
      { ...original, type: 'api_key' },
      { ...original, access: 'other' },
      { ...original, accountId: 'other' },
    ]) {
      const read = vi.spyOn(handle.credentials, 'read').mockResolvedValue(current as never);
      await handle.observeInference(
        presented!,
        { kind: 'auth_rejected', settled: true, status: 401 },
        Date.now() + 1000
      );
      read.mockRestore();
      expect(await handle.getObservation()).toBeUndefined();
    }
  });
  it('suppresses changed or missing xAI bearer auth without inspecting provider credential fields', async () => {
    const fixture = createFixture();
    const handle = await createStoredPair(
      fixture,
      { subscriptionProviderId: 'xai', accountSlotId: 'proof' },
      'vault_00000000-0000-7a8c-bf98-bea97503c2dd'
    );
    const presented = (await handle.resolveInferenceAuth())?.presented;
    for (const auth of [undefined, { auth: { apiKey: 'different-bearer' } }]) {
      const getAuth = vi.spyOn(handle.models, 'getAuth').mockResolvedValue(auth);
      await handle.observeInference(
        presented!,
        { kind: 'auth_rejected', settled: true, status: 401 },
        Date.now() + 1000
      );
      getAuth.mockRestore();
      expect(await handle.getObservation()).toBeUndefined();
    }
  });
});

describe('public inference observation read model', () => {
  it.each([
    'openai-codex',
    'xai',
  ] as const)('projects independent %s timestamps without quota reads', async (subscriptionProviderId) => {
    const fixture = createFixture();
    const pair = accountPair('public', subscriptionProviderId);
    const handle = await createStoredPair(
      fixture,
      pair,
      'vault_00000000-0000-7b65-922a-a84acfa604c4'
    );
    const presented = (await handle.resolveInferenceAuth())!.presented!;
    const app = createApp({
      coreDb: fixture.coreDb,
      dataRoot: fixture.dataRoot,
      providerSubscriptionAccountManager: fixture.manager,
    });
    const fetchSpy = vi
      .spyOn(globalThis, 'fetch')
      .mockRejectedValue(new Error('Account reads must not fetch quota.'));
    const before = authoritySnapshot(fixture);
    const read = async () => {
      fixture.clock.use(DEFAULT_TIME);
      const list = await app.request(
        ...operationRequest('provider-subscription.account-list', {
          subscriptionProviderId: subscriptionProviderId,
        })
      );
      const detail = await app.request(
        ...operationRequest('provider-subscription.account-status', {
          subscriptionProviderId: subscriptionProviderId,
          accountSlotId: 'public',
        })
      );
      expect(list.status).toBe(200);
      expect(detail.status).toBe(200);
      const accounts = (await list.json()).accounts;
      const account = await detail.json();
      expect(accounts).toEqual([account]);
      expect(account.status).toBe('logged_in');
      return account;
    };
    expect(await read()).not.toHaveProperty('inferenceObservation');
    const accessAt = '2026-10-02T01:00:00.000Z';
    const quotaAt = '2026-10-02T02:00:00.000Z';
    fixture.clock.use(accessAt);
    await handle.observeInference(
      presented,
      { kind: 'auth_rejected', settled: true, status: 401 },
      Date.now() + 1000
    );
    fixture.clock.use(quotaAt);
    await handle.observeInference(presented, { kind: 'quota_exhausted', settled: true });
    expect((await read()).inferenceObservation).toEqual({
      accessRejected: { observedAt: accessAt },
      quotaExhausted: { observedAt: quotaAt },
    });
    await handle.observeInference(presented);
    expect((await read()).inferenceObservation).toEqual({
      quotaExhausted: { observedAt: quotaAt },
    });
    await handle.observeQuota(presented.version, 'available');
    expect(await read()).not.toHaveProperty('inferenceObservation');
    expect(fetchSpy).not.toHaveBeenCalled();
    expect(authoritySnapshot(fixture)).toEqual(before);
  });

  it.each([
    'openai-codex',
    'xai',
  ] as const)('clears %s observations only on accepted same-version uncancelled quota', async (subscriptionProviderId) => {
    const fixture = createFixture();
    const pair = accountPair('quota_clear', subscriptionProviderId);
    const handle = await createStoredPair(
      fixture,
      pair,
      'vault_00000000-0000-7817-beca-2e6ab68aadec'
    );
    const presented = (await handle.resolveInferenceAuth())!.presented!;
    await handle.observeInference(
      presented,
      { kind: 'auth_rejected', settled: true, status: 401 },
      Date.now() + 1000
    );
    await handle.observeInference(presented, { kind: 'quota_exhausted', settled: true });
    const both = await handle.getObservation();
    await handle.observeQuota('predecessor:1', 'available');
    expect(await handle.getObservation()).toEqual(both);
    const controller = new AbortController();
    controller.abort();
    await handle.observeQuota(presented.version, 'available', true, controller.signal);
    expect(await handle.getObservation()).toEqual(both);
    await handle.observeQuota(presented.version, 'temporarily_unavailable');
    expect(await handle.getObservation()).toEqual(both);
    await handle.observeQuota(presented.version, 'temporarily_unavailable', true);
    expect(await handle.getObservation()).toEqual({ quotaExhausted: { observedAt: DEFAULT_TIME } });
    await handle.observeQuota(presented.version, 'available');
    expect(await handle.getObservation()).toBeUndefined();
  });
});

describe('live quota and inference observations', () => {
  it.each([
    'openai-codex',
    'xai',
  ] as const)('keeps live %s quota independent and clears through the real owner', async (subscriptionProviderId) => {
    const fixture = createFixture();
    const pair = accountPair('live_quota', subscriptionProviderId);
    const handle = await createStoredPair(
      fixture,
      pair,
      'vault_00000000-0000-7698-afb3-d211797cfe6f'
    );
    const presented = (await handle.resolveInferenceAuth())!.presented!;
    await handle.observeInference(
      presented,
      { kind: 'auth_rejected', settled: true, status: 401 },
      Date.now() + 1000
    );
    await handle.observeInference(presented, { kind: 'quota_exhausted', settled: true });
    const both = await handle.getObservation();
    const before = authoritySnapshot(fixture);
    const app = createApp({
      coreDb: fixture.coreDb,
      dataRoot: fixture.dataRoot,
      providerSubscriptionAccountManager: fixture.manager,
    });
    const upstream = vi
      .spyOn(globalThis, 'fetch')
      .mockResolvedValueOnce(new Response('', { status: 503 }));
    const failed = await app.request(
      ...operationRequest('provider-subscription.account-quota', {
        subscriptionProviderId: subscriptionProviderId,
        accountSlotId: 'live_quota',
      })
    );
    expect(failed.status).toBe(200);
    expect(await failed.json()).toEqual({
      ...pair,
      availability: 'temporarily_unavailable',
      observedAt: expect.any(String),
    });
    expect(await handle.getObservation()).toEqual(both);
    if (subscriptionProviderId === 'xai') {
      upstream
        .mockResolvedValueOnce(
          new Response(JSON.stringify({ userId: 'private-user', subscriptionTier: 'SuperGrok' }))
        )
        .mockResolvedValueOnce(new Response('', { status: 503 }));
      const partial = await app.request(
        ...operationRequest('provider-subscription.account-quota', {
          subscriptionProviderId: subscriptionProviderId,
          accountSlotId: 'live_quota',
        })
      );
      expect((await partial.json()).availability).toBe('temporarily_unavailable');
      expect(await handle.getObservation()).toEqual({
        quotaExhausted: { observedAt: DEFAULT_TIME },
      });
      upstream
        .mockResolvedValueOnce(
          new Response(JSON.stringify({ userId: 'private-user', subscriptionTier: 'SuperGrok' }))
        )
        .mockResolvedValueOnce(
          new Response(JSON.stringify({ config: { creditUsagePercent: 10 } }))
        );
    } else {
      upstream.mockResolvedValueOnce(
        new Response(JSON.stringify({ plan_type: 'pro', rate_limit: null }))
      );
    }
    const available = await app.request(
      ...operationRequest('provider-subscription.account-quota', {
        subscriptionProviderId: subscriptionProviderId,
        accountSlotId: 'live_quota',
      })
    );
    expect(available.status).toBe(200);
    expect((await available.json()).availability).toBe('available');
    expect(await handle.getObservation()).toBeUndefined();
    expect(await fixture.manager.getStatus(pair)).not.toHaveProperty('inferenceObservation');
    expect(authoritySnapshot(fixture)).toEqual(before);
  });
});

/**
 * Builds a real inference app using the account fixture's existing pair owner.
 * @param subscriptionProviderId Provider whose stock auth and synthetic inference are exercised.
 * @param worker Whether to admit the existing trusted Worker relay and submitted execution attempt.
 * @returns App, real account owner, admitted Turn and controlled synthetic Provider.
 */
async function createObservedInferenceRouteFixture(
  subscriptionProviderId: 'openai-codex' | 'xai',
  worker: boolean
) {
  const fixture = createFixture();
  const pair = accountPair('route_rejection', subscriptionProviderId);
  const handle = await createStoredPair(
    fixture,
    pair,
    'vault_00000000-0000-799d-848e-914aef612c73'
  );
  const providerModel =
    subscriptionProviderId === 'openai-codex' ? 'openai-codex/gpt-5.6-sol' : 'grok-4.3';
  const models = handle.models as MutableModels;
  const stock = models.getProvider(subscriptionProviderId)!;
  const faux = fauxProvider({
    provider: subscriptionProviderId,
    api:
      subscriptionProviderId === 'openai-codex' ? 'openai-codex-responses' : 'openai-completions',
    models: [{ id: providerModel.replace('openai-codex/', '') }],
  });
  models.setProvider({ ...faux.provider, auth: stock.auth });
  const store = createDemoStore({ dataRoot: fixture.dataRoot });
  const turn = store.createTurn(
    'ws_00000000-0000-7000-8000-000000000001',
    'th_00000000-0000-7000-8000-000000000001',
    'Inference observation regression',
    {
      kind: 'user',
      id: 'usr_00000000-0000-7000-8000-000000000001',
    }
  );
  ensureLocalUser(fixture.coreDb);
  recordWorkspaceOwnerMembership({
    coreDb: fixture.coreDb,
    workspaceId: turn.workspaceId,
    ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
  });
  let workerControlGateway: WorkerControlGateway | undefined;
  const token = 'BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB';
  if (worker) {
    const environmentPackage = resolveAgentEnvironmentPackage({
      captureCoverage: store.getTurnCaptureCoverage(turn.id)!,
      agentSetup: createTestAgentSetup({
        logicalModelId: 'observed-tier',
        privateRoute: { providerProfileId: 'observed-provider', providerModel },
        requiredCapabilities: ['trusted-worker-inference-relay'],
      }),
      agentSessionId: 'as_00000000-0000-73a6-ad6e-94db2c0fc59a',
      backend: { kind: 'openshell' },
      createdAt: DEFAULT_TIME,
      requestId: 'req_observed_worker',
      triggerActor: {
        kind: 'automation',
        id: 'auto_00000000-0000-7632-841a-e500ef6a5297',
        responsibleUserId: 'usr_00000000-0000-7000-8000-000000000001',
      },
      turn,
      workspaceCwd: '/workspace/openkit',
      workspaceRoots: [],
    });
    const entry = createSchedulerAdmissionEntry(fixture.coreDb, {
      backendId: 'nanohost',
      queueEntryId: 'queue_observed',
      requestId: 'req_observed_worker',
      triggerActor: environmentPackage.scope.triggerActor,
      serverAdminTokenId: null,
      workspaceId: turn.workspaceId,
      threadId: turn.threadId,
      turnId: turn.id,
      turnInput: 'Inference observation regression',
      requestedAgentId: environmentPackage.agent.agentId,
    });
    recordTestExecutionAttempt(fixture.coreDb, {
      entry,
      attemptId: 'attempt_00000000-0000-78e7-a1a8-e35549517347',
      agentSessionId: environmentPackage.scope.agentSessionId,
      inputRef: environmentPackage.snapshotId,
      bindingRef: 'lease-binding:observed',
      sessionCompatibilityKey: 'observed-inference',
      operationId: 'submit:observed',
      now: () => new Date().toISOString(),
    });
    workerControlGateway = new WorkerControlGateway({
      resolveTokenBinding: () => ({ status: 'accepted' }),
    });
    workerControlGateway.registerSession(environmentPackage, {
      sandboxBindingRef: 'lease-binding:observed',
      workerControlToken: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
      workerInferenceToken: token,
      workerCapabilityToken: 'CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC',
    });
  }
  const app = createApp({
    coreDb: fixture.coreDb,
    dataRoot: fixture.dataRoot,
    store,
    providerSubscriptionAccountManager: fixture.manager,
    ...(workerControlGateway ? { workerControlGateway } : {}),
    gatewayConfig: {
      schemaVersion: 1,
      enabled: true,
      defaultLogicalModelId: 'observed-tier',
      logicalModels: [
        {
          id: 'observed-tier',
          displayName: 'Observed',
          contextManagement: [{ type: 'compaction', compactThreshold: 8000 }],
          routes: [
            { id: 'authored-primary', providerProfileId: 'observed-provider', providerModel },
          ],
        },
      ],
    },
    providerRegistry: new ProviderRegistry([
      {
        id: 'observed-provider',
        displayName: 'Observed',
        kind: 'oauth',
        vendor: subscriptionProviderId,
        models: [providerModel],
        extensions: { openkit: { subscriptionAccount: { accountSlotId: pair.accountSlotId } } },
      },
    ]),
    llmGatewayDispatcher: new LLMGatewayProviderDispatcher({ piAiClient: new PiAiGatewayClient() }),
  });
  return { fixture, pair, handle, faux, app, turn, token, providerModel };
}

describe('inference route same-credential rejection', () => {
  const routes = [
    { worker: false, endpoint: 'chat/completions', stream: false },
    { worker: false, endpoint: 'chat/completions', stream: true },
    { worker: false, endpoint: 'responses', stream: false },
    { worker: false, endpoint: 'responses', stream: true },
    { worker: true, endpoint: 'chat/completions', stream: true },
    { worker: true, endpoint: 'responses', stream: false },
  ];
  for (const route of routes)
    for (const subscriptionProviderId of ['openai-codex', 'xai'] as const) {
      it.each([
        'proven',
        'predecessor',
        'deadline',
      ] as const)(`${subscriptionProviderId} ${route.worker ? 'Worker' : 'public'} ${route.endpoint} stream=${route.stream} %s preserves outcome and lineage`, async (scenario) => {
        const f = await createObservedInferenceRouteFixture(subscriptionProviderId, route.worker);
        const epoch = Date.now();
        const clock = vi.spyOn(Date, 'now').mockReturnValue(epoch);
        const observed = vi.spyOn(f.handle, 'observeInference');
        const fetchSpy = vi
          .spyOn(globalThis, 'fetch')
          .mockRejectedValue(new Error('Inference observation must not fetch quota.'));
        let bearer: string | undefined;
        const reject = async (_context: unknown, options: StreamOptions | undefined) => {
          // This controlled native source emits only a framing event before its classified rejection.
          // Invoke the installed pre-conversion hook so the Worker can prove its complete empty output.
          if (route.worker) {
            const model = f.handle.models.getModel(
              subscriptionProviderId,
              f.providerModel.replace('openai-codex/', '')
            )!;
            await options?.onProviderStreamEvent?.(
              subscriptionProviderId === 'openai-codex'
                ? {
                    type: 'response.created',
                    response: { id: 'resp_observed_rejection', output: [] },
                  }
                : { id: 'chatcmpl_observed_rejection', choices: [] },
              model
            );
          }
          bearer = options?.apiKey;
          if (scenario === 'predecessor')
            await f.handle.credentials.modify(subscriptionProviderId, async (current) => current!);
          if (scenario === 'deadline') clock.mockReturnValue(epoch + 120001);
          return Object.assign(
            fauxAssistantMessage([], {
              stopReason: 'error',
              errorMessage: 'invalid_token private-inference-marker',
            }),
            { status: 401 }
          );
        };
        const request = async () => {
          clock.mockReturnValue(epoch);
          f.faux.setResponses([reject]);
          const response = await f.app.request(
            `${route.worker ? '/api/worker-inference' : ''}/v1/${route.endpoint}`,
            {
              method: 'POST',
              headers: {
                'content-type': 'application/json',
                ...(route.worker ? { authorization: `Bearer ${f.token}` } : {}),
              },
              body: JSON.stringify({
                model: 'observed-tier',
                stream: route.stream,
                // Keep synthetic input measurements identical across the control and observed calls.
                prompt_cache_retention: 'none',
                ...(route.endpoint === 'responses'
                  ? { input: 'Hello' }
                  : { messages: [{ role: 'user', content: 'Hello' }] }),
                ...(!route.worker && subscriptionProviderId !== 'openai-codex'
                  ? {
                      metadata: {
                        openkit: {
                          requestId: randomUUID(),
                          workspaceId: f.turn.workspaceId,
                          threadId: f.turn.threadId,
                          turnId: f.turn.id,
                        },
                      },
                    }
                  : {}),
              }),
            }
          );
          return {
            status: response.status,
            contentType: response.headers.get('content-type'),
            body: await response.text(),
          };
        };
        // The control changes only observation consumption, retaining real dispatch and route owners.
        observed.mockResolvedValueOnce(undefined);
        const control = await request();
        expect(await f.handle.getObservation()).toBeUndefined();
        const outcome = await request();
        expect(outcome).toEqual(control);
        expect(outcome.body).toMatch(
          /gateway_logical_model_unavailable|gateway_provider_authentication_failed/
        );
        expect(outcome.body).not.toContain('private-inference-marker');
        expect(observed).toHaveBeenCalledTimes(2);
        const [presented, failure, deadline] = observed.mock.calls[1]!;
        expect(presented.auth.apiKey).toBe(bearer);
        expect(failure).toMatchObject({
          kind: 'auth_rejected',
          settled: true,
          status: 401,
        });
        expect(deadline).toBe(epoch + 120000);
        if (scenario === 'predecessor')
          expect(await f.handle.getCredentialVersion()).not.toBe(presented.version);
        if (scenario === 'deadline') expect(Date.now()).toBeGreaterThan(deadline!);
        const list = await f.app.request(
          ...operationRequest('provider-subscription.account-list', {
            subscriptionProviderId: subscriptionProviderId,
          })
        );
        const detail = await f.app.request(
          ...operationRequest('provider-subscription.account-status', {
            subscriptionProviderId: subscriptionProviderId,
            accountSlotId: f.pair.accountSlotId,
          })
        );
        expect(list.status).toBe(200);
        expect(detail.status).toBe(200);
        const account = await detail.json();
        expect((await list.json()).accounts).toEqual([account]);
        expect(account.status).toBe('logged_in');
        if (scenario === 'proven')
          expect(account.inferenceObservation).toEqual({
            accessRejected: { observedAt: DEFAULT_TIME },
          });
        else expect(account).not.toHaveProperty('inferenceObservation');
        expect(fetchSpy).not.toHaveBeenCalled();
        const db = openWorkspaceDb(f.fixture.dataRoot, f.turn.workspaceId);
        try {
          const calls = listWorkspaceCapabilityCalls(db, f.turn.workspaceId);
          // Codex native admission excludes public metadata; Worker scope supplies its durable attribution.
          if (!route.worker && subscriptionProviderId === 'openai-codex') {
            expect(calls).toHaveLength(0);
            return;
          }
          expect(calls).toHaveLength(2);
          const facts = calls.map((call) => ({
            status: call.status,
            errorCode: call.errorCode,
            providerRef: call.providerRef,
            entries: call.extensions?.['openkit.gateway/routeLineage']?.entries.map(
              ({ usageRecordIds, ...entry }) => ({
                ...entry,
                usageRecords: usageRecordIds?.length ?? 0,
              })
            ),
          }));
          expect(facts[1]).toEqual(facts[0]);
          expect(facts[1]).toMatchObject({
            status: 'failed',
            providerRef: null,
            entries: [
              {
                kind: 'attempt',
                routeMemberId: 'authored-primary',
                providerProfileId: 'observed-provider',
                providerModel: f.providerModel,
                selectionReason: 'primary',
                attemptOrder: 0,
                retryIndex: 0,
                terminalResult: 'failed',
                failureKind: 'auth_rejected',
              },
            ],
          });
          expect(facts[1]!.entries).toHaveLength(1);
          expect(JSON.stringify(facts)).not.toMatch(
            /route_rejection|accessRejected|private-inference-marker/
          );
        } finally {
          db.sqlite.close();
        }
      });
    }
});

describe('subscription refresh inference ownership', () => {
  it.each([
    'openai-codex',
    'xai',
  ] as const)('terminates one %s member attempt on its first stock refresh failure', async (subscriptionProviderId) => {
    const f = await createObservedInferenceRouteFixture(subscriptionProviderId, true);
    await f.handle.credentials.modify(subscriptionProviderId, async () => ({
      ...oauthCredential('expired'),
      expires: Date.now() - 1,
    }));
    const oauth = requireProviderOAuth(f.handle, f.pair);
    const refresh = vi
      .spyOn(oauth, 'refresh')
      .mockRejectedValueOnce(new Error('refresh dependency failed'))
      .mockResolvedValue(oauthCredential('fresh'));
    const inference = vi.fn(() => fauxAssistantMessage([fauxText('accepted')]));
    f.faux.setResponses([inference]);
    const attempt = vi.spyOn(PiAiGatewayClient.prototype, 'createChatCompletion');
    const response = await f.app.request('/api/worker-inference/v1/chat/completions', {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${f.token}` },
      body: JSON.stringify({
        model: 'observed-tier',
        messages: [{ role: 'user', content: 'Hello' }],
        prompt_cache_retention: 'none',
      }),
    });
    // Stock setup errors have no HTTP/delivery evidence; the existing unknown projection is 400.
    expect(response.status).toBe(400);
    expect(attempt).toHaveBeenCalledTimes(1);
    await expect(attempt.mock.results[0]!.value).rejects.toMatchObject({
      message: `OAuth refresh failed for ${subscriptionProviderId}: refresh dependency failed`,
      failure: { kind: 'unknown', settled: false },
    });
    expect(refresh).toHaveBeenCalledTimes(1);
    expect(inference).not.toHaveBeenCalled();
    expect(await f.handle.getCredentialVersion()).toBe(
      'vault_00000000-0000-799d-848e-914aef612c73:2'
    );
    expect(await f.fixture.manager.getStatus(f.pair)).not.toHaveProperty('inferenceObservation');
    const db = openWorkspaceDb(f.fixture.dataRoot, f.turn.workspaceId);
    try {
      const calls = listWorkspaceCapabilityCalls(db, f.turn.workspaceId);
      expect(calls).toHaveLength(1);
      expect(calls[0]).toMatchObject({ status: 'failed', providerRef: null });
      expect(calls[0]!.extensions?.['openkit.gateway/routeLineage']?.entries).toEqual([
        expect.objectContaining({
          kind: 'attempt',
          attemptOrder: 0,
          retryIndex: 0,
          terminalResult: 'failed',
          failureKind: 'unknown',
          routeMemberId: 'authored-primary',
        }),
      ]);
    } finally {
      db.sqlite.close();
    }
  });

  for (const subscriptionProviderId of ['openai-codex', 'xai'] as const)
    it.each([
      'auth_rejected',
      'quota_exhausted',
    ] as const)(`projects post-refresh ${subscriptionProviderId} %s from the actual bearer`, async (kind) => {
      // Refresh attribution must finish within the unchanged deadline, independent of real Vault I/O speed.
      vi.useFakeTimers({ toFake: ['Date', 'setTimeout', 'clearTimeout'] });
      vi.setSystemTime(DEFAULT_TIME);
      const fixture = createFixture();
      const pair = accountPair('refresh', subscriptionProviderId);
      const handle = await createStoredPair(
        fixture,
        pair,
        'vault_00000000-0000-79d6-aa15-2f46423f0a70',
        {
          ...oauthCredential('expired'),
          expires: Date.now() - 1,
        }
      );
      const models = handle.models as MutableModels;
      const stock = models.getProvider(subscriptionProviderId)!;
      const fresh = oauthCredential('fresh');
      const refresh = vi.spyOn(stock.auth.oauth!, 'refresh').mockResolvedValue(fresh);
      const faux = fauxProvider({
        provider: subscriptionProviderId,
        api: 'openai-completions',
        models: [{ id: 'gpt-test' }],
      });
      models.setProvider({ ...faux.provider, auth: stock.auth });
      let bearer: string | undefined;
      faux.setResponses([
        (_context, options) => {
          bearer = options.apiKey;
          return Object.assign(
            fauxAssistantMessage([], {
              stopReason: 'error',
              errorMessage: kind === 'auth_rejected' ? 'invalid_token' : 'insufficient_quota',
            }),
            { status: kind === 'auth_rejected' ? 401 : 429 }
          );
        },
      ]);
      const provider = {
        id: 'subscription',
        adapterId: subscriptionProviderId,
        subscriptionProviderId,
        accountSlotId: pair.accountSlotId,
        backend: 'pi-ai',
        apiKey: null,
        requiresApiKey: false,
        baseUrl: null,
        displayName: 'Subscription',
        models: ['gpt-test'],
        gatewayCapabilities: { chatCompletions: 'native', responses: 'bridged' },
      } as ResolvedLLMProviderConfig;
      const observed = vi.spyOn(handle, 'observeInference');
      await expect(
        new PiAiGatewayClient().createChatCompletion(
          provider,
          { model: 'gpt-test', messages: [] },
          undefined,
          { deadline: Date.now() + 1000 },
          models
        )
      ).rejects.toMatchObject({
        failure: {
          kind,
          settled: true,
          status: kind === 'auth_rejected' ? 401 : 429,
        },
      });
      expect(refresh).toHaveBeenCalledTimes(1);
      expect(bearer).toBe(fresh.access);
      expect(await handle.getCredentialVersion()).toBe(
        'vault_00000000-0000-79d6-aa15-2f46423f0a70:2'
      );
      expect(observed).toHaveBeenCalledTimes(1);
      expect(observed.mock.calls[0]![0]).toMatchObject({
        version: 'vault_00000000-0000-79d6-aa15-2f46423f0a70:2',
        auth: { apiKey: fresh.access },
      });
      const app = createApp({
        coreDb: fixture.coreDb,
        dataRoot: fixture.dataRoot,
        providerSubscriptionAccountManager: fixture.manager,
      });
      const fetchSpy = vi
        .spyOn(globalThis, 'fetch')
        .mockRejectedValue(new Error('No quota request allowed.'));
      const detail = await app.request(
        ...operationRequest('provider-subscription.account-status', {
          subscriptionProviderId: subscriptionProviderId,
          accountSlotId: 'refresh',
        })
      );
      const list = await app.request(
        ...operationRequest('provider-subscription.account-list', {
          subscriptionProviderId: subscriptionProviderId,
        })
      );
      expect(detail.status).toBe(200);
      expect(list.status).toBe(200);
      const account = await detail.json();
      expect((await list.json()).accounts).toEqual([account]);
      expect(account).toMatchObject({
        status: 'logged_in',
        inferenceObservation: {
          [kind === 'auth_rejected' ? 'accessRejected' : 'quotaExhausted']: {
            observedAt: DEFAULT_TIME,
          },
        },
      });
      expect(fetchSpy).not.toHaveBeenCalled();
    });
});

describe('subscription auth attribution isolation', () => {
  for (const subscriptionProviderId of ['openai-codex', 'xai'] as const) {
    it(`keeps resolved ${subscriptionProviderId} auth when optional attribution is unreadable`, async () => {
      const fixture = createFixture();
      const pair = accountPair('advisory', subscriptionProviderId);
      const handle = await createStoredPair(
        fixture,
        pair,
        'vault_00000000-0000-7abd-84b1-ca3ac953559e'
      );
      const models = handle.models as MutableModels;
      const stock = models.getProvider(subscriptionProviderId)!;
      const faux = fauxProvider({
        provider: subscriptionProviderId,
        api: 'openai-completions',
        models: [{ id: 'gpt-test' }],
      });
      models.setProvider({ ...faux.provider, auth: stock.auth });
      const original = models.getAuth.bind(models);
      const getAuth = vi.spyOn(models, 'getAuth').mockImplementation(async (...args) => {
        const resolved = await original(...args);
        fixture.replaceBackend({
          ...fixture.backend(),
          listReferences: () => {
            throw new Error('optional attribution unavailable');
          },
        });
        return resolved;
      });
      faux.setResponses([
        (_context, options) => {
          fixture.replaceBackend();
          expect(options.apiKey).toBe(
            oauthCredential('vault_00000000-0000-7abd-84b1-ca3ac953559e').access
          );
          return fauxAssistantMessage([fauxText('accepted')]);
        },
      ]);
      const provider = {
        id: 'subscription',
        adapterId: subscriptionProviderId,
        subscriptionProviderId,
        accountSlotId: pair.accountSlotId,
        backend: 'pi-ai',
        apiKey: null,
        requiresApiKey: false,
        baseUrl: null,
        displayName: 'Subscription',
        models: ['gpt-test'],
        gatewayCapabilities: { chatCompletions: 'native', responses: 'bridged' },
      } as ResolvedLLMProviderConfig;
      const response = await new PiAiGatewayClient().createChatCompletion(
        provider,
        { model: 'gpt-test', messages: [] },
        undefined,
        {},
        models
      );
      expect(response.choices[0]!.message.content).toBe('accepted');
      expect(getAuth).toHaveBeenCalledTimes(1);
      expect(await handle.getObservation()).toBeUndefined();
    });

    it.each([
      'auth_rejected',
      'quota_exhausted',
    ] as const)(`suppresses ${subscriptionProviderId} %s after identical material is replaced during auth derivation`, async (kind) => {
      const fixture = createFixture();
      const pair = accountPair('derivation', subscriptionProviderId);
      const handle = await createStoredPair(
        fixture,
        pair,
        'vault_00000000-0000-740a-b6b4-6b4c397f0315'
      );
      const models = handle.models as MutableModels;
      const stock = models.getProvider(subscriptionProviderId)!;
      const original = stock.auth.oauth!.toAuth.bind(stock.auth.oauth!);
      vi.spyOn(stock.auth.oauth!, 'toAuth').mockImplementation(async (credential) => {
        const auth = await original(credential);
        await handle.credentials.modify(subscriptionProviderId, async (current) => current!);
        return auth;
      });
      const getAuth = vi.spyOn(models, 'getAuth');
      const faux = fauxProvider({
        provider: subscriptionProviderId,
        api: 'openai-completions',
        models: [{ id: 'gpt-test' }],
      });
      models.setProvider({ ...faux.provider, auth: stock.auth });
      faux.setResponses([
        Object.assign(
          fauxAssistantMessage([], {
            stopReason: 'error',
            errorMessage: kind === 'auth_rejected' ? 'invalid_token' : 'insufficient_quota',
          }),
          { status: kind === 'auth_rejected' ? 401 : 429 }
        ),
      ]);
      const provider = {
        id: 'subscription',
        adapterId: subscriptionProviderId,
        subscriptionProviderId,
        accountSlotId: pair.accountSlotId,
        backend: 'pi-ai',
        apiKey: null,
        requiresApiKey: false,
        baseUrl: null,
        displayName: 'Subscription',
        models: ['gpt-test'],
        gatewayCapabilities: { chatCompletions: 'native', responses: 'bridged' },
      } as ResolvedLLMProviderConfig;
      await expect(
        new PiAiGatewayClient().createChatCompletion(
          provider,
          { model: 'gpt-test', messages: [] },
          undefined,
          { deadline: Date.now() + 1000 },
          models
        )
      ).rejects.toMatchObject({ failure: { kind } });
      expect(getAuth).toHaveBeenCalledTimes(1);
      expect(await handle.getCredentialVersion()).toBe(
        'vault_00000000-0000-740a-b6b4-6b4c397f0315:2'
      );
      expect(await fixture.manager.getStatus(pair)).not.toHaveProperty('inferenceObservation');
    });
  }
});

describe('subscription account publication durability', () => {
  it('syncs account authority before rename and its exact parent after rename, then reopens the manager', async () => {
    const fixture = createFixture();
    const pair = accountPair('durable_slot');
    durability.events.length = 0;
    await fixture.manager.createAccount({ ...pair, displayName: 'Durable account' });
    const path = accountPath(fixture.dataRoot, pair);
    const renameAt = durability.events.findIndex(
      (event) => event.op === 'rename' && event.path === path
    );
    expect(renameAt).toBeGreaterThan(0);
    const staged = durability.events[renameAt].from;
    expect(
      durability.events
        .slice(0, renameAt)
        .some(
          (event) =>
            event.op === 'sync' && !event.directory && event.path === staged && event.mode === 0o600
        )
    ).toBe(true);
    expect(
      durability.events
        .slice(renameAt + 1)
        .some((event) => event.op === 'sync' && event.directory && event.path === dirname(path))
    ).toBe(true);
    expect(
      durability.events.some(
        (event) => event.op === 'sync' && event.directory && event.path === dirname(dirname(path))
      )
    ).toBe(true);
    expect(lstatSync(path).mode & 0o777).toBe(0o600);
    expect(await fixture.createManager().listAccounts(pair.subscriptionProviderId)).toEqual(
      expect.arrayContaining([expect.objectContaining({ ...pair, displayName: 'Durable account' })])
    );
  });

  it.each([
    'before',
    'after',
  ] as const)('rejects success when synchronization fails %s the account rename', async (boundary) => {
    const fixture = createFixture();
    const pair = accountPair('durable_slot');
    await fixture.manager.createAccount({ ...pair, displayName: 'Prior name' });
    const path = accountPath(fixture.dataRoot, pair);
    durability.events.length = 0;
    durability.fail = (candidate, directory) =>
      boundary === 'before'
        ? !directory && dirname(candidate) === dirname(path)
        : directory &&
          candidate === dirname(path) &&
          durability.events.some((event) => event.op === 'rename' && event.path === path);
    try {
      await expect(
        fixture.manager.updateAccount(pair, { displayName: 'Replacement name' })
      ).rejects.toMatchObject(PERSISTENCE_ERROR);
      durability.fail = undefined;
      expect(await fixture.createManager().listAccounts(pair.subscriptionProviderId)).toEqual(
        expect.arrayContaining([
          expect.objectContaining({
            ...pair,
            displayName: boundary === 'before' ? 'Prior name' : 'Replacement name',
          }),
        ])
      );
    } finally {
      durability.fail = undefined;
    }
  });
});

describe('uncommitted ancestor account recovery', () => {
  it('retries a failed managed-ancestor synchronization before account authority can be published', async () => {
    const fixture = createFixture();
    const pair = accountPair('ancestor_retry');
    const parent = join(fixture.dataRoot, 'server', 'files');
    const managedRoot = join(parent, 'provider-subscriptions');
    const path = accountPath(fixture.dataRoot, pair);
    durability.events.length = 0;
    durability.fail = (candidate, directory) => directory && candidate === parent;
    try {
      await expect(
        fixture.manager.createAccount({ ...pair, displayName: 'Retained account' })
      ).rejects.toMatchObject(PERSISTENCE_ERROR);
      expect(existsSync(managedRoot)).toBe(true);
      expect(existsSync(path)).toBe(false);
      durability.events.length = 0;
      await expect(
        fixture.createManager().createAccount({ ...pair, displayName: 'Retained account' })
      ).rejects.toMatchObject(PERSISTENCE_ERROR);
      expect(existsSync(path)).toBe(false);
      durability.events.length = 0;
      durability.fail = undefined;
      await fixture.createManager().createAccount({ ...pair, displayName: 'Retained account' });
      expect(await fixture.createManager().listAccounts(pair.subscriptionProviderId)).toEqual(
        expect.arrayContaining([
          expect.objectContaining({ ...pair, displayName: 'Retained account' }),
        ])
      );
      expect(lstatSync(path).mode & 0o777).toBe(0o600);
      expect(
        durability.events.some(
          (event) => event.op === 'sync' && event.directory && event.path === parent
        )
      ).toBe(true);
    } finally {
      durability.fail = undefined;
    }
  });
});
