import { existsSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { createOpenKitAccessTokenRecord } from './auth/access-token-store.js';
import { FsStore } from './lib/store.js';
import { feedbackFilePath, readTurnFeedback } from './runtime/feedback.js';
import { raiseRecordedPendingRequest } from './runtime/pending-request-flow.js';
import { createSchedulerAdmissionEntry } from './scheduler-records.js';
import { openCoreDb, openWorkspaceDb } from './storage/db.js';
import { applyMigrations, applyScopedMigrations } from './storage/migrate.js';
import { createApp } from './test-support/app.js';
import { testEntityId } from './test-support/entity-ids.js';
import { recordTestExecutionAttempt } from './test-support/execution-attempt.js';
import { ensureLocalUser } from './test-support/local-user.js';
import { operationRequest } from './test-support/operation-request.js';
import { recordWorkspaceOwnerMembership } from './workspace-membership.js';

const STAMP = '2026-09-14T00:00:00.000Z';
const TOKEN_EXPIRY = '2999-01-01T00:00:00.000Z';

type MemberActor = {
  readonly scope: 'workspace' | 'workspace-readonly' | 'server-admin';
  readonly userId:
    | 'usr_00000000-0000-7000-8000-000000000001'
    | 'usr_00000000-0000-73d4-904a-d4c4b905df7c';
};

const READ_ACTORS: readonly MemberActor[] = [
  { scope: 'workspace-readonly', userId: 'usr_00000000-0000-7000-8000-000000000001' },
  { scope: 'workspace-readonly', userId: 'usr_00000000-0000-73d4-904a-d4c4b905df7c' },
  { scope: 'server-admin', userId: 'usr_00000000-0000-7000-8000-000000000001' },
];

/**
 * Builds the dashboard CoreDb fixture with two active members, including the owner as server-admin.
 *
 * @returns Server-mode app, own/other private Threads, shared Thread, and mutation owners.
 */
function createCoreAudienceFixture() {
  const dataRoot = mkdtempSync(join(tmpdir(), 'openkit-thread-audience-'));
  const coreDb = openCoreDb(dataRoot);
  applyMigrations(coreDb);
  ensureLocalUser(coreDb);
  const store = new FsStore({ dataRoot });
  const workspace = store.createWorkspace('Team');
  recordWorkspaceOwnerMembership({
    coreDb,
    ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
    workspaceId: workspace.id,
  });
  const now = Date.now();
  coreDb.sqlite
    .prepare(
      `INSERT INTO users (id, display_name, email, email_verified, created_at, updated_at, kind, status, disabled_at) VALUES ('usr_00000000-0000-73d4-904a-d4c4b905df7c', 'Other', 'other@example.invalid', false, ?, ?, 'human', 'active', NULL)`
    )
    .run(now, now);
  coreDb.sqlite
    .prepare(
      `INSERT INTO workspace_members (workspace_id, user_id, status, access_level, invitation_id, joined_at, removed_at, revision, created_at, updated_at) VALUES (?, 'usr_00000000-0000-73d4-904a-d4c4b905df7c', 'active', 'editor', NULL, ?, NULL, 1, ?, ?)`
    )
    .run(workspace.id, STAMP, STAMP, STAMP);
  const own = assignAudience(
    store.createThread(workspace.id, 'local-private needle'),
    'private',
    'usr_00000000-0000-7000-8000-000000000001'
  );
  const denied = assignAudience(
    store.createThread(workspace.id, 'other-private needle'),
    'private',
    'usr_00000000-0000-73d4-904a-d4c4b905df7c'
  );
  const shared = assignAudience(store.createThread(workspace.id, 'shared needle'), 'workspace');
  const ownTurn = seedCompletedSurface(store, workspace.id, own, 'local-private');
  const deniedTurn = seedCompletedSurface(store, workspace.id, denied, 'other-private');
  const sharedTurn = seedCompletedSurface(store, workspace.id, shared, 'shared');
  const approvalTurn = store.createTurn(workspace.id, own.id, 'Approve private push', {
    kind: 'user',
    id: 'usr_00000000-0000-7000-8000-000000000001',
  });
  const deniedApprovalTurn = store.createTurn(
    workspace.id,
    denied.id,
    'Approve other private push',
    {
      kind: 'user',
      id: 'usr_00000000-0000-73d4-904a-d4c4b905df7c',
    }
  );
  const workspaceDb = openWorkspaceDb(dataRoot, workspace.id);
  applyScopedMigrations(workspaceDb);
  for (const [turn, requestId, requestItemId] of [
    [approvalTurn, 'ap_local_private', 'it_00000000-0000-7e55-98df-414094b7707e'],
    [deniedApprovalTurn, 'ap_other_private', 'it_00000000-0000-7b56-bcdb-1d8dc2f6af03'],
  ] as const) {
    store.createItem({
      id: requestItemId,
      workspaceId: workspace.id,
      threadId: turn.threadId,
      turnId: turn.id,
      type: 'approval-request',
      status: 'completed',
      approvalRequestId: requestId,
      title: 'Approve a vendor tool call',
      description: 'Allow the captured vendor call.',
      kind: 'permission',
      createdAt: STAMP,
      completedAt: STAMP,
    });
    raiseRecordedPendingRequest(store, workspaceDb.sqlite, {
      requestId,
      workspaceId: workspace.id,
      threadId: turn.threadId,
      raisingTurnId: turn.id,
      requestItemId,
      responsibleUserId: turn.triggerActor.id,
      requesterKind: 'worker',
      agentId: 'agent_fixture',
      kind: 'approval',
      now: STAMP,
      approval: {
        kind: 'permission',
        title: 'Approve a vendor tool call',
        description: 'Allow the captured vendor call.',
      },
      call: {
        serverId: 'vendor',
        toolName: 'publish',
        catalogRevision: 'sha256:fixture',
        schemaSnapshotId: 'snap_fixture',
        canonicalArgumentsJson: '{}',
        argumentsDigest: 'sha256:44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a',
        packageDigest: null,
        policyDecisionId: null,
        authorizationContext: {
          threadId: turn.threadId,
          turnId: turn.id,
          agentSessionId: null,
          agentId: 'agent_fixture',
          responsibleUserId: turn.triggerActor.id,
          packageDigest: null,
          policyDecisionId: null,
        },
      },
    });
  }
  const gate = { approvalId: 'ap_local_private' };
  const deniedGate = { approvalId: 'ap_other_private' };
  workspaceDb.sqlite.close();
  const entry = createSchedulerAdmissionEntry(coreDb, {
    backendId: 'nanohost',
    queueEntryId: `queue_${approvalTurn.id}`,
    requestId: `request_${approvalTurn.id}`,
    workspaceId: workspace.id,
    threadId: own.id,
    turnId: approvalTurn.id,
    turnInput: 'Approve private push',
    requestedAgentId: 'agent_fixture',
    triggerActor: approvalTurn.triggerActor,
    now: () => new Date().toISOString(),
  });
  recordTestExecutionAttempt(coreDb, {
    entry,
    attemptId: testEntityId('attempt', `lease_${approvalTurn.id}`),
    agentSessionId: testEntityId('as', `as_${approvalTurn.id}`),
    inputRef: `pkg_${approvalTurn.id}`,
    bindingRef: `binding_${approvalTurn.id}`,
    sessionCompatibilityKey: 'audience-fixture',
    now: () => new Date().toISOString(),
  });
  const app = createApp({
    auth: {
      api: { getSession: async () => null },
      handler: async () => new Response(null, { status: 404 }),
    },
    coreDb,
    dataRoot,
    mode: 'server',
    store,
  });
  return {
    app,
    approvalTurn,
    close: () => {
      coreDb.sqlite.close();
      rmSync(dataRoot, { force: true, recursive: true });
    },
    coreDb,
    denied,
    deniedApprovalTurn,
    deniedGate,
    deniedTurn,
    gate,
    own,
    ownTurn,
    shared,
    sharedTurn,
    store,
    workspace,
  };
}

type AudienceFixture = ReturnType<typeof createCoreAudienceFixture>;

/**
 * Overwrites durable audience fields the same way the dashboard visibility fixture does.
 *
 * @param thread Thread record already inserted by the store.
 * @param visibility Requested audience.
 * @param privateOwnerUserId Private owner when visibility is private.
 * @returns The mutated Thread record.
 */
function assignAudience(
  thread: ReturnType<FsStore['createThread']>,
  visibility: 'private' | 'workspace',
  privateOwnerUserId?: string
): ReturnType<FsStore['createThread']> {
  const raw = thread as unknown as Record<string, unknown>;
  delete raw.privateOwnerUserId;
  if (visibility === 'private') {
    Object.assign(raw, { privateOwnerUserId, visibility: 'private' });
  } else {
    Object.assign(raw, { visibility: 'workspace' });
  }
  return thread;
}

/**
 * Creates one completed Turn, Item, and retained event stream for HTTP read surfaces.
 *
 * @param store Product store receiving the surface.
 * @param workspaceId Workspace that owns the Thread.
 * @param thread Thread that should receive the completed work.
 * @param label Unique needle used in names and payloads.
 * @returns The completed Turn.
 */
function seedCompletedSurface(
  store: FsStore,
  workspaceId: string,
  thread: ReturnType<FsStore['createThread']>,
  label: string
): ReturnType<FsStore['createTurn']> {
  const turn = store.createTurn(workspaceId, thread.id, `${label} needle`, {
    kind: 'user',
    id: 'usr_00000000-0000-7000-8000-000000000001',
  });
  store.createItem({
    completedAt: STAMP,
    createdAt: STAMP,
    id: testEntityId('it', `it_${label}`),
    status: 'completed',
    text: `${label} needle content`,
    threadId: thread.id,
    turnId: turn.id,
    type: 'assistant-message',
    workspaceId,
  });
  store.emitTurnEvent(turn.id, {
    data: { status: 'running', turnId: turn.id, type: 'turn-started' },
    event: 'turn.started',
    threadId: thread.id,
    turnId: turn.id,
    workspaceId,
  });
  store.emitTurnEvent(turn.id, {
    data: {
      delta: `${label} needle content`,
      deltaKind: 'text-delta',
      itemId: testEntityId('it', `it_${label}`),
      itemType: 'assistant-message',
      type: 'item-delta',
    },
    event: 'item.delta',
    threadId: thread.id,
    turnId: turn.id,
    workspaceId,
  });
  const completed = store.updateTurn(turn.id, { completedAt: STAMP, status: 'completed' });
  store.emitTurnEvent(turn.id, {
    data: { stopReason: 'completed', turn: completed, type: 'turn-completed' },
    event: 'turn.completed',
    threadId: thread.id,
    turnId: turn.id,
    workspaceId,
  });
  return completed;
}

/**
 * Issues a Bearer header for one CoreDb access token.
 *
 * @param coreDb Core database that owns the token record.
 * @param actor Authenticated member actor.
 * @param workspaceId Workspace bound to workspace-scoped tokens.
 * @returns Authorization header map.
 */
function bearer(
  coreDb: ReturnType<typeof openCoreDb>,
  actor: MemberActor,
  workspaceId: string
): { authorization: string } {
  const token = createOpenKitAccessTokenRecord(coreDb, {
    expiresAt: TOKEN_EXPIRY,
    ownerUserId: actor.userId,
    scope: actor.scope,
    workspaceIds: actor.scope === 'server-admin' ? [] : [workspaceId],
  });
  return { authorization: `Bearer ${token.secret}` };
}

/**
 * Resolves the actor's own private Thread and the other member's private Thread.
 *
 * @param fixture Active audience fixture.
 * @param userId Current member.
 * @returns Own and other-private Thread/Turn pair.
 */
function audienceFor(fixture: AudienceFixture, userId: MemberActor['userId']) {
  return userId === 'usr_00000000-0000-7000-8000-000000000001'
    ? {
        denied: fixture.denied,
        deniedTurn: fixture.deniedTurn,
        own: fixture.own,
        ownTurn: fixture.ownTurn,
      }
    : {
        denied: fixture.own,
        deniedTurn: fixture.ownTurn,
        own: fixture.denied,
        ownTurn: fixture.deniedTurn,
      };
}

/**
 * Asserts the central hidden-or-missing Thread guard: 404 `not_found` with no private needles.
 *
 * @param response HTTP response under test.
 * @param secrets Private strings that must stay absent from the error body.
 */
async function expectNondisclosing404(
  response: Response,
  secrets: readonly string[]
): Promise<void> {
  const text = await response.text();
  expect(response.status, text).toBe(404);
  expect(JSON.parse(text)).toMatchObject({ code: 'not_found', message: 'Thread not found.' });
  for (const secret of secrets) {
    expect(text).not.toContain(secret);
  }
}

describe('core Thread audience', () => {
  it('requires CoreDb server auth instead of the local implicit actor', async () => {
    const fixture = createCoreAudienceFixture();
    try {
      const response = await fixture.app.request('/api/app/operations/thread.read', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ workspaceId: fixture.workspace.id, threadId: fixture.own.id }),
      });
      expect(response.status).toBe(401);
    } finally {
      fixture.close();
    }
  });

  it('admits own and shared Thread GET and list while denying the other member private Thread', async () => {
    const fixture = createCoreAudienceFixture();
    try {
      for (const actor of READ_ACTORS) {
        const headers = bearer(fixture.coreDb, actor, fixture.workspace.id);
        const { denied, own } = audienceFor(fixture, actor.userId);
        const ownRes = await fixture.app.request('/api/app/operations/thread.read', {
          ...{ headers },
          method: 'POST',
          headers: { ...headers, ...headers, 'content-type': 'application/json' },
          body: JSON.stringify({ workspaceId: fixture.workspace.id, threadId: own.id }),
        });
        expect(ownRes.status, await ownRes.clone().text()).toBe(200);
        expect(await ownRes.json()).toMatchObject({ id: own.id, name: own.name });
        const sharedRes = await fixture.app.request('/api/app/operations/thread.read', {
          ...{ headers },
          method: 'POST',
          headers: { ...headers, ...headers, 'content-type': 'application/json' },
          body: JSON.stringify({ workspaceId: fixture.workspace.id, threadId: fixture.shared.id }),
        });
        expect(sharedRes.status, await sharedRes.clone().text()).toBe(200);
        expect(await sharedRes.json()).toMatchObject({ id: fixture.shared.id });
        if (actor.scope === 'server-admin') {
          const adminRead = await fixture.app.request('/api/app/operations/thread.read', {
            method: 'POST',
            headers: { ...headers, 'content-type': 'application/json' },
            body: JSON.stringify({ workspaceId: fixture.workspace.id, threadId: denied.id }),
          });
          expect(adminRead.status).toBe(200);
          expect(await adminRead.json()).toMatchObject({ id: denied.id });
        } else
          await expectNondisclosing404(
            await fixture.app.request('/api/app/operations/thread.read', {
              ...{
                headers,
              },
              method: 'POST',
              headers: { ...headers, ...headers, 'content-type': 'application/json' },
              body: JSON.stringify({ workspaceId: fixture.workspace.id, threadId: denied.id }),
            }),
            [denied.name as string]
          );
        const listRes = await fixture.app.request(
          ...operationRequest(
            'thread.list',
            { workspaceId: fixture.workspace.id },
            {
              headers,
            }
          )
        );
        const listText = await listRes.text();
        expect(listRes.status, listText).toBe(200);
        const list = JSON.parse(listText) as { items: Array<{ id: string }> };
        expect(list.items.map((thread) => thread.id).sort()).toEqual(
          [own.id, ...(actor.scope === 'server-admin' ? [denied.id] : []), fixture.shared.id].sort()
        );
        if (actor.scope !== 'server-admin') expect(listText).not.toContain(denied.name);
      }
    } finally {
      fixture.close();
    }
  });

  it('admits own and shared Turn, items, and conversation.targets for current members', async () => {
    const fixture = createCoreAudienceFixture();
    try {
      for (const actor of READ_ACTORS) {
        const headers = bearer(fixture.coreDb, actor, fixture.workspace.id);
        const { own, ownTurn } = audienceFor(fixture, actor.userId);
        const rows = [
          [own, ownTurn],
          [fixture.shared, fixture.sharedTurn],
        ] as const;
        for (const [thread, turn] of rows) {
          const paths = [
            [
              '/api/app/operations/turn.read',
              { workspaceId: fixture.workspace.id, threadId: thread.id, turnId: turn.id },
            ],
            [
              '/api/app/operations/thread.items',
              { workspaceId: fixture.workspace.id, threadId: thread.id },
            ],
            [
              '/api/app/operations/conversation.targets',
              { workspaceId: fixture.workspace.id, threadId: thread.id },
            ],
          ];
          for (const [path, input] of paths as Array<[string, unknown]>) {
            const response = await fixture.app.request(
              path,
              input
                ? {
                    method: 'POST',
                    headers: { ...headers, 'content-type': 'application/json' },
                    body: JSON.stringify(input),
                  }
                : { headers }
            );
            expect(response.status, await response.clone().text()).toBe(200);
          }
        }
      }
    } finally {
      fixture.close();
    }
  });

  it('refuses another member private Turn, items, and conversation.targets without disclosing titles', async () => {
    const fixture = createCoreAudienceFixture();
    try {
      for (const actor of READ_ACTORS) {
        const headers = bearer(fixture.coreDb, actor, fixture.workspace.id);
        const { denied, deniedTurn } = audienceFor(fixture, actor.userId);
        const secrets = [denied.name as string, `${denied.name?.slice(0, -7)} needle content`];
        const paths = [
          [
            '/api/app/operations/turn.read',
            { workspaceId: fixture.workspace.id, threadId: denied.id, turnId: deniedTurn.id },
          ],
          [
            '/api/app/operations/thread.items',
            { workspaceId: fixture.workspace.id, threadId: denied.id },
          ],
          [
            '/api/app/operations/conversation.targets',
            { workspaceId: fixture.workspace.id, threadId: denied.id },
          ],
        ];
        for (const [path, input] of paths as Array<[string, unknown]>) {
          if (actor.scope === 'server-admin' && input) {
            const adminRead = await fixture.app.request(path, {
              method: 'POST',
              headers: { ...headers, 'content-type': 'application/json' },
              body: JSON.stringify(input),
            });
            expect(adminRead.status).toBe(200);
          } else
            await expectNondisclosing404(
              await fixture.app.request(
                path,
                input
                  ? {
                      method: 'POST',
                      headers: { ...headers, 'content-type': 'application/json' },
                      body: JSON.stringify(input),
                    }
                  : { headers }
              ),
              secrets
            );
        }
      }
    } finally {
      fixture.close();
    }
  });

  it('denies ordinary-member turn.start, feedback and approval on private Threads and admits current administrators', async () => {
    const fixture = createCoreAudienceFixture();
    try {
      const member = bearer(
        fixture.coreDb,
        { scope: 'workspace', userId: 'usr_00000000-0000-73d4-904a-d4c4b905df7c' },
        fixture.workspace.id
      );
      const admin = bearer(
        fixture.coreDb,
        { scope: 'server-admin', userId: 'usr_00000000-0000-7000-8000-000000000001' },
        fixture.workspace.id
      );
      const memberTurnsBefore = fixture.store.listThreadTurns(
        fixture.workspace.id,
        fixture.own.id
      ).length;
      const adminTurnsBefore = fixture.store.listThreadTurns(
        fixture.workspace.id,
        fixture.denied.id
      ).length;
      const mutations = [
        {
          after: () =>
            expect(
              fixture.store.listThreadTurns(fixture.workspace.id, fixture.own.id)
            ).toHaveLength(memberTurnsBefore),
          headers: member,
          init: {
            body: JSON.stringify({
              input: 'start-turn-secret',
              requestId: '11111111-1111-4111-8111-111111111202',
              threadId: fixture.own.id,
              workspaceId: fixture.workspace.id,
            }),
            method: 'POST' as const,
          },
          path: '/api/app/operations/turn.start',
          secrets: ['start-turn-secret', 'local-private needle'],
        },
        {
          after: () =>
            expect(
              fixture.store.listThreadTurns(fixture.workspace.id, fixture.denied.id)
            ).toHaveLength(adminTurnsBefore),
          headers: admin,
          init: {
            body: JSON.stringify({
              input: 'start-turn-secret',
              requestId: '11111111-1111-4111-8111-111111111203',
              threadId: fixture.denied.id,
              workspaceId: fixture.workspace.id,
            }),
            method: 'POST' as const,
          },
          path: '/api/app/operations/turn.start',
          secrets: ['start-turn-secret', 'other-private needle'],
        },
        {
          after: () => {
            if (existsSync(feedbackFilePath(fixture.store, fixture.ownTurn))) {
              expect(readTurnFeedback(fixture.store, fixture.ownTurn.id)).toMatchObject({
                note: null,
                rating: null,
              });
            }
          },
          headers: member,
          init: {
            body: JSON.stringify({
              turnId: fixture.ownTurn.id,
              note: 'feedback-secret',
              rating: 'good',
            }),
            method: 'POST' as const,
          },
          path: '/api/app/operations/turn.feedback',
          secrets: ['feedback-secret', 'local-private needle'],
        },
        {
          after: () => {
            if (existsSync(feedbackFilePath(fixture.store, fixture.deniedTurn))) {
              expect(readTurnFeedback(fixture.store, fixture.deniedTurn.id)).toMatchObject({
                note: null,
                rating: null,
              });
            }
          },
          headers: admin,
          init: {
            body: JSON.stringify({
              turnId: fixture.deniedTurn.id,
              note: 'feedback-secret',
              rating: 'good',
            }),
            method: 'POST' as const,
          },
          path: '/api/app/operations/turn.feedback',
          secrets: ['feedback-secret', 'other-private needle'],
        },
        {
          after: () => {
            expect(fixture.store.getApproval(fixture.gate.approvalId).status).toBe('pending');
            expect(fixture.store.getTurnById(fixture.approvalTurn.id).status).toBe('running');
          },
          headers: member,
          init: {
            body: JSON.stringify({
              approvalRequestId: fixture.gate.approvalId,
              decision: 'granted',
              requestId: '11111111-1111-4111-8111-111111111204',
              threadId: fixture.own.id,
              turnId: fixture.approvalTurn.id,
              workspaceId: fixture.workspace.id,
            }),
            method: 'POST' as const,
          },
          path: '/api/app/operations/approval.respond',
          secrets: ['local-private needle', 'Approve private push'],
        },
      ];
      for (const row of mutations) {
        const response = await fixture.app.request(
          ...operationRequest(
            row.path.split('/').at(-1)!,
            {},
            { ...row.init, headers: row.headers }
          )
        );
        if (row.headers === admin) {
          if (row.path.endsWith('turn.start')) {
            expect(response.status).toBe(409);
            expect(await response.json()).toMatchObject({ code: 'thread_busy' });
            row.after();
          } else {
            expect(response.status).toBe(200);
            expect(await response.json()).toMatchObject({
              turnId: fixture.deniedTurn.id,
              rating: 'good',
              note: 'feedback-secret',
            });
            expect(readTurnFeedback(fixture.store, fixture.deniedTurn.id)).toMatchObject({
              rating: 'good',
              note: 'feedback-secret',
            });
          }
        } else {
          await expectNondisclosing404(response, row.secrets);
          row.after();
        }
      }
    } finally {
      fixture.close();
    }
  });

  it('replays own thread.create requestId and does not return another actor private Thread', async () => {
    const fixture = createCoreAudienceFixture();
    try {
      const owner = bearer(
        fixture.coreDb,
        { scope: 'workspace', userId: 'usr_00000000-0000-7000-8000-000000000001' },
        fixture.workspace.id
      );
      const other = bearer(
        fixture.coreDb,
        { scope: 'workspace', userId: 'usr_00000000-0000-73d4-904a-d4c4b905df7c' },
        fixture.workspace.id
      );
      const requestId = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
      const created = await ((input: Record<string, unknown>) =>
        fixture.app.request('/api/app/operations/thread.create', {
          method: 'POST',
          headers: {
            ...{
              ...{ ...owner, 'content-type': 'application/json' },
              'content-type': 'application/json',
            },
            ...(typeof input.requestId === 'string'
              ? { 'x-openkit-request-id': input.requestId }
              : {}),
          },
          body: JSON.stringify(input),
        }))({
        ...{ name: 'Owner private create', requestId, visibility: 'private' },
        workspaceId: fixture.workspace.id,
      });
      expect(created.status, await created.clone().text()).toBe(200);
      const createdThread = (await created.json()) as { id: string; name: string | null };
      const replay = await ((input: Record<string, unknown>) =>
        fixture.app.request('/api/app/operations/thread.create', {
          method: 'POST',
          headers: {
            ...{
              ...{ ...owner, 'content-type': 'application/json' },
              'content-type': 'application/json',
            },
            ...(typeof input.requestId === 'string'
              ? { 'x-openkit-request-id': input.requestId }
              : {}),
          },
          body: JSON.stringify(input),
        }))({
        ...{ name: 'Owner private create', requestId, visibility: 'private' },
        workspaceId: fixture.workspace.id,
      });
      expect([200, 201]).toContain(replay.status);
      expect(await replay.json()).toMatchObject({
        id: createdThread.id,
        name: 'Owner private create',
      });
      const crossed = await ((input: Record<string, unknown>) =>
        fixture.app.request('/api/app/operations/thread.create', {
          method: 'POST',
          headers: {
            ...{
              ...{ ...other, 'content-type': 'application/json' },
              'content-type': 'application/json',
            },
            ...(typeof input.requestId === 'string'
              ? { 'x-openkit-request-id': input.requestId }
              : {}),
          },
          body: JSON.stringify(input),
        }))({
        ...{ name: 'Other create attempt', requestId, visibility: 'private' },
        workspaceId: fixture.workspace.id,
      });
      const crossedText = await crossed.text();
      expect(crossedText).not.toContain(createdThread.id);
      expect(crossedText).not.toContain('Owner private create');
      if (crossed.status < 300) {
        const body = JSON.parse(crossedText) as { id: string; name: string | null };
        expect(body.id).not.toBe(createdThread.id);
        expect(body.name).not.toBe('Owner private create');
      }
    } finally {
      fixture.close();
    }
  });
});
