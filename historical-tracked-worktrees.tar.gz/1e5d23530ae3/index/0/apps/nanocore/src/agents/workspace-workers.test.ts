import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { WorkspaceWorkersResponseSchema } from '@openkit/app-api-schemas';
import {
  type AgentEnvironmentPackage,
  AgentEnvironmentPackageSchema,
} from '@openkit/config-schema';
import { WorkspaceResourcesResponseSchema } from '@openkit/protocol';
import { describe, expect, it, vi } from 'vitest';
import { createOpenKitAccessTokenRecord } from '../auth/access-token-store.js';
import * as usageLedger from '../capability/usage-ledger.js';
import { recordUsage, startCapabilityCall } from '../capability/usage-ledger.js';
import { FsStore } from '../lib/store.js';
import { recordAgentEnvironmentPackageSnapshot } from '../runtime/aep-snapshot-ledger.js';
import { clearWorkerCheckpoint, upsertWorkerCheckpoint } from '../runtime/worker-checkpoints.js';
import { type CoreDb, openCoreDb, openWorkspaceDb, type WorkspaceDb } from '../storage/db.js';
import { applyMigrations, applyScopedMigrations } from '../storage/migrate.js';
import { createTestAgentSetup } from '../test-support/agent-environment.js';
import { createApp } from '../test-support/app.js';
import { createDemoStore } from '../test-support/demo-store.js';
import { ensureLocalUser } from '../test-support/local-user.js';
import { operationRequest } from '../test-support/operation-request.js';
import { resolveAgentEnvironmentPackage } from '../test-support/prepared-agent-environment.js';
import { recordWorkspaceOwnerMembership } from '../workspace-membership.js';

const timestamp = '2026-09-17T02:00:00.000Z';
const digest = `sha256:${'a'.repeat(64)}`;

/**
 * Opens a migrated Core database for current Worker operation tests.
 *
 * @returns Migrated Core database handle.
 */
function createCoreDb(): CoreDb {
  const coreDb = openCoreDb(mkdtempSync(join(tmpdir(), 'openkit-workspace-workers-')));
  applyMigrations(coreDb);
  return coreDb;
}

/**
 * Opens a migrated workspace database for current Worker operation tests.
 *
 * @param coreDb Core database whose data root owns the workspace database.
 * @returns Migrated workspace database handle.
 */
function openTestWorkspaceDb(coreDb: CoreDb): WorkspaceDb {
  const workspaceDb = openWorkspaceDb(coreDb.dataRoot, 'ws_00000000-0000-7000-8000-000000000001');
  applyScopedMigrations(workspaceDb);
  return workspaceDb;
}

/**
 * Authorizes the local actor and returns a NanoCore app for the fixture store.
 *
 * @param coreDb Core database that owns authorization facts.
 * @param store Test store whose Workspaces need canonical owner membership.
 * @param agentId Optional catalog Agent id to project as configured supply.
 * @returns NanoCore test app with local Workspace access.
 */
function createAuthorizedApp(
  coreDb: CoreDb,
  store: FsStore,
  agentId = 'agent_codex_host'
): ReturnType<typeof createApp> {
  ensureLocalUser(coreDb);
  for (const workspace of store.listWorkspaces()) {
    recordWorkspaceOwnerMembership({
      coreDb,
      ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
      workspaceId: workspace.id,
    });
  }
  return createApp({
    agentManifests: [
      createTestAgentSetup({
        agentId,
        displayName: 'Codex',
        logicalModelId: 'openai/gpt-catalog',
      }).manifest,
    ],
    coreDb,
    store,
  });
}

/**
 * Creates one current AgentSession bound to a Thread and Turn.
 *
 * @param store Product store that owns sessions and Turns.
 * @param input Thread, Turn, Agent, and session identity.
 * @returns Created AgentSession.
 */
function createCurrentWorkerSession(
  store: FsStore,
  input: {
    readonly agentId: string;
    readonly sessionId: string;
    readonly status?: 'busy' | 'idle';
    readonly threadId: string;
    readonly turnId: string;
  }
) {
  const turn = store.createTurn(
    'ws_00000000-0000-7000-8000-000000000001',
    input.threadId,
    'Worker turn',
    {
      kind: 'user',
      id: 'usr_00000000-0000-7000-8000-000000000001',
    },
    null,
    { startedAt: timestamp, turnId: input.turnId }
  );
  const session = store.createAgentSession({
    agentId: input.agentId,
    createdAt: timestamp,
    id: input.sessionId,
    message: null,
    status: input.status ?? 'busy',
    threadId: input.threadId,
    updatedAt: timestamp,
    workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
  });
  store.updateTurn(turn.id, { agentId: input.agentId, agentSessionId: session.id });
  return session;
}

/**
 * Records one exact current package snapshot for a Worker session.
 *
 * @param workspaceDb Workspace database that owns the snapshot.
 * @param input Session, Turn, and product-safe package fields.
 * @returns Recorded package snapshot id.
 */
function recordWorkerPackage(
  workspaceDb: WorkspaceDb,
  input: {
    readonly agentId: string;
    readonly displayName: string;
    readonly omitProcess?: boolean;
    readonly preferredLogicalModelId: string;
    readonly sessionId: string;
    readonly threadId: string;
    readonly turnId: string;
  }
): string {
  const setup = createTestAgentSetup({
    agentId: input.agentId,
    displayName: input.displayName,
    logicalModelId: input.preferredLogicalModelId,
  });
  const environmentPackage = AgentEnvironmentPackageSchema.parse({
    ...resolveAgentEnvironmentPackage({
      agent: {
        capabilities: [],
        config: {
          adapterType: 'codex',
          baseUrl: null,
          capabilities: [],
          command: null,
          environment: { OPENAI_API_KEY: 'sk-secret-must-not-leak' },
          workspaceRoot: '/secret/host/path',
        },
        defaultProfileId: 'default',
        health: { checkedAt: null, message: null, status: 'unknown' },
        id: input.agentId,
        kind: 'coder',
        modelId: 'openai/gpt-catalog',
        name: input.displayName,
        profiles: [
          {
            capabilityIds: [],
            displayName: 'Default',
            id: 'default',
            instructionsRef: null,
            modelId: null,
            skillIds: [],
          },
        ],
        sandboxSummary: null,
        skillIds: [],
        status: 'enabled',
      },
      agentSetup: setup,
      agentSessionId: input.sessionId,
      backend: { kind: 'openshell' },
      requestId: `req_${input.turnId}`,
      triggerActor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
      turn: {
        completedAt: null,
        configVersion: null,
        durationMs: null,
        error: null,
        id: input.turnId,
        items: [],
        startedAt: timestamp,
        status: 'running',
        threadId: input.threadId,
        triggerActor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
      },
      turnInput: 'Run the Worker',
      workspaceCwd: '/secret/host/path',
      workspaceRoots: [],
    }),
    supply: {
      mcpServers: [
        {
          allowedTools: ['list_issues'],
          approvalRequiredTools: ['create_issue'],
          catalogDigest: digest,
          deniedTools: ['delete_repo'],
          id: 'github',
          pinnedSchemaSnapshotId: null,
          schemaPolicy: 'pinned',
        },
      ],
      services: [],
      skills: [],
    },
  } satisfies AgentEnvironmentPackage);
  if (input.omitProcess) {
    delete environmentPackage.policy.process;
  }
  recordAgentEnvironmentPackageSnapshot(workspaceDb, {
    createdAt: timestamp,
    environmentPackage,
  });
  return environmentPackage.snapshotId;
}

/**
 * Records one LLM usage row for a Worker session.
 *
 * @param workspaceDb Workspace database that owns the ledger.
 * @param input Session, Turn, and model attribution.
 */
function recordSessionLlmUsage(
  workspaceDb: WorkspaceDb,
  input: {
    readonly agentId: string;
    readonly callId: string;
    readonly family?: 'llm' | 'mcp';
    readonly modelId: string | null;
    readonly recordedAt: string;
    readonly requestId: string;
    readonly sessionId: string;
    readonly threadId: string;
    readonly turnId: string;
    readonly usageId: string;
  }
): void {
  const call = startCapabilityCall({
    agentId: input.agentId,
    agentSessionId: input.sessionId,
    authorityActor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
    callId: input.callId,
    capabilityId: 'llm.responses',
    family: input.family ?? 'llm',
    now: new Date(input.recordedAt),
    operation: 'responses.create',
    redactionClass: 'metadata-only',
    requestId: input.requestId,
    threadId: input.threadId,
    turnId: input.turnId,
    workspaceDb,
    workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
  });
  recordUsage({
    call,
    now: new Date(input.recordedAt),
    records: [
      {
        category: 'llm',
        modelId: input.modelId,
        quantity: 8,
        source: 'provider-reported',
        unit: 'tokens',
        usageId: input.usageId,
      },
    ],
    workspaceDb,
  });
}

describe('worker.list operation', () => {
  it('keeps catalog-only supply and internal-role Turns out of current Worker inventory', async () => {
    const coreDb = createCoreDb();
    const store = createDemoStore({ dataRoot: coreDb.dataRoot });
    const thread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Assistant conversation'
    );
    const turn = store.createTurn('ws_00000000-0000-7000-8000-000000000001', thread.id, 'Hello', {
      kind: 'user',
      id: 'usr_00000000-0000-7000-8000-000000000001',
    });
    store.updateTurn(turn.id, { agentId: 'quick-chat' });
    const app = createAuthorizedApp(coreDb, store);

    try {
      const workersRes = await app.request(
        ...operationRequest(
          'worker.list',
          {},
          {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ workspaceId: 'ws_00000000-0000-7000-8000-000000000001' }),
          }
        )
      );
      const resourcesRes = await app.request('/api/app/operations/workspace.resources', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ workspaceId: 'ws_00000000-0000-7000-8000-000000000001' }),
      });
      const workers = WorkspaceWorkersResponseSchema.parse(await workersRes.json());
      const resources = WorkspaceResourcesResponseSchema.parse(await resourcesRes.json());

      expect(workersRes.status).toBe(200);
      expect(workers).toEqual({
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        items: [],
      });
      expect(resources.agents.map((agent) => agent.id)).toContain('agent_codex_host');
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('keeps a removed-catalog Agent visible and omits terminal predecessors, prelaunch, idle history, and incomplete lineage', async () => {
    let coreDb = createCoreDb();
    let store = createDemoStore({ dataRoot: coreDb.dataRoot });
    const liveThread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Removed catalog Worker ghp_publicFixture'
    );
    const closedThread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Closed predecessor'
    );
    const idleThread = store.createThread('ws_00000000-0000-7000-8000-000000000001', 'Idle Worker');
    const prelaunchThread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Prelaunch Worker'
    );
    const halfNullThread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Half null Worker'
    );
    const liveSession = createCurrentWorkerSession(store, {
      agentId: 'agent_removed_codex',
      sessionId: 'as_00000000-0000-7285-8900-19db303a73c0',
      threadId: liveThread.id,
      turnId: 'tu_00000000-0000-70ac-880b-8087adbcb6c1',
    });
    store.createAgentSession({
      agentId: 'agent_removed_codex',
      createdAt: timestamp,
      id: 'as_00000000-0000-70b4-8d5f-3842173f113d',
      message: null,
      status: 'closed',
      threadId: closedThread.id,
      updatedAt: timestamp,
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
    });
    const idleSession = createCurrentWorkerSession(store, {
      agentId: 'agent_removed_codex',
      sessionId: 'as_00000000-0000-780a-a435-d0f1f7a9c9b2',
      status: 'idle',
      threadId: idleThread.id,
      turnId: 'tu_00000000-0000-7e72-a456-0270c65934a6',
    });
    const prelaunchSession = createCurrentWorkerSession(store, {
      agentId: 'agent_removed_codex',
      sessionId: 'as_00000000-0000-70f1-aa0b-7c49c5a815d5',
      threadId: prelaunchThread.id,
      turnId: 'tu_00000000-0000-7a5b-bdc1-1800ee3a79ba',
    });
    const halfNullSession = createCurrentWorkerSession(store, {
      agentId: 'agent_removed_codex',
      sessionId: 'as_00000000-0000-7176-8240-cb8e2db56a9b',
      threadId: halfNullThread.id,
      turnId: 'tu_00000000-0000-7420-9535-a55451a2a2f3',
    });
    const workspaceDb = openTestWorkspaceDb(coreDb);
    try {
      const snapshotId = recordWorkerPackage(workspaceDb, {
        agentId: 'agent_removed_codex',
        displayName: 'Retired Codex',
        omitProcess: true,
        preferredLogicalModelId: 'openai/gpt-preferred',
        sessionId: liveSession.id,
        threadId: liveThread.id,
        turnId: 'tu_00000000-0000-70ac-880b-8087adbcb6c1',
      });
      store.updateAgentSession(liveSession.id, { environmentPackageSnapshotId: snapshotId });
      upsertWorkerCheckpoint(workspaceDb, {
        goalId: 'goal_removed',
        iteration: 1,
        now: () => timestamp,
        requestId: '00000000-0000-4000-8000-000000000304',
        requestInputHash: digest,
        stage: 'running_worker',
        taskId: 'task_removed',
        threadId: liveThread.id,
        turnId: 'tu_00000000-0000-70ac-880b-8087adbcb6c1',
        workerSessionId: liveSession.id,
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
      });
      upsertWorkerCheckpoint(workspaceDb, {
        goalId: 'goal_prelaunch',
        iteration: 1,
        now: () => timestamp,
        requestId: '00000000-0000-4000-8000-000000000305',
        requestInputHash: digest,
        stage: 'preparing',
        taskId: 'task_prelaunch',
        threadId: prelaunchThread.id,
        turnId: 'tu_00000000-0000-7a5b-bdc1-1800ee3a79ba',
        workerSessionId: null,
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
      });
      upsertWorkerCheckpoint(workspaceDb, {
        goalId: 'goal_half',
        iteration: 1,
        now: () => timestamp,
        requestId: '00000000-0000-4000-8000-000000000306',
        requestInputHash: digest,
        stage: 'running_worker',
        taskId: null,
        threadId: halfNullThread.id,
        turnId: 'tu_00000000-0000-7420-9535-a55451a2a2f3',
        workerSessionId: halfNullSession.id,
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
      });
    } finally {
      workspaceDb.sqlite.close();
    }
    ensureLocalUser(coreDb);
    recordWorkspaceOwnerMembership({
      coreDb,
      ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
    });
    coreDb.sqlite.close();
    coreDb = openCoreDb(coreDb.dataRoot);
    store = new FsStore({ dataRoot: coreDb.dataRoot });
    const app = createApp({
      agentManifests: [
        createTestAgentSetup({
          agentId: 'agent_other_supply',
          displayName: 'Other Supply',
        }).manifest,
      ],
      coreDb,
      store,
    });

    try {
      const response = await app.request(
        ...operationRequest(
          'worker.list',
          {},
          {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ workspaceId: 'ws_00000000-0000-7000-8000-000000000001' }),
          }
        )
      );
      const body = WorkspaceWorkersResponseSchema.parse(await response.json());
      const byThread = Object.fromEntries(body.items.map((item) => [item.threadId, item]));

      expect(response.status).toBe(200);
      expect(store.getThread('ws_00000000-0000-7000-8000-000000000001', liveThread.id).name).toBe(
        'Removed catalog Worker ghp_publicFixture'
      );
      expect(byThread[liveThread.id]).toMatchObject({
        agentId: 'agent_removed_codex',
        agentName: 'Retired Codex',
        threadTitle: 'Removed catalog Worker ghp_publicFixture',
        work: {
          goalId: 'goal_removed',
          kind: 'goal',
          taskId: 'task_removed',
          turnId: 'tu_00000000-0000-70ac-880b-8087adbcb6c1',
        },
      });
      expect(byThread[closedThread.id]).toBeUndefined();
      expect(byThread[liveThread.id]?.packageDetails).toMatchObject({
        kind: 'available',
        process: null,
      });
      expect(byThread[idleThread.id]?.work).toEqual({ kind: 'none' });
      expect(byThread[prelaunchThread.id]?.work).toEqual({ kind: 'none' });
      expect(byThread[halfNullThread.id]?.work).toEqual({ kind: 'unavailable' });
      expect(idleSession.id).toBe('as_00000000-0000-780a-a435-d0f1f7a9c9b2');
      expect(prelaunchSession.id).toBe('as_00000000-0000-70f1-aa0b-7c49c5a815d5');
    } finally {
      coreDb.sqlite.close();
    }
  });

  it('reports missing Turns and conflicting checkpoint session lineage as unavailable', async () => {
    const coreDb = createCoreDb();
    const store = createDemoStore({ dataRoot: coreDb.dataRoot });
    const thread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Incomplete worker'
    );
    const session = createCurrentWorkerSession(store, {
      agentId: 'agent_codex_host',
      sessionId: 'as_00000000-0000-70c0-addb-3f25fbfb971f',
      threadId: thread.id,
      turnId: 'tu_00000000-0000-7ac3-97b3-02904dd64098',
    });
    const app = createAuthorizedApp(coreDb, store);
    const workspaceDb = openTestWorkspaceDb(coreDb);
    try {
      for (const [turnId, workerSessionId] of [
        ['tu_00000000-0000-76d4-be96-fe2dccab50f4', session.id],
        ['tu_00000000-0000-7ac3-97b3-02904dd64098', 'as_00000000-0000-7436-9246-ac6dd3ca3fe4'],
      ]) {
        upsertWorkerCheckpoint(workspaceDb, {
          workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
          threadId: thread.id,
          turnId: turnId!,
          workerSessionId: workerSessionId!,
          goalId: null,
          taskId: null,
          iteration: 1,
          stage: 'running_worker',
          requestId: '00000000-0000-4000-8000-000000000398',
          requestInputHash: digest,
        });
        const response = await app.request(
          ...operationRequest(
            'worker.list',
            {},
            {
              method: 'POST',
              headers: { 'content-type': 'application/json' },
              body: JSON.stringify({ workspaceId: 'ws_00000000-0000-7000-8000-000000000001' }),
            }
          )
        );
        expect(response.status).toBe(200);
        const body = WorkspaceWorkersResponseSchema.parse(await response.json());
        expect(body.items.find((item) => item.threadId === thread.id)?.work).toEqual({
          kind: 'unavailable',
        });
        clearWorkerCheckpoint(
          workspaceDb,
          'ws_00000000-0000-7000-8000-000000000001',
          thread.id,
          turnId!
        );
      }
    } finally {
      workspaceDb.sqlite.close();
      coreDb.sqlite.close();
    }
  });

  it('labels package preference and last-used model separately and restricts usage without audit.read', async () => {
    const coreDb = createCoreDb();
    const store = createDemoStore({ dataRoot: coreDb.dataRoot });
    const thread = store.createThread('ws_00000000-0000-7000-8000-000000000001', 'Model Worker');
    const predecessorThread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Predecessor Worker'
    );
    const session = createCurrentWorkerSession(store, {
      agentId: 'agent_codex_host',
      sessionId: 'as_00000000-0000-7c5d-93c5-ea2808ca86f7',
      status: 'idle',
      threadId: thread.id,
      turnId: 'tu_00000000-0000-7b64-ab5a-4855db181097',
    });
    store.createAgentSession({
      agentId: 'agent_codex_host',
      createdAt: timestamp,
      id: 'as_00000000-0000-7709-bb38-c94cb60bb065',
      message: null,
      status: 'closed',
      threadId: predecessorThread.id,
      updatedAt: timestamp,
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
    });
    const predecessorTurn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      predecessorThread.id,
      'Predecessor turn',
      { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
      null,
      { startedAt: timestamp, turnId: 'tu_00000000-0000-74fc-b0da-01927fa8e961' }
    );
    store.updateTurn(predecessorTurn.id, {
      agentId: 'agent_codex_host',
      agentSessionId: 'as_00000000-0000-7709-bb38-c94cb60bb065',
    });
    const workspaceDb = openTestWorkspaceDb(coreDb);
    try {
      const snapshotId = recordWorkerPackage(workspaceDb, {
        agentId: 'agent_codex_host',
        displayName: 'Codex',
        preferredLogicalModelId: 'openai/gpt-preferred',
        sessionId: session.id,
        threadId: thread.id,
        turnId: 'tu_00000000-0000-7b64-ab5a-4855db181097',
      });
      store.updateAgentSession(session.id, { environmentPackageSnapshotId: snapshotId });
      recordSessionLlmUsage(workspaceDb, {
        agentId: 'agent_codex_host',
        callId: 'cap_00000000-0000-7682-9329-8d28c3eddeef',
        modelId: 'openai/gpt-last-used',
        recordedAt: '2026-09-17T02:01:00.000Z',
        requestId: '00000000-0000-4000-8000-000000000201',
        sessionId: session.id,
        threadId: thread.id,
        turnId: 'tu_00000000-0000-7b64-ab5a-4855db181097',
        usageId: 'use_00000000-0000-720e-a059-ea2496d083a3',
      });
      recordSessionLlmUsage(workspaceDb, {
        agentId: 'agent_codex_host',
        callId: 'cap_00000000-0000-70c7-8f0b-db044f2644fa',
        modelId: 'openai/gpt-predecessor',
        recordedAt: '2026-09-17T02:02:00.000Z',
        requestId: '00000000-0000-4000-8000-000000000202',
        sessionId: 'as_00000000-0000-7709-bb38-c94cb60bb065',
        threadId: predecessorThread.id,
        turnId: 'tu_00000000-0000-74fc-b0da-01927fa8e961',
        usageId: 'use_00000000-0000-7dc9-9cba-0a11208bcfd3',
      });
    } finally {
      workspaceDb.sqlite.close();
    }
    const ownerApp = createAuthorizedApp(coreDb, store);
    const now = Date.now();
    coreDb.sqlite
      .prepare(
        `INSERT INTO users
          (id, display_name, email, email_verified, created_at, updated_at, kind)
         VALUES ('usr_00000000-0000-7b43-8df8-fd24a5ccdbe8', 'Viewer', 'viewer-workers@example.com', false, ?, ?, 'human')`
      )
      .run(now, now);
    coreDb.sqlite
      .prepare(
        `INSERT INTO workspace_members (
          workspace_id, user_id, status, access_level, invitation_id,
          joined_at, removed_at, revision, created_at, updated_at
        ) VALUES ('ws_00000000-0000-7000-8000-000000000001', 'usr_00000000-0000-7b43-8df8-fd24a5ccdbe8', 'active', 'viewer', NULL, ?, NULL, 1, ?, ?)`
      )
      .run(new Date(now).toISOString(), new Date(now).toISOString(), new Date(now).toISOString());
    const viewerToken = createOpenKitAccessTokenRecord(coreDb, {
      expiresAt: '2999-01-01T00:00:00.000Z',
      ownerUserId: 'usr_00000000-0000-7b43-8df8-fd24a5ccdbe8',
      scope: 'workspace-readonly',
      workspaceIds: ['ws_00000000-0000-7000-8000-000000000001'],
    });
    const viewerApp = createApp({
      agentManifests: [
        createTestAgentSetup({
          agentId: 'agent_codex_host',
          displayName: 'Codex',
        }).manifest,
      ],
      auth: {
        api: { getSession: async () => null },
        handler: async () => new Response(null, { status: 404 }),
      },
      coreDb,
      dataRoot: coreDb.dataRoot,
      mode: 'server',
      store,
    });
    const usageSpy = vi.spyOn(usageLedger, 'readLatestCurrentAgentSessionLlmUsage');

    try {
      const ownerRes = await ownerApp.request(
        ...operationRequest(
          'worker.list',
          {},
          {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ workspaceId: 'ws_00000000-0000-7000-8000-000000000001' }),
          }
        )
      );
      const ownerBody = WorkspaceWorkersResponseSchema.parse(await ownerRes.json());
      const ownerWorker = ownerBody.items.find((item) => item.threadId === thread.id);
      const publicJson = JSON.stringify(ownerBody);
      usageSpy.mockClear();
      const viewerRes = await viewerApp.request(
        ...operationRequest(
          'worker.list',
          {},
          {
            method: 'POST',
            headers: {
              ...{ authorization: `Bearer ${viewerToken.secret}` },
              'content-type': 'application/json',
            },
            body: JSON.stringify({ workspaceId: 'ws_00000000-0000-7000-8000-000000000001' }),
          }
        )
      );
      const viewerBody = WorkspaceWorkersResponseSchema.parse(await viewerRes.json());
      const viewerWorker = viewerBody.items.find((item) => item.threadId === thread.id);

      expect(ownerRes.status).toBe(200);
      expect(ownerWorker?.packageDetails).toMatchObject({
        kind: 'available',
        preferredLogicalModelId: 'openai/gpt-preferred',
        mcpServers: [
          {
            allowedTools: ['list_issues'],
            approvalRequiredTools: ['create_issue'],
            deniedTools: ['delete_repo'],
            id: 'github',
          },
        ],
        filesystem: { default: 'deny', enforcement: 'openshell' },
        network: { default: 'deny', enforcement: 'openshell' },
        process: { default: 'allow', enforcement: 'openshell', ruleCount: 0 },
      });
      expect(ownerWorker?.lastUsedModel).toEqual({
        kind: 'available',
        modelId: 'openai/gpt-last-used',
        recordedAt: '2026-09-17T02:01:00.000Z',
      });
      expect(publicJson).not.toContain('openai/gpt-catalog');
      expect(publicJson).not.toContain('openai/gpt-predecessor');
      expect(publicJson).not.toContain('sk-secret-must-not-leak');
      expect(publicJson).not.toContain('/secret/host/path');
      expect(publicJson).not.toContain('catalogDigest');
      expect(publicJson).not.toContain('schemaPolicy');
      expect(viewerRes.status).toBe(200);
      expect(viewerWorker?.lastUsedModel).toEqual({ kind: 'restricted' });
      expect(usageSpy).not.toHaveBeenCalled();
    } finally {
      usageSpy.mockRestore();
      coreDb.sqlite.close();
    }
  });
});

it('admits current administrators to foreign private Threads under the accepted rule with HTTP and MCP Worker field parity', async () => {
  const coreDb = createCoreDb();
  const store = createDemoStore({ dataRoot: coreDb.dataRoot });
  const foreign = store.createThread(
    'ws_00000000-0000-7000-8000-000000000001',
    'Foreign private Worker',
    undefined,
    'conversation',
    { visibility: 'private', privateOwnerUserId: 'usr_00000000-0000-7ed5-9b62-226e0a66887f' }
  );
  createCurrentWorkerSession(store, {
    agentId: 'agent_codex_host',
    sessionId: 'as_00000000-0000-7a52-acda-ab0e51b27751',
    threadId: foreign.id,
    turnId: 'tu_00000000-0000-75a4-a0e0-d617a6fe00cb',
  });
  ensureLocalUser(coreDb);
  recordWorkspaceOwnerMembership({
    coreDb,
    ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
    workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
  });
  const app = createApp({
    coreDb,
    dataRoot: coreDb.dataRoot,
    store,
    mode: 'server',
    auth: {
      api: { getSession: async () => null },
      handler: async () => new Response(null, { status: 404 }),
    },
    agentManifests: [createTestAgentSetup().manifest],
  });
  const admin = createOpenKitAccessTokenRecord(coreDb, {
    ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
    scope: 'server-admin',
    workspaceIds: [],
    expiresAt: '2999-01-01T00:00:00.000Z',
  });
  const member = createOpenKitAccessTokenRecord(coreDb, {
    ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
    scope: 'workspace',
    workspaceIds: ['ws_00000000-0000-7000-8000-000000000001'],
    expiresAt: '2999-01-01T00:00:00.000Z',
  });
  try {
    const http = async (secret: string) =>
      app.request(
        ...operationRequest(
          'worker.list',
          {},
          {
            headers: { authorization: `Bearer ${secret}` },
            body: JSON.stringify({ workspaceId: 'ws_00000000-0000-7000-8000-000000000001' }),
          }
        )
      );
    const hidden = await http(member.secret);
    expect(hidden.status).toBe(200);
    expect(await hidden.json()).toEqual({
      items: [],
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
    });
    const visible = await http(admin.secret);
    expect(visible.status).toBe(200);
    const expected = WorkspaceWorkersResponseSchema.parse(await visible.json());
    expect(expected.items).toEqual([
      expect.objectContaining({
        threadId: foreign.id,
        threadTitle: 'Foreign private Worker',
        agentId: 'agent_codex_host',
        packageDetails: { kind: 'unavailable' },
        lastUsedModel: { kind: 'unavailable' },
        work: { kind: 'none' },
      }),
    ]);
    const remote = await app.request('/mcp', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        accept: 'application/json, text/event-stream',
        authorization: `Bearer ${admin.secret}`,
      },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: 1,
        method: 'tools/call',
        params: {
          name: 'call',
          arguments: {
            operation: 'worker.list',
            input: { workspaceId: 'ws_00000000-0000-7000-8000-000000000001' },
          },
        },
      }),
    });
    expect(remote.status).toBe(200);
    const body = await remote.json();
    expect(body.error).toBeUndefined();
    expect(body.result.isError).not.toBe(true);
    expect(JSON.parse(body.result.content[0].text)).toEqual(expected);
  } finally {
    coreDb.sqlite.close();
  }
});
