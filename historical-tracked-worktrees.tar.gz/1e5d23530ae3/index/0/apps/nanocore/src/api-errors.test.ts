import { Hono } from 'hono';
import { expect, it, vi } from 'vitest';
import { z } from 'zod';
import { asCommandError, asInvalidRequestError, publishedErrorMessage } from './api-errors.js';
import type { AuthVariables } from './auth/middleware.js';
import { StoreRecordNotFoundError } from './lib/store.js';
import { registerOperationJsonRoutes } from './operation-json-routes.js';
import { createAppWithWorkspaceAuthority } from './test-support/app.js';
import { createDemoStore } from './test-support/demo-store.js';
import { operationRequest } from './test-support/operation-request.js';

it.each([
  'string',
  'error',
] as const)('preserves %s validation messages in a JSON 400', async (kind) => {
  const message = 'Invalid MCP binding request.';
  const response = asInvalidRequestError(kind === 'string' ? message : new Error(message));
  expect(response.status).toBe(400);
  expect(response.headers.get('content-type')).toContain('application/json');
  expect(await response.json()).toMatchObject({ code: 'invalid_request', message });
});

it('walks cyclic causes and aggregate entries before reading the baked message', () => {
  const parser = new SyntaxError('ROW_SECRET_X9');
  const aggregate = new AggregateError([], 'Baked private message');
  aggregate.errors.push(aggregate, { cause: new Error('wrapper', { cause: parser }) });
  Object.defineProperty(aggregate, 'message', {
    get: () => {
      throw new Error('Must not read the aggregate message.');
    },
  });
  expect(publishedErrorMessage(aggregate)).toBe('The record could not be processed.');
  const authored = new Error('Authored cyclic failure.');
  Object.defineProperty(authored, 'cause', { value: authored });
  expect(publishedErrorMessage(authored)).toBe(authored.message);
});

it('keeps each caller fallback for non-Error values', () => {
  expect(publishedErrorMessage('backend failed', 'The governed worker turn failed.')).toBe(
    'The governed worker turn failed.'
  );
  expect(publishedErrorMessage(null, 'null')).toBe('null');
  expect(publishedErrorMessage({ cause: new SyntaxError('ROW_SECRET_X9') }, 'unknown')).toBe(
    'The record could not be processed.'
  );
});

it('preserves authored errors and route-specific code and status', async () => {
  const error = new StoreRecordNotFoundError(
    'Workspace not found: ws_00000000-0000-7000-8000-000000000001'
  );
  const command = asCommandError(error, 'command_missing', 409);
  expect(command.status).toBe(409);
  expect(await command.json()).toMatchObject({ code: 'command_missing', message: error.message });
  const store = createDemoStore();
  const app = createAppWithWorkspaceAuthority({ store });
  vi.spyOn(store, 'listThreads').mockImplementation(() => {
    throw error;
  });
  const response = await app.request(
    ...operationRequest('thread.list', { workspaceId: 'ws_00000000-0000-7000-8000-000000000001' })
  );
  expect(response.status).toBe(404);
  expect(await response.json()).toMatchObject({ code: 'not_found', message: error.message });
});

it.each([
  'syntax',
  'schema',
  'cause',
  'aggregate',
  'nested',
] as const)('bounds the %s quoting error tree at command publication', async (variant) => {
  const marker = 'ROW_SECRET_X9';
  const parsed = z
    .object({ id: z.string() })
    .strict()
    .safeParse({ id: 'demo', [marker]: true });
  if (parsed.success) throw new Error('Expected invalid retained record.');
  const syntax = new SyntaxError(marker);
  const error =
    variant === 'syntax'
      ? syntax
      : variant === 'schema'
        ? parsed.error
        : variant === 'cause'
          ? new Error('Already authored', { cause: syntax })
          : variant === 'aggregate'
            ? new AggregateError([parsed.error], `Baked ${marker}`)
            : new AggregateError(
                [new Error('wrapped', { cause: new AggregateError([syntax], marker) })],
                marker
              );
  const response = asCommandError(error, 'reader_failed', 500);
  expect(response.status).toBe(500);
  const body = await response.json();
  expect(body).toMatchObject({
    code: 'reader_failed',
    message: 'The record could not be processed.',
  });
  expect(JSON.stringify(body)).not.toContain(marker);
});

it('preserves safe declared-field validation detail before entering the real operation', async () => {
  const app = new Hono<{ Variables: AuthVariables }>();
  registerOperationJsonRoutes({
    app,
    inflightCommands: new WeakMap(),
    requestStore: () => {
      throw new Error('Must not enter operation.');
    },
  });
  const response = await ((input: Record<string, unknown>) =>
    app.request('/api/app/operations/thread.create', {
      method: 'POST',
      headers: {
        ...{ ...{ 'content-type': 'application/json' }, 'content-type': 'application/json' },
        ...(typeof input.requestId === 'string' ? { 'x-openkit-request-id': input.requestId } : {}),
      },
      body: JSON.stringify(input),
    }))({ ...{ name: 42 }, workspaceId: 'ws_00000000-0000-7000-8000-000000000001' });
  expect(response.status).toBe(400);
  const body = await response.json();
  expect(body.code).toBe('invalid_request');
  expect(body.message).toBe('Invalid operation input.');
  expect(body.details).toEqual({ fields: ['requestId', 'name'] });
  const parsed = z.object({ name: z.string() }).safeParse({ name: 42 });
  if (parsed.success) throw new Error('Expected invalid request.');
  expect(await asInvalidRequestError(parsed.error).json()).toMatchObject({
    message: z.prettifyError(parsed.error),
  });
});
