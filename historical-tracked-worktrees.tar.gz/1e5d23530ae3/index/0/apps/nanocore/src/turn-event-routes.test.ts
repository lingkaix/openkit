import { ApiErrorSchema, SseEventEnvelopeSchema } from '@openkit/protocol';
import { describe, expect, it, vi } from 'vitest';
import type { FsStore } from './lib/store.js';
import { createApp } from './test-support/app.js';
import { createDemoStore } from './test-support/demo-store.js';
import { testEntityId } from './test-support/entity-ids.js';

/**
 * Parses a complete SSE response body into JSON event payloads.
 *
 * @param text Raw SSE body text.
 * @returns Parsed event payloads in stream order.
 * @throws Error when an SSE event chunk does not contain a data line.
 */
function parseSseEvents(text: string): unknown[] {
  return text
    .split('\n\n')
    .filter((chunk) => chunk.trim().length > 0)
    .map((chunk) => {
      const dataLine = chunk.split('\n').find((line) => line.startsWith('data: '));

      if (!dataLine) {
        throw new Error(`Missing SSE data line: ${chunk}`);
      }

      return JSON.parse(dataLine.slice('data: '.length)) as unknown;
    });
}

/**
 * Creates a completed turn with retained replay events.
 *
 * @param store Store that should receive the replay fixture records.
 * @param workspaceId Workspace that should own the replay fixture.
 * @returns Identifiers needed to open the turn event stream.
 */
function createReplayTurn(
  store: FsStore,
  workspaceId = 'ws_00000000-0000-7000-8000-000000000001'
): {
  workspaceId: string;
  threadId: string;
  turnId: string;
} {
  const thread = store.createThread(workspaceId, 'Replay thread');
  const turn = store.createTurn(workspaceId, thread.id, 'Replay this stream', {
    kind: 'user',
    id: 'usr_00000000-0000-7000-8000-000000000001',
  });
  const assistantItem = store.createItem({
    id: testEntityId('it', `it_assistant_${turn.id}`),
    workspaceId,
    threadId: thread.id,
    turnId: turn.id,
    type: 'assistant-message',
    status: 'in_progress',
    text: '',
    createdAt: turn.startedAt ?? new Date().toISOString(),
    completedAt: null,
  });

  store.emitTurnEvent(turn.id, {
    event: 'turn.started',
    workspaceId,
    threadId: thread.id,
    turnId: turn.id,
    data: { type: 'turn-started', turnId: turn.id, status: 'running' },
  });
  store.emitTurnEvent(turn.id, {
    event: 'item.delta',
    workspaceId,
    threadId: thread.id,
    turnId: turn.id,
    data: {
      type: 'item-delta',
      itemId: assistantItem.id,
      itemType: 'assistant-message',
      deltaKind: 'text-delta',
      delta: 'First replay delta.',
    },
  });
  store.emitTurnEvent(turn.id, {
    event: 'item.delta',
    workspaceId,
    threadId: thread.id,
    turnId: turn.id,
    data: {
      type: 'item-delta',
      itemId: assistantItem.id,
      itemType: 'assistant-message',
      deltaKind: 'text-delta',
      delta: 'Second replay delta.',
    },
  });
  const completedTurn = store.updateTurn(turn.id, {
    status: 'completed',
    completedAt: turn.startedAt,
  });
  store.emitTurnEvent(turn.id, {
    event: 'turn.completed',
    workspaceId,
    threadId: thread.id,
    turnId: turn.id,
    data: { type: 'turn-completed', stopReason: 'completed', turn: completedTurn },
  });

  return { workspaceId, threadId: thread.id, turnId: turn.id };
}

describe('turn event routes', () => {
  it('replays turn events after the since cursor without duplicates', async () => {
    const store = createDemoStore();
    const app = createApp({ store });
    const { workspaceId, threadId, turnId } = createReplayTurn(store);

    const coldRes = await app.request(
      `/api/workspaces/${workspaceId}/threads/${threadId}/events?turnId=${turnId}&since=0`
    );
    const coldEvents = parseSseEvents(await coldRes.text()).map((event) =>
      SseEventEnvelopeSchema.parse(event)
    );
    const lastSeen = coldEvents.at(1)?.sequence;

    expect(coldRes.status).toBe(200);
    expect(coldEvents.map((event) => event.sequence)).toEqual([1, 2, 3, 4]);
    expect(lastSeen).toBe(2);

    const replayRes = await app.request(
      `/api/workspaces/${workspaceId}/threads/${threadId}/events?turnId=${turnId}&since=${lastSeen}`
    );
    const replayEvents = parseSseEvents(await replayRes.text()).map((event) =>
      SseEventEnvelopeSchema.parse(event)
    );

    expect(replayRes.status).toBe(200);
    expect(replayEvents.map((event) => event.sequence)).toEqual([3, 4]);
  });

  it('returns no content when the since cursor is already terminal', async () => {
    const store = createDemoStore();
    const app = createApp({ store });
    const { workspaceId, threadId, turnId } = createReplayTurn(store);
    const terminalSequence = store
      .getTurnEvents(turnId)
      .find((event) => event.event === 'turn.completed')?.sequence;

    const res = await app.request(
      `/api/workspaces/${workspaceId}/threads/${threadId}/events?turnId=${turnId}&since=${terminalSequence}`
    );
    const text = await res.text();

    expect(res.status).toBe(204);
    expect(text).toBe('');
  });

  it('keeps non-terminal empty replays open instead of returning no content', async () => {
    const store = createDemoStore();
    const unsubscribe = vi.fn();

    vi.spyOn(store, 'addTurnListener').mockReturnValue(unsubscribe);

    const app = createApp({ store });
    const workspaceId = 'ws_00000000-0000-7000-8000-000000000001';
    const thread = store.createThread(workspaceId, 'Open replay thread');
    const turn = store.createTurn(workspaceId, thread.id, 'Keep streaming', {
      kind: 'user',
      id: 'usr_00000000-0000-7000-8000-000000000001',
    });

    store.emitTurnEvent(turn.id, {
      event: 'turn.started',
      workspaceId,
      threadId: thread.id,
      turnId: turn.id,
      data: { type: 'turn-started', turnId: turn.id, status: 'running' },
    });

    const res = await app.request(
      `/api/workspaces/${workspaceId}/threads/${thread.id}/events?turnId=${turn.id}&since=1`
    );

    expect(res.status).toBe(200);
    await res.body?.cancel();
    await vi.waitFor(() => expect(unsubscribe).toHaveBeenCalledTimes(1));
  });

  it('preserves events emitted while retained events are being replayed', async () => {
    const store = createDemoStore();
    const workspaceId = 'ws_00000000-0000-7000-8000-000000000001';
    const thread = store.createThread(workspaceId, 'Replay race thread');
    const turn = store.createTurn(workspaceId, thread.id, 'Preserve replay ordering', {
      kind: 'user',
      id: 'usr_00000000-0000-7000-8000-000000000001',
    });
    const assistantItem = store.createItem({
      id: testEntityId('it', `it_assistant_${turn.id}`),
      workspaceId,
      threadId: thread.id,
      turnId: turn.id,
      type: 'assistant-message',
      status: 'in_progress',
      text: '',
      createdAt: turn.startedAt ?? new Date().toISOString(),
      completedAt: null,
    });

    store.emitTurnEvent(turn.id, {
      event: 'turn.started',
      workspaceId,
      threadId: thread.id,
      turnId: turn.id,
      data: { type: 'turn-started', turnId: turn.id, status: 'running' },
    });
    store.emitTurnEvent(turn.id, {
      event: 'item.delta',
      workspaceId,
      threadId: thread.id,
      turnId: turn.id,
      data: {
        type: 'item-delta',
        itemId: assistantItem.id,
        itemType: 'assistant-message',
        deltaKind: 'text-delta',
        delta: 'Retained replay delta.',
      },
    });

    const listenerSpy = vi.spyOn(store, 'addTurnListener');
    const app = createApp({ store });
    const res = await app.request(
      `/api/workspaces/${workspaceId}/threads/${thread.id}/events?turnId=${turn.id}&since=0`
    );

    store.emitTurnEvent(turn.id, {
      event: 'item.delta',
      workspaceId,
      threadId: thread.id,
      turnId: turn.id,
      data: {
        type: 'item-delta',
        itemId: assistantItem.id,
        itemType: 'assistant-message',
        deltaKind: 'text-delta',
        delta: 'Gap replay delta.',
      },
    });

    const bodyPromise = res.text();

    await vi.waitFor(() => expect(listenerSpy).toHaveBeenCalledTimes(1));

    const completedTurn = store.updateTurn(turn.id, {
      status: 'completed',
      completedAt: turn.startedAt,
    });

    store.emitTurnEvent(turn.id, {
      event: 'turn.completed',
      workspaceId,
      threadId: thread.id,
      turnId: turn.id,
      data: { type: 'turn-completed', stopReason: 'completed', turn: completedTurn },
    });

    const events = parseSseEvents(await bodyPromise).map((event) =>
      SseEventEnvelopeSchema.parse(event)
    );

    expect(res.status).toBe(200);
    expect(events.map((event) => event.sequence)).toEqual([1, 2, 3, 4]);
  });

  it('returns cursor_expired when since is older than the retained event window', async () => {
    const store = createDemoStore();
    const app = createApp({ store });
    const thread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Overflow replay thread'
    );
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Fill the retained window',
      {
        kind: 'user',
        id: 'usr_00000000-0000-7000-8000-000000000001',
      }
    );
    const workspaceId = 'ws_00000000-0000-7000-8000-000000000001';
    const threadId = thread.id;
    const turnId = turn.id;
    store.createItem({
      id: testEntityId('it', `it_assistant_${turnId}`),
      workspaceId,
      threadId,
      turnId,
      type: 'assistant-message',
      status: 'in_progress',
      text: '',
      createdAt: turn.startedAt ?? new Date().toISOString(),
      completedAt: null,
    });

    for (let index = 0; index < 105; index += 1) {
      store.emitTurnEvent(turnId, {
        event: 'item.delta',
        workspaceId,
        threadId,
        turnId,
        data: {
          type: 'item-delta',
          itemId: testEntityId('it', `it_assistant_${turnId}`),
          itemType: 'assistant-message',
          deltaKind: 'text-delta',
          delta: `Overflow ${index}`,
        },
      });
    }

    const res = await app.request(
      `/api/workspaces/${workspaceId}/threads/${threadId}/events?turnId=${turnId}&since=1`
    );
    const error = ApiErrorSchema.parse(await res.json());

    expect(res.status).toBe(410);
    expect(error.code).toBe('core.stream.cursor_expired');
  });

  it('does not replay a turn through a different workspace and thread path', async () => {
    const store = createDemoStore();
    const otherWorkspace = store.createWorkspace('Other event workspace');
    const { turnId } = createReplayTurn(store, otherWorkspace.id);
    const app = createApp({ store });

    const res = await app.request(
      `/api/workspaces/ws_00000000-0000-7000-8000-000000000001/threads/th_00000000-0000-7000-8000-000000000001/events?turnId=${turnId}&since=0`
    );

    expect(res.status).toBe(404);
    expect(ApiErrorSchema.parse(await res.json()).code).toBe('not_found');
  });

  it('omits AgentSession identity from ordinary SSE while retained events may still carry it', async () => {
    const store = createDemoStore();
    const app = createApp({ store });
    const thread = store.createThread(
      'ws_00000000-0000-7000-8000-000000000001',
      'Hidden AgentSession stream'
    );
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      thread.id,
      'Hide AgentSession from SSE',
      {
        kind: 'user',
        id: 'usr_00000000-0000-7000-8000-000000000001',
      }
    );
    const agentSession = store.createAgentSession({
      id: 'as_00000000-0000-7271-8ba3-bea82b217022',
      agentId: 'agent_codex_host',
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
      threadId: thread.id,
      status: 'busy',
      message: null,
      createdAt: turn.startedAt ?? new Date().toISOString(),
      updatedAt: turn.startedAt ?? new Date().toISOString(),
    });
    const hiddenTurn = store.updateTurn(turn.id, { agentSessionId: agentSession.id });
    store.emitTurnEvent(turn.id, {
      event: 'agent.session.updated',
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
      threadId: thread.id,
      turnId: turn.id,
      data: { type: 'agent-session-updated', agentSession },
    });
    store.emitTurnEvent(turn.id, {
      event: 'turn.updated',
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
      threadId: thread.id,
      turnId: turn.id,
      data: { type: 'turn-updated', turn: hiddenTurn },
    });
    const completedTurn = store.updateTurn(turn.id, {
      status: 'completed',
      completedAt: turn.startedAt,
    });
    store.emitTurnEvent(turn.id, {
      event: 'turn.completed',
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
      threadId: thread.id,
      turnId: turn.id,
      data: { type: 'turn-completed', stopReason: 'completed', turn: completedTurn },
    });

    const response = await app.request(
      `/api/workspaces/ws_00000000-0000-7000-8000-000000000001/threads/${thread.id}/events?turnId=${turn.id}&since=0`
    );
    const events = parseSseEvents(await response.text());

    expect(response.status).toBe(200);
    expect(JSON.stringify(events)).not.toContain('agentSessionId');
    expect(JSON.stringify(events)).not.toContain('agent-session-updated');
    expect(JSON.stringify(events)).not.toContain('agent.session.updated');
    expect(
      store.getTurnEvents(turn.id).some((event) => event.event === 'agent.session.updated')
    ).toBe(true);
    expect(
      store.getTurn('ws_00000000-0000-7000-8000-000000000001', thread.id, turn.id).agentSessionId
    ).toBe('as_00000000-0000-7271-8ba3-bea82b217022');
  });
});
