import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createModels, fauxAssistantMessage, fauxProvider } from '@earendil-works/pi-ai';
import { googleProvider } from '@earendil-works/pi-ai/providers/google';
import { openaiProvider } from '@earendil-works/pi-ai/providers/openai';
import { openaiCodexProvider } from '@earendil-works/pi-ai/providers/openai-codex';
import { afterEach, describe, expect, it, vi } from 'vitest';
import {
  type CapabilityAuditLineage,
  listWorkspaceCapabilityCalls,
  listWorkspaceUsageRecords,
} from '../capability/usage-ledger.js';
import { readWorkObservationBody } from '../evidence-bundles.js';
import { FsStore } from '../lib/store.js';
import { withTurnModelCapture } from '../llm/model-capture.js';
import { openWorkspaceDb, type WorkspaceDb } from '../storage/db.js';
import { applyScopedMigrations } from '../storage/migrate.js';
import { readWorkObservations } from '../storage/work-observations.js';
import { testEntityId } from '../test-support/entity-ids.js';

const databases: WorkspaceDb[] = [];
const roots: string[] = [];
afterEach(() => {
  vi.restoreAllMocks();
  for (const db of databases.splice(0)) db.sqlite.close();
  for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true });
});

/** Creates actual persisted admission even when the model transport is a fixture. */
function captureBinding(value: 'off' | 'on' = 'off') {
  const dataRoot = mkdtempSync(join(tmpdir(), 'internal-model-capture-'));
  roots.push(dataRoot);
  const store = new FsStore({ dataRoot });
  const workspace = store.createWorkspace('Internal capture');
  const thread = store.createThread(workspace.id, 'Internal capture');
  const turn = store.createTurn(
    workspace.id,
    thread.id,
    'Request',
    { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
    null,
    { captureCoverage: { scope: 'server', value } }
  );
  const workspaceDb = openWorkspaceDb(dataRoot, workspace.id);
  databases.push(workspaceDb);
  applyScopedMigrations(workspaceDb);
  return { dataRoot, store, turn, workspaceDb, threadId: thread.id, turnId: turn.id };
}

import {
  GatewayAttemptFailure,
  LogicalModelRoutesExhaustedError,
} from '../llm/gateway-execution.js';
import type { ResolvedLogicalModel } from '../llm/logical-models.js';
import { OpenAICompatibleProviderError } from '../llm/openai-compatible-client.js';
import { GatewayUnsupportedFeatureError, PiAiGatewayClient } from '../llm/pi-ai-client.js';
import { attachPiAiFailure } from '../llm/pi-ai-failure.js';
import { LLMGatewayProviderDispatcher } from '../llm/provider-dispatcher.js';
import { createInternalAgentGatewayProvider } from './gateway-provider.js';
import { type InternalAgentProviderRequest, runInternalAgentLoop } from './internal-agent-loop.js';

const logicalModel: ResolvedLogicalModel = {
  id: 'assistant',
  displayName: 'Assistant',
  capabilities: ['responses', 'tool-calling'],
  contextManagement: { type: 'compaction', compactThreshold: 8_000 },
  modelFamilyId: 'gpt-5',
  autoFailover: true,
  routes: [
    {
      id: 'primary',
      providerProfileId: 'provider',
      providerModel: 'model',
      available: true,
      unavailableReason: null,
    },
  ],
};

function request(input = 'Read status.') {
  return {
    systemPrompt: 'Admin role.',
    messages: [{ role: 'user' as const, content: [{ type: 'text' as const, text: input }] }],
    tools: [
      {
        name: 'environment.status',
        description: 'Read status.',
        inputSchema: { type: 'object' },
      },
    ],
    model: {
      logicalModelId: 'assistant',
      capabilities: logicalModel.capabilities,
      modelFamilyId: logicalModel.modelFamilyId,
    },
    signal: new AbortController().signal,
  };
}

describe('internal Agent Gateway provider', () => {
  it('logs undeclared Tool output from the real adapter as output-projection', async () => {
    const capture = captureBinding();
    const faux = fauxProvider({
      api: 'openai-responses',
      provider: 'provider',
      models: [{ id: 'model' }],
    });
    const models = createModels();
    models.setProvider(faux.provider);
    faux.setResponses([
      fauxAssistantMessage(
        {
          type: 'toolCall',
          id: 'call_private',
          name: 'undeclared',
          arguments: { secret: 'argument-canary' },
        },
        { stopReason: 'toolUse' }
      ),
    ]);
    const log = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const provider = createInternalAgentGatewayProvider({
      capture,
      logicalModel,
      resolveLogicalModel: () => logicalModel,
      dispatcher: new LLMGatewayProviderDispatcher({
        piAiClient: new PiAiGatewayClient({ models }),
      }),
      resolveGatewayProvider: () => ({
        id: 'provider',
        displayName: 'Provider',
        adapterId: 'provider',
        apiKey: 'credential-canary',
        baseUrl: null,
        models: ['model'],
        requiresApiKey: true,
        gatewayCapabilities: { chatCompletions: 'native', responses: 'native' },
        modelMetadata: { model: { tool_call: true, limit: { context: 64_000, output: 8_000 } } },
      }),
      promptCacheScope: { sessionId: 'internal', workspaceId: capture.turn.workspaceId },
      usageEndpoint: 'responses',
    });
    await expect(
      provider({
        ...request('prompt-canary'),
        tools: [
          { name: 'declared', description: 'schema-canary', inputSchema: { type: 'object' } },
        ],
      })
    ).rejects.toHaveProperty('failure.kind', 'unsupported');
    expect(faux.state.callCount).toBe(1);
    expect(log).toHaveBeenCalledTimes(1);
    const diagnostic = JSON.parse(String(log.mock.calls[0]![0]));
    expect(diagnostic).toEqual({
      code: 'internal_gateway_call_failed',
      message: 'Internal Gateway logical call failed.',
      phase: 'output-projection',
      failureKind: 'unsupported',
      workspaceId: capture.turn.workspaceId,
      threadId: capture.threadId,
      turnId: capture.turnId,
      corr: expect.any(String),
      attempt: 0,
    });
    for (const prohibited of [
      'declared',
      'undeclared',
      'argument-canary',
      'schema-canary',
      'credential-canary',
      'prompt-canary',
      'exception',
    ])
      expect(JSON.stringify(diagnostic)).not.toContain(prohibited);
  });

  it('logs terminal local resolution without the preceding member HTTP status', async () => {
    const capture = captureBinding();
    const log = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const model = {
      ...logicalModel,
      routes: [
        ...logicalModel.routes,
        { ...logicalModel.routes[0]!, id: 'backup', providerProfileId: 'backup' },
      ],
    };
    const createResponses = vi.fn(async (_provider, _input, context) => {
      context.transport.onProviderHandoff();
      throw new GatewayAttemptFailure({
        kind: 'auth_rejected',
        settled: true,
        status: 401,
      });
    });
    const resolveGatewayProvider = vi.fn((id: string) => {
      if (id === 'backup')
        throw new OpenAICompatibleProviderError({
          message: 'exception-canary',
          code: 'provider_not_configured',
          status: 503,
        });
      return {
        id,
        models: ['model'],
        gatewayCapabilities: {},
        modelMetadata: { model: { tool_call: true, limit: { context: 64_000, output: 8_000 } } },
      } as never;
    });
    const provider = createInternalAgentGatewayProvider({
      capture,
      logicalModel: model,
      resolveLogicalModel: () => model,
      dispatcher: { createResponses },
      resolveGatewayProvider,
      promptCacheScope: { sessionId: 'internal', workspaceId: capture.turn.workspaceId },
      usageEndpoint: 'responses',
    });
    await expect(provider(request())).rejects.toMatchObject({
      code: 'gateway_logical_model_unavailable',
      cause: 'provider_unavailable',
    });
    expect(resolveGatewayProvider.mock.calls.map(([id]) => id)).toEqual(['provider', 'backup']);
    expect(createResponses).toHaveBeenCalledTimes(1);
    expect(log).toHaveBeenCalledTimes(1);
    expect(JSON.parse(String(log.mock.calls[0]![0]))).toEqual({
      code: 'internal_gateway_call_failed',
      message: 'Internal Gateway logical call failed.',
      phase: 'pre-transport',
      failureKind: 'provider_unavailable',
      workspaceId: capture.turn.workspaceId,
      threadId: capture.threadId,
      turnId: capture.turnId,
      corr: expect.any(String),
      attempt: 1,
    });
  });

  it('logs the real required prefixItems rejection as pre-transport without private content', async () => {
    const capture = captureBinding();
    const stock = openaiProvider();
    const models = createModels();
    models.setProvider(stock);
    const model = models
      .getModels()
      .find(
        (model) =>
          model.provider === stock.id &&
          model.api === 'openai-responses' &&
          model.contextWindow - model.maxTokens > 8_192
      )!;
    expect(model).toBeDefined();
    const selectedModel = {
      ...logicalModel,
      routes: [{ ...logicalModel.routes[0]!, providerModel: model.id }],
    };
    const dispatcher = new LLMGatewayProviderDispatcher({
      piAiClient: new PiAiGatewayClient({ models }),
    });
    const log = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const fetch = vi
      .spyOn(globalThis, 'fetch')
      .mockRejectedValue(new Error('Unexpected transport.'));
    const provider = createInternalAgentGatewayProvider({
      capture,
      logicalModel: selectedModel,
      resolveLogicalModel: () => selectedModel,
      dispatcher: {
        // Recreate the original required-sampling admission through the real stock serializer.
        createResponses: (provider, input, context) =>
          dispatcher.createResponses(
            provider,
            {
              ...input,
              tools: (input.tools as Record<string, unknown>[]).map((tool) => ({
                ...tool,
                strict: true,
              })),
            },
            context
          ),
      },
      resolveGatewayProvider: () => ({
        id: 'provider',
        displayName: 'Provider',
        adapterId: stock.id,
        apiKey: 'credential-canary',
        baseUrl: null,
        models: [model.id],
        requiresApiKey: true,
        gatewayCapabilities: { chatCompletions: 'native', responses: 'native' },
        modelMetadata: {
          [model.id]: {
            tool_call: true,
            limit: { context: model.contextWindow, output: model.maxTokens },
          },
        },
      }),
      promptCacheScope: {
        sessionId: 'private-session-canary',
        workspaceId: capture.turn.workspaceId,
      },
      usageEndpoint: 'responses',
      callContext: {
        workspaceId: capture.turn.workspaceId,
        authorityActor: capture.turn.triggerActor,
        family: 'llm',
        operation: 'administration',
        capabilityId: 'inference.local.administration',
        requestId: '00000000-0000-4000-8000-000000000001',
        redactionClass: 'metadata-only',
      },
    });
    const failure = await provider({
      ...request('prompt-canary'),
      tools: [
        {
          name: 'task_start',
          description: 'schema-canary',
          inputSchema: {
            type: 'object',
            properties: { args: { type: 'array', prefixItems: [{ type: 'string' }] } },
          },
        },
      ],
    }).catch((error: unknown) => error);
    expect(failure).toHaveProperty(
      'cause.message',
      'Tool "task_start" requires JSON-schema constrained sampling, but prefixItems schemas are unsupported.'
    );
    expect(fetch).not.toHaveBeenCalled();
    const calls = listWorkspaceCapabilityCalls(capture.workspaceDb, capture.turn.workspaceId);
    expect(calls).toHaveLength(1);
    expect(calls[0]).toMatchObject({ status: 'failed', errorCode: 'internal_inference_failed' });
    expect(log).toHaveBeenCalledTimes(1);
    const diagnostic = JSON.parse(String(log.mock.calls[0]![0]));
    expect(diagnostic).toEqual({
      code: 'internal_gateway_call_failed',
      message: 'Internal Gateway logical call failed.',
      phase: 'pre-transport',
      failureKind: 'unknown',
      requestId: '00000000-0000-4000-8000-000000000001',
      workspaceId: capture.turn.workspaceId,
      threadId: capture.threadId,
      turnId: capture.turnId,
      capabilityCallId: calls[0]!.id,
      corr: expect.any(String),
      attempt: 0,
    });
    const serialized = JSON.stringify(diagnostic);
    for (const prohibited of [
      'task_start',
      'prefixItems',
      'constrained sampling',
      'schema-canary',
      'prompt-canary',
      'credential-canary',
      'private-session-canary',
    ])
      expect(serialized).not.toContain(prohibited);
  });

  it.each([
    'transport',
    'provider-response',
    'output-projection',
    'pre-transport',
    'unsupported-after-handoff',
    'sink-failure',
  ] as const)('keeps %s diagnostics safe and independent of product closeout', async (scenario) => {
    const capture = captureBinding();
    const original =
      scenario === 'pre-transport' || scenario === 'unsupported-after-handoff'
        ? new GatewayUnsupportedFeatureError('schema-canary')
        : attachPiAiFailure(new Error('exception-canary'), {
            code: 'provider-private-canary',
            ...(scenario === 'provider-response' ? { status: 401 } : {}),
          });
    const log = vi.spyOn(console, 'warn').mockImplementation(() => {
      if (scenario === 'sink-failure') throw new Error('Log sink unavailable.');
    });
    const provider = createInternalAgentGatewayProvider({
      capture,
      logicalModel: { ...logicalModel, autoFailover: false },
      resolveLogicalModel() {
        return this.logicalModel;
      },
      dispatcher: {
        createResponses: async (_provider, _input, context) => {
          if (scenario !== 'pre-transport') context?.transport?.onProviderHandoff?.();
          if (scenario === 'output-projection')
            return {
              id: 'response',
              object: 'response',
              output: [
                {
                  type: 'function_call',
                  call_id: 'call',
                  name: 'environment_status',
                  arguments: 'argument-canary',
                },
              ],
            } as never;
          throw original;
        },
      },
      resolveGatewayProvider: () =>
        ({
          id: 'provider',
          models: ['model'],
          gatewayCapabilities: {},
          modelMetadata: { model: { tool_call: true, limit: { context: 64_000, output: 8_000 } } },
        }) as never,
      promptCacheScope: { sessionId: 'internal', workspaceId: capture.turn.workspaceId },
      usageEndpoint: 'responses',
      callContext: {
        workspaceId: capture.turn.workspaceId,
        authorityActor: capture.turn.triggerActor,
        family: 'llm',
        operation: 'administration',
        capabilityId: 'inference.local.administration',
        redactionClass: 'metadata-only',
      },
    });
    const error = await provider(request()).catch((error: unknown) => error);
    if (scenario === 'output-projection')
      expect(error).toHaveProperty('message', 'Gateway returned invalid Tool arguments.');
    else if (scenario === 'pre-transport' || scenario === 'unsupported-after-handoff')
      expect(error).toHaveProperty('cause.cause', original);
    else expect(error).toHaveProperty('cause', original);
    expect(
      listWorkspaceCapabilityCalls(capture.workspaceDb, capture.turn.workspaceId)
    ).toMatchObject([
      {
        status: 'failed',
        errorCode:
          scenario === 'provider-response'
            ? 'gateway_provider_authentication_failed'
            : scenario === 'pre-transport' || scenario === 'unsupported-after-handoff'
              ? 'unsupported_gateway_feature'
              : 'internal_inference_failed',
      },
    ]);
    expect(log).toHaveBeenCalledTimes(1);
    expect(JSON.parse(String(log.mock.calls[0]![0]))).toEqual({
      code: 'internal_gateway_call_failed',
      message: 'Internal Gateway logical call failed.',
      phase:
        scenario === 'sink-failure' || scenario === 'unsupported-after-handoff'
          ? 'transport'
          : scenario,
      failureKind:
        scenario === 'provider-response'
          ? 'auth_rejected'
          : scenario === 'pre-transport' || scenario === 'unsupported-after-handoff'
            ? 'unsupported'
            : 'unknown',
      ...(scenario === 'provider-response' ? { httpStatus: 401 } : {}),
      workspaceId: capture.turn.workspaceId,
      threadId: capture.threadId,
      turnId: capture.turnId,
      capabilityCallId: expect.any(String),
      corr: expect.any(String),
      attempt: 0,
    });
  });

  it('emits one diagnostic after retry and failover exhaustion', async () => {
    vi.useFakeTimers();
    try {
      const capture = captureBinding();
      const log = vi.spyOn(console, 'warn').mockImplementation(() => {});
      const createResponses = vi.fn(async (_provider, _input, context) => {
        context.transport.onProviderHandoff();
        throw new GatewayAttemptFailure({
          kind: 'rate_limited',
          settled: true,
          status: 429,
          providerCode: 'private-code-canary',
          retryAfter: '0',
        });
      });
      const provider = createInternalAgentGatewayProvider({
        capture,
        logicalModel: {
          ...logicalModel,
          routes: [
            ...logicalModel.routes,
            { ...logicalModel.routes[0]!, id: 'backup', providerProfileId: 'backup' },
          ],
        },
        resolveLogicalModel() {
          return this.logicalModel;
        },
        dispatcher: { createResponses },
        resolveGatewayProvider: (id) =>
          ({
            id,
            models: ['model'],
            gatewayCapabilities: {},
            modelMetadata: {
              model: { tool_call: true, limit: { context: 64_000, output: 8_000 } },
            },
          }) as never,
        promptCacheScope: { sessionId: 'internal', workspaceId: capture.turn.workspaceId },
        usageEndpoint: 'responses',
      });
      const pending = provider(request()).catch((error: unknown) => error);
      await vi.runAllTimersAsync();
      expect(await pending).toBeInstanceOf(LogicalModelRoutesExhaustedError);
      expect(createResponses).toHaveBeenCalledTimes(8);
      expect(log).toHaveBeenCalledTimes(1);
      expect(JSON.parse(String(log.mock.calls[0]![0]))).toEqual({
        code: 'internal_gateway_call_failed',
        message: 'Internal Gateway logical call failed.',
        phase: 'provider-response',
        failureKind: 'rate_limited',
        httpStatus: 429,
        workspaceId: capture.turn.workspaceId,
        threadId: capture.threadId,
        turnId: capture.turnId,
        corr: expect.any(String),
        attempt: 7,
      });
    } finally {
      vi.useRealTimers();
    }
  });

  it('returns existing unavailable outcome when the pinned model no longer resolves', async () => {
    const log = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const capture = captureBinding();
    const createResponses = vi.fn().mockResolvedValue({
      id: 'unexpected',
      object: 'response',
      status: 'completed',
      output: [
        {
          type: 'message',
          role: 'assistant',
          status: 'completed',
          content: [{ type: 'output_text', text: 'Unexpected dispatch.' }],
        },
      ],
    });
    const resolveGatewayProvider = vi.fn().mockReturnValue({
      id: 'provider',
      models: ['model'],
      gatewayCapabilities: {},
      modelMetadata: { model: { tool_call: true, limit: { context: 64_000, output: 8_000 } } },
    });
    const provider = createInternalAgentGatewayProvider({
      capture,
      logicalModel,
      resolveLogicalModel: () => null,
      dispatcher: { createResponses },
      resolveGatewayProvider,
      promptCacheScope: { sessionId: 'admin:missing', workspaceId: capture.turn.workspaceId },
      usageEndpoint: 'responses',
      callContext: {
        authorityActor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
        agentId: 'assistant',
        workspaceId: capture.turn.workspaceId,
        family: 'llm',
        operation: 'administration',
        capabilityId: 'inference.local.administration',
        providerRef: null,
        requestId: null,
        serviceRef: 'llm-gateway',
        redactionClass: 'metadata-only',
        summary: 'Missing pinned model regression.',
      },
    });
    await expect(provider(request())).rejects.toMatchObject({
      code: 'gateway_logical_model_unavailable',
    });
    expect(resolveGatewayProvider).not.toHaveBeenCalled();
    expect(createResponses).not.toHaveBeenCalled();
    expect(
      listWorkspaceCapabilityCalls(capture.workspaceDb, capture.turn.workspaceId)
    ).toMatchObject([{ status: 'failed', errorCode: 'gateway_logical_model_unavailable' }]);
    expect(listWorkspaceUsageRecords(capture.workspaceDb, capture.turn.workspaceId)).toEqual([]);
    expect(log).toHaveBeenCalledTimes(1);
    expect(JSON.parse(String(log.mock.calls[0]![0]))).toEqual({
      code: 'internal_gateway_call_failed',
      message: 'Internal Gateway logical call failed.',
      phase: 'pre-transport',
      failureKind: 'unknown',
      workspaceId: capture.turn.workspaceId,
      threadId: capture.threadId,
      turnId: capture.turnId,
      capabilityCallId: expect.any(String),
    });
  });

  it('projects only fixed Tools and preserves provider output interleaving', async () => {
    const createResponses = vi.fn().mockResolvedValue({
      id: 'response',
      object: 'response',
      status: 'completed',
      output: [
        {
          type: 'message',
          role: 'assistant',
          status: 'completed',
          content: [{ type: 'output_text', text: 'Checking.' }],
        },
        {
          type: 'function_call',
          call_id: 'call_status',
          name: 'environment_status',
          arguments: '{"workspaceId":"ws_00000000-0000-7b16-81e5-c0b623c0c636"}',
        },
      ],
    });
    const onDispatch = vi.fn();
    const provider = createInternalAgentGatewayProvider({
      resolveLogicalModel(): ResolvedLogicalModel {
        return this.logicalModel;
      },
      logicalModel,
      dispatcher: { createResponses } as Pick<LLMGatewayProviderDispatcher, 'createResponses'>,
      resolveGatewayProvider: () =>
        ({
          id: 'provider',
          models: ['model'],
          gatewayCapabilities: {},
          modelMetadata: { model: { tool_call: true, limit: { context: 64_000, output: 8_000 } } },
        }) as never,
      promptCacheScope: {
        sessionId: 'admin:th_00000000-0000-7915-b626-0b698e2552dc',
        workspaceId: 'ws_00000000-0000-762a-9808-5bd4bc2f5b3f',
      },
      usageEndpoint: 'responses',
      capture: captureBinding(),
      onDispatch,
    });

    const currentRequest: InternalAgentProviderRequest = {
      ...request(),
      tools: [
        ...request().tools,
        {
          name: 'nanohost.runtime-target',
          description: 'Read target.',
          inputSchema: { type: 'object' },
        },
        { name: 'task_start', description: 'Start task.', inputSchema: { type: 'object' } },
        { name: 'a'.repeat(64), description: 'Boundary.', inputSchema: { type: 'object' } },
      ],
      messages: [
        ...request().messages,
        {
          role: 'assistant',
          truncated: false,
          content: [
            {
              type: 'toolCall',
              callId: 'earlier_status',
              name: 'environment.status',
              arguments: { workspaceId: 'ws_00000000-0000-7b16-81e5-c0b623c0c636' },
            },
            {
              type: 'toolCall',
              callId: 'earlier_target',
              name: 'nanohost.runtime-target',
              arguments: {},
            },
            { type: 'toolCall', callId: 'earlier_task', name: 'task_start', arguments: {} },
          ],
        },
      ],
    };
    const response = await provider(currentRequest);

    expect(createResponses).toHaveBeenCalledTimes(1);
    expect(createResponses.mock.calls[0]![1]).toMatchObject({
      parallel_tool_calls: false,
      tools: [
        {
          type: 'function',
          name: 'environment_status',
          description: 'Read status.',
          parameters: { type: 'object' },
          strict: false,
        },
        {
          type: 'function',
          name: 'nanohost_runtime_target',
          description: 'Read target.',
          parameters: { type: 'object' },
          strict: false,
        },
        {
          type: 'function',
          name: 'task_start',
          description: 'Start task.',
          parameters: { type: 'object' },
          strict: false,
        },
        {
          type: 'function',
          name: 'a'.repeat(64),
          description: 'Boundary.',
          parameters: { type: 'object' },
          strict: false,
        },
      ],
    });
    expect(createResponses.mock.calls[0]![2]).toMatchObject({
      transport: {
        signal: expect.any(AbortSignal),
        deadline: expect.any(Number),
        onModelEvent: expect.any(Function),
        onProviderHandoff: expect.any(Function),
      },
    });
    expect(createResponses.mock.calls[0]?.[1]).not.toHaveProperty('metadata');
    const payload = createResponses.mock.calls[0]![1];
    for (const tool of payload.tools) expect(tool.name).toMatch(/^[a-zA-Z0-9_-]{1,64}$/);
    expect(payload.input.slice(1)).toEqual([
      {
        type: 'function_call',
        call_id: 'earlier_status',
        name: 'environment_status',
        arguments: '{"workspaceId":"ws_00000000-0000-7b16-81e5-c0b623c0c636"}',
      },
      {
        type: 'function_call',
        call_id: 'earlier_target',
        name: 'nanohost_runtime_target',
        arguments: '{}',
      },
      { type: 'function_call', call_id: 'earlier_task', name: 'task_start', arguments: '{}' },
    ]);
    expect(currentRequest.tools.map(({ name }) => name)).toEqual([
      'environment.status',
      'nanohost.runtime-target',
      'task_start',
      'a'.repeat(64),
    ]);
    expect(response.message).toEqual({
      role: 'assistant',
      truncated: false,
      content: [
        { type: 'text', text: 'Checking.' },
        {
          type: 'toolCall',
          callId: 'call_status',
          name: 'environment.status',
          arguments: { workspaceId: 'ws_00000000-0000-7b16-81e5-c0b623c0c636' },
        },
      ],
    });
    expect(onDispatch).toHaveBeenCalledWith({ id: 'response', providerId: 'provider' });
  });

  it.each([
    ['undeclared', 'undeclared'],
    ['environment.status', 'openkit_unavailable_tool'],
    ['environment-status', 'environment-status'],
    ['environment__status', 'environment__status'],
    ['invalid/name', 'openkit_unavailable_tool'],
    ['a'.repeat(65), 'openkit_unavailable_tool'],
  ])('projects unadmitted returned names for loop correction: %s', async (name, expectedName) => {
    const createResponses = vi.fn().mockResolvedValue({
      id: 'response',
      object: 'response',
      status: 'completed',
      output: [{ type: 'function_call', call_id: 'call_status', name, arguments: '{}' }],
    });
    const onDispatch = vi.fn();
    const provider = createInternalAgentGatewayProvider({
      capture: captureBinding(),
      logicalModel,
      resolveLogicalModel: () => logicalModel,
      dispatcher: { createResponses },
      resolveGatewayProvider: () =>
        ({
          id: 'provider',
          models: ['model'],
          gatewayCapabilities: {},
          modelMetadata: { model: { tool_call: true, limit: { context: 64_000, output: 8_000 } } },
        }) as never,
      promptCacheScope: { sessionId: 'admin', workspaceId: testEntityId('ws', 'workspace') },
      usageEndpoint: 'responses',
      onDispatch,
    });
    await expect(provider(request())).resolves.toMatchObject({
      message: {
        content: [{ type: 'toolCall', callId: 'call_status', name: expectedName, arguments: {} }],
      },
    });
    expect(createResponses).toHaveBeenCalledTimes(1);
    expect(onDispatch).toHaveBeenCalledTimes(1);
  });

  it.each([
    ['environment.status', 'openkit_unavailable_tool', 'environment.status'],
    ['undeclared', 'undeclared', 'environment.status'],
    ['invalid/name', 'openkit_unavailable_tool', 'environment.status'],
    ['environment-status', 'openkit_unavailable_tool', 'environment-status'],
  ])('corrects an unadmitted spelling through the real loop and Gateway history: %s', async (name, historyName, canonicalName) => {
    const execute = vi.fn(async () => ({
      content: [{ type: 'text' as const, text: 'Available.' }],
    }));
    const args = { workspaceId: 'ws_00000000-0000-7b16-81e5-c0b623c0c636' };
    const createResponses = vi
      .fn()
      .mockResolvedValueOnce({
        id: 'response_unknown',
        object: 'response',
        status: 'completed',
        output: [
          { type: 'function_call', call_id: 'unknown_call', name, arguments: JSON.stringify(args) },
        ],
      })
      .mockImplementationOnce(async (_provider, payload) => {
        expect(execute).not.toHaveBeenCalled();
        expect(payload.tools.map((tool: { name: string }) => tool.name)).toEqual([
          'environment_status',
        ]);
        expect(payload.input.slice(1)).toEqual([
          {
            type: 'function_call',
            call_id: 'unknown_call',
            name: historyName,
            arguments: JSON.stringify(args),
          },
          {
            type: 'function_call_output',
            call_id: 'unknown_call',
            output: 'The requested Tool is unavailable.',
          },
        ]);
        for (const item of payload.input) {
          if (item.type === 'function_call') expect(item.name).toMatch(/^[a-zA-Z0-9_-]{1,64}$/);
        }
        return {
          id: 'response_corrected',
          object: 'response',
          status: 'completed',
          output: [
            {
              type: 'function_call',
              call_id: 'admitted_call',
              name: 'environment_status',
              arguments: JSON.stringify(args),
            },
          ],
        };
      })
      .mockResolvedValueOnce({
        id: 'response_done',
        object: 'response',
        status: 'completed',
        output: [
          {
            type: 'message',
            role: 'assistant',
            content: [{ type: 'output_text', text: 'Ready.' }],
          },
        ],
      });
    const provider = createInternalAgentGatewayProvider({
      capture: captureBinding(),
      logicalModel,
      resolveLogicalModel: () => logicalModel,
      dispatcher: { createResponses },
      resolveGatewayProvider: () =>
        ({
          id: 'provider',
          models: ['model'],
          gatewayCapabilities: {},
          modelMetadata: { model: { tool_call: true, limit: { context: 64_000, output: 8_000 } } },
        }) as never,
      promptCacheScope: { sessionId: 'admin', workspaceId: testEntityId('ws', 'workspace') },
      usageEndpoint: 'responses',
    });
    const result = await runInternalAgentLoop(
      {
        ...request(),
        tools: [{ ...request().tools[0]!, name: canonicalName, execute }],
        limits: { maxModelTurns: 3, maxToolCalls: 1, deadlineMs: 10_000 },
      },
      provider
    );
    expect(result.kind).toBe('quiescent');
    expect(createResponses).toHaveBeenCalledTimes(3);
    expect(execute).toHaveBeenCalledExactlyOnceWith(args, {
      callId: 'admitted_call',
      signal: expect.any(AbortSignal),
    });
    expect(createResponses.mock.calls[2]![1].input.slice(-2)).toEqual([
      {
        type: 'function_call',
        call_id: 'admitted_call',
        name: 'environment_status',
        arguments: JSON.stringify(args),
      },
      { type: 'function_call_output', call_id: 'admitted_call', output: 'Available.' },
    ]);
    expect(result.messages).toContainEqual({
      role: 'assistant',
      truncated: false,
      content: [
        { type: 'toolCall', callId: 'admitted_call', name: canonicalName, arguments: args },
      ],
    });
  });

  it('keeps malformed Tool calls and arguments fatal instead of requesting correction', async () => {
    const createResponses = vi.fn();
    const provider = createInternalAgentGatewayProvider({
      capture: captureBinding(),
      logicalModel,
      resolveLogicalModel: () => logicalModel,
      dispatcher: { createResponses },
      resolveGatewayProvider: () =>
        ({
          id: 'provider',
          models: ['model'],
          gatewayCapabilities: {},
          modelMetadata: { model: { tool_call: true, limit: { context: 64_000, output: 8_000 } } },
        }) as never,
      promptCacheScope: { sessionId: 'admin', workspaceId: testEntityId('ws', 'workspace') },
      usageEndpoint: 'responses',
    });
    const invalidCalls = [
      { call_id: undefined },
      { call_id: '' },
      { name: '' },
      { name: 7 },
      { arguments: {} },
    ];
    for (const invalid of invalidCalls) {
      createResponses.mockResolvedValueOnce({
        id: 'response',
        object: 'response',
        status: 'completed',
        output: [
          {
            type: 'function_call',
            call_id: 'call_status',
            name: 'undeclared',
            arguments: '{}',
            ...invalid,
          },
        ],
      });
      await expect(provider(request())).rejects.toThrow('Gateway returned invalid Tool calls.');
    }
    createResponses.mockResolvedValueOnce({
      id: 'response',
      object: 'response',
      status: 'completed',
      output: [
        { type: 'function_call', call_id: 'call_status', name: 'undeclared', arguments: '{' },
      ],
    });
    await expect(provider(request())).rejects.toThrow('Gateway returned invalid Tool arguments.');
    expect(createResponses).toHaveBeenCalledTimes(6);
  });

  it.each([
    ['environment.status', 'environment_status'],
    ['nanohost.runtime-target', 'nanohost.runtime_target'],
    [''],
    ['a'.repeat(65)],
    ['invalid/name'],
    ['openkit_unavailable_tool'],
    ['openkit.unavailable-tool'],
  ])('rejects invalid or colliding Tool aliases before dispatch: %j', async (...names) => {
    const createResponses = vi.fn().mockResolvedValue({
      id: 'response',
      object: 'response',
      status: 'completed',
      output: [
        {
          type: 'message',
          role: 'assistant',
          content: [{ type: 'output_text', text: 'Ready.' }],
        },
      ],
    });
    const resolveGatewayProvider = vi.fn(
      () =>
        ({
          id: 'provider',
          models: ['model'],
          gatewayCapabilities: {},
          modelMetadata: { model: { tool_call: true, limit: { context: 64_000, output: 8_000 } } },
        }) as never
    );
    const provider = createInternalAgentGatewayProvider({
      capture: captureBinding(),
      logicalModel,
      resolveLogicalModel: () => logicalModel,
      dispatcher: { createResponses },
      resolveGatewayProvider,
      promptCacheScope: { sessionId: 'admin', workspaceId: testEntityId('ws', 'workspace') },
      usageEndpoint: 'responses',
    });
    await expect(
      provider({
        ...request(),
        tools: names.map((name) => ({
          name,
          description: 'Read.',
          inputSchema: { type: 'object' },
        })),
      })
    ).rejects.toThrow('Internal Agent Tool aliases must be unique Responses function names.');
    expect(resolveGatewayProvider).not.toHaveBeenCalled();
    expect(createResponses).not.toHaveBeenCalled();
  });

  it.each([
    0, 1,
  ])('completes the real internal Google request with %i ordinary functions', async (toolCount) => {
    const stock = googleProvider();
    const models = createModels();
    models.setProvider(stock);
    const model = models
      .getModels()
      .find((model) => model.provider === stock.id && model.id === 'gemini-3-flash-preview')!;
    expect(model.api).toBe('google-generative-ai');
    const googleLogicalModel: ResolvedLogicalModel = {
      ...logicalModel,
      modelFamilyId: 'gemini',
      routes: [{ ...logicalModel.routes[0]!, providerModel: model.id }],
    };
    const capture = captureBinding();
    const payloads: Record<string, unknown>[] = [];
    const fetchMock = vi.spyOn(globalThis, 'fetch').mockImplementation(async (_url, init) => {
      payloads.push(JSON.parse(String(init?.body)));
      return new Response(
        `data: ${JSON.stringify({
          candidates: [
            { content: { role: 'model', parts: [{ text: 'answer' }] }, finishReason: 'STOP' },
          ],
          usageMetadata: { promptTokenCount: 1, candidatesTokenCount: 1, totalTokenCount: 2 },
        })}\n\n`,
        { headers: { 'content-type': 'text/event-stream' } }
      );
    });
    try {
      const response = await withTurnModelCapture(
        { store: capture.store, turn: capture.turn },
        async (admitted) => {
          const provider = createInternalAgentGatewayProvider({
            capture: admitted,
            logicalModel: googleLogicalModel,
            resolveLogicalModel: () => googleLogicalModel,
            dispatcher: new LLMGatewayProviderDispatcher({
              piAiClient: new PiAiGatewayClient({ models }),
            }),
            resolveGatewayProvider: () => ({
              id: 'provider',
              displayName: 'Provider',
              adapterId: stock.id,
              apiKey: 'synthetic',
              baseUrl: null,
              models: [model.id],
              requiresApiKey: true,
              gatewayCapabilities: { chatCompletions: 'native', responses: 'bridged' },
              modelMetadata: { [model.id]: { tool_call: true, limit: { context: 1_000_000 } } },
            }),
            promptCacheScope: {
              sessionId: 'internal-google',
              workspaceId: capture.turn.workspaceId,
            },
            usageEndpoint: 'responses',
          });
          return provider({
            ...request(),
            model: {
              logicalModelId: googleLogicalModel.id,
              capabilities: googleLogicalModel.capabilities,
              modelFamilyId: googleLogicalModel.modelFamilyId,
            },
            tools:
              toolCount === 0
                ? []
                : [
                    {
                      name: 'lookup',
                      description: 'Read status.',
                      inputSchema: {
                        type: 'object',
                        properties: { key: { type: 'string' } },
                        required: ['key'],
                        additionalProperties: false,
                      },
                    },
                  ],
          });
        }
      );
      expect(response.message).toEqual({
        role: 'assistant',
        content: [{ type: 'text', text: 'answer' }],
        truncated: false,
      });
      expect(fetchMock).toHaveBeenCalledTimes(1);
      if (toolCount === 0) {
        expect(payloads[0]?.tools).toBeUndefined();
      } else {
        expect(payloads[0]?.tools).toMatchObject([{ functionDeclarations: [{ name: 'lookup' }] }]);
        // Provider constrained generation is disabled; the internal loop retains schema admission.
        expect(payloads[0]?.toolConfig).toBeUndefined();
      }
    } catch (error) {
      throw new Error(
        `Internal Google request failed after ${fetchMock.mock.calls.length} fetches.`,
        { cause: error }
      );
    } finally {
      fetchMock.mockRestore();
    }
  });

  it.each([
    'off',
    'on',
  ] as const)('passes a physically fitting request through real Gateway admission with capture %s', async (value) => {
    const faux = fauxProvider({
      // Give the capture fixture a meaningful API identity matching its native Responses capability.
      api: 'openai-responses',
      provider: 'provider',
      models: [{ id: 'model' }],
    });
    const models = createModels();
    models.setProvider(faux.provider);
    const answer = '  Admitted. 世界\n\t';
    faux.setResponses([fauxAssistantMessage(answer)]);
    const capture = captureBinding(value);
    const providerOptions = {
      logicalModel,
      dispatcher: new LLMGatewayProviderDispatcher({
        piAiClient: new PiAiGatewayClient({ models }),
      }),
      resolveGatewayProvider: () => ({
        adapterId: 'provider',
        apiKey: 'test-key',
        baseUrl: null,
        displayName: 'Provider',
        gatewayCapabilities: { chatCompletions: 'native' as const, responses: 'native' as const },
        id: 'provider',
        models: ['model'],
        modelMetadata: { model: { tool_call: true, limit: { context: 64_000, output: 8_000 } } },
        requiresApiKey: true,
      }),
      promptCacheScope: {
        sessionId: 'administration:th_00000000-0000-7915-b626-0b698e2552dc',
        workspaceId: 'ws_00000000-0000-762a-9808-5bd4bc2f5b3f',
      },
      usageEndpoint: 'responses' as const,
    };
    let admittedDb: WorkspaceDb | undefined;
    const response = await withTurnModelCapture(
      { store: capture.store, turn: capture.turn },
      async (admitted) => {
        admittedDb = admitted.workspaceDb;
        const provider = createInternalAgentGatewayProvider({
          resolveLogicalModel(): ResolvedLogicalModel {
            return this.logicalModel;
          },
          ...providerOptions,
          capture: admitted,
        });
        return provider(request());
      }
    );

    expect(response.message.content).toEqual([{ type: 'text', text: answer }]);
    expect(faux.state.callCount).toBe(1);
    expect(admittedDb?.sqlite.open).toBe(false);
    const rows = readWorkObservations(capture.workspaceDb, capture);
    expect(rows.some((row) => row.type === 'model.observed')).toBe(true);
    const publications = rows.filter((row) => row.type === 'content.published');
    if (value === 'off') {
      expect(publications).toEqual([]);
    } else {
      const bodies = publications.flatMap((row) =>
        (row.refs ?? []).map((ref) => {
          const original = rows.find((candidate) => candidate.id === row.parent)!;
          const bytes = readWorkObservationBody(capture.workspaceDb, {
            ...capture,
            bundleId: ref.locator,
            createdAt: original.ts,
            sha256: ref.digest!,
          });
          return { direction: original.payload.direction, bytes };
        })
      );
      expect(bodies.every(({ bytes }) => bytes !== null)).toBe(true);
      const responseEvents = bodies
        .filter(({ direction }) => direction === 'response')
        .map(
          ({ bytes }) => JSON.parse(new TextDecoder().decode(bytes!)) as Record<string, unknown>
        );
      expect(
        responseEvents.filter((event) => event.type === 'text_end').map((event) => event.content)
      ).toEqual([answer]);
      expect(
        responseEvents
          .filter((event) => event.type === 'text_delta')
          .map((event) => event.delta)
          .join('')
      ).toBe(answer);
      expect(
        responseEvents
          .filter((event) => event.type === 'done')
          .map((event) => (event.message as { content: unknown }).content)
      ).toEqual([[{ type: 'text', text: answer }]]);
    }
    const turnPath = join(
      capture.dataRoot,
      'workspaces',
      capture.workspaceDb.workspaceId,
      'threads',
      capture.threadId,
      'turns',
      capture.turnId,
      'turn.json'
    );
    const turn = JSON.parse(readFileSync(turnPath, 'utf8')) as Record<string, unknown>;
    delete turn.captureCoverage;
    writeFileSync(turnPath, JSON.stringify(turn));
    const onModelCall = vi.fn();
    await expect(
      withTurnModelCapture({ store: capture.store, turn: capture.turn }, onModelCall)
    ).rejects.toMatchObject({ code: 'model_capture_unavailable' });
    expect(onModelCall).not.toHaveBeenCalled();
    expect(faux.state.callCount).toBe(1);
  });

  it('admits a Codex subscription Responses turn without internal metadata', async () => {
    const faux = fauxProvider({
      api: 'openai-codex-responses',
      provider: 'openai-codex',
      models: [{ id: 'gpt-5.6-sol' }],
    });
    const pairModels = createModels();
    const baseUrl = openaiCodexProvider().baseUrl;
    pairModels.setProvider({
      ...faux.provider,
      ...(baseUrl === undefined ? {} : { baseUrl }),
    });
    pairModels.checkAuth = async () => ({}) as never;
    faux.setResponses([fauxAssistantMessage('Codex admitted.')]);
    const provider = createInternalAgentGatewayProvider({
      resolveLogicalModel(): ResolvedLogicalModel {
        return this.logicalModel;
      },
      logicalModel: {
        ...logicalModel,
        routes: [
          {
            id: 'primary',
            providerProfileId: 'codex-work',
            providerModel: 'openai-codex/gpt-5.6-sol',
            available: true,
            unavailableReason: null,
          },
        ],
      },
      dispatcher: new LLMGatewayProviderDispatcher({
        piAiClient: new PiAiGatewayClient(),
      }),
      resolveGatewayProvider: () => ({
        accountSlotId: 'work',
        adapterId: 'openai-codex',
        apiKey: null,
        baseUrl: null,
        displayName: 'OpenAI Codex',
        gatewayCapabilities: { chatCompletions: 'bridged', responses: 'native' },
        id: 'codex-work',
        models: ['openai-codex/gpt-5.6-sol'],
        modelMetadata: {
          'openai-codex/gpt-5.6-sol': {
            tool_call: true,
            limit: { context: faux.getModel().contextWindow, output: faux.getModel().maxTokens },
          },
        },
        requiresApiKey: false,
        subscriptionProviderId: 'openai-codex',
      }),
      capture: captureBinding(),
      providerSubscriptionAccountManager: {
        getPairHandle: async () => ({ models: pairModels }),
      } as never,
      promptCacheScope: {
        sessionId: 'administration:th_00000000-0000-7915-b626-0b698e2552dc',
        workspaceId: 'ws_00000000-0000-762a-9808-5bd4bc2f5b3f',
      },
      usageEndpoint: 'responses',
    });

    const response = await provider(request());

    expect(response.message.content).toEqual([{ type: 'text', text: 'Codex admitted.' }]);
    expect(faux.state.callCount).toBe(1);
  });

  it('fails before provider contact when Tool image content cannot be preserved', async () => {
    const createResponses = vi.fn();
    const provider = createInternalAgentGatewayProvider({
      resolveLogicalModel(): ResolvedLogicalModel {
        return this.logicalModel;
      },
      logicalModel,
      dispatcher: { createResponses } as Pick<LLMGatewayProviderDispatcher, 'createResponses'>,
      resolveGatewayProvider: () => ({}) as never,
      promptCacheScope: {
        sessionId: 'administration:th_00000000-0000-7915-b626-0b698e2552dc',
        workspaceId: 'ws_00000000-0000-762a-9808-5bd4bc2f5b3f',
      },
      usageEndpoint: 'responses',
      capture: captureBinding(),
    });
    const input = request();

    await expect(
      provider({
        ...input,
        messages: [
          ...input.messages,
          {
            role: 'tool',
            callId: 'call_image',
            isError: false,
            content: [{ type: 'image', mimeType: 'image/png', data: 'private-image-bytes' }],
          },
        ],
      })
    ).rejects.toMatchObject({ code: 'tool_image_content_unavailable' });
    expect(createResponses).not.toHaveBeenCalled();
  });
});

/** The internal role uses the same fixed failure oracle as public Gateway requests. */
const internalDecisions = [
  ['auth_rejected', 1, true],
  ['quota_exhausted', 1, true],
  ['rate_limited', 4, true],
  ['provider_unavailable', 4, true],
  ['context_overflow', 1, false],
  ['unsupported', 1, false],
  ['output_limit', 1, false],
  ['refused', 1, false],
  ['invalid_request', 1, false],
  ['cancelled', 1, false],
  ['unknown', 1, false],
] as const;

describe('internal role shares Gateway planning and replay rules', () => {
  it.each(
    internalDecisions
  )('%s follows the same retry and advancement rule', async (kind, primaryCalls, advances) => {
    const capture = captureBinding();
    vi.useFakeTimers();
    try {
      for (const autoFailover of [false, true]) {
        const model = {
          ...logicalModel,
          autoFailover,
          routes: ['primary', 'backup'].map((id) => ({
            ...logicalModel.routes[0]!,
            id,
            providerProfileId: id,
          })),
        };
        const calls: string[] = [];
        const createResponses = vi.fn(async (config: { id: string }) => {
          calls.push(config.id);
          if (config.id === 'primary')
            throw Object.assign(new Error('private detail'), { failure: { kind, settled: true } });
          return {
            id: 'response',
            object: 'response' as const,
            status: 'completed',
            output: [
              {
                type: 'message',
                role: 'assistant',
                content: [{ type: 'output_text', text: 'Backup.' }],
              },
            ],
          };
        });
        const provider = createInternalAgentGatewayProvider({
          resolveLogicalModel(): ResolvedLogicalModel {
            return this.logicalModel;
          },
          logicalModel: model,
          capture,
          dispatcher: { createResponses } as unknown as Pick<
            LLMGatewayProviderDispatcher,
            'createResponses'
          >,
          resolveGatewayProvider: (id) =>
            ({
              id,
              models: ['model'],
              gatewayCapabilities: { responses: 'native', chatCompletions: 'native' },
              modelMetadata: {
                model: { tool_call: true, limit: { context: 64_000, output: 8_000 } },
              },
            }) as never,
          promptCacheScope: { sessionId: 'admin', workspaceId: testEntityId('ws', 'workspace') },
          usageEndpoint: 'responses',
        });
        const pending = provider(request()).then(
          (result) => ({ result }),
          (error) => ({ error })
        );
        await vi.runAllTimersAsync();
        const outcome = await pending;
        expect(calls.filter((id) => id === 'primary')).toHaveLength(primaryCalls);
        expect(calls.filter((id) => id === 'backup')).toHaveLength(
          autoFailover && advances ? 1 : 0
        );
        if (autoFailover && advances)
          expect(outcome).toMatchObject({
            result: { message: { content: [{ type: 'text', text: 'Backup.' }] } },
          });
        else expect(outcome).toMatchObject({ error: { failure: { kind } } });
      }
    } finally {
      vi.useRealTimers();
    }
  });

  it('skips a member unable to satisfy the run-pinned tool capability without dispatch', async () => {
    const calls: string[] = [];
    const provider = createInternalAgentGatewayProvider({
      resolveLogicalModel(): ResolvedLogicalModel {
        return this.logicalModel;
      },
      logicalModel: {
        ...logicalModel,
        routes: ['primary', 'backup'].map((id) => ({
          ...logicalModel.routes[0]!,
          id,
          providerProfileId: id,
        })),
      },
      capture: captureBinding(),
      dispatcher: {
        createResponses: async (config: { id: string }) => {
          calls.push(config.id);
          return {
            id: 'response',
            object: 'response',
            status: 'completed',
            output: [{ type: 'message', content: [{ type: 'output_text', text: 'Ready.' }] }],
          };
        },
      } as never,
      resolveGatewayProvider: (id) =>
        ({
          id,
          models: ['model'],
          gatewayCapabilities: { responses: 'native' },
          modelMetadata: {
            model: { tool_call: id === 'backup', limit: { context: 64_000, output: 8_000 } },
          },
        }) as never,
      promptCacheScope: { sessionId: 'admin', workspaceId: testEntityId('ws', 'workspace') },
      usageEndpoint: 'responses',
    });
    await expect(provider(request())).resolves.toMatchObject({
      message: { content: [{ type: 'text', text: 'Ready.' }] },
    });
    expect(calls).toEqual(['backup']);
  });

  it('validates a non-stream result before release and never replays invalid Tool arguments', async () => {
    const createResponses = vi.fn(async () => ({
      id: 'response',
      object: 'response',
      status: 'completed',
      output: [
        { type: 'function_call', call_id: 'call', name: 'environment_status', arguments: '{' },
      ],
    }));
    const onDispatch = vi.fn();
    const provider = createInternalAgentGatewayProvider({
      resolveLogicalModel(): ResolvedLogicalModel {
        return this.logicalModel;
      },
      logicalModel: {
        ...logicalModel,
        routes: ['primary', 'backup'].map((id) => ({
          ...logicalModel.routes[0]!,
          id,
          providerProfileId: id,
        })),
      },
      capture: captureBinding(),
      dispatcher: { createResponses } as never,
      onDispatch,
      resolveGatewayProvider: (id) =>
        ({
          id,
          models: ['model'],
          gatewayCapabilities: { responses: 'native' },
          modelMetadata: { model: { tool_call: true, limit: { context: 64_000, output: 8_000 } } },
        }) as never,
      promptCacheScope: { sessionId: 'admin', workspaceId: testEntityId('ws', 'workspace') },
      usageEndpoint: 'responses',
    });
    await expect(provider(request())).rejects.toThrow('Gateway returned invalid Tool arguments.');
    expect(createResponses).toHaveBeenCalledTimes(1);
    expect(onDispatch).not.toHaveBeenCalled();
  });
});

describe('Round 2 internal-role exhaustion cause', () => {
  it.each([
    { kind: 'rate_limited', attempts: 4 },
    { kind: 'provider_unavailable', attempts: 4 },
    { kind: 'auth_rejected', attempts: 1 },
    { kind: 'quota_exhausted', attempts: 1 },
    { kind: undefined, attempts: 0 },
    { kind: 'auth_rejected', attempts: 1, disabled: true },
    { kind: 'rate_limited', attempts: 4, disabled: true },
    { kind: 'context_overflow', attempts: 1 },
  ] as const)('propagates only the terminating kind: %j', async (scenario) => {
    const capture = captureBinding();
    vi.useFakeTimers();
    try {
      const disabled = 'disabled' in scenario;
      const terminal = scenario.kind === 'context_overflow';
      // The first member must advance with a kind distinct from the final member's kind.
      const primaryKind =
        disabled || terminal
          ? scenario.kind
          : scenario.kind === 'quota_exhausted'
            ? 'auth_rejected'
            : 'quota_exhausted';
      const primaryFailure = Object.assign(new Error('private primary marker=internal-secret'), {
        failure: { kind: primaryKind, settled: true },
      });
      const finalFailure = Object.assign(new Error('private backup marker=internal-secret'), {
        failure: { kind: scenario.kind, settled: true },
      });
      const calls: string[] = [];
      const createResponses = vi.fn(async (config: { id: string }) => {
        calls.push(config.id);
        throw config.id === 'primary' ? primaryFailure : finalFailure;
      });
      const provider = createInternalAgentGatewayProvider({
        resolveLogicalModel(): ResolvedLogicalModel {
          return this.logicalModel;
        },
        logicalModel: {
          ...logicalModel,
          autoFailover: !disabled,
          routes: ['primary', 'backup'].map((id) => ({
            ...logicalModel.routes[0]!,
            id,
            providerProfileId: id,
            available: scenario.kind !== undefined,
            unavailableReason:
              scenario.kind === undefined ? ('provider_profile_missing' as const) : null,
          })),
        },
        capture,
        dispatcher: { createResponses } as never,
        resolveGatewayProvider: (id) =>
          ({
            id,
            models: ['model'],
            gatewayCapabilities: { responses: 'native' },
            modelMetadata: {
              model: { tool_call: true, limit: { context: 64_000, output: 8_000 } },
            },
          }) as never,
        promptCacheScope: { sessionId: 'admin', workspaceId: testEntityId('ws', 'workspace') },
        usageEndpoint: 'responses',
      });
      const pending = provider(request()).catch((error: unknown) => error);
      await vi.runAllTimersAsync();
      const error = await pending;
      if (disabled || terminal) {
        expect(error).toHaveProperty('failure', primaryFailure.failure);
        expect(error).toHaveProperty('cause', primaryFailure);
      } else {
        expect(error).toBeInstanceOf(LogicalModelRoutesExhaustedError);
        expect(error).toMatchObject({
          code: 'gateway_logical_model_unavailable',
          message: 'Logical model is temporarily unavailable.',
        });
        if (scenario.kind !== undefined) expect(error).toHaveProperty('cause', scenario.kind);
        else expect(error).not.toHaveProperty('cause');
      }
      expect(calls.filter((id) => id === 'primary')).toHaveLength(
        scenario.kind === undefined ? 0 : disabled || terminal ? scenario.attempts : 1
      );
      expect(calls.filter((id) => id === 'backup')).toHaveLength(
        scenario.kind !== undefined && !disabled && !terminal ? scenario.attempts : 0
      );
    } finally {
      vi.useRealTimers();
    }
  });
});

describe('slice 1d internal logical call', () => {
  it('retains a failed call when every member is excluded before model dispatch', async () => {
    const capture = captureBinding();
    const createResponses = vi.fn();
    const resolveGatewayProvider = vi.fn();
    const provider = createInternalAgentGatewayProvider({
      resolveLogicalModel(): ResolvedLogicalModel {
        return this.logicalModel;
      },
      capture,
      logicalModel: {
        ...logicalModel,
        routes: logicalModel.routes.map((route) => ({
          ...route,
          available: false,
          unavailableReason: 'provider_profile_absent',
        })),
      },
      dispatcher: { createResponses } as never,
      resolveGatewayProvider,
      promptCacheScope: { sessionId: 'internal', workspaceId: capture.turn.workspaceId },
      usageEndpoint: 'responses',
      callContext: {
        workspaceId: capture.turn.workspaceId,
        authorityActor: capture.turn.triggerActor,
        agentId: 'administration',
        family: 'llm',
        operation: 'administration',
        capabilityId: 'inference.local.administration',
        redactionClass: 'metadata-only',
      },
    });
    await expect(provider(request())).rejects.toMatchObject({
      code: 'gateway_logical_model_unavailable',
    });
    const calls = listWorkspaceCapabilityCalls(capture.workspaceDb, capture.turn.workspaceId);
    expect(calls).toHaveLength(1);
    expect(calls[0]).toMatchObject({
      status: 'failed',
      errorCode: 'gateway_logical_model_unavailable',
      turnId: capture.turn.id,
      extensions: { 'openkit.gateway/routeLineage': { entries: [{ kind: 'unavailable' }] } },
    });
    expect(listWorkspaceUsageRecords(capture.workspaceDb, capture.turn.workspaceId)).toEqual([]);
    expect(
      readWorkObservations(capture.workspaceDb, capture).filter(
        (row) => row.type === 'model.observed'
      )
    ).toEqual([]);
    expect(createResponses).not.toHaveBeenCalled();
    expect(resolveGatewayProvider).not.toHaveBeenCalled();
  });
});

describe('slice 1d round 2 internal lifecycle', () => {
  for (const failed of [false, true])
    it(`ignores late usage after ${failed ? 'failed' : 'successful'} closeout`, async () => {
      const capture = captureBinding();
      let usageCallback: ((usage: unknown) => void) | undefined;
      const createResponses = vi.fn(async (_p, _r, context) => {
        usageCallback = context.onUsage;
        if (failed) throw new GatewayAttemptFailure({ kind: 'invalid_request', settled: true });
        return {
          id: 'resp_late',
          object: 'response',
          status: 'completed',
          model: 'model',
          output: [
            {
              type: 'message',
              role: 'assistant',
              status: 'completed',
              content: [{ type: 'output_text', text: 'served' }],
            },
          ],
        };
      });
      const provider = createInternalAgentGatewayProvider({
        resolveLogicalModel(): ResolvedLogicalModel {
          return this.logicalModel;
        },
        capture,
        logicalModel,
        dispatcher: { createResponses } as never,
        resolveGatewayProvider: () =>
          ({
            id: 'provider',
            models: ['model'],
            gatewayCapabilities: {},
            modelMetadata: {
              model: { tool_call: true, limit: { context: 64_000, output: 8_000 } },
            },
          }) as never,
        promptCacheScope: { sessionId: 'internal', workspaceId: capture.turn.workspaceId },
        usageEndpoint: 'responses',
        callContext: {
          workspaceId: capture.turn.workspaceId,
          authorityActor: capture.turn.triggerActor,
          family: 'llm',
          operation: 'administration',
          capabilityId: 'inference.local.administration',
          redactionClass: 'metadata-only',
        },
      });
      if (failed)
        await expect(provider(request())).rejects.toHaveProperty('failure.kind', 'invalid_request');
      else await provider(request());
      const read = () => ({
        calls: listWorkspaceCapabilityCalls(capture.workspaceDb, capture.turn.workspaceId),
        usage: listWorkspaceUsageRecords(capture.workspaceDb, capture.turn.workspaceId),
        rows: capture.workspaceDb.sqlite.prepare('SELECT * FROM capability_calls').all(),
      });
      const before = read();
      expect(usageCallback).toBeTypeOf('function');
      expect(() => usageCallback?.({ total_tokens: 42 })).not.toThrow();
      expect(read()).toEqual(before);
      capture.workspaceDb.sqlite.close();
      databases.splice(databases.indexOf(capture.workspaceDb), 1);
      expect(() => usageCallback?.({ total_tokens: 43 })).not.toThrow();
    });
  it('carries one absolute deadline through internal retry and failover', async () => {
    const capture = captureBinding();
    vi.useFakeTimers();
    const contexts: Array<Parameters<LLMGatewayProviderDispatcher['createResponses']>[2]> = [];
    const createResponses = vi.fn(async (_p, _r, context) => {
      contexts.push(context);
      if (contexts.length < 3)
        throw new GatewayAttemptFailure({
          kind: contexts.length === 1 ? 'rate_limited' : 'auth_rejected',
          settled: true,
        });
      return {
        id: 'resp_deadline',
        object: 'response',
        status: 'completed',
        model: 'model',
        output: [
          {
            type: 'message',
            role: 'assistant',
            status: 'completed',
            content: [{ type: 'output_text', text: 'served' }],
          },
        ],
      };
    });
    const provider = createInternalAgentGatewayProvider({
      resolveLogicalModel(): ResolvedLogicalModel {
        return this.logicalModel;
      },
      capture,
      logicalModel: {
        ...logicalModel,
        routes: [
          ...logicalModel.routes,
          { ...logicalModel.routes[0]!, id: 'backup', providerProfileId: 'backup' },
        ],
      },
      dispatcher: { createResponses } as never,
      resolveGatewayProvider: (id) =>
        ({
          id,
          models: ['model'],
          gatewayCapabilities: {},
          modelMetadata: { model: { tool_call: true, limit: { context: 64_000, output: 8_000 } } },
        }) as never,
      promptCacheScope: { sessionId: 'internal', workspaceId: capture.turn.workspaceId },
      usageEndpoint: 'responses',
    });
    try {
      const before = Date.now();
      const pending = provider(request());
      await vi.runAllTimersAsync();
      await pending;
      expect(createResponses.mock.calls.map(([p]) => p.id)).toEqual([
        'provider',
        'provider',
        'backup',
      ]);
      expect(contexts.map((c) => c?.transport?.deadline)).toEqual([
        before + 120000,
        before + 120000,
        before + 120000,
      ]);
    } finally {
      vi.useRealTimers();
    }
  });
});

describe('internal rolling context Gateway boundary', () => {
  const completeResponse = {
    id: 'context_answer',
    object: 'response',
    status: 'completed',
    output: [
      { type: 'message', role: 'assistant', content: [{ type: 'output_text', text: 'Ready.' }] },
    ],
  };

  /** Binds the real projection while leaving only outer Provider transport under test control. */
  function boundaryFixture(
    admitted = logicalModel,
    current = () => admitted,
    limit: { context?: number; output?: number } = { context: 64_000, output: 8_000 }
  ) {
    const createResponses = vi.fn().mockResolvedValue(completeResponse);
    const resolveLogicalModel = vi.fn(current);
    const resolveGatewayProvider = vi.fn(() => ({
      id: 'provider',
      models: ['model'],
      gatewayCapabilities: { responses: 'native' },
      modelMetadata: { model: { tool_call: true, limit } },
    }));
    const provider = createInternalAgentGatewayProvider({
      capture: captureBinding(),
      logicalModel: admitted,
      resolveLogicalModel,
      dispatcher: { createResponses },
      resolveGatewayProvider: resolveGatewayProvider as never,
      promptCacheScope: {
        sessionId: 'rolling-context',
        workspaceId: testEntityId('ws', 'workspace'),
      },
      usageEndpoint: 'responses',
    });
    return { provider, createResponses, resolveLogicalModel, resolveGatewayProvider };
  }

  it('dispatches an assembled window above the authored compaction threshold without a compactor', async () => {
    const admitted = {
      ...logicalModel,
      contextManagement: { type: 'compaction' as const, compactThreshold: 100 },
    };
    let current = admitted;
    const { provider, createResponses, resolveLogicalModel } = boundaryFixture(
      admitted,
      () => current
    );
    const assembled = request('Retain this admitted source. '.repeat(400));
    const before = structuredClone(assembled.messages);

    await expect(provider(assembled)).resolves.toMatchObject({
      message: { content: [{ type: 'text', text: 'Ready.' }] },
    });
    current = {
      ...admitted,
      contextManagement: { type: 'compaction', compactThreshold: 200 },
    };
    await expect(provider(assembled)).resolves.toMatchObject({
      message: { content: [{ type: 'text', text: 'Ready.' }] },
    });

    expect(resolveLogicalModel.mock.calls).toEqual([['assistant'], ['assistant']]);
    expect(createResponses).toHaveBeenCalledTimes(2);
    for (const [, payload] of createResponses.mock.calls) {
      expect(payload).not.toHaveProperty('context_management');
      expect(payload).not.toHaveProperty('previous_response_id');
      expect(payload.input).toEqual([
        { role: 'user', content: [{ type: 'input_text', text: before[0]!.content[0]!.text }] },
      ]);
    }
    expect(assembled.messages).toEqual(before);
  });

  it.each([
    'messages',
    'prompt',
    'schema',
  ] as const)('rejects physical overflow from %s before Provider dispatch', async (component) => {
    const { provider, createResponses } = boundaryFixture(logicalModel, undefined, {
      context: 16_000,
      output: 2_000,
    });
    const large = 'Required source constraint and exact continuation reference. '.repeat(16_000);
    const assembled = {
      ...request(component === 'messages' ? large : 'Read status.'),
      ...(component === 'prompt' ? { systemPrompt: large } : {}),
      ...(component === 'schema'
        ? {
            tools: [
              { ...request().tools[0]!, inputSchema: { type: 'object', description: large } },
            ],
          }
        : {}),
    };
    const before = structuredClone(assembled.messages);

    await expect(provider(assembled)).rejects.toMatchObject({
      code: 'internal_agent_context_exceeded',
    });

    expect(createResponses).not.toHaveBeenCalled();
    expect(assembled.messages).toEqual(before);
  });

  it('reserves known output capacity when fitting an otherwise admissible request', async () => {
    const limit = { context: 16_000, output: 1_000 };
    const { provider, createResponses } = boundaryFixture(logicalModel, undefined, limit);
    const assembled = request('Current source fact. '.repeat(400));

    await expect(provider(assembled)).resolves.toMatchObject({ message: { role: 'assistant' } });
    limit.output = 15_000;
    await expect(provider(assembled)).rejects.toMatchObject({
      code: 'internal_agent_context_exceeded',
    });

    expect(createResponses).toHaveBeenCalledTimes(1);
  });

  it.each([
    { admittedOutput: 2_000, expectedOutput: 2_000 },
    { admittedOutput: null, expectedOutput: 8_000 },
  ])('caps model output at the known admitted or member limit: %j', async ({
    admittedOutput,
    expectedOutput,
  }) => {
    const admitted: ResolvedLogicalModel = {
      ...logicalModel,
      contract: { context: 64_000, output: admittedOutput, inputModalities: null, reasoning: null },
    };
    const { provider, createResponses } = boundaryFixture(admitted);

    await expect(provider(request())).resolves.toMatchObject({ message: { role: 'assistant' } });

    expect(createResponses).toHaveBeenCalledTimes(1);
    expect(createResponses.mock.calls[0]![1]).toMatchObject({
      model: 'model',
      max_output_tokens: expectedOutput,
    });
  });

  it('enforces the admitted logical window when the selected member has more physical capacity', async () => {
    const admitted: ResolvedLogicalModel = {
      ...logicalModel,
      contextManagement: { type: 'compaction', compactThreshold: 1_000 },
      contract: { context: 8_000, output: 2_000, inputModalities: null, reasoning: null },
    };
    const { provider, createResponses } = boundaryFixture(admitted, undefined, {
      context: 128_000,
      output: 2_000,
    });
    const initial = request(
      'Exact retained continuation fact and required source boundary. '.repeat(1_400)
    );
    const before = structuredClone(initial.messages);

    const result = await runInternalAgentLoop(
      {
        ...initial,
        tools: [],
        limits: { maxModelTurns: 2, maxToolCalls: 1, deadlineMs: 5_000 },
      },
      provider
    );

    expect(result.kind).toBe('failed');
    expect(result).toMatchObject({ code: 'internal_agent_context_exceeded' });
    expect(result.messages).toEqual(before);
    expect(createResponses).not.toHaveBeenCalled();
    expect(initial.messages).toEqual(before);
  });

  it('rejects a Provider compaction item without accepting its summary or ordinary output', async () => {
    const { provider, createResponses } = boundaryFixture();
    createResponses.mockResolvedValueOnce({
      ...completeResponse,
      output: [
        ...completeResponse.output,
        {
          type: 'compaction',
          id: 'provider-checkpoint',
          summary: 'Provider-owned history replacement.',
        },
      ],
    });
    const initial = request();
    const before = structuredClone(initial.messages);

    const result = await runInternalAgentLoop(
      {
        ...initial,
        tools: [],
        limits: { maxModelTurns: 2, maxToolCalls: 1, deadlineMs: 5_000 },
      },
      provider
    );

    expect(result).toEqual({ kind: 'failed', code: 'provider_response_invalid', messages: before });
    expect(createResponses).toHaveBeenCalledTimes(1);
    expect(initial.messages).toEqual(before);
  });

  it('fails closed when no physical context limit can be established', async () => {
    const { provider, createResponses } = boundaryFixture(logicalModel, undefined, {});

    await expect(provider(request())).rejects.toMatchObject({
      code: 'internal_agent_context_unavailable',
    });

    expect(createResponses).not.toHaveBeenCalled();
  });

  it('returns a safe failure for later overflow without trimming observations or replaying a Tool', async () => {
    const { provider, createResponses } = boundaryFixture(logicalModel, undefined, {
      context: 16_000,
      output: 2_000,
    });
    const observation = 'Required observed state and pending work. '.repeat(16_000);
    const execute = vi.fn(async () => ({
      content: [{ type: 'text' as const, text: observation }],
    }));
    createResponses.mockResolvedValueOnce({
      id: 'context_tool',
      object: 'response',
      status: 'completed',
      output: [
        {
          type: 'function_call',
          call_id: 'effect_once',
          name: 'environment_status',
          arguments: '{}',
        },
      ],
    });
    const initial = request();
    const before = structuredClone(initial.messages);

    const result = await runInternalAgentLoop(
      {
        ...initial,
        tools: [{ ...initial.tools[0]!, execute }],
        limits: { maxModelTurns: 3, maxToolCalls: 2, deadlineMs: 5_000 },
      },
      provider
    );

    expect(result).toMatchObject({ kind: 'failed', code: 'internal_agent_context_exceeded' });
    expect(createResponses).toHaveBeenCalledTimes(1);
    expect(execute).toHaveBeenCalledTimes(1);
    expect(initial.messages).toEqual(before);
    expect(result.messages).toEqual([
      ...before,
      {
        role: 'assistant',
        truncated: false,
        content: [
          { type: 'toolCall', callId: 'effect_once', name: 'environment.status', arguments: {} },
        ],
      },
      {
        role: 'tool',
        callId: 'effect_once',
        content: [{ type: 'text', text: observation }],
        isError: false,
      },
    ]);
  });

  it('keeps the admitted model identity and known physical minimums across current resolution', async () => {
    const admitted: ResolvedLogicalModel = {
      ...logicalModel,
      contract: { context: 64_000, output: 8_000, inputModalities: null, reasoning: null },
    };
    const limit = { context: 64_000, output: 8_000 };
    const { provider, createResponses, resolveLogicalModel } = boundaryFixture(
      admitted,
      () => ({ ...admitted, contract: { ...admitted.contract!, context: 16_000 } }),
      limit
    );

    await expect(provider(request())).resolves.toMatchObject({ message: { role: 'assistant' } });
    limit.context = 16_000;
    await expect(provider(request())).rejects.toMatchObject({
      code: 'gateway_logical_model_unavailable',
    });
    await expect(
      provider({ ...request(), model: { ...request().model, logicalModelId: 'another-model' } })
    ).rejects.toThrow('Internal Agent logical model changed after admission.');

    expect(resolveLogicalModel.mock.calls).toEqual([['assistant'], ['assistant']]);
    expect(createResponses).toHaveBeenCalledTimes(1);
  });
});

describe('command audit lineage at the internal Gateway seam', () => {
  const commandRequestId = '00000000-0000-4000-8000-000000000144';

  /** Composes real capture, Gateway, usage and audit writers; only model transport is injected. */
  function auditFixture(
    auditLineage?: CapabilityAuditLineage,
    storedRequestId: string | null = null
  ) {
    const capture = captureBinding();
    const createResponses = vi
      .fn<LLMGatewayProviderDispatcher['createResponses']>()
      .mockResolvedValue({
        id: 'response-audit',
        object: 'response',
        status: 'completed',
        output: [
          {
            type: 'message',
            role: 'assistant',
            status: 'completed',
            content: [{ type: 'output_text', text: 'Audited answer.' }],
          },
        ],
        usage: { input_tokens: 9, output_tokens: 3, total_tokens: 12 },
      });
    const options = {
      capture,
      logicalModel,
      resolveLogicalModel: () => logicalModel,
      dispatcher: { createResponses },
      resolveGatewayProvider: () =>
        ({
          id: 'provider',
          models: ['model'],
          gatewayCapabilities: {},
          modelMetadata: { model: { tool_call: true, limit: { context: 64_000, output: 8_000 } } },
        }) as never,
      promptCacheScope: { sessionId: capture.threadId, workspaceId: capture.turn.workspaceId },
      usageEndpoint: 'responses' as const,
      callContext: {
        workspaceId: capture.turn.workspaceId,
        authorityActor: capture.turn.triggerActor,
        agentId: 'assistant',
        family: 'llm' as const,
        operation: 'quick_chat',
        capabilityId: 'inference.local.quick_chat',
        redactionClass: 'metadata-only',
        requestId: storedRequestId,
      },
      ...(auditLineage === undefined ? {} : { auditLineage }),
    };
    return { capture, createResponses, provider: createInternalAgentGatewayProvider(options) };
  }

  it.each([
    {
      label: 'without command context',
      lineage: undefined,
      storedRequestId: null,
      expectedAuditRequest: null,
    },
    {
      label: 'with command context',
      lineage: { commandRequestId },
      storedRequestId: null,
      expectedAuditRequest: commandRequestId,
    },
    {
      label: 'with an existing non-null call request',
      lineage: { commandRequestId },
      storedRequestId: '00000000-0000-4000-8000-000000000145',
      expectedAuditRequest: '00000000-0000-4000-8000-000000000145',
    },
  ])('preserves success attribution $label', async ({
    lineage,
    storedRequestId,
    expectedAuditRequest,
  }) => {
    const f = auditFixture(lineage, storedRequestId);

    await f.provider(request());

    const calls = listWorkspaceCapabilityCalls(f.capture.workspaceDb, f.capture.turn.workspaceId);
    expect(calls).toHaveLength(1);
    expect(calls[0]).toMatchObject({
      requestId: storedRequestId,
      status: 'succeeded',
      threadId: f.capture.threadId,
      turnId: f.capture.turnId,
    });
    expect(listWorkspaceUsageRecords(f.capture.workspaceDb, f.capture.turn.workspaceId)).toEqual([
      expect.objectContaining({
        requestId: storedRequestId,
        capabilityCallId: calls[0]!.id,
        responsibleUserId: 'usr_00000000-0000-7000-8000-000000000001',
        threadId: f.capture.threadId,
        turnId: f.capture.turnId,
        quantity: 12,
      }),
    ]);
    expect(
      f.capture.workspaceDb.sqlite
        .prepare('SELECT * FROM audit_events WHERE capability_call_id = ?')
        .all(calls[0]!.id)
    ).toEqual([
      expect.objectContaining({
        action: 'capability.finish',
        request_id: expectedAuditRequest,
        capability_call_id: calls[0]!.id,
        thread_id: f.capture.threadId,
        turn_id: f.capture.turnId,
        outcome: 'succeeded',
      }),
    ]);
  });

  it('retains the command audit request when inference fails', async () => {
    const f = auditFixture({ commandRequestId });
    const error = new GatewayAttemptFailure({ kind: 'invalid_request', settled: true });
    f.createResponses.mockRejectedValue(error);
    vi.spyOn(console, 'warn').mockImplementation(() => {});

    await expect(f.provider(request())).rejects.toHaveProperty('failure.kind', 'invalid_request');

    expect(f.createResponses).toHaveBeenCalledOnce();
    const calls = listWorkspaceCapabilityCalls(f.capture.workspaceDb, f.capture.turn.workspaceId);
    expect(calls).toHaveLength(1);
    expect(calls[0]).toMatchObject({ requestId: null, status: 'failed' });
    expect(listWorkspaceUsageRecords(f.capture.workspaceDb, f.capture.turn.workspaceId)).toEqual(
      []
    );
    expect(
      f.capture.workspaceDb.sqlite
        .prepare('SELECT * FROM audit_events WHERE capability_call_id = ?')
        .all(calls[0]!.id)
    ).toEqual([
      expect.objectContaining({
        action: 'capability.finish',
        request_id: commandRequestId,
        capability_call_id: calls[0]!.id,
        workspace_id: f.capture.turn.workspaceId,
        thread_id: f.capture.threadId,
        turn_id: f.capture.turnId,
        outcome: 'failed',
      }),
    ]);
  });

  it.each([
    'reported-callback',
    'successful-response',
  ] as const)('retains command audit lineage when the %s usage write fails', async (boundary) => {
    const f = auditFixture({ commandRequestId });
    f.capture.workspaceDb.sqlite.exec(`
      CREATE TRIGGER reject_gateway_usage_write
      BEFORE INSERT ON usage_records
      BEGIN
        SELECT RAISE(ABORT, 'injected Gateway usage write failure');
      END
    `);
    if (boundary === 'reported-callback') {
      f.createResponses.mockImplementation(async (_provider, _input, context) => {
        context?.onUsage?.({ input_tokens: 9, output_tokens: 3, total_tokens: 12 });
        throw new Error('The failed usage callback must not return.');
      });
    }
    vi.spyOn(console, 'warn').mockImplementation(() => {});

    await expect(f.provider(request())).rejects.toBeInstanceOf(Error);

    expect(f.createResponses).toHaveBeenCalledOnce();
    const calls = listWorkspaceCapabilityCalls(f.capture.workspaceDb, f.capture.turn.workspaceId);
    expect(calls).toHaveLength(1);
    expect(calls[0]).toMatchObject({
      requestId: null,
      status: 'failed',
      errorCode: 'usage_record_failed',
    });
    expect(listWorkspaceUsageRecords(f.capture.workspaceDb, f.capture.turn.workspaceId)).toEqual(
      []
    );
    expect(
      f.capture.workspaceDb.sqlite
        .prepare('SELECT * FROM audit_events WHERE capability_call_id = ?')
        .all(calls[0]!.id)
    ).toEqual([
      expect.objectContaining({
        action: 'capability.finish',
        capability_call_id: calls[0]!.id,
        request_id: commandRequestId,
        workspace_id: f.capture.turn.workspaceId,
        thread_id: f.capture.threadId,
        turn_id: f.capture.turnId,
        outcome: 'failed',
        error_code: 'usage_record_failed',
      }),
    ]);
  });
});
