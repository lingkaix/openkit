import { WorkspaceChangeSetSchema } from '@openkit/app-api-schemas';
import type { AgentEnvironmentPackage } from '@openkit/config-schema';
import { workerSessionInputPaths } from '@openkit/worker-protocol';
import { describe, expect, it } from 'vitest';
import { createTestAgentSetup } from '../test-support/agent-environment.js';
import { createDemoStore } from '../test-support/demo-store.js';
import { testEntityId } from '../test-support/entity-ids.js';
import { resolveAgentEnvironmentPackage } from '../test-support/prepared-agent-environment.js';
import {
  buildWorkspaceInputSnapshots,
  buildWorkspaceMaterializationRecords,
  stageWorkspaceChangeSet,
} from './workspace-materializer.js';

describe('workspace materializer records', () => {
  it('builds product-safe input snapshots from an Agent Environment Package', () => {
    const store = createDemoStore();
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      'th_00000000-0000-7000-8000-000000000001',
      'Update docs',
      {
        kind: 'user',
        id: 'usr_00000000-0000-7000-8000-000000000001',
      }
    );
    const environmentPackage = resolveAgentEnvironmentPackage({
      agentSetup: createTestAgentSetup(),
      agentSessionId: testEntityId('as', 'session_1'),
      triggerActor: turn.triggerActor,
      userId: 'usr_00000000-0000-7000-8000-000000000001',
      backend: {
        kind: 'openshell',
      },
      createdAt: '2026-06-27T00:00:00.000Z',
      requestId: 'req_1',
      turn,
      turnInput: 'Update docs',
      workspaceCwd: null,
      workspaceSourceRefs: { repo: 'repo' },
      workspaceDataSourceCatalog: {
        schemaVersion: 1,
        sources: [
          {
            id: 'repo',
            displayName: 'Repository',
            kind: 'git',
            locator: { commit: 'a'.repeat(40), url: 'https://example.invalid/materializer.git' },
            access: 'read-write',
            allowedSlotKinds: ['worktree'],
            sensitivity: 'internal',
            status: 'active',
          },
        ],
      },
      workspaceRoots: [
        {
          access: 'read-write',
          id: 'repo',
          sourceKind: 'remote-git',
          sourceCommit: 'a'.repeat(40),
          workerPath: '/workspace/openkit',
        },
      ],
    });

    const snapshots = buildWorkspaceInputSnapshots({
      backendCapabilities: ['git-materialization', 'change-set-collection'],
      backendKind: 'openshell',
      createdAt: '2026-06-27T01:00:00.000Z',
      environmentPackage,
    });

    expect(snapshots).toEqual([
      expect.objectContaining({
        backend: {
          capabilitySummary: ['git-materialization', 'change-set-collection'],
          kind: 'openshell',
          label: 'openshell worker backend',
        },
        createdAt: '2026-06-27T01:00:00.000Z',
        pathScope: ['repo'],
        resourceId: 'repo',
        strategy: 'git',
        writableRoots: ['repo'],
      }),
    ]);
    expect(JSON.stringify(snapshots)).not.toContain('/Users/m5pro');
  });

  it('builds the exact S39 context handoff without changing generated near misses', () => {
    const store = createDemoStore();
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      'th_00000000-0000-7000-8000-000000000001',
      'Use the accepted context package',
      {
        kind: 'user',
        id: 'usr_00000000-0000-7000-8000-000000000001',
      }
    );
    const packageRootDigest = `sha256:${'a'.repeat(64)}`;
    const environmentPackage = resolveAgentEnvironmentPackage({
      agentSetup: createTestAgentSetup(),
      agentSessionId: testEntityId('as', 'session_context_1'),
      triggerActor: turn.triggerActor,
      userId: 'usr_00000000-0000-7000-8000-000000000001',
      backend: {
        kind: 'openshell',
      },
      createdAt: '2026-07-18T01:00:00.000Z',
      requestId: 'req_context_1',
      turn,
      turnInput: 'Use the accepted context package',
      workspaceCwd: null,
      workspaceRoots: [],
    });
    const contextRoot = workerSessionInputPaths(
      environmentPackage.scope.agentSessionId
    ).contextRoot;
    const contextInput: AgentEnvironmentPackage['workspace']['inputs'][number] = {
      access: 'read-only',
      id: `context_${turn.id}`,
      kind: 'generated',
      materialization: {
        contentDigest: packageRootDigest,
        slotId: 'context',
        strategy: 'filesystem',
      },
      source: {
        kind: 'generated',
        pathRef: `threads/${turn.threadId}/turns/${turn.id}/context-package`,
      },
      target: contextRoot,
    };
    const nearMissInput: AgentEnvironmentPackage['workspace']['inputs'][number] = {
      ...contextInput,
      id: `context_${turn.id}_near_miss`,
      target: '/openkit/turn-inputs/context',
    };
    const withContextInputs: AgentEnvironmentPackage = {
      ...environmentPackage,
      workspace: {
        ...environmentPackage.workspace,
        generatedFiles: [
          {
            access: 'read-only',
            contentRef: 'inline://worker-request',
            id: 'worker_request',
            target: '/openkit/turn-inputs/request.json',
          },
        ],
        inputs: [contextInput, nearMissInput],
      },
    };
    const snapshots = buildWorkspaceInputSnapshots({
      backendCapabilities: ['filesystem-materialization', 'backend-only-capability'],
      backendKind: 'openshell',
      createdAt: '2026-07-18T01:01:00.000Z',
      environmentPackage: withContextInputs,
    });
    const contextSnapshot = snapshots[0];
    const nearMissSnapshot = snapshots[1];

    expect(contextSnapshot).toEqual({
      backend: {
        capabilitySummary: withContextInputs.backend.requiredCapabilities,
        kind: 'openshell',
        label: 'openshell worker backend',
      },
      base: { commit: null, contentDigest: packageRootDigest },
      createdAt: '2026-07-18T01:01:00.000Z',
      generatedFiles: [],
      id: `wis_${environmentPackage.snapshotId}_context_${turn.id}`,
      ignoredPaths: [],
      pathScope: [`context_${turn.id}`],
      resourceId: `context_${turn.id}`,
      resourceKind: 'filesystem',
      strategy: 'filesystem',
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
      writableRoots: [],
    });
    expect(nearMissSnapshot).toMatchObject({
      backend: {
        capabilitySummary: ['filesystem-materialization', 'backend-only-capability'],
        kind: 'openshell',
        label: 'openshell worker backend',
      },
      generatedFiles: [{ id: 'worker_request', target: 'openkit/turn-inputs/request.json' }],
      resourceKind: 'git_repository',
      strategy: 'git',
    });

    const records = buildWorkspaceMaterializationRecords({
      createdAt: '2026-07-18T01:02:00.000Z',
      inputSnapshots: snapshots,
      materialization: {
        backendKind: 'openshell',
        backendStatus: { health: 'ready', version: '0.0.80' },
        packageSnapshotId: environmentPackage.snapshotId,
        requiredCapabilities: ['filesystem-materialization'],
        sandbox: { name: 'backend_session_context_1', state: 'created' },
        workspaceInputs: [
          { id: contextInput.id, target: contextInput.target },
          { id: nearMissInput.id, target: nearMissInput.target },
        ],
      },
    });

    expect(records[0]).toMatchObject({
      backendKind: 'openshell',
      base: { commit: null, contentDigest: packageRootDigest },
      createdAt: '2026-07-18T01:01:00.000Z',
      id: `wmr_${environmentPackage.snapshotId}_context_${turn.id}`,
      inputSnapshotId: `wis_${environmentPackage.snapshotId}_context_${turn.id}`,
      materializedRootRef: contextRoot,
      packageSnapshotId: environmentPackage.snapshotId,
      strategy: 'filesystem',
      workerSessionId: 'backend_session_context_1',
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
    });
    expect(records[0]).not.toHaveProperty('sourceId');
    expect(records[1]).toMatchObject({
      createdAt: '2026-07-18T01:02:00.000Z',
      materializedRootRef: '/openkit/turn-inputs/context',
      strategy: 'git',
    });
  });

  it('carries catalog source ids into workspace lineage records', () => {
    const store = createDemoStore();
    const turn = store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      'th_00000000-0000-7000-8000-000000000001',
      'Update docs from catalog source',
      {
        kind: 'user',
        id: 'usr_00000000-0000-7000-8000-000000000001',
      }
    );
    const environmentPackage = resolveAgentEnvironmentPackage({
      agentSetup: createTestAgentSetup(),
      agentSessionId: testEntityId('as', 'session_source_1'),
      triggerActor: turn.triggerActor,
      userId: 'usr_00000000-0000-7000-8000-000000000001',
      backend: {
        kind: 'openshell',
      },
      createdAt: '2026-06-27T00:00:00.000Z',
      requestId: 'req_source_1',
      turn,
      workspaceCwd: null,
      workspaceDataSourceCatalog: {
        schemaVersion: 1,
        sources: [
          {
            access: 'read-write',
            allowedSlotKinds: ['worktree'],
            displayName: 'Main repository',
            id: 'repo_default',
            kind: 'git',
            locator: { commit: 'a'.repeat(40), url: 'https://example.invalid/materializer.git' },
            sensitivity: 'internal',
            status: 'active',
          },
        ],
      },
      workspaceRoots: [
        {
          access: 'read-write',
          id: 'repo_default',
          sourceKind: 'remote-git',
          sourceCommit: 'a'.repeat(40),
          workerPath: '/workspace/openkit',
        },
      ],
      workspaceSourceRefs: { repo_default: 'repo_default' },
    });
    const snapshots = buildWorkspaceInputSnapshots({
      backendCapabilities: ['git-materialization'],
      backendKind: 'openshell',
      createdAt: '2026-06-27T01:00:00.000Z',
      environmentPackage,
    });
    const records = buildWorkspaceMaterializationRecords({
      createdAt: '2026-06-27T01:01:00.000Z',
      inputSnapshots: snapshots,
      materialization: {
        backendKind: 'openshell',
        packageSnapshotId: 'pkg_source_1',
        requiredCapabilities: ['container'],
        workspaceInputs: [{ id: 'repo_default', target: '/workspace/openkit' }],
      },
    });

    expect(snapshots[0]).toMatchObject({ resourceId: 'repo_default', sourceId: 'repo_default' });
    expect(records[0]).toMatchObject({
      inputSnapshotId: snapshots[0]?.id,
      sourceId: 'repo_default',
    });
  });

  it('builds product-safe materialization records from backend summaries', () => {
    const snapshots = [
      {
        backend: {
          capabilitySummary: ['git-materialization'],
          kind: 'openshell',
          label: 'openshell worker backend',
        },
        base: { commit: 'abc123', contentDigest: null },
        createdAt: '2026-06-27T01:00:00.000Z',
        generatedFiles: [],
        id: 'wis_pkg_1_repo',
        ignoredPaths: [],
        pathScope: ['repo'],
        resourceId: 'repo',
        resourceKind: 'git_repository',
        strategy: 'git',
        workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
        writableRoots: ['repo'],
      },
    ] as const;

    const records = buildWorkspaceMaterializationRecords({
      createdAt: '2026-06-27T01:01:00.000Z',
      inputSnapshots: snapshots,
      materialization: {
        backendKind: 'openshell',
        backendStatus: { health: 'ready', version: '0.0.63' },
        packageSnapshotId: 'pkg_1',
        requiredCapabilities: ['container', 'transcript-sink'],
        sandbox: { name: 'sandbox_pkg_1', state: 'created' },
        workspaceInputs: [{ id: 'repo', target: '/workspace/openkit' }],
      },
    });

    expect(records).toEqual([
      expect.objectContaining({
        backendKind: 'openshell',
        id: 'wmr_pkg_1_repo',
        inputSnapshotId: 'wis_pkg_1_repo',
        materializedRootRef: '/workspace/openkit',
        packageSnapshotId: 'pkg_1',
        strategy: 'git',
        workerSessionId: 'sandbox_pkg_1',
      }),
    ]);
    expect(records[0]?.policyDigest).toMatch(/^sha256:/);
    expect(records[0]?.readinessEvidence).toEqual([
      { kind: 'backend.ready', ref: 'version:0.0.63' },
      { kind: 'sandbox.created', ref: 'sandbox_pkg_1' },
    ]);
    expect(JSON.stringify(records)).not.toContain('/Users/m5pro');
  });

  it('stages parsed change sets as pending workspace reviews', () => {
    const patchText = [
      'diff --git a/docs/spec.md b/docs/spec.md',
      '--- a/docs/spec.md',
      '+++ b/docs/spec.md',
      '@@ -1 +1,3 @@',
      '-Old finding',
      '+- Root finding',
      '+- First child finding',
      '+- Second child finding',
      '',
    ].join('\n');
    const changeSet = WorkspaceChangeSetSchema.parse({
      id: 'wcs_1',
      materializationRecordId: 'wmr_1',
      inputSnapshotId: 'wis_1',
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
      resourceId: 'repo',
      strategy: 'git',
      base: { commit: 'abc123', contentDigest: null },
      head: { commit: 'def456', contentDigest: null },
      changedPaths: [{ path: 'docs/spec.md', status: 'modified', binary: false }],
      patch: { ref: 'artifact://patch', digest: 'sha256:patch', bytes: 1200 },
      bundle: null,
      artifactIds: ['ar_00000000-0000-7f26-8292-8ac950dddeba'],
      evidenceRefs: [{ kind: 'test', ref: 'ev_test' }],
      redaction: { status: 'redacted', notes: [] },
      createdAt: '2026-06-27T01:00:00.000Z',
    });

    expect(
      stageWorkspaceChangeSet(changeSet, {
        createdAt: '2026-06-27T01:05:00.000Z',
        patchPayload: {
          bytes: Buffer.byteLength(patchText, 'utf8'),
          digest: 'sha256:patch',
          mediaType: 'text/x-diff',
          text: patchText,
        },
        reviewId: 'swr_1',
        stagingRef: 'staging://workspace/swr_1',
      })
    ).toMatchObject({
      actionCenterRowId: 'workspace-review:swr_1',
      changeSetId: 'wcs_1',
      diffSummary: { additions: 3, deletions: 1, filesChanged: 1 },
      status: 'pending',
    });
  });
});
