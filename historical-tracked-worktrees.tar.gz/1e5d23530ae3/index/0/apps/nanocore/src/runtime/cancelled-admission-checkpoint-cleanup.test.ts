import {
  appendFileSync,
  existsSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  unlinkSync,
  writeFileSync,
} from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { AgentEnvironmentPackageSchema } from '@openkit/config-schema';
import Database from 'better-sqlite3';
import { describe, expect, it } from 'vitest';
import { acquireDataRootLock } from '../bootstrap/lock.js';
import { FsStore } from '../lib/store.js';
import {
  cancelSchedulerAdmissionEntry,
  createSchedulerAdmissionEntry,
} from '../scheduler-records.js';
import { type CoreDb, openCoreDb, openWorkspaceDb, type WorkspaceDb } from '../storage/db.js';
import { applyMigrations, applyScopedMigrations } from '../storage/migrate.js';
import { createTestAgentSetup } from '../test-support/agent-environment.js';
import { testEntityId } from '../test-support/entity-ids.js';
import {
  ensureLocalUser,
  FIXTURE_LOCAL_USER_ID as LOCAL_USER_ID,
} from '../test-support/local-user.js';
import { resolveAgentEnvironmentPackage } from '../test-support/prepared-agent-environment.js';
import { recordWorkspaceOwnerMembership } from '../workspace-membership.js';
import { recordAgentEnvironmentPackageSnapshot } from './aep-snapshot-ledger.js';
import { cleanCancelledAdmissionTaskCheckpoints } from './cancelled-admission-checkpoint-cleanup.js';
import {
  bindSchedulerExecutionAttemptSession,
  closeSchedulerExecutionAttemptWithoutEffects,
  createSchedulerExecutionAttempt,
} from './execution-attempt-records.js';
import { getWorkerCheckpoint, upsertWorkerCheckpoint } from './worker-checkpoints.js';

const ACTOR = { kind: 'user' as const, id: LOCAL_USER_ID };

/** Opens a stopped data root with one Workspace, Thread, and migrated databases. */
function createFixture(): {
  readonly backupRoot: string;
  readonly coreDb: CoreDb;
  readonly dataRoot: string;
  readonly store: FsStore;
  readonly threadId: string;
  readonly workspaceDb: WorkspaceDb;
  readonly workspaceId: string;
} {
  const dataRoot = mkdtempSync(join(tmpdir(), 'openkit-checkpoint-cleanup-'));
  const backupRoot = mkdtempSync(join(tmpdir(), 'openkit-checkpoint-cleanup-backup-'));
  const coreDb = openCoreDb(dataRoot);
  applyMigrations(coreDb);

  const store = new FsStore({ dataRoot });
  const workspace = store.createWorkspace('Checkpoint cleanup');
  ensureLocalUser(coreDb);
  recordWorkspaceOwnerMembership({ coreDb, workspaceId: workspace.id, ownerUserId: LOCAL_USER_ID });
  const thread = store.createThread(workspace.id, 'Checkpoint cleanup thread');
  const workspaceDb = openWorkspaceDb(dataRoot, workspace.id);
  applyScopedMigrations(workspaceDb);
  return {
    backupRoot,
    coreDb,
    dataRoot,
    store,
    threadId: thread.id,
    workspaceDb,
    workspaceId: workspace.id,
  };
}

/** Closes fixture databases so the maintenance command can lock the data root. */
function closeFixture(fixture: {
  readonly coreDb: CoreDb;
  readonly workspaceDb: WorkspaceDb;
}): void {
  fixture.workspaceDb.sqlite.close();
  fixture.coreDb.sqlite.close();
}

/** Records one failed direct Task checkpoint with no Worker session. */
function writeFailedCheckpoint(
  workspaceDb: WorkspaceDb,
  input: {
    readonly goalId?: string | null;
    readonly requestId: string;
    readonly stage?: 'failed' | 'preparing';
    readonly threadId: string;
    readonly turnId: string;
    readonly workerSessionId?: string | null;
    readonly workspaceId: string;
    readonly contextDigest?: string | null;
  }
): void {
  upsertWorkerCheckpoint(workspaceDb, {
    contextDigest: input.contextDigest ?? null,
    goalId: input.goalId ?? null,
    iteration: 0,
    requestId: input.requestId,
    requestInputHash: `sha256:${input.requestId}`,
    stage: input.stage ?? 'failed',
    stopReason: input.stage === 'preparing' ? null : 'error',
    taskId: null,
    threadId: input.threadId,
    turnId: input.turnId,
    workerSessionId: input.workerSessionId ?? null,
    workspaceId: input.workspaceId,
  });
}

/** Records one cancelled admission and no attempt for a missing Turn. */
function writeCancelledAdmission(
  coreDb: CoreDb,
  input: {
    readonly requestId: string;
    readonly threadId: string;
    readonly turnId: string;
    readonly workspaceId: string;
  }
): void {
  const queueEntryId = `queue_${input.turnId}`;
  createSchedulerAdmissionEntry(coreDb, {
    backendId: 'nanohost',
    profileRef: 'agent_codex_host',
    queueEntryId,
    requestId: input.requestId,
    requestedAgentId: 'agent_codex_host',
    threadId: input.threadId,
    triggerActor: ACTOR,
    turnId: input.turnId,
    turnInput: 'Cancelled before Turn persistence.',
    workspaceId: input.workspaceId,
  });
  cancelSchedulerAdmissionEntry(coreDb, {
    queueEntryId,
    workspaceId: input.workspaceId,
  });
}

/** Records one admitted attempt that failed before Turn persistence. */
function writeStartFailureLease(
  coreDb: CoreDb,
  input: {
    readonly requestId: string;
    readonly threadId: string;
    readonly turnId: string;
    readonly workspaceId: string;
  }
): void {
  const queueEntryId = `queue_${input.turnId}`;
  const entry = createSchedulerAdmissionEntry(coreDb, {
    backendId: 'nanohost',
    profileRef: 'agent_codex_host',
    queueEntryId,
    requestId: input.requestId,
    requestedAgentId: 'agent_codex_host',
    threadId: input.threadId,
    triggerActor: ACTOR,
    turnId: input.turnId,
    turnInput: 'Start failed before Turn persistence.',
    workspaceId: input.workspaceId,
  });
  createSchedulerExecutionAttempt(coreDb, {
    entry,
    attemptId: testEntityId('attempt', `lease_${input.turnId}`),
    preparationInput: { admission: entry },
  });
  bindSchedulerExecutionAttemptSession(coreDb, {
    attemptId: testEntityId('attempt', `lease_${input.turnId}`),
    agentSessionId: testEntityId('as', `as_${input.turnId}`),
  });
  // No preparation or backend operation occurred in this missing-Turn fixture.
  closeSchedulerExecutionAttemptWithoutEffects(coreDb, {
    attemptId: testEntityId('attempt', `lease_${input.turnId}`),
    cause: 'turn-start-failed',
    noOutstandingEffects: true,
  });
}

/** Reads scheduler rows that this cleanup must preserve. */
function schedulerSnapshot(dataRoot: string): {
  readonly admissions: unknown[];
  readonly attempts: unknown[];
} {
  const coreDb = openCoreDb(dataRoot);
  try {
    return {
      admissions: coreDb.sqlite
        .prepare(
          `SELECT queue_entry_id, request_id, status, turn_id, workspace_id
           FROM scheduler_admission_entries ORDER BY queue_entry_id`
        )
        .all(),
      attempts: coreDb.sqlite
        .prepare(
          "SELECT name FROM sqlite_master WHERE type='table' AND name='scheduler_execution_attempts'"
        )
        .get()
        ? coreDb.sqlite.prepare('SELECT * FROM scheduler_execution_attempts ORDER BY rowid').all()
        : [],
    };
  } finally {
    coreDb.sqlite.close();
  }
}

describe('cancelled-admission Task checkpoint cleanup', () => {
  it('reports a proved cancelled admission on dry-run and removes it only on apply', async () => {
    const fixture = createFixture();
    const turnId = 'tu_00000000-0000-7ce2-a4ef-a80fb53e8b1d';
    const requestId = '0190f4c8-0000-7000-8000-000000000591';
    const siblingTurnId = 'tu_00000000-0000-720f-8cf6-feec28411135';
    writeCancelledAdmission(fixture.coreDb, {
      requestId,
      threadId: fixture.threadId,
      turnId,
      workspaceId: fixture.workspaceId,
    });
    writeFailedCheckpoint(fixture.workspaceDb, {
      requestId,
      threadId: fixture.threadId,
      turnId,
      workspaceId: fixture.workspaceId,
    });
    writeCancelledAdmission(fixture.coreDb, {
      requestId: '0190f4c8-0000-7000-8000-000000000592',
      threadId: fixture.threadId,
      turnId: siblingTurnId,
      workspaceId: fixture.workspaceId,
    });
    writeFailedCheckpoint(fixture.workspaceDb, {
      requestId: '0190f4c8-0000-7000-8000-000000000592',
      threadId: fixture.threadId,
      turnId: siblingTurnId,
      workspaceId: fixture.workspaceId,
    });
    const keptTurn = fixture.store.createTurn(
      fixture.workspaceId,
      fixture.threadId,
      'Unrelated product history',
      ACTOR
    );
    const before = schedulerSnapshot(fixture.dataRoot);
    closeFixture(fixture);

    const identity = {
      threadId: fixture.threadId,
      turnId,
      workspaceId: fixture.workspaceId,
    };
    const dryRun = await cleanCancelledAdmissionTaskCheckpoints({
      backupRoot: fixture.backupRoot,
      checkpoints: [identity],
      dataRoot: fixture.dataRoot,
    });
    expect(dryRun).toMatchObject({
      applied: false,
      backupRoot: null,
      outcome: 'succeeded',
      removedCount: 0,
      rows: [{ decision: 'removable', reason: 'cancelled-admission', ...identity }],
    });
    const afterDryRun = openWorkspaceDb(fixture.dataRoot, fixture.workspaceId);
    expect(
      getWorkerCheckpoint(afterDryRun, fixture.workspaceId, fixture.threadId, turnId)
    ).not.toBeNull();
    afterDryRun.sqlite.close();

    const applied = await cleanCancelledAdmissionTaskCheckpoints({
      apply: true,
      backupRoot: fixture.backupRoot,
      checkpoints: [identity],
      dataRoot: fixture.dataRoot,
    });
    expect(applied).toMatchObject({
      applied: true,
      outcome: 'succeeded',
      removedCount: 1,
      rows: [{ decision: 'removed', reason: 'cancelled-admission', ...identity }],
    });
    expect(applied.backupRoot).toBe(fixture.backupRoot);
    const backup = new Database(
      join(fixture.backupRoot, 'workspaces', fixture.workspaceId, 'workspace.sqlite'),
      { readonly: true }
    );
    const backedUp = backup
      .prepare('SELECT turn_id FROM worker_turn_checkpoints WHERE turn_id = ?')
      .get(turnId) as { turn_id: string } | undefined;
    backup.close();
    expect(backedUp?.turn_id).toBe(turnId);

    const afterApply = openWorkspaceDb(fixture.dataRoot, fixture.workspaceId);
    try {
      expect(
        getWorkerCheckpoint(afterApply, fixture.workspaceId, fixture.threadId, turnId)
      ).toBeNull();
      expect(
        getWorkerCheckpoint(afterApply, fixture.workspaceId, fixture.threadId, siblingTurnId)
      ).not.toBeNull();
    } finally {
      afterApply.sqlite.close();
    }
    expect(schedulerSnapshot(fixture.dataRoot)).toEqual(before);
    expect(
      new FsStore({ dataRoot: fixture.dataRoot }).getTurn(
        fixture.workspaceId,
        fixture.threadId,
        keptTurn.id
      ).id
    ).toBe(keptTurn.id);

    const repeated = await cleanCancelledAdmissionTaskCheckpoints({
      apply: true,
      backupRoot: fixture.backupRoot,
      checkpoints: [identity],
      dataRoot: fixture.dataRoot,
    });
    expect(repeated).toMatchObject({
      applied: true,
      backupRoot: null,
      outcome: 'succeeded',
      removedCount: 0,
      rows: [{ decision: 'absent', reason: 'absent', ...identity }],
    });
    expect(schedulerSnapshot(fixture.dataRoot)).toEqual(before);
  });

  it('removes a proved pre-persistence start-failure checkpoint only on apply', async () => {
    const fixture = createFixture();
    const turnId = 'tu_00000000-0000-7a81-a9d4-017d6a90c247';
    const requestId = '0190f4c8-0000-7000-8000-000000000593';
    writeStartFailureLease(fixture.coreDb, {
      requestId,
      threadId: fixture.threadId,
      turnId,
      workspaceId: fixture.workspaceId,
    });
    writeFailedCheckpoint(fixture.workspaceDb, {
      requestId,
      threadId: fixture.threadId,
      turnId,
      workspaceId: fixture.workspaceId,
    });
    const before = schedulerSnapshot(fixture.dataRoot);
    closeFixture(fixture);
    const identity = {
      threadId: fixture.threadId,
      turnId,
      workspaceId: fixture.workspaceId,
    };

    const dryRun = await cleanCancelledAdmissionTaskCheckpoints({
      backupRoot: fixture.backupRoot,
      checkpoints: [identity],
      dataRoot: fixture.dataRoot,
    });
    expect(dryRun.rows).toEqual([
      expect.objectContaining({ decision: 'removable', reason: 'turn-start-failed', ...identity }),
    ]);

    const applied = await cleanCancelledAdmissionTaskCheckpoints({
      apply: true,
      backupRoot: fixture.backupRoot,
      checkpoints: [identity],
      dataRoot: fixture.dataRoot,
    });
    expect(applied.removedCount).toBe(1);
    expect(applied.rows[0]).toMatchObject({ decision: 'removed', reason: 'turn-start-failed' });
    const workspaceDb = openWorkspaceDb(fixture.dataRoot, fixture.workspaceId);
    try {
      expect(
        getWorkerCheckpoint(workspaceDb, fixture.workspaceId, fixture.threadId, turnId)
      ).toBeNull();
    } finally {
      workspaceDb.sqlite.close();
    }
    expect(schedulerSnapshot(fixture.dataRoot)).toEqual(before);

    const repeated = await cleanCancelledAdmissionTaskCheckpoints({
      apply: true,
      backupRoot: fixture.backupRoot,
      checkpoints: [identity],
      dataRoot: fixture.dataRoot,
    });
    expect(repeated.removedCount).toBe(0);
    expect(repeated.rows[0]?.decision).toBe('absent');
    expect(schedulerSnapshot(fixture.dataRoot)).toEqual(before);
  });

  it.each([
    {
      mutate: 'lineage' as const,
      reason: 'mismatched-turn-lineage',
    },
    {
      mutate: 'history' as const,
      reason: 'unreadable-history',
    },
    {
      mutate: 'live-lease' as const,
      reason: 'live-lease',
    },
    {
      mutate: 'multiple-leases' as const,
      reason: 'multiple-leases',
    },
    {
      mutate: 'session' as const,
      reason: 'non-null-session',
    },
    {
      mutate: 'stage' as const,
      reason: 'nonterminal-checkpoint',
    },
    {
      mutate: 'goal' as const,
      reason: 'goal-ownership',
    },
    {
      mutate: 'runtime' as const,
      reason: 'runtime-evidence',
    },
    {
      mutate: 'provenance' as const,
      reason: 'missing-provenance',
    },
  ])('preserves a checkpoint with $mutate', async ({ mutate, reason }) => {
    const fixture = createFixture();
    const turnId = testEntityId('tu', `turn_preserve_${mutate}`);
    const requestId = `0190f4c8-0000-7000-8000-0000000005${mutate.length}`;
    if (mutate !== 'provenance' && mutate !== 'live-lease' && mutate !== 'multiple-leases') {
      writeCancelledAdmission(fixture.coreDb, {
        requestId,
        threadId: fixture.threadId,
        turnId,
        workspaceId: fixture.workspaceId,
      });
    }
    if (mutate === 'live-lease' || mutate === 'multiple-leases') {
      writeStartFailureLease(fixture.coreDb, {
        requestId,
        threadId: fixture.threadId,
        turnId,
        workspaceId: fixture.workspaceId,
      });
    }
    if (mutate === 'live-lease') {
      fixture.coreDb.sqlite
        .prepare(
          `UPDATE scheduler_execution_attempts
           SET phase = 'open', terminal_cause = NULL, recovery_state = NULL
           WHERE attempt_id = ?`
        )
        .run(testEntityId('attempt', `lease_${turnId}`));
    }
    if (mutate === 'multiple-leases') {
      fixture.coreDb.sqlite
        .prepare(
          `INSERT INTO scheduler_execution_attempts (
             attempt_id, queue_entry_id, backend_id, workspace_id, thread_id, turn_id,
             preparation_input_json, phase, disposition, terminal_cause, created_at, updated_at
           )
           SELECT ?, queue_entry_id, backend_id, workspace_id, thread_id,
                  turn_id, preparation_input_json, phase, disposition, terminal_cause, created_at, updated_at
           FROM scheduler_execution_attempts WHERE attempt_id = ?`
        )
        .run(
          testEntityId('attempt', `lease_extra_${turnId}`),
          testEntityId('attempt', `lease_${turnId}`)
        );
    }
    writeFailedCheckpoint(fixture.workspaceDb, {
      contextDigest: mutate === 'runtime' ? 'sha256:context' : null,
      goalId: mutate === 'goal' ? 'goal_preserve' : null,
      requestId,
      stage: mutate === 'stage' ? 'preparing' : 'failed',
      threadId: fixture.threadId,
      turnId,
      workerSessionId: mutate === 'session' ? 'as_00000000-0000-73cf-8c67-8f725aa0624f' : null,
      workspaceId: fixture.workspaceId,
    });
    if (mutate === 'lineage') {
      const other = fixture.store.createWorkspace('Other lineage');
      const otherThread = fixture.store.createThread(other.id, 'Other lineage thread');
      fixture.store.createTurn(other.id, otherThread.id, 'Foreign Turn', ACTOR, null, { turnId });
    }
    if (mutate === 'runtime') {
      fixture.workspaceDb.sqlite
        .prepare(
          `INSERT INTO runtime_evidence (
             runtime_evidence_id, workspace_id, thread_id, turn_id, placement, phase, summary,
             upload_manifest_json, download_manifest_json, outcome, evidence_bundle_ids_json,
             content_digests_json, required_features_json, created_at
           ) VALUES (?, ?, ?, ?, 'local', 'checkpoint', 'fixture', '[]', '[]', 'unknown', '[]', '[]', '[]', ?)`
        )
        .run(
          `rte_${turnId}`,
          fixture.workspaceId,
          fixture.threadId,
          turnId,
          '2026-09-22T00:00:00.000Z'
        );
    }
    const before = schedulerSnapshot(fixture.dataRoot);
    const checkpointBefore = getWorkerCheckpoint(
      fixture.workspaceDb,
      fixture.workspaceId,
      fixture.threadId,
      turnId
    );
    closeFixture(fixture);
    if (mutate === 'history') {
      writeFileSync(
        join(
          fixture.dataRoot,
          'workspaces',
          fixture.workspaceId,
          'threads',
          fixture.threadId,
          'thread.json'
        ),
        '{'
      );
    }

    const result = await cleanCancelledAdmissionTaskCheckpoints({
      apply: true,
      backupRoot: fixture.backupRoot,
      checkpoints: [{ threadId: fixture.threadId, turnId, workspaceId: fixture.workspaceId }],
      dataRoot: fixture.dataRoot,
    });
    expect(result.removedCount).toBe(0);
    expect(result.rows).toEqual([
      expect.objectContaining({
        decision: 'refused',
        reason,
        threadId: fixture.threadId,
        turnId,
        workspaceId: fixture.workspaceId,
      }),
    ]);
    if (mutate !== 'history') {
      const workspaceDb = openWorkspaceDb(fixture.dataRoot, fixture.workspaceId);
      try {
        expect(
          getWorkerCheckpoint(workspaceDb, fixture.workspaceId, fixture.threadId, turnId)
        ).toEqual(checkpointBefore);
      } finally {
        workspaceDb.sqlite.close();
      }
      expect(schedulerSnapshot(fixture.dataRoot)).toEqual(before);
    }
  });
});

describe('cancelled-admission checkpoint cleanup preservation', () => {
  it('keeps a matching expired receipt during dry-run and apply', async () => {
    for (const apply of [false, true]) {
      const fixture = createFixture();
      const turnId = testEntityId('tu', `turn_receipt_${apply}`);
      const requestId = '0190f4c8-0000-7000-8000-000000000991';
      const identity = { threadId: fixture.threadId, turnId, workspaceId: fixture.workspaceId };
      writeCancelledAdmission(fixture.coreDb, { ...identity, requestId });
      writeFailedCheckpoint(fixture.workspaceDb, { ...identity, requestId });
      insertReceipt(fixture.workspaceDb, {
        expiresAt: '2020-01-02T00:00:00.000Z',
        requestId,
        requestKey: `receipt_${turnId}`,
        responseId: turnId,
        scope: { threadId: fixture.threadId, workspaceId: fixture.workspaceId },
      });
      const receiptsBefore = readReceipts(fixture.dataRoot, fixture.workspaceId);
      const checkpointBefore = getWorkerCheckpoint(
        fixture.workspaceDb,
        fixture.workspaceId,
        fixture.threadId,
        turnId
      );
      closeFixture(fixture);

      const result = await cleanCancelledAdmissionTaskCheckpoints({
        apply,
        backupRoot: fixture.backupRoot,
        checkpoints: [identity],
        dataRoot: fixture.dataRoot,
      });

      expect(result.removedCount).toBe(0);
      expect(result.backupRoot).toBeNull();
      expect(result.rows).toEqual([
        expect.objectContaining({ decision: 'refused', reason: 'missing-provenance', turnId }),
      ]);
      expect(readReceipts(fixture.dataRoot, fixture.workspaceId)).toEqual(receiptsBefore);
      expect(readCheckpoint(fixture.dataRoot, identity)).toEqual(checkpointBefore);
    }
  });

  it('preserves an unrelated expired receipt while removing a proved checkpoint', async () => {
    const fixture = createFixture();
    const turnId = 'tu_00000000-0000-7f5a-b8f3-3a41e3c2b08d';
    const requestId = '0190f4c8-0000-7000-8000-000000000992';
    const identity = { threadId: fixture.threadId, turnId, workspaceId: fixture.workspaceId };
    writeCancelledAdmission(fixture.coreDb, { ...identity, requestId });
    writeFailedCheckpoint(fixture.workspaceDb, { ...identity, requestId });
    insertReceipt(fixture.workspaceDb, {
      expiresAt: '2020-01-02T00:00:00.000Z',
      requestId: '0190f4c8-0000-7000-8000-000000000993',
      requestKey: 'receipt_unrelated',
      responseId: 'tu_00000000-0000-7963-ac3b-c41b06427ed7',
      scope: { threadId: fixture.threadId, workspaceId: fixture.workspaceId },
    });
    const receiptsBefore = readReceipts(fixture.dataRoot, fixture.workspaceId);
    closeFixture(fixture);

    const result = await cleanCancelledAdmissionTaskCheckpoints({
      apply: true,
      backupRoot: fixture.backupRoot,
      checkpoints: [identity],
      dataRoot: fixture.dataRoot,
    });

    expect(result.rows).toEqual([
      expect.objectContaining({ decision: 'removed', reason: 'cancelled-admission', turnId }),
    ]);
    expect(readCheckpoint(fixture.dataRoot, identity)).toBeNull();
    expect(readReceipts(fixture.dataRoot, fixture.workspaceId)).toEqual(receiptsBefore);
  });

  it.each([
    'dry-run',
    'apply',
    'refused',
  ] as const)('preserves an unrelated pending approval during %s', async (mode) => {
    const fixture = createFixture();
    const turnId = testEntityId('tu', `turn_history_${mode}`);
    const requestId = '0190f4c8-0000-7000-8000-000000000994';
    const identity = { threadId: fixture.threadId, turnId, workspaceId: fixture.workspaceId };
    if (mode !== 'refused') {
      writeCancelledAdmission(fixture.coreDb, { ...identity, requestId });
    }
    writeFailedCheckpoint(fixture.workspaceDb, { ...identity, requestId });
    const unrelated = fixture.store.createTurn(
      fixture.workspaceId,
      fixture.threadId,
      'Unrelated terminal approval',
      ACTOR
    );
    const timestamp = '2026-09-22T00:00:00.000Z';
    fixture.store.createItem({
      approvalRequestId: `ap_${unrelated.id}`,
      completedAt: null,
      createdAt: timestamp,
      description: 'Independent history',
      id: testEntityId('it', `it_req_${unrelated.id}`),
      kind: 'permission',
      status: 'in_progress',
      threadId: fixture.threadId,
      title: 'Unresolved approval',
      turnId: unrelated.id,
      type: 'approval-request',
      workspaceId: fixture.workspaceId,
    });
    fixture.store.updateTurn(unrelated.id, {
      completedAt: timestamp,
      error: null,
      status: 'completed',
    });
    const itemsPath = join(
      fixture.dataRoot,
      'workspaces',
      fixture.workspaceId,
      'threads',
      fixture.threadId,
      'turns',
      unrelated.id,
      'items.jsonl'
    );
    const itemsBefore = readFileSync(itemsPath);
    closeFixture(fixture);

    const result = await cleanCancelledAdmissionTaskCheckpoints({
      apply: mode === 'apply',
      backupRoot: fixture.backupRoot,
      checkpoints: [identity],
      dataRoot: fixture.dataRoot,
    });

    expect(readFileSync(itemsPath)).toEqual(itemsBefore);
    expect(readFileSync(itemsPath, 'utf8')).not.toContain(
      'it_00000000-0000-7548-a1b7-5dff9f300931'
    );
    if (mode === 'apply') {
      expect(result.removedCount).toBe(1);
      expect(readCheckpoint(fixture.dataRoot, identity)).toBeNull();
    } else {
      expect(result.removedCount).toBe(0);
      expect(readCheckpoint(fixture.dataRoot, identity)).not.toBeNull();
    }
  });

  it('refuses malformed diagnostics and blocks every selected checkpoint', async () => {
    const fixture = createFixture();
    const corruptId = identityFor(fixture, 'tu_00000000-0000-7f48-be95-803bf8edcd90');
    const cleanId = identityFor(fixture, 'tu_00000000-0000-7ea2-b600-fcf572339658');
    writeCancelledAdmission(fixture.coreDb, {
      ...corruptId,
      requestId: '0190f4c8-0000-7000-8000-000000000995',
    });
    writeFailedCheckpoint(fixture.workspaceDb, {
      ...corruptId,
      requestId: '0190f4c8-0000-7000-8000-000000000995',
    });
    writeCancelledAdmission(fixture.coreDb, {
      ...cleanId,
      requestId: '0190f4c8-0000-7000-8000-000000001095',
    });
    writeFailedCheckpoint(fixture.workspaceDb, {
      ...cleanId,
      requestId: '0190f4c8-0000-7000-8000-000000001095',
    });
    fixture.workspaceDb.sqlite
      .prepare('UPDATE worker_turn_checkpoints SET diagnostics_summary = ? WHERE turn_id = ?')
      .run('{', corruptId.turnId);
    closeFixture(fixture);

    const result = await cleanCancelledAdmissionTaskCheckpoints({
      apply: true,
      backupRoot: fixture.backupRoot,
      checkpoints: [corruptId, cleanId],
      dataRoot: fixture.dataRoot,
    });

    expect(result.outcome).toBe('blocked');
    expect(result.removedCount).toBe(0);
    expect(result.rows).toEqual([
      expect.objectContaining({
        decision: 'refused',
        reason: 'unreadable-history',
        turnId: corruptId.turnId,
      }),
      expect.objectContaining({
        decision: 'refused',
        reason: 'unreadable-history',
        turnId: cleanId.turnId,
      }),
    ]);
    expect(readCheckpoint(fixture.dataRoot, corruptId)).not.toBeNull();
    expect(readCheckpoint(fixture.dataRoot, cleanId)).not.toBeNull();
  });

  it('treats incomplete context assembly as execution evidence', async () => {
    const fixture = createFixture();
    const identity = identityFor(fixture, 'tu_00000000-0000-749c-8e69-38e10357fa79');
    const requestId = '0190f4c8-0000-7000-8000-000000000996';
    writeCancelledAdmission(fixture.coreDb, { ...identity, requestId });
    writeFailedCheckpoint(fixture.workspaceDb, { ...identity, requestId });
    fixture.workspaceDb.sqlite
      .prepare('UPDATE worker_turn_checkpoints SET diagnostics_summary = ? WHERE turn_id = ?')
      .run(
        JSON.stringify({ contextAssembly: { contextDigest: 'sha256:ran', contextRefs: [] } }),
        identity.turnId
      );
    closeFixture(fixture);

    const result = await cleanCancelledAdmissionTaskCheckpoints({
      apply: true,
      backupRoot: fixture.backupRoot,
      checkpoints: [identity],
      dataRoot: fixture.dataRoot,
    });

    expect(result.removedCount).toBe(0);
    expect(result.rows).toEqual([
      expect.objectContaining({
        decision: 'refused',
        reason: 'runtime-evidence',
        turnId: identity.turnId,
      }),
    ]);
    expect(readCheckpoint(fixture.dataRoot, identity)).not.toBeNull();
  });

  it.each([
    ['item ids', JSON.stringify({ itemIds: 'bad' })],
    ['artifact ids', JSON.stringify({ artifactIds: {} })],
  ] as const)('refuses incorrectly typed %s diagnostics', async (_label, diagnostics) => {
    const fixture = createFixture();
    const identity = identityFor(fixture, `turn_typed_${_label.replace(' ', '_')}`);
    const requestId = '0190f4c8-0000-7000-8000-000000000997';
    writeCancelledAdmission(fixture.coreDb, { ...identity, requestId });
    writeFailedCheckpoint(fixture.workspaceDb, { ...identity, requestId });
    fixture.workspaceDb.sqlite
      .prepare('UPDATE worker_turn_checkpoints SET diagnostics_summary = ? WHERE turn_id = ?')
      .run(diagnostics, identity.turnId);
    closeFixture(fixture);

    const result = await cleanCancelledAdmissionTaskCheckpoints({
      apply: true,
      backupRoot: fixture.backupRoot,
      checkpoints: [identity],
      dataRoot: fixture.dataRoot,
    });

    expect(result.outcome).toBe('blocked');
    expect(result.removedCount).toBe(0);
    expect(readCheckpoint(fixture.dataRoot, identity)).not.toBeNull();
  });

  it('still removes a checkpoint whose diagnostics are plain failure text', async () => {
    const fixture = createFixture();
    const identity = identityFor(fixture, 'tu_00000000-0000-7248-a8ea-70525940472a');
    const requestId = '0190f4c8-0000-7000-8000-000000000998';
    writeCancelledAdmission(fixture.coreDb, { ...identity, requestId });
    writeFailedCheckpoint(fixture.workspaceDb, { ...identity, requestId });
    fixture.workspaceDb.sqlite
      .prepare('UPDATE worker_turn_checkpoints SET diagnostics_summary = ? WHERE turn_id = ?')
      .run('Worker start failed.', identity.turnId);
    closeFixture(fixture);

    const result = await cleanCancelledAdmissionTaskCheckpoints({
      apply: true,
      backupRoot: fixture.backupRoot,
      checkpoints: [identity],
      dataRoot: fixture.dataRoot,
    });

    expect(result.rows).toEqual([
      expect.objectContaining({ decision: 'removed', reason: 'cancelled-admission' }),
    ]);
    expect(readCheckpoint(fixture.dataRoot, identity)).toBeNull();
  });

  it('refuses a runtime evidence row without using context digest as a shortcut', async () => {
    const fixture = createFixture();
    const identity = identityFor(fixture, 'tu_00000000-0000-7cd8-ac6d-ce67f0efa520');
    const requestId = '0190f4c8-0000-7000-8000-000000001001';
    writeCancelledAdmission(fixture.coreDb, { ...identity, requestId });
    writeFailedCheckpoint(fixture.workspaceDb, { ...identity, requestId });
    fixture.workspaceDb.sqlite
      .prepare(
        `INSERT INTO runtime_evidence (
           runtime_evidence_id, workspace_id, thread_id, turn_id, placement, phase, summary,
           upload_manifest_json, download_manifest_json, outcome, evidence_bundle_ids_json,
           content_digests_json, required_features_json, created_at
         ) VALUES (?, ?, ?, ?, 'local', 'checkpoint', 'fixture', '[]', '[]', 'unknown', '[]', '[]', '[]', ?)`
      )
      .run(
        `rte_${identity.turnId}`,
        fixture.workspaceId,
        fixture.threadId,
        identity.turnId,
        '2026-09-22T00:00:00.000Z'
      );
    closeFixture(fixture);

    const result = await cleanCancelledAdmissionTaskCheckpoints({
      apply: true,
      backupRoot: fixture.backupRoot,
      checkpoints: [identity],
      dataRoot: fixture.dataRoot,
    });

    expect(result.rows).toEqual([
      expect.objectContaining({ decision: 'refused', reason: 'runtime-evidence' }),
    ]);
    expect(readCheckpoint(fixture.dataRoot, identity)).not.toBeNull();
  });

  it('refuses a worker control record for the checkpoint Turn', async () => {
    const fixture = createFixture();
    const identity = identityFor(fixture, 'tu_00000000-0000-7781-892a-3b253a33f2d9');
    const requestId = '0190f4c8-0000-7000-8000-000000001002';
    writeCancelledAdmission(fixture.coreDb, { ...identity, requestId });
    writeFailedCheckpoint(fixture.workspaceDb, { ...identity, requestId });
    fixture.coreDb.sqlite
      .prepare(
        `INSERT INTO worker_control_records (
           workspace_id, thread_id, turn_id, agent_session_id, package_snapshot_id, request_id,
           operation, record_key, sequence, record_json, accepted_at
         ) VALUES (?, ?, ?, 'as_00000000-0000-736f-9643-8c3c704c2cce', 'aepsnap_control', ?, 'observe', 'key', 1, '{}', ?)`
      )
      .run(
        fixture.workspaceId,
        fixture.threadId,
        identity.turnId,
        requestId,
        '2026-09-22T00:00:00.000Z'
      );
    closeFixture(fixture);

    const result = await cleanCancelledAdmissionTaskCheckpoints({
      apply: true,
      backupRoot: fixture.backupRoot,
      checkpoints: [identity],
      dataRoot: fixture.dataRoot,
    });

    expect(result.rows).toEqual([
      expect.objectContaining({ decision: 'refused', reason: 'runtime-evidence' }),
    ]);
    expect(readCheckpoint(fixture.dataRoot, identity)).not.toBeNull();
  });

  it('refuses an environment package bound to the checkpoint Turn', async () => {
    const fixture = createFixture();
    const identity = identityFor(fixture, 'tu_00000000-0000-7c9c-a800-07ed48da3579');
    const requestId = '0190f4c8-0000-7000-8000-000000001003';
    writeCancelledAdmission(fixture.coreDb, { ...identity, requestId });
    writeFailedCheckpoint(fixture.workspaceDb, { ...identity, requestId });
    const sessionId = 'as_00000000-0000-78a3-a9bb-2860a6e89e42';
    recordAgentEnvironmentPackageSnapshot(fixture.workspaceDb, {
      createdAt: '2026-09-22T00:00:00.000Z',
      environmentPackage: AgentEnvironmentPackageSchema.parse(
        resolveAgentEnvironmentPackage({
          agent: {
            capabilities: [],
            config: {
              adapterType: 'codex',
              baseUrl: null,
              capabilities: [],
              command: null,
              environment: {},
              workspaceRoot: '/workspace',
            },
            defaultProfileId: 'default',
            id: 'agent_codex_host',
            kind: 'coder',
            modelId: null,
            name: 'Codex Agent',
            profiles: [
              {
                capabilityIds: [],
                displayName: 'Default',
                id: 'default',
                instructionsRef: null,
                modelId: null,
                skillIds: [],
              },
            ],
            sandboxSummary: null,
            skillIds: [],
            status: 'enabled',
          },
          agentSessionId: sessionId,
          agentSetup: createTestAgentSetup(),
          backend: { kind: 'openshell' },
          requestId,
          triggerActor: ACTOR,
          turn: {
            completedAt: null,
            configVersion: null,
            durationMs: null,
            error: null,
            id: identity.turnId,
            items: [],
            startedAt: '2026-09-22T00:00:00.000Z',
            status: 'running',
            threadId: fixture.threadId,
            triggerActor: ACTOR,
            workspaceId: fixture.workspaceId,
          },
          turnInput: 'Run tests',
          workspaceCwd: '/workspace',
          workspaceRoots: [],
        })
      ),
    });
    fixture.store.createAgentSession({
      agentId: 'agent_codex_host',
      createdAt: '2026-09-22T00:00:00.000Z',
      id: sessionId,
      message: null,
      status: 'closed',
      threadId: fixture.threadId,
      updatedAt: '2026-09-22T00:00:00.000Z',
      workspaceId: fixture.workspaceId,
    });
    closeFixture(fixture);

    const result = await cleanCancelledAdmissionTaskCheckpoints({
      apply: true,
      backupRoot: fixture.backupRoot,
      checkpoints: [identity],
      dataRoot: fixture.dataRoot,
    });

    expect(result.rows).toEqual([
      expect.objectContaining({ decision: 'refused', reason: 'runtime-evidence' }),
    ]);
    expect(readCheckpoint(fixture.dataRoot, identity)).not.toBeNull();
  });

  it('refuses an AgentSession that matches the start-failure lease', async () => {
    const fixture = createFixture();
    const identity = identityFor(fixture, 'tu_00000000-0000-780f-be6c-5b90f496572f');
    const requestId = '0190f4c8-0000-7000-8000-000000001004';
    writeStartFailureLease(fixture.coreDb, { ...identity, requestId });
    writeFailedCheckpoint(fixture.workspaceDb, { ...identity, requestId });
    const sessionId = testEntityId('as', `as_${identity.turnId}`);
    fixture.store.createAgentSession({
      agentId: 'agent_codex_host',
      createdAt: '2026-09-22T00:00:00.000Z',
      id: sessionId,
      message: null,
      status: 'closed',
      threadId: fixture.threadId,
      updatedAt: '2026-09-22T00:00:00.000Z',
      workspaceId: fixture.workspaceId,
    });
    closeFixture(fixture);

    const result = await cleanCancelledAdmissionTaskCheckpoints({
      apply: true,
      backupRoot: fixture.backupRoot,
      checkpoints: [identity],
      dataRoot: fixture.dataRoot,
    });

    expect(result.rows).toEqual([
      expect.objectContaining({ decision: 'refused', reason: 'runtime-evidence' }),
    ]);
    expect(readCheckpoint(fixture.dataRoot, identity)).not.toBeNull();
  });

  it('refuses cleanup while another holder owns the data-root lock', async () => {
    const fixture = createFixture();
    const identity = identityFor(fixture, 'tu_00000000-0000-7e14-8c92-1734e9d4fbff');
    const requestId = '0190f4c8-0000-7000-8000-000000001005';
    writeCancelledAdmission(fixture.coreDb, { ...identity, requestId });
    writeFailedCheckpoint(fixture.workspaceDb, { ...identity, requestId });
    const checkpointBefore = getWorkerCheckpoint(
      fixture.workspaceDb,
      fixture.workspaceId,
      fixture.threadId,
      identity.turnId
    );
    closeFixture(fixture);
    const lock = acquireDataRootLock(fixture.dataRoot, { bootId: 'held-by-test' });
    try {
      await expect(
        cleanCancelledAdmissionTaskCheckpoints({
          apply: true,
          backupRoot: fixture.backupRoot,
          checkpoints: [identity],
          dataRoot: fixture.dataRoot,
        })
      ).rejects.toThrow(/stopped NanoCore/);
    } finally {
      lock.release();
    }
    expect(readCheckpoint(fixture.dataRoot, identity)).toEqual(checkpointBefore);
  });

  it('refuses apply when the backup destination already exists', async () => {
    const fixture = createFixture();
    const identity = identityFor(fixture, 'tu_00000000-0000-72bf-ba1a-70e8fc2f5cee');
    const requestId = '0190f4c8-0000-7000-8000-000000001006';
    writeCancelledAdmission(fixture.coreDb, { ...identity, requestId });
    writeFailedCheckpoint(fixture.workspaceDb, { ...identity, requestId });
    const schedulerBefore = schedulerSnapshot(fixture.dataRoot);
    const checkpointBefore = getWorkerCheckpoint(
      fixture.workspaceDb,
      fixture.workspaceId,
      fixture.threadId,
      identity.turnId
    );
    closeFixture(fixture);
    const destination = join(
      fixture.backupRoot,
      'workspaces',
      fixture.workspaceId,
      'workspace.sqlite'
    );
    mkdirSync(join(fixture.backupRoot, 'workspaces', fixture.workspaceId), { recursive: true });
    writeFileSync(destination, 'occupied');

    await expect(
      cleanCancelledAdmissionTaskCheckpoints({
        apply: true,
        backupRoot: fixture.backupRoot,
        checkpoints: [identity],
        dataRoot: fixture.dataRoot,
      })
    ).rejects.toThrow(/backup destination already exists/);
    expect(readCheckpoint(fixture.dataRoot, identity)).toEqual(checkpointBefore);
    expect(schedulerSnapshot(fixture.dataRoot)).toEqual(schedulerBefore);
    expect(readFileSync(destination, 'utf8')).toBe('occupied');
  });

  it.each([
    ['invalid Turn status', 'turn-schema'],
    ['corrupt Thread JSON', 'thread-json'],
    ['malformed Item JSONL', 'items-json'],
    ['missing Item history', 'missing-items'],
  ] as const)('blocks cleanup when unrelated published history has %s', async (_label, kind) => {
    const fixture = createFixture();
    const identity = identityFor(fixture, testEntityId('tu', `turn_corrupt_${kind}`));
    const requestId = '0190f4c8-0000-7000-8000-000000001099';
    writeCancelledAdmission(fixture.coreDb, { ...identity, requestId });
    writeFailedCheckpoint(fixture.workspaceDb, { ...identity, requestId });
    const unrelated = publishUnrelatedTurn(fixture.store, fixture.dataRoot);
    const historyPath = unrelatedHistoryPath(unrelated, kind);
    if (kind === 'turn-schema') {
      const record = JSON.parse(readFileSync(historyPath, 'utf8')) as { status: string };
      record.status = 'corrupt-invalid-status';
      writeFileSync(historyPath, JSON.stringify(record));
    } else if (kind === 'thread-json') {
      writeFileSync(historyPath, '{');
    } else if (kind === 'items-json') {
      writeFileSync(historyPath, '{\n');
    } else {
      unlinkSync(historyPath);
    }
    const historyBefore = existsSyncFile(historyPath);
    const checkpointBefore = getWorkerCheckpoint(
      fixture.workspaceDb,
      fixture.workspaceId,
      fixture.threadId,
      identity.turnId
    );
    closeFixture(fixture);

    const result = await cleanCancelledAdmissionTaskCheckpoints({
      apply: true,
      backupRoot: fixture.backupRoot,
      checkpoints: [identity],
      dataRoot: fixture.dataRoot,
    });

    expect(result.outcome).toBe('blocked');
    expect(result.removedCount).toBe(0);
    expect(result.rows).toEqual([
      expect.objectContaining({
        decision: 'refused',
        reason: 'unreadable-history',
        turnId: identity.turnId,
      }),
    ]);
    expect(readCheckpoint(fixture.dataRoot, identity)).toEqual(checkpointBefore);
    expect(existsSyncFile(historyPath)).toEqual(historyBefore);
  });

  it('keeps an incomplete Item JSONL tail without treating it as corrupt history', async () => {
    const fixture = createFixture();
    const identity = identityFor(fixture, 'tu_00000000-0000-71e2-bfd1-a8b0df334491');
    const requestId = '0190f4c8-0000-7000-8000-000000001098';
    writeCancelledAdmission(fixture.coreDb, { ...identity, requestId });
    writeFailedCheckpoint(fixture.workspaceDb, { ...identity, requestId });
    const unrelated = publishUnrelatedTurn(fixture.store, fixture.dataRoot);
    const itemsPath = unrelatedHistoryPath(unrelated, 'items-json');
    appendFileSync(itemsPath, '{"id":');
    const itemsBefore = readFileSync(itemsPath);
    closeFixture(fixture);

    const result = await cleanCancelledAdmissionTaskCheckpoints({
      apply: true,
      backupRoot: fixture.backupRoot,
      checkpoints: [identity],
      dataRoot: fixture.dataRoot,
    });

    expect(result.removedCount).toBe(1);
    expect(readFileSync(itemsPath)).toEqual(itemsBefore);
    expect(readCheckpoint(fixture.dataRoot, identity)).toBeNull();
  });
});

/** Publishes one valid Turn outside the selected checkpoint Workspace. */
function publishUnrelatedTurn(
  store: FsStore,
  dataRoot: string
): {
  readonly itemsPath: string;
  readonly threadId: string;
  readonly threadPath: string;
  readonly turnId: string;
  readonly turnPath: string;
  readonly workspaceId: string;
} {
  const workspace = store.createWorkspace('Unrelated history');
  const thread = store.createThread(workspace.id, 'Unrelated history');
  const turn = store.createTurn(workspace.id, thread.id, 'Unrelated work', ACTOR);
  const turnRoot = join(
    dataRoot,
    'workspaces',
    workspace.id,
    'threads',
    thread.id,
    'turns',
    turn.id
  );
  return {
    itemsPath: join(turnRoot, 'items.jsonl'),
    threadId: thread.id,
    threadPath: join(dataRoot, 'workspaces', workspace.id, 'threads', thread.id, 'thread.json'),
    turnId: turn.id,
    turnPath: join(turnRoot, 'turn.json'),
    workspaceId: workspace.id,
  };
}

/** Resolves the canonical file introduced by one corruption case. */
function unrelatedHistoryPath(
  unrelated: ReturnType<typeof publishUnrelatedTurn>,
  kind: 'turn-schema' | 'thread-json' | 'items-json' | 'missing-items'
): string {
  if (kind === 'thread-json') return unrelated.threadPath;
  if (kind === 'turn-schema') return unrelated.turnPath;
  return unrelated.itemsPath;
}

/** Reads one canonical file, or null when the corruption case removed it. */
function existsSyncFile(path: string): Buffer | null {
  return existsSync(path) ? readFileSync(path) : null;
}

/** Builds one checkpoint identity inside a fixture Workspace and Thread. */
function identityFor(
  fixture: { readonly threadId: string; readonly workspaceId: string },
  turnId: string
): { readonly threadId: string; readonly turnId: string; readonly workspaceId: string } {
  return { threadId: fixture.threadId, turnId, workspaceId: fixture.workspaceId };
}

/** Inserts one command receipt, including an already expired row. */
function insertReceipt(
  workspaceDb: WorkspaceDb,
  input: {
    readonly expiresAt: string;
    readonly requestId: string;
    readonly requestKey: string;
    readonly responseId: string;
    readonly scope: { readonly threadId: string; readonly workspaceId: string };
  }
): void {
  workspaceDb.sqlite
    .prepare(
      `INSERT INTO idempotency_requests (
         request_key, command_name, request_id, scope_json, input_hash, response_kind,
         response_id, created_at, expires_at
       ) VALUES (?, 'task.start', ?, ?, 'hash', 'turn', ?, '2020-01-01T00:00:00.000Z', ?)`
    )
    .run(
      input.requestKey,
      input.requestId,
      JSON.stringify(input.scope),
      input.responseId,
      input.expiresAt
    );
}

/** Reads receipt rows without using the pruning inventory. */
function readReceipts(dataRoot: string, workspaceId: string): unknown[] {
  const workspaceDb = openWorkspaceDb(dataRoot, workspaceId);
  try {
    return workspaceDb.sqlite
      .prepare(
        `SELECT request_key, command_name, request_id, scope_json, input_hash, response_kind,
                response_id, response_json, created_at, expires_at
         FROM idempotency_requests ORDER BY request_key`
      )
      .all();
  } finally {
    workspaceDb.sqlite.close();
  }
}

/** Reopens a Workspace database and reads one checkpoint. */
function readCheckpoint(
  dataRoot: string,
  identity: { readonly threadId: string; readonly turnId: string; readonly workspaceId: string }
) {
  const workspaceDb = openWorkspaceDb(dataRoot, identity.workspaceId);
  try {
    return getWorkerCheckpoint(
      workspaceDb,
      identity.workspaceId,
      identity.threadId,
      identity.turnId
    );
  } finally {
    workspaceDb.sqlite.close();
  }
}
