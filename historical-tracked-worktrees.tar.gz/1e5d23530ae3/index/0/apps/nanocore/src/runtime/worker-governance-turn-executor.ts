import { createHash } from 'node:crypto';
import { join } from 'node:path';
import { isDeepStrictEqual } from 'node:util';
import type {
  WorkspaceInputSnapshot,
  WorkspaceMaterializationRecord,
  WorkspaceSynchronizationBackendKind,
} from '@openkit/app-api-schemas';
import { workspaceSyncReviewPatchBytes } from '@openkit/app-api-schemas';
import type {
  AgentEnvironmentPackage,
  SessionWorkspaceMaterializationPlan,
  WorkerGovernanceBackendCapabilities,
} from '@openkit/config-schema';
import {
  allocateEntityId,
  deriveEntityId,
  GitFailureExplanationSchema,
  isEntityId,
  isSealedTurnTerminal,
  responsibleUserIdForActor,
  type StopReason,
} from '@openkit/protocol';
import { workerSessionInputPaths } from '@openkit/worker-protocol';
import { publishedErrorMessage } from '../api-errors.js';
import { currentWorkerLineageWorkspaceAuthority } from '../auth/operation-authorizer.js';
import { listWorkspaceCapabilityCalls } from '../capability/usage-ledger.js';
import { createWorkerContextPackageAuthorityReader } from '../context/worker-context-authorities.js';
import {
  createWorkerContextPackageFiles,
  createWorkerContextPackageTrace,
  isChatSubordinateTaskTurn,
  projectWorkerContextRequest,
  readWorkerContextPackageTrace,
  type WorkerContextPackageFiles,
  type WorkerContextPackageKnowledgeExclusion,
  type WorkerContextPackageKnowledgeSelectionInput,
  type WorkerContextPackageKnowledgeSelectionReference,
  type WorkerContextPackageMaterialExclusion,
  type WorkerContextPackageMaterialSelectionInput,
  type WorkerContextPackageTrace,
  writeWorkerContextPackageFiles,
  writeWorkerContextPackageTrace,
} from '../context/worker-context-package.js';
import {
  ALREADY_DECIDED_PUBLICATION_ADMISSION,
  ArtifactAuthorityError,
  type FsStore,
} from '../lib/store.js';
import { WORKER_TURN_LAUNCH_POLICY_SNAPSHOT_ID } from '../policy/permission-decisions.js';
import type { SchedulerWorkerStorageChoice } from '../scheduler-records.js';
import { type CoreDb, openWorkspaceDb, type WorkspaceDb } from '../storage/db.js';
import { resolveWorkspaceKnowledgeRetrievalPages } from '../storage/index-rebuild.js';
import { applyScopedMigrations } from '../storage/migrate.js';
import { readWorkObservationTurnBinding } from '../storage/work-observations.js';
import {
  AgentSessionRetainedStorageSchema,
  isCurrentAgentSessionStatus,
} from '../storage/workspace-file-records.js';
import type { VaultBackend } from '../vault/vault-backend.js';
import {
  type CreateVaultInjectionReceiptInput,
  createVaultInjectionReceipt,
} from '../vault-injection-receipts.js';
import {
  consumeQueuedThreadMaterialRevision,
  type QueuedThreadMaterialSelection,
  selectQueuedThreadMaterialRevision,
} from '../workspace-materials.js';
import type { WorkspaceMutationAdmission } from '../workspace-mutation-admission.js';
import { recordAgentEnvironmentPackageSnapshot } from './aep-snapshot-ledger.js';
import {
  type AgentEnvironmentPackagePreview,
  type PreparedWorkerContextPackage,
  type ResolveAgentEnvironmentBackendInput,
  type ResolvedAgentEnvironmentProviderCredential,
  type ResolvedAgentEnvironmentRuntimeEnvCredential,
  type ResolvedAgentEnvironmentRuntimeFileCredential,
  resolveAgentEnvironmentPackage,
  resolveAgentEnvironmentPackageMetadata,
} from './agent-environment.js';
import { DeterministicAgentPreparationError } from './agent-preparation-error.js';
import {
  acceptSchedulerExecutionObservation,
  closeSchedulerExecutionAttemptWithFence,
  closeSchedulerExecutionAttemptWithoutEffects,
  listSchedulerExecutionAttemptsForTurn,
  markSchedulerExecutionAttemptClosing,
  recordSchedulerExecutionOperation,
  requireSchedulerExecutionAttempt,
  schedulerExecutionCorrelation,
} from './execution-attempt-records.js';
import { commandInputHash } from './idempotent-command.js';
import { bindNanoHostAttemptPreparation } from './nanohost-attempt-records.js';
import { TurnStartValidationError } from './orchestrator.js';
import {
  frozenPendingOutcomeInput,
  listThreadPendingRequests,
  pendingRequestSystemActor,
  proveFrozenDelivery,
} from './pending-requests.js';
import type { PublicNetworkConfiguration } from './public-network-grants.js';
import type {
  AgentSessionReadModel,
  CommitPreparedAgentSessionForTurnInput,
  PrepareAgentSessionForTurnInput,
  PreparedAgentSessionForTurn,
  PreparedCurrentAgentSession,
  RuntimeCapabilities,
  RuntimeEventFamily,
  RuntimeItemType,
  TurnCommandRuntimeContext,
  TurnExecutor,
  TurnStartRuntimeContext,
} from './types.js';
import { projectWorkerBackendCleanup } from './worker-backend-cleanup-projection.js';
import {
  markWorkerBackendSessionLaunching,
  markWorkerBackendWorkspaceHandoffComplete,
  recordWorkerBackendSessionMaterializing,
  transitionWorkerBackendSessionState,
  type WorkerBackendSessionRecord,
  workerBackendImageIdentity,
  workerBackendLineageFromRuntimeImage,
} from './worker-backend-sessions.js';
import {
  getWorkerCheckpoint,
  parseWorkerCheckpointContextAssembly,
  type WorkerCheckpointRecord,
} from './worker-checkpoints.js';
import type { WorkerControlGateway } from './worker-control-gateway.js';
import {
  type AcceptedWorkerFinalStatus,
  canonicalStopReasonForAcceptedWorkerFinalStatus,
  getWorkerControlAcceptedFinalStatus,
  listWorkerControlAcceptedEvents,
  turnStatusForCanonicalWorkerStopReason,
} from './worker-control-records.js';
import {
  WORKER_ARTIFACT_COLLECTION_INVALID,
  type WorkerGovernanceAgentSessionContinuityDisposition,
  type WorkerGovernanceBackend,
  type WorkerGovernanceBackendSessionIdentity,
  WorkerGovernanceCapacityUnavailableError,
  type WorkerGovernanceEvidenceRecord,
  type WorkerGovernanceNativeResume,
  type WorkerGovernanceWorkspaceChangeRecord,
  WorkerNativeProofValidationError,
} from './worker-governance-backend.js';
import { importWorkerRuntimeProvenance } from './worker-runtime-provenance.js';
import {
  getWorkerStorageBinding,
  resolveWorkerStorageWorkSlotRef,
  workerStorageDefaultWorkSlotRef,
} from './worker-storage-bindings.js';
import { importWorkerTranscript } from './worker-transcript.js';
import { terminalizeGovernedWorkerTurn } from './worker-turn-failure.js';
import { bindWorkerCheckpointToPreparedSession } from './worker-turn-loop.js';
import { recordFilesystemWorkspaceStagingRoot } from './workspace-filesystem-staging.js';
import {
  buildWorkspaceInputSnapshots,
  buildWorkspaceMaterializationRecords,
} from './workspace-materializer.js';
import {
  listWorkspaceInputSnapshots,
  listWorkspaceMaterializationRecords,
  recordWorkspaceBackendHandoff,
  recordWorkspaceSyncReview,
} from './workspace-sync-records.js';

/** Returns the closed continuity disposition while retaining any cleanup proof separately. */
function workerGovernanceContinuityDisposition(
  result: WorkerGovernanceAgentSessionContinuityDisposition
): 'reusable' | 'replacement-required' | 'sandbox-replacement-required' | 'closed' | 'absent' {
  return typeof result === 'string' ? result : result.disposition;
}

/**
 * Selects the resume pair a successor's new binding presents, or null to start a new native
 * conversation. The predecessor is the Thread's latest-created other AgentSession: a Thread holds
 * at most one current AgentSession, and a successor is created only after its predecessor is
 * terminal, so creation order is predecessor order. A predecessor with an accepted ready proof
 * supplies its own pair. One without proof never had a resumed open accepted, or lost only the
 * record of one, because a resumed open proves the resume pair's exact digest; either way the
 * Thread's retained conversation is the one the predecessor would have resumed, so the walk moves
 * to the next earlier AgentSession. Unproved native state is never inherited, so a Thread with no
 * accepted proof starts a new conversation.
 *
 * @param agentSessions Every AgentSession of the Thread.
 * @param successorId AgentSession the new binding belongs to, excluded from the walk.
 * @throws TurnStartValidationError when creation order or the accepted proof's storage provenance is unproved.
 */
function selectThreadNativeResumeSource(
  agentSessions: readonly ReturnType<FsStore['getAgentSession']>[],
  successorId: string
): ReturnType<FsStore['getAgentSession']> | null {
  const ordered = agentSessions
    .filter((candidate) => candidate.id !== successorId)
    .sort((left, right) =>
      left.createdAt === right.createdAt ? 0 : left.createdAt < right.createdAt ? 1 : -1
    );
  for (const [index, candidate] of ordered.entries()) {
    if (ordered[index + 1]?.createdAt === candidate.createdAt) {
      throw new TurnStartValidationError(
        'recovery_required',
        'The Thread AgentSession order is ambiguous, so its resume predecessor is unproved.',
        409
      );
    }
    if (candidate.nativeHandleDigest !== null) {
      if (!AgentSessionRetainedStorageSchema.safeParse(candidate.retainedStorage).success) {
        throw new TurnStartValidationError(
          'recovery_required',
          'The native resume predecessor has no proven retained-storage attachment.',
          409
        );
      }
      return candidate;
    }
  }
  return null;
}

/** Mutable exact-backend lifecycle retained while one turn executes and cleans up. */
interface WorkerTurnBackendLifecycle {
  /** Pure physical identity used for every cleanup attempt. */
  readonly identity: WorkerGovernanceBackendSessionIdentity;
  /** Durable Core lifecycle record when the turn is scheduler-owned. */
  session: WorkerBackendSessionRecord | null;
  /** Stable successful cleanup timestamp retained across workspace projection retries. */
  physicalCleanedAt: string | null;
  /** Whether the atomic workspace handoff transaction committed. */
  workspaceHandoffState: 'pending' | 'complete';
}

/** Prepared S39 package state retained until its accepted trace and queue handoff complete. */
export interface PreparedWorkerTurnContext {
  /** Task diagnostic lineage, absent for an outcome-initiated Turn. */
  readonly checkpoint: WorkerCheckpointRecord | null;
  /** Exact scheduler request identity, including checkpoint-free outcome Turns. */
  readonly requestId: string;
  /** Canonical package bytes and immutable identity. */
  readonly packageFiles: WorkerContextPackageFiles;
  /** Backend-private generated root projected into the AEP and materializer. */
  readonly preparedContextPackage: PreparedWorkerContextPackage;
  /** Canonical Workspace root that owns package files and the accepted trace. */
  readonly workspaceRoot: string;
  /** Included automatic Material queue candidate, when eligible. */
  readonly queuedMaterialSelection: QueuedThreadMaterialSelection | null;
  /** Addressed automatic Material candidates excluded by the closed S39 rules. */
  readonly materialExclusions: readonly WorkerContextPackageMaterialExclusion[];
  /** Exact S61 selection invocation consumed by this direct Task. */
  readonly knowledgeSelectionInput: WorkerContextPackageKnowledgeSelectionReference | null;
  /** S61-selected Knowledge pages omitted only by the later S39 package budget. */
  readonly knowledgeExclusions: readonly WorkerContextPackageKnowledgeExclusion[];
}

/**
 * Prepares the one accepted S39 package from a Task checkpoint or frozen Pending Request input.
 *
 * @param coreDb Core authority used to reverify accepted Knowledge work references.
 * @param workspaceDb Open Workspace database containing checkpoint and Material authority.
 * @param store Product store containing canonical Thread Items.
 * @param checkpoint Exact Task diagnostic checkpoint, or null for an outcome-initiated Turn.
 * @param input Exact worker Turn, command, and request bytes.
 * @returns Prepared immutable package state.
 * @throws TurnStartValidationError when checkpoint or requested Item authority is contradictory.
 */
export function prepareWorkerTurnContextPackage(
  coreDb: CoreDb | null,
  workspaceDb: WorkspaceDb,
  store: FsStore,
  checkpoint: WorkerCheckpointRecord | null,
  input: {
    readonly agentSessionId: string;
    readonly workerRequest: string;
    readonly requestId: string | null;
    readonly workspaceId: string;
    readonly threadId: string;
    readonly turnId: string;
  }
): PreparedWorkerTurnContext {
  if (
    !input.requestId ||
    (checkpoint &&
      (checkpoint.requestId !== input.requestId ||
        (checkpoint.goalId === null) !== (checkpoint.taskId === null)))
  ) {
    throw new TurnStartValidationError(
      'recovery_required',
      'Worker Context Package checkpoint lineage is contradictory.',
      409
    );
  }

  const workerRequest = projectWorkerContextRequest(input.workerRequest);
  if (!checkpoint && workerRequest.requestKind !== 'pending-outcomes') {
    throw new TurnStartValidationError(
      'recovery_required',
      'Worker Context Package requires Task or frozen outcome authority.',
      409
    );
  }
  const contextBudgetTokens = workerRequest.contextBudgetTokens;
  const contextAssembly = checkpoint
    ? parseWorkerCheckpointContextAssembly(checkpoint.diagnosticsSummary)
    : null;
  const knowledgeSelectionInput = contextAssembly?.knowledgeSelectionInput ?? null;
  const turn = store.getTurn(input.workspaceId, input.threadId, input.turnId);
  const isChatSubordinateTask = isChatSubordinateTaskTurn({
    originatingThreadId: store.getThread(input.workspaceId, input.threadId).parentThreadId ?? null,
    requestId: input.requestId,
    turn,
  });
  const isTask =
    workerRequest.requestKind === 'structured-delegation' && checkpoint?.goalId === null;
  // Direct Task entry requires selection. A Chat handoff retains its entry's existing
  // selection choice; changing its identity must not add or remove a query.
  if (
    (isTask && !isChatSubordinateTask && knowledgeSelectionInput === null) ||
    (!isTask && knowledgeSelectionInput !== null)
  ) {
    throw new TurnStartValidationError(
      'recovery_required',
      'Worker Context Package Task Knowledge selection authority is contradictory.',
      409
    );
  }
  const workerRequestItemId = deriveEntityId('it', ['task-user', input.turnId]);
  const requestedItemIds = new Set(workerRequest.requestedItemIds);
  requestedItemIds.delete(workerRequestItemId);
  const includedPriorItems = store
    .listThreadItems(input.workspaceId, input.threadId)
    .filter((item) => requestedItemIds.delete(item.id));
  if (requestedItemIds.size > 0) {
    throw new TurnStartValidationError(
      'recovery_required',
      'Worker Context Package Item authority is unavailable.',
      409
    );
  }
  const queuedMaterial = selectQueuedThreadMaterialRevision(workspaceDb, input.threadId);
  const materialSelections: WorkerContextPackageMaterialSelectionInput[] = [];
  const materialExclusions: WorkerContextPackageMaterialExclusion[] = [];
  let selectedContextBytes = Buffer.byteLength(input.workerRequest, 'utf8');
  let queuedMaterialSelection: QueuedThreadMaterialSelection | null = null;
  const bindingCandidate = queuedMaterial;
  if (bindingCandidate?.inclusionState === 'excluded') {
    materialExclusions.push({
      materialId: bindingCandidate.materialId,
      reason: 'explicit_scope_excluded',
      revisionId: bindingCandidate.revisionId,
      sensitivity: bindingCandidate.sensitivity,
    });
  } else if (bindingCandidate?.sensitivity === 'restricted') {
    materialExclusions.push({
      materialId: bindingCandidate.materialId,
      reason: 'sensitive_content',
      revisionId: bindingCandidate.revisionId,
      sensitivity: bindingCandidate.sensitivity,
    });
  } else if (bindingCandidate) {
    const bindingContentBytes = Buffer.byteLength(bindingCandidate.content, 'utf8');
    if (Math.ceil((selectedContextBytes + bindingContentBytes) / 4) > contextBudgetTokens) {
      materialExclusions.push({
        materialId: bindingCandidate.materialId,
        reason: 'budget_exceeded',
        revisionId: bindingCandidate.revisionId,
        sensitivity: bindingCandidate.sensitivity,
      });
    } else {
      materialSelections.push({
        bindingMutationRequestId: bindingCandidate.bindingMutationRequestId,
        content: bindingCandidate.content,
        contentDigest: bindingCandidate.contentDigest,
        inclusionReason: bindingCandidate.inclusionReason,
        materialId: bindingCandidate.materialId,
        mediaType: bindingCandidate.mediaType,
        parentRevisionId: bindingCandidate.parentRevisionId,
        revisionId: bindingCandidate.revisionId,
        sensitivity: bindingCandidate.sensitivity,
      });
      queuedMaterialSelection = bindingCandidate;
    }
  }

  const knowledgeSelections: WorkerContextPackageKnowledgeSelectionInput[] = [];
  const knowledgeExclusions: WorkerContextPackageKnowledgeExclusion[] = [];
  if (knowledgeSelectionInput) {
    let pages: ReturnType<typeof resolveWorkspaceKnowledgeRetrievalPages>;
    try {
      pages = resolveWorkspaceKnowledgeRetrievalPages({
        caller: 'task-mode',
        dataRoot: workspaceDb.dataRoot,
        access: {
          store,
          coreDb: coreDb ?? undefined,
          actor: store.getTurnById(input.turnId).triggerActor,
          outputThreadId: input.threadId,
          outputTurnId: input.turnId,
        },
        retrievalTraceRef: knowledgeSelectionInput.retrievalTraceRef,
        workspaceId: input.workspaceId,
      });
    } catch {
      throw new TurnStartValidationError(
        'recovery_required',
        'Worker Context Package Knowledge selection is contradictory.',
        409
      );
    }
    if (!pages) {
      throw new TurnStartValidationError(
        'source_unavailable',
        'Worker Context Package Knowledge source is unavailable.',
        503
      );
    }
    for (const page of pages) {
      const pageBytes = Buffer.byteLength(page.content, 'utf8');
      if (Math.ceil((selectedContextBytes + pageBytes) / 4) > contextBudgetTokens) {
        knowledgeExclusions.push({
          contentDigest: page.contentDigest,
          knowledgePageId: page.knowledgePageId,
          reason: 'budget_exceeded',
        });
        continue;
      }
      selectedContextBytes += pageBytes;
      knowledgeSelections.push(page);
    }
  }

  const includedItemIds = [workerRequestItemId, ...includedPriorItems.map((item) => item.id)];
  const packageFiles = createWorkerContextPackageFiles({
    contextBudgetTokens,
    includedItemIds,
    knowledgeSelections,
    materialSelections,
    threadId: input.threadId,
    turnId: input.turnId,
    workerRequestBytes: input.workerRequest,
    workerRequestItemId,
    workspaceId: input.workspaceId,
  });
  const workspaceRoot = join(workspaceDb.dataRoot, 'workspaces', workspaceDb.workspaceId);
  const packageRoot = join(
    workspaceRoot,
    'threads',
    input.threadId,
    'turns',
    input.turnId,
    'context-package'
  );
  writeWorkerContextPackageFiles(workspaceRoot, packageFiles);
  return {
    checkpoint,
    requestId: input.requestId,
    knowledgeExclusions,
    knowledgeSelectionInput,
    materialExclusions,
    packageFiles,
    preparedContextPackage: {
      contentDigest: packageFiles.packageRootDigest,
      workspaceRoot: {
        access: 'read-only',
        id: `context_${input.turnId}`,
        sourceKind: 'materialized-dir',
        sourcePath: packageRoot,
        workerPath: workerSessionInputPaths(input.agentSessionId).contextRoot,
      },
    },
    queuedMaterialSelection,
    workspaceRoot,
  };
}

/**
 * Publishes and strictly reverifies one prepared S39 package before consuming its input owners.
 *
 * @param input Existing Core, Workspace, product, package, and AEP authorities.
 * @returns Strictly accepted immutable worker Context Package trace.
 * @throws Error when any delivery owner, package byte, handoff, or queue proof is contradictory.
 */
export function acceptPreparedWorkerTurnContextPackage(input: {
  readonly coreDb: CoreDb;
  readonly environmentPackage: AgentEnvironmentPackage;
  readonly preparedContext: PreparedWorkerTurnContext;
  readonly store: FsStore;
  readonly workspaceDb: WorkspaceDb;
}): WorkerContextPackageTrace {
  const { environmentPackage, preparedContext, workspaceDb } = input;
  const authorities = createWorkerContextPackageAuthorityReader({
    coreDb: input.coreDb,
    store: input.store,
    workspaceDb,
  });
  const trace = createWorkerContextPackageTrace({
    agentSessionId: environmentPackage.scope.agentSessionId,
    excludedItems: [],
    goalId: preparedContext.checkpoint?.goalId ?? null,
    knowledgeExclusions: preparedContext.knowledgeExclusions,
    knowledgeSelectionInput: preparedContext.knowledgeSelectionInput,
    materialExclusions: preparedContext.materialExclusions,
    packageFiles: preparedContext.packageFiles,
    packageSnapshotId: environmentPackage.snapshotId,
    requestId: preparedContext.requestId,
    taskId: preparedContext.checkpoint?.taskId ?? null,
  });
  writeWorkerContextPackageTrace({
    authorities,
    trace,
    workspaceRoot: preparedContext.workspaceRoot,
  });
  const acceptedTrace = readWorkerContextPackageTrace({
    authorities,
    threadId: environmentPackage.scope.threadId,
    turnId: environmentPackage.scope.turnId,
    workspaceId: environmentPackage.scope.workspaceId,
    workspaceRoot: preparedContext.workspaceRoot,
  });

  workspaceDb.sqlite.transaction(() => {
    const queuedMaterial = preparedContext.queuedMaterialSelection;
    if (queuedMaterial) {
      consumeQueuedThreadMaterialRevision(
        workspaceDb,
        environmentPackage.scope.threadId,
        queuedMaterial.materialId,
        queuedMaterial.revisionId,
        queuedMaterial.bindingMutationRequestId
      );
    }
  })();

  return acceptedTrace;
}

/**
 * Options for the worker-governance-backed turn executor.
 */
export interface WorkerGovernanceTurnExecutorOptions {
  /** Active configuration snapshot for resolution-time public-route admission. */
  readRuntimeConfig?: (() => PublicNetworkConfiguration) | undefined;
  /** Optional durable completion barrier used after a detached backend launch. */
  awaitWorkerCompletion?:
    | ((
        environmentPackage: AgentEnvironmentPackage,
        attemptId: string
      ) => Promise<AcceptedWorkerFinalStatus>)
    | undefined;
  /** Backend that materializes, launches, collects, and tears down worker sessions. */
  backend: WorkerGovernanceBackend;
  /** Optional Core database used to persist workspace synchronization records. */
  coreDb?: CoreDb | undefined;
  /** Optional deterministic AgentSession id factory for tests. */
  createAgentSessionId?: (() => string) | undefined;
  /** Optional clock for deterministic tests. */
  now?: (() => string) | undefined;
  /** Optional deterministic runtime provenance importer for tests. */
  runtimeProvenanceImporter?: typeof importWorkerRuntimeProvenance | undefined;
  /** Resolves an exact work slot from a compatible resident Sandbox without effects. */
  resolveResidentWorkerStorageWorkSlotRef?:
    | ((environmentPackage: AgentEnvironmentPackagePreview) => string | null)
    | undefined;
  /** Optional vault backend used for grant-derived provider attachments. */
  vaultBackend?: (() => VaultBackend) | undefined;
  /** Optional shared worker-control gateway used to enqueue live-session interrupts. */
  workerControlGateway?: WorkerControlGateway | undefined;
  /** Optional shared Workspace deletion fence for late transcript publication. */
  workspaceMutationAdmission?: WorkspaceMutationAdmission | undefined;
}

/**
 * Turn executor that runs one worker through a WorkerGovernanceBackend.
 */
export class WorkerGovernanceTurnExecutor implements TurnExecutor {
  public readonly capabilities: RuntimeCapabilities;

  public readonly eventFamilies: readonly RuntimeEventFamily[] = [
    'turn.started',
    'turn.updated',
    'item.created',
    'item.completed',
    'artifact.created',
    'agent.session.updated',
    'turn.completed',
    'error',
  ];

  public readonly itemTypes: readonly RuntimeItemType[] = [
    'user-message',
    'assistant-message',
    'artifact-reference',
    'status',
  ];

  private readonly awaitWorkerCompletion:
    | ((
        environmentPackage: AgentEnvironmentPackage,
        attemptId: string
      ) => Promise<AcceptedWorkerFinalStatus>)
    | null;
  private readonly readRuntimeConfig: (() => PublicNetworkConfiguration) | null;
  private readonly backend: WorkerGovernanceBackend;
  /** Configured four-operation boundary; the executor retains its existing preparation and closeout responsibility. */
  public readonly executionBackend: import('./execution-backend.js').ExecutionBackend;
  private readonly coreDb: CoreDb | null;
  private readonly createAgentSessionId: () => string;
  private readonly now: () => string;
  private readonly resolveResidentWorkerStorageWorkSlotRef:
    | ((environmentPackage: AgentEnvironmentPackagePreview) => string | null)
    | null;
  private readonly runtimeProvenanceImporter: typeof importWorkerRuntimeProvenance;
  private readonly vaultBackend: (() => VaultBackend) | null;
  private readonly workerControlGateway: WorkerControlGateway | null;
  private readonly workspaceMutationAdmission: WorkspaceMutationAdmission | null;
  /** Live lifecycle ownership through cleanup and terminal publication; never restored. */
  private readonly activeTurnExecutions = new Set<string>();

  /**
   * Creates the governance-backed turn executor.
   *
   * @param options Backend, package target, and optional deterministic factories.
   */
  public constructor(options: WorkerGovernanceTurnExecutorOptions) {
    this.awaitWorkerCompletion = options.awaitWorkerCompletion ?? null;
    this.backend = options.backend;
    this.executionBackend = options.backend;
    this.readRuntimeConfig = options.readRuntimeConfig ?? null;
    this.capabilities = {
      approvals: false,
      artifacts: true,
      interrupts: Boolean(options.workerControlGateway && options.backend.interruptTurn),
      questions: false,
      workspaceConfig: true,
      workspaceKnowledgeEditing: false,
    };
    this.coreDb = options.coreDb ?? null;
    this.createAgentSessionId = options.createAgentSessionId ?? (() => allocateEntityId('as'));
    this.now = options.now ?? (() => new Date().toISOString());
    this.resolveResidentWorkerStorageWorkSlotRef =
      options.resolveResidentWorkerStorageWorkSlotRef ?? null;
    this.runtimeProvenanceImporter =
      options.runtimeProvenanceImporter ?? importWorkerRuntimeProvenance;
    this.vaultBackend = options.vaultBackend ?? null;
    this.workerControlGateway = options.workerControlGateway ?? null;
    this.workspaceMutationAdmission = options.workspaceMutationAdmission ?? null;
  }

  /** Hands off surviving ready proof before previewing continuity, without replacement effects. */
  public async prepareAgentSessionForTurn(
    store: FsStore,
    input: PrepareAgentSessionForTurnInput
  ): Promise<PreparedAgentSessionForTurn> {
    if (!isEntityId('as', input.freshAgentSessionId)) {
      throw new TurnStartValidationError(
        'recovery_required',
        'The reserved AgentSession identity is invalid.',
        409
      );
    }
    let workerStorageChoice = this.selectContinuationStorage(
      store,
      input,
      input.workerStorageChoice
    );
    input = { ...input, ...(workerStorageChoice ? { workerStorageChoice } : {}) };
    const currentSessions = store
      .listThreadAgentSessions(input.turn.workspaceId, input.turn.threadId)
      .filter((candidate) => isCurrentAgentSessionStatus(candidate.status));
    if (currentSessions.length > 1) {
      throw new TurnStartValidationError(
        'recovery_required',
        'The Thread has multiple current AgentSessions.',
        409
      );
    }
    let current = currentSessions[0];
    if (!current) {
      let blockingBinding: { readonly agentSessionId: string } | null | undefined;
      try {
        blockingBinding = this.backend.readThreadAgentSessionBinding?.({
          threadId: input.turn.threadId,
          workspaceId: input.turn.workspaceId,
        });
      } catch (error) {
        if (error instanceof WorkerGovernanceCapacityUnavailableError) throw error;
        throw new TurnStartValidationError(
          'recovery_required',
          'The worker backend is not ready for fresh AgentSession admission.',
          409
        );
      }
      if (blockingBinding) {
        try {
          current = store.getAgentSession(blockingBinding.agentSessionId);
        } catch {
          throw new TurnStartValidationError(
            'recovery_required',
            'The worker backend is not ready for fresh AgentSession admission.',
            409
          );
        }
        if (
          current.threadId !== input.turn.threadId ||
          current.workspaceId !== input.turn.workspaceId ||
          (current.status !== 'failed' &&
            current.status !== 'interrupted' &&
            current.status !== 'closed')
        ) {
          throw new TurnStartValidationError(
            'recovery_required',
            'The worker backend is not ready for fresh AgentSession admission.',
            409
          );
        }
      }
    }
    if (current) {
      const currentAgentSessionId = current.id;
      const currentTurns = store
        .listThreadTurns(input.turn.workspaceId, input.turn.threadId)
        .filter((turn) => turn.agentSessionId === currentAgentSessionId);
      if (currentTurns.some((turn) => !isSealedTurnTerminal(turn.status))) {
        throw new TurnStartValidationError(
          'recovery_required',
          'The current AgentSession still owns an active Turn.',
          409
        );
      }
    }
    if (current && current.nativeHandleDigest === null) {
      if (!this.backend.prepareAgentSessionContinuity) {
        throw new TurnStartValidationError(
          'recovery_required',
          'The worker backend cannot inspect surviving native proof.',
          409
        );
      }
      let proofInspection: WorkerGovernanceAgentSessionContinuityDisposition;
      try {
        // Inspect the old identity without planning a desired work slot or any replacement effect.
        proofInspection = await this.backend.prepareAgentSessionContinuity({
          agentSessionId: current.id,
          recordNativeHandleDigest: (digest, retainedStorage) =>
            this.recordNativeHandleDigest(store, current!.id, digest, retainedStorage),
          reuseAllowed: true,
          threadId: input.turn.threadId,
          workspaceId: input.turn.workspaceId,
        });
      } catch (error) {
        if (error instanceof WorkerGovernanceCapacityUnavailableError) throw error;
        throw new TurnStartValidationError(
          'recovery_required',
          'The surviving native proof cannot be joined to its retained-storage attachment.',
          409
        );
      }
      if (
        !['reusable', 'replacement-required', 'sandbox-replacement-required', 'absent'].includes(
          workerGovernanceContinuityDisposition(proofInspection)
        )
      ) {
        throw new TurnStartValidationError(
          'recovery_required',
          'Native proof inspection performed a replacement effect.',
          409
        );
      }
      current = store.getAgentSession(current.id);
      workerStorageChoice = this.selectContinuationStorage(store, input, workerStorageChoice);
      input = { ...input, ...(workerStorageChoice ? { workerStorageChoice } : {}) };
    }
    if (!current) {
      if (!this.backend.prepareAgentSessionContinuity) {
        throw new TurnStartValidationError(
          'recovery_required',
          'The worker backend cannot prove fresh AgentSession admission readiness.',
          409
        );
      }
      const sessionCompatibilityKey = this.previewAgentSessionCompatibilityKey(
        input.freshAgentSessionId,
        input
      );
      const environmentPackage = this.previewAgentEnvironmentPackage(
        input.freshAgentSessionId,
        input
      );
      this.requireMaterializationCapacity(input.freshAgentSessionId, input);
      let disposition: WorkerGovernanceAgentSessionContinuityDisposition;
      try {
        disposition = await this.backend.prepareAgentSessionContinuity({
          agentSessionCompatibilityKey: sessionCompatibilityKey,
          agentSessionId: input.freshAgentSessionId,
          environmentPackage,
          ...(workerStorageChoice ? { workerStorageChoice } : {}),
          reuseAllowed: true,
          threadId: input.turn.threadId,
          workspaceId: input.turn.workspaceId,
        });
      } catch (error) {
        if (error instanceof WorkerGovernanceCapacityUnavailableError) throw error;
        throw new TurnStartValidationError(
          'recovery_required',
          'The worker backend is not ready for fresh AgentSession admission.',
          409
        );
      }
      if (workerGovernanceContinuityDisposition(disposition) !== 'absent') {
        throw new TurnStartValidationError(
          'recovery_required',
          'Fresh AgentSession admission did not prove absent durable continuity.',
          409
        );
      }
      return {
        ...(workerStorageChoice ? { workerStorageChoice } : {}),
        agentSessionId: input.freshAgentSessionId,
        currentAgentSession: null,
        replacementRequired: false,
        sessionCompatibilityKey,
      };
    }
    const currentCompatibilityKey = this.previewAgentSessionCompatibilityKey(current.id, input);
    const currentEnvironmentPackage = this.previewAgentEnvironmentPackage(current.id, input);
    this.requireMaterializationCapacity(current.id, input);
    const reuseAllowed =
      current.status === 'idle' &&
      !current.stale &&
      current.agentId === input.agentSetup.manifest.id &&
      current.policySnapshotId === WORKER_TURN_LAUNCH_POLICY_SNAPSHOT_ID &&
      current.sessionCompatibilityKey === currentCompatibilityKey;
    if (!this.backend.prepareAgentSessionContinuity) {
      throw new TurnStartValidationError(
        'recovery_required',
        'The worker backend cannot prove current AgentSession continuity.',
        409
      );
    }
    let disposition: WorkerGovernanceAgentSessionContinuityDisposition;
    try {
      disposition = await this.backend.prepareAgentSessionContinuity({
        agentSessionCompatibilityKey: currentCompatibilityKey,
        agentSessionId: current.id,
        environmentPackage: currentEnvironmentPackage,
        recordNativeHandleDigest: (digest, retainedStorage) =>
          this.recordNativeHandleDigest(store, current.id, digest, retainedStorage),
        reuseAllowed: true,
        threadId: input.turn.threadId,
        workspaceId: input.turn.workspaceId,
      });
    } catch (error) {
      if (error instanceof WorkerGovernanceCapacityUnavailableError) throw error;
      throw new TurnStartValidationError(
        'recovery_required',
        'The current AgentSession runtime binding cannot be safely inspected.',
        409
      );
    }
    const currentAgentSession: PreparedCurrentAgentSession = {
      agentId: current.agentId,
      id: current.id,
      policySnapshotId: current.policySnapshotId,
      sessionCompatibilityKey: current.sessionCompatibilityKey,
      stale: current.stale,
      status: current.status,
      updatedAt: current.updatedAt,
    };
    if (reuseAllowed && workerGovernanceContinuityDisposition(disposition) === 'reusable') {
      // Ready proof can survive only on the runtime binding after a failed digest handoff.
      if (!AgentSessionRetainedStorageSchema.safeParse(current.retainedStorage).success) {
        throw new TurnStartValidationError(
          'recovery_required',
          'The reusable native binding has no proven retained-storage attachment.',
          409
        );
      }
      return {
        ...(workerStorageChoice ? { workerStorageChoice } : {}),
        agentSessionId: current.id,
        currentAgentSession,
        replacementRequired: false,
        sessionCompatibilityKey: currentCompatibilityKey,
      };
    }
    if (
      !['reusable', 'replacement-required', 'sandbox-replacement-required', 'absent'].includes(
        workerGovernanceContinuityDisposition(disposition)
      )
    ) {
      throw new TurnStartValidationError(
        'recovery_required',
        'The worker backend performed an effect during read-only continuity inspection.',
        409
      );
    }
    const freshCompatibilityKey = this.previewAgentSessionCompatibilityKey(
      input.freshAgentSessionId,
      input
    );
    this.requireMaterializationCapacity(input.freshAgentSessionId, input);
    return {
      ...(workerStorageChoice ? { workerStorageChoice } : {}),
      agentSessionId: input.freshAgentSessionId,
      currentAgentSession,
      replacementRequired: true,
      sessionCompatibilityKey: freshCompatibilityKey,
    };
  }

  /** Revalidates one preview after dispatch and commits exact predecessor replacement. */
  public async commitPreparedAgentSessionForTurn(
    store: FsStore,
    input: CommitPreparedAgentSessionForTurnInput
  ): Promise<SchedulerWorkerStorageChoice | undefined> {
    const { prepared } = input;
    if (!this.coreDb) throw new Error('Attempt preparation requires Core storage.');
    bindNanoHostAttemptPreparation(this.coreDb, {
      attemptId: input.attemptId,
      agentSessionId: prepared.agentSessionId,
      inputRef: `aepsnap_${input.preparation.turn.id}_${prepared.agentSessionId}`,
      bindingRef: `attempt-binding:${input.attemptId}`,
      sessionCompatibilityKey: prepared.sessionCompatibilityKey,
    });
    // Keep the captured revision; a revalidation must never rebase a caller or prepared choice.
    const workerStorageChoice = this.selectContinuationStorage(
      store,
      input.preparation,
      prepared.workerStorageChoice ?? input.preparation.workerStorageChoice
    );
    const preparation = {
      ...input.preparation,
      ...(workerStorageChoice ? { workerStorageChoice } : {}),
    };
    const currentSessions = store
      .listThreadAgentSessions(preparation.turn.workspaceId, preparation.turn.threadId)
      .filter((candidate) => isCurrentAgentSessionStatus(candidate.status));
    if (!this.backend.prepareAgentSessionContinuity) {
      throw new TurnStartValidationError(
        'recovery_required',
        'The worker backend cannot commit AgentSession admission.',
        409
      );
    }
    const inspectBackendContinuity = async (
      agentSessionId: string,
      agentSessionCompatibilityKey: string,
      environmentPackage: AgentEnvironmentPackagePreview,
      reuseAllowed: boolean
    ) => {
      try {
        return await this.backend.prepareAgentSessionContinuity!({
          admissionAgentSessionId: prepared.agentSessionId,
          admissionAttemptId: input.attemptId,
          agentSessionCompatibilityKey,
          agentSessionId,
          environmentPackage:
            environmentPackage.scope.agentSessionId === prepared.agentSessionId
              ? environmentPackage
              : this.previewAgentEnvironmentPackage(prepared.agentSessionId, preparation),
          recordNativeHandleDigest: (digest, retainedStorage) =>
            this.recordNativeHandleDigest(store, agentSessionId, digest, retainedStorage),
          reuseAllowed,
          ...(preparation.workerStorageChoice
            ? { workerStorageChoice: preparation.workerStorageChoice }
            : {}),
          threadId: preparation.turn.threadId,
          workspaceId: preparation.turn.workspaceId,
        });
      } catch (error) {
        if (error instanceof WorkerGovernanceCapacityUnavailableError) throw error;
        throw new TurnStartValidationError(
          'recovery_required',
          'The AgentSession runtime binding changed after scheduler dispatch.',
          409
        );
      }
    };

    if (!prepared.currentAgentSession) {
      if (prepared.replacementRequired || currentSessions.length !== 0) {
        throw new TurnStartValidationError(
          'recovery_required',
          'Fresh AgentSession admission changed after scheduler dispatch.',
          409
        );
      }
      const freshCompatibilityKey = this.previewAgentSessionCompatibilityKey(
        prepared.agentSessionId,
        preparation
      );
      const freshEnvironmentPackage = this.previewAgentEnvironmentPackage(
        prepared.agentSessionId,
        preparation
      );
      if (freshCompatibilityKey !== prepared.sessionCompatibilityKey) {
        throw new TurnStartValidationError(
          'recovery_required',
          'Fresh AgentSession compatibility changed after scheduler dispatch.',
          409
        );
      }
      this.requireMaterializationCapacity(prepared.agentSessionId, preparation);
      const disposition = await inspectBackendContinuity(
        prepared.agentSessionId,
        freshCompatibilityKey,
        freshEnvironmentPackage,
        true
      );
      if (
        typeof disposition === 'object' &&
        disposition.disposition === 'closed' &&
        workerStorageChoice?.kind === 'selected'
      ) {
        const advance = disposition.storageRevisionAdvance;
        if (
          advance.storageRef !== workerStorageChoice.storageRef ||
          advance.previousRevision !== workerStorageChoice.expectedRevision ||
          advance.revision !== advance.previousRevision + 1
        )
          throw new TurnStartValidationError(
            'recovery_required',
            'Selected retirement revision contradicts its captured owner.',
            409
          );
        return { ...workerStorageChoice, expectedRevision: advance.revision };
      }
      if (workerGovernanceContinuityDisposition(disposition) !== 'absent') {
        throw new TurnStartValidationError(
          'recovery_required',
          'Fresh AgentSession admission no longer has absent durable continuity.',
          409
        );
      }
      return workerStorageChoice;
    }

    const predecessorIsTerminal =
      prepared.currentAgentSession.status === 'failed' ||
      prepared.currentAgentSession.status === 'interrupted' ||
      prepared.currentAgentSession.status === 'closed';
    const current = predecessorIsTerminal
      ? store.getAgentSession(prepared.currentAgentSession.id)
      : currentSessions[0];
    const currentSnapshot: PreparedCurrentAgentSession | null = current
      ? {
          agentId: current.agentId,
          id: current.id,
          policySnapshotId: current.policySnapshotId,
          sessionCompatibilityKey: current.sessionCompatibilityKey,
          stale: current.stale,
          status: current.status,
          updatedAt: current.updatedAt,
        }
      : null;
    if (
      (predecessorIsTerminal
        ? currentSessions.length !== 0 || !prepared.replacementRequired
        : currentSessions.length !== 1 || current?.status !== 'idle' || current.stale) ||
      !isDeepStrictEqual(currentSnapshot, prepared.currentAgentSession) ||
      !current
    ) {
      throw new TurnStartValidationError(
        'recovery_required',
        predecessorIsTerminal
          ? 'The predecessor AgentSession changed after scheduler dispatch.'
          : 'The current AgentSession changed after scheduler dispatch.',
        409
      );
    }
    const hasActiveTurn = store
      .listThreadTurns(preparation.turn.workspaceId, preparation.turn.threadId)
      .some((turn) => turn.agentSessionId === current.id && !isSealedTurnTerminal(turn.status));
    if (hasActiveTurn) {
      throw new TurnStartValidationError(
        'recovery_required',
        'The current AgentSession acquired an active Turn after scheduler dispatch.',
        409
      );
    }
    const currentCompatibilityKey = this.previewAgentSessionCompatibilityKey(
      current.id,
      preparation
    );
    const currentEnvironmentPackage = this.previewAgentEnvironmentPackage(current.id, preparation);
    const reuseAllowed =
      current.agentId === preparation.agentSetup.manifest.id &&
      current.policySnapshotId === WORKER_TURN_LAUNCH_POLICY_SNAPSHOT_ID &&
      current.sessionCompatibilityKey === currentCompatibilityKey;

    if (!prepared.replacementRequired) {
      if (
        prepared.agentSessionId !== current.id ||
        prepared.sessionCompatibilityKey !== currentCompatibilityKey ||
        !reuseAllowed
      ) {
        throw new TurnStartValidationError(
          'recovery_required',
          'Reusable AgentSession admission changed after scheduler dispatch.',
          409
        );
      }
      this.requireMaterializationCapacity(current.id, preparation);
      const disposition = await inspectBackendContinuity(
        current.id,
        currentCompatibilityKey,
        currentEnvironmentPackage,
        true
      );
      if (workerGovernanceContinuityDisposition(disposition) !== 'reusable') {
        throw new TurnStartValidationError(
          'recovery_required',
          'Reusable AgentSession continuity changed after scheduler dispatch.',
          409
        );
      }
      return workerStorageChoice;
    }

    if (
      prepared.agentSessionId !== preparation.freshAgentSessionId ||
      prepared.agentSessionId === current.id
    ) {
      throw new TurnStartValidationError(
        'recovery_required',
        'Replacement AgentSession identity changed after scheduler dispatch.',
        409
      );
    }
    const freshCompatibilityKey = this.previewAgentSessionCompatibilityKey(
      prepared.agentSessionId,
      preparation
    );
    const freshEnvironmentPackage = this.previewAgentEnvironmentPackage(
      prepared.agentSessionId,
      preparation
    );
    if (freshCompatibilityKey !== prepared.sessionCompatibilityKey) {
      throw new TurnStartValidationError(
        'recovery_required',
        'Replacement AgentSession compatibility changed after scheduler dispatch.',
        409
      );
    }
    this.requireMaterializationCapacity(prepared.agentSessionId, preparation);
    const inspected = await inspectBackendContinuity(
      current.id,
      currentCompatibilityKey,
      currentEnvironmentPackage,
      true
    );
    if (
      !['reusable', 'replacement-required', 'sandbox-replacement-required', 'absent'].includes(
        workerGovernanceContinuityDisposition(inspected)
      )
    ) {
      throw new TurnStartValidationError(
        'recovery_required',
        'The predecessor AgentSession runtime inspection was not read-only.',
        409
      );
    }
    if (
      !isDeepStrictEqual(
        this.selectContinuationStorage(store, preparation, workerStorageChoice),
        workerStorageChoice
      )
    ) {
      throw new TurnStartValidationError(
        'recovery_required',
        'Native proof changed the prepared storage selection after scheduler dispatch.',
        409
      );
    }
    let committedWorkerStorageChoice = workerStorageChoice;
    if (workerGovernanceContinuityDisposition(inspected) !== 'absent') {
      const closed = await inspectBackendContinuity(
        current.id,
        currentCompatibilityKey,
        freshEnvironmentPackage,
        false
      );
      const closedDisposition = workerGovernanceContinuityDisposition(closed);
      if (closedDisposition !== 'closed' && closedDisposition !== 'absent') {
        throw new TurnStartValidationError(
          'recovery_required',
          'The worker backend did not retire predecessor AgentSession continuity.',
          409
        );
      }
      if (typeof closed !== 'string') {
        const choice = preparation.workerStorageChoice;
        const advance = closed.storageRevisionAdvance;
        if (
          choice?.kind !== 'selected' ||
          advance.storageRef !== choice.storageRef ||
          advance.previousRevision !== choice.expectedRevision ||
          advance.revision !== choice.expectedRevision + 1
        ) {
          throw new TurnStartValidationError(
            'recovery_required',
            'The worker backend returned a mismatched retained-storage cleanup revision.',
            409
          );
        }
        committedWorkerStorageChoice = { ...choice, expectedRevision: advance.revision };
      }
    }
    if (!predecessorIsTerminal) {
      store.updateAgentSession(current.id, {
        message: 'Replaced before a Turn with incompatible or unproved runtime continuity.',
        status: 'closed',
        updatedAt: this.now(),
      });
    }
    if (
      store
        .listThreadAgentSessions(preparation.turn.workspaceId, preparation.turn.threadId)
        .some((candidate) => isCurrentAgentSessionStatus(candidate.status))
    ) {
      throw new TurnStartValidationError(
        'recovery_required',
        'The predecessor AgentSession did not become terminal.',
        409
      );
    }
    return committedWorkerStorageChoice;
  }

  /** Joins native proof to its exact storage selection before package planning or replacement. */
  private selectContinuationStorage(
    store: FsStore,
    input: PrepareAgentSessionForTurnInput,
    choice: SchedulerWorkerStorageChoice | undefined
  ): SchedulerWorkerStorageChoice | undefined {
    const source = selectThreadNativeResumeSource(
      store.listThreadAgentSessions(input.turn.workspaceId, input.turn.threadId),
      input.freshAgentSessionId
    );
    if (!source) return choice;
    const retainedStorage = source.retainedStorage!;
    if (
      choice &&
      (choice.kind === 'fresh' ||
        choice.storageRef !== retainedStorage.storageRef ||
        (choice.reuseWorkSlotRef !== undefined &&
          choice.reuseWorkSlotRef !== retainedStorage.workSlotRef))
    ) {
      throw new TurnStartValidationError(
        'worker_storage_choice_conflict',
        'Worker storage choice conflicts with the expected native resume.',
        409
      );
    }
    if (choice?.kind === 'selected')
      return { ...choice, reuseWorkSlotRef: retainedStorage.workSlotRef };
    const binding = this.coreDb
      ? getWorkerStorageBinding(this.coreDb, { storageRef: retainedStorage.storageRef })
      : null;
    if (!binding)
      throw new TurnStartValidationError(
        'recovery_required',
        'The native resume storage association is unavailable.',
        409
      );
    return {
      kind: 'selected',
      storageRef: retainedStorage.storageRef,
      reuseWorkSlotRef: retainedStorage.workSlotRef,
      expectedRevision: binding.revision,
      purpose: 'work',
      goalId: null,
      taskId: null,
    };
  }

  /** Rejects admission when the current NanoHost target cannot host the resolved package. */
  private requireMaterializationCapacity(
    agentSessionId: string,
    input: PrepareAgentSessionForTurnInput
  ): void {
    if (!this.backend.inspectMaterializationCapacity) {
      return;
    }
    let capacity: 'available' | 'capacity-saturated';
    try {
      capacity = this.backend.inspectMaterializationCapacity(
        this.previewAgentEnvironmentPackage(agentSessionId, input)
      );
    } catch (cause) {
      // Never stringify arbitrary exceptions: Zod issues, paths and native errors can contain secrets.
      console.error(
        JSON.stringify({
          event: 'worker.admission.capacity-inspection-failed',
          errorCode: 'recovery_required',
          requestId: input.requestId,
          workspaceId: input.turn.workspaceId,
          threadId: input.turn.threadId,
          agentId: input.agentSetup.manifest.id,
          agentSessionId,
          ...(cause instanceof WorkerNativeProofValidationError && cause.diagnostic
            ? {
                proofAgentSessionId: cause.diagnostic.proofAgentSessionId,
                packageSnapshotId: cause.diagnostic.packageSnapshotId,
                attemptId: cause.diagnostic.attemptId,
                originPhysicalEpoch: cause.diagnostic.originPhysicalEpoch,
                attachmentPhysicalEpoch: cause.diagnostic.attachmentPhysicalEpoch,
              }
            : {}),
          errorClass:
            cause instanceof WorkerNativeProofValidationError
              ? 'WorkerNativeProofValidationError'
              : cause instanceof TurnStartValidationError
                ? 'TurnStartValidationError'
                : cause instanceof TypeError
                  ? 'TypeError'
                  : cause instanceof SyntaxError
                    ? 'SyntaxError'
                    : cause instanceof Error
                      ? 'Error'
                      : 'UnknownError',
          message:
            cause instanceof WorkerNativeProofValidationError
              ? 'Retained native-session proof disagrees with its original binding and package provenance.'
              : 'Worker backend materialization capacity inspection failed.',
          failedCheck:
            cause instanceof WorkerNativeProofValidationError
              ? cause.failedCheck
              : 'materialization-capacity-inspection',
        })
      );
      if (cause instanceof TurnStartValidationError) throw cause;
      const failure = new TurnStartValidationError(
        'recovery_required',
        'The worker backend materialization capacity cannot be safely inspected.',
        409
      );
      Object.defineProperty(failure, 'cause', { value: cause, configurable: true, writable: true });
      throw failure;
    }
    if (capacity === 'capacity-saturated') {
      throw new WorkerGovernanceCapacityUnavailableError();
    }
  }

  /** Computes the metadata-only compatibility key used by admission and full launch. */
  private previewAgentSessionCompatibilityKey(
    agentSessionId: string,
    input: PrepareAgentSessionForTurnInput
  ): string {
    return agentSessionCompatibilityKeyFromPackage(
      this.previewAgentEnvironmentPackage(agentSessionId, input)
    );
  }

  /** Reads durable admission before preview or dispatch; missing history cannot become default-off. */
  private requireTurnCaptureCoverage(turn: { workspaceId: string; threadId: string; id: string }) {
    const workspaceDb = this.openWorkspaceDb(turn.workspaceId);
    if (!workspaceDb)
      throw new TurnStartValidationError(
        'recovery_required',
        'Worker capture admission is not durable.',
        409
      );
    try {
      const binding = readWorkObservationTurnBinding(workspaceDb, {
        threadId: turn.threadId,
        turnId: turn.id,
      });
      if (!binding.coverage) throw new Error('Missing persisted capture coverage');
      return binding.coverage;
    } catch {
      throw new TurnStartValidationError(
        'recovery_required',
        'Worker capture admission is unavailable.',
        409
      );
    } finally {
      workspaceDb.sqlite.close();
    }
  }

  /** Resolves one complete secret-free AEP for admission without backend or Store effects. */
  private previewAgentEnvironmentPackage(
    agentSessionId: string,
    input: PrepareAgentSessionForTurnInput
  ): AgentEnvironmentPackagePreview {
    const resolvePackage = (workSlotRef: string) =>
      resolveAgentEnvironmentPackageMetadata({
        agentSessionId,
        agentSetup: input.agentSetup,
        backend: { kind: 'openshell' },
        ...(this.readRuntimeConfig ? { readRuntimeConfig: this.readRuntimeConfig } : {}),
        ...(this.coreDb ? { coreDb: this.coreDb } : {}),
        requestId: input.requestId,
        turn: input.turn,
        turnInput: input.turnInput,
        triggerActor: input.turn.triggerActor,
        workspaceCwd: input.workspaceCwd,
        workerStorageWorkSlotRef: workSlotRef,
        workspaceRoots: input.workspaceRoots,
        ...(input.workspaceDataSourceCatalog
          ? { workspaceDataSourceCatalog: input.workspaceDataSourceCatalog }
          : {}),
        ...(input.workspaceMcpServerCatalog
          ? { workspaceMcpServerCatalog: input.workspaceMcpServerCatalog }
          : {}),
        ...(input.workspaceSourceRefs ? { workspaceSourceRefs: input.workspaceSourceRefs } : {}),
      });
    const plannedWorkSlotRef = workerStorageWorkSlotRef(
      input.workerStorageChoice,
      input.turn.workspaceId,
      input.turn.threadId,
      this.coreDb,
      responsibleUserIdForActor(input.turn.triggerActor)
    );
    const planned = resolvePackage(plannedWorkSlotRef);
    if (input.workerStorageChoice) return planned;
    const residentWorkSlotRef = this.resolveResidentWorkerStorageWorkSlotRef?.(planned);
    return residentWorkSlotRef && residentWorkSlotRef !== plannedWorkSlotRef
      ? resolvePackage(residentWorkSlotRef)
      : planned;
  }

  /**
   * Polls provider refresh status for active backend sessions.
   *
   * @returns Product-safe refresh status evidence records.
   */
  public async collectProviderRefreshStatuses(): Promise<WorkerGovernanceEvidenceRecord[]> {
    return this.backend.collectProviderRefreshStatuses();
  }

  /**
   * Starts and completes one backend-governed worker turn.
   *
   * Validates the complete AEP against the backend before creating an AgentSession or attempting runtime effects; unsupported authored requirements retain their diagnostic as deterministic preparation failures.
   *
   * @param store Store that owns the workspace and thread.
   * @param turnId Turn id to execute.
   * @param input User-facing turn input.
   * @param context Runtime context with request id and workspace roots.
   * @returns Promise that resolves after transcript import and teardown.
   * @throws DeterministicAgentPreparationError when backend package validation rejects an authored requirement.
   */
  public async startTurn(
    store: FsStore,
    turnId: string,
    input: string,
    context?: TurnStartRuntimeContext
  ): Promise<void> {
    this.activeTurnExecutions.add(turnId);
    try {
      await this.executeTurn(store, turnId, input, context);
    } finally {
      this.activeTurnExecutions.delete(turnId);
    }
  }

  /** Reports whether the live lifecycle owner still owns cleanup and outcome publication. */
  public isTurnExecutionActive(turnId: string): boolean {
    return this.activeTurnExecutions.has(turnId);
  }

  /** Executes the governed lifecycle while startTurn holds process-local recovery exclusion. */
  private async executeTurn(
    store: FsStore,
    turnId: string,
    input: string,
    context?: TurnStartRuntimeContext
  ): Promise<void> {
    if (!context) {
      throw new Error('Governed worker execution requires exact turn-start runtime context.');
    }
    if (!this.coreDb || !context.attemptId)
      throw new Error('Governed execution requires its exact durable attempt.');
    const executionAttempt = requireSchedulerExecutionAttempt(this.coreDb, context.attemptId);
    if (
      executionAttempt.phase !== 'open' ||
      executionAttempt.turnId !== turnId ||
      !executionAttempt.bindingRef
    )
      throw new Error('Governed execution has no prepared attempt binding.');
    context = { ...context, sandboxBindingRef: executionAttempt.bindingRef };
    const turn = store.getTurnById(turnId);
    const requestId = context.requestId ?? null;
    let agentSessionId: string | null = context.agentSessionId ?? null;
    let workspaceDb: WorkspaceDb | null = null;
    let backendCapabilities: WorkerGovernanceBackendCapabilities | null = null;
    let backendLifecycle: WorkerTurnBackendLifecycle | null = null;
    let backendCleanupRequired = false;
    let materializationPublished = false;
    let closeoutAt: string | null = null;
    let environmentPackage: AgentEnvironmentPackage | null = null;
    let preparedWorkerContext: PreparedWorkerTurnContext | null = null;
    let workerFinalStatus: AcceptedWorkerFinalStatus | null = null;
    let submissionInvoked = false;
    let primaryFailed = false;
    let primaryError: unknown;

    try {
      if (!context.agentSetup) {
        throw new Error('Governed worker execution requires one resolved agent setup.');
      }
      if (!turn.agentId) {
        throw new Error(`Worker turn has no assigned agent: ${turn.id}`);
      }
      const manifest = context.agentSetup.manifest;
      if (turn.agentId !== manifest.id) {
        throw new Error(
          `Worker turn agent ${turn.agentId} does not match resolved agent setup ${manifest.id}.`
        );
      }
      const resolvedAgentSessionId = agentSessionId ?? this.createAgentSessionId();
      agentSessionId = resolvedAgentSessionId;
      const captureCoverage = this.requireTurnCaptureCoverage(turn);
      const launchPreparation: PrepareAgentSessionForTurnInput = {
        agentSetup: context.agentSetup,
        freshAgentSessionId: resolvedAgentSessionId,
        requestId,
        turn,
        turnInput: input,
        ...(context.workerStorageChoice
          ? { workerStorageChoice: context.workerStorageChoice }
          : {}),
        workspaceCwd: workerVisibleWorkspaceCwd(context, { kind: 'openshell' }),
        workspaceRoots: context.workspaceRoots,
        ...(context.workspaceDataSourceCatalog
          ? { workspaceDataSourceCatalog: context.workspaceDataSourceCatalog }
          : {}),
        ...(context.workspaceMcpServerCatalog
          ? { workspaceMcpServerCatalog: context.workspaceMcpServerCatalog }
          : {}),
        ...(context.workspaceSourceRefs
          ? { workspaceSourceRefs: context.workspaceSourceRefs }
          : {}),
      };
      // This inexpensive recheck is a snapshot; materialize owns the final capacity decision.
      // Publication precedes every incoming reservation or effect.
      this.requireMaterializationCapacity(resolvedAgentSessionId, launchPreparation);
      const launchEnvironmentPackage = this.previewAgentEnvironmentPackage(
        resolvedAgentSessionId,
        launchPreparation
      );
      const launchCompatibilityKey =
        agentSessionCompatibilityKeyFromPackage(launchEnvironmentPackage);
      if (
        context.sessionCompatibilityKey &&
        context.sessionCompatibilityKey !== launchCompatibilityKey
      ) {
        throw new TurnStartValidationError(
          'recovery_required',
          'The execution attempt SessionCompatibilityKey does not match launch metadata.',
          409
        );
      }
      workspaceDb = this.openWorkspaceDb(turn.workspaceId);
      if (workspaceDb) {
        applyScopedMigrations(workspaceDb);
      }
      const checkpoint = workspaceDb
        ? getWorkerCheckpoint(workspaceDb, turn.workspaceId, turn.threadId, turn.id)
        : null;
      const workerInput = workspaceDb
        ? frozenPendingOutcomeInput(workspaceDb.sqlite, turn.id, input)
        : input;
      // Delivery cause owns initiating-request identity; carried outcomes do not replace it.
      const outcomeInitiated = workspaceDb
        ? listThreadPendingRequests(workspaceDb.sqlite, turn.workspaceId, turn.threadId).some(
            (record) => record.deliveryTurnId === turn.id && record.deliveryCause === 'outcome'
          )
        : false;
      const contextRequest = outcomeInitiated ? workerInput : input;
      if (checkpoint && !context.sandboxBindingRef) {
        throw new TurnStartValidationError(
          'recovery_required',
          'Worker Context Package scheduler binding is unavailable.',
          409
        );
      }
      if (workspaceDb && (checkpoint || outcomeInitiated) && context.sandboxBindingRef) {
        preparedWorkerContext = prepareWorkerTurnContextPackage(
          this.coreDb,
          workspaceDb,
          store,
          checkpoint,
          {
            agentSessionId: resolvedAgentSessionId,
            requestId,
            threadId: turn.threadId,
            turnId: turn.id,
            workerRequest: contextRequest,
            workspaceId: turn.workspaceId,
          }
        );
      }
      if (preparedWorkerContext && !turn.startedAt) {
        throw new TurnStartValidationError(
          'recovery_required',
          'Worker Context Package requires one accepted Turn timestamp.',
          409
        );
      }
      const timestamp = preparedWorkerContext ? turn.startedAt! : this.now();
      const providerCredentials: ResolvedAgentEnvironmentProviderCredential[] = [];
      const runtimeEnvCredentials: ResolvedAgentEnvironmentRuntimeEnvCredential[] = [];
      const runtimeFileCredentials: ResolvedAgentEnvironmentRuntimeFileCredential[] = [];
      const credentialReceipts: CreateVaultInjectionReceiptInput[] = [];
      const resolvedEnvironmentPackage = resolveAgentEnvironmentPackage({
        captureCoverage,
        ...(this.readRuntimeConfig ? { readRuntimeConfig: this.readRuntimeConfig } : {}),
        agentSetup: context.agentSetup,
        agentSessionId: resolvedAgentSessionId,
        backend: { kind: 'openshell' },
        ...(preparedWorkerContext
          ? {
              createdAt: timestamp,
              preparedContextPackage: preparedWorkerContext.preparedContextPackage,
            }
          : {}),
        ...(this.coreDb ? { coreDb: this.coreDb } : {}),
        now: this.now,
        providerCredentialSink: (credential) => providerCredentials.push(credential),
        credentialReceiptSink: (receipt) => credentialReceipts.push(receipt),
        requestId,
        runtimeEnvCredentialSink: (credential) => runtimeEnvCredentials.push(credential),
        runtimeFileCredentialSink: (credential) => runtimeFileCredentials.push(credential),
        turn,
        turnInput: workerInput,
        triggerActor: context.triggerActor,
        ...(this.vaultBackend ? { vaultBackend: this.vaultBackend } : {}),
        ...(context.workspaceDataSourceCatalog
          ? { workspaceDataSourceCatalog: context.workspaceDataSourceCatalog }
          : {}),
        ...(context.workspaceMcpServerCatalog
          ? { workspaceMcpServerCatalog: context.workspaceMcpServerCatalog }
          : {}),
        workspaceCwd: workerVisibleWorkspaceCwd(context, { kind: 'openshell' }),
        workerStorageWorkSlotRef: requirePackageWorkerStorageWorkSlotRef(launchEnvironmentPackage),
        workspaceRoots: context.workspaceRoots,
        ...(context.workspaceSourceRefs
          ? { workspaceSourceRefs: context.workspaceSourceRefs }
          : {}),
      });
      environmentPackage = preparedWorkerContext
        ? {
            ...resolvedEnvironmentPackage,
            scope: {
              ...resolvedEnvironmentPackage.scope,
              itemId: deriveEntityId('it', ['task-user', turnId]),
            },
          }
        : resolvedEnvironmentPackage;
      // Validate the complete package before publishing a session or attempting runtime effects.
      const packageDiagnostics = await this.backend.validatePackage(environmentPackage);
      if (packageDiagnostics.length > 0) {
        agentSessionId = null;
        throw new DeterministicAgentPreparationError(
          packageDiagnostics.map((diagnostic) => diagnostic.message).join(' ')
        );
      }
      const workerLineage = {
        workspaceId: environmentPackage.scope.workspaceId,
        threadId: environmentPackage.scope.threadId,
        turnId: environmentPackage.scope.turnId,
        agentSessionId: environmentPackage.scope.agentSessionId,
        packageSnapshotId: environmentPackage.snapshotId,
        triggerActor: environmentPackage.scope.triggerActor,
      };
      const sessionWorkspace = (
        environmentPackage.extensions.openkit as {
          sessionWorkspace: SessionWorkspaceMaterializationPlan;
        }
      ).sessionWorkspace;
      if (
        context.sessionCompatibilityKey &&
        sessionWorkspace.compatibilityKey.digest !== launchCompatibilityKey
      ) {
        throw new TurnStartValidationError(
          'recovery_required',
          'The final Agent Environment Package changed the prepared compatibility key.',
          409
        );
      }
      const threadAgentSessions = store.listThreadAgentSessions(turn.workspaceId, turn.threadId);
      let existingAgentSession: ReturnType<FsStore['getAgentSession']> | undefined;
      try {
        existingAgentSession = store.getAgentSession(resolvedAgentSessionId);
      } catch {
        existingAgentSession = undefined;
      }
      const conflictingCurrentAgentSession = threadAgentSessions.find(
        (candidate) =>
          candidate.id !== resolvedAgentSessionId &&
          !['interrupted', 'failed', 'closed'].includes(candidate.status)
      );
      if (conflictingCurrentAgentSession) {
        agentSessionId = null;
        throw new TurnStartValidationError(
          'recovery_required',
          'The Thread already has another current AgentSession.',
          409
        );
      }
      if (
        existingAgentSession &&
        (existingAgentSession.workspaceId !== turn.workspaceId ||
          existingAgentSession.threadId !== turn.threadId ||
          existingAgentSession.agentId !== manifest.id ||
          existingAgentSession.status !== 'idle' ||
          existingAgentSession.stale ||
          existingAgentSession.sessionCompatibilityKey !==
            sessionWorkspace.compatibilityKey.digest ||
          existingAgentSession.policySnapshotId !== WORKER_TURN_LAUNCH_POLICY_SNAPSHOT_ID)
      ) {
        agentSessionId = null;
        throw new TurnStartValidationError(
          'recovery_required',
          'The selected AgentSession is not reusable for this Turn.',
          409
        );
      }
      if (
        existingAgentSession &&
        !AgentSessionRetainedStorageSchema.safeParse(existingAgentSession.retainedStorage).success
      ) {
        agentSessionId = null;
        throw new TurnStartValidationError(
          'recovery_required',
          'The selected native AgentSession has no proven retained-storage attachment.',
          409
        );
      }
      let nativeResume: WorkerGovernanceNativeResume | null;
      try {
        const source = selectThreadNativeResumeSource(threadAgentSessions, resolvedAgentSessionId);
        nativeResume = source ? { digest: source.nativeHandleDigest!, locator: source.id } : null;
      } catch (error) {
        agentSessionId = null;
        throw error;
      }
      backendCapabilities = await this.backend.describeCapabilities();
      const backendKind = toWorkspaceSynchronizationBackendKind(backendCapabilities.kind);
      let inputSnapshots = workspaceDb
        ? buildWorkspaceInputSnapshots({
            backendCapabilities: backendCapabilities.capabilities,
            backendKind,
            createdAt: preparedWorkerContext ? timestamp : this.now(),
            environmentPackage,
          })
        : [];
      backendLifecycle = {
        identity: this.backend.planSession(environmentPackage),
        physicalCleanedAt: null,
        session: null,
        workspaceHandoffState: 'pending',
      };
      if (
        this.coreDb &&
        !currentWorkerLineageWorkspaceAuthority(this.coreDb, workerLineage, 'runtime.launch', true)
      ) {
        throw new TurnStartValidationError(
          'workspace_access_denied',
          'Workspace access denied.',
          403
        );
      }
      const launchPackage = environmentPackage;
      const launchContext = context;
      const launchCapabilities = backendCapabilities;
      const launchLifecycle = backendLifecycle;
      /** Publishes the execution binding only after the backend's final no-effect capacity guards. */
      const publishMaterialization = () => {
        if (materializationPublished)
          throw new Error('Worker materialization publication may occur only once.');
        materializationPublished = true;
        if (workspaceDb)
          bindWorkerCheckpointToPreparedSession({
            coreDb: this.coreDb!,
            workspaceDb,
            store,
            workspaceId: turn.workspaceId,
            threadId: turn.threadId,
            turnId: turn.id,
            requestId,
            agentSessionId: resolvedAgentSessionId,
            attemptId: launchContext.attemptId!,
          });
        const agentSession = existingAgentSession
          ? store.updateAgentSession(existingAgentSession.id, {
              configVersion: turn.configVersion,
              environmentPackageSnapshotId: launchPackage.snapshotId,
              message: null,
              status: 'initializing',
              updatedAt: timestamp,
            })
          : store.createAgentSession({
              agentId: manifest.id,
              configVersion: turn.configVersion,
              createdAt: timestamp,
              environmentPackageSnapshotId: launchPackage.snapshotId,
              id: resolvedAgentSessionId,
              message: null,
              policySnapshotId: WORKER_TURN_LAUNCH_POLICY_SNAPSHOT_ID,
              sessionCompatibilityKey: sessionWorkspace.compatibilityKey.digest,
              status: 'created',
              threadId: turn.threadId,
              updatedAt: timestamp,
              workspaceId: turn.workspaceId,
              workspaceRoots: launchContext.workspaceRoots,
            });
        store.updateTurn(turnId, {
          agentProfileId: launchPackage.agent.profileId,
          agentSessionId: agentSession.id,
        });
        const userItem = store.createItem({
          actor: outcomeInitiated
            ? pendingRequestSystemActor(responsibleUserIdForActor(launchContext.triggerActor))
            : launchContext.triggerActor,
          completedAt: timestamp,
          createdAt: timestamp,
          id: deriveEntityId('it', ['task-user', turnId]),
          status: 'completed',
          text: contextRequest,
          threadId: turn.threadId,
          turnId,
          type: 'user-message',
          workspaceId: turn.workspaceId,
        });

        this.emitTurnStarted(store, launchPackage, requestId);
        this.emitItemCreatedAndCompleted(store, launchPackage, requestId, userItem);
        this.emitAgentSession(store, launchPackage, requestId, agentSession);

        if (workspaceDb) {
          recordAgentEnvironmentPackageSnapshot(workspaceDb, {
            createdAt: preparedWorkerContext ? timestamp : this.now(),
            environmentPackage: launchPackage,
          });
        }

        if (this.coreDb && launchContext.sandboxBindingRef) {
          launchLifecycle.session = recordWorkerBackendSessionMaterializing(this.coreDb, {
            backendLineage: workerBackendLineageFromRuntimeImage(launchPackage.runtime.image),
            backendVersion: launchCapabilities.version ?? null,
            identity: launchLifecycle.identity,
            lineage: {
              threadId: launchPackage.scope.threadId,
              turnId: launchPackage.scope.turnId,
              workspaceId: launchPackage.scope.workspaceId,
            },
            now: this.now,
            sandboxBindingRef: launchContext.sandboxBindingRef,
          });
        }
        backendCleanupRequired = true;
      };
      const materialization = await this.backend.materialize(environmentPackage, {
        beforeMaterialization: publishMaterialization,
        ...(this.coreDb?.dataRoot ? { dataRoot: this.coreDb.dataRoot } : {}),
        providerCredentials,
        runtimeEnvCredentials,
        runtimeFileCredentials,
        ...(context.sandboxBindingRef ? { sandboxBindingRef: context.sandboxBindingRef } : {}),
        ...(context.workerStorageChoice
          ? { workerStorageChoice: context.workerStorageChoice }
          : {}),
        nativeResume,
        workspaceRoots: preparedWorkerContext
          ? [...context.workspaceRoots, preparedWorkerContext.preparedContextPackage.workspaceRoot]
          : context.workspaceRoots,
      });
      if (!materializationPublished)
        throw new Error('Backend materialization omitted its pre-effect publication boundary.');
      if (materialization.retainedStorage) {
        const sourceStorage = nativeResume
          ? store.getAgentSession(nativeResume.locator).retainedStorage
          : null;
        if (sourceStorage && !isDeepStrictEqual(sourceStorage, materialization.retainedStorage)) {
          throw new TurnStartValidationError(
            'recovery_required',
            'The admitted storage differs from the native resume attachment.',
            409
          );
        }
        store.updateAgentSession(agentSessionId, {
          retainedStorage: materialization.retainedStorage,
          updatedAt: this.now(),
        });
      }
      this.bindNativeHandleRecorder(store, environmentPackage);
      if (backendLifecycle.session) {
        backendLifecycle.session = transitionWorkerBackendSessionState(this.coreDb!, {
          fromState: 'materializing',
          attemptId: backendLifecycle.session.attemptId,
          now: this.now,
          toState: 'materialized',
        });
      }

      if (materialization.workspaceBaseCommits) {
        inputSnapshots = inputSnapshots.map((snapshot) => {
          const commit = materialization.workspaceBaseCommits?.[snapshot.resourceId];
          return commit ? { ...snapshot, base: { ...snapshot.base, commit } } : snapshot;
        });
      }
      const builtMaterializationRecords = workspaceDb
        ? buildWorkspaceMaterializationRecords({
            createdAt: preparedWorkerContext ? timestamp : this.now(),
            inputSnapshots,
            materialization: { ...materialization, backendKind },
          })
        : [];
      const handoff = workspaceDb
        ? recordWorkspaceBackendHandoff(workspaceDb, inputSnapshots, builtMaterializationRecords)
        : { inputSnapshots, materializationRecords: builtMaterializationRecords };
      const materializationRecords = handoff.materializationRecords;
      backendLifecycle.workspaceHandoffState = workspaceDb ? 'complete' : 'pending';
      if (backendLifecycle.session) {
        backendLifecycle.session = markWorkerBackendWorkspaceHandoffComplete(this.coreDb!, {
          attemptId: backendLifecycle.session.attemptId,
          now: this.now,
        });
        backendLifecycle.workspaceHandoffState = backendLifecycle.session.workspaceHandoffState;
      }

      if (preparedWorkerContext) {
        if (!this.coreDb || !workspaceDb || !backendLifecycle.session) {
          throw new TurnStartValidationError(
            'recovery_required',
            'Worker Context Package authority is unavailable after backend handoff.',
            409
          );
        }
        acceptPreparedWorkerTurnContextPackage({
          coreDb: this.coreDb,
          environmentPackage,
          preparedContext: preparedWorkerContext,
          store,
          workspaceDb,
        });
      }

      const busySession = store.updateAgentSession(resolvedAgentSessionId, {
        message: null,
        status: 'busy',
        updatedAt: this.now(),
      });
      this.emitAgentSession(store, environmentPackage, requestId, busySession);

      const completionLeaseId = this.awaitWorkerCompletion
        ? backendLifecycle.session?.attemptId
        : null;
      if (this.awaitWorkerCompletion && !completionLeaseId) {
        throw new Error('Detached worker completion requires a durable execution attempt.');
      }
      if (
        this.coreDb &&
        !currentWorkerLineageWorkspaceAuthority(this.coreDb, workerLineage, 'runtime.launch', true)
      ) {
        throw new TurnStartValidationError(
          'workspace_access_denied',
          'Workspace access denied.',
          403
        );
      }
      await this.backend.prepareLaunch(materialization);
      const submission = recordSchedulerExecutionOperation(this.coreDb!, {
        attemptId: context.attemptId!,
        operationId: commandInputHash({
          attemptId: context.attemptId,
          inputRef: environmentPackage.snapshotId,
          operation: 'submit',
        }),
        submission: true,
        now: this.now,
      });
      if (backendLifecycle.session)
        backendLifecycle.session = markWorkerBackendSessionLaunching(this.coreDb!, {
          attemptId: backendLifecycle.session.attemptId,
          now: this.now,
        });
      let observation: Awaited<
        ReturnType<import('./execution-backend.js').ExecutionBackend['submit']>
      >;
      try {
        submissionInvoked = true;
        observation = await this.executionBackend.submit({
          ...schedulerExecutionCorrelation(submission),
          deadline: submission.deadline!,
        });
      } finally {
        // The durable attempt holds only its own exclusion after a definite or unknown submission.
        context.onSubmissionSettled?.();
      }
      const accepted = acceptSchedulerExecutionObservation(this.coreDb!, observation);
      if (!accepted || observation.disposition !== 'accepted')
        throw new Error(
          'Native submission is unresolved; inspect its original operation without replay.'
        );
      if (workspaceDb) proveFrozenDelivery(workspaceDb.sqlite, turn.id, this.now());
      // Credential material is delivered once at `session.open`; a reused binding receives none.
      if (!existingAgentSession) {
        for (const receipt of credentialReceipts) {
          createVaultInjectionReceipt(this.coreDb!, { ...receipt, injectedAt: this.now() });
        }
      }

      if (this.awaitWorkerCompletion && completionLeaseId) {
        workerFinalStatus = await this.awaitWorkerCompletion(environmentPackage, completionLeaseId);
        closeoutAt = workerFinalStatus.acceptedAt;
      }
      closeoutAt ??= this.now();
      await this.finishLaunchedTurn(
        store,
        environmentPackage,
        requestId,
        backendCapabilities,
        backendLifecycle,
        workspaceDb,
        inputSnapshots,
        materializationRecords,
        closeoutAt
      );
      backendCleanupRequired = false;
    } catch (error) {
      primaryFailed = true;
      primaryError = asWorkerArtifactTurnError(error);
    }

    context.onSubmissionSettled?.();
    if (
      primaryError instanceof WorkerGovernanceCapacityUnavailableError &&
      !materializationPublished &&
      requireSchedulerExecutionAttempt(this.coreDb!, context.attemptId!).operationId === null
    ) {
      store.updateTurn(turnId, { status: 'pending' });
      workspaceDb?.sqlite.close();
      throw primaryError;
    }
    const errors: unknown[] = primaryFailed ? [primaryError] : [];
    const failedAttempt = requireSchedulerExecutionAttempt(this.coreDb!, context.attemptId!);
    if (primaryFailed && failedAttempt.operationId === null)
      closeSchedulerExecutionAttemptWithoutEffects(this.coreDb!, {
        attemptId: failedAttempt.attemptId,
        noOutstandingEffects: true,
        cause: 'turn-start-failed',
        now: this.now,
      });
    else if (primaryFailed)
      markSchedulerExecutionAttemptClosing(this.coreDb!, {
        attemptId: failedAttempt.attemptId,
        cause: 'execution-failed',
        now: this.now,
      });
    if (backendCleanupRequired) {
      if (!backendLifecycle || !environmentPackage || !backendCapabilities) {
        errors.push(new Error('Backend cleanup is missing its durable runtime lineage.'));
      } else {
        try {
          await this.cleanupBackendLifecycle(
            backendLifecycle,
            workspaceDb,
            environmentPackage,
            backendCapabilities,
            true
          );
          backendCleanupRequired = false;
        } catch (error) {
          errors.push(error);
        }
      }
    }
    try {
      workspaceDb?.sqlite.close();
    } catch (error) {
      errors.push(error);
    }

    let terminalObserved = false;
    if (errors.length === 0) {
      if (!agentSessionId) {
        errors.push(new Error('The governed worker turn is missing its AgentSession id.'));
      } else {
        try {
          if (workerFinalStatus) {
            this.recordAcceptedWorkerOutcome(
              store,
              turn,
              agentSessionId,
              requestId,
              workerFinalStatus,
              environmentPackage?.snapshotId ?? null
            );
          } else {
            this.completeTurn(store, turn, agentSessionId, requestId);
          }
        } catch (error) {
          errors.push(error);
          terminalObserved = store
            .getTurnEvents(turn.id)
            .some(
              (event) => event.event === 'turn.completed' && event.data.type === 'turn-completed'
            );
          if (terminalObserved) {
            try {
              store.updateTurn(turn.id, {});
            } catch (persistError) {
              errors.push(persistError);
            }
          }
        }
      }
    }

    if (errors.length === 0 && backendLifecycle?.session?.state === 'cleaned')
      await this.releaseTerminalAttempt(store, context.attemptId!, environmentPackage!);
    if (errors.length > 0) {
      // Later passive cleanup preserves this diagnostic as the first cleanup attempt's history.
      const error =
        errors.length === 1
          ? errors[0]
          : new AggregateError(
              errors,
              `Worker execution failed and the first backend cleanup attempt failed${
                primaryError instanceof Error ? `: ${primaryError.message}` : '.'
              }`
            );
      if (!terminalObserved) {
        try {
          if (
            primaryError instanceof TurnStartValidationError &&
            primaryError.code === 'workspace_access_denied'
          ) {
            terminalizeGovernedWorkerTurn({
              agentSessionId,
              completedAt: this.now(),
              errorCode: primaryError.code,
              message: primaryError.message,
              outcome: 'interrupted',
              requestId,
              store,
              turnId: turn.id,
            });
          } else {
            this.failTurn(store, turn, agentSessionId, requestId, error, primaryError);
          }
        } catch (failureError) {
          throw new AggregateError(
            [error, failureError],
            'Worker execution failed and the failed turn could not be persisted.'
          );
        }
      }
      // Cleanup after a possibly accepted submit cannot prove unread output or evidence.
      if (
        primaryFailed &&
        errors.length === 1 &&
        (!submissionInvoked || failedAttempt.disposition === 'not_accepted') &&
        !backendCleanupRequired &&
        backendLifecycle?.session?.state === 'cleaned' &&
        backendLifecycle.session.workspaceHandoffState === 'complete'
      ) {
        try {
          await this.releaseTerminalAttempt(store, context.attemptId!, environmentPackage!);
        } catch (releaseError) {
          throw new AggregateError(
            [error, releaseError],
            'Worker execution failed and attempt release failed.'
          );
        }
      }
      throw error;
    }
  }

  /**
   * Resumes the existing post-launch closeout path for one durable accepted final status.
   *
   * @param store Product store that owns the turn.
   * @param environmentPackage Immutable package restored from the workspace ledger.
   * @param session Exact durable backend session restored by the lifecycle runtime.
   * @returns Product terminal status established by closeout.
   */
  public async resumeAcceptedFinalStatus(
    store: FsStore,
    environmentPackage: AgentEnvironmentPackage,
    session: WorkerBackendSessionRecord
  ): Promise<'cancelled' | 'completed' | 'failed' | 'interrupted'> {
    const turnId = environmentPackage.scope.turnId;
    this.activeTurnExecutions.add(turnId);
    try {
      return await this.closeAcceptedFinalStatus(store, environmentPackage, session);
    } finally {
      this.activeTurnExecutions.delete(turnId);
    }
  }

  /** Finishes restored closeout under the same process-local exclusion as ordinary execution. */
  private async closeAcceptedFinalStatus(
    store: FsStore,
    environmentPackage: AgentEnvironmentPackage,
    session: WorkerBackendSessionRecord
  ): Promise<'cancelled' | 'completed' | 'failed' | 'interrupted'> {
    if (!this.coreDb) {
      throw new Error('Restart closeout requires the durable Core database.');
    }
    assertRestoredSession(
      environmentPackage,
      session,
      this.backend.planSession(environmentPackage)
    );
    if (session.state !== 'cleaned') this.bindNativeHandleRecorder(store, environmentPackage);
    const turn = store.getTurnById(environmentPackage.scope.turnId);
    const accepted = getWorkerControlAcceptedFinalStatus(this.coreDb, {
      agentSessionId: environmentPackage.scope.agentSessionId,
      packageSnapshotId: environmentPackage.snapshotId,
      requestId: environmentPackage.scope.requestId,
      threadId: environmentPackage.scope.threadId,
      turnId: environmentPackage.scope.turnId,
      workspaceId: environmentPackage.scope.workspaceId,
    });
    if (!accepted) {
      throw new Error('Restart closeout requires the exact durable final status.');
    }
    const stopReason = canonicalStopReasonForAcceptedWorkerFinalStatus(
      accepted,
      requireSchedulerExecutionAttempt(this.coreDb, session.attemptId).terminalCause
    );
    const recoveredStatus = turnStatusForCanonicalWorkerStopReason(stopReason);
    const workspaceDb = this.openWorkspaceDb(environmentPackage.scope.workspaceId);
    if (!workspaceDb) {
      throw new Error('Restart closeout requires durable workspace storage.');
    }
    applyScopedMigrations(workspaceDb);

    try {
      const backendCapabilities = await this.backend.describeCapabilities();
      const lifecycle: WorkerTurnBackendLifecycle = {
        identity: this.backend.planSession(environmentPackage),
        physicalCleanedAt: session.physicalCleanedAt,
        session,
        workspaceHandoffState: session.workspaceHandoffState,
      };
      const collectDurableOutput =
        session.state !== 'physical-cleaned' && session.state !== 'cleaned';
      const restartFailure = {
        agentSessionId: environmentPackage.scope.agentSessionId,
        completedAt: this.now(),
        errorCode: 'worker_governance_restart_recovery',
        message: 'Worker output could not be verified during restart closeout.',
        outcome: 'interrupted' as const,
        requestId: environmentPackage.scope.requestId ?? null,
        store,
        turnId: environmentPackage.scope.turnId,
      };
      const currentTurn = store.getTurnById(environmentPackage.scope.turnId);
      if (
        currentTurn.status === 'interrupted' &&
        currentTurn.error?.code === restartFailure.errorCode
      ) {
        terminalizeGovernedWorkerTurn(restartFailure);
        if (session.state !== 'cleaned') {
          await this.cleanupBackendLifecycle(
            lifecycle,
            workspaceDb,
            environmentPackage,
            backendCapabilities,
            true
          );
        }
        return 'interrupted';
      }
      if (collectDurableOutput) {
        try {
          await this.finishLaunchedTurn(
            store,
            environmentPackage,
            environmentPackage.scope.requestId ?? null,
            backendCapabilities,
            lifecycle,
            workspaceDb,
            listWorkspaceInputSnapshots(workspaceDb, environmentPackage.scope.workspaceId),
            listWorkspaceMaterializationRecords(workspaceDb, environmentPackage.scope.workspaceId),
            accepted.acceptedAt
          );
        } catch (error) {
          try {
            terminalizeGovernedWorkerTurn(restartFailure);
          } catch (terminalError) {
            throw new AggregateError(
              [error, terminalError],
              'Restored worker closeout failed and its stable product outcome could not be persisted.'
            );
          }
          try {
            await this.cleanupBackendLifecycle(
              lifecycle,
              workspaceDb,
              environmentPackage,
              backendCapabilities,
              true
            );
          } catch (cleanupError) {
            throw new AggregateError(
              [error, cleanupError],
              'Restored worker closeout failed after its stable product outcome was persisted.'
            );
          }
          return 'interrupted';
        }
      } else if (session.state !== 'cleaned') {
        await this.cleanupBackendLifecycle(
          lifecycle,
          workspaceDb,
          environmentPackage,
          backendCapabilities
        );
      }

      if (turn.status === recoveredStatus) {
        await this.releaseTerminalAttempt(store, session.attemptId, environmentPackage);
        return recoveredStatus;
      }

      this.recordAcceptedWorkerOutcome(
        store,
        turn,
        environmentPackage.scope.agentSessionId,
        environmentPackage.scope.requestId ?? null,
        accepted,
        environmentPackage.snapshotId
      );
      await this.releaseTerminalAttempt(store, session.attemptId, environmentPackage);
      return recoveredStatus;
    } finally {
      workspaceDb.sqlite.close();
    }
  }

  /** Releases only after this owner's full output, evidence, collection, drain and terminal path succeeds. */
  private async releaseTerminalAttempt(
    store: FsStore,
    attemptId: string,
    environmentPackage: AgentEnvironmentPackage
  ): Promise<void> {
    if (!this.coreDb) throw new Error('Attempt release requires Core authority.');
    let attempt = requireSchedulerExecutionAttempt(this.coreDb, attemptId);
    if (attempt.phase === 'closed') return;
    const turn = store.getTurnById(attempt.turnId);
    if (!isSealedTurnTerminal(turn.status))
      throw new Error('Attempt terminal handoff is incomplete.');
    // The Task envelope observes this owner's full worker closeout before finishing its own
    // checkpoint. That later mode projection cannot be a prerequisite for this same release.
    attempt = markSchedulerExecutionAttemptClosing(this.coreDb, {
      attemptId,
      cause: `turn-${turn.status}`,
      outcomeRef: `turn:${turn.id}:${turn.status}`,
      now: this.now,
    });
    const proof = {
      terminalHandoff: true,
      output: true,
      evidence: true,
      outsideWorkspaceCollection: true,
      integrationDrain: true,
      routesRevoked: true,
    } as const;
    const correlation = schedulerExecutionCorrelation(attempt);
    for (let pass = 0; pass < 2; pass += 1) {
      const result = await this.executionBackend.release({ ...correlation, proof });
      if (
        result.attemptId !== correlation.attemptId ||
        result.backendId !== correlation.backendId ||
        result.bindingRef !== correlation.bindingRef ||
        result.inputRef !== correlation.inputRef ||
        result.operationId !== correlation.operationId
      )
        throw new Error('Release response contradicts the exact original operation.');
      if (result.state === 'released' && result.fenceRef) {
        closeSchedulerExecutionAttemptWithFence(this.coreDb, {
          correlation,
          proof,
          fenceRef: result.fenceRef,
          now: this.now,
        });
        return;
      }
      if (pass !== 0 || result.state !== 'unknown') break;
      // The cleaned Turn anchor does not prove wider resident cleanup.
      // Continue that existing owner without restoring the obsolete binding or replaying an uncertain effect.
      await this.backend.cleanupSession(this.backend.planSession(environmentPackage));
    }
    throw new Error('Attempt release remains incomplete.');
  }

  /**
   * Interrupts the exact live worker attempt through the backend's private Harness channel
   * without terminalizing it; the Turn settles through its normal closeout.
   *
   * @param store Store that owns the turn and AgentSession.
   * @param turnId Turn id to interrupt.
   * @param _context Runtime command context.
   * @returns Promise resolved after the backend accepted the interrupt.
   * @throws Error when the backend cannot interrupt or no exact live lineage exists.
   */
  public async interruptTurn(
    store: FsStore,
    turnId: string,
    context: TurnCommandRuntimeContext = { requestId: null }
  ): Promise<void> {
    const gateway = this.workerControlGateway;
    if (!gateway || !this.backend.interruptTurn) {
      throw new Error('The worker governance executor does not support turn interruption.');
    }

    const turn = store.getTurnById(turnId);
    if (!turn.agentSessionId || isSealedTurnTerminal(turn.status)) {
      throw new Error(`Turn has no live worker attempt: ${turnId}`);
    }

    const agentSession = store.getAgentSession(turn.agentSessionId);
    const snapshot = agentSession.environmentPackageSnapshotId
      ? gateway.getSessionSnapshot(agentSession.environmentPackageSnapshotId)
      : null;
    if (
      agentSession.stale ||
      agentSession.status !== 'busy' ||
      agentSession.workspaceId !== turn.workspaceId ||
      agentSession.threadId !== turn.threadId ||
      !snapshot ||
      snapshot.workspaceId !== turn.workspaceId ||
      snapshot.threadId !== turn.threadId ||
      snapshot.turnId !== turn.id ||
      snapshot.agentSessionId !== turn.agentSessionId
    ) {
      throw new Error(`Turn worker lineage is not live and exact: ${turnId}`);
    }

    const attempts = listSchedulerExecutionAttemptsForTurn(this.coreDb!, {
      workspaceId: turn.workspaceId,
      threadId: turn.threadId,
      turnId,
    });
    const attempt = attempts.find((candidate) => candidate.phase !== 'closed');
    if (
      context.stopReason &&
      attempt?.phase === 'closing' &&
      ['turn-cancelled', 'raw-output-exhausted', 'raw-output-unavailable'].includes(
        attempt.terminalCause ?? ''
      )
    )
      return;
    if (!attempt || attempt.phase !== 'open')
      throw new Error('Turn cancellation is already owned or has no live attempt.');
    const closing = markSchedulerExecutionAttemptClosing(this.coreDb!, {
      attemptId: attempt.attemptId,
      cause:
        context.stopReason === 'budget_exhausted'
          ? 'raw-output-exhausted'
          : context.stopReason === 'error'
            ? 'raw-output-unavailable'
            : 'turn-cancelled',
      now: this.now,
    });
    acceptSchedulerExecutionObservation(
      this.coreDb!,
      await this.executionBackend.cancel(schedulerExecutionCorrelation(closing))
    );
  }

  /**
   * Returns the latest persisted AgentSession for one thread.
   *
   * @param store Store that owns the thread.
   * @param workspaceId Workspace id.
   * @param threadId Thread id.
   * @returns AgentSession read model, or null.
   */
  public getAgentSession(
    store: FsStore,
    workspaceId: string,
    threadId: string
  ): AgentSessionReadModel | null {
    const session = store
      .listThreadAgentSessions(workspaceId, threadId)
      .sort((left, right) => right.updatedAt.localeCompare(left.updatedAt))[0];

    if (!session) {
      return null;
    }

    return {
      backend: null,
      configVersion: session.configVersion,
      id: session.id,
      message: session.message,
      sandboxSummary: session.sandboxSummary ?? null,
      stale: session.stale,
      status: session.status,
      workspaceRoots: session.workspaceRoots,
    };
  }

  /** Runs the single transcript, workspace, artifact, and backend closeout path. */
  private async finishLaunchedTurn(
    store: FsStore,
    environmentPackage: AgentEnvironmentPackage,
    requestId: string | null,
    backendCapabilities: WorkerGovernanceBackendCapabilities,
    backendLifecycle: WorkerTurnBackendLifecycle,
    workspaceDb: WorkspaceDb | null,
    inputSnapshots: readonly WorkspaceInputSnapshot[],
    materializationRecords: readonly WorkspaceMaterializationRecord[],
    recordedAt: string
  ): Promise<void> {
    await this.backend.collectEvidence(environmentPackage.snapshotId);
    const transcript = await this.backend.collectTranscript(environmentPackage.snapshotId, true);
    const workerLineage = {
      workspaceId: environmentPackage.scope.workspaceId,
      threadId: environmentPackage.scope.threadId,
      turnId: environmentPackage.scope.turnId,
      agentSessionId: environmentPackage.scope.agentSessionId,
      packageSnapshotId: environmentPackage.snapshotId,
      triggerActor: environmentPackage.scope.triggerActor,
    };
    const releaseMutation = this.workspaceMutationAdmission?.enterLatePublisher(
      environmentPackage.scope.workspaceId,
      'worker-turn-closeout'
    );
    if (this.workspaceMutationAdmission && !releaseMutation) {
      throw new TurnStartValidationError(
        'workspace_access_denied',
        'Workspace access denied.',
        403
      );
    }
    try {
      if (environmentPackage.control.transcript?.runtimeProvenance) {
        if (
          this.coreDb &&
          !currentWorkerLineageWorkspaceAuthority(
            this.coreDb,
            workerLineage,
            'artifact.write',
            true
          )
        ) {
          throw new TurnStartValidationError(
            'workspace_access_denied',
            'Workspace access denied.',
            403
          );
        }
        if (!workspaceDb) {
          throw new Error('Runtime provenance collection requires durable workspace storage.');
        }
        const collection = transcript.runtimeProvenance;
        const provenance = await this.runtimeProvenanceImporter({
          backend: {
            kind: backendCapabilities.kind,
            placement: 'local',
            version: backendCapabilities.version ?? null,
          },
          capture: {
            nativeOriginIndexPath: collection?.nativeOriginIndexPath ?? null,
            rawStreamPaths: collection?.rawStreamPaths ?? {},
            streamManifestPath: collection?.manifestPath ?? null,
          },
          collectedAt: this.now(),
          environmentPackage,
          workspaceDb,
          workspaceRoot: join(workspaceDb.dataRoot, 'workspaces', workspaceDb.workspaceId),
        });
        if (!provenance.complete) {
          throw new Error('Required worker runtime provenance verification failed.');
        }
      }
      const acceptedLiveEvents = this.coreDb
        ? listWorkerControlAcceptedEvents(this.coreDb, {
            agentSessionId: environmentPackage.scope.agentSessionId,
            packageSnapshotId: environmentPackage.snapshotId,
            requestId: environmentPackage.scope.requestId,
            threadId: environmentPackage.scope.threadId,
            turnId: environmentPackage.scope.turnId,
            workspaceId: environmentPackage.scope.workspaceId,
          })
        : [];
      const workspaceChanges = await this.backend.collectWorkspaceChanges(
        environmentPackage.snapshotId,
        true
      );
      const publishesWorkspaceContent = Boolean(transcript.itemsJsonl?.trim());
      const publishesArtifacts = Boolean(workspaceChanges.length);
      if (
        this.coreDb &&
        ((publishesWorkspaceContent &&
          !currentWorkerLineageWorkspaceAuthority(
            this.coreDb,
            workerLineage,
            'workspace.write',
            true
          )) ||
          (publishesArtifacts &&
            !currentWorkerLineageWorkspaceAuthority(
              this.coreDb,
              workerLineage,
              'artifact.write',
              true
            )))
      ) {
        throw new TurnStartValidationError(
          'workspace_access_denied',
          'Workspace access denied.',
          403
        );
      }
      const importResult = importWorkerTranscript(store, environmentPackage, transcript, {
        acceptedLiveEvents,
        recordedAt,
      });
      if (
        importResult.rejectedEventSequences.length > 0 ||
        importResult.diagnostics.some((diagnostic) => diagnostic.path.startsWith('$.events'))
      ) {
        // Diagnostics supply owned codes only; parser messages and transcript payloads stay private.
        const codes = [
          ...new Set(
            importResult.diagnostics
              .filter((diagnostic) => diagnostic.path.startsWith('$.events'))
              .map((diagnostic) => diagnostic.code)
          ),
        ].slice(0, 8);
        const sequences = [...new Set(importResult.rejectedEventSequences)].sort(
          (left, right) => left - right
        );
        const omitted = sequences.length > 32 ? `; omittedSequences=${sequences.length - 32}` : '';
        const message = `Worker transcript event reconciliation failed. diagnosticCodes=${codes.join(',')}; rejectedEventSequences=${JSON.stringify(sequences.slice(0, 32))}${omitted}`;
        console.error(message);
        throw new Error(message);
      }
      await this.createWorkspaceChangeArtifacts(
        store,
        environmentPackage,
        workspaceChanges,
        workspaceDb,
        inputSnapshots,
        materializationRecords,
        recordedAt
      );
      await this.cleanupBackendLifecycle(
        backendLifecycle,
        workspaceDb,
        environmentPackage,
        backendCapabilities
      );
      this.emitImportedRecords(store, environmentPackage, requestId, importResult);
    } finally {
      releaseMutation?.();
    }
  }

  /** Stages release and successor captures through the same durable review and Artifact owner as Turn end. */
  public async publishWorkspaceCollections(
    store: FsStore,
    environmentPackage: AgentEnvironmentPackage,
    records: readonly WorkerGovernanceWorkspaceChangeRecord[]
  ): Promise<void> {
    if (!this.coreDb || records.length === 0) return;
    const lineage = {
      ...environmentPackage.scope,
      packageSnapshotId: environmentPackage.snapshotId,
    };
    if (
      !currentWorkerLineageWorkspaceAuthority(this.coreDb, lineage, 'workspace.write', true) ||
      !currentWorkerLineageWorkspaceAuthority(this.coreDb, lineage, 'artifact.write', true)
    )
      throw new TurnStartValidationError(
        'workspace_access_denied',
        'Workspace access denied.',
        403
      );
    const releaseMutation = this.workspaceMutationAdmission?.enterLatePublisher(
      environmentPackage.scope.workspaceId,
      'worker-turn-closeout'
    );
    if (this.workspaceMutationAdmission && !releaseMutation)
      throw new TurnStartValidationError(
        'workspace_access_denied',
        'Workspace access denied.',
        403
      );
    const db = openWorkspaceDb(this.coreDb.dataRoot, environmentPackage.scope.workspaceId);
    try {
      await this.createWorkspaceChangeArtifacts(
        store,
        environmentPackage,
        records,
        db,
        listWorkspaceInputSnapshots(db, environmentPackage.scope.workspaceId),
        listWorkspaceMaterializationRecords(db, environmentPackage.scope.workspaceId),
        records[0]!.review.createdAt
      );
    } finally {
      db.sqlite.close();
      releaseMutation?.();
    }
  }

  /**
   * Binds the Turn's AgentSession as the durable owner of native ready proof the backend accepts,
   * so the resume pair survives a failed Turn, a NanoCore restart, and the binding's close. With
   * that AgentSession's id the digest forms the resume pair a successor presents.
   *
   * @param store Store that owns the AgentSession.
   * @param environmentPackage Package of the live or restored Turn whose binding the backend holds.
   * @throws Error when native proof contradicts the durable digest or actual attachment provenance.
   */
  public bindNativeHandleRecorder(
    store: FsStore,
    environmentPackage: AgentEnvironmentPackage
  ): void {
    const agentSessionId = environmentPackage.scope.agentSessionId;
    this.backend.bindNativeHandleRecorder?.(
      environmentPackage.snapshotId,
      (digest, retainedStorage) => {
        this.recordNativeHandleDigest(store, agentSessionId, digest, retainedStorage);
      }
    );
  }

  /**
   * Joins live, restored or retiring binding proof to immutable attachment without backfilling it.
   *
   * @param store Store that owns the proof-producing AgentSession.
   * @param agentSessionId Exact binding's durable AgentSession identity.
   * @param digest Ready proof accepted by that binding.
   * @param retainedStorage Actual association and work slot held by that binding.
   * @throws TurnStartValidationError when immutable attachment provenance is missing or disagrees.
   */
  public recordNativeHandleDigest(
    store: FsStore,
    agentSessionId: string,
    digest: string,
    retainedStorage: { storageRef: string; workSlotRef: string }
  ): void {
    const session = store.getAgentSession(agentSessionId);
    if (
      !AgentSessionRetainedStorageSchema.safeParse(session.retainedStorage).success ||
      !isDeepStrictEqual(session.retainedStorage, retainedStorage)
    ) {
      throw new TurnStartValidationError(
        'recovery_required',
        'Native ready proof has no matching durable retained-storage attachment.',
        409
      );
    }
    if (session.nativeHandleDigest !== digest) {
      store.updateAgentSession(agentSessionId, {
        nativeHandleDigest: digest,
        updatedAt: this.now(),
      });
    }
  }

  /**
   * Physically cleans one exact backend identity and atomically projects only proven success.
   *
   * @param lifecycle Exact physical identity and optional durable Core state.
   * @param workspaceDb Optional product workspace projection target.
   * @param environmentPackage Immutable package that owns the session.
   * @param backendCapabilities Backend identity captured before materialization.
   * @param failedCloseout Whether product closeout failed and native session reuse is forbidden.
   * @returns Promise settled after physical cleanup and durable projection.
   * @throws Error when physical cleanup, lifecycle transition, or workspace projection fails.
   */
  private async cleanupBackendLifecycle(
    lifecycle: WorkerTurnBackendLifecycle,
    workspaceDb: WorkspaceDb | null,
    environmentPackage: AgentEnvironmentPackage,
    backendCapabilities: WorkerGovernanceBackendCapabilities,
    failedCloseout = false
  ): Promise<void> {
    if (lifecycle.session?.state === 'cleaned') {
      return;
    }

    // A live materialize refusal plus successful physical cleanup proves the unpublished handoff boundary.
    // Restart must derive its own exact proof instead of reconstructing this fact.
    const materializationNotPublished =
      failedCloseout && lifecycle.session?.state === 'materializing';
    if (!lifecycle.physicalCleanedAt) {
      if (lifecycle.session) {
        const session = lifecycle.session;
        if (session.state !== 'cleanup-pending') {
          lifecycle.session = transitionWorkerBackendSessionState(this.coreDb!, {
            fromState: session.state,
            attemptId: session.attemptId,
            now: this.now,
            toState: 'cleanup-pending',
          });
        }
      }

      try {
        if (failedCloseout) {
          await this.backend.cleanupSession(lifecycle.identity, { failedCloseout: true });
        } else {
          await this.backend.cleanupSession(lifecycle.identity);
        }
      } catch (error) {
        if (lifecycle.session?.state === 'cleanup-pending') {
          lifecycle.session = transitionWorkerBackendSessionState(this.coreDb!, {
            fromState: 'cleanup-pending',
            attemptId: lifecycle.session.attemptId,
            now: this.now,
            toState: 'cleanup-failed',
          });
        }
        throw error;
      }

      lifecycle.physicalCleanedAt = this.now();
      if (lifecycle.session?.state === 'cleanup-pending') {
        lifecycle.session = transitionWorkerBackendSessionState(this.coreDb!, {
          fromState: 'cleanup-pending',
          attemptId: lifecycle.session.attemptId,
          now: () => lifecycle.physicalCleanedAt!,
          toState: 'physical-cleaned',
        });
        lifecycle.physicalCleanedAt = lifecycle.session.physicalCleanedAt;
      }
    }

    if (workspaceDb) {
      const projection = projectWorkerBackendCleanup(workspaceDb, {
        agentSessionId: environmentPackage.scope.agentSessionId,
        backendSessionId: lifecycle.identity.backendSessionId,
        backendType: backendCapabilities.kind,
        backendVersion: backendCapabilities.version ?? null,
        completedAt: lifecycle.physicalCleanedAt!,
        environmentPackage,
        outcome: 'succeeded',
        packageSnapshotId: environmentPackage.snapshotId,
        placement: 'local',
        threadId: environmentPackage.scope.threadId,
        turnId: environmentPackage.scope.turnId,
        workerImage: lifecycle.session
          ? workerBackendImageIdentity(lifecycle.session.backendLineage)
          : workerBackendImageIdentity(
              normalizeUnanchoredReferenceLineage(environmentPackage.runtime.image)
            ),
        workspaceHandoffState: lifecycle.workspaceHandoffState,
        materializationNotPublished,
        workspaceId: environmentPackage.scope.workspaceId,
      });
      if (
        lifecycle.session?.workspaceHandoffState === 'pending' &&
        projection.workspaceHandoffComplete
      ) {
        lifecycle.session = markWorkerBackendWorkspaceHandoffComplete(this.coreDb!, {
          attemptId: lifecycle.session.attemptId,
          now: this.now,
        });
      }
    }

    if (lifecycle.session?.state === 'physical-cleaned' && workspaceDb) {
      lifecycle.session = transitionWorkerBackendSessionState(this.coreDb!, {
        fromState: 'physical-cleaned',
        attemptId: lifecycle.session.attemptId,
        now: this.now,
        toState: 'cleaned',
      });
    }
  }

  /**
   * Emits the start event for one governed turn.
   *
   * @param store Store that owns the turn.
   * @param environmentPackage Package lineage.
   * @param requestId Request id.
   */
  private emitTurnStarted(
    store: FsStore,
    environmentPackage: AgentEnvironmentPackage,
    requestId: string | null
  ): void {
    store.emitTurnEvent(environmentPackage.scope.turnId, {
      data: { status: 'running', turnId: environmentPackage.scope.turnId, type: 'turn-started' },
      event: 'turn.started',
      requestId,
      threadId: environmentPackage.scope.threadId,
      turnId: environmentPackage.scope.turnId,
      workspaceId: environmentPackage.scope.workspaceId,
    });
  }

  /**
   * Creates reviewable artifacts for worker-produced workspace change sets.
   *
   * @param store Store that owns the workspace.
   * @param environmentPackage Package lineage for the worker turn.
   * @param records Workspace change records returned by the backend.
   * @param workspaceDb Optional durable workspace database.
   * @param inputSnapshots Trusted input snapshots for the current worker package.
   * @param materializationRecords Trusted materializations for the current worker package.
   * @param recordedAt Stable durable final-status timestamp used by exact replay.
   */
  private async createWorkspaceChangeArtifacts(
    store: FsStore,
    environmentPackage: AgentEnvironmentPackage,
    records: readonly WorkerGovernanceWorkspaceChangeRecord[],
    workspaceDb: WorkspaceDb | null,
    inputSnapshots: readonly WorkspaceInputSnapshot[],
    materializationRecords: readonly WorkspaceMaterializationRecord[],
    recordedAt: string
  ): Promise<void> {
    if (records.length === 0) {
      return;
    }
    const artifactRequestId = environmentPackage.scope.requestId;
    if (!artifactRequestId) {
      throw new Error('Workspace review Artifact creation requires package request identity.');
    }

    for (const record of records) {
      const workerTurnRefs = record.changeSet.evidenceRefs
        .filter((reference) => reference.kind === 'worker')
        .map((reference) => reference.ref);
      const inputSnapshot = inputSnapshots.find(
        (snapshot) => snapshot.id === record.changeSet.inputSnapshotId
      );
      const materializationRecord = materializationRecords.find(
        (materialization) => materialization.id === record.changeSet.materializationRecordId
      );
      if (
        record.changeSet.workspaceId !== environmentPackage.scope.workspaceId ||
        record.review.workspaceId !== environmentPackage.scope.workspaceId ||
        record.review.changeSetId !== record.changeSet.id ||
        workerTurnRefs.length !== 1 ||
        workerTurnRefs[0] !== environmentPackage.scope.turnId ||
        (workspaceDb &&
          (!inputSnapshot ||
            inputSnapshot.resourceId !== record.changeSet.resourceId ||
            !materializationRecord ||
            materializationRecord.inputSnapshotId !== inputSnapshot.id ||
            materializationRecord.workspaceId !== environmentPackage.scope.workspaceId))
      ) {
        throw new Error(`Workspace review lineage mismatch: ${record.review.id}`);
      }

      const timestamp = recordedAt;
      const artifactId = deriveEntityId('ar', [
        'workspace_changes',
        environmentPackage.scope.turnId,
        record.review.id,
      ]);
      // Git sources publish through selected vendor MCP; retained output is evidence, never an apply prerequisite.
      const gitSource =
        environmentPackage.workspace?.inputs.some(
          (input) => input.id === record.changeSet.resourceId && input.source.kind === 'git'
        ) ?? false;
      const patchBytes = record.patchPayload
        ? workspaceSyncReviewPatchBytes(record.patchPayload)
        : null;
      const patchDigest = patchBytes
        ? `sha256:${createHash('sha256').update(patchBytes).digest('hex')}`
        : null;
      const gitPatchIsValid =
        record.changeSet.strategy !== 'git' ||
        Boolean(
          record.changeSet.patch &&
            record.patchPayload &&
            record.changeSet.patch.digest === record.patchPayload.digest &&
            record.changeSet.patch.bytes === record.patchPayload.bytes &&
            patchDigest === record.patchPayload.digest &&
            patchBytes?.byteLength === record.patchPayload.bytes
        );
      const filesystemApplyIsValid =
        record.changeSet.strategy !== 'filesystem' ||
        Boolean(
          record.filesystemApply &&
            record.filesystemApply.before.workspaceId === record.changeSet.workspaceId &&
            record.filesystemApply.before.resourceId === record.changeSet.resourceId &&
            record.filesystemApply.before.contentDigest === record.changeSet.base.contentDigest
        );
      const actionabilityFailures = [
        record.review.status !== 'pending' ? 'review_not_pending' : null,
        record.changeSet.strategy === 'git' && record.review.staging.strategy !== 'git_worktree'
          ? 'git_staging_invalid'
          : null,
        record.changeSet.strategy === 'git' && record.filesystemApply !== null
          ? 'git_filesystem_apply_present'
          : null,
        record.changeSet.strategy === 'filesystem' &&
        record.review.staging.strategy !== 'filesystem_staging'
          ? 'filesystem_staging_invalid'
          : null,
        record.changeSet.strategy === 'filesystem' && record.review.staging.branch !== null
          ? 'filesystem_branch_present'
          : null,
        record.changeSet.strategy === 'filesystem' && record.patchPayload !== null
          ? 'filesystem_patch_payload_present'
          : null,
        record.changeSet.strategy === 'filesystem' && record.changeSet.patch !== null
          ? 'filesystem_patch_reference_present'
          : null,
        workspaceDb && inputSnapshot?.strategy !== record.changeSet.strategy
          ? 'input_strategy_mismatch'
          : null,
        workspaceDb && materializationRecord?.strategy !== record.changeSet.strategy
          ? 'materialization_strategy_mismatch'
          : null,
        workspaceDb && !isDeepStrictEqual(inputSnapshot?.base, record.changeSet.base)
          ? 'input_base_mismatch'
          : null,
        workspaceDb && !isDeepStrictEqual(materializationRecord?.base, record.changeSet.base)
          ? 'materialization_base_mismatch'
          : null,
        !gitPatchIsValid ? 'git_patch_invalid' : null,
        !filesystemApplyIsValid ? 'filesystem_apply_invalid' : null,
      ].filter((reason): reason is string => reason !== null);
      if (actionabilityFailures.length > 0) {
        const reasons = actionabilityFailures.join(', ');
        const prefix = `Workspace review is not actionable (${reasons}): ${record.review.id}`;
        throw new Error(prefix);
      }
      const item = {
        artifactId,
        changeSet: record.changeSet,
        patchPayload: record.patchPayload,
        review: record.review,
      };
      let artifactCreated = false;
      /** Persists one staged record to artifact and durable workspace storage. */
      const persistRecord = (stagedItem: typeof item): void => {
        const body = JSON.stringify(
          {
            changeSet: stagedItem.changeSet,
            patchPayload: stagedItem.patchPayload,
            ...(gitSource ? {} : { review: stagedItem.review }),
          },
          null,
          2
        );
        const existingArtifact = store
          .listArtifacts(environmentPackage.scope.workspaceId)
          .find((candidate) => candidate.id === artifactId);
        const artifact = {
          id: artifactId,
          workspaceId: environmentPackage.scope.workspaceId,
          threadId: environmentPackage.scope.threadId,
          turnId: environmentPackage.scope.turnId,
          kind: 'diff',
          title: gitSource ? 'Git work evidence' : 'Workspace changes ready for review',
          status: 'ready',
          summary: stagedItem.review.riskSummary,
          version: 1,
          content: { format: 'json', body },
          contentDigest: `sha256:${createHash('sha256').update(body, 'utf8').digest('hex')}`,
          lastMutationRequestId: artifactRequestId,
          origin: {
            kind: 'turn-output',
            requestId: artifactRequestId,
            threadId: environmentPackage.scope.threadId,
            turnId: environmentPackage.scope.turnId,
          },
          createdAt: existingArtifact?.createdAt ?? timestamp,
          updatedAt: existingArtifact?.updatedAt ?? timestamp,
        } as const;
        const persist = (): void => {
          if (record.filesystemApply && workspaceDb) {
            recordFilesystemWorkspaceStagingRoot(workspaceDb, {
              before: record.filesystemApply.before,
              changeSetId: stagedItem.changeSet.id,
              createdAt: timestamp,
              reviewId: stagedItem.review.id,
              stagingRootPath: record.filesystemApply.stagingRootPath,
              targetRootPath: record.filesystemApply.targetRootPath,
              workspaceId: stagedItem.review.workspaceId,
            });
          }
          if (workspaceDb && !gitSource) {
            recordWorkspaceSyncReview(workspaceDb, { item: stagedItem });
          }
          if (existingArtifact) {
            if (!isDeepStrictEqual(existingArtifact, artifact)) {
              throw new Error(`Workspace review artifact replay conflict: ${artifactId}`);
            }
          } else {
            store.createArtifact(artifact);
            artifactCreated = true;
          }
        };

        if (workspaceDb) {
          workspaceDb.sqlite.transaction(persist)();
        } else {
          persist();
        }
      };
      persistRecord(item);
      if (artifactCreated) {
        const artifactItem = store
          .listThreadItems(environmentPackage.scope.workspaceId, environmentPackage.scope.threadId)
          .find(
            (candidate) =>
              candidate.type === 'artifact-reference' &&
              candidate.artifactId === artifactId &&
              candidate.artifactVersion === 1 &&
              candidate.lastMutationRequestId === artifactRequestId
          );
        if (!artifactItem) {
          throw new Error(`Workspace review Artifact reference is missing: ${artifactId}`);
        }
        this.emitImportedRecords(store, environmentPackage, artifactRequestId, {
          artifactIds: [artifactId],
          itemIds: [artifactItem.id],
        });
      }
    }
  }

  /**
   * Opens the workspace-scoped database used by workspace synchronization records.
   *
   * @param workspaceId Workspace id that owns the records.
   * @returns Workspace database handle, or null when durable storage is disabled.
   */
  private openWorkspaceDb(workspaceId: string): WorkspaceDb | null {
    if (!this.coreDb) {
      return null;
    }

    return openWorkspaceDb(this.coreDb.dataRoot, workspaceId);
  }

  /**
   * Emits created and completed events for one item.
   *
   * @param store Store that owns the turn.
   * @param environmentPackage Package lineage.
   * @param requestId Request id.
   * @param item Item to emit.
   */
  private emitItemCreatedAndCompleted(
    store: FsStore,
    environmentPackage: AgentEnvironmentPackage,
    requestId: string | null,
    item: ReturnType<FsStore['createItem']>
  ): void {
    store.emitTurnEvent(
      environmentPackage.scope.turnId,
      {
        data: { item, type: 'item-created' },
        event: 'item.created',
        requestId,
        threadId: environmentPackage.scope.threadId,
        turnId: environmentPackage.scope.turnId,
        workspaceId: environmentPackage.scope.workspaceId,
      },
      ALREADY_DECIDED_PUBLICATION_ADMISSION
    );
    store.emitTurnEvent(
      environmentPackage.scope.turnId,
      {
        data: { item, itemId: item.id, type: 'item-completed' },
        event: 'item.completed',
        requestId,
        threadId: environmentPackage.scope.threadId,
        turnId: environmentPackage.scope.turnId,
        workspaceId: environmentPackage.scope.workspaceId,
      },
      ALREADY_DECIDED_PUBLICATION_ADMISSION
    );
  }

  /**
   * Emits an AgentSession update event.
   *
   * @param store Store that owns the turn.
   * @param environmentPackage Package lineage.
   * @param requestId Request id.
   * @param agentSession AgentSession record.
   */
  private emitAgentSession(
    store: FsStore,
    environmentPackage: AgentEnvironmentPackage,
    requestId: string | null,
    agentSession: ReturnType<FsStore['createAgentSession']>
  ): void {
    store.emitTurnEvent(
      environmentPackage.scope.turnId,
      {
        data: { agentSession, type: 'agent-session-updated' },
        event: 'agent.session.updated',
        requestId,
        threadId: environmentPackage.scope.threadId,
        turnId: environmentPackage.scope.turnId,
        workspaceId: environmentPackage.scope.workspaceId,
      },
      ALREADY_DECIDED_PUBLICATION_ADMISSION
    );
  }

  /**
   * Emits events for records imported from worker transcript files.
   *
   * @param store Store that owns the turn.
   * @param environmentPackage Package lineage.
   * @param requestId Request id.
   * @param importResult Imported canonical record ids.
   */
  private emitImportedRecords(
    store: FsStore,
    environmentPackage: AgentEnvironmentPackage,
    requestId: string | null,
    importResult: { itemIds: string[]; artifactIds: string[] }
  ): void {
    const threadItems = store.listThreadItems(
      environmentPackage.scope.workspaceId,
      environmentPackage.scope.threadId
    );

    for (const itemId of importResult.itemIds) {
      const item = threadItems.find((candidate) => candidate.id === itemId);

      if (item) {
        this.emitItemCreatedAndCompleted(store, environmentPackage, requestId, item);
      }
    }
    for (const artifactId of importResult.artifactIds) {
      const artifact = store.getArtifact(environmentPackage.scope.workspaceId, artifactId);
      store.emitTurnEvent(
        environmentPackage.scope.turnId,
        {
          data: { artifact, type: 'artifact-created' },
          event: 'artifact.created',
          requestId,
          threadId: environmentPackage.scope.threadId,
          turnId: environmentPackage.scope.turnId,
          workspaceId: environmentPackage.scope.workspaceId,
        },
        ALREADY_DECIDED_PUBLICATION_ADMISSION
      );
    }
  }

  /**
   * Projects one accepted worker-control final status through the canonical Turn owners.
   *
   * @param store Store that owns the Turn and AgentSession.
   * @param turnScope Turn whose ids scope the terminal records.
   * @param agentSessionId Exact worker AgentSession.
   * @param requestId Worker command request id.
   * @param accepted Durable worker-control final status.
   * @param packageSnapshotId Exact package whose last inference call may explain failure.
   * @throws Error when the accepted status has no supported canonical StopReason.
   */
  private recordAcceptedWorkerOutcome(
    store: FsStore,
    turnScope: ReturnType<FsStore['getTurnById']>,
    agentSessionId: string,
    requestId: string | null,
    accepted: AcceptedWorkerFinalStatus,
    packageSnapshotId: string | null
  ): void {
    const terminalCause = this.coreDb
      ? listSchedulerExecutionAttemptsForTurn(this.coreDb, {
          workspaceId: turnScope.workspaceId,
          threadId: turnScope.threadId,
          turnId: turnScope.id,
        }).find(
          (attempt) =>
            attempt.agentSessionId === agentSessionId && attempt.inputRef === packageSnapshotId
        )?.terminalCause
      : null;
    const cancellationWon = terminalCause === 'turn-cancelled';
    // Native final evidence proves stop; the exact attempt's durable cause owns product meaning.
    const stopReason = canonicalStopReasonForAcceptedWorkerFinalStatus(accepted, terminalCause);
    // Closeout already closed a binding it could not prove reusable; one that survives keeps its
    // AgentSession current, because an unsuccessful Turn does not by itself end the conversation.
    const agentSessionRetained =
      this.backend.readThreadAgentSessionBinding?.({
        threadId: turnScope.threadId,
        workspaceId: turnScope.workspaceId,
      })?.agentSessionId === agentSessionId;
    if (
      stopReason === 'completed' ||
      stopReason === 'length' ||
      stopReason === 'budget_exhausted'
    ) {
      this.completeTurn(store, turnScope, agentSessionId, requestId, stopReason);
      return;
    }
    if (stopReason === 'aborted') {
      terminalizeGovernedWorkerTurn({
        agentSessionId,
        agentSessionRetained,
        completedAt: this.now(),
        errorCode: 'worker_governance_turn_cancelled',
        message: cancellationWon
          ? 'Worker execution was interrupted.'
          : 'Worker reported an aborted terminal status.',
        outcome: turnStatusForCanonicalWorkerStopReason(stopReason),
        requestId,
        store,
        turnId: turnScope.id,
      });
      return;
    }
    if (accepted.status === 'failed') {
      // The admitted map already fits the 64 KiB control envelope; preserve it exactly for operator diagnosis.
      console.error(
        JSON.stringify({
          event: 'worker.turn.failed',
          turnId: turnScope.id,
          status: accepted.status,
          diagnostics: accepted.diagnostics ?? {},
        })
      );
    }
    let inferenceDetail = '';
    let unsupportedInference = false;
    const workspaceDb = packageSnapshotId ? this.openWorkspaceDb(turnScope.workspaceId) : null;
    try {
      const lastInference =
        workspaceDb && packageSnapshotId
          ? listWorkspaceCapabilityCalls(workspaceDb, turnScope.workspaceId).findLast(
              (call) =>
                call.serviceRef === 'worker-inference-gateway' &&
                call.threadId === turnScope.threadId &&
                call.turnId === turnScope.id &&
                call.agentSessionId === agentSessionId &&
                call.packageSnapshotId === packageSnapshotId
            )
          : undefined;
      if (
        lastInference?.status === 'failed' &&
        (lastInference.errorCode === 'worker_inference_stream_failed' ||
          lastInference.errorCode === 'gateway_stream_failed' ||
          lastInference.errorCode === 'provider_stream_truncated' ||
          lastInference.errorCode === 'provider_stream_failed')
      ) {
        inferenceDetail = ' Last worker inference stream failed before completion.';
      }
      unsupportedInference =
        lastInference?.status === 'failed' &&
        lastInference.errorCode === 'unsupported_gateway_feature';
    } finally {
      workspaceDb?.sqlite.close();
    }
    if (unsupportedInference) {
      // Project only the known Gateway category, never the request or bridge feature text.
      terminalizeGovernedWorkerTurn({
        agentSessionId,
        agentSessionRetained,
        completedAt: this.now(),
        errorCode: 'unsupported_gateway_feature',
        message:
          'The Gateway cannot preserve the requested features for the selected model route. Choose a compatible model route and start a new Task.',
        outcome: 'failed',
        requestId,
        store,
        turnId: turnScope.id,
      });
      return;
    }
    // Both live and reopened closeout consume the same admitted, product-safe cause.
    const cause =
      accepted.diagnostics?.failureCause?.trim() || accepted.diagnostics?.native?.trim();
    const failure = new Error(
      cause || `Worker reported terminal status: ${accepted.status}.${inferenceDetail}`
    );
    this.failTurn(
      store,
      turnScope,
      agentSessionId,
      requestId,
      failure,
      failure,
      agentSessionRetained
    );
  }

  /**
   * Completes one turn after successful transcript import.
   *
   * @param store Store that owns the turn.
   * @param turnScope Turn whose ids scope the terminal records.
   * @param agentSessionId AgentSession completed by the turn.
   * @param requestId Request id.
   * @param stopReason Canonical successful terminal reason.
   */
  private completeTurn(
    store: FsStore,
    turnScope: ReturnType<FsStore['getTurnById']>,
    agentSessionId: string,
    requestId: string | null,
    stopReason: Extract<StopReason, 'budget_exhausted' | 'completed' | 'length'> = 'completed'
  ): void {
    const completedAt = this.now();
    const agentSession = store.updateAgentSession(agentSessionId, {
      message: null,
      status: 'idle',
      updatedAt: completedAt,
    });
    const turn = store.updateTurn(turnScope.id, {
      completedAt,
      error: null,
      status: 'completed',
    });

    store.emitTurnEvent(
      turnScope.id,
      {
        data: { agentSession, type: 'agent-session-updated' },
        event: 'agent.session.updated',
        requestId,
        threadId: turnScope.threadId,
        turnId: turnScope.id,
        workspaceId: turnScope.workspaceId,
      },
      ALREADY_DECIDED_PUBLICATION_ADMISSION
    );
    store.emitTurnEvent(
      turnScope.id,
      {
        data: { stopReason, turn, type: 'turn-completed' },
        event: 'turn.completed',
        requestId,
        threadId: turnScope.threadId,
        turnId: turnScope.id,
        workspaceId: turnScope.workspaceId,
      },
      ALREADY_DECIDED_PUBLICATION_ADMISSION
    );
  }

  /**
   * Publishes failure or the already decided cancellation without changing its race winner.
   *
   * @param store Store that owns the turn.
   * @param turnScope Turn whose ids scope the terminal records.
   * @param agentSessionId Optional AgentSession created before the failure.
   * @param requestId Request id.
   * @param error Failure reason, including cleanup errors.
   * @param primaryError Original execution failure whose safe observation survives cleanup.
   * @param agentSessionRetained Whether the backend still holds the AgentSession's reusable binding.
   * @throws AggregateError when one or more terminal writes report a partial failure.
   */
  private failTurn(
    store: FsStore,
    turnScope: ReturnType<FsStore['getTurnById']>,
    agentSessionId: string | null,
    requestId: string | null,
    error: unknown,
    primaryError: unknown = error,
    agentSessionRetained = false
  ): void {
    const cancellationWon =
      this.coreDb &&
      agentSessionId !== null &&
      listSchedulerExecutionAttemptsForTurn(this.coreDb, {
        workspaceId: turnScope.workspaceId,
        threadId: turnScope.threadId,
        turnId: turnScope.id,
      }).some(
        (attempt) =>
          attempt.agentSessionId === agentSessionId && attempt.terminalCause === 'turn-cancelled'
      );
    const explanation = GitFailureExplanationSchema.safeParse(
      primaryError instanceof Error && 'explanation' in primaryError
        ? primaryError.explanation
        : undefined
    );
    const message = publishedErrorMessage(error, 'The governed worker turn failed.');
    terminalizeGovernedWorkerTurn({
      agentSessionId,
      agentSessionRetained,
      completedAt: this.now(),
      errorCode: cancellationWon
        ? 'worker_governance_turn_cancelled'
        : 'worker_governance_turn_failed',
      ...(!cancellationWon && explanation.success ? { explanation: explanation.data } : {}),
      message: cancellationWon ? 'Worker execution was interrupted.' : message,
      outcome: cancellationWon ? 'interrupted' : 'failed',
      requestId,
      store,
      turnId: turnScope.id,
    });
  }
}

/** Identifies one redacted live Artifact collection validation failure. @param error Backend failure. @returns Whether the existing Turn boundary should return invalid_request. */
function isWorkerArtifactCollectionInvalid(error: unknown): boolean {
  return (
    typeof error === 'object' &&
    error !== null &&
    'code' in error &&
    error.code === WORKER_ARTIFACT_COLLECTION_INVALID
  );
}

/** Maps bounded Artifact import failures onto the existing public Turn-start error boundary. */
function asWorkerArtifactTurnError(error: unknown): unknown {
  if (isWorkerArtifactCollectionInvalid(error)) {
    return new TurnStartValidationError(
      'invalid_request',
      'Worker Artifact declarations or content are invalid.',
      400
    );
  }
  if (
    error instanceof ArtifactAuthorityError &&
    (error.code === 'invalid_request' || error.code === 'recovery_required')
  ) {
    return new TurnStartValidationError(error.code, error.message, error.status);
  }
  return error;
}

/**
 * Reads the canonical SessionCompatibilityKey projected by the AEP resolver.
 *
 * @param environmentPackage Admitted package or non-dispatchable planning metadata.
 * @returns The existing session-static key, before backend path materialization.
 */
export function agentSessionCompatibilityKeyFromPackage(
  environmentPackage: AgentEnvironmentPackagePreview
): string {
  return (
    environmentPackage.extensions.openkit as {
      sessionWorkspace: SessionWorkspaceMaterializationPlan;
    }
  ).sessionWorkspace.compatibilityKey.digest;
}

/** Reads the exact work-slot identity already validated into one metadata-only AEP. */
function requirePackageWorkerStorageWorkSlotRef(
  environmentPackage: AgentEnvironmentPackagePreview
): string {
  const workSlotRef = (
    environmentPackage.extensions.openkit as {
      workerStorage: { workSlotRef: string };
    }
  ).workerStorage.workSlotRef;
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/.test(workSlotRef)) {
    throw new TurnStartValidationError(
      'recovery_required',
      'The Agent Environment Package Worker storage slot is invalid.',
      409
    );
  }
  return workSlotRef;
}

/** Verifies that the restored package, Core session, and backend plan have one authority lineage. */
function assertRestoredSession(
  environmentPackage: AgentEnvironmentPackage,
  session: WorkerBackendSessionRecord,
  identity: WorkerGovernanceBackendSessionIdentity
): void {
  const scope = environmentPackage.scope;
  if (
    session.workspaceId !== scope.workspaceId ||
    session.threadId !== scope.threadId ||
    session.turnId !== scope.turnId ||
    session.agentSessionId !== scope.agentSessionId ||
    session.packageSnapshotId !== environmentPackage.snapshotId ||
    session.backendKind !== identity.backendKind ||
    session.backendSessionId !== identity.backendSessionId ||
    session.deploymentId !== identity.deploymentId ||
    session.stagingDirectoryRef !== identity.stagingDirectoryRef ||
    session.transientProviderInstanceId !== identity.transientProviderInstanceId ||
    session.runtimeTargetId !== identity.runtimeTargetId
  ) {
    throw new Error('Restart closeout backend session does not match its immutable lineage.');
  }
}

/** Returns reference lineage for the retained unanchored legacy cleanup projection. */
function normalizeUnanchoredReferenceLineage(
  image: AgentEnvironmentPackage['runtime']['image']
): WorkerBackendSessionRecord['backendLineage'] {
  if (image.kind !== 'reference') {
    throw new Error('NanoHost build lineage must be durably anchored before cleanup.');
  }
  return { imageRef: image.ref };
}

/**
 * Converts backend capability kinds into the public workspace synchronization vocabulary.
 *
 * @param kind Backend capability kind.
 * @returns Workspace synchronization backend kind.
 */
function toWorkspaceSynchronizationBackendKind(kind: string): WorkspaceSynchronizationBackendKind {
  if (
    kind === 'host' ||
    kind === 'openshell' ||
    kind === 'docker' ||
    kind === 'managed-sandbox' ||
    kind === 'remote-vm'
  ) {
    return kind;
  }

  if (kind === 'vm') {
    return 'remote-vm';
  }

  return 'managed-sandbox';
}

/**
 * Maps NanoCore's selected workspace cwd to the matching worker-visible path.
 *
 * @param context Turn startup context captured by NanoCore.
 * @param backend Backend selected for the Agent Environment Package.
 * @returns Worker-visible cwd when a backend path mapping exists, otherwise the original cwd.
 */
export function workerVisibleWorkspaceCwd(
  context: TurnStartRuntimeContext,
  backend: ResolveAgentEnvironmentBackendInput
): string | null {
  const workspaceCwd = context.workspaceCwd ?? null;

  if (backend.kind !== 'openshell' || !workspaceCwd) {
    return workspaceCwd;
  }

  return (
    context.workspaceRoots.find(
      (root) => root.sourceKind !== 'remote-git' && root.sourcePath === workspaceCwd
    )?.workerPath ?? workspaceCwd
  );
}

/** Selects the exact storage work slot before the immutable package is planned. */
export function workerStorageWorkSlotRef(
  choice: TurnStartRuntimeContext['workerStorageChoice'],
  workspaceId: string,
  threadId: string,
  coreDb: CoreDb | null,
  responsibleUserId: string | null
): string {
  if (choice?.kind !== 'selected') return workerStorageDefaultWorkSlotRef(workspaceId, threadId);
  const binding = coreDb
    ? getWorkerStorageBinding(coreDb, { storageRef: choice.storageRef })
    : null;
  if (!binding || binding.workspaceId !== workspaceId || !responsibleUserId) {
    throw new TurnStartValidationError(
      'recovery_required',
      'Selected Worker storage is unavailable.',
      409
    );
  }
  return resolveWorkerStorageWorkSlotRef(binding, {
    threadId,
    responsibleUserId,
    ...(choice.reuseWorkSlotRef ? { reuseWorkSlotRef: choice.reuseWorkSlotRef } : {}),
  });
}
