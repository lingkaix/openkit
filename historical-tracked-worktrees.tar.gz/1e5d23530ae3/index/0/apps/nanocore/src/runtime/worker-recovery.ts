import { join } from 'node:path';
import { isDeepStrictEqual } from 'node:util';
import { AgentSessionSchema, deriveEntityId, type StopReason } from '@openkit/protocol';
import { StructuredWorkerDelegationRequestSchema } from '../internal-agents/delegation.js';
import {
  DISPLAY_PROJECTION_REFRESH_FIELDS,
  type FsStore,
  projectTurnEventRequestId,
} from '../lib/store.js';
import { OperationError } from '../operation-error.js';
import {
  requireSchedulerExecutionAttemptAdmissionContext,
  schedulerAdmissionInputHash,
} from '../scheduler-records.js';
import type { CoreDb, WorkspaceDb } from '../storage/db.js';
import { isAlreadyDecidedWorkerMcpItem } from '../worker-mcp-routes.js';
import {
  findNamedAgentEnvironmentPackageSnapshot,
  listExportableAgentEnvironmentPackageSnapshots,
  requireAgentEnvironmentPackageSnapshot,
} from './aep-snapshot-ledger.js';
import {
  isSchedulerExecutionBusyRefusal,
  listSchedulerExecutionAttemptsForTurn,
} from './execution-attempt-records.js';
import { commandInputHash } from './idempotent-command.js';
import {
  hasNanoHostAttemptPreEffectProof,
  hasNanoHostUnusedFailedStartAnchorProof,
} from './nanohost-attempt-recovery.js';
import { getSchedulerPreparationClaims } from './scheduler-dispatch-loop.js';
import {
  clearWorkerCheckpoint,
  getWorkerCheckpoint,
  listRecoverableWorkerCheckpoints,
  parseWorkerCheckpointContextAssembly,
  type WorkerCheckpointContextAssemblySummary,
  type WorkerCheckpointRecord,
} from './worker-checkpoints.js';
import { turnStatusForCanonicalWorkerStopReason } from './worker-control-records.js';
import { importWorkerRuntimeProvenance } from './worker-runtime-provenance.js';
import {
  isTerminalWorkerTurnStage,
  type WorkerTurnStage,
  workerTurnStageForStopReason,
} from './worker-stage.js';

/**
 * Worker stages that still need visible recovery materialization.
 */
export type RecoverableWorkerTurnStage = Exclude<WorkerTurnStage, 'completed'>;

/**
 * Resolves the initiating human command scope for one exact worker checkpoint.
 *
 * @param coreDb Core database containing scheduler admission lineage.
 * @param checkpoint Worker checkpoint whose initiating command is being verified.
 * @returns Human actor, Workspace, and Thread command scope.
 * @throws Error when scheduler ownership or the human trigger identity is absent or contradictory.
 */
export function requireWorkerCheckpointHumanCommandScope(
  coreDb: CoreDb,
  checkpoint: WorkerCheckpointRecord
): { readonly actorId: string; readonly threadId: string; readonly workspaceId: string } {
  const attempts = listSchedulerExecutionAttemptsForTurn(coreDb, {
    workspaceId: checkpoint.workspaceId,
    threadId: checkpoint.threadId,
    turnId: checkpoint.turnId,
  }).filter((attempt) => !isSchedulerExecutionBusyRefusal(attempt));
  const attempt = attempts[0];
  if (attempts.length !== 1 || !attempt || attempt.agentSessionId !== checkpoint.workerSessionId) {
    throw new Error('Worker checkpoint has no exact execution attempt.');
  }

  const admission = requireSchedulerExecutionAttemptAdmissionContext(coreDb, attempt.attemptId);
  if (admission.requestId !== checkpoint.requestId || admission.triggerActor.kind !== 'user') {
    throw new Error('Worker checkpoint has no exact human command identity.');
  }

  return {
    actorId: admission.triggerActor.id,
    threadId: checkpoint.threadId,
    workspaceId: checkpoint.workspaceId,
  };
}

/**
 * Read-model row describing a worker turn that was interrupted before terminal save.
 */
export interface InterruptedWorkerStateRecord {
  /** Stable row kind used by App API projections. */
  readonly kind: 'interrupted_worker_state';
  /** Source checkpoint id. */
  readonly checkpointId: string;
  /** Workspace that owns the interrupted worker turn. */
  readonly workspaceId: string;
  /** Thread that owns the interrupted worker turn. */
  readonly threadId: string;
  /** Turn represented by the interrupted state. */
  readonly turnId: string;
  /** Optional goal id associated with the interrupted worker turn. */
  readonly goalId: string | null;
  /** Optional goal task id associated with the interrupted worker turn. */
  readonly taskId: string | null;
  /** Last known recoverable worker stage. */
  readonly stage: RecoverableWorkerTurnStage;
  /** Worker iteration count at the source checkpoint. */
  readonly iteration: number;
  /** Optional host worker session id from the source checkpoint. */
  readonly workerSessionId: string | null;
  /** Optional context package digest from the source checkpoint. */
  readonly contextDigest: string | null;
  /** Product-safe context assembly summary from the source checkpoint. */
  readonly contextAssembly: WorkerCheckpointContextAssemblySummary | null;
  /** Optional stop reason known at interruption time. */
  readonly stopReason: StopReason | null;
  /** Redacted diagnostic summary from the source checkpoint. */
  readonly diagnosticsSummary: string | null;
  /** Interrupted states are visibility records, not replay instructions. */
  readonly replayInstruction: false;
  /** Typed recovery choices available to a user or Coordinator. */
  readonly choices: readonly InterruptedWorkerRecoveryChoice[];
  /** ISO timestamp for recovery materialization. */
  readonly materializedAt: string;
  /** ISO timestamp copied from the source checkpoint update. */
  readonly sourceUpdatedAt: string;
}

/**
 * Typed recovery choice surfaced for an interrupted worker turn.
 */
export type InterruptedWorkerRecoveryChoice =
  | {
      /** Inspect durable state and evidence before choosing a recovery action. */
      readonly kind: 'inspect';
      /** User-facing action label. */
      readonly label: string;
      /** True when this should be the first recovery step. */
      readonly recommended: true;
    }
  | {
      /** Retry the interrupted checkpoint through the existing recovery endpoint. */
      readonly kind: 'retry';
      /** User-facing action label. */
      readonly label: string;
    }
  | {
      /** Ask the user or coordinator how to proceed when evidence is insufficient. */
      readonly kind: 'request_human';
      /** User-facing action label. */
      readonly label: string;
    };

/**
 * Derived authority decision for one interrupted-worker retry request.
 */
export interface InterruptedWorkerRetryDecision {
  /** Whether the exact existing owners permit retry, inspection, or no recovery action. */
  readonly status:
    | 'eligible'
    | 'inspect-only'
    | 'reconnect-pending'
    | 'stale'
    | 'recovery-required';
  /** Exact source checkpoint, or null when no checkpoint exists. */
  readonly checkpoint: WorkerCheckpointRecord | null;
}

/**
 * Input used to clear a checkpoint after terminal state is durably saved.
 */
export interface ClearWorkerCheckpointAfterTerminalStateInput {
  /** Workspace that owns the worker turn. */
  readonly workspaceId: string;
  /** Thread that owns the worker turn. */
  readonly threadId: string;
  /** Turn represented by the checkpoint. */
  readonly turnId: string;
  /**
   * Skips runtime-provenance re-import for one proved boot leftover.
   *
   * Only the stale direct-Task classifier sets this, and only after a null
   * worker session plus one closed, definite pre-effect failed-start attempt. Skipping does not claim provenance is complete or that no Worker ran.
   */
  readonly skipRuntimeProvenance?: boolean;
  /** Existing Core and product owners used to revalidate the assigned-Session never-submitted exception. */
  readonly coreDb?: CoreDb;
  /** Original product store; supplied with Core only by the initiating checkpoint owner. */
  readonly store?: FsStore;
}

/**
 * Validates the complete assigned-Session failed-start alternative without writing any owner.
 *
 * Command receipt authority remains with the initiating mode. Native absence stays adapter-owned; this proof only makes execution-generated provenance inapplicable on the exact never-submitted branch.
 * @param coreDb Existing admission and attempt owners.
 * @param store Original Turn, AgentSession and publication owners.
 * @param workspaceDb Immutable input, package and checkpoint owners.
 * @param checkpoint Exact original checkpoint, including a failed projection left by partial closeout.
 * @returns Whether this tuple proves a never-submitted failed start.
 * @throws Error for unreadable or contradictory retained owners.
 */
export function hasWorkerCheckpointNeverSubmittedProof(
  coreDb: CoreDb,
  store: FsStore,
  workspaceDb: WorkspaceDb,
  checkpoint: WorkerCheckpointRecord
): boolean {
  if (
    !checkpoint.workerSessionId ||
    checkpoint.goalId !== null ||
    checkpoint.taskId !== null ||
    checkpoint.iteration !== 0 ||
    !(
      (checkpoint.stage === 'running_worker' && checkpoint.stopReason === null) ||
      (checkpoint.stage === 'failed' && checkpoint.stopReason === 'error')
    )
  )
    return false;
  const attempts = listSchedulerExecutionAttemptsForTurn(coreDb, checkpoint);
  const relevant = attempts.filter((attempt) => !isSchedulerExecutionBusyRefusal(attempt));
  const attempt = relevant[0];
  if (
    !attempt ||
    relevant.length !== 1 ||
    attempt.agentSessionId !== checkpoint.workerSessionId ||
    attempt.phase !== 'closed' ||
    attempt.disposition !== 'not_accepted' ||
    attempt.terminalCause !== 'turn-start-failed' ||
    attempt.operationId !== null ||
    attempt.deadline !== null ||
    attempt.fenceRef !== null ||
    attempt.outcomeRef !== null ||
    !attempt.inputRef
  )
    return false;
  const admission = requireSchedulerExecutionAttemptAdmissionContext(coreDb, attempt.attemptId);
  if (getSchedulerPreparationClaims(coreDb).has(admission.queueEntryId)) return false;
  const turn = store.getTurn(checkpoint.workspaceId, checkpoint.threadId, checkpoint.turnId);
  const session = store.getAgentSession(checkpoint.workerSessionId);
  const pkg = requireAgentEnvironmentPackageSnapshot(
    workspaceDb,
    checkpoint.workspaceId,
    attempt.inputRef
  ).snapshot;
  const initiatingItem = turn.items.find(
    (item) => item.id === deriveEntityId('it', ['task-user', turn.id])
  );
  const originalInput = store
    .listWorkspaceItemRevisions(checkpoint.workspaceId)
    .find((item) => item.id === deriveEntityId('it', ['task-user', turn.id]));
  const preparation = JSON.parse(attempt.preparationInputJson);
  if (
    admission.status !== 'admitted' ||
    admission.requestId !== checkpoint.requestId ||
    admission.requestedAgentId !== turn.agentId ||
    admission.backendId !== attempt.backendId ||
    schedulerAdmissionInputHash(admission) !== admission.inputHash ||
    !preparation?.admission ||
    preparation.admission.queueEntryId !== admission.queueEntryId ||
    schedulerAdmissionInputHash(preparation.admission) !== admission.inputHash ||
    !isDeepStrictEqual(turn.triggerActor, admission.triggerActor) ||
    turn.agentSessionId !== session.id ||
    !['running', 'failed'].includes(turn.status) ||
    session.workspaceId !== checkpoint.workspaceId ||
    session.threadId !== checkpoint.threadId ||
    session.agentId !== turn.agentId ||
    session.stale ||
    session.nativeHandleDigest != null ||
    !['created', 'failed'].includes(session.status) ||
    (session.status === 'created' && session.message !== null) ||
    session.environmentPackageSnapshotId !== pkg.snapshotId ||
    pkg.agent.agentId !== turn.agentId ||
    pkg.scope.workspaceId !== checkpoint.workspaceId ||
    pkg.scope.threadId !== checkpoint.threadId ||
    pkg.scope.turnId !== checkpoint.turnId ||
    pkg.scope.agentSessionId !== session.id ||
    pkg.scope.requestId !== checkpoint.requestId ||
    !isDeepStrictEqual(pkg.scope.triggerActor, admission.triggerActor) ||
    initiatingItem?.type !== 'user-message' ||
    initiatingItem.status !== 'completed' ||
    initiatingItem.workspaceId !== checkpoint.workspaceId ||
    initiatingItem.threadId !== checkpoint.threadId ||
    initiatingItem.turnId !== turn.id ||
    !isDeepStrictEqual(initiatingItem, originalInput) ||
    !isDeepStrictEqual(initiatingItem.actor, turn.triggerActor) ||
    initiatingItem.text !== admission.turnInput ||
    (pkg.extensions.openkit as { turnInput?: unknown }).turnInput !== admission.turnInput ||
    !checkpoint.contextDigest ||
    commandInputHash(
      StructuredWorkerDelegationRequestSchema.parse(JSON.parse(admission.turnInput))
    ) !== checkpoint.contextDigest ||
    parseWorkerCheckpointContextAssembly(checkpoint.diagnosticsSummary)?.contextDigest !==
      checkpoint.contextDigest
  )
    throw new Error('Never-submitted checkpoint has contradictory input or product lineage.');
  if (
    // The attempt owner enumerates rowid creation order; equal timestamps alone prove no order.
    attempts.some(
      (sibling, index) =>
        sibling.attemptId !== attempt.attemptId &&
        (!isSchedulerExecutionBusyRefusal(sibling) ||
          index >= attempts.indexOf(attempt) ||
          sibling.createdAt > attempt.createdAt ||
          !hasNanoHostAttemptPreEffectProof(coreDb, sibling.attemptId))
    ) ||
    coreDb.sqlite
      .prepare(
        'SELECT 1 FROM scheduler_admission_entries WHERE turn_id = ? AND queue_entry_id <> ? LIMIT 1'
      )
      .get(turn.id, admission.queueEntryId) ||
    coreDb.sqlite
      .prepare(
        "SELECT 1 FROM scheduler_execution_attempts WHERE agent_session_id = ? AND attempt_id <> ? AND phase <> 'closed' LIMIT 1"
      )
      .get(session.id, attempt.attemptId) ||
    coreDb.sqlite
      .prepare(
        'SELECT 1 FROM worker_backend_sessions WHERE (turn_id = ? OR agent_session_id = ?) AND attempt_id <> ? LIMIT 1'
      )
      .get(turn.id, session.id, attempt.attemptId) ||
    coreDb.sqlite
      .prepare(`SELECT 1 FROM worker_control_records WHERE turn_id = ?
      UNION ALL SELECT 1 FROM worker_control_rejected_evidence WHERE turn_id = ?
      UNION ALL SELECT 1 FROM worker_control_sequence_fingerprints WHERE turn_id = ? LIMIT 1`)
      .get(turn.id, turn.id, turn.id) ||
    workspaceDb.sqlite
      .prepare(
        'SELECT 1 FROM pending_requests WHERE raising_turn_id = ? OR delivery_turn_id = ? LIMIT 1'
      )
      .get(turn.id, turn.id) ||
    turn.items.some((item) =>
      [
        'approval-request',
        'approval-decision',
        'user-input-request',
        'user-input-response',
      ].includes(item.type)
    ) ||
    store
      .listCommandRequests()
      .some(
        (receipt) =>
          receipt.scope.workspaceId === turn.workspaceId &&
          receipt.scope.turnId === turn.id &&
          ['approval.respond', 'user_input.answer', 'pending_request.withdraw'].includes(
            receipt.command
          )
      ) ||
    store
      .listThreadTurns(turn.workspaceId, turn.threadId)
      .some(
        (other) =>
          other.id !== turn.id &&
          other.agentSessionId === session.id &&
          !['completed', 'failed', 'cancelled', 'interrupted'].includes(other.status)
      ) ||
    !hasNanoHostUnusedFailedStartAnchorProof(coreDb, workspaceDb, pkg, attempt.attemptId)
  )
    return false;
  // Validate existing partial publications before invoking a lifecycle owner that can repair missing writes.
  const events = store.getTurnEvents(turn.id);
  const terminals = events.filter((event) => event.event === 'turn.completed');
  const sessionEvents = events.filter((event) => event.event === 'agent.session.updated');
  const requestId = projectTurnEventRequestId(
    checkpoint.requestId,
    turn.workspaceId,
    turn.threadId
  );
  const completedAt = turn.completedAt ?? (session.status === 'failed' ? session.updatedAt : null);
  if (
    (turn.status === 'running' && (turn.error !== null || turn.completedAt !== null)) ||
    (turn.status === 'failed' && (!turn.error?.code || !turn.error.message || !turn.completedAt)) ||
    terminals.length > 1 ||
    terminals.some(
      (event) =>
        event.requestId !== requestId ||
        event.workspaceId !== turn.workspaceId ||
        event.threadId !== turn.threadId ||
        event.turnId !== turn.id ||
        event.data.type !== 'turn-completed' ||
        event.data.stopReason !== 'error' ||
        Date.parse(event.data.turn.completedAt!) > Date.parse(event.timestamp) ||
        // Align with native failed-start recovery: preserve the ordered published prefix and prove every addition.
        !isDeepStrictEqual(
          withoutConversationStatusDisplayFields(event.data.turn),
          withoutConversationStatusDisplayFields({
            ...turn,
            items: turn.items.slice(0, event.data.turn.items.length),
          })
        ) ||
        !turn.items
          .slice(event.data.turn.items.length)
          .every((item) => isAlreadyDecidedWorkerMcpItem(workspaceDb, pkg, item, turn.completedAt))
    ) ||
    sessionEvents.filter(
      (event) =>
        event.data.type === 'agent-session-updated' && event.data.agentSession.status === 'created'
    ).length > 1 ||
    sessionEvents.filter(
      (event) =>
        event.data.type === 'agent-session-updated' && event.data.agentSession.status === 'failed'
    ).length > 1 ||
    sessionEvents.some(
      (event) =>
        event.requestId !== requestId ||
        event.workspaceId !== turn.workspaceId ||
        event.threadId !== turn.threadId ||
        event.turnId !== turn.id ||
        event.data.type !== 'agent-session-updated' ||
        event.data.agentSession.id !== session.id ||
        event.data.agentSession.agentId !== session.agentId ||
        event.data.agentSession.workspaceId !== session.workspaceId ||
        event.data.agentSession.threadId !== session.threadId ||
        event.data.agentSession.createdAt !== session.createdAt ||
        Date.parse(event.data.agentSession.updatedAt) > Date.parse(event.timestamp) ||
        !['created', 'failed'].includes(event.data.agentSession.status) ||
        (event.data.agentSession.status === 'failed' &&
          (session.status !== 'failed' ||
            event.data.agentSession.updatedAt !== completedAt ||
            !isDeepStrictEqual(event.data.agentSession, AgentSessionSchema.parse(session)))) ||
        (event.data.agentSession.status === 'created' &&
          events.some(
            (closeout) =>
              (closeout.event === 'turn.completed' ||
                (closeout.data.type === 'agent-session-updated' &&
                  closeout.data.agentSession.status === 'failed')) &&
              event.sequence >= closeout.sequence
          ))
    ) ||
    (session.status === 'failed' &&
      (session.updatedAt !== completedAt || (turn.error && session.message !== turn.error.message)))
  )
    throw new Error('Never-submitted checkpoint has contradictory terminal publication.');
  return true;
}

/**
 * Omits only the Store-admitted display refresh fields of the conversation's existing result Item.
 *
 * @param turn Published or current Turn whose ordered decided Item content must remain intact.
 * @returns Turn content with only result status level, title and summary omitted for comparison.
 */
function withoutConversationStatusDisplayFields(turn: ReturnType<FsStore['getTurnById']>) {
  return {
    ...turn,
    items: turn.items.map((item) =>
      item.id === deriveEntityId('it', ['worker-result', turn.id]) && item.type === 'status'
        ? Object.fromEntries(
            Object.entries(item).filter(
              ([field]) => !DISPLAY_PROJECTION_REFRESH_FIELDS.some((allowed) => allowed === field)
            )
          )
        : item
    ),
  };
}

/**
 * Derives one checkpoint outcome from the exact released attempt and canonical product owner tuple.
 *
 * @param coreDb Open Core database containing exact scheduler execution authority.
 * @param store Product store containing the Turn and AgentSession owners.
 * @param workspaceDb Open workspace database containing the package and checkpoint owners.
 * @param checkpoint Exact request-bound worker checkpoint.
 * @returns Canonical stop reason accepted for the original worker lineage.
 * @throws Error when any durable owner is absent or contradictory.
 */
export function recoverWorkerCheckpointStopReason(
  coreDb: CoreDb,
  store: FsStore,
  workspaceDb: WorkspaceDb,
  checkpoint: WorkerCheckpointRecord
): StopReason {
  let turn: ReturnType<FsStore['getTurnById']>;
  try {
    turn = store.getTurn(checkpoint.workspaceId, checkpoint.threadId, checkpoint.turnId);
  } catch {
    throw new Error('Worker checkpoint is missing its Turn owner.');
  }
  if (!checkpoint.workerSessionId || turn.agentSessionId !== checkpoint.workerSessionId) {
    throw new Error('Worker checkpoint has no exact AgentSession owner.');
  }

  let agentSession: ReturnType<FsStore['getAgentSession']>;
  try {
    agentSession = store.getAgentSession(checkpoint.workerSessionId);
  } catch {
    throw new Error('Worker checkpoint is missing its AgentSession.');
  }
  if (
    agentSession.workspaceId !== checkpoint.workspaceId ||
    agentSession.threadId !== checkpoint.threadId ||
    turn.agentId !== agentSession.agentId
  ) {
    throw new Error('Worker AgentSession contradicts its checkpoint lineage.');
  }

  const attempts = listSchedulerExecutionAttemptsForTurn(coreDb, {
    workspaceId: checkpoint.workspaceId,
    threadId: checkpoint.threadId,
    turnId: checkpoint.turnId,
  }).filter((attempt) => !isSchedulerExecutionBusyRefusal(attempt));
  const attempt = attempts[0];
  if (attempts.length !== 1 || !attempt || attempt.agentSessionId !== checkpoint.workerSessionId) {
    throw new Error('Worker checkpoint has no exact execution attempt.');
  }
  const admission = requireSchedulerExecutionAttemptAdmissionContext(coreDb, attempt.attemptId);
  if (admission.requestId !== checkpoint.requestId) {
    throw new Error('Worker scheduler admission contradicts its command owner.');
  }

  let stopReason = checkpoint.stopReason;
  if (stopReason && checkpoint.stage !== workerTurnStageForStopReason(stopReason)) {
    throw new Error('Worker checkpoint contradicts its recorded StopReason.');
  }
  if (attempt.inputRef || agentSession.environmentPackageSnapshotId) {
    if (!attempt.inputRef) {
      throw new Error('Worker environment package contradicts its checkpoint lineage.');
    }
    let environmentPackage: ReturnType<typeof requireAgentEnvironmentPackageSnapshot>['snapshot'];
    try {
      // Sequential Turns can advance the AgentSession pointer. The exact attempt owns
      // this checkpoint's immutable package; the current pointer cannot replace it.
      const record = findNamedAgentEnvironmentPackageSnapshot(
        workspaceDb,
        checkpoint.workspaceId,
        checkpoint.workerSessionId,
        attempt.inputRef
      );
      if (!record) throw new Error('Missing original worker environment package.');
      environmentPackage = record.snapshot;
    } catch {
      throw new Error('Worker checkpoint is missing its environment package.');
    }
    if (
      !isDeepStrictEqual(environmentPackage.scope.triggerActor, admission.triggerActor) ||
      environmentPackage.scope.workspaceId !== checkpoint.workspaceId ||
      environmentPackage.scope.threadId !== checkpoint.threadId ||
      environmentPackage.scope.turnId !== checkpoint.turnId ||
      environmentPackage.scope.agentSessionId !== checkpoint.workerSessionId ||
      environmentPackage.scope.requestId !== checkpoint.requestId ||
      attempt.inputRef !== environmentPackage.snapshotId
    ) {
      throw new Error('Worker environment package contradicts its checkpoint lineage.');
    }
    // Native final-status verification and every release barrier belong behind the adapter.
    // A closed attempt with its exact retained fence proves those owners settled, while the
    // product terminal event supplies the canonical StopReason without parsing Native proof.
    if (
      (attempt.phase !== 'closed' || !attempt.fenceRef || !attempt.operationId) &&
      !hasWorkerCheckpointNeverSubmittedProof(coreDb, store, workspaceDb, checkpoint)
    )
      throw new Error('Worker checkpoint has no complete execution closeout.');
  } else if (
    !stopReason ||
    checkpoint.stage === 'preparing' ||
    checkpoint.stage === 'running_worker' ||
    attempt.phase !== 'closed' ||
    attempt.disposition !== 'not_accepted' ||
    attempt.operationId !== null ||
    attempt.inputRef !== null
  ) {
    throw new Error('Pre-effect worker checkpoint has no definite terminal closeout.');
  }
  const events = store.getTurnEvents(checkpoint.turnId);
  const terminalEvents = events.filter(
    (event) => event.event === 'turn.completed' && event.data.type === 'turn-completed'
  );
  const terminalEvent = terminalEvents[0];
  if (terminalEvents.length !== 1 || terminalEvent?.data.type !== 'turn-completed')
    throw new Error('Worker checkpoint has no exact product terminal event.');
  const productStopReason = terminalEvent.data.stopReason;
  if (stopReason && stopReason !== productStopReason)
    throw new Error('Worker checkpoint contradicts its product terminal event.');
  stopReason = productStopReason;
  if (
    terminalEvent.workspaceId !== checkpoint.workspaceId ||
    terminalEvent.threadId !== checkpoint.threadId ||
    terminalEvent.turnId !== checkpoint.turnId ||
    terminalEvent.data.turn.id !== checkpoint.turnId ||
    terminalEvent.data.turn.workspaceId !== checkpoint.workspaceId ||
    terminalEvent.data.turn.threadId !== checkpoint.threadId ||
    terminalEvent.data.turn.agentId !== turn.agentId ||
    !isDeepStrictEqual(terminalEvent.data.turn.triggerActor, turn.triggerActor)
  ) {
    throw new Error('Worker product terminal event contradicts its checkpoint lineage.');
  }

  if (!stopReason) {
    throw new Error('Worker checkpoint has no canonical StopReason.');
  }

  const closedApprovalGate = classifyClosedWorkerApprovalGate(store, turn);
  // An exact Approval Gate closure belongs to its response command; ordinary closeout
  // belongs to the initiating checkpoint/admission command, even when App ids need projection.
  const publicationRequestId = projectTurnEventRequestId(
    closedApprovalGate?.responseRequestId ?? checkpoint.requestId,
    checkpoint.workspaceId,
    checkpoint.threadId
  );
  if (terminalEvent.requestId !== publicationRequestId) {
    throw new Error('Worker product terminal event contradicts its command owner.');
  }
  const expectedTurnStatus = closedApprovalGate
    ? closedApprovalGate.stopReason === 'aborted'
      ? 'interrupted'
      : 'completed'
    : turnStatusForCanonicalWorkerStopReason(stopReason);

  let expectedAgentSessionStatus =
    closedApprovalGate?.stopReason === 'completed'
      ? 'closed'
      : expectedTurnStatus === 'completed'
        ? 'idle'
        : expectedTurnStatus === 'interrupted'
          ? 'interrupted'
          : 'failed';
  // Live closeout publishes idle when it retains a reusable binding.
  // That publication outlives the backend binding and proves the historical retention decision.
  const sessionPublications = events.filter(
    (event) =>
      event.event === 'agent.session.updated' && event.data.type === 'agent-session-updated'
  );
  const sessionEvents = sessionPublications.filter(
    (event) =>
      event.data.type === 'agent-session-updated' &&
      ['idle', 'closed', 'failed', 'interrupted'].includes(event.data.agentSession.status)
  );
  // Execution observations must precede both the first closeout publication and turn.completed.
  // A later nonterminal publication for this Turn contradicts ordinary and repaired closeout alike.
  const closeoutSequence = Math.min(
    sessionEvents[0]?.sequence ?? terminalEvent.sequence,
    terminalEvent.sequence
  );
  if (
    sessionPublications.some(
      (event) => event.sequence >= closeoutSequence && !sessionEvents.includes(event)
    )
  ) {
    throw new Error('Worker AgentSession publication contradicts its checkpoint lineage.');
  }
  const sessionEvent = sessionEvents.at(-1);
  if (sessionEvent) {
    if (
      sessionEvent.data.type !== 'agent-session-updated' ||
      sessionEvent.workspaceId !== checkpoint.workspaceId ||
      sessionEvent.threadId !== checkpoint.threadId ||
      sessionEvent.turnId !== checkpoint.turnId ||
      sessionEvent.requestId !== publicationRequestId ||
      sessionEvent.data.agentSession.id !== agentSession.id ||
      sessionEvent.data.agentSession.agentId !== agentSession.agentId ||
      sessionEvent.data.agentSession.createdAt !== agentSession.createdAt ||
      sessionEvent.data.agentSession.workspaceId !== checkpoint.workspaceId ||
      sessionEvent.data.agentSession.threadId !== checkpoint.threadId ||
      Date.parse(sessionEvent.data.agentSession.updatedAt) > Date.parse(sessionEvent.timestamp)
    ) {
      throw new Error('Worker AgentSession publication contradicts its checkpoint lineage.');
    }
    const publishedSession = sessionEvent.data.agentSession;
    // The terminalization owner can lose the Session event write yet publish turn.completed.
    // Its retry publishes the original completion snapshot without replacing the terminal event.
    // Prove that decided content, not how long the repair took; fresh post-terminal changes
    // and a second closeout publication cannot establish this missing-publication repair.
    const repairedPublication =
      !closedApprovalGate &&
      (stopReason === 'completed' || stopReason === 'error' || stopReason === 'aborted') &&
      sessionEvents.length === 1 &&
      sessionEvent.sequence > terminalEvent.sequence &&
      publishedSession.updatedAt === terminalEvent.data.turn.completedAt &&
      terminalEvent.data.turn.completedAt === turn.completedAt &&
      terminalEvent.data.turn.agentSessionId === agentSession.id &&
      isDeepStrictEqual(terminalEvent.data.turn.error, turn.error) &&
      isDeepStrictEqual(publishedSession.sandboxSummary, agentSession.sandboxSummary) &&
      publishedSession.message ===
        (publishedSession.status === 'idle' ? null : turn.error?.message);
    const precedingPublication =
      sessionEvent.sequence < terminalEvent.sequence &&
      Date.parse(sessionEvent.timestamp) <= Date.parse(terminalEvent.timestamp);
    if (!precedingPublication && !repairedPublication) {
      throw new Error('Worker AgentSession publication contradicts its checkpoint lineage.');
    }
    const retained =
      !closedApprovalGate && Boolean(attempt.inputRef) && publishedSession.status === 'idle';
    if (publishedSession.status !== expectedAgentSessionStatus && !retained) {
      throw new Error('Worker generic closeout contradicts its canonical StopReason.');
    }
    expectedAgentSessionStatus = publishedSession.status;
    // Idle reclamation may close the binding after this Turn finished.
    // Recovery preserves the later owner's write instead of reopening the AgentSession.
    const closedLater =
      publishedSession.status === 'idle' &&
      agentSession.status === 'closed' &&
      Date.parse(agentSession.updatedAt) > Date.parse(terminalEvent.timestamp);
    if (closedLater) expectedAgentSessionStatus = 'closed';
    else if (agentSession.updatedAt !== publishedSession.updatedAt) {
      throw new Error('Worker generic closeout contradicts its canonical StopReason.');
    }
  }
  if (
    turn.status !== expectedTurnStatus ||
    terminalEvent.data.turn.status !== expectedTurnStatus ||
    agentSession.status !== expectedAgentSessionStatus ||
    attempt.phase !== 'closed' ||
    terminalEvents.length !== 1 ||
    terminalEvents[0]?.data.type !== 'turn-completed' ||
    terminalEvents[0].data.stopReason !== stopReason
  ) {
    throw new Error('Worker generic closeout contradicts its canonical StopReason.');
  }
  return stopReason;
}

/**
 * Classifies one closed worker Approval Gate from its exact request, decision, and owners.
 *
 * @param store Product store containing the Turn, Items, Approval, and terminal event.
 * @param turn Terminal Turn whose prior Gate may have been closed.
 * @returns Exact Approval closure, or null when the owner tuple is absent or contradictory.
 */
export function classifyClosedWorkerApprovalGate(
  store: FsStore,
  turn: ReturnType<FsStore['getTurnById']>
): {
  readonly requestItemId: string;
  readonly responseRequestId: string;
  readonly responseItemId: string;
  readonly stopReason: Extract<StopReason, 'aborted' | 'completed'>;
} | null {
  if (turn.status !== 'completed' && turn.status !== 'interrupted') {
    return null;
  }

  const candidates: Array<{
    readonly requestItemId: string;
    readonly responseRequestId: string;
    readonly responseItemId: string;
    readonly stopReason: Extract<StopReason, 'aborted' | 'completed'>;
  }> = [];
  for (const response of turn.items) {
    if (response.status !== 'completed') {
      continue;
    }
    if (response.type !== 'approval-decision') {
      continue;
    }
    if (response.actor.kind === 'system' && response.actor.id === 'nanocore-repo-push-policy') {
      continue;
    }
    const requests = turn.items.filter(
      (item) =>
        item.type === 'approval-request' &&
        item.status === 'completed' &&
        item.approvalRequestId === response.approvalRequestId
    );
    if (requests.length !== 1 || !requests[0]) {
      continue;
    }
    try {
      const approval = store.getApproval(response.approvalRequestId);
      if (
        approval.workspaceId !== turn.workspaceId ||
        approval.threadId !== turn.threadId ||
        approval.turnId !== turn.id ||
        approval.status !== response.decision ||
        approval.resolvedAt === null
      ) {
        continue;
      }
    } catch {
      continue;
    }
    candidates.push({
      requestItemId: requests[0].id,
      responseRequestId: response.causationId,
      responseItemId: response.id,
      stopReason: response.decision === 'denied' ? 'aborted' : 'completed',
    });
  }

  const closure = candidates[0];
  if (candidates.length !== 1 || !closure) {
    return null;
  }
  const terminalEvents = store
    .getTurnEvents(turn.id)
    .filter((event) => event.event === 'turn.completed' && event.data.type === 'turn-completed');
  const terminalEvent = terminalEvents[0];
  const expectedTurnStatus = closure.stopReason === 'aborted' ? 'interrupted' : 'completed';
  if (
    turn.status !== expectedTurnStatus ||
    terminalEvents.length !== 1 ||
    terminalEvent?.data.type !== 'turn-completed' ||
    terminalEvent.data.stopReason !== closure.stopReason ||
    !terminalEvent.requestId ||
    closure.responseRequestId !== terminalEvent.requestId
  ) {
    return null;
  }
  return closure;
}

/**
 * Classifies one closed worker user-input Gate from its exact request and response Items.
 *
 * @param store Product store containing the Turn and terminal event.
 * @param turn Terminal Turn whose prior Gate may have been closed.
 * @returns Exact user-input closure, or null when the Item tuple is absent or contradictory.
 */
export function classifyClosedWorkerUserInputGate(
  store: FsStore,
  turn: ReturnType<FsStore['getTurnById']>
): {
  readonly requestItemId: string;
  readonly responseRequestId: string;
  readonly responseItemId: string;
  readonly stopReason: Extract<StopReason, 'completed'>;
} | null {
  if (turn.status !== 'completed') {
    return null;
  }
  const candidates: Array<{
    readonly requestItemId: string;
    readonly responseItemId: string;
    readonly stopReason: Extract<StopReason, 'completed'>;
  }> = [];
  for (const response of turn.items) {
    if (response.type !== 'user-input-response' || response.status !== 'completed') {
      continue;
    }
    const requests = turn.items.filter(
      (item) =>
        item.type === 'user-input-request' &&
        item.status === 'completed' &&
        item.userInputRequestId === response.userInputRequestId
    );
    const request = requests[0];
    if (
      requests.length !== 1 ||
      !request ||
      request.type !== 'user-input-request' ||
      JSON.stringify(Object.keys(response.answers).sort()) !==
        JSON.stringify(request.questions.map((question) => question.id).sort())
    ) {
      continue;
    }
    candidates.push({
      requestItemId: request.id,
      responseItemId: response.id,
      stopReason: 'completed',
    });
  }
  const closure = candidates[0];
  if (candidates.length !== 1 || !closure) {
    return null;
  }
  const terminalEvents = store
    .getTurnEvents(turn.id)
    .filter((event) => event.event === 'turn.completed' && event.data.type === 'turn-completed');
  const terminalEvent = terminalEvents[0];
  if (
    terminalEvents.length !== 1 ||
    terminalEvent?.data.type !== 'turn-completed' ||
    terminalEvent.data.stopReason !== 'completed' ||
    !terminalEvent.requestId
  ) {
    return null;
  }
  return { ...closure, responseRequestId: terminalEvent.requestId };
}

/** The human Gate is gone. Retained callers observe no active Gate. */
export function hasExactActiveHumanGate(
  _store: FsStore,
  _turn: ReturnType<FsStore['getTurnById']>
): boolean {
  return false;
}

/**
 * Materializes only checkpoints whose existing owners prove an interrupted worker closeout.
 *
 * @param coreDb Open Core database handle containing scheduler authority.
 * @param store App-local product Turn and AgentSession store.
 * @param workspaceDb Open workspace-scope database handle.
 * @param isCandidate Audience admission required before dependent checkpoint reads.
 * @returns Interrupted worker state rows for visible restart recovery.
 */
export function materializeInterruptedWorkerStates(
  coreDb: CoreDb,
  store: FsStore,
  workspaceDb: WorkspaceDb,
  isCandidate: (checkpoint: WorkerCheckpointRecord) => boolean
): InterruptedWorkerStateRecord[] {
  const materializedAt = new Date().toISOString();

  return listRecoverableWorkerCheckpoints(workspaceDb).flatMap((checkpoint) => {
    if (!isCandidate(checkpoint)) {
      return [];
    }
    const decision = resolveInterruptedWorkerRetryDecision(coreDb, store, workspaceDb, {
      workspaceId: checkpoint.workspaceId,
      threadId: checkpoint.threadId,
      turnId: checkpoint.turnId,
    });

    return decision.status === 'eligible' || decision.status === 'inspect-only'
      ? [createInterruptedWorkerState(checkpoint, materializedAt, decision.status === 'eligible')]
      : [];
  });
}

/**
 * Derives retry authority from the exact checkpoint, product, and scheduler owners.
 *
 * @param coreDb Open Core database handle containing scheduler authority.
 * @param store App-local product Turn and AgentSession store.
 * @param workspaceDb Open workspace-scope database handle.
 * @param input Exact Workspace, Thread, and Turn lineage.
 * @returns One non-durable retry authority decision and its source checkpoint when present.
 */
export function resolveInterruptedWorkerRetryDecision(
  coreDb: CoreDb,
  store: FsStore,
  workspaceDb: WorkspaceDb,
  input: { readonly workspaceId: string; readonly threadId: string; readonly turnId: string }
): InterruptedWorkerRetryDecision {
  const checkpoint = getWorkerCheckpoint(
    workspaceDb,
    input.workspaceId,
    input.threadId,
    input.turnId
  );
  if (!checkpoint) {
    return { status: 'recovery-required', checkpoint: null };
  }

  let turn: ReturnType<FsStore['getTurn']>;
  try {
    turn = store.getTurn(input.workspaceId, input.threadId, input.turnId);
  } catch {
    return { status: 'recovery-required', checkpoint };
  }

  const agentSessionId = checkpoint.workerSessionId;
  if (!agentSessionId || turn.agentSessionId !== agentSessionId) {
    return { status: 'recovery-required', checkpoint };
  }

  let agentSession: ReturnType<FsStore['getAgentSession']>;
  try {
    agentSession = store.getAgentSession(agentSessionId);
  } catch {
    return { status: 'recovery-required', checkpoint };
  }
  if (agentSession.workspaceId !== input.workspaceId || agentSession.threadId !== input.threadId) {
    return { status: 'recovery-required', checkpoint };
  }

  const attempts = listSchedulerExecutionAttemptsForTurn(coreDb, input).filter(
    (attempt) => !isSchedulerExecutionBusyRefusal(attempt)
  );
  if (attempts.length !== 1 || attempts[0]?.agentSessionId !== agentSessionId) {
    return { status: 'recovery-required', checkpoint };
  }
  const attempt = attempts[0];

  if (attempt.phase === 'open') {
    return { status: 'reconnect-pending', checkpoint };
  }
  if (attempt.phase === 'closing') {
    return { status: 'stale', checkpoint };
  }

  if (
    (checkpoint.stage !== 'preparing' && checkpoint.stage !== 'running_worker') ||
    checkpoint.stopReason !== null ||
    turn.status !== 'interrupted' ||
    agentSession.status !== 'interrupted' ||
    attempt.phase !== 'closed'
  ) {
    return { status: 'recovery-required', checkpoint };
  }

  return checkpoint.goalId === null && checkpoint.taskId === null
    ? { status: 'eligible', checkpoint }
    : { status: 'inspect-only', checkpoint };
}

/**
 * Clears one checkpoint after its terminal worker state has been durably saved.
 *
 * @param workspaceDb Open workspace-scope database handle.
 * @param input Cleanup input identifying the stored checkpoint.
 * @returns True when a checkpoint row was deleted.
 * @throws OperationError when required retained provenance is missing or fails the existing bounded verification; other cleanup failures remain unclassified.
 */
export async function clearWorkerCheckpointAfterTerminalState(
  workspaceDb: WorkspaceDb,
  input: ClearWorkerCheckpointAfterTerminalStateInput
): Promise<boolean> {
  const checkpoint = getWorkerCheckpoint(
    workspaceDb,
    input.workspaceId,
    input.threadId,
    input.turnId
  );
  if (!checkpoint || !isTerminalWorkerTurnStage(checkpoint.stage)) {
    return false;
  }
  const environmentPackage = listExportableAgentEnvironmentPackageSnapshots(
    workspaceDb,
    input.workspaceId
  ).find(
    (record) =>
      record.turnId === input.turnId &&
      (!checkpoint.workerSessionId || record.agentSessionId === checkpoint.workerSessionId)
  )?.snapshot;
  if (
    !input.skipRuntimeProvenance &&
    environmentPackage?.control.transcript?.runtimeProvenance &&
    !(
      input.coreDb &&
      input.store &&
      hasWorkerCheckpointNeverSubmittedProof(input.coreDb, input.store, workspaceDb, checkpoint)
    )
  ) {
    const rawBundle = workspaceDb.sqlite
      .prepare(
        `SELECT evidence_bundle_id, backend_type, created_at
        FROM evidence_bundles
        WHERE workspace_id = ?
          AND thread_id = ?
          AND turn_id = ?
          AND agent_session_id = ?
          AND source_kind = 'worker-runtime-provenance-raw'
        LIMIT 1`
      )
      .get(
        input.workspaceId,
        input.threadId,
        input.turnId,
        environmentPackage.scope.agentSessionId
      ) as
      | { evidence_bundle_id: string; backend_type: string | null; created_at: string }
      | undefined;
    if (!rawBundle) {
      throw new OperationError(
        'recovery_retry_failed',
        'Required retained runtime provenance is missing.',
        400
      );
    }
    const runtime = workspaceDb.sqlite
      .prepare(
        `SELECT backend_version, placement
        FROM runtime_evidence
        WHERE workspace_id = ?
          AND turn_id = ?
          AND agent_session_id = ?
          AND phase = 'transcript-collection'
        LIMIT 1`
      )
      .get(input.workspaceId, input.turnId, environmentPackage.scope.agentSessionId) as
      | { backend_version: string | null; placement: 'local' | 'remote' | 'unknown' }
      | undefined;
    const workspaceRoot = join(workspaceDb.dataRoot, 'workspaces', workspaceDb.workspaceId);
    const rawRoot = join(workspaceRoot, 'evidence', 'backend', rawBundle.evidence_bundle_id);
    const verified = await importWorkerRuntimeProvenance({
      backend: {
        kind: rawBundle.backend_type ?? environmentPackage.backend.preferred,
        placement: runtime?.placement ?? 'unknown',
        version: runtime?.backend_version ?? null,
      },
      capture: {
        nativeOriginIndexPath: join(rawRoot, 'native-origin-index.jsonl'),
        rawStreamsRoot: join(rawRoot, 'raw'),
        streamManifestPath: join(rawRoot, 'raw-streams.json'),
      },
      collectedAt: rawBundle.created_at,
      environmentPackage,
      workspaceDb,
      workspaceRoot,
    }).catch((cause) => {
      throw new OperationError(
        'recovery_retry_failed',
        'Required retained runtime provenance verification failed.',
        400,
        { cause }
      );
    });
    if (!verified.complete) {
      throw new OperationError(
        'recovery_retry_failed',
        'Required retained runtime provenance verification failed.',
        400
      );
    }
  }

  return clearWorkerCheckpoint(workspaceDb, input.workspaceId, input.threadId, input.turnId);
}

/**
 * Creates one interrupted worker state row from a source checkpoint.
 *
 * @param checkpoint Source pending worker checkpoint.
 * @param materializedAt ISO timestamp for recovery materialization.
 * @param retryAvailable Whether the exact Goal or Task continuation owner permits retry.
 * @returns Interrupted worker read-model row.
 */
function createInterruptedWorkerState(
  checkpoint: WorkerCheckpointRecord,
  materializedAt: string,
  retryAvailable: boolean
): InterruptedWorkerStateRecord {
  return {
    kind: 'interrupted_worker_state',
    checkpointId: checkpoint.checkpointId,
    workspaceId: checkpoint.workspaceId,
    threadId: checkpoint.threadId,
    turnId: checkpoint.turnId,
    goalId: checkpoint.goalId,
    taskId: checkpoint.taskId,
    stage: checkpoint.stage as RecoverableWorkerTurnStage,
    iteration: checkpoint.iteration,
    workerSessionId: checkpoint.workerSessionId,
    contextDigest: checkpoint.contextDigest,
    contextAssembly: parseWorkerCheckpointContextAssembly(checkpoint.diagnosticsSummary),
    stopReason: checkpoint.stopReason,
    diagnosticsSummary: checkpoint.diagnosticsSummary,
    replayInstruction: false,
    choices: createInterruptedWorkerRecoveryChoices(retryAvailable),
    materializedAt,
    sourceUpdatedAt: checkpoint.updatedAt,
  };
}

/**
 * Creates the V1 typed recovery choices for an interrupted worker checkpoint.
 *
 * @param retryAvailable Whether the existing business owner permits retry.
 * @returns Product-safe recovery choices.
 */
function createInterruptedWorkerRecoveryChoices(
  retryAvailable: boolean
): readonly InterruptedWorkerRecoveryChoice[] {
  const choices: InterruptedWorkerRecoveryChoice[] = [
    {
      kind: 'inspect',
      label: 'Inspect interrupted worker evidence',
      recommended: true,
    },
    {
      kind: 'request_human',
      label: 'Ask the user how to recover this worker turn',
    },
  ];

  if (retryAvailable) {
    choices.splice(1, 0, {
      kind: 'retry',
      label: 'Retry interrupted worker turn',
    });
  }

  return choices;
}
