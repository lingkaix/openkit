import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { ProductTurnSchema, SseEventEnvelopeSchema } from '@openkit/protocol';
import { describe, expect, it, vi } from 'vitest';
import { FsStore } from '../lib/store.js';
import { createDemoStore } from '../test-support/demo-store.js';
import { terminalizeGovernedWorkerTurn } from './worker-turn-failure.js';

/** Creates one persisted running turn and busy AgentSession. */
function createFixture() {
  const dataRoot = mkdtempSync(join(tmpdir(), 'openkit-worker-turn-failure-'));
  const store = createDemoStore({ dataRoot });
  const turn = store.createTurn(
    'ws_00000000-0000-7000-8000-000000000001',
    'th_00000000-0000-7000-8000-000000000001',
    'Run governed worker',
    { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
    null,
    {
      turnId: 'tu_00000000-0000-7cfa-813c-d5549b2b9ef9',
    }
  );
  store.createAgentSession({
    agentId: 'agent_codex_host',
    createdAt: turn.startedAt ?? '2026-07-15T00:00:00.000Z',
    id: 'as_00000000-0000-770e-a08d-6c9479c1d1f5',
    message: null,
    status: 'busy',
    threadId: turn.threadId,
    updatedAt: turn.startedAt ?? '2026-07-15T00:00:00.000Z',
    workspaceId: turn.workspaceId,
  });
  return { dataRoot, store, turn };
}

/** Runs the shared governed-worker failure projection. */
function projectFailure(store: FsStore) {
  return terminalizeGovernedWorkerTurn({
    agentSessionId: 'as_00000000-0000-770e-a08d-6c9479c1d1f5',
    completedAt: '2026-07-15T00:01:00.000Z',
    errorCode: 'worker_governance_restart_recovery',
    message: 'Worker execution stopped during NanoCore restart recovery.',
    outcome: 'failed',
    requestId: null,
    store,
    turnId: 'tu_00000000-0000-7cfa-813c-d5549b2b9ef9',
  });
}

/** Runs the shared governed-worker interruption projection. */
function projectInterruption(store: FsStore) {
  return terminalizeGovernedWorkerTurn({
    agentSessionId: 'as_00000000-0000-770e-a08d-6c9479c1d1f5',
    completedAt: '2026-07-15T00:01:00.000Z',
    errorCode: 'worker_governance_restart_recovery',
    message: 'Worker execution was interrupted during NanoCore restart recovery.',
    outcome: 'interrupted',
    requestId: null,
    store,
    turnId: 'tu_00000000-0000-7cfa-813c-d5549b2b9ef9',
  });
}

describe('governed worker turn failure projection', () => {
  it('repairs a decided delivery_unknown failure after a cold restart without changing its outcome', () => {
    const { dataRoot, store, turn } = createFixture();
    store.updateTurn(turn.id, {
      status: 'failed',
      completedAt: '2026-07-15T00:00:30.000Z',
      error: { code: 'delivery_unknown', message: 'Outcome delivery could not be proved.' },
    });
    const decided = store.getTurnById(turn.id);
    const restarted = new FsStore({ dataRoot });
    projectFailure(restarted);
    projectFailure(restarted);
    expect(restarted.getTurnById(turn.id)).toEqual(decided);
    expect(restarted.getAgentSession('as_00000000-0000-770e-a08d-6c9479c1d1f5')).toMatchObject({
      status: 'failed',
      message: decided.error!.message,
    });
    expect(
      restarted.getTurnEvents(turn.id).filter((event) => event.event === 'turn.completed')
    ).toHaveLength(1);
    expect(
      restarted.getTurnEvents(turn.id).filter((event) => event.event === 'agent.session.updated')
    ).toHaveLength(1);
  });

  it('retains the first normalized explanation in cold reads, lists and terminal events', () => {
    const { dataRoot, store, turn } = createFixture();
    const explanation = {
      code: 'git_fetch_http_refused',
      stage: 'workspace_materialization',
      operation: 'git.fetch',
      dependency: 'git_remote',
      producer: 'worker-shim',
      observedAt: '2026-09-22T00:00:00.000Z',
      basis: 'direct_observation',
      subprocess: 'exit',
      httpStatus: 403,
      enforcement: 'unavailable',
      evidence: { availability: 'partial', outputTruncated: false },
    } as const;
    terminalizeGovernedWorkerTurn({
      agentSessionId: 'as_00000000-0000-770e-a08d-6c9479c1d1f5',
      completedAt: '2026-09-22T00:00:01.000Z',
      errorCode: 'worker_governance_turn_failed',
      message: 'Repository HTTP refusal; attribution unavailable.',
      explanation,
      outcome: 'failed',
      requestId: null,
      store,
      turnId: turn.id,
    });
    const cold = new FsStore({ dataRoot });
    // Restart repair cannot replace the original diagnostic with a generic cleanup error.
    projectFailure(cold);
    expect(cold.getTurnById(turn.id).error?.explanation).toEqual(explanation);
    expect(
      ProductTurnSchema.parse(cold.listThreadTurns(turn.workspaceId, turn.threadId)[0]).error
        ?.explanation
    ).toEqual(explanation);
    const events = cold.getTurnEvents(turn.id).filter((event) => event.event === 'turn.completed');
    expect(events).toHaveLength(1);
    expect(SseEventEnvelopeSchema.parse(events[0])).toMatchObject({
      data: { turn: { error: { explanation } } },
    });
    expect(JSON.stringify({ turn: cold.getTurnById(turn.id), events })).not.toContain(
      'canary-secret'
    );
  });

  it('treats a missing pre-anchor turn as an idempotent no-op', () => {
    const store = createDemoStore();

    expect(projectFailure(store)).toEqual({ status: 'missing' });
  });

  it('fails an existing turn when its AgentSession was not durably created', () => {
    const store = createDemoStore();
    store.createTurn(
      'ws_00000000-0000-7000-8000-000000000001',
      'th_00000000-0000-7000-8000-000000000001',
      'Crash before session write',
      { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
      null,
      {
        turnId: 'tu_00000000-0000-7cfa-813c-d5549b2b9ef9',
      }
    );

    expect(projectFailure(store)).toMatchObject({ status: 'failed' });
    expect(store.getTurnById('tu_00000000-0000-7cfa-813c-d5549b2b9ef9')).toMatchObject({
      status: 'failed',
    });
    expect(
      store
        .getTurnEvents('tu_00000000-0000-7cfa-813c-d5549b2b9ef9')
        .filter(
          (event) =>
            event.event === 'turn.completed' &&
            event.data.type === 'turn-completed' &&
            event.data.stopReason === 'error'
        )
    ).toHaveLength(1);
  });

  it('interrupts an anchored turn and session exactly once after restart cleanup', () => {
    const { dataRoot, store } = createFixture();

    expect(projectInterruption(store)).toMatchObject({ status: 'interrupted' });
    expect(projectInterruption(new FsStore({ dataRoot }))).toMatchObject({
      status: 'interrupted',
    });

    const reloaded = new FsStore({ dataRoot });
    expect(reloaded.getTurnById('tu_00000000-0000-7cfa-813c-d5549b2b9ef9')).toMatchObject({
      error: {
        code: 'worker_governance_restart_recovery',
        message: 'Worker execution was interrupted during NanoCore restart recovery.',
      },
      status: 'interrupted',
    });
    expect(reloaded.getAgentSession('as_00000000-0000-770e-a08d-6c9479c1d1f5')).toMatchObject({
      message: 'Worker execution was interrupted during NanoCore restart recovery.',
      status: 'interrupted',
    });
    expect(
      reloaded
        .getTurnEvents('tu_00000000-0000-7cfa-813c-d5549b2b9ef9')
        .filter(
          (event) =>
            event.event === 'turn.completed' &&
            event.data.type === 'turn-completed' &&
            event.data.stopReason === 'aborted'
        )
    ).toHaveLength(1);
  });

  it('fails closed when product-store reads fail for reasons other than not-found', () => {
    const { store } = createFixture();
    const turnRead = vi.spyOn(store, 'getTurnById').mockImplementation(() => {
      throw new Error('turn store is corrupt');
    });

    expect(() => projectFailure(store)).toThrow('turn store is corrupt');
    turnRead.mockRestore();

    const sessionRead = vi.spyOn(store, 'getAgentSession').mockImplementation(() => {
      throw new Error('AgentSession store is corrupt');
    });
    expect(() => projectFailure(store)).toThrow('AgentSession store is corrupt');
    sessionRead.mockRestore();
  });

  it('preserves a durable successful terminal event when the turn row is still running', () => {
    const { dataRoot, store, turn } = createFixture();
    const completed = {
      ...turn,
      completedAt: '2026-07-15T00:00:30.000Z',
      error: null,
      status: 'completed' as const,
    };
    store.emitTurnEvent(turn.id, {
      data: { stopReason: 'completed', turn: completed, type: 'turn-completed' },
      event: 'turn.completed',
      requestId: null,
      threadId: turn.threadId,
      turnId: turn.id,
      workspaceId: turn.workspaceId,
    });

    expect(projectFailure(store)).toMatchObject({ status: 'completed' });

    const reloaded = new FsStore({ dataRoot });
    expect(reloaded.getTurnById(turn.id)).toMatchObject({
      completedAt: '2026-07-15T00:00:30.000Z',
      error: null,
      status: 'completed',
    });
    expect(
      reloaded
        .getTurnEvents(turn.id)
        .filter(
          (event) =>
            event.event === 'turn.completed' &&
            event.data.type === 'turn-completed' &&
            event.data.stopReason === 'error'
        )
    ).toEqual([]);
  });

  it('fails a running turn and session exactly once across store reloads', () => {
    const { dataRoot, store } = createFixture();

    expect(projectFailure(store)).toMatchObject({ status: 'failed' });
    expect(projectFailure(new FsStore({ dataRoot }))).toMatchObject({ status: 'failed' });

    const reloaded = new FsStore({ dataRoot });
    expect(reloaded.getTurnById('tu_00000000-0000-7cfa-813c-d5549b2b9ef9')).toMatchObject({
      error: {
        code: 'worker_governance_restart_recovery',
        message: 'Worker execution stopped during NanoCore restart recovery.',
      },
      status: 'failed',
    });
    expect(reloaded.getAgentSession('as_00000000-0000-770e-a08d-6c9479c1d1f5')).toMatchObject({
      message: 'Worker execution stopped during NanoCore restart recovery.',
      status: 'failed',
    });
    expect(
      reloaded
        .getTurnEvents('tu_00000000-0000-7cfa-813c-d5549b2b9ef9')
        .filter(
          (event) =>
            event.event === 'turn.completed' &&
            event.data.type === 'turn-completed' &&
            event.data.stopReason === 'error'
        )
    ).toHaveLength(1);
  });

  it('preserves a completed turn and does not fail its session', () => {
    const { dataRoot, store } = createFixture();
    const completed = store.updateTurn('tu_00000000-0000-7cfa-813c-d5549b2b9ef9', {
      completedAt: '2026-07-15T00:00:30.000Z',
      error: null,
      status: 'completed',
    });
    store.updateAgentSession('as_00000000-0000-770e-a08d-6c9479c1d1f5', {
      message: null,
      status: 'idle',
      updatedAt: '2026-07-15T00:00:30.000Z',
    });
    store.emitTurnEvent(completed.id, {
      data: { stopReason: 'completed', turn: completed, type: 'turn-completed' },
      event: 'turn.completed',
      requestId: null,
      threadId: completed.threadId,
      turnId: completed.id,
      workspaceId: completed.workspaceId,
    });

    expect(projectFailure(store)).toMatchObject({ status: 'completed' });

    const reloaded = new FsStore({ dataRoot });
    expect(reloaded.getTurnById('tu_00000000-0000-7cfa-813c-d5549b2b9ef9')).toMatchObject({
      error: null,
      status: 'completed',
    });
    expect(reloaded.getAgentSession('as_00000000-0000-770e-a08d-6c9479c1d1f5')).toMatchObject({
      message: null,
      status: 'idle',
    });
    expect(
      reloaded
        .getTurnEvents('tu_00000000-0000-7cfa-813c-d5549b2b9ef9')
        .filter(
          (event) =>
            event.event === 'turn.completed' &&
            event.data.type === 'turn-completed' &&
            event.data.stopReason === 'error'
        )
    ).toEqual([]);
  });

  it('repairs missing success events for an already completed turn exactly once', () => {
    const { dataRoot, store } = createFixture();
    store.updateAgentSession('as_00000000-0000-770e-a08d-6c9479c1d1f5', {
      message: null,
      status: 'idle',
      updatedAt: '2026-07-15T00:00:30.000Z',
    });
    store.updateTurn('tu_00000000-0000-7cfa-813c-d5549b2b9ef9', {
      completedAt: '2026-07-15T00:00:30.000Z',
      error: null,
      status: 'completed',
    });

    expect(projectFailure(store)).toMatchObject({ status: 'completed' });
    expect(projectFailure(new FsStore({ dataRoot }))).toMatchObject({ status: 'completed' });

    const events = new FsStore({ dataRoot }).getTurnEvents(
      'tu_00000000-0000-7cfa-813c-d5549b2b9ef9'
    );
    expect(
      events.filter(
        (event) =>
          event.event === 'agent.session.updated' &&
          event.data.type === 'agent-session-updated' &&
          event.data.agentSession.status === 'idle'
      )
    ).toHaveLength(1);
    expect(
      events.filter(
        (event) =>
          event.event === 'turn.completed' &&
          event.data.type === 'turn-completed' &&
          event.data.stopReason === 'completed'
      )
    ).toHaveLength(1);
    expect(
      events.filter(
        (event) =>
          event.event === 'turn.completed' &&
          event.data.type === 'turn-completed' &&
          event.data.stopReason === 'error'
      )
    ).toEqual([]);
  });

  it.each([
    'completed',
    'interrupted',
    'cancelled',
    'failed',
  ] as const)('preserves an authoritative %s turn instead of replacing its outcome', (status) => {
    const { dataRoot, store } = createFixture();
    const originalError =
      status === 'failed'
        ? { code: 'original_product_failure', message: 'Preserve the original failure.' }
        : null;

    store.updateTurn('tu_00000000-0000-7cfa-813c-d5549b2b9ef9', {
      completedAt: '2026-07-15T00:00:30.000Z',
      error: originalError,
      status,
    });
    store.updateAgentSession('as_00000000-0000-770e-a08d-6c9479c1d1f5', {
      message: 'Authoritative terminal session state.',
      status: 'idle',
      updatedAt: '2026-07-15T00:00:30.000Z',
    });

    expect(projectFailure(store)).toMatchObject({ status });

    const reloaded = new FsStore({ dataRoot });
    expect(reloaded.getTurnById('tu_00000000-0000-7cfa-813c-d5549b2b9ef9')).toMatchObject({
      error: originalError,
      status,
    });
    expect(reloaded.getAgentSession('as_00000000-0000-770e-a08d-6c9479c1d1f5')).toMatchObject({
      message: 'Authoritative terminal session state.',
      status: 'idle',
    });
    expect(
      reloaded
        .getTurnEvents('tu_00000000-0000-7cfa-813c-d5549b2b9ef9')
        .filter(
          (event) =>
            event.event === 'turn.completed' &&
            event.data.type === 'turn-completed' &&
            event.data.stopReason === 'error'
        )
    ).toEqual([]);
  });

  it('repairs session and terminal-event projections after the failed turn write persisted', () => {
    const { dataRoot, store } = createFixture();
    const sessionWrite = vi.spyOn(store, 'updateAgentSession').mockImplementation(() => {
      throw new Error('AgentSession store unavailable');
    });

    expect(() => projectFailure(store)).toThrow(AggregateError);
    sessionWrite.mockRestore();
    expect(
      new FsStore({ dataRoot }).getTurnById('tu_00000000-0000-7cfa-813c-d5549b2b9ef9')
    ).toMatchObject({
      error: { code: 'worker_governance_restart_recovery' },
      status: 'failed',
    });

    expect(projectFailure(new FsStore({ dataRoot }))).toMatchObject({ status: 'failed' });

    const reloaded = new FsStore({ dataRoot });
    expect(reloaded.getAgentSession('as_00000000-0000-770e-a08d-6c9479c1d1f5')).toMatchObject({
      message: 'Worker execution stopped during NanoCore restart recovery.',
      status: 'failed',
    });
    expect(
      reloaded
        .getTurnEvents('tu_00000000-0000-7cfa-813c-d5549b2b9ef9')
        .filter(
          (event) =>
            event.event === 'turn.completed' &&
            event.data.type === 'turn-completed' &&
            event.data.stopReason === 'error'
        )
    ).toHaveLength(1);
  });

  it.each([
    'worker_governance_restart_recovery',
    'unsupported_gateway_feature',
  ])('repairs a missing terminal event after a cold retry of %s without replacing its diagnostic', (errorCode) => {
    const { dataRoot, store } = createFixture();
    const originalError = {
      code: errorCode,
      message:
        errorCode === 'unsupported_gateway_feature'
          ? 'The Gateway cannot preserve the requested features for the selected model route. Choose a compatible model route and start a new Task.'
          : 'Worker execution stopped during NanoCore restart recovery.',
    };
    const completedAt = '2026-07-15T00:00:45.000Z';
    const emitTurnEvent = store.emitTurnEvent.bind(store);
    const terminalEventWrite = vi
      .spyOn(store, 'emitTurnEvent')
      .mockImplementation((turnId, event) => {
        if (event.event === 'turn.completed') {
          throw new Error('terminal event store unavailable');
        }
        return emitTurnEvent(turnId, event);
      });

    expect(() =>
      terminalizeGovernedWorkerTurn({
        agentSessionId: 'as_00000000-0000-770e-a08d-6c9479c1d1f5',
        completedAt,
        errorCode,
        message: originalError.message,
        outcome: 'failed',
        requestId: null,
        store,
        turnId: 'tu_00000000-0000-7cfa-813c-d5549b2b9ef9',
      })
    ).toThrow(AggregateError);
    terminalEventWrite.mockRestore();

    const partial = new FsStore({ dataRoot });
    expect(partial.getTurnById('tu_00000000-0000-7cfa-813c-d5549b2b9ef9')).toMatchObject({
      completedAt,
      error: originalError,
      status: 'failed',
    });
    expect(partial.getAgentSession('as_00000000-0000-770e-a08d-6c9479c1d1f5')).toMatchObject({
      status: 'failed',
    });
    expect(
      partial
        .getTurnEvents('tu_00000000-0000-7cfa-813c-d5549b2b9ef9')
        .filter((event) => event.event === 'turn.completed')
    ).toEqual([]);

    expect(projectFailure(partial)).toMatchObject({ status: 'failed' });
    const repaired = new FsStore({ dataRoot });
    expect(repaired.getTurnById('tu_00000000-0000-7cfa-813c-d5549b2b9ef9')).toMatchObject({
      completedAt,
      error: originalError,
      status: 'failed',
    });
    expect(repaired.getAgentSession('as_00000000-0000-770e-a08d-6c9479c1d1f5')).toMatchObject({
      message: originalError.message,
      status: 'failed',
    });
    const terminalEvents = repaired
      .getTurnEvents('tu_00000000-0000-7cfa-813c-d5549b2b9ef9')
      .filter((event) => event.event === 'turn.completed');
    expect(terminalEvents).toHaveLength(1);
    expect(SseEventEnvelopeSchema.parse(terminalEvents[0])).toMatchObject({
      data: {
        type: 'turn-completed',
        stopReason: 'error',
        turn: { completedAt, error: originalError, status: 'failed' },
      },
    });
    projectFailure(repaired);
    expect(
      new FsStore({ dataRoot })
        .getTurnEvents('tu_00000000-0000-7cfa-813c-d5549b2b9ef9')
        .filter((event) => event.event === 'turn.completed')
    ).toEqual(terminalEvents);
  });

  it('repairs a partial normal worker failure during restart without replacing its error', () => {
    const { dataRoot, store } = createFixture();
    store.updateTurn('tu_00000000-0000-7cfa-813c-d5549b2b9ef9', {
      completedAt: '2026-07-15T00:00:45.000Z',
      error: {
        code: 'worker_governance_turn_failed',
        message: 'The original worker execution failed.',
      },
      status: 'failed',
    });

    expect(projectFailure(store)).toMatchObject({
      error: {
        code: 'worker_governance_turn_failed',
        message: 'The original worker execution failed.',
      },
      status: 'failed',
    });

    const reloaded = new FsStore({ dataRoot });
    expect(reloaded.getAgentSession('as_00000000-0000-770e-a08d-6c9479c1d1f5')).toMatchObject({
      message: 'The original worker execution failed.',
      status: 'failed',
    });
    expect(
      reloaded
        .getTurnEvents('tu_00000000-0000-7cfa-813c-d5549b2b9ef9')
        .filter(
          (event) =>
            event.event === 'turn.completed' &&
            event.data.type === 'turn-completed' &&
            event.data.stopReason === 'error'
        )
    ).toHaveLength(1);
  });
});
