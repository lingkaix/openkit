import { existsSync, mkdirSync, mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, expect, it, vi } from 'vitest';
import { createRuntimeConfigManager } from './config/runtime-config.js';
import { SimulatedTurnExecutor } from './lib/simulator.js';
import { ProviderRegistry } from './providers/registry.js';
import {
  allocateNanoHostRuntimeTargetConnectionGeneration,
  upsertNanoHostRuntimeTarget,
} from './runtime/nanohost-runtime-target.js';
import { openCoreDb } from './storage/db.js';
import { readDataRootLayoutMarker } from './storage/fs-layout.js';
import { applyMigrations } from './storage/migrate.js';
import { createTestAgentSetup } from './test-support/agent-environment.js';
import { createAppWithWorkspaceAuthority as createApp } from './test-support/app.js';
import { createDemoStore } from './test-support/demo-store.js';
import { seedWritableGitRepository } from './test-support/git-repository.js';
import { ensureLocalUser } from './test-support/local-user.js';
import { operationRequest } from './test-support/operation-request.js';
import { recordWorkspaceOwnerMembership } from './workspace-membership.js';

/**
 * Creates a temporary NanoCore data root with one runtime config.
 *
 * @param model Provider model id.
 * @returns Temporary data root path.
 */
function createConfiguredDataRoot(model: string): string {
  const dataRoot = mkdtempSync(join(tmpdir(), 'openkit-runtime-reload-api-'));

  writeServerConfig(dataRoot, model);

  return dataRoot;
}

/**
 * Writes the canonical server config used by reload API tests.
 *
 * @param dataRoot Data root that owns the config file.
 * @param model Provider model id.
 */
function writeServerConfig(dataRoot: string, model: string): void {
  mkdirSync(join(dataRoot, 'config'), { recursive: true });
  writeFileSync(
    join(dataRoot, 'config', 'server.jsonc'),
    `{
      "schemaVersion": 1,
      "defaults": {
        "defaultAgentId": "agent_codex_host"
      }
    }`
  );
  const providersRoot = join(dataRoot, 'config', 'providers');
  mkdirSync(providersRoot, { recursive: true });
  writeFileSync(
    join(providersRoot, 'agent-openrouter.provider.jsonc'),
    JSON.stringify({
      id: 'agent-openrouter',
      vendor: 'openrouter',
      kind: 'gateway',
      displayName: `Agent OpenRouter ${model}`,
      models: ['openai/gpt-5.1'],
    })
  );
  const gatewayPath = join(dataRoot, 'config', 'gateway.jsonc');
  if (!existsSync(gatewayPath))
    writeFileSync(
      gatewayPath,
      JSON.stringify({
        schemaVersion: 1,
        enabled: true,
        defaultLogicalModelId: 'reasoning',
        logicalModels: [
          {
            id: 'reasoning',
            displayName: 'Reasoning',
            contextManagement: [{ type: 'compaction', compactThreshold: 8_000 }],
            routes: [
              { id: 'primary', providerProfileId: 'agent-openrouter', providerModel: model },
            ],
          },
        ],
        requiredFeatures: [],
      })
    );
}

describe('runtime config reload API', () => {
  it('hydrates the joined Workspace name after an accepted config reload', async () => {
    const dataRoot = createConfiguredDataRoot('openai/gpt-5.1');
    const store = createDemoStore({ dataRoot });
    const workspaceConfigPath = join(
      dataRoot,
      'workspaces',
      'ws_00000000-0000-7000-8000-000000000001',
      'config',
      'workspace.jsonc'
    );
    const app = createApp({ dataRoot, store, turnExecutor: new SimulatedTurnExecutor() });

    writeFileSync(
      workspaceConfigPath,
      JSON.stringify({
        schemaVersion: 1,
        workspace: { name: 'Reloaded Workspace', defaultAgentId: null },
      })
    );
    const response = await app.request(
      ...operationRequest(
        'runtime.reload',
        {},
        {
          method: 'POST',
          body: JSON.stringify({ mode: 'safe' }),
          headers: { 'content-type': 'application/json' },
        }
      )
    );

    expect(response.status).toBe(200);
    expect(store.getWorkspace('ws_00000000-0000-7000-8000-000000000001').name).toBe(
      'Reloaded Workspace'
    );
  });

  it('keeps provider changes pending restart and exposes the live runtime status', async () => {
    const dataRoot = createConfiguredDataRoot('openai/gpt-5.1');
    const app = createApp({
      dataRoot,
      runtimeConfigManager: createRuntimeConfigManager({ dataRoot }),
      turnExecutor: new SimulatedTurnExecutor(),
    });

    writeServerConfig(dataRoot, 'openai/gpt-5.2');
    const reloadRes = await app.request(
      ...operationRequest(
        'runtime.reload',
        {},
        {
          method: 'POST',
          body: JSON.stringify({ mode: 'safe' }),
          headers: { 'content-type': 'application/json' },
        }
      )
    );

    expect(reloadRes.status).toBe(200);
    const reload = (await reloadRes.json()) as {
      runtimeConfig: { currentVersion: number; pendingRestart: Array<{ path: string }> };
      plan: { applied: Array<{ path: string }>; requiresRestart: Array<{ path: string }> };
    };

    expect(reload.runtimeConfig.currentVersion).toBe(2);
    expect(reload.plan.applied).toEqual([]);
    expect(reload.plan.requiresRestart).toEqual([expect.objectContaining({ path: 'providers' })]);
    expect(reload.runtimeConfig.pendingRestart).toEqual([
      expect.objectContaining({ path: 'providers' }),
    ]);

    const diagnosticsRes = await app.request(...operationRequest('diagnostics.app', {}));
    const diagnostics = (await diagnosticsRes.json()) as {
      runtimeConfig: { currentVersion: number };
      providers: { registry: Array<{ id: string; models: string[] }> };
    };

    expect(diagnostics.runtimeConfig.currentVersion).toBe(2);
    expect(diagnostics.providers.registry[0]?.models).toContain('openai/gpt-5.1');
  });

  it('keeps the active AgentSession across a restart-required provider reload', async () => {
    const dataRoot = createConfiguredDataRoot('openai/gpt-5.1');
    const coreDb = openCoreDb(dataRoot);
    applyMigrations(coreDb);
    ensureLocalUser(coreDb);
    const target = allocateNanoHostRuntimeTargetConnectionGeneration(coreDb, {
      deploymentId: readDataRootLayoutMarker(dataRoot).deploymentId,
      identityId: 'identity_reload_fixture',
      observedAt: new Date().toISOString(),
      targetId: 'target_reload_fixture',
    });
    upsertNanoHostRuntimeTarget(coreDb, {
      ...target,
      freshEmpty: true,
      observedAt: new Date().toISOString(),
      physicalEpoch: 'a'.repeat(64),
      predecessorFenced: true,
      ready: true,
    });
    recordWorkspaceOwnerMembership({
      coreDb,
      ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
      workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
    });
    const store = createDemoStore({ dataRoot });
    const agentSetup = createTestAgentSetup({
      logicalModelId: 'reasoning',
      privateRoute: {
        providerProfileId: 'agent-openrouter',
        providerModel: 'openai/gpt-5.1',
      },
    });
    const app = createApp({
      agentManifests: [agentSetup.manifest],
      coreDb,
      dataRoot,
      gatewayConfig: {
        schemaVersion: 1,
        enabled: true,
        defaultLogicalModelId: 'reasoning',
        logicalModels: [
          {
            id: 'reasoning',
            displayName: 'Reasoning',
            contextManagement: [{ type: 'compaction', compactThreshold: 8_000 }],
            routes: [
              {
                id: 'primary',
                providerProfileId: 'agent-openrouter',
                providerModel: 'openai/gpt-5.1',
              },
            ],
          },
        ],
        requiredFeatures: [],
      },
      providerRegistry: new ProviderRegistry([
        {
          defaultModel: 'openai/gpt-5.1',
          displayName: 'Agent OpenRouter',
          id: 'agent-openrouter',
          kind: 'gateway',
          models: ['openai/gpt-5.1'],
          vendor: 'openrouter',
          secretRef: 'env:OPENKIT_RELOAD_FIXTURE_KEY',
        },
      ]),
      // This lifecycle fixture needs configured non-Vault supply, without a Provider call.
      providerCredentialResolver: (secretRef) =>
        secretRef === 'env:OPENKIT_RELOAD_FIXTURE_KEY' ? 'test-only-reload-key' : null,
      store,
      turnExecutor: new SimulatedTurnExecutor({ coreDb }),
    });
    const repositoryPath = mkdtempSync(join(tmpdir(), 'openkit-runtime-reload-repository-'));

    try {
      seedWritableGitRepository(repositoryPath);

      const turnRes = await app.request(
        ...operationRequest(
          'turn.start',
          {},
          {
            method: 'POST',
            body: JSON.stringify({
              workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
              threadId: 'th_00000000-0000-7000-8000-000000000001',
              requestId: '0190f4c8-0000-7000-8000-000000000301',
              input: 'Run with version one',
            }),
            headers: { 'content-type': 'application/json' },
          }
        )
      );
      const turn = (await turnRes.json()) as { id: string; configVersion: number };

      expect(turnRes.status, JSON.stringify(turn)).toBe(202);
      expect(turn.configVersion, JSON.stringify(turn)).toBe(1);
      expect(turn).not.toHaveProperty('agentSessionId');
      await vi.waitFor(() => {
        expect(store.getTurnById(turn.id).status).toBe('completed');
        expect(
          coreDb.sqlite
            .prepare('SELECT phase FROM scheduler_execution_attempts WHERE turn_id = ?')
            .get(turn.id)
        ).toEqual({ phase: 'closed' });
      });
      const sessionsBeforeReload = store.listThreadAgentSessions(
        'ws_00000000-0000-7000-8000-000000000001',
        'th_00000000-0000-7000-8000-000000000001'
      );
      expect(sessionsBeforeReload).toEqual([
        expect.objectContaining({ configVersion: 1, stale: false, status: 'idle' }),
      ]);

      writeServerConfig(dataRoot, 'openai/gpt-5.2');
      const reloadRes = await app.request(
        ...operationRequest(
          'runtime.reload',
          {},
          {
            method: 'POST',
            body: JSON.stringify({ mode: 'safe' }),
            headers: { 'content-type': 'application/json' },
          }
        )
      );

      expect(reloadRes.status).toBe(200);
      const reload = (await reloadRes.json()) as {
        runtimeConfig: { pendingRestart: Array<{ path: string }> };
        plan: { requiresRestart: Array<{ path: string }> };
      };
      expect(reload.plan.requiresRestart).toContainEqual(
        expect.objectContaining({ path: 'providers' })
      );
      expect(reload.runtimeConfig.pendingRestart).toContainEqual(
        expect.objectContaining({ path: 'providers' })
      );

      const dashboardRes = await app.request('/api/app/operations/thread.dashboard', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          workspaceId: 'ws_00000000-0000-7000-8000-000000000001',
          threadId: 'th_00000000-0000-7000-8000-000000000001',
        }),
      });
      const dashboard = await dashboardRes.json();
      const sessionsAfterReload = store.listThreadAgentSessions(
        'ws_00000000-0000-7000-8000-000000000001',
        'th_00000000-0000-7000-8000-000000000001'
      );

      expect(dashboardRes.status, JSON.stringify(dashboard)).toBe(200);
      expect(JSON.stringify(dashboard)).not.toMatch(/agentSession/i);
      expect(sessionsAfterReload).toEqual(sessionsBeforeReload);
      expect(
        store
          .listThreadTurns(
            'ws_00000000-0000-7000-8000-000000000001',
            'th_00000000-0000-7000-8000-000000000001'
          )
          .some((item) => item.status === 'interrupted')
      ).toBe(false);
    } finally {
      coreDb.sqlite.close();
    }
  });
});

// This fixture supplies confirmed image evidence; the production resolver and subject checks still run.
vi.mock('./runtime/agent-environment.js', async (importOriginal) => {
  const actual = await importOriginal<typeof import('./runtime/agent-environment.js')>();
  const { withTestPreparedNativeEnvironment } = await import(
    './test-support/native-environment.js'
  );
  return withTestPreparedNativeEnvironment(actual);
});
