import { ApiCallError, type CoreClient } from '@openkit/core-client';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it, vi } from 'vitest';
import { CoreClientProvider } from '../../app/core-client';
import { AccessTokensScreen } from './AccessTokensScreen';

const TIMESTAMP = '2026-08-30T00:00:00.000Z';
const RAW_TOKEN = 'okt_issued_once_never_cached';
const RECORD = {
  tokenId: 'tok_00000000-0000-71d2-a336-a862021357ff',
  ownerUserId: 'usr_00000000-0000-7011-88df-c2b1e8466b6f',
  scope: 'server-admin' as const,
  workspaceIds: [],
  status: 'active' as const,
  issuedAt: TIMESTAMP,
  expiresAt: '2027-08-30T00:00:00.000Z',
  revokedAt: null,
  predecessorTokenId: null,
  rotatedGraceExpiresAt: null,
  lastUsedAt: null,
  lastUsedChannel: null,
  lastUsedSource: null,
};

function makeClient(app: Partial<CoreClient['operations']> = {}): CoreClient {
  return {
    operations: {
      'token.list': vi.fn().mockResolvedValue({ items: [RECORD] }),
      'token.create': vi.fn().mockResolvedValue({ token: RAW_TOKEN, record: RECORD }),
      'token.revoke': vi.fn().mockResolvedValue({ record: { ...RECORD, status: 'revoked' } }),
      'token.rotate': vi.fn().mockResolvedValue({
        token: RAW_TOKEN,
        record: { ...RECORD, tokenId: 'tok_00000000-0000-7c9e-a136-86e094ee0dc9' },
        rotatedRecord: { ...RECORD, status: 'rotated' },
      }),
      ...app,
    },
  } as unknown as CoreClient;
}

function renderScreen(client: CoreClient) {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  const rendered = render(
    <QueryClientProvider client={queryClient}>
      <CoreClientProvider client={client}>
        <AccessTokensScreen />
      </CoreClientProvider>
    </QueryClientProvider>
  );
  return { ...rendered, queryClient };
}

describe('Access tokens administration', () => {
  it('lists redacted tokens and issues one to an exact owner without caching the secret', async () => {
    const user = userEvent.setup();
    const client = makeClient();
    const { queryClient } = renderScreen(client);

    expect(await screen.findByText('tok_00000000-0000-71d2-a336-a862021357ff')).toBeInTheDocument();
    await user.type(
      screen.getByLabelText('Owner user id'),
      'usr_00000000-0000-7011-88df-c2b1e8466b6f'
    );
    await user.click(screen.getByRole('button', { name: 'Issue token' }));

    await waitFor(() =>
      expect(client.operations['token.create']).toHaveBeenCalledWith(
        expect.objectContaining({
          ownerUserId: 'usr_00000000-0000-7011-88df-c2b1e8466b6f',
          scope: 'server-admin',
        })
      )
    );
    expect(await screen.findByLabelText('Issued token')).toHaveValue(RAW_TOKEN);
    expect(
      JSON.stringify(
        queryClient
          .getQueryCache()
          .findAll()
          .map((query) => query.queryKey)
      )
    ).not.toContain(RAW_TOKEN);

    await user.click(screen.getByRole('button', { name: 'Dismiss' }));
    expect(screen.queryByLabelText('Issued token')).not.toBeInTheDocument();
    await waitFor(() =>
      expect(
        JSON.stringify(
          queryClient
            .getMutationCache()
            .getAll()
            .map((mutation) => mutation.state.data)
        )
      ).not.toContain(RAW_TOKEN)
    );
  });

  it('revokes and rotates listed tokens', async () => {
    const user = userEvent.setup();
    const client = makeClient();
    const { queryClient } = renderScreen(client);

    expect(await screen.findByText('tok_00000000-0000-71d2-a336-a862021357ff')).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'Revoke' }));
    await waitFor(() =>
      expect(client.operations['token.revoke']).toHaveBeenCalledWith({
        tokenId: 'tok_00000000-0000-71d2-a336-a862021357ff',
      })
    );

    await user.click(screen.getByRole('button', { name: 'Rotate' }));
    await waitFor(() =>
      expect(client.operations['token.rotate']).toHaveBeenCalledWith({
        tokenId: 'tok_00000000-0000-71d2-a336-a862021357ff',
      })
    );
    expect(await screen.findByLabelText('Issued token')).toHaveValue(RAW_TOKEN);

    await user.click(screen.getByRole('button', { name: 'Dismiss' }));
    expect(screen.queryByLabelText('Issued token')).not.toBeInTheDocument();
    await waitFor(() =>
      expect(
        JSON.stringify(
          queryClient
            .getMutationCache()
            .getAll()
            .map((mutation) => mutation.state.data)
        )
      ).not.toContain(RAW_TOKEN)
    );
  });

  it('shows access denied with retry and never asks for a credential', async () => {
    const user = userEvent.setup();
    const listOpenKitAccessTokens = vi
      .fn()
      .mockRejectedValue(new ApiCallError(403, 'deployment admin required', { code: 'forbidden' }));
    renderScreen(makeClient({ 'token.list': listOpenKitAccessTokens }));

    expect(await screen.findByText('Access denied')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Issue token' })).not.toBeInTheDocument();
    expect(screen.queryByLabelText('Server admin token')).not.toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'Retry' }));
    await waitFor(() => expect(listOpenKitAccessTokens).toHaveBeenCalledTimes(2));
  });
});
