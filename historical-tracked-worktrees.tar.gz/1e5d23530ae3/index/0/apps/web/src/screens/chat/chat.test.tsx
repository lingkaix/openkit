import type { AuthorizedWorkspaceSummary, ThreadDashboardResponse } from '@openkit/app-api-schemas';
import { ApiCallError, type CoreClient } from '@openkit/core-client';
import {
  ArtifactReferenceItemSchema,
  ArtifactSchema,
  ItemSchema,
  TurnSchema,
  WorkspaceRecordSchema,
} from '@openkit/protocol';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { act, render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import type { ReactNode } from 'react';
import { MemoryRouter } from 'react-router-dom';
import { afterEach, beforeEach, describe, expect, it, onTestFinished, vi } from 'vitest';
import { CoreClientProvider } from '../../app/core-client';
import { AppRoutes } from '../../app/routes';
import { useWorkspaceStore } from '../workspace-store';
import { chatKeys } from './data';

const THREAD = {
  id: 'th_00000000-0000-70a0-9cde-4561f64881c6',
  workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
  name: 'Competitive teardown',
  preview: 'Competitive teardown',
  status: 'active',
  createdAt: '2026-07-21T00:00:00.000Z',
  updatedAt: '2026-07-21T00:00:00.000Z',
};

/** Safe dashboard activity is informational even when its outward text requests a decision. */
const RUNTIME_ACTIVITY = [
  {
    turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
    contentCapture: 'on' as const,
    coverage: 'partial' as const,
    entries: [
      {
        sequence: 3,
        observedAt: '2026-07-21T00:00:01.000Z',
        kind: 'progress' as const,
        label: 'Child 1: verification running',
        text: 'Please approve the reported proposal.',
        textTruncated: false,
      },
    ],
    omittedEntryCount: 0,
  },
];

const CONVERSATION_TARGET = {
  workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
  threadId: null,
  defaultTargetRef: 'internal-role:assistant',
  targets: [
    {
      targetRef: 'internal-role:assistant',
      kind: 'assistant' as const,
      label: 'Assistant',
      description: 'Workspace assistant',
      availability: 'available' as const,
      unavailableReason: null,
      threadId: null,
      profileId: null,
      logicalModels: [{ id: 'default', label: 'Default', capabilities: ['chat'] }],
      defaultLogicalModelId: 'default',
    },
    {
      targetRef: 'warm-worker:agent_codex_host:default',
      kind: 'warm-worker' as const,
      label: 'Codex Agent',
      description: 'Reuse the configured Worker',
      availability: 'available' as const,
      unavailableReason: null,
      threadId: null,
      profileId: 'default',
      logicalModels: [{ id: 'default', label: 'Default', capabilities: ['chat'] }],
      defaultLogicalModelId: 'default',
    },
    {
      targetRef: 'new-task-worker',
      kind: 'new-task-worker' as const,
      label: 'New task worker',
      description: 'Start a task worker',
      availability: 'available' as const,
      unavailableReason: null,
      threadId: null,
      profileId: null,
      logicalModels: [{ id: 'default', label: 'Default', capabilities: ['chat'] }],
      defaultLogicalModelId: 'default',
    },
  ],
};

const ITEMS = ItemSchema.array().parse([
  {
    id: 'it_00000000-0000-7596-a3e2-be317d999ead',
    workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
    threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
    turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
    type: 'user-message',
    status: 'completed',
    actor: { kind: 'user', id: 'usr_00000000-0000-7609-aed5-db4b5c95e76c' },
    text: 'Draft a competitive teardown.',
    createdAt: '2026-07-21T00:00:00.000Z',
    completedAt: '2026-07-21T00:00:00.000Z',
  },
  {
    id: 'it_00000000-0000-785f-a82d-59daa7b54760',
    workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
    threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
    turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
    type: 'assistant-message',
    status: 'completed',
    text: 'On it — gathering the details.',
    createdAt: '2026-07-21T00:00:01.000Z',
    completedAt: '2026-07-21T00:00:01.000Z',
  },
  {
    id: 'it_00000000-0000-7570-9913-dd37f2bda2fe',
    workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
    threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
    type: 'approval-request',
    turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
    status: 'completed',
    approvalRequestId: 'ap1',
    title: 'Approve $5 spend',
    description: 'To pull competitor pricing.',
    kind: 'permission',
    createdAt: '2026-07-21T00:00:02.000Z',
    completedAt: '2026-07-21T00:00:02.000Z',
  },
]);

const USER_INPUT_ITEMS = ItemSchema.array().parse([
  {
    id: 'it_00000000-0000-722b-8b9c-ef21b6ead700',
    workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
    threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
    turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
    type: 'user-input-request',
    status: 'completed',
    responsibleUserId: 'usr_00000000-0000-7609-aed5-db4b5c95e76c',
    userInputRequestId: 'uir1',
    prompt: 'Confirm the release shape.',
    questions: [
      {
        id: 'audience',
        header: 'Audience',
        question: 'Who should receive the release?',
        options: null,
        isOther: false,
        isSecret: false,
      },
      {
        id: 'tone',
        header: 'Tone',
        question: 'Which tone should the release use?',
        options: [
          { label: 'Concise', description: 'Keep the release brief.' },
          { label: 'Detailed', description: 'Include supporting detail.' },
        ],
        isOther: false,
        isSecret: false,
      },
    ],
    createdAt: '2026-07-21T00:00:02.000Z',
    completedAt: '2026-07-21T00:00:02.000Z',
  },
]);

type CoreOverrides = Partial<Record<string, unknown>>;
type AppOverrides = Partial<Record<string, unknown>>;

/** Creates a caller-controlled promise for proving pre-settlement UI state. */
function createDeferred<T>() {
  let resolve!: (value: T) => void;
  let reject!: (reason?: unknown) => void;
  const promise = new Promise<T>((resolvePromise, rejectPromise) => {
    resolve = resolvePromise;
    reject = rejectPromise;
  });
  return { promise, reject, resolve };
}

/** Build a fake CoreClient; per-test overrides replace individual methods. */
function makeClient(
  core: CoreOverrides = {},
  app: AppOverrides = {},
  files: Partial<CoreClient['artifactFiles']> = {}
): CoreClient {
  const client = {
    artifactFiles: files,
    core: {
      meta: vi.fn().mockResolvedValue({}),

      ...core,
    },
    app: {
      ...app,
    },

    operations: {
      'thread.list': vi.fn().mockResolvedValue({ items: [] }),
      'turn.start': vi.fn().mockResolvedValue({ id: 'turn1' }),
      'approval.respond': vi.fn().mockResolvedValue({}),
      'conversation.targets': vi
        .fn()
        .mockImplementation(
          ({ workspaceId, threadId }: { workspaceId: string; threadId?: string }) =>
            Promise.resolve({
              ...CONVERSATION_TARGET,
              workspaceId,
              threadId: threadId ?? null,
            })
        ),

      'thread.read': vi.fn().mockResolvedValue(THREAD),
      'thread.items': vi.fn().mockResolvedValue({ items: [], nextCursor: null }),
      'thread.create': vi
        .fn()
        .mockResolvedValue({ ...THREAD, id: 'th_00000000-0000-75c2-bada-0a01c17d153e' }),
      'thread.dashboard': vi.fn().mockResolvedValue({ turns: [] }),
      ...core,
      ...app,
      'workspace.list': vi
        .fn()
        .mockResolvedValueOnce({
          items: [
            { id: 'ws_00000000-0000-7b10-9af8-12fd37a880e0', name: 'Market research' },
            { id: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6', name: 'Second workspace' },
          ].map((workspace) => ({
            membershipStatus: 'active' as const,
            accessCause: 'membership' as const,
            workspace,
            effectiveRole: 'owner',
            membershipRevision: 1,
            ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
            registryRevision: 1,
          })),
        })
        .mockImplementation(
          ((core['workspace.list'] ?? app['workspace.list']) as
            | CoreClient['operations']['workspace.list']
            | undefined) ??
            vi.fn().mockResolvedValue({
              items: [
                { id: 'ws_00000000-0000-7b10-9af8-12fd37a880e0', name: 'Market research' },
                { id: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6', name: 'Second workspace' },
              ].map((workspace) => ({
                membershipStatus: 'active' as const,
                accessCause: 'membership' as const,
                workspace,
                effectiveRole: 'owner',
                membershipRevision: 1,
                ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
                registryRevision: 1,
              })),
            })
        ),
    },
  } as unknown as CoreClient;
  if (app['conversation.navigation'] == null) {
    (
      client.operations as {
        'conversation.navigation': CoreClient['operations']['conversation.navigation'];
      }
    )['conversation.navigation'] = vi.fn(async ({ workspaceId }: { workspaceId: string }) => {
      const listed = await client.operations['thread.list']({ workspaceId: workspaceId });
      return {
        items: listed.items
          .filter((thread) => thread.status === 'active')
          .map((thread) => ({
            activity: 'chat' as const,
            lastActivityAt: thread.updatedAt,
            state: 'idle' as const,
            thread: {
              ...thread,
              entryPath: 'conversation' as const,
              visibility: 'workspace' as const,
            },
          })),
      };
    });
  }
  return client;
}

/** Build one protocol-shaped turn-stream envelope for UI subscription tests. */
function turnStreamEvent(sequence: number, event: string, data: unknown) {
  return {
    protocolVersion: '0.4.0',
    event,
    sequence,
    requestId: null,
    timestamp: '2026-07-21T00:00:00.000Z',
    workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
    threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
    turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
    data,
  };
}

const ACTIVE_TURN = TurnSchema.parse({
  id: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
  workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
  threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
  triggerActor: { kind: 'user', id: 'usr_00000000-0000-7968-a053-ad9e71464afe' },
  items: [],
  error: null,
  configVersion: null,
  startedAt: '2026-07-21T00:00:00.000Z',
  completedAt: null,
  durationMs: null,
  status: 'running',
});

const APPROVAL_TURN = TurnSchema.parse({
  ...ACTIVE_TURN,
  status: 'completed',
  completedAt: '2026-07-21T00:00:02.000Z',
  durationMs: 2_000,
  items: ITEMS,
});

const COMPLETED_TURN = TurnSchema.parse({
  ...ACTIVE_TURN,
  status: 'completed',
  completedAt: '2026-07-21T00:00:02.000Z',
  durationMs: 2_000,
});

const CHAT_MODE_RESPONSE = {
  outcome: 'answered' as const,
  explanation: 'Answered in Chat Mode.',
  turn: COMPLETED_TURN,
  item: ITEMS[1],
  handoff: null,
  originatingWorkspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
  originatingThreadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
  receivingWorkspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
  receivingThreadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
  targetRef: 'internal-role:assistant',
  logicalModelId: 'default',
};

const STARTER_CHAT_MODE_RESPONSE = {
  ...CHAT_MODE_RESPONSE,
  originatingThreadId: 'th_00000000-0000-75c2-bada-0a01c17d153e',
  receivingThreadId: 'th_00000000-0000-75c2-bada-0a01c17d153e',
  turn: TurnSchema.parse({
    ...COMPLETED_TURN,
    id: 'tu_00000000-0000-7c3d-9396-86f77325ff24',
    threadId: 'th_00000000-0000-75c2-bada-0a01c17d153e',
  }),
  item: ItemSchema.parse({
    ...ITEMS[1],
    id: 'it_00000000-0000-7618-b870-ed916b3802da',
    threadId: 'th_00000000-0000-75c2-bada-0a01c17d153e',
    turnId: 'tu_00000000-0000-7c3d-9396-86f77325ff24',
  }),
};

const TASK_MODE_RESPONSE = {
  turn: ACTIVE_TURN,
  state: 'running' as const,
  completion: null,
  evidence: { itemIds: [], artifactIds: [], reviewIds: [] },
  escalation: null,
};

const QUICK_CHAT_WORKSPACE = WorkspaceRecordSchema.parse({
  id: 'ws_7d54f339-a119-5221-bbbf-bfbf3e8a3f28',
  name: 'Quick Chat',
  kind: 'quick-chat',
  status: 'active',
  counts: {
    threadCount: 1,
    artifactCount: 0,
    knowledgeEntryCount: 0,
  },
  createdAt: '2026-07-21T00:00:00.000Z',
  updatedAt: '2026-07-21T00:00:00.000Z',
});

const QUICK_CHAT_MODE_RESPONSE = {
  ...CHAT_MODE_RESPONSE,
  originatingWorkspaceId: QUICK_CHAT_WORKSPACE.id,
  receivingWorkspaceId: QUICK_CHAT_WORKSPACE.id,
  turn: TurnSchema.parse({
    ...COMPLETED_TURN,
    workspaceId: QUICK_CHAT_WORKSPACE.id,
  }),
  item: ItemSchema.parse({
    ...ITEMS[1],
    workspaceId: QUICK_CHAT_WORKSPACE.id,
  }),
};

const SECOND_ASSISTANT_ITEM = ItemSchema.parse({
  ...ITEMS[1],
  id: 'it_00000000-0000-7a2a-8d80-ada19c95b5ee',
  text: 'Here is the completed pricing comparison.',
  createdAt: '2026-07-21T00:00:02.000Z',
  completedAt: '2026-07-21T00:00:02.000Z',
});

const STREAMING_ITEM = {
  id: 'it_00000000-0000-7ba1-a7e3-58d592e2e90b',
  workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
  threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
  turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
  type: 'assistant-message',
  status: 'in_progress',
  text: '',
  createdAt: '2026-07-21T00:00:01.000Z',
  completedAt: null,
};

/**
 * Render one route with an isolated query cache and expose that public cache seam.
 *
 * @param path Initial application route.
 * @param client Core Client fake used by the rendered application.
 * @param prepareQueryClient Optional cache setup applied before the route mounts.
 * @returns The isolated TanStack Query client used by the render.
 */
function renderApp(
  path: string,
  client: CoreClient,
  prepareQueryClient?: (queryClient: QueryClient) => void
) {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  prepareQueryClient?.(queryClient);
  const wrapper = (children: ReactNode) => (
    <QueryClientProvider client={queryClient}>
      <CoreClientProvider client={client}>
        <MemoryRouter initialEntries={[path]}>{children}</MemoryRouter>
      </CoreClientProvider>
    </QueryClientProvider>
  );
  render(wrapper(<AppRoutes />));
  return queryClient;
}

/** Returns the persistent selected-Workspace switcher after discovery settles. */
function workspaceSelectTrigger(name = 'Market research'): Promise<HTMLElement> {
  return screen.findByRole('button', { name });
}

/** Switches the persistent Workspace context and opens one Thread from the starter list. */
async function switchToThread(
  user: ReturnType<typeof userEvent.setup>,
  currentWorkspaceName: string,
  nextWorkspaceName: string,
  threadName: string
) {
  await user.click(await workspaceSelectTrigger(currentWorkspaceName));
  await user.click(await screen.findByRole('menuitem', { name: nextWorkspaceName }));
  await user.click(
    await within(screen.getByRole('main', { name: 'Workspace' })).findByRole('button', {
      name: threadName,
    })
  );
}

beforeEach(() => {
  // jsdom lacks the browser byte-read method; FileReader reads the actual fixture bytes.
  Object.defineProperty(Blob.prototype, 'arrayBuffer', {
    configurable: true,
    writable: true,
    value: function (this: Blob) {
      return new Promise<ArrayBuffer>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as ArrayBuffer);
        reader.onerror = () => reject(reader.error);
        reader.readAsArrayBuffer(this);
      });
    },
  });
  localStorage.clear();
  useWorkspaceStore.setState({ currentWorkspaceId: null });
});

describe.each([
  ['starter', '/chat'],
  [
    'Thread',
    '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
  ],
])('Composer file import on %s', (_surface, path) => {
  afterEach(() => vi.restoreAllMocks());

  it.each([
    ['notes.md', 'text/markdown'],
    ['notes.json', 'application/json'],
    ['notes.txt', 'text/plain'],
    ['notes.MD', 'text/plain'],
    ['notes.JSON', 'text/plain'],
  ])('imports %s with exact bytes and attachment identity without awaiting list refresh', async (name, mediaType) => {
    const user = userEvent.setup();
    const content = '{"note":"héllo"}\n';
    const read = createDeferred<string>();
    const imported = createDeferred<{ artifactId: string; artifactVersion: number }>();
    const refreshed = createDeferred<{ items: [] }>();
    const listArtifacts = vi
      .fn()
      .mockResolvedValueOnce({ items: [] })
      .mockReturnValue(refreshed.promise);
    const importWorkspaceArtifact = vi.fn().mockReturnValue(imported.promise);
    const submitConversation = vi.fn().mockReturnValue(new Promise(() => {}));
    const queryClient = renderApp(
      path,
      makeClient(
        { 'artifact.list': listArtifacts },
        { 'conversation.submit': submitConversation },
        { import: importWorkspaceArtifact }
      )
    );
    await user.type(await screen.findByRole('textbox', { name: 'Message' }), 'Review this file');
    await waitFor(() => expect(listArtifacts).toHaveBeenCalledTimes(1));
    const send = screen.getByRole('button', { name: 'Send message' });
    const trigger = screen.getByRole('button', { name: 'Add artifact or upload attachment' });
    await user.click(trigger);
    const file = new File([content], name, { type: 'application/json' });
    const text = vi.fn().mockReturnValue(read.promise);
    Object.defineProperty(file, 'text', { value: text });
    const requestId = '11111111-1111-4111-8111-111111111111';
    const randomUUID = vi.spyOn(crypto, 'randomUUID').mockReturnValue(requestId);
    await user.upload(document.querySelector('input[type="file"]') as HTMLInputElement, file);

    expect(text).toHaveBeenCalledTimes(1);
    expect(randomUUID).not.toHaveBeenCalled();
    expect(importWorkspaceArtifact).not.toHaveBeenCalled();
    expect(send).toBeDisabled();
    expect(screen.getByRole('button', { name: 'Upload text file' })).toBeDisabled();
    expect(document.querySelector('input[type="file"]')).toBeDisabled();
    await act(async () => read.resolve(content));
    await waitFor(() => expect(importWorkspaceArtifact).toHaveBeenCalledTimes(1));
    expect(randomUUID).toHaveBeenCalledTimes(1);
    expect(importWorkspaceArtifact).toHaveBeenCalledWith(
      {
        workspaceId: 'ws1',
        ...{
          title: name,
          mediaType,
          byteLength: new TextEncoder().encode(content).byteLength,
          contentDigest: 'sha256:2641e795d217a25722a8e1554b6d51257b2fabe3c1ce8f760f19da116706b696',
          requestId,
        },
      },
      expect.any(Blob)
    );
    expect(
      Array.from(
        new Uint8Array(await (importWorkspaceArtifact.mock.calls[0]![1] as Blob).arrayBuffer())
      )
    ).toEqual(Array.from(new TextEncoder().encode(content)));
    expect(importWorkspaceArtifact.mock.calls[0]![0]).not.toHaveProperty('content');
    expect(listArtifacts).toHaveBeenCalledTimes(1);
    expect(send).toBeDisabled();

    await act(async () =>
      imported.resolve({
        artifactId: 'ar_00000000-0000-7c8d-af4c-2980db144abf',
        artifactVersion: 3,
      })
    );
    expect(await screen.findByRole('button', { name: `Remove ${name}` })).toBeInTheDocument();
    expect(screen.queryByRole('dialog', { name: 'Attachments' })).not.toBeInTheDocument();
    expect(listArtifacts.mock.calls).toEqual([
      [{ workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0' }],
      [{ workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0' }],
    ]);
    expect(
      queryClient.getQueryState(['artifacts', 'ws_00000000-0000-7b10-9af8-12fd37a880e0'])
        ?.fetchStatus
    ).toBe('fetching');
    expect(screen.getByRole('button', { name: 'Send message' })).toBeEnabled();
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    await waitFor(() =>
      expect(submitConversation).toHaveBeenCalledWith(
        expect.objectContaining({
          workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          threadId:
            path === '/chat'
              ? 'th_00000000-0000-75c2-bada-0a01c17d153e'
              : 'th_00000000-0000-70a0-9cde-4561f64881c6',
          ...{
            input: 'Review this file',
            artifactRefs: [
              { artifactId: 'ar_00000000-0000-7c8d-af4c-2980db144abf', artifactVersion: 3 },
            ],
          },
        })
      )
    );
    await act(async () => refreshed.resolve({ items: [] }));
  });

  it.each([
    'file read',
    'import command',
  ])('preserves the draft and existing attachment after a failed %s', async (stage) => {
    const user = userEvent.setup();
    const listArtifacts = vi.fn().mockResolvedValue({
      items: [
        { id: 'ar_00000000-0000-7fcd-91a3-6acf6c2aee4e', version: 2, title: 'Existing brief' },
      ],
    });
    const importWorkspaceArtifact = vi.fn().mockRejectedValue(new Error('Import unavailable'));
    const submitConversation = vi.fn().mockReturnValue(new Promise(() => {}));
    renderApp(
      path,
      makeClient(
        { 'artifact.list': listArtifacts },
        { 'conversation.submit': submitConversation },
        { import: importWorkspaceArtifact }
      )
    );
    const message = await screen.findByRole('textbox', { name: 'Message' });
    await user.type(message, 'Keep this draft');
    const trigger = screen.getByRole('button', { name: 'Add artifact or upload attachment' });
    await user.click(trigger);
    await user.click(await screen.findByRole('button', { name: 'Existing brief' }));
    const file = new File(['notes'], 'notes.txt', { type: 'text/plain' });
    const text =
      stage === 'file read'
        ? vi.fn().mockRejectedValue(new Error('Read unavailable'))
        : vi.fn().mockResolvedValue('notes');
    Object.defineProperty(file, 'text', { value: text });
    const input = document.querySelector('input[type="file"]') as HTMLInputElement;
    await user.upload(input, file);

    await waitFor(() => expect(trigger).toBeEnabled());
    expect(text).toHaveBeenCalledTimes(1);
    expect(importWorkspaceArtifact).toHaveBeenCalledTimes(stage === 'file read' ? 0 : 1);
    expect(listArtifacts.mock.calls).toEqual([
      [{ workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0' }],
    ]);
    expect(message).toHaveValue('Keep this draft');
    expect(input).toHaveValue('');
    expect(screen.getByRole('dialog', { name: 'Attachments' })).toBeInTheDocument();
    const alert = within(screen.getByRole('dialog', { name: 'Attachments' })).getByRole('alert');
    expect(alert).toHaveTextContent("Couldn't confirm the file import.");
    expect(alert).toHaveTextContent('The file may already exist.');
    expect(alert).toHaveTextContent('Select the same file to try again.');
    expect(alert).not.toHaveTextContent('Read unavailable');
    expect(alert).not.toHaveTextContent('Import unavailable');
    await user.keyboard('{Escape}');
    expect(screen.getByRole('button', { name: 'Remove Existing brief' })).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Remove notes.txt' })).not.toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    await waitFor(() =>
      expect(submitConversation).toHaveBeenCalledWith(
        expect.objectContaining({
          workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          threadId:
            path === '/chat'
              ? 'th_00000000-0000-75c2-bada-0a01c17d153e'
              : 'th_00000000-0000-70a0-9cde-4561f64881c6',
          ...{
            input: 'Keep this draft',
            artifactRefs: [
              { artifactId: 'ar_00000000-0000-7fcd-91a3-6acf6c2aee4e', artifactVersion: 2 },
            ],
          },
        })
      )
    );
  });

  it('uses a new import request when file content changes after failure', async () => {
    const user = userEvent.setup();
    const importWorkspaceArtifact = vi
      .fn()
      .mockRejectedValueOnce(new Error('Response lost'))
      .mockResolvedValue({ artifactId: 'changed-notes', artifactVersion: 1 });
    renderApp(path, makeClient({}, {}, { import: importWorkspaceArtifact }));
    const trigger = await screen.findByRole('button', {
      name: 'Add artifact or upload attachment',
    });
    await waitFor(() => expect(trigger).toBeEnabled());
    await user.click(trigger);
    const fileInput = document.querySelector('input[type="file"]') as HTMLInputElement;
    for (const content of ['First bytes', 'Corrected bytes']) {
      const file = new File([content], 'notes.txt', { type: 'text/plain' });
      Object.defineProperty(file, 'text', { value: vi.fn().mockResolvedValue(content) });
      await user.upload(fileInput, file);
      await waitFor(() => expect(trigger).toBeEnabled());
    }
    expect(await screen.findByRole('button', { name: 'Remove notes.txt' })).toBeInTheDocument();
    expect(importWorkspaceArtifact).toHaveBeenCalledTimes(2);
    const [first, second] = importWorkspaceArtifact.mock.calls.map(([input]) => input);
    expect(
      new TextDecoder().decode(
        await (importWorkspaceArtifact.mock.calls[0]![1] as Blob).arrayBuffer()
      )
    ).toBe('First bytes');
    expect(
      new TextDecoder().decode(
        await (importWorkspaceArtifact.mock.calls[1]![1] as Blob).arrayBuffer()
      )
    ).toBe('Corrected bytes');
    expect(first).not.toHaveProperty('content');
    expect(second).not.toHaveProperty('content');
    expect(first.contentDigest).not.toBe(second.contentDigest);
    expect(second.requestId).not.toBe(first.requestId);
  });

  it('clears import errors only after success and preserves the conversation request through file selection retries', async () => {
    const user = userEvent.setup();
    const draftRequestId = '11111111-1111-4111-8111-111111111111';
    vi.spyOn(crypto, 'randomUUID')
      .mockReturnValueOnce(draftRequestId)
      .mockReturnValueOnce('22222222-2222-4222-8222-222222222222')
      .mockReturnValue('33333333-3333-4333-8333-333333333333');
    const importWorkspaceArtifact = vi
      .fn()
      .mockRejectedValueOnce(new Error('Private import failure details'))
      .mockResolvedValue({ artifactId: 'uploaded-notes', artifactVersion: 3 });
    const submitConversation = vi.fn().mockReturnValue(new Promise(() => {}));
    renderApp(
      path,
      makeClient(
        {
          'artifact.list': vi.fn().mockResolvedValue({
            items: [
              {
                id: 'ar_00000000-0000-7fcd-91a3-6acf6c2aee4e',
                version: 2,
                title: 'Existing brief',
              },
            ],
          }),
        },
        { 'conversation.submit': submitConversation },
        { import: importWorkspaceArtifact }
      )
    );
    const message = await screen.findByRole('textbox', { name: 'Message' });
    await user.type(message, 'Keep this draft');
    const trigger = screen.getByRole('button', { name: 'Add artifact or upload attachment' });
    await user.click(trigger);
    await user.click(await screen.findByRole('button', { name: 'Existing brief' }));
    const file = new File(['notes'], 'notes.txt', { type: 'text/plain' });
    const text = vi
      .fn()
      .mockRejectedValueOnce(new Error('Private read failure details'))
      .mockResolvedValue('notes');
    Object.defineProperty(file, 'text', { value: text });
    const fileInput = document.querySelector('input[type="file"]') as HTMLInputElement;

    await user.upload(fileInput, file);
    await waitFor(() => expect(trigger).toBeEnabled());
    expect(screen.getByRole('alert')).toHaveTextContent("Couldn't confirm the file import.");
    expect(importWorkspaceArtifact).not.toHaveBeenCalled();
    await user.upload(fileInput, file);
    await waitFor(() => expect(importWorkspaceArtifact).toHaveBeenCalledTimes(1));
    await waitFor(() => expect(trigger).toBeEnabled());
    expect(screen.getByRole('alert')).toHaveTextContent("Couldn't confirm the file import.");
    expect(screen.getByRole('alert')).toHaveTextContent('The file may already exist.');
    expect(screen.getByRole('alert')).not.toHaveTextContent(/Private.*failure details/);
    expect(message).toHaveValue('Keep this draft');

    await user.upload(fileInput, file);
    expect(await screen.findByRole('button', { name: 'Remove notes.txt' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Remove Existing brief' })).toBeInTheDocument();
    expect(message).toHaveValue('Keep this draft');
    expect(importWorkspaceArtifact).toHaveBeenCalledTimes(2);
    expect(importWorkspaceArtifact.mock.calls[1]).toEqual(importWorkspaceArtifact.mock.calls[0]);
    await user.click(trigger);
    expect(
      within(screen.getByRole('dialog', { name: 'Attachments' })).queryByRole('alert')
    ).not.toBeInTheDocument();
    await user.keyboard('{Escape}');
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    await waitFor(() =>
      expect(submitConversation).toHaveBeenCalledWith(
        expect.objectContaining({
          requestId: draftRequestId,
          input: 'Keep this draft',
          artifactRefs: [
            { artifactId: 'ar_00000000-0000-7fcd-91a3-6acf6c2aee4e', artifactVersion: 2 },
            { artifactId: 'uploaded-notes', artifactVersion: 3 },
          ],
        })
      )
    );
  });
});

describe.each([
  ['starter', '/chat', 'th_00000000-0000-75c2-bada-0a01c17d153e'],
  ['starter with immediate acceptance', '/chat', 'th_00000000-0000-75c2-bada-0a01c17d153e'],
  [
    'Thread',
    '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
    'th_00000000-0000-70a0-9cde-4561f64881c6',
  ],
])('successful %s submission selection', (_surface, path, threadId) => {
  it('retains the chosen agent and model for a fresh second request', async () => {
    const user = userEvent.setup();
    const first = createDeferred<typeof CHAT_MODE_RESPONSE>();
    const selectedTarget = {
      ...CONVERSATION_TARGET.targets[1],
      logicalModels: [
        { id: 'worker-default', label: 'Worker default', capabilities: ['chat'] },
        { id: 'orcarouter', label: 'OrcaRouter', capabilities: ['chat'] },
      ],
      defaultLogicalModelId: 'worker-default',
    };
    const submitConversation = vi
      .fn()
      .mockReturnValueOnce(
        _surface.includes('immediate')
          ? Promise.resolve({
              ...CHAT_MODE_RESPONSE,
              originatingThreadId: threadId,
              receivingThreadId: threadId,
            })
          : first.promise
      )
      .mockResolvedValue({
        ...CHAT_MODE_RESPONSE,
        originatingThreadId: threadId,
        receivingThreadId: threadId,
      });
    renderApp(
      path,
      makeClient(
        {
          'thread.read': vi.fn().mockResolvedValue({ ...THREAD, id: threadId }),
          'artifact.list': vi.fn().mockResolvedValue({
            items: [
              {
                id: 'ar_00000000-0000-7fcd-91a3-6acf6c2aee4e',
                version: 2,
                title: 'Existing brief',
              },
            ],
          }),
        },
        {
          'conversation.submit': submitConversation,
          'conversation.targets': vi.fn().mockResolvedValue({
            ...CONVERSATION_TARGET,
            targets: [CONVERSATION_TARGET.targets[0], selectedTarget],
          }),
        }
      )
    );
    await user.click(await screen.findByRole('button', { name: /Conversation agent/ }));
    await user.click(await screen.findByRole('option', { name: 'Codex Agent' }));
    await user.click(screen.getByRole('button', { name: /Logical model/ }));
    await user.click(await screen.findByRole('option', { name: 'OrcaRouter' }));
    await user.click(screen.getByRole('button', { name: 'Add artifact or upload attachment' }));
    await user.click(await screen.findByRole('button', { name: 'Existing brief' }));
    await user.keyboard('{Escape}');
    await user.type(screen.getByRole('textbox', { name: 'Message' }), 'First message');
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    await waitFor(() => expect(submitConversation).toHaveBeenCalledTimes(1));
    const firstDraft = submitConversation.mock.calls[0]?.[0];
    expect(firstDraft).toMatchObject({
      targetRef: selectedTarget.targetRef,
      logicalModelId: 'orcarouter',
      artifactRefs: [{ artifactId: 'ar_00000000-0000-7fcd-91a3-6acf6c2aee4e', artifactVersion: 2 }],
    });
    await act(async () => {
      first.resolve({
        ...CHAT_MODE_RESPONSE,
        originatingThreadId: threadId,
        receivingThreadId: threadId,
      });
      await first.promise;
    });
    await waitFor(() => expect(screen.getByRole('textbox', { name: 'Message' })).toHaveValue(''));
    expect(
      screen.getByRole('button', { name: /Codex Agent.*Conversation agent/ })
    ).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /OrcaRouter.*Logical model/ })).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Remove Existing brief' })).not.toBeInTheDocument();
    await user.type(screen.getByRole('textbox', { name: 'Message' }), 'Second message');
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    await waitFor(() => expect(submitConversation).toHaveBeenCalledTimes(2));
    expect(submitConversation.mock.calls[1]).toEqual([
      {
        workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
        threadId: threadId,
        ...{
          input: 'Second message',
          targetRef: selectedTarget.targetRef,
          logicalModelId: 'orcarouter',
          artifactRefs: [],
          requestId: expect.any(String),
        },
      },
    ]);
    expect(submitConversation.mock.calls[1]?.[0].requestId).not.toBe(firstDraft.requestId);
  });
});

describe('conversation failure identity', () => {
  it.each([
    ['network failure', new TypeError('Private network failure'), 'internal-role:assistant'],
    ['untyped abort', { status: 499, code: 'provider_call_aborted' }, 'internal-role:assistant'],
    [
      'wrong status',
      new ApiCallError(500, 'Private failure', { code: 'provider_call_aborted' }),
      'internal-role:assistant',
    ],
    [
      'wrong code',
      new ApiCallError(499, 'Private failure', { code: 'other_abort' }),
      'internal-role:assistant',
    ],
    [
      'another target',
      new ApiCallError(499, 'Private failure', { code: 'provider_call_aborted' }),
      'new-task-worker',
    ],
  ])('keeps exact retry for %s', async (_name, error, targetRef) => {
    const user = userEvent.setup();
    const submitConversation = vi.fn().mockRejectedValue(error);
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient({}, { 'conversation.submit': submitConversation })
    );
    if (targetRef === 'new-task-worker') await chooseNewTaskWorker(user);
    await user.type(await screen.findByRole('textbox', { name: 'Message' }), 'Retained request');
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    expect(await screen.findByText("Couldn't send that message. Try again.")).toBeInTheDocument();
    const first = submitConversation.mock.calls[0];
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    await waitFor(() => expect(submitConversation).toHaveBeenCalledTimes(2));
    expect(submitConversation.mock.calls[1]).toEqual(first);
    expect(
      screen.queryByText('This turn was stopped. Send starts a new turn.')
    ).not.toBeInTheDocument();
    expect(document.body).not.toHaveTextContent('Private');
  });
});

describe('chat starter (board 01)', () => {
  it('uses Quick Chat when no Workspace is selected', async () => {
    const listConversationNavigation = vi.fn().mockResolvedValue({ items: [] });
    const client = makeClient(
      {
        'workspace.list': vi.fn().mockResolvedValue({
          items: [
            {
              id: 'ws_00000000-0000-7d15-8bb9-5d57f3c7a053',
              name: 'Project Workspace',
              kind: 'general',
            },
            {
              id: 'ws_7d54f339-a119-5221-bbbf-bfbf3e8a3f28',
              name: 'Quick Chat',
              kind: 'quick-chat',
            },
          ].map((workspace) => ({
            membershipStatus: 'active' as const,
            accessCause: 'membership' as const,
            workspace,
            effectiveRole: 'owner',
            membershipRevision: 1,
            ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
            registryRevision: 1,
          })),
        }),
      },
      { 'conversation.navigation': listConversationNavigation }
    );

    renderApp('/chat', client);

    await waitFor(() =>
      expect(listConversationNavigation).toHaveBeenCalledWith({
        workspaceId: 'ws_7d54f339-a119-5221-bbbf-bfbf3e8a3f28',
      })
    );
    expect(listConversationNavigation).not.toHaveBeenCalledWith({
      workspaceId: 'ws_00000000-0000-7d15-8bb9-5d57f3c7a053',
    });
  });

  it('falls back from an unavailable selected Workspace before loading threads', async () => {
    useWorkspaceStore.setState({ currentWorkspaceId: 'ws_00000000-0000-7afd-8124-c249cdaf069a' });
    const workspaces = createDeferred<{
      items: AuthorizedWorkspaceSummary[];
    }>();
    const listConversationNavigation = vi.fn().mockResolvedValue({ items: [] });
    const client = makeClient(
      {
        'workspace.list': vi.fn().mockReturnValue(workspaces.promise),
      },
      { 'conversation.navigation': listConversationNavigation }
    );

    renderApp('/chat', client);

    expect(listConversationNavigation).not.toHaveBeenCalled();
    await act(async () => {
      workspaces.resolve({
        items: [
          {
            workspace: {
              ...QUICK_CHAT_WORKSPACE,
              id: 'ws_00000000-0000-703e-a6be-9a9f8ac8f52c',
              name: 'Authorized Workspace',
              kind: 'general',
            },
            effectiveRole: 'owner',
            membershipStatus: 'active',
            accessCause: 'membership',
            membershipRevision: 1,
            ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
            registryRevision: 1,
          },
          {
            workspace: QUICK_CHAT_WORKSPACE,
            effectiveRole: 'owner',
            membershipStatus: 'active',
            accessCause: 'membership',
            membershipRevision: 1,
            ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
            registryRevision: 1,
          },
        ],
      });
      await workspaces.promise;
    });
    await waitFor(() =>
      expect(listConversationNavigation).toHaveBeenCalledWith({
        workspaceId: 'ws_7d54f339-a119-5221-bbbf-bfbf3e8a3f28',
      })
    );
    expect(
      listConversationNavigation.mock.calls.every(
        ([{ workspaceId }]) => workspaceId === 'ws_7d54f339-a119-5221-bbbf-bfbf3e8a3f28'
      )
    ).toBe(true);
    expect(listConversationNavigation).not.toHaveBeenCalledWith({
      workspaceId: 'ws_00000000-0000-7afd-8124-c249cdaf069a',
    });
    expect(listConversationNavigation).not.toHaveBeenCalledWith({
      workspaceId: 'ws_00000000-0000-703e-a6be-9a9f8ac8f52c',
    });
  });

  it('shows Recent empty only after Workspace discovery and navigation succeed', async () => {
    const workspaces = createDeferred<{
      items: AuthorizedWorkspaceSummary[];
    }>();
    const navigation = createDeferred<{ items: [] }>();
    const listWorkspaces = vi.fn().mockReturnValue(workspaces.promise);
    const listConversationNavigation = vi.fn().mockReturnValue(navigation.promise);
    renderApp(
      '/chat',
      makeClient(
        { 'workspace.list': listWorkspaces },
        { 'conversation.navigation': listConversationNavigation }
      )
    );

    await screen.findByRole('heading', { name: 'What can we get done?' });
    const recent = within(screen.getByText('Recent').closest('section')!);
    expect(listWorkspaces).toHaveBeenCalled();
    expect(listConversationNavigation).not.toHaveBeenCalled();
    expect(recent.queryByText('Start a chat')).not.toBeInTheDocument();
    expect(recent.getByRole('status', { name: 'Loading' })).toBeInTheDocument();

    await act(async () => {
      workspaces.resolve({
        items: [
          {
            workspace: QUICK_CHAT_WORKSPACE,
            effectiveRole: 'owner' as const,
            membershipStatus: 'active' as const,
            accessCause: 'membership' as const,
            membershipRevision: 1,
            ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
            registryRevision: 1,
          },
        ],
      });
      await workspaces.promise;
    });
    await waitFor(() =>
      expect(listConversationNavigation).toHaveBeenCalledWith({
        workspaceId: 'ws_7d54f339-a119-5221-bbbf-bfbf3e8a3f28',
      })
    );
    expect(recent.queryByText('Start a chat')).not.toBeInTheDocument();
    expect(recent.getByRole('status', { name: 'Loading' })).toBeInTheDocument();

    await act(async () => {
      navigation.resolve({ items: [] });
      await navigation.promise;
    });
    expect(await recent.findByText('Start a chat')).toBeInTheDocument();
    expect(recent.queryByRole('status', { name: 'Loading' })).not.toBeInTheDocument();
  });

  it.each([
    'discovery',
    'navigation',
  ] as const)('keeps failed %s out of Recent empty and retries its own read', async (failure) => {
    const user = userEvent.setup();
    const workspaceResult = {
      items: [
        {
          workspace: QUICK_CHAT_WORKSPACE,
          effectiveRole: 'owner' as const,
          membershipStatus: 'active' as const,
          accessCause: 'membership' as const,
          membershipRevision: 1,
          ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
          registryRevision: 1,
        },
      ],
    };
    const listWorkspaces = vi.fn().mockResolvedValue(workspaceResult);
    const listNavigation = vi.fn().mockResolvedValue({ items: [] });
    const failedRead = failure === 'discovery' ? listWorkspaces : listNavigation;
    failedRead.mockRejectedValue(new Error('Read unavailable'));
    renderApp(
      '/chat',
      makeClient(
        { 'workspace.list': listWorkspaces },
        { 'conversation.navigation': listNavigation }
      )
    );

    await screen.findByRole('heading', { name: 'What can we get done?' });
    const recent = within(screen.getByText('Recent').closest('section')!);
    expect(await recent.findByText("Couldn't load recent chats.")).toBeInTheDocument();
    expect(recent.queryByText('Start a chat')).not.toBeInTheDocument();
    if (failure === 'discovery') expect(listNavigation).not.toHaveBeenCalled();
    const callsBeforeRetry = failedRead.mock.calls.length;
    failedRead.mockResolvedValue(failure === 'discovery' ? workspaceResult : { items: [] });
    await user.click(recent.getByRole('button', { name: 'Try again' }));
    expect(await recent.findByText('Start a chat')).toBeInTheDocument();
    expect(failedRead).toHaveBeenCalledTimes(callsBeforeRetry + 1);
    expect(listNavigation).toHaveBeenCalledWith({
      workspaceId: 'ws_7d54f339-a119-5221-bbbf-bfbf3e8a3f28',
    });
  });

  it('loads Recent from actual caller membership without a separate session read', async () => {
    const getSession = vi.fn().mockRejectedValue(new Error('Identity unavailable'));
    const listNavigation = vi.fn().mockResolvedValue({ items: [] });
    const client = makeClient(
      {
        'workspace.list': vi.fn().mockResolvedValue({
          items: [
            'usr_00000000-0000-73d4-904a-d4c4b905df7c',
            'usr_00000000-0000-7000-8000-000000000001',
          ].map((ownerUserId, index) => ({
            membershipStatus: index === 0 ? null : 'active',
            accessCause: 'administrator',
            workspace: {
              ...QUICK_CHAT_WORKSPACE,
              id:
                index === 0
                  ? 'ws_00000000-0000-71f5-922f-6fd42f52f580'
                  : 'ws_7d54f339-a119-5221-bbbf-bfbf3e8a3f28',
            },
            effectiveRole: index === 0 ? null : 'owner',
            ownerUserId,
            membershipRevision: index === 0 ? null : 1,
            registryRevision: 1,
          })),
        }),
      },
      { 'conversation.navigation': listNavigation }
    );
    Object.assign(client, { auth: { email: { getSession } } });
    renderApp('/chat', client);

    await screen.findByRole('heading', { name: 'What can we get done?' });
    const recent = within(screen.getByText('Recent').closest('section')!);
    expect(await recent.findByText('Start a chat')).toBeInTheDocument();
    expect(getSession).not.toHaveBeenCalled();
    expect(listNavigation).toHaveBeenCalledWith({
      workspaceId: 'ws_7d54f339-a119-5221-bbbf-bfbf3e8a3f28',
    });
    expect(listNavigation).not.toHaveBeenCalledWith({
      workspaceId: 'ws_00000000-0000-71f5-922f-6fd42f52f580',
    });
  });

  it('does not present an unavailable Workspace as Recent empty', async () => {
    const listNavigation = vi.fn().mockResolvedValue({ items: [] });
    renderApp(
      '/chat',
      makeClient(
        { 'workspace.list': vi.fn().mockResolvedValue({ items: [] }) },
        { 'conversation.navigation': listNavigation }
      )
    );

    await screen.findByRole('heading', { name: 'What can we get done?' });
    const recent = within(screen.getByText('Recent').closest('section')!);
    expect(await recent.findByText('No workspace is available.')).toBeInTheDocument();
    expect(recent.queryByText('Start a chat')).not.toBeInTheDocument();
    expect(listNavigation).not.toHaveBeenCalled();
  });

  it('keeps disconnected Recent in error treatment even after an empty read', async () => {
    renderApp('/chat', makeClient({ meta: vi.fn().mockRejectedValue(new Error('Offline')) }));

    await screen.findByRole('heading', { name: 'What can we get done?' });
    const recent = within(screen.getByText('Recent').closest('section')!);
    expect(await recent.findByText("Couldn't reach the local runtime.")).toBeInTheDocument();
    expect(recent.queryByText('Start a chat')).not.toBeInTheDocument();
  });

  it('switches the active Workspace from Chat', async () => {
    const user = userEvent.setup();
    const listConversationNavigation = vi.fn().mockResolvedValue({ items: [] });
    renderApp('/chat', makeClient({}, { 'conversation.navigation': listConversationNavigation }));

    await screen.findByRole('heading', { name: 'What can we get done?' });
    await user.click(await workspaceSelectTrigger());
    await user.click(await screen.findByRole('menuitem', { name: 'Second workspace' }));

    await waitFor(() =>
      expect(listConversationNavigation).toHaveBeenCalledWith({
        workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
      })
    );
    expect(useWorkspaceStore.getState().currentWorkspaceId).toBe(
      'ws_00000000-0000-7ec6-8e33-a3b1d758efc6'
    );
  });

  it('lists recent chats in conversation navigation order, not thread creation order', async () => {
    const createdFirst = {
      ...THREAD,
      id: 'th_00000000-0000-74d9-ae98-00c3a0823aba',
      name: 'Created first',
      createdAt: '2026-07-20T00:00:00.000Z',
      updatedAt: '2026-07-20T00:00:00.000Z',
    };
    const activeLater = {
      ...THREAD,
      id: 'th_00000000-0000-732f-81d2-d42066fd8c2b',
      name: 'Active later',
      createdAt: '2026-07-21T00:00:00.000Z',
      updatedAt: '2026-07-22T00:00:00.000Z',
    };
    const listThreads = vi.fn().mockResolvedValue({
      items: [
        createdFirst,
        activeLater,
        { ...THREAD, id: 'th_00000000-0000-7915-b626-0b698e2552dc', name: 'Private chat' },
        {
          ...THREAD,
          id: 'th_00000000-0000-75ac-8cd2-693b43c568a2',
          name: 'Old chat',
          status: 'archived',
        },
      ],
    });
    const listConversationNavigation = vi.fn().mockResolvedValue({
      items: [
        {
          activity: 'chat',
          lastActivityAt: '2026-07-22T00:00:00.000Z',
          state: 'idle',
          thread: { ...activeLater, entryPath: 'conversation', visibility: 'workspace' },
        },
        {
          activity: 'chat',
          lastActivityAt: '2026-07-21T12:00:00.000Z',
          state: 'idle',
          thread: { ...createdFirst, entryPath: 'conversation', visibility: 'workspace' },
        },
      ],
    });
    renderApp(
      '/chat',
      makeClient(
        { 'thread.list': listThreads },
        { 'conversation.navigation': listConversationNavigation }
      )
    );

    const recent = (await screen.findByText('Recent')).closest('section');
    expect(recent).not.toBeNull();
    expect(
      await within(recent!).findByRole('button', { name: 'Active later' })
    ).toBeInTheDocument();
    expect(
      within(recent!)
        .getAllByRole('button')
        .map((button) => button.textContent)
    ).toEqual(['Active later', 'Created first']);
    expect(within(recent!).queryByText('Private chat')).not.toBeInTheDocument();
    expect(within(recent!).queryByText('Old chat')).not.toBeInTheDocument();
    expect(listConversationNavigation).toHaveBeenCalledWith({
      workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
    });
  });

  it.each([
    'chat',
    'unknown',
    'goal',
  ] as const)('opens a Recent %s on its registered route with encoded owner identifiers', async (activity) => {
    const user = userEvent.setup();
    const workspaceId = 'ws/space ?#%';
    const thread = {
      ...THREAD,
      workspaceId,
      id: 'th_00000000-0000-77d5-84f0-993908e56e3f',
      name: 'Encoded conversation',
    };
    const getThread = vi.fn().mockResolvedValue(thread);
    const readGoal = vi.fn().mockResolvedValue({ goal: null, cards: [], versions: [], tasks: [] });
    renderApp(
      '/chat',
      makeClient(
        {
          'workspace.list': vi.fn().mockResolvedValue({
            items: [{ id: workspaceId, name: 'Encoded workspace', kind: 'general' }].map(
              (workspace) => ({
                membershipStatus: 'active' as const,
                accessCause: 'membership' as const,
                workspace,
                effectiveRole: 'owner',
                membershipRevision: 1,
                ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
                registryRevision: 1,
              })
            ),
          }),
          'thread.read': getThread,
        },
        {
          'goal.read': readGoal,
          'conversation.navigation': vi.fn().mockResolvedValue({
            items: [{ thread, activity, state: 'idle', lastActivityAt: thread.updatedAt }],
          }),
        }
      )
    );
    const recent = (await screen.findByText('Recent')).closest('section')!;
    await user.click(await within(recent).findByRole('button', { name: thread.name }));

    if (activity === 'goal') {
      expect(await screen.findByRole('heading', { name: 'Create Goal' })).toBeInTheDocument();
      expect(readGoal).toHaveBeenCalledWith({ workspaceId, threadId: thread.id });
      expect(getThread).not.toHaveBeenCalled();
    } else {
      expect(await screen.findByRole('heading', { name: thread.name })).toBeInTheDocument();
      expect(getThread).toHaveBeenCalledWith({ workspaceId: workspaceId, threadId: thread.id });
      expect(screen.queryByRole('img', { name: 'Task' })).not.toBeInTheDocument();
      expect(readGoal).not.toHaveBeenCalled();
    }
  });

  it('opens a Recent task on the conversation navigation task route', async () => {
    const user = userEvent.setup();
    const taskThread = {
      ...THREAD,
      id: 'th_00000000-0000-7f4d-8b32-425735d1e383',
      name: 'Worker task',
      preview: 'Worker task',
    };
    const chatThread = {
      ...THREAD,
      id: 'th_00000000-0000-7ac9-b5d3-7c03840e3fbd',
      name: 'Assistant chat',
      preview: 'Assistant chat',
    };
    const getThread = vi
      .fn()
      .mockImplementation(({ threadId }: { workspaceId: string; threadId: string }) =>
        Promise.resolve(
          threadId === 'th_00000000-0000-7f4d-8b32-425735d1e383' ? taskThread : chatThread
        )
      );
    const listConversationNavigation = vi.fn().mockResolvedValue({
      items: [
        {
          activity: 'task',
          lastActivityAt: '2026-07-22T00:00:00.000Z',
          state: 'idle',
          thread: { ...taskThread, entryPath: 'conversation', visibility: 'workspace' },
        },
        {
          activity: 'chat',
          lastActivityAt: '2026-07-21T12:00:00.000Z',
          state: 'idle',
          thread: { ...chatThread, entryPath: 'conversation', visibility: 'workspace' },
        },
      ],
    });
    renderApp(
      '/chat',
      makeClient(
        { 'thread.read': getThread },
        { 'conversation.navigation': listConversationNavigation }
      )
    );

    const recent = (await screen.findByText('Recent')).closest('section');
    expect(recent).not.toBeNull();
    expect(await within(recent!).findByRole('button', { name: 'Worker task' })).toBeInTheDocument();
    expect(
      within(recent!)
        .getAllByRole('button')
        .map((button) => button.textContent)
    ).toEqual(['Worker task', 'Assistant chat']);

    await user.click(within(recent!).getByRole('button', { name: 'Worker task' }));
    expect(await screen.findByRole('heading', { name: 'Worker task' })).toBeInTheDocument();
    expect(screen.getByRole('img', { name: 'Task' })).toBeInTheDocument();
    expect(getThread).toHaveBeenCalledWith({
      workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
      threadId: 'th_00000000-0000-7f4d-8b32-425735d1e383',
    });
  });

  it('creates a thread and opens it from the composer', async () => {
    const user = userEvent.setup();
    const createThread = vi
      .fn()
      .mockResolvedValue({ ...THREAD, id: 'th_00000000-0000-75c2-bada-0a01c17d153e' });
    const getThread = vi
      .fn()
      .mockResolvedValue({ ...THREAD, id: 'th_00000000-0000-75c2-bada-0a01c17d153e' });
    const startTurn = vi.fn();
    const submitConversation = vi.fn().mockResolvedValue(STARTER_CHAT_MODE_RESPONSE);
    const quickChat = vi.fn();
    const client = makeClient(
      { 'thread.create': createThread, 'thread.read': getThread, 'turn.start': startTurn },
      { 'chat.quick': quickChat, 'conversation.submit': submitConversation }
    );
    renderApp('/chat', client);
    const input = await screen.findByRole('textbox', { name: 'Message' });
    await user.type(input, 'Plan a launch');
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    await waitFor(() =>
      expect(createThread).toHaveBeenCalledWith({
        workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
        name: 'Plan a launch',
        requestId: expect.any(String),
      })
    );
    await waitFor(() =>
      expect(submitConversation).toHaveBeenCalledWith(
        expect.objectContaining({
          workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          threadId: 'th_00000000-0000-75c2-bada-0a01c17d153e',
          ...{
            artifactRefs: [],
            input: 'Plan a launch',
            logicalModelId: 'default',
            requestId: expect.any(String),
            targetRef: 'internal-role:assistant',
          },
        })
      )
    );
    expect(createThread.mock.invocationCallOrder[0]).toBeLessThan(
      submitConversation.mock.invocationCallOrder[0] ?? 0
    );
    expect(startTurn).not.toHaveBeenCalled();
    expect(quickChat).not.toHaveBeenCalled();
    // Navigated into the thread screen (its index toggle is present).
    expect(await screen.findByRole('button', { name: /Side panel/i })).toBeInTheDocument();
    expect(getThread).toHaveBeenCalledWith({
      workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
      threadId: 'th_00000000-0000-75c2-bada-0a01c17d153e',
    });
    getThread.mockClear();
    await act(async () =>
      useWorkspaceStore.setState({ currentWorkspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6' })
    );
    expect(getThread).not.toHaveBeenCalled();
  });

  it('opens a fresh Chat when the Workspace changes from a thread', async () => {
    const user = userEvent.setup();
    const listConversationNavigation = vi.fn().mockResolvedValue({ items: [] });
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient({}, { 'conversation.navigation': listConversationNavigation })
    );

    await screen.findByRole('heading', { name: 'Competitive teardown' });
    await user.click(await workspaceSelectTrigger());
    await user.click(await screen.findByRole('menuitem', { name: 'Second workspace' }));

    expect(
      await screen.findByRole('heading', { name: 'What can we get done?' })
    ).toBeInTheDocument();
    await waitFor(() =>
      expect(listConversationNavigation).toHaveBeenCalledWith({
        workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
      })
    );
  });

  it('fails closed when a canonical Thread route names an unavailable Workspace', async () => {
    const getThread = vi.fn();
    renderApp(
      '/chat/ws_00000000-0000-7afd-8124-c249cdaf069a/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient({ 'thread.read': getThread })
    );

    expect(await screen.findByText('Workspace unavailable')).toBeInTheDocument();
    expect(getThread).not.toHaveBeenCalled();
  });

  it('syncs the primary switcher to the canonical Thread route Workspace', async () => {
    const workspaceBThread = {
      ...THREAD,
      workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
      name: 'Workspace B thread',
      preview: 'Workspace B thread',
    };
    renderApp(
      '/chat/ws_00000000-0000-7ec6-8e33-a3b1d758efc6/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient({
        'thread.read': vi.fn().mockResolvedValue(workspaceBThread),
        'thread.list': vi.fn().mockImplementation(({ workspaceId }: { workspaceId: string }) =>
          Promise.resolve({
            items: [
              workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6' ? workspaceBThread : THREAD,
            ],
          })
        ),
      })
    );

    expect(await screen.findByRole('heading', { name: 'Workspace B thread' })).toBeInTheDocument();
    await waitFor(() =>
      expect(useWorkspaceStore.getState().currentWorkspaceId).toBe(
        'ws_00000000-0000-7ec6-8e33-a3b1d758efc6'
      )
    );
    expect(screen.getByRole('button', { name: 'Second workspace' })).toBeInTheDocument();
  });

  it('keeps Chat starter on the persistent sidebar switcher', async () => {
    renderApp('/chat', makeClient());
    expect(await workspaceSelectTrigger()).toBeInTheDocument();
    expect(screen.getAllByRole('button', { name: 'Market research' })).toHaveLength(1);
  });

  it('keeps Thread on the persistent sidebar switcher', async () => {
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient()
    );
    expect(
      await screen.findByRole('heading', { name: 'Competitive teardown' })
    ).toBeInTheDocument();
    expect(screen.getAllByRole('button', { name: 'Market research' })).toHaveLength(1);
  });

  it('does not preserve a compatibility Chat Thread route without a Workspace segment', async () => {
    renderApp('/chat/th_00000000-0000-70a0-9cde-4561f64881c6', makeClient());
    expect(await screen.findByText(/doesn't exist/i)).toBeInTheDocument();
  });

  it('opens the created Chat and exposes its running Turn before first submission settles', async () => {
    const user = userEvent.setup();
    const started = createDeferred<typeof STARTER_CHAT_MODE_RESPONSE>();
    const createdThread = {
      ...THREAD,
      id: 'th_00000000-0000-75c2-bada-0a01c17d153e',
      name: 'Pending first Chat',
    };
    const createThread = vi.fn().mockResolvedValue(createdThread);
    const getThread = vi.fn().mockResolvedValue(createdThread);
    const submitConversation = vi.fn().mockReturnValue(started.promise);
    const getThreadDashboard = vi.fn().mockResolvedValue({
      turns: [
        TurnSchema.parse({
          ...ACTIVE_TURN,
          id: 'tu_00000000-0000-7c3d-9396-86f77325ff24',
          threadId: createdThread.id,
        }),
      ],
    });
    renderApp(
      '/chat',
      makeClient(
        { 'thread.create': createThread, 'thread.read': getThread },
        { 'thread.dashboard': getThreadDashboard, 'conversation.submit': submitConversation }
      )
    );

    try {
      await user.type(await screen.findByRole('textbox', { name: 'Message' }), 'Story thread');
      await user.click(screen.getByRole('button', { name: 'Send message' }));
      await waitFor(() => expect(submitConversation).toHaveBeenCalledTimes(1));

      expect(await screen.findByRole('button', { name: 'Stop turn' })).toBeInTheDocument();
      expect(screen.getByRole('heading', { name: createdThread.name })).toBeInTheDocument();
      expect(getThread).toHaveBeenCalledWith({
        workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
        threadId: createdThread.id,
      });
      expect(getThreadDashboard).toHaveBeenCalledWith({
        workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
        threadId: createdThread.id,
      });
      expect(screen.getByRole('textbox', { name: 'Message' })).toHaveValue('Story thread');
      expect(screen.getByRole('button', { name: 'Send message' })).toBeDisabled();
      expect(createThread).toHaveBeenCalledTimes(1);
      expect(submitConversation).toHaveBeenCalledWith(
        expect.objectContaining({
          workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          threadId: createdThread.id,
          ...{ input: 'Story thread', targetRef: 'internal-role:assistant' },
        })
      );
    } finally {
      await act(async () => {
        started.resolve(STARTER_CHAT_MODE_RESPONSE);
        await started.promise;
      });
    }
  });

  it.each([
    'th_00000000-0000-7507-bcfa-25c593615d8d',
    'th_00000000-0000-75c2-bada-0a01c17d153e',
  ])('follows the accepted receiving Workspace and Thread %s after a deferred first submit', async (receivingThreadId) => {
    const user = userEvent.setup();
    const started = createDeferred<typeof STARTER_CHAT_MODE_RESPONSE>();
    const origin = {
      ...THREAD,
      id: 'th_00000000-0000-75c2-bada-0a01c17d153e',
      name: 'Origin Chat',
    };
    const destination = {
      ...THREAD,
      workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
      id: receivingThreadId,
      name: 'Receiving Task',
    };
    const getThread = vi
      .fn()
      .mockImplementation(({ workspaceId }: { workspaceId: string; threadId?: string }) =>
        Promise.resolve(
          workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6' ? destination : origin
        )
      );
    const submitConversation = vi.fn().mockReturnValue(started.promise);
    renderApp(
      '/chat',
      makeClient(
        {
          'thread.create': vi.fn().mockResolvedValue(origin),
          'thread.read': getThread,
          'thread.list': vi.fn().mockImplementation(({ workspaceId }: { workspaceId: string }) =>
            Promise.resolve({
              items: [
                workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6' ? destination : origin,
              ],
            })
          ),
        },
        { 'conversation.submit': submitConversation }
      )
    );
    await user.type(await screen.findByRole('textbox', { name: 'Message' }), 'Hand off this work');
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    expect(await screen.findByRole('heading', { name: 'Origin Chat' })).toBeInTheDocument();
    await act(async () => {
      started.resolve({
        ...STARTER_CHAT_MODE_RESPONSE,
        receivingWorkspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
        receivingThreadId,
      });
      await started.promise;
    });
    expect(await screen.findByRole('heading', { name: 'Receiving Task' })).toBeInTheDocument();
    expect(getThread).toHaveBeenCalledWith({
      workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
      threadId: receivingThreadId,
    });
    expect(screen.getByRole('textbox', { name: 'Message' })).toHaveValue('');
    expect(submitConversation).toHaveBeenCalledTimes(1);
    // Revisiting the origin is a history read, not another handoff request.
    await switchToThread(user, 'Second workspace', 'Market research', 'Origin Chat');
    expect(await screen.findByRole('heading', { name: 'Origin Chat' })).toBeInTheDocument();
    expect(submitConversation).toHaveBeenCalledTimes(1);
  });

  it('keeps a late first-submit handoff and draft out of another Workspace with a colliding Thread id', async () => {
    const user = userEvent.setup();
    const started = createDeferred<typeof STARTER_CHAT_MODE_RESPONSE>();
    const origin = {
      ...THREAD,
      id: 'th_00000000-0000-75c2-bada-0a01c17d153e',
      name: 'Origin Chat',
    };
    const other = {
      ...origin,
      workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
      name: 'Other Chat',
    };
    const getThread = vi
      .fn()
      .mockImplementation(({ workspaceId }: { workspaceId: string; threadId?: string }) =>
        Promise.resolve(workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6' ? other : origin)
      );
    const submitConversation = vi.fn().mockReturnValue(started.promise);
    renderApp(
      '/chat',
      makeClient(
        {
          'thread.create': vi.fn().mockResolvedValue(origin),
          'thread.read': getThread,
          'thread.list': vi.fn().mockImplementation(({ workspaceId }: { workspaceId: string }) =>
            Promise.resolve({
              items: [workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6' ? other : origin],
            })
          ),
        },
        { 'conversation.submit': submitConversation }
      )
    );
    await user.type(await screen.findByRole('textbox', { name: 'Message' }), 'Original draft');
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    expect(await screen.findByRole('heading', { name: 'Origin Chat' })).toBeInTheDocument();
    await switchToThread(user, 'Market research', 'Second workspace', 'Other Chat');
    expect(await screen.findByRole('heading', { name: 'Other Chat' })).toBeInTheDocument();
    await user.type(screen.getByRole('textbox', { name: 'Message' }), 'Unsent other draft');
    await act(async () => {
      started.resolve({
        ...STARTER_CHAT_MODE_RESPONSE,
        receivingThreadId: 'th_00000000-0000-7507-bcfa-25c593615d8d',
      });
      await started.promise;
    });
    expect(screen.getByRole('heading', { name: 'Other Chat' })).toBeInTheDocument();
    expect(screen.getByRole('textbox', { name: 'Message' })).toHaveValue('Unsent other draft');
    expect(getThread).not.toHaveBeenCalledWith(
      'ws_00000000-0000-7b10-9af8-12fd37a880e0',
      'th_00000000-0000-7507-bcfa-25c593615d8d'
    );
    expect(submitConversation).toHaveBeenCalledTimes(1);
  });

  it('retains the first draft and exact request in the created Thread after submission fails', async () => {
    const user = userEvent.setup();
    const createThread = vi
      .fn()
      .mockResolvedValue({ ...THREAD, id: 'th_00000000-0000-75c2-bada-0a01c17d153e' });
    const startTurn = vi.fn();
    const submitConversation = vi.fn().mockRejectedValue(new Error('chat_mode_unavailable'));
    const quickChat = vi.fn();
    const client = makeClient(
      {
        'thread.create': createThread,
        'turn.start': startTurn,
        'thread.read': vi
          .fn()
          .mockResolvedValue({ ...THREAD, id: 'th_00000000-0000-75c2-bada-0a01c17d153e' }),
      },
      { 'chat.quick': quickChat, 'conversation.submit': submitConversation }
    );
    renderApp('/chat', client);
    const input = await screen.findByRole('textbox', { name: 'Message' });
    await user.type(input, 'Story thread');
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    expect(await screen.findByText("Couldn't send that message. Try again.")).toBeInTheDocument();
    await waitFor(() =>
      expect(submitConversation).toHaveBeenCalledWith(
        expect.objectContaining({
          workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          threadId: 'th_00000000-0000-75c2-bada-0a01c17d153e',
          ...{
            input: 'Story thread',
            targetRef: 'internal-role:assistant',
          },
        })
      )
    );
    expect(screen.getByRole('textbox', { name: 'Message' })).toHaveValue('Story thread');
    const submitted = submitConversation.mock.calls[0];
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    await waitFor(() => expect(submitConversation).toHaveBeenCalledTimes(2));
    expect(submitConversation.mock.calls[1]).toEqual(submitted);
    expect(createThread).toHaveBeenCalledTimes(1);
    expect(startTurn).not.toHaveBeenCalled();
    expect(quickChat).not.toHaveBeenCalled();
  });

  it('does not open a workspace A starter result after the current workspace switches to B', async () => {
    const user = userEvent.setup();
    const started = createDeferred<typeof STARTER_CHAT_MODE_RESPONSE>();
    const created = createDeferred<typeof THREAD>();
    const createThread = vi.fn().mockReturnValue(created.promise);
    const getThread = vi.fn();
    const submitConversation = vi.fn().mockReturnValue(started.promise);
    const client = makeClient(
      { 'thread.create': createThread, 'thread.read': getThread },
      { 'conversation.submit': submitConversation }
    );
    const queryClient = renderApp('/chat', client);
    const invalidateQueries = vi.spyOn(queryClient, 'invalidateQueries');

    await user.type(await screen.findByRole('textbox', { name: 'Message' }), 'Plan for A');
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    await waitFor(() => expect(createThread).toHaveBeenCalledTimes(1));
    act(() =>
      useWorkspaceStore.setState({ currentWorkspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6' })
    );
    await act(async () => {
      created.resolve({ ...THREAD, id: 'th_00000000-0000-75c2-bada-0a01c17d153e' });
      await created.promise;
    });
    await waitFor(() =>
      expect(submitConversation).toHaveBeenCalledWith(
        expect.objectContaining({
          workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          threadId: 'th_00000000-0000-75c2-bada-0a01c17d153e',
          ...{ input: 'Plan for A' },
        })
      )
    );
    await act(async () => {
      started.resolve(STARTER_CHAT_MODE_RESPONSE);
      await started.promise;
    });

    await waitFor(() =>
      expect(invalidateQueries).toHaveBeenCalledWith({
        queryKey: chatKeys.threads('ws_00000000-0000-7b10-9af8-12fd37a880e0'),
      })
    );
    expect(invalidateQueries).not.toHaveBeenCalledWith({
      queryKey: chatKeys.threads('ws_00000000-0000-7ec6-8e33-a3b1d758efc6'),
    });
    expect(screen.getByRole('heading', { name: 'What can we get done?' })).toBeInTheDocument();
    expect(getThread).not.toHaveBeenCalled();
    expect(
      queryClient.getQueryData(
        chatKeys.thread(
          'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
          'th_00000000-0000-75c2-bada-0a01c17d153e'
        )
      )
    ).toBeUndefined();
  });

  it('disables the composer with a reason when the runtime is unreachable', async () => {
    const client = makeClient({ meta: vi.fn().mockRejectedValue(new Error('down')) });
    renderApp('/chat', client);
    // useConnection retries once, so disconnection settles after ~1s.
    await waitFor(() => expect(screen.getByRole('textbox', { name: 'Message' })).toBeDisabled(), {
      timeout: 3000,
    });
  });
});

describe('chat thread (boards 02/03)', () => {
  it('renders the item stream: messages and an inline approval card', async () => {
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
      },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          pendingRequests: [
            {
              requestId: 'ap1',
              canRespond: true,
              approvalEffect: {
                status: 'available',
                summary: 'Summary: Approval',
                detail: '{"effect":{"amount":5}}',
              },
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
          turns: [APPROVAL_TURN],
        }),
      }
    );
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    expect(
      await screen.findByRole('heading', { name: 'Competitive teardown' })
    ).toBeInTheDocument();
    expect(await screen.findByText('Draft a competitive teardown.')).toBeInTheDocument();
    expect(screen.getByText('On it — gathering the details.')).toBeInTheDocument();
    expect(screen.getByText('Approve $5 spend')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Approve' })).toBeInTheDocument();
  });

  it('hides grant for unavailable exact detail while retaining authorized denial and withdrawal', async () => {
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
        'pending-request.withdraw': vi.fn().mockResolvedValue({}),
      },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          turns: [APPROVAL_TURN],
          pendingRequests: [
            {
              requestId: 'ap1',
              state: 'pending',
              canRespond: true,
              approvalEffect: {
                status: 'unavailable',
                reason: 'Complete detail exceeds the limit.',
              },
            },
          ],
        }),
      }
    );
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    expect(
      await screen.findByText(/Exact effect unavailable; approval disabled/)
    ).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Approve' })).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Deny' })).toBeInTheDocument();
    await userEvent.setup().click(screen.getByRole('button', { name: 'Withdraw' }));
    expect(client.operations['pending-request.withdraw']).toHaveBeenCalledWith(
      expect.objectContaining({
        pendingRequestId: 'ap1',
        ...{
          workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
        },
      })
    );
  });

  it('responds to an inline approval', async () => {
    const user = userEvent.setup();
    const respondApproval = vi.fn().mockResolvedValue({});
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
        'approval.respond': respondApproval,
      },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          pendingRequests: [
            {
              requestId: 'ap1',
              canRespond: true,
              approvalEffect: {
                status: 'available',
                summary: 'Summary: Approval',
                detail: '{"effect":{"amount":5}}',
              },
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
          turns: [APPROVAL_TURN],
          runtimeActivity: RUNTIME_ACTIVITY,
        }),
      }
    );
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    expect(await screen.findByText('Child 1: verification running')).toBeInTheDocument();
    expect(screen.getAllByRole('button', { name: 'Approve' })).toHaveLength(1);
    expect(
      screen.getByRole('region', { name: 'Runtime activity' }).querySelector('button')
    ).toBeNull();
    await user.click(await screen.findByRole('button', { name: 'Approve' }));
    expect(respondApproval).toHaveBeenCalledWith({
      approvalRequestId: 'ap1',
      ...{
        workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
        threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
        turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
        decision: 'granted',
        requestId: expect.any(String),
      },
    });
  });

  it('explains a closed approval and never offers another decision', async () => {
    const decision = ItemSchema.parse({
      id: 'it_00000000-0000-7858-8a3b-5f4791bf9c4a',
      workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
      threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
      turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
      type: 'approval-decision',
      status: 'completed',
      actor: { kind: 'user', id: 'usr_00000000-0000-7000-8000-000000000001' },
      causationId: 'it_00000000-0000-7570-9913-dd37f2bda2fe',
      approvalRequestId: 'ap1',
      decision: 'denied',
      decidedAt: '2026-07-21T00:00:03.000Z',
      createdAt: '2026-07-21T00:00:03.000Z',
      completedAt: '2026-07-21T00:00:03.000Z',
    });
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient({
        'thread.items': vi
          .fn()
          .mockResolvedValue({ items: [...ITEMS, decision], nextCursor: null }),
      })
    );
    expect(await screen.findByText('Denied. This approval is closed.')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Approve' })).not.toBeInTheDocument();
  });

  it('keeps an unanswered approval actionable after its raising Turn ends', async () => {
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient(
        { 'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }) },
        {
          'thread.dashboard': vi.fn().mockResolvedValue({
            pendingRequests: [
              {
                requestId: 'ap1',
                canRespond: true,
                approvalEffect: {
                  status: 'available',
                  summary: 'Summary: Approval',
                  detail: '{"effect":{"amount":5}}',
                },
                state: 'pending',
                resolution: null,
                ending: null,
                disposition: null,
              },
            ],
            turns: [COMPLETED_TURN],
          }),
        }
      )
    );
    expect(await screen.findByRole('button', { name: 'Approve' })).toBeEnabled();
  });

  it('shows pending approval and retries a failed decision with the same request identity', async () => {
    const pending = createDeferred<unknown>();
    const respondApproval = vi.fn().mockReturnValueOnce(pending.promise).mockResolvedValue({});
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient(
        {
          'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
          'approval.respond': respondApproval,
        },
        {
          'thread.dashboard': vi.fn().mockResolvedValue({
            pendingRequests: [
              {
                requestId: 'ap1',
                canRespond: true,
                approvalEffect: {
                  status: 'available',
                  summary: 'Summary: Approval',
                  detail: '{"effect":{"amount":5}}',
                },
                state: 'pending',
                resolution: null,
                ending: null,
                disposition: null,
              },
            ],
            turns: [APPROVAL_TURN],
          }),
        }
      )
    );
    await userEvent.click(await screen.findByRole('button', { name: 'Approve' }));
    expect(screen.getByRole('button', { name: 'Approve' })).toBeDisabled();
    expect(screen.getByText('Submitting decision…')).toBeInTheDocument();
    pending.reject(new Error('request failed'));
    expect(await screen.findByRole('alert')).toHaveTextContent("Couldn't submit this decision.");
    await userEvent.click(screen.getByRole('button', { name: 'Try again' }));
    await waitFor(() => expect(respondApproval).toHaveBeenCalledTimes(2));
    expect(respondApproval.mock.calls[0]?.[0].requestId).toEqual(expect.any(String));
    expect(respondApproval.mock.calls[1]).toEqual(respondApproval.mock.calls[0]);
  });

  it('waits for authoritative task status before exposing approval actions', async () => {
    const dashboard = createDeferred<Pick<ThreadDashboardResponse, 'turns' | 'pendingRequests'>>();
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient(
        { 'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }) },
        { 'thread.dashboard': vi.fn().mockReturnValue(dashboard.promise) }
      )
    );
    expect(await screen.findByText('Checking approval status…')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Approve' })).not.toBeInTheDocument();
    await act(async () =>
      dashboard.resolve({
        pendingRequests: [
          {
            requestId: 'ap1',
            canRespond: true,
            approvalEffect: {
              status: 'available',
              summary: 'Summary: Approval',
              detail: '{"effect":{"amount":5}}',
            },
            state: 'pending',
            resolution: null,
            ending: null,
            disposition: null,
          },
        ],
        turns: [COMPLETED_TURN],
      })
    );
    expect(await screen.findByRole('button', { name: 'Approve' })).toBeEnabled();
  });

  it('keeps an undecided approval decidable while its raising Turn is still running', async () => {
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient(
        {
          'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
          subscribeTurnEvents: vi.fn().mockReturnValue({
            [Symbol.asyncIterator]() {
              return { next: () => new Promise(() => {}) };
            },
          }),
        },
        {
          'thread.dashboard': vi.fn().mockResolvedValue({
            pendingRequests: [
              {
                requestId: 'ap1',
                canRespond: true,
                approvalEffect: {
                  status: 'available',
                  summary: 'Summary: Approval',
                  detail: '{"effect":{"amount":5}}',
                },
                state: 'pending',
                resolution: null,
                ending: null,
                disposition: null,
              },
            ],
            turns: [ACTIVE_TURN],
          }),
        }
      )
    );
    expect(await screen.findByRole('button', { name: 'Approve' })).toBeEnabled();
  });

  it('keeps an undecided approval available when another approval on the Turn is already decided', async () => {
    const turn = TurnSchema.parse({
      ...APPROVAL_TURN,
      items: ItemSchema.array().parse([
        ...ITEMS,
        {
          id: 'it_00000000-0000-78b1-834e-a8dc49f35819',
          workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
          turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
          type: 'approval-decision',
          status: 'completed',
          actor: { kind: 'user', id: 'usr_00000000-0000-7a12-a95f-975ecdd21953' },
          causationId: 'req_other',
          approvalRequestId: 'another-approval',
          decision: 'denied',
          decidedAt: '2026-07-21T00:00:03.000Z',
          createdAt: '2026-07-21T00:00:03.000Z',
          completedAt: '2026-07-21T00:00:03.000Z',
        },
      ]),
    });
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient(
        { 'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }) },
        {
          'thread.dashboard': vi.fn().mockResolvedValue({
            pendingRequests: [
              {
                requestId: 'ap1',
                canRespond: true,
                approvalEffect: {
                  status: 'available',
                  summary: 'Summary: Approval',
                  detail: '{"effect":{"amount":5}}',
                },
                state: 'pending',
                resolution: null,
                ending: null,
                disposition: null,
              },
            ],
            turns: [turn],
          }),
        }
      )
    );
    expect(await screen.findByRole('button', { name: 'Approve' })).toBeEnabled();
  });

  it('keeps a resolved approval request and decision legible without response controls', async () => {
    const resolvedItems = ItemSchema.array().parse([
      ...ITEMS,
      {
        id: 'it_00000000-0000-7db6-8b5a-6d048ddcb778',
        workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
        threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
        turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
        type: 'approval-decision',
        status: 'completed',
        actor: { kind: 'user', id: 'usr_00000000-0000-7a12-a95f-975ecdd21953' },
        causationId: 'req_approval',
        approvalRequestId: 'ap1',
        decision: 'granted',
        decidedAt: '2026-07-21T00:00:03.000Z',
        createdAt: '2026-07-21T00:00:03.000Z',
        completedAt: '2026-07-21T00:00:03.000Z',
      },
    ]);
    const client = makeClient({
      'thread.items': vi.fn().mockResolvedValue({ items: resolvedItems, nextCursor: null }),
    });

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    expect(await screen.findByText('Approve $5 spend')).toBeInTheDocument();
    expect(screen.getByText('Approved')).toBeInTheDocument();
    expect(screen.getByText('by usr_00000000-0000-7a12-a95f-975ecdd21953')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Approve' })).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Deny' })).not.toBeInTheDocument();
  });

  it('renders every non-secret Gate question and submits one complete answer map', async () => {
    const user = userEvent.setup();
    const answerUserInput = vi.fn().mockResolvedValue({
      requestId: 'uir1',
      workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
      threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
      state: 'resolved',
      resolution: 'answered',
      ending: null,
    });
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: USER_INPUT_ITEMS, nextCursor: null }),
        'question.answer': answerUserInput,
      },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          pendingRequests: [
            {
              requestId: 'uir1',
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
          viewerUserId: 'usr_00000000-0000-7609-aed5-db4b5c95e76c',
          turns: [
            {
              ...APPROVAL_TURN,
              items: USER_INPUT_ITEMS,
            },
          ],
          runtimeActivity: RUNTIME_ACTIVITY,
        }),
      }
    );
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    expect(await screen.findByText('Child 1: verification running')).toBeInTheDocument();
    expect(
      screen.getByRole('region', { name: 'Runtime activity' }).querySelector('input, button')
    ).toBeNull();
    await user.type(await screen.findByRole('textbox', { name: 'Audience' }), 'Operators');
    await user.click(screen.getByRole('radio', { name: 'Concise' }));
    await user.click(screen.getByRole('button', { name: 'Submit answers' }));

    await waitFor(() =>
      expect(answerUserInput).toHaveBeenCalledWith(
        expect.objectContaining({
          userInputRequestId: 'uir1',
          ...{
            workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
            threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
            answers: { audience: ['Operators'], tone: ['Concise'] },
            requestId: expect.any(String),
          },
        })
      )
    );
  });

  it('keeps option choices and submits one free-form Other answer under the same question id', async () => {
    const userInputItem = USER_INPUT_ITEMS.find((item) => item.type === 'user-input-request');
    if (!userInputItem) {
      throw new Error('The Gate fixture must contain one user-input request.');
    }
    const toneQuestion = userInputItem.questions.find((question) => question.id === 'tone');
    if (!toneQuestion) {
      throw new Error('The Gate fixture must contain the option question.');
    }
    const otherItems = ItemSchema.array().parse([
      {
        ...userInputItem,
        prompt: toneQuestion.question,
        questions: [{ ...toneQuestion, isOther: true }],
      },
    ]);
    const user = userEvent.setup();
    const answerUserInput = vi.fn().mockResolvedValue({
      requestId: 'uir1',
      workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
      threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
      state: 'resolved',
      resolution: 'answered',
      ending: null,
    });
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: otherItems, nextCursor: null }),
        'question.answer': answerUserInput,
      },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          turns: [APPROVAL_TURN],
          pendingRequests: [
            {
              requestId: 'uir1',
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
        }),
      }
    );
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    expect(await screen.findByRole('radio', { name: 'Concise' })).toBeInTheDocument();
    expect(screen.getByRole('radio', { name: 'Detailed' })).toBeInTheDocument();
    await user.type(screen.getByRole('textbox', { name: 'Other' }), 'Warm and direct');
    await user.click(screen.getByRole('button', { name: 'Submit answers' }));

    await waitFor(() =>
      expect(answerUserInput).toHaveBeenCalledWith(
        expect.objectContaining({
          userInputRequestId: 'uir1',
          ...{
            workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
            threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
            answers: { tone: ['Warm and direct'] },
            requestId: expect.any(String),
          },
        })
      )
    );
  });

  it('keeps Gate answers pending, exposes failure, and retries the same complete map', async () => {
    const user = userEvent.setup();
    const pending = createDeferred<unknown>();
    const answerUserInput = vi.fn().mockReturnValueOnce(pending.promise).mockResolvedValueOnce({
      requestId: 'uir1',
      workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
      threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
      state: 'resolved',
      resolution: 'answered',
      ending: null,
    });
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: USER_INPUT_ITEMS, nextCursor: null }),
        'question.answer': answerUserInput,
      },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          turns: [APPROVAL_TURN],
          pendingRequests: [
            {
              requestId: 'uir1',
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
        }),
      }
    );
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    await user.type(await screen.findByRole('textbox', { name: 'Audience' }), 'Operators');
    await user.click(screen.getByRole('radio', { name: 'Concise' }));
    await user.click(screen.getByRole('button', { name: 'Submit answers' }));
    expect(screen.getByRole('button', { name: 'Submitting answers' })).toBeDisabled();
    pending.reject(new Error('answer rejected'));
    expect(await screen.findByRole('alert')).toHaveTextContent("Couldn't submit answers.");
    await user.click(screen.getByRole('button', { name: 'Try again' }));
    await waitFor(() => expect(answerUserInput).toHaveBeenCalledTimes(2));
    expect(answerUserInput.mock.calls[1]).toEqual(answerUserInput.mock.calls[0]);
  });

  it('correlates an answered request with its response on a later Turn', async () => {
    const userInputItem = USER_INPUT_ITEMS.find((item) => item.type === 'user-input-request');
    if (!userInputItem) {
      throw new Error('The Gate fixture must contain one user-input request.');
    }
    const client = makeClient({
      'thread.items': vi.fn().mockResolvedValue({
        items: ItemSchema.array().parse([
          userInputItem,
          {
            id: 'it_00000000-0000-72f2-914f-1f9755fa60c1',
            workspaceId: userInputItem.workspaceId,
            threadId: userInputItem.threadId,
            turnId: 'tu_00000000-0000-7553-9195-34d7d80353d5',
            type: 'user-input-response',
            status: 'completed',
            actor: { kind: 'user', id: 'usr_00000000-0000-7580-8c3b-db9da7a361ae' },
            causationId: 'req_user_input_response',
            userInputRequestId: userInputItem.userInputRequestId,
            answers: { audience: ['Operators'], tone: ['Concise'] },
            answeredAt: '2026-07-21T00:00:03.000Z',
            createdAt: '2026-07-21T00:00:03.000Z',
            completedAt: '2026-07-21T00:00:03.000Z',
          },
        ]),
        nextCursor: null,
      }),
    });
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    expect(await screen.findByText('Answered')).toBeInTheDocument();
    expect(screen.queryByText('You answered')).not.toBeInTheDocument();
    expect(screen.getByText(/usr_00000000-0000-7580-8c3b-db9da7a361ae/)).toBeInTheDocument();
    expect(screen.queryByRole('textbox', { name: 'Audience' })).not.toBeInTheDocument();
    expect(screen.queryByRole('radio', { name: 'Concise' })).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Submit answers' })).not.toBeInTheDocument();
  });

  it.each([
    { disconnected: false, secret: true, posture: 'secret-bearing' },
    { disconnected: true, secret: false, posture: 'disconnected' },
  ])('keeps a $posture Gate visible but read-only', async ({ disconnected, secret }) => {
    const userInputItem = USER_INPUT_ITEMS.find((item) => item.type === 'user-input-request');
    if (!userInputItem) {
      throw new Error('The Gate fixture must contain one user-input request.');
    }
    const secretItems = ItemSchema.array().parse([
      {
        ...userInputItem,
        questions: userInputItem.questions.map((question, index) => ({
          ...question,
          isSecret: secret && index === 0,
        })),
      },
    ]);
    const startTurn = vi.fn();
    const client = makeClient({
      ...(disconnected ? { meta: vi.fn().mockRejectedValue(new Error('down')) } : {}),
      'thread.items': vi.fn().mockResolvedValue({ items: secretItems, nextCursor: null }),
      'turn.start': startTurn,
    });
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    expect(await screen.findByText('Who should receive the release?')).toBeInTheDocument();
    expect(screen.getByText('Which tone should the release use?')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Submit answers' })).not.toBeInTheDocument();
    expect(startTurn).not.toHaveBeenCalled();
  });

  it('sends a follow-up turn', async () => {
    const user = userEvent.setup();
    const startTurn = vi.fn();
    const submitConversation = vi.fn().mockResolvedValue(CHAT_MODE_RESPONSE);
    const quickChat = vi.fn();
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
        'turn.start': startTurn,
      },
      { 'chat.quick': quickChat, 'conversation.submit': submitConversation }
    );
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    const input = await screen.findByRole('textbox', { name: 'Message' });
    await user.type(input, 'Add a pricing table');
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    await waitFor(() =>
      expect(submitConversation).toHaveBeenCalledWith(
        expect.objectContaining({
          workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
          ...{
            input: 'Add a pricing table',
            targetRef: 'internal-role:assistant',
          },
        })
      )
    );
    expect(startTurn).not.toHaveBeenCalled();
    expect(quickChat).not.toHaveBeenCalled();
  });

  it('shows a skeleton while the stream loads', async () => {
    const client = makeClient({ 'thread.items': vi.fn().mockReturnValue(new Promise(() => {})) });
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    await waitFor(() => expect(screen.getAllByLabelText('Loading').length).toBeGreaterThan(0));
  });

  it('shows an inline error when the stream fails', async () => {
    const client = makeClient({ 'thread.items': vi.fn().mockRejectedValue(new Error('boom')) });
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    expect(await screen.findByText(/Couldn't load this thread\./i)).toBeInTheDocument();
  });

  it.each([
    'resolved',
    'ended',
    'inspect-only',
    'invalidated',
  ] as const)('hides controls for an authoritative %s request before publication', async (state) => {
    const client = makeClient(
      {
        subscribeTurnEvents: vi.fn().mockReturnValue({
          [Symbol.asyncIterator]() {
            return {
              next: () => new Promise(() => {}),
              return: async () => ({ done: true, value: undefined }),
            };
          },
        }),
        'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
      },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          turns: [APPROVAL_TURN, { ...ACTIVE_TURN, id: 'tu_00000000-0000-7e19-a9ee-94030e5f5d04' }],
          pendingRequests: [
            {
              requestId: 'ap1',
              canRespond: true,
              approvalEffect: {
                status: 'available',
                summary: 'Summary: Approval',
                detail: '{"effect":{"amount":5}}',
              },
              state: state === 'invalidated' ? 'ended' : state,
              resolution: state === 'resolved' ? 'granted' : null,
              ending:
                state === 'ended' ? 'withdrawn' : state === 'invalidated' ? 'invalidated' : null,
              disposition: null,
            },
          ],
        }),
      }
    );
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    await screen.findByText('Approve $5 spend');
    await waitFor(() =>
      expect(screen.queryByRole('button', { name: 'Approve' })).not.toBeInTheDocument()
    );
    expect(screen.queryByRole('button', { name: 'Deny' })).not.toBeInTheDocument();
  });

  it.each([
    'resolved',
    'withdrawn',
    'invalidated',
    'inspect-only',
  ] as const)('hides input controls for authoritative %s input during unrelated work', async (state) => {
    const client = makeClient(
      {
        subscribeTurnEvents: vi.fn().mockReturnValue({
          [Symbol.asyncIterator]() {
            return {
              next: () => new Promise(() => {}),
              return: async () => ({ done: true, value: undefined }),
            };
          },
        }),
        'thread.items': vi.fn().mockResolvedValue({ items: USER_INPUT_ITEMS, nextCursor: null }),
      },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          turns: [ACTIVE_TURN],
          pendingRequests: [
            {
              requestId: 'uir1',
              state: state === 'withdrawn' || state === 'invalidated' ? 'ended' : state,
              resolution: state === 'resolved' ? 'answered' : null,
              ending: state === 'withdrawn' || state === 'invalidated' ? state : null,
              disposition: null,
            },
          ],
        }),
      }
    );
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    expect(await screen.findByRole('textbox', { name: 'Audience' })).toBeDisabled();
    expect(screen.queryByRole('button', { name: 'Submit answers' })).not.toBeInTheDocument();
  });

  it('makes approvals read-only and disables the composer when disconnected', async () => {
    const client = makeClient({
      meta: vi.fn().mockRejectedValue(new Error('down')),
      'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
    });
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    await screen.findByText('Approve $5 spend');
    await waitFor(() => expect(screen.getByRole('textbox', { name: 'Message' })).toBeDisabled(), {
      timeout: 3000,
    });
    expect(screen.queryByRole('button', { name: 'Approve' })).not.toBeInTheDocument();
  });
});

describe('thread lifecycle and attribution (S7)', () => {
  it.each([
    'usr_00000000-0000-7609-aed5-db4b5c95e76c',
    'usr_00000000-0000-73d4-904a-d4c4b905df7c',
  ])('attributes people and agents for viewer %s', async (viewerUserId) => {
    const messages = ItemSchema.array().parse([
      ITEMS[0],
      {
        ...ITEMS[0],
        id: 'it_00000000-0000-7670-93ab-28e0c439d4f7',
        actor: { kind: 'user', id: 'usr_00000000-0000-73d4-904a-d4c4b905df7c' },
        text: 'Other person.',
      },
      {
        ...ITEMS[0],
        id: 'it_00000000-0000-7a85-8cdd-896abe379ad8',
        actor: { kind: 'user', id: 'usr_00000000-0000-7838-b1bf-3222f1a8d6a7' },
        text: 'Unknown person.',
      },
      {
        ...ITEMS[0],
        id: 'it_00000000-0000-78cd-bf21-01c4693d8efa',
        actor: {
          kind: 'automation',
          id: 'auto_00000000-0000-7db2-8081-9e80c1ee615a',
          responsibleUserId: 'usr_00000000-0000-7609-aed5-db4b5c95e76c',
        },
        text: 'Scheduled input.',
      },
      ITEMS[1],
      {
        ...ITEMS[1],
        id: 'it_00000000-0000-72dd-9e78-ec589912dbf1',
        turnId: 'tu_00000000-0000-7229-8099-120c4bdc703e',
        text: 'Internal reply.',
      },
    ]);
    const client = makeClient(
      { 'thread.items': vi.fn().mockResolvedValue({ items: messages, nextCursor: null }) },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          viewerUserId,
          participants: [
            { kind: 'user', id: 'usr_00000000-0000-7609-aed5-db4b5c95e76c', displayName: 'Simon' },
            { kind: 'user', id: 'usr_00000000-0000-73d4-904a-d4c4b905df7c', displayName: 'Alex' },
            { kind: 'agent', id: 'agent_codex_host', displayName: 'Codex Agent' },
          ],
          turns: [{ ...COMPLETED_TURN, agentId: 'agent_codex_host' }],
        }),
      }
    );
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    const own = await screen.findByRole('article', {
      name: `Message from Simon${viewerUserId === 'usr_00000000-0000-7609-aed5-db4b5c95e76c' ? ' (You)' : ''}`,
    });
    expect(own).toHaveClass(
      viewerUserId === 'usr_00000000-0000-7609-aed5-db4b5c95e76c' ? 'items-end' : 'items-start'
    );
    expect(within(own).getByRole('img', { name: 'Simon' })).toHaveClass('rounded-full');
    const other = screen.getByRole('article', {
      name: `Message from Alex${viewerUserId === 'usr_00000000-0000-73d4-904a-d4c4b905df7c' ? ' (You)' : ''}`,
    });
    expect(other).toHaveClass(
      viewerUserId === 'usr_00000000-0000-73d4-904a-d4c4b905df7c' ? 'items-end' : 'items-start'
    );
    expect(within(other).getByRole('img', { name: 'Alex' })).toHaveClass('rounded-full');
    expect(
      screen.getByRole('article', { name: 'Message from usr_00000000-0000-7838-b1bf-3222f1a8d6a7' })
    ).toHaveClass('items-start');
    const worker = screen.getByRole('article', { name: 'Message from Codex Agent' });
    expect(within(worker).getByRole('img', { name: 'Codex Agent' })).toHaveClass('rounded-ok');
    expect(
      within(screen.getByRole('article', { name: 'Message from Agent' })).getByText(
        'Internal reply.'
      )
    ).toBeInTheDocument();
    expect(
      within(
        screen.getByRole('article', {
          name: 'Message from auto_00000000-0000-7db2-8081-9e80c1ee615a',
        })
      ).getByText('Scheduled input.')
    ).toBeInTheDocument();
  });

  it('keeps the authoritative title through a failed rename and adopts the retry result', async () => {
    const user = userEvent.setup();
    const firstRename = createDeferred<typeof THREAD>();
    const updateThread = vi
      .fn()
      .mockReturnValueOnce(firstRename.promise)
      .mockResolvedValueOnce({ ...THREAD, name: 'Market map' });
    const client = makeClient({ 'thread.update': updateThread });

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    await user.click(await screen.findByRole('button', { name: 'Rename thread' }));
    const name = screen.getByRole('textbox', { name: 'Thread name' });
    await user.clear(name);
    await user.type(name, 'Market map');
    await user.click(screen.getByRole('button', { name: 'Save' }));

    await waitFor(() =>
      expect(updateThread).toHaveBeenCalledWith({
        workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
        threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
        name: 'Market map',
      })
    );
    expect(screen.getByRole('heading', { name: 'Competitive teardown' })).toBeInTheDocument();

    firstRename.reject(new Error('rename rejected'));
    expect(await screen.findByRole('alert')).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: 'Competitive teardown' })).toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'Try again' }));
    expect(await screen.findByRole('heading', { name: 'Market map' })).toBeInTheDocument();
    expect(updateThread).toHaveBeenCalledTimes(2);
  });

  it('does not project an archive until Core returns the archived thread', async () => {
    const user = userEvent.setup();
    const archiveResult = createDeferred<typeof THREAD>();
    const archiveThread = vi.fn().mockReturnValue(archiveResult.promise);
    const client = makeClient({ 'thread.archive': archiveThread });

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    await user.click(await screen.findByRole('button', { name: 'Archive thread' }));
    expect(archiveThread).toHaveBeenCalledWith({
      workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
      threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
    });
    expect(screen.queryByText('Archived')).not.toBeInTheDocument();

    await act(async () => archiveResult.resolve({ ...THREAD, status: 'archived' }));
    expect(await screen.findByText('Archived')).toBeInTheDocument();
  });

  it('does not project interruption until Core returns the interrupted turn', async () => {
    const user = userEvent.setup();
    const interruptResult = createDeferred<Record<string, unknown>>();
    const interruptTurn = vi.fn().mockReturnValue(interruptResult.promise);
    const subscribeTurnEvents = vi.fn().mockReturnValue({
      [Symbol.asyncIterator]() {
        return { next: vi.fn().mockResolvedValue({ value: undefined, done: true }) };
      },
    });
    const client = makeClient(
      { 'turn.interrupt': interruptTurn, subscribeTurnEvents },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          pendingRequests: [
            {
              requestId: 'ap1',
              canRespond: true,
              approvalEffect: {
                status: 'available',
                summary: 'Summary: Approval',
                detail: '{"effect":{"amount":5}}',
              },
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
          turns: [ACTIVE_TURN],
        }),
      }
    );

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    await user.click(await screen.findByRole('button', { name: 'Stop turn' }));
    expect(interruptTurn).toHaveBeenCalledWith({
      workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
      threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
      turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
    });
    expect(screen.queryByText('Interrupted')).not.toBeInTheDocument();

    await act(async () =>
      interruptResult.resolve(
        TurnSchema.parse({
          ...ACTIVE_TURN,
          status: 'interrupted',
          completedAt: '2026-07-21T00:00:03.000Z',
          durationMs: 3_000,
        })
      )
    );
    expect(await screen.findByText('Interrupted')).toBeInTheDocument();
  });

  it.each([
    'rename',
    'archive',
    'interrupt',
  ] as const)('keeps a pending %s command bound to its original workspace owner', async (command) => {
    const user = userEvent.setup();
    const pending = createDeferred<unknown>();
    const mutation = vi.fn().mockReturnValue(pending.promise);
    const workspaceBThread = {
      ...THREAD,
      workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
      name: 'Workspace B teardown',
      preview: 'Workspace B teardown',
    };
    const workspaceBTurn = TurnSchema.parse({
      ...ACTIVE_TURN,
      workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
      triggerActor: { kind: 'user', id: 'usr_00000000-0000-7e1a-82fc-aa295bc43d6c' },
    });
    const subscribeTurnEvents = vi.fn().mockReturnValue({
      [Symbol.asyncIterator]() {
        return { next: vi.fn().mockResolvedValue({ value: undefined, done: true }) };
      },
    });
    const method =
      command === 'rename'
        ? 'thread.update'
        : command === 'archive'
          ? 'thread.archive'
          : 'turn.interrupt';
    const client = makeClient(
      {
        [method]: mutation,
        'thread.read': vi
          .fn()
          .mockImplementation(({ workspaceId }: { workspaceId: string; threadId?: string }) =>
            Promise.resolve(
              workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6' ? workspaceBThread : THREAD
            )
          ),
        'thread.list': vi.fn().mockImplementation(({ workspaceId }: { workspaceId: string }) =>
          Promise.resolve({
            items: [
              workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6' ? workspaceBThread : THREAD,
            ],
          })
        ),
        'thread.items': vi
          .fn()
          .mockImplementation(({ workspaceId }: { workspaceId: string; threadId?: string }) =>
            Promise.resolve({
              items: workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6' ? [] : ITEMS,
              nextCursor: null,
            })
          ),
        subscribeTurnEvents,
      },
      {
        'thread.dashboard': vi
          .fn()
          .mockImplementation(({ workspaceId }: { workspaceId: string; threadId?: string }) =>
            Promise.resolve({
              turns: [
                workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6'
                  ? workspaceBTurn
                  : ACTIVE_TURN,
              ],
            })
          ),
      }
    );
    const queryClient = renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    if (command === 'rename') {
      await user.click(await screen.findByRole('button', { name: 'Rename thread' }));
      const name = screen.getByRole('textbox', { name: 'Thread name' });
      await user.clear(name);
      await user.type(name, 'Workspace A renamed');
      await user.click(screen.getByRole('button', { name: 'Save' }));
    } else {
      await user.click(
        await screen.findByRole('button', {
          name: command === 'archive' ? 'Archive thread' : 'Stop turn',
        })
      );
    }

    const expectedArgs =
      command === 'rename'
        ? {
            workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
            threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
            name: 'Workspace A renamed',
          }
        : command === 'archive'
          ? {
              workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
              threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
            }
          : {
              workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
              threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
              turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
            };
    await waitFor(() => expect(mutation).toHaveBeenCalledWith(expectedArgs));

    await switchToThread(user, 'Market research', 'Second workspace', 'Workspace B teardown');
    expect(
      await screen.findByRole('heading', { name: 'Workspace B teardown' })
    ).toBeInTheDocument();

    const workspaceAResult =
      command === 'rename'
        ? { ...THREAD, name: 'Workspace A renamed' }
        : command === 'archive'
          ? { ...THREAD, status: 'archived' }
          : TurnSchema.parse({
              ...ACTIVE_TURN,
              status: 'interrupted',
              completedAt: '2026-07-21T00:00:03.000Z',
              durationMs: 3_000,
            });
    await act(async () => {
      pending.resolve(workspaceAResult);
      await pending.promise;
    });

    if (command === 'interrupt') {
      expect(
        queryClient.getQueryData<{ turns: (typeof workspaceBTurn)[] }>(
          chatKeys.dashboard(
            'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
            'th_00000000-0000-70a0-9cde-4561f64881c6'
          )
        )?.turns[0]
      ).toEqual(workspaceBTurn);
      expect(screen.queryByText('Interrupted')).not.toBeInTheDocument();
    } else {
      expect(
        queryClient.getQueryData(
          chatKeys.thread(
            'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
            'th_00000000-0000-70a0-9cde-4561f64881c6'
          )
        )
      ).toEqual(workspaceBThread);
      expect(screen.queryByText('Archived')).not.toBeInTheDocument();
    }
    expect(screen.getByRole('heading', { name: 'Workspace B teardown' })).toBeInTheDocument();
  });

  it.each([
    ['rename', 'before'],
    ['rename', 'after'],
    ['archive', 'before'],
    ['archive', 'after'],
    ['interrupt', 'before'],
    ['interrupt', 'after'],
  ] as const)('keeps concurrent %s failures and retries owner-bound when B settles %s A retry', async (command, workspaceBSettlement) => {
    // Null delay skips the per-keystroke timer. A loaded runner otherwise spends the 10s test
    // budget on those waits before the owner-bound retry is reached.
    const user = userEvent.setup({ delay: null });
    const workspaceARequest = createDeferred<unknown>();
    const workspaceBRequest = createDeferred<unknown>();
    const workspaceBThread = {
      ...THREAD,
      workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
      name: 'Workspace B teardown',
      preview: 'Workspace B teardown',
    };
    const workspaceBTurn = TurnSchema.parse({
      ...ACTIVE_TURN,
      workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
      triggerActor: { kind: 'user', id: 'usr_00000000-0000-7e1a-82fc-aa295bc43d6c' },
    });
    const workspaceAResult =
      command === 'rename'
        ? { ...THREAD, name: 'Workspace A renamed' }
        : command === 'archive'
          ? { ...THREAD, status: 'archived' }
          : TurnSchema.parse({
              ...ACTIVE_TURN,
              status: 'interrupted',
              completedAt: '2026-07-21T00:00:03.000Z',
              durationMs: 3_000,
            });
    const workspaceBResult =
      command === 'rename'
        ? { ...workspaceBThread, name: 'Workspace B renamed' }
        : command === 'archive'
          ? { ...workspaceBThread, status: 'archived' }
          : TurnSchema.parse({
              ...workspaceBTurn,
              status: 'interrupted',
              completedAt: '2026-07-21T00:00:03.000Z',
              durationMs: 3_000,
            });
    let workspaceACallCount = 0;
    const mutation = vi.fn((input: { workspaceId: string }) => {
      if (input.workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6')
        return workspaceBRequest.promise;
      workspaceACallCount += 1;
      return workspaceACallCount === 1
        ? workspaceARequest.promise
        : Promise.resolve(workspaceAResult);
    });
    const subscribeTurnEvents = vi.fn().mockReturnValue({
      [Symbol.asyncIterator]() {
        return { next: vi.fn().mockResolvedValue({ value: undefined, done: true }) };
      },
    });
    const method =
      command === 'rename'
        ? 'thread.update'
        : command === 'archive'
          ? 'thread.archive'
          : 'turn.interrupt';
    const client = makeClient(
      {
        [method]: mutation,
        'thread.read': vi
          .fn()
          .mockImplementation(({ workspaceId }: { workspaceId: string; threadId?: string }) =>
            Promise.resolve(
              workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6' ? workspaceBThread : THREAD
            )
          ),
        'thread.list': vi.fn().mockImplementation(({ workspaceId }: { workspaceId: string }) =>
          Promise.resolve({
            items: [
              workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6' ? workspaceBThread : THREAD,
            ],
          })
        ),
        'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
        subscribeTurnEvents,
      },
      {
        'thread.dashboard': vi
          .fn()
          .mockImplementation(({ workspaceId }: { workspaceId: string; threadId?: string }) =>
            Promise.resolve({
              turns: [
                workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6'
                  ? workspaceBTurn
                  : ACTIVE_TURN,
              ],
            })
          ),
      }
    );

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    if (command === 'rename') {
      await user.click(await screen.findByRole('button', { name: 'Rename thread' }));
      const name = screen.getByRole('textbox', { name: 'Thread name' });
      await user.clear(name);
      await user.type(name, 'Workspace A renamed');
      await user.click(screen.getByRole('button', { name: 'Save' }));
    } else {
      await user.click(
        await screen.findByRole('button', {
          name: command === 'archive' ? 'Archive thread' : 'Stop turn',
        })
      );
    }

    const workspaceAArgs =
      command === 'rename'
        ? {
            workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
            threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
            name: 'Workspace A renamed',
          }
        : command === 'archive'
          ? {
              workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
              threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
            }
          : {
              workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
              threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
              turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
            };
    await waitFor(() => expect(mutation).toHaveBeenCalledWith(workspaceAArgs));

    await switchToThread(user, 'Market research', 'Second workspace', 'Workspace B teardown');
    expect(
      await screen.findByRole('heading', { name: 'Workspace B teardown' })
    ).toBeInTheDocument();

    if (command === 'rename') {
      await user.click(screen.getByRole('button', { name: 'Rename thread' }));
      const name = screen.getByRole('textbox', { name: 'Thread name' });
      await user.clear(name);
      await user.type(name, 'Workspace B renamed');
      await user.click(screen.getByRole('button', { name: 'Save' }));
    } else {
      await user.click(
        screen.getByRole('button', {
          name: command === 'archive' ? 'Archive thread' : 'Stop turn',
        })
      );
    }

    const workspaceBArgs =
      command === 'rename'
        ? {
            workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
            threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
            name: 'Workspace B renamed',
          }
        : command === 'archive'
          ? {
              workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
              threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
            }
          : {
              workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
              threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
              turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
            };
    await waitFor(() => expect(mutation).toHaveBeenCalledWith(workspaceBArgs));

    await act(async () => {
      workspaceARequest.reject(new Error(`workspace A ${command} rejected`));
      await workspaceARequest.promise.catch(() => undefined);
    });
    if (workspaceBSettlement === 'before') {
      await act(async () => {
        workspaceBRequest.resolve(workspaceBResult);
        await workspaceBRequest.promise;
      });
      if (command === 'rename') {
        expect(await screen.findByRole('heading', { name: 'Workspace B renamed' })).toBeVisible();
      } else if (command === 'archive') {
        expect(await screen.findByText('Archived')).toBeInTheDocument();
      } else {
        expect(await screen.findByText('Interrupted')).toBeInTheDocument();
      }
    }
    await switchToThread(user, 'Second workspace', 'Market research', 'Competitive teardown');
    expect(
      await screen.findByRole('heading', { name: 'Competitive teardown' })
    ).toBeInTheDocument();

    const alert = await screen.findByRole('alert');
    expect(alert).toHaveTextContent(
      command === 'rename'
        ? "Couldn't rename this thread."
        : command === 'archive'
          ? "Couldn't archive this thread."
          : "Couldn't stop this turn."
    );
    await user.click(screen.getByRole('button', { name: 'Try again' }));
    await waitFor(() => expect(mutation).toHaveBeenCalledTimes(3));
    expect(mutation).toHaveBeenNthCalledWith(1, workspaceAArgs);
    expect(mutation).toHaveBeenNthCalledWith(2, workspaceBArgs);
    expect(mutation).toHaveBeenNthCalledWith(3, workspaceAArgs);
    await waitFor(() => expect(screen.queryByRole('alert')).not.toBeInTheDocument());

    if (command === 'rename') {
      expect(await screen.findByRole('heading', { name: 'Workspace A renamed' })).toBeVisible();
    } else if (command === 'archive') {
      expect(await screen.findByText('Archived')).toBeInTheDocument();
    } else {
      expect(await screen.findByText('Interrupted')).toBeInTheDocument();
    }

    if (workspaceBSettlement === 'after') {
      await switchToThread(user, 'Market research', 'Second workspace', 'Workspace B teardown');
      expect(screen.queryByRole('alert')).not.toBeInTheDocument();
      if (command !== 'rename') {
        expect(
          await screen.findByRole('button', {
            name: command === 'archive' ? 'Archive thread' : 'Stop turn',
          })
        ).toBeDisabled();
      }

      await act(async () => {
        workspaceBRequest.resolve(workspaceBResult);
        await workspaceBRequest.promise;
      });
      if (command === 'rename') {
        expect(await screen.findByRole('heading', { name: 'Workspace B renamed' })).toBeVisible();
      } else if (command === 'archive') {
        expect(await screen.findByText('Archived')).toBeInTheDocument();
      } else {
        expect(await screen.findByText('Interrupted')).toBeInTheDocument();
      }
    }
  });

  it('does not attach a rejected interrupt history to a newer active turn', async () => {
    const user = userEvent.setup();
    const secondInterrupt = createDeferred<unknown>();
    const interruptTurn = vi
      .fn()
      .mockRejectedValueOnce(new Error('t1 interrupt rejected'))
      .mockReturnValueOnce(secondInterrupt.promise);
    const secondActiveTurn = TurnSchema.parse({
      ...ACTIVE_TURN,
      id: 'tu_00000000-0000-7229-8099-120c4bdc703e',
      startedAt: '2026-07-21T00:00:04.000Z',
    });
    const subscribeTurnEvents = vi.fn().mockReturnValue({
      [Symbol.asyncIterator]() {
        return { next: vi.fn().mockResolvedValue({ value: undefined, done: true }) };
      },
    });
    const client = makeClient(
      { 'turn.interrupt': interruptTurn, subscribeTurnEvents },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          pendingRequests: [
            {
              requestId: 'ap1',
              canRespond: true,
              approvalEffect: {
                status: 'available',
                summary: 'Summary: Approval',
                detail: '{"effect":{"amount":5}}',
              },
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
          turns: [ACTIVE_TURN],
        }),
      }
    );
    const queryClient = renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    await user.click(await screen.findByRole('button', { name: 'Stop turn' }));
    expect(await screen.findByRole('alert')).toHaveTextContent("Couldn't stop this turn.");
    expect(interruptTurn).toHaveBeenNthCalledWith(1, {
      workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
      threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
      turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
    });

    act(() =>
      queryClient.setQueryData(
        chatKeys.dashboard(
          'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          'th_00000000-0000-70a0-9cde-4561f64881c6'
        ),
        {
          turns: [COMPLETED_TURN, secondActiveTurn],
        }
      )
    );

    await waitFor(() => expect(screen.queryByRole('alert')).not.toBeInTheDocument());
    expect(screen.queryByRole('button', { name: 'Try again' })).not.toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'Stop turn' }));
    expect(interruptTurn).toHaveBeenNthCalledWith(2, {
      workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
      threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
      turnId: 'tu_00000000-0000-7229-8099-120c4bdc703e',
    });
  });

  it('never submits a rename draft to a newly selected workspace owner', async () => {
    const user = userEvent.setup();
    const updateThread = vi.fn().mockResolvedValue(THREAD);
    const workspaceBThread = {
      ...THREAD,
      workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
      name: 'Workspace B teardown',
      preview: 'Workspace B teardown',
    };
    const client = makeClient({
      'thread.update': updateThread,
      'thread.read': vi
        .fn()
        .mockImplementation(({ workspaceId }: { workspaceId: string; threadId?: string }) =>
          Promise.resolve(
            workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6' ? workspaceBThread : THREAD
          )
        ),
    });

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    await user.click(await screen.findByRole('button', { name: 'Rename thread' }));
    const name = screen.getByRole('textbox', { name: 'Thread name' });
    await user.clear(name);
    await user.type(name, 'Workspace A draft');

    await user.click(await workspaceSelectTrigger('Market research'));
    await user.click(await screen.findByRole('menuitem', { name: 'Second workspace' }));
    expect(
      await screen.findByRole('heading', { name: 'What can we get done?' })
    ).toBeInTheDocument();

    const save = screen.queryByRole('button', { name: 'Save' });
    if (save) await user.click(save);
    expect(updateThread).not.toHaveBeenCalledWith({
      workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
      threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
      name: 'Workspace A draft',
    });
    expect(updateThread).not.toHaveBeenCalled();
  });

  it('keeps the active thread visible and retries the exact rejected archive command', async () => {
    const user = userEvent.setup();
    const archiveThread = vi
      .fn()
      .mockRejectedValueOnce(new Error('archive rejected'))
      .mockResolvedValueOnce({ ...THREAD, status: 'archived' });
    const client = makeClient({ 'thread.archive': archiveThread });

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    await user.click(await screen.findByRole('button', { name: 'Archive thread' }));

    const alert = await screen.findByRole('alert');
    expect(alert).toHaveTextContent("Couldn't archive this thread.");
    expect(screen.getByRole('heading', { name: 'Competitive teardown' })).toBeInTheDocument();
    expect(screen.queryByText('Archived')).not.toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'Try again' }));
    await waitFor(() => expect(archiveThread).toHaveBeenCalledTimes(2));
    expect(archiveThread).toHaveBeenNthCalledWith(1, {
      workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
      threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
    });
    expect(archiveThread).toHaveBeenNthCalledWith(2, {
      workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
      threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
    });
    expect(await screen.findByText('Archived')).toBeInTheDocument();
  });

  it('keeps the running turn visible and retries the exact rejected interrupt command', async () => {
    const user = userEvent.setup();
    const interruptedTurn = TurnSchema.parse({
      ...ACTIVE_TURN,
      status: 'interrupted',
      completedAt: '2026-07-21T00:00:03.000Z',
      durationMs: 3_000,
    });
    const interruptTurn = vi
      .fn()
      .mockRejectedValueOnce(new Error('interrupt rejected'))
      .mockResolvedValueOnce(interruptedTurn);
    const subscribeTurnEvents = vi.fn().mockReturnValue({
      [Symbol.asyncIterator]() {
        return { next: vi.fn().mockResolvedValue({ value: undefined, done: true }) };
      },
    });
    const client = makeClient(
      { 'turn.interrupt': interruptTurn, subscribeTurnEvents },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          pendingRequests: [
            {
              requestId: 'ap1',
              canRespond: true,
              approvalEffect: {
                status: 'available',
                summary: 'Summary: Approval',
                detail: '{"effect":{"amount":5}}',
              },
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
          turns: [ACTIVE_TURN],
        }),
      }
    );

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    await user.click(await screen.findByRole('button', { name: 'Stop turn' }));

    const alert = await screen.findByRole('alert');
    expect(alert).toHaveTextContent("Couldn't stop this turn.");
    expect(screen.getByRole('button', { name: 'Stop turn' })).toBeInTheDocument();
    expect(screen.queryByText('Interrupted')).not.toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'Try again' }));
    await waitFor(() => expect(interruptTurn).toHaveBeenCalledTimes(2));
    const args = {
      workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
      threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
      turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
    };
    expect(interruptTurn).toHaveBeenNthCalledWith(1, args);
    expect(interruptTurn).toHaveBeenNthCalledWith(2, args);
    expect(await screen.findByText('Interrupted')).toBeInTheDocument();
  });

  it.each([
    ['local', 'usr_00000000-0000-7000-8000-000000000001'],
    ['server', 'usr_00000000-0000-7c6a-be9d-0973844c8526'],
  ])('renders the exact %s user-message actor without deployment-mode probing', async (_, actorId) => {
    const setupDiagnosticsOperation = vi.fn().mockRejectedValue(new Error('must not be called'));
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({
          items: [{ ...ITEMS[0], actor: { kind: 'user', id: actorId } }],
          nextCursor: null,
        }),
      },
      { 'diagnostics.setup': setupDiagnosticsOperation }
    );

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    expect(await screen.findByText(new RegExp(actorId))).toBeInTheDocument();
    expect(setupDiagnosticsOperation).not.toHaveBeenCalled();
  });

  it('renders the exact actors on approval decisions and user-input responses', async () => {
    const client = makeClient({
      'thread.items': vi.fn().mockResolvedValue({
        items: ItemSchema.array().parse([
          {
            id: 'it_00000000-0000-799d-8511-6b79b6446a1d',
            workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
            threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
            type: 'approval-decision',
            turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
            status: 'completed',
            actor: { kind: 'user', id: 'usr_00000000-0000-7a12-a95f-975ecdd21953' },
            causationId: 'req_approval',
            approvalRequestId: 'ap1',
            decision: 'granted',
            decidedAt: '2026-07-21T00:00:03.000Z',
            createdAt: '2026-07-21T00:00:03.000Z',
            completedAt: '2026-07-21T00:00:03.000Z',
          },
          {
            id: 'it_00000000-0000-7ac7-8058-2f2d482b7437',
            workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
            threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
            type: 'user-input-response',
            turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
            status: 'completed',
            actor: { kind: 'user', id: 'usr_00000000-0000-7580-8c3b-db9da7a361ae' },
            causationId: 'req_response',
            userInputRequestId: 'input1',
            answers: { question1: ['Yes'] },
            answeredAt: '2026-07-21T00:00:04.000Z',
            createdAt: '2026-07-21T00:00:04.000Z',
            completedAt: '2026-07-21T00:00:04.000Z',
          },
        ]),
        nextCursor: null,
      }),
    });

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    expect(
      await screen.findByText('by usr_00000000-0000-7a12-a95f-975ecdd21953')
    ).toBeInTheDocument();
    expect(screen.getByText(/usr_00000000-0000-7580-8c3b-db9da7a361ae/)).toBeInTheDocument();
  });

  it('renders the exact active-turn trigger actor from the typed dashboard projection', async () => {
    const setupDiagnosticsOperation = vi.fn().mockRejectedValue(new Error('must not be called'));
    const subscribeTurnEvents = vi.fn().mockReturnValue({
      [Symbol.asyncIterator]() {
        return { next: vi.fn().mockResolvedValue({ value: undefined, done: true }) };
      },
    });
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
        subscribeTurnEvents,
      },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          turns: [
            TurnSchema.parse({
              ...ACTIVE_TURN,
              triggerActor: {
                kind: 'automation',
                id: 'auto_00000000-0000-77df-8c37-4f4fdb2227b8',
                responsibleUserId: 'usr_00000000-0000-7968-a053-ad9e71464afe',
              },
            }),
          ],
        }),
        'diagnostics.setup': setupDiagnosticsOperation,
      }
    );

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    expect(
      await screen.findByText(/auto_00000000-0000-77df-8c37-4f4fdb2227b8/)
    ).toBeInTheDocument();
    expect(setupDiagnosticsOperation).not.toHaveBeenCalled();
  });

  it.each([
    {
      label: 'matching viewer',
      triggerActor: { kind: 'user' as const, id: 'usr_00000000-0000-768a-8658-44c33d82c1f5' },
      expected: 'Triggered by Administrator (You)',
      unexpected: ['usr_00000000-0000-768a-8658-44c33d82c1f5'],
    },
    {
      label: 'automation sharing a User UUID body',
      triggerActor: {
        kind: 'automation' as const,
        id: 'auto_00000000-0000-768a-8658-44c33d82c1f5',
        responsibleUserId: 'usr_00000000-0000-768a-8658-44c33d82c1f5',
      },
      expected: 'Triggered by auto_00000000-0000-768a-8658-44c33d82c1f5',
      unexpected: ['Administrator', '(You)'],
    },
  ])('resolves the running Task trigger for a $label without borrowing another kind', async ({
    triggerActor,
    expected,
    unexpected,
  }) => {
    const subscribeTurnEvents = vi.fn().mockReturnValue({
      [Symbol.asyncIterator]() {
        return { next: vi.fn().mockResolvedValue({ value: undefined, done: true }) };
      },
    });
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
        subscribeTurnEvents,
      },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          pendingRequests: [
            {
              requestId: 'uir1',
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
          viewerUserId: 'usr_00000000-0000-768a-8658-44c33d82c1f5',
          participants: [
            {
              kind: 'user',
              id: 'usr_00000000-0000-768a-8658-44c33d82c1f5',
              displayName: 'Administrator',
            },
          ],
          turns: [TurnSchema.parse({ ...ACTIVE_TURN, triggerActor })],
        }),
      }
    );

    renderApp(
      '/tasks/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    expect(await screen.findByText(expected)).toBeInTheDocument();
    for (const value of unexpected) {
      expect(screen.queryByText(new RegExp(value))).not.toBeInTheDocument();
    }
  });

  it('leaves an intentionally actorless assistant item without an inferred actor label', async () => {
    const client = makeClient({
      'thread.items': vi.fn().mockResolvedValue({ items: [ITEMS[1]], nextCursor: null }),
    });

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    expect(await screen.findByText('On it — gathering the details.')).toBeInTheDocument();
    expect(screen.queryByText(/^by\s/)).not.toBeInTheDocument();
  });
});

describe('live turn subscription (S6)', () => {
  it('refreshes a newly arriving author even with a cached dashboard', async () => {
    const dashboard = {
      viewerUserId: 'usr_00000000-0000-7609-aed5-db4b5c95e76c',
      participants: [],
      pendingRequests: [
        {
          requestId: 'ap1',
          canRespond: true,
          approvalEffect: {
            status: 'available',
            summary: 'Summary: Approval',
            detail: '{"effect":{"amount":5}}',
          },
          state: 'pending',
          resolution: null,
          ending: null,
          disposition: null,
        },
      ],
      turns: [ACTIVE_TURN],
    };
    const getThreadDashboard = vi
      .fn()
      .mockResolvedValueOnce(dashboard)
      .mockResolvedValue({
        ...dashboard,
        participants: [
          { kind: 'user', id: 'usr_00000000-0000-73d4-904a-d4c4b905df7c', displayName: 'Alex' },
        ],
      });
    async function* stream() {
      yield turnStreamEvent(1, 'item.created', {
        type: 'item-created',
        item: {
          ...ITEMS[0],
          id: 'it_00000000-0000-71e7-aa1f-57ab2b827ff6',
          actor: { kind: 'user', id: 'usr_00000000-0000-73d4-904a-d4c4b905df7c' },
          text: 'New participant.',
        },
      });
    }
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: [], nextCursor: null }),
        subscribeTurnEvents: vi.fn().mockReturnValue(stream()),
      },
      { 'thread.dashboard': getThreadDashboard }
    );
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    const message = await screen.findByRole('article', { name: 'Message from Alex' });
    expect(message).toHaveClass('items-start');
    expect(within(message).getByText('New participant.')).toBeInTheDocument();
    expect(getThreadDashboard).toHaveBeenCalledTimes(2);
  });

  it.each([
    'send',
    'approval',
  ] as const)('refreshes the dashboard and subscribes once after a successful %s command', async (command) => {
    const user = userEvent.setup();
    const submitConversation = vi.fn().mockResolvedValue(CHAT_MODE_RESPONSE);
    const respondApproval = vi.fn().mockResolvedValue({});
    const getThreadDashboard = vi
      .fn()
      .mockResolvedValueOnce({
        pendingRequests: [
          {
            requestId: 'ap1',
            canRespond: true,
            approvalEffect: {
              status: 'available',
              summary: 'Summary: Approval',
              detail: '{"effect":{"amount":5}}',
            },
            state: 'pending',
            resolution: null,
            ending: null,
            disposition: null,
          },
        ],
        turns: command === 'approval' ? [APPROVAL_TURN] : [],
      })
      .mockResolvedValue({
        pendingRequests: [
          {
            requestId: 'ap1',
            canRespond: true,
            approvalEffect: {
              status: 'available',
              summary: 'Summary: Approval',
              detail: '{"effect":{"amount":5}}',
            },
            state: 'pending',
            resolution: null,
            ending: null,
            disposition: null,
          },
        ],
        turns: [ACTIVE_TURN],
      });
    const subscribeTurnEvents = vi.fn().mockReturnValue({
      [Symbol.asyncIterator]() {
        return {
          next: () => new Promise(() => {}),
          return: vi.fn().mockResolvedValue({ value: undefined, done: true }),
        };
      },
    });
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
        'approval.respond': respondApproval,
        subscribeTurnEvents,
      },
      { 'thread.dashboard': getThreadDashboard, 'conversation.submit': submitConversation }
    );

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    await waitFor(() => expect(getThreadDashboard).toHaveBeenCalledTimes(1));

    if (command === 'send') {
      await user.type(screen.getByRole('textbox', { name: 'Message' }), 'Start fresh work');
      await user.click(screen.getByRole('button', { name: 'Send message' }));
      await waitFor(() => expect(submitConversation).toHaveBeenCalledTimes(1));
    } else {
      await user.click(await screen.findByRole('button', { name: 'Approve' }));
      await waitFor(() => expect(respondApproval).toHaveBeenCalledTimes(1));
    }

    await waitFor(() => expect(getThreadDashboard).toHaveBeenCalledTimes(2));
    await waitFor(() =>
      expect(subscribeTurnEvents).toHaveBeenCalledWith({
        workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
        threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
        turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
      })
    );
    expect(subscribeTurnEvents).toHaveBeenCalledTimes(1);
  });

  it('folds an already-running turn into the thread cache without refetching', async () => {
    let releaseDelta!: () => void;
    let releaseCompletion!: () => void;
    const waitForDelta = new Promise<void>((resolve) => {
      releaseDelta = resolve;
    });
    const waitForCompletion = new Promise<void>((resolve) => {
      releaseCompletion = resolve;
    });
    async function* stream() {
      yield turnStreamEvent(1, 'item.created', {
        type: 'item-created',
        item: STREAMING_ITEM,
      });
      await waitForDelta;
      yield turnStreamEvent(2, 'item.delta', {
        type: 'item-delta',
        itemId: STREAMING_ITEM.id,
        itemType: STREAMING_ITEM.type,
        deltaKind: 'text-delta',
        delta: 'Streaming live',
      });
      await waitForCompletion;
      yield turnStreamEvent(3, 'item.completed', {
        type: 'item-completed',
        itemId: STREAMING_ITEM.id,
        item: {
          ...STREAMING_ITEM,
          status: 'completed',
          text: 'Authoritative final',
          completedAt: '2026-07-21T00:00:02.000Z',
        },
      });
      yield turnStreamEvent(4, 'turn.completed', {
        type: 'turn-completed',
        stopReason: 'completed',
        turn: { ...ACTIVE_TURN, status: 'completed' },
      });
    }

    const listThreadItems = vi.fn().mockResolvedValue({
      items: [ITEMS[0]],
      nextCursor: null,
    });
    const subscribeTurnEvents = vi.fn().mockReturnValue(stream());
    const client = makeClient(
      { 'thread.items': listThreadItems, subscribeTurnEvents },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          pendingRequests: [
            {
              requestId: 'ap1',
              canRespond: true,
              approvalEffect: {
                status: 'available',
                summary: 'Summary: Approval',
                detail: '{"effect":{"amount":5}}',
              },
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
          turns: [ACTIVE_TURN],
        }),
      }
    );

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    await waitFor(() =>
      expect(subscribeTurnEvents).toHaveBeenCalledWith(
        expect.objectContaining({
          workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
          turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
        })
      )
    );
    releaseDelta();
    expect(await screen.findByText('Streaming live')).toBeInTheDocument();

    releaseCompletion();
    expect(await screen.findByText('Authoritative final')).toBeInTheDocument();
    expect(screen.queryByText('Streaming live')).not.toBeInTheDocument();
    expect(screen.getAllByText('Authoritative final')).toHaveLength(1);
    expect(listThreadItems).toHaveBeenCalledTimes(1);
  });

  it('projects authoritative turn completion into active controls and feedback', async () => {
    const completion = createDeferred<void>();
    async function* stream() {
      await completion.promise;
      yield turnStreamEvent(1, 'turn.completed', {
        type: 'turn-completed',
        stopReason: 'completed',
        turn: COMPLETED_TURN,
      });
    }

    const subscribeTurnEvents = vi.fn().mockReturnValue(stream());
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
        subscribeTurnEvents,
      },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          pendingRequests: [
            {
              requestId: 'ap1',
              canRespond: true,
              approvalEffect: {
                status: 'available',
                summary: 'Summary: Approval',
                detail: '{"effect":{"amount":5}}',
              },
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
          turns: [ACTIVE_TURN],
        }),
      }
    );
    const queryClient = renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    expect(await screen.findByRole('button', { name: 'Stop turn' })).toBeInTheDocument();
    await waitFor(() => expect(subscribeTurnEvents).toHaveBeenCalledTimes(1));
    expect(screen.queryByRole('button', { name: 'Good' })).not.toBeInTheDocument();

    await act(async () => completion.resolve());

    await waitFor(() =>
      expect(
        queryClient.getQueryData<Pick<ThreadDashboardResponse, 'turns' | 'pendingRequests'>>(
          chatKeys.dashboard(
            'ws_00000000-0000-7b10-9af8-12fd37a880e0',
            'th_00000000-0000-70a0-9cde-4561f64881c6'
          )
        )?.turns
      ).toEqual([COMPLETED_TURN])
    );
    expect(screen.queryByRole('button', { name: 'Stop turn' })).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Good' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Bad' })).toBeInTheDocument();
  });

  it.each([
    ['completed', 'completed'],
    ['interrupted', 'aborted'],
    ['cancelled', 'aborted'],
    ['failed', 'error'],
  ] as const)('projects an authoritative %s Turn without touching the items cache', async (status, stopReason) => {
    const release = createDeferred<void>();
    const processed = createDeferred<void>();
    const terminalTurn = TurnSchema.parse({ ...COMPLETED_TURN, status });
    async function* stream() {
      await release.promise;
      yield turnStreamEvent(1, 'turn.completed', {
        type: 'turn-completed',
        stopReason,
        turn: terminalTurn,
      });
      processed.resolve();
    }

    const subscribeTurnEvents = vi.fn().mockReturnValue(stream());
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
        subscribeTurnEvents,
      },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          pendingRequests: [
            {
              requestId: 'ap1',
              canRespond: true,
              approvalEffect: {
                status: 'available',
                summary: 'Summary: Approval',
                detail: '{"effect":{"amount":5}}',
              },
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
          turns: [ACTIVE_TURN],
        }),
      }
    );
    const itemsKey = chatKeys.items(
      'ws_00000000-0000-7b10-9af8-12fd37a880e0',
      'th_00000000-0000-70a0-9cde-4561f64881c6'
    );
    const dashboardKey = chatKeys.dashboard(
      'ws_00000000-0000-7b10-9af8-12fd37a880e0',
      'th_00000000-0000-70a0-9cde-4561f64881c6'
    );
    const queryClient = renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client,
      (cache) => {
        cache.setQueryDefaults(itemsKey, { staleTime: Number.POSITIVE_INFINITY });
        cache.setQueryData(itemsKey, ITEMS, { updatedAt: 1 });
      }
    );

    expect(await screen.findByRole('button', { name: 'Stop turn' })).toBeInTheDocument();
    await waitFor(() => expect(subscribeTurnEvents).toHaveBeenCalledTimes(1));
    const initialItems = queryClient.getQueryData(itemsKey);
    const initialItemsUpdatedAt = queryClient.getQueryState(itemsKey)?.dataUpdatedAt;
    const cancelQueries = vi.spyOn(queryClient, 'cancelQueries');

    await act(async () => {
      release.resolve();
      await processed.promise;
    });

    expect.soft(queryClient.getQueryData(dashboardKey)).toEqual({
      pendingRequests: [
        {
          requestId: 'ap1',
          canRespond: true,
          approvalEffect: {
            status: 'available',
            summary: 'Summary: Approval',
            detail: '{"effect":{"amount":5}}',
          },
          state: 'pending',
          resolution: null,
          ending: null,
          disposition: null,
        },
      ],
      turns: [terminalTurn],
    });
    expect.soft(cancelQueries).toHaveBeenCalledTimes(1);
    expect.soft(cancelQueries).toHaveBeenCalledWith({ queryKey: dashboardKey, exact: true });
    expect.soft(cancelQueries).not.toHaveBeenCalledWith({ queryKey: itemsKey, exact: true });
    expect.soft(queryClient.getQueryData(itemsKey)).toEqual(initialItems);
    expect.soft(queryClient.getQueryState(itemsKey)?.dataUpdatedAt).toBe(initialItemsUpdatedAt);
  });

  it('streams over a fresh authoritative cache without starting a baseline refetch', async () => {
    let releaseCompletion!: () => void;
    const waitForCompletion = new Promise<void>((resolve) => {
      releaseCompletion = resolve;
    });
    async function* stream() {
      yield turnStreamEvent(1, 'item.created', {
        type: 'item-created',
        item: STREAMING_ITEM,
      });
      yield turnStreamEvent(2, 'item.delta', {
        type: 'item-delta',
        itemId: STREAMING_ITEM.id,
        itemType: STREAMING_ITEM.type,
        deltaKind: 'text-delta',
        delta: 'Fresh-cache live text',
      });
      await waitForCompletion;
      yield turnStreamEvent(3, 'item.completed', {
        type: 'item-completed',
        itemId: STREAMING_ITEM.id,
        item: {
          ...STREAMING_ITEM,
          status: 'completed',
          text: 'Authoritative fresh-cache result',
          completedAt: '2026-07-21T00:00:02.000Z',
        },
      });
    }

    const listThreadItems = vi.fn().mockResolvedValue({ items: [], nextCursor: null });
    const subscribeTurnEvents = vi.fn().mockReturnValue(stream());
    const client = makeClient(
      { 'thread.items': listThreadItems, subscribeTurnEvents },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          pendingRequests: [
            {
              requestId: 'ap1',
              canRespond: true,
              approvalEffect: {
                status: 'available',
                summary: 'Summary: Approval',
                detail: '{"effect":{"amount":5}}',
              },
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
          turns: [ACTIVE_TURN],
        }),
      }
    );

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client,
      (queryClient) => {
        queryClient.setQueryDefaults(
          chatKeys.items(
            'ws_00000000-0000-7b10-9af8-12fd37a880e0',
            'th_00000000-0000-70a0-9cde-4561f64881c6'
          ),
          { staleTime: 5_000 }
        );
        queryClient.setQueryData(
          chatKeys.items(
            'ws_00000000-0000-7b10-9af8-12fd37a880e0',
            'th_00000000-0000-70a0-9cde-4561f64881c6'
          ),
          [ITEMS[0]]
        );
      }
    );

    expect(await screen.findByText('Draft a competitive teardown.')).toBeInTheDocument();
    expect(listThreadItems).not.toHaveBeenCalled();
    await waitFor(() => expect(subscribeTurnEvents).toHaveBeenCalledTimes(1));
    expect(await screen.findByText('Fresh-cache live text')).toBeInTheDocument();

    releaseCompletion();
    expect(await screen.findByText('Authoritative fresh-cache result')).toBeInTheDocument();
    expect(screen.queryByText('Fresh-cache live text')).not.toBeInTheDocument();
    expect(listThreadItems).not.toHaveBeenCalled();
    expect(subscribeTurnEvents).toHaveBeenCalledTimes(1);
  });

  it('keeps the fresh-cache stream alive while a command refetch catches up', async () => {
    const user = userEvent.setup();
    let resolveStaleItems!: (value: { items: typeof ITEMS; nextCursor: null }) => void;
    let releaseStream!: () => void;
    const staleItems = new Promise<{ items: typeof ITEMS; nextCursor: null }>((resolve) => {
      resolveStaleItems = resolve;
    });
    const streamReady = new Promise<void>((resolve) => {
      releaseStream = resolve;
    });
    /** Emit one completed Item only after the command-owned refetch is in flight. */
    async function* streamDuringRefetch() {
      await streamReady;
      yield turnStreamEvent(1, 'item.created', {
        type: 'item-created',
        item: STREAMING_ITEM,
      });
      yield turnStreamEvent(2, 'item.delta', {
        type: 'item-delta',
        itemId: STREAMING_ITEM.id,
        itemType: STREAMING_ITEM.type,
        deltaKind: 'text-delta',
        delta: 'Command-refetch live text',
      });
      yield turnStreamEvent(3, 'item.completed', {
        type: 'item-completed',
        itemId: STREAMING_ITEM.id,
        item: {
          ...STREAMING_ITEM,
          status: 'completed',
          text: 'Authoritative command-refetch result',
          completedAt: '2026-07-21T00:00:02.000Z',
        },
      });
      await new Promise(() => {});
    }

    const iterator = streamDuringRefetch();
    const returnStream = vi.spyOn(iterator, 'return');
    const listThreadItems = vi.fn().mockReturnValue(staleItems);
    const subscribeTurnEvents = vi.fn().mockReturnValue({
      [Symbol.asyncIterator]: () => iterator,
    });
    const submitConversation = vi.fn().mockResolvedValue(CHAT_MODE_RESPONSE);
    const client = makeClient(
      { 'thread.items': listThreadItems, subscribeTurnEvents },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          pendingRequests: [
            {
              requestId: 'ap1',
              canRespond: true,
              approvalEffect: {
                status: 'available',
                summary: 'Summary: Approval',
                detail: '{"effect":{"amount":5}}',
              },
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
          turns: [ACTIVE_TURN],
        }),
        'conversation.submit': submitConversation,
      }
    );
    const queryClient = renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client,
      (cache) => {
        cache.setQueryDefaults(
          chatKeys.items(
            'ws_00000000-0000-7b10-9af8-12fd37a880e0',
            'th_00000000-0000-70a0-9cde-4561f64881c6'
          ),
          { staleTime: 5_000 }
        );
        cache.setQueryData(
          chatKeys.items(
            'ws_00000000-0000-7b10-9af8-12fd37a880e0',
            'th_00000000-0000-70a0-9cde-4561f64881c6'
          ),
          ITEMS
        );
      }
    );

    expect(await screen.findByText('Draft a competitive teardown.')).toBeInTheDocument();
    expect(listThreadItems).not.toHaveBeenCalled();
    await waitFor(() => expect(subscribeTurnEvents).toHaveBeenCalledTimes(1));

    await user.type(screen.getByRole('textbox', { name: 'Message' }), 'Start fresh work');
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    await waitFor(() => expect(submitConversation).toHaveBeenCalledTimes(1));
    await waitFor(() => expect(listThreadItems).toHaveBeenCalledTimes(1));
    expect(
      queryClient.getQueryState(
        chatKeys.items(
          'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          'th_00000000-0000-70a0-9cde-4561f64881c6'
        )
      )?.fetchStatus
    ).toBe('fetching');
    expect(returnStream).not.toHaveBeenCalled();
    expect(subscribeTurnEvents).toHaveBeenCalledTimes(1);

    releaseStream();
    expect(await screen.findByText('Authoritative command-refetch result')).toBeInTheDocument();
    expect(screen.getAllByText('Authoritative command-refetch result')).toHaveLength(1);

    await act(async () => {
      resolveStaleItems({ items: ITEMS, nextCursor: null });
      await staleItems;
    });
    await waitFor(() => expect(queryClient.isFetching()).toBe(0));

    expect(screen.getAllByText('Authoritative command-refetch result')).toHaveLength(1);
    expect(
      queryClient
        .getQueryData<{ id: string }[]>(
          chatKeys.items(
            'ws_00000000-0000-7b10-9af8-12fd37a880e0',
            'th_00000000-0000-70a0-9cde-4561f64881c6'
          )
        )
        ?.filter((item) => item.id === STREAMING_ITEM.id)
    ).toHaveLength(1);
    expect(returnStream).not.toHaveBeenCalled();
    expect(subscribeTurnEvents).toHaveBeenCalledTimes(1);
  });

  it('keeps a completed streamed item when an older command refetch settles after the stream', async () => {
    const user = userEvent.setup();
    let resolveStaleItems!: (value: { items: typeof ITEMS; nextCursor: null }) => void;
    const staleItems = new Promise<{ items: typeof ITEMS; nextCursor: null }>((resolve) => {
      resolveStaleItems = resolve;
    });
    const listThreadItems = vi
      .fn()
      .mockResolvedValueOnce({ items: ITEMS, nextCursor: null })
      .mockReturnValueOnce(staleItems);
    const getThreadDashboard = vi
      .fn()
      .mockResolvedValueOnce({ turns: [] })
      .mockResolvedValue({
        pendingRequests: [
          {
            requestId: 'ap1',
            canRespond: true,
            approvalEffect: {
              status: 'available',
              summary: 'Summary: Approval',
              detail: '{"effect":{"amount":5}}',
            },
            state: 'pending',
            resolution: null,
            ending: null,
            disposition: null,
          },
        ],
        turns: [ACTIVE_TURN],
      });
    async function* streamThenDrop() {
      yield turnStreamEvent(1, 'item.created', {
        type: 'item-created',
        item: STREAMING_ITEM,
      });
      yield turnStreamEvent(2, 'item.delta', {
        type: 'item-delta',
        itemId: STREAMING_ITEM.id,
        itemType: STREAMING_ITEM.type,
        deltaKind: 'text-delta',
        delta: 'Interleaved live text',
      });
      yield turnStreamEvent(3, 'item.completed', {
        type: 'item-completed',
        itemId: STREAMING_ITEM.id,
        item: {
          ...STREAMING_ITEM,
          status: 'completed',
          text: 'Authoritative interleaved result',
          completedAt: '2026-07-21T00:00:02.000Z',
        },
      });
      throw new Error('stream dropped');
    }
    const subscribeTurnEvents = vi.fn().mockReturnValue(streamThenDrop());
    const client = makeClient(
      {
        'thread.items': listThreadItems,
        subscribeTurnEvents,
      },
      {
        'thread.dashboard': getThreadDashboard,
        'conversation.submit': vi.fn().mockResolvedValue(CHAT_MODE_RESPONSE),
      }
    );

    const queryClient = renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    await screen.findByText('Draft a competitive teardown.');
    await user.type(screen.getByRole('textbox', { name: 'Message' }), 'Start interleaved work');
    await user.click(screen.getByRole('button', { name: 'Send message' }));

    await waitFor(() => expect(listThreadItems).toHaveBeenCalledTimes(2));
    // Stream-drop rendering can replace Markdown nodes; assert the current DOM in the query's turn.
    await waitFor(() =>
      expect(screen.getByText('Authoritative interleaved result')).toBeInTheDocument()
    );
    expect(await screen.findByText("Couldn't reach the local runtime.")).toBeInTheDocument();

    await act(async () => {
      resolveStaleItems({ items: ITEMS, nextCursor: null });
      await staleItems;
    });
    await waitFor(() => expect(queryClient.isFetching()).toBe(0));

    expect(screen.getByText('Draft a competitive teardown.')).toBeInTheDocument();
    expect(screen.getAllByText('Authoritative interleaved result')).toHaveLength(1);
    expect(listThreadItems).toHaveBeenCalledTimes(2);
    expect(subscribeTurnEvents).toHaveBeenCalledTimes(1);
  });

  it('settles the first authoritative remount baseline before starting the stream', async () => {
    const serverOnlyItem = {
      ...STREAMING_ITEM,
      id: 'it_00000000-0000-7e64-9e62-31f9c01e3e1b',
      status: 'completed',
      text: 'Authoritative server-only item',
      completedAt: '2026-07-21T00:00:01.500Z',
    };
    let resolveBaseline!: (value: { items: (typeof serverOnlyItem)[]; nextCursor: null }) => void;
    let resolveDashboard!: (
      value: Pick<ThreadDashboardResponse, 'turns' | 'pendingRequests'>
    ) => void;
    let releaseStream!: () => void;
    const baseline = new Promise<{ items: (typeof serverOnlyItem)[]; nextCursor: null }>(
      (resolve) => {
        resolveBaseline = resolve;
      }
    );
    const dashboard = new Promise<Pick<ThreadDashboardResponse, 'turns' | 'pendingRequests'>>(
      (resolve) => {
        resolveDashboard = resolve;
      }
    );
    const streamReady = new Promise<void>((resolve) => {
      releaseStream = resolve;
    });
    async function* streamDuringBaseline() {
      await streamReady;
      yield turnStreamEvent(1, 'item.created', {
        type: 'item-created',
        item: STREAMING_ITEM,
      });
      yield turnStreamEvent(2, 'item.delta', {
        type: 'item-delta',
        itemId: STREAMING_ITEM.id,
        itemType: STREAMING_ITEM.type,
        deltaKind: 'text-delta',
        delta: 'Remount live text',
      });
      yield turnStreamEvent(3, 'item.completed', {
        type: 'item-completed',
        itemId: STREAMING_ITEM.id,
        item: {
          ...STREAMING_ITEM,
          status: 'completed',
          text: 'Authoritative remount stream item',
          completedAt: '2026-07-21T00:00:02.000Z',
        },
      });
      yield turnStreamEvent(4, 'turn.completed', {
        type: 'turn-completed',
        stopReason: 'completed',
        turn: { ...ACTIVE_TURN, status: 'completed' },
      });
    }

    const listThreadItems = vi.fn().mockReturnValue(baseline);
    const subscribeTurnEvents = vi.fn().mockReturnValue(streamDuringBaseline());
    const client = makeClient(
      { 'thread.items': listThreadItems, subscribeTurnEvents },
      { 'thread.dashboard': vi.fn().mockReturnValue(dashboard) }
    );
    const queryClient = renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client,
      (cache) => {
        cache.setQueryData(
          chatKeys.items(
            'ws_00000000-0000-7b10-9af8-12fd37a880e0',
            'th_00000000-0000-70a0-9cde-4561f64881c6'
          ),
          [ITEMS[0]]
        );
      }
    );

    await waitFor(() => expect(listThreadItems).toHaveBeenCalledTimes(1));
    await act(async () => {
      resolveDashboard({
        pendingRequests: [
          {
            requestId: 'ap1',
            canRespond: true,
            approvalEffect: {
              status: 'available',
              summary: 'Summary: Approval',
              detail: '{"effect":{"amount":5}}',
            },
            state: 'pending',
            resolution: null,
            ending: null,
            disposition: null,
          },
        ],
        turns: [ACTIVE_TURN],
      });
      await dashboard;
    });
    await waitFor(() =>
      expect(
        queryClient.getQueryState(
          chatKeys.dashboard(
            'ws_00000000-0000-7b10-9af8-12fd37a880e0',
            'th_00000000-0000-70a0-9cde-4561f64881c6'
          )
        )?.status
      ).toBe('success')
    );
    expect(subscribeTurnEvents).not.toHaveBeenCalled();

    await act(async () => {
      resolveBaseline({ items: [serverOnlyItem], nextCursor: null });
      await baseline;
    });
    await waitFor(() => expect(queryClient.isFetching()).toBe(0));
    expect(await screen.findByText('Authoritative server-only item')).toBeInTheDocument();
    await waitFor(() => expect(subscribeTurnEvents).toHaveBeenCalledTimes(1));

    releaseStream();
    expect(await screen.findByText('Authoritative remount stream item')).toBeInTheDocument();
    expect(screen.getAllByText('Authoritative remount stream item')).toHaveLength(1);
    const finalItems = queryClient.getQueryData<{ id: string }[]>(
      chatKeys.items(
        'ws_00000000-0000-7b10-9af8-12fd37a880e0',
        'th_00000000-0000-70a0-9cde-4561f64881c6'
      )
    );
    expect(finalItems?.filter((item) => item.id === serverOnlyItem.id)).toHaveLength(1);
    expect(finalItems?.filter((item) => item.id === STREAMING_ITEM.id)).toHaveLength(1);
  });

  it('surfaces a dropped stream and retries only through the existing affordance', async () => {
    const user = userEvent.setup();
    const droppedStream = {
      [Symbol.asyncIterator]() {
        return { next: vi.fn().mockRejectedValue(new Error('stream dropped')) };
      },
    };
    async function* reconnectedStream() {
      yield turnStreamEvent(1, 'item.completed', {
        type: 'item-completed',
        itemId: STREAMING_ITEM.id,
        item: {
          ...STREAMING_ITEM,
          status: 'completed',
          text: 'Reconnected result',
          completedAt: '2026-07-21T00:00:02.000Z',
        },
      });
      yield turnStreamEvent(2, 'turn.completed', {
        type: 'turn-completed',
        stopReason: 'completed',
        turn: { ...ACTIVE_TURN, status: 'completed' },
      });
    }

    const subscribeTurnEvents = vi
      .fn()
      .mockReturnValueOnce(droppedStream)
      .mockReturnValueOnce(reconnectedStream());
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
        subscribeTurnEvents,
      },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          pendingRequests: [
            {
              requestId: 'ap1',
              canRespond: true,
              approvalEffect: {
                status: 'available',
                summary: 'Summary: Approval',
                detail: '{"effect":{"amount":5}}',
              },
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
          turns: [ACTIVE_TURN],
        }),
      }
    );

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    expect(await screen.findByText("Couldn't reach the local runtime.")).toBeInTheDocument();
    expect(subscribeTurnEvents).toHaveBeenCalledTimes(1);
    expect(screen.getByRole('textbox', { name: 'Message' })).toBeDisabled();
    expect(screen.queryByRole('button', { name: 'Approve' })).not.toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'Try again' }));

    expect(await screen.findByText('Reconnected result')).toBeInTheDocument();
    await waitFor(() => expect(subscribeTurnEvents).toHaveBeenCalledTimes(2));
    await waitFor(() =>
      expect(screen.queryByText("Couldn't reach the local runtime.")).not.toBeInTheDocument()
    );
    expect(screen.getByRole('textbox', { name: 'Message' })).toBeEnabled();
  });

  it('clears the disconnected posture when retry receives terminal empty replay', async () => {
    const user = userEvent.setup();
    const droppedStream = {
      [Symbol.asyncIterator]() {
        return { next: vi.fn().mockRejectedValue(new Error('stream dropped')) };
      },
    };
    const terminalEmptyReplay = {
      [Symbol.asyncIterator]() {
        return {
          next: vi.fn().mockResolvedValue({ value: undefined, done: true }),
        };
      },
    };

    const subscribeTurnEvents = vi
      .fn()
      .mockReturnValueOnce(droppedStream)
      .mockReturnValueOnce(terminalEmptyReplay);
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
        subscribeTurnEvents,
      },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          pendingRequests: [
            {
              requestId: 'ap1',
              canRespond: true,
              approvalEffect: {
                status: 'available',
                summary: 'Summary: Approval',
                detail: '{"effect":{"amount":5}}',
              },
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
          turns: [ACTIVE_TURN],
        }),
      }
    );

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    expect(await screen.findByText("Couldn't reach the local runtime.")).toBeInTheDocument();
    expect(screen.getByRole('textbox', { name: 'Message' })).toBeDisabled();
    expect(screen.queryByRole('button', { name: 'Approve' })).not.toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'Try again' }));

    await waitFor(() => expect(subscribeTurnEvents).toHaveBeenCalledTimes(2));
    await waitFor(() =>
      expect(screen.queryByText("Couldn't reach the local runtime.")).not.toBeInTheDocument()
    );
    expect(screen.getByRole('textbox', { name: 'Message' })).toBeEnabled();
    expect(screen.getByRole('button', { name: 'Approve' })).toBeEnabled();
  });

  it('preserves an authoritative completed item across replayed creation and a drop', async () => {
    let releaseReplay!: () => void;
    const waitForReplay = new Promise<void>((resolve) => {
      releaseReplay = resolve;
    });
    const completedItem = {
      ...STREAMING_ITEM,
      status: 'completed',
      text: 'Already authoritative',
      completedAt: '2026-07-21T00:00:02.000Z',
    };
    async function* replayThenDrop() {
      await waitForReplay;
      yield turnStreamEvent(1, 'item.created', {
        type: 'item-created',
        item: STREAMING_ITEM,
      });
      throw new Error('stream dropped');
    }

    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: [completedItem], nextCursor: null }),
        subscribeTurnEvents: vi.fn().mockReturnValue(replayThenDrop()),
      },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          pendingRequests: [
            {
              requestId: 'ap1',
              canRespond: true,
              approvalEffect: {
                status: 'available',
                summary: 'Summary: Approval',
                detail: '{"effect":{"amount":5}}',
              },
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
          turns: [ACTIVE_TURN],
        }),
      }
    );

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    expect(await screen.findByText('Already authoritative')).toBeInTheDocument();
    releaseReplay();
    expect(await screen.findByText("Couldn't reach the local runtime.")).toBeInTheDocument();
    expect(screen.getByText('Already authoritative')).toBeInTheDocument();
  });
});

describe('open thread external activity', () => {
  const idleTurn = COMPLETED_TURN;
  const laterItem = ItemSchema.parse({
    id: 'it_00000000-0000-7025-9336-d2c7c3d76ac2',
    workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
    threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
    turnId: 'tu_00000000-0000-7e0f-94c8-e1078c4837c1',
    type: 'assistant-message',
    status: 'completed',
    text: 'CATALOG_OK_GROK',
    createdAt: '2026-07-21T00:01:00.000Z',
    completedAt: '2026-07-21T00:01:00.000Z',
  });

  function navigationItem(
    thread: typeof THREAD,
    lastActivityAt: string
  ): {
    activity: 'chat';
    lastActivityAt: string;
    state: 'idle';
    thread: typeof THREAD & { entryPath: 'conversation'; visibility: 'workspace' };
  } {
    return {
      activity: 'chat',
      lastActivityAt,
      state: 'idle',
      thread: {
        ...thread,
        entryPath: 'conversation',
        visibility: 'workspace',
      },
    };
  }

  function laterDashboard() {
    return {
      turns: [
        idleTurn,
        TurnSchema.parse({
          ...idleTurn,
          id: 'tu_00000000-0000-7e0f-94c8-e1078c4837c1',
          startedAt: '2026-07-21T00:01:00.000Z',
          completedAt: '2026-07-21T00:01:00.000Z',
        }),
      ],
    };
  }

  afterEach(() => {
    vi.useRealTimers();
  });

  it.each([
    'SSE terminal refresh',
    'idle dashboard poll',
    'first completed Turn poll',
  ] as const)('makes the current Worker selectable after %s without reloading', async (path) => {
    const user = userEvent.setup();
    let completed = false;
    const getConversationTargets = vi.fn(
      async ({ workspaceId, threadId }: { workspaceId: string; threadId?: string }) => ({
        ...CONVERSATION_TARGET,
        workspaceId,
        threadId: threadId ?? null,
        targets: [
          ...CONVERSATION_TARGET.targets,
          {
            ...CONVERSATION_TARGET.targets[1]!,
            targetRef: 'running-worker:th_00000000-0000-70a0-9cde-4561f64881c6',
            kind: 'running-worker' as const,
            label: 'Current Worker',
            threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
            availability: completed ? ('available' as const) : ('unavailable' as const),
            unavailableReason: completed ? null : 'Worker is busy.',
          },
        ],
      })
    );
    const completion = createDeferred<void>();
    async function* stream() {
      await completion.promise;
      yield turnStreamEvent(1, 'turn.completed', {
        type: 'turn-completed',
        stopReason: 'completed',
        turn: COMPLETED_TURN,
      });
    }
    const subscribeTurnEvents = vi.fn().mockReturnValue(stream());
    const getThreadDashboard = vi.fn(async () =>
      path === 'first completed Turn poll'
        ? { turns: [] }
        : path === 'idle dashboard poll'
          ? { turns: [idleTurn] }
          : {
              pendingRequests: [
                {
                  requestId: 'ap1',
                  canRespond: true,
                  approvalEffect: {
                    status: 'available',
                    summary: 'Summary: Approval',
                    detail: '{"effect":{"amount":5}}',
                  },
                  state: 'pending',
                  resolution: null,
                  ending: null,
                  disposition: null,
                },
              ],
              turns: [ACTIVE_TURN],
            }
    );
    if (path !== 'SSE terminal refresh') {
      vi.useFakeTimers({ toFake: ['setInterval', 'clearInterval'] });
    }
    renderApp(
      '/tasks/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient(
        {
          'thread.items': vi.fn(async () => ({ items: ITEMS, nextCursor: null })),
          subscribeTurnEvents,
        },
        { 'conversation.targets': getConversationTargets, 'thread.dashboard': getThreadDashboard }
      )
    );
    await user.click(await screen.findByRole('button', { name: /Conversation agent/ }));
    expect(await screen.findByRole('option', { name: /Current Worker/ })).toHaveAttribute(
      'aria-disabled',
      'true'
    );
    await user.keyboard('{Escape}');
    completed = true;
    if (path === 'SSE terminal refresh') {
      await waitFor(() => expect(subscribeTurnEvents).toHaveBeenCalledTimes(1));
      await act(async () => completion.resolve());
    } else {
      getThreadDashboard.mockResolvedValue(laterDashboard());
      await act(async () => {
        await vi.advanceTimersByTimeAsync(5_000);
      });
    }
    await user.click(await screen.findByRole('button', { name: /Conversation agent/ }));
    await waitFor(() =>
      expect(screen.getByRole('option', { name: /Current Worker/ })).not.toHaveAttribute(
        'aria-disabled',
        'true'
      )
    );
    await user.click(screen.getByRole('option', { name: /Current Worker/ }));
    expect(
      screen.getByRole('button', { name: /Current Worker.*Conversation agent/ })
    ).toBeInTheDocument();
    expect(
      getConversationTargets.mock.calls.every(
        ([{ workspaceId, threadId }]) =>
          workspaceId === 'ws_00000000-0000-7b10-9af8-12fd37a880e0' &&
          threadId === 'th_00000000-0000-70a0-9cde-4561f64881c6'
      )
    ).toBe(true);
  });

  it('refetches an idle open Thread on the foreground item poll', async () => {
    vi.useFakeTimers({ toFake: ['setInterval', 'clearInterval'] });
    let items = ITEMS;
    const listThreadItems = vi.fn(async () => ({ items, nextCursor: null }));
    const getThreadDashboard = vi.fn(async () => ({ turns: [idleTurn] }));
    const listThreads = vi.fn(async () => ({ items: [THREAD] }));
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient(
        { 'thread.items': listThreadItems, 'thread.list': listThreads },
        { 'thread.dashboard': getThreadDashboard }
      )
    );
    expect(await screen.findByText('On it — gathering the details.')).toBeInTheDocument();
    expect(screen.queryByText('CATALOG_OK_GROK')).not.toBeInTheDocument();
    const itemCallsAfterBaseline = listThreadItems.mock.calls.length;
    const dashboardCallsAfterBaseline = getThreadDashboard.mock.calls.length;

    items = [...ITEMS, laterItem];
    getThreadDashboard.mockResolvedValue(laterDashboard());
    await act(async () => {
      await vi.advanceTimersByTimeAsync(5_000);
    });

    await waitFor(() => expect(screen.getByText('CATALOG_OK_GROK')).toBeInTheDocument());
    expect(listThreadItems.mock.calls.length).toBeGreaterThan(itemCallsAfterBaseline);
    expect(getThreadDashboard.mock.calls.length).toBeGreaterThan(dashboardCallsAfterBaseline);
  });

  it.each(
    [500, 401, 403].flatMap((status) => [true, false].map((hasItems) => ({ status, hasItems })))
  )('suppresses cached activity after a $status refresh with Items=$hasItems until retry succeeds', async ({
    status,
    hasItems,
  }) => {
    const user = userEvent.setup();
    const initialDashboard = {
      pendingRequests: [
        {
          requestId: 'ap1',
          canRespond: true,
          approvalEffect: {
            status: 'available',
            summary: 'Summary: Approval',
            detail: '{"effect":{"amount":5}}',
          },
          state: 'pending',
          resolution: null,
          ending: null,
          disposition: null,
        },
      ],
      turns: [hasItems ? APPROVAL_TURN : { ...idleTurn, items: [] }],
      runtimeActivity: RUNTIME_ACTIVITY.map((activity) => ({
        ...activity,
        coverage: 'collecting' as const,
      })),
    };
    const getThreadDashboard = vi.fn().mockResolvedValue(initialDashboard);
    const queryClient = renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient(
        {
          'thread.items': vi
            .fn()
            .mockResolvedValue({ items: hasItems ? ITEMS : [], nextCursor: null }),
        },
        { 'thread.dashboard': getThreadDashboard }
      )
    );
    expect(await screen.findByText('Activity collection is ongoing.')).toBeInTheDocument();
    expect(screen.getByText('Please approve the reported proposal.')).toBeInTheDocument();
    if (hasItems) expect(screen.getByRole('button', { name: 'Approve' })).toBeInTheDocument();

    getThreadDashboard.mockRejectedValue(new ApiCallError(status, 'Private refresh diagnostic'));
    await act(async () => {
      await queryClient.refetchQueries({
        queryKey: chatKeys.dashboard(
          'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          'th_00000000-0000-70a0-9cde-4561f64881c6'
        ),
        exact: true,
      });
    });
    expect(
      queryClient.getQueryState(
        chatKeys.dashboard(
          'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          'th_00000000-0000-70a0-9cde-4561f64881c6'
        )
      )?.status
    ).toBe('error');
    expect(
      queryClient.getQueryData(
        chatKeys.dashboard(
          'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          'th_00000000-0000-70a0-9cde-4561f64881c6'
        )
      )
    ).toEqual(initialDashboard);
    await waitFor(() =>
      expect(screen.queryByText('Activity collection is ongoing.')).not.toBeInTheDocument()
    );
    expect(screen.queryByText('Please approve the reported proposal.')).not.toBeInTheDocument();
    expect(
      screen.queryByText('Full-content capture was enabled for this Turn.')
    ).not.toBeInTheDocument();
    expect(screen.queryByText('Private refresh diagnostic')).not.toBeInTheDocument();
    expect(
      screen.getByText('Runtime activity is unavailable. Retry to refresh.')
    ).toBeInTheDocument();
    if (hasItems) {
      expect(screen.getByText('Draft a competitive teardown.')).toBeInTheDocument();
      expect(screen.getByText('Approve $5 spend')).toBeInTheDocument();
      expect(screen.queryByRole('button', { name: 'Approve' })).not.toBeInTheDocument();
    }

    const recovery = createDeferred<typeof initialDashboard>();
    getThreadDashboard.mockImplementation(() => recovery.promise);
    await user.click(screen.getByRole('button', { name: 'Try again' }));
    await waitFor(() =>
      expect(
        queryClient.getQueryState(
          chatKeys.dashboard(
            'ws_00000000-0000-7b10-9af8-12fd37a880e0',
            'th_00000000-0000-70a0-9cde-4561f64881c6'
          )
        )?.fetchStatus
      ).toBe('fetching')
    );
    expect(screen.queryByText('Please approve the reported proposal.')).not.toBeInTheDocument();
    expect(screen.queryByText('Activity collection is ongoing.')).not.toBeInTheDocument();
    await act(async () => {
      recovery.resolve({
        ...initialDashboard,
        runtimeActivity: initialDashboard.runtimeActivity.map((activity) => ({
          ...activity,
          entries: activity.entries.map((entry) => ({
            ...entry,
            text: 'Fresh authorized activity after recovery.',
          })),
        })),
      });
    });
    expect(
      await screen.findByText('Fresh authorized activity after recovery.')
    ).toBeInTheDocument();
    expect(screen.getByText('Activity collection is ongoing.')).toBeInTheDocument();
    expect(
      screen.queryByText('Runtime activity is unavailable. Retry to refresh.')
    ).not.toBeInTheDocument();
    expect(screen.queryByText('Please approve the reported proposal.')).not.toBeInTheDocument();
    if (hasItems) expect(screen.getByRole('button', { name: 'Approve' })).toBeInTheDocument();
  });

  it('refreshes runtime activity on the existing dashboard poll without new Items', async () => {
    vi.useFakeTimers({ toFake: ['setInterval', 'clearInterval'] });
    let reported = false;
    const getThreadDashboard = vi.fn(async () => ({
      turns: [idleTurn],
      runtimeActivity: reported ? RUNTIME_ACTIVITY : [],
    }));
    const listThreadItems = vi.fn(async () => ({ items: ITEMS, nextCursor: null }));
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient({ 'thread.items': listThreadItems }, { 'thread.dashboard': getThreadDashboard })
    );
    expect(await screen.findByText('On it — gathering the details.')).toBeInTheDocument();
    expect(screen.queryByRole('region', { name: 'Runtime activity' })).not.toBeInTheDocument();
    reported = true;
    await act(async () => {
      await vi.advanceTimersByTimeAsync(5_000);
    });
    expect(await screen.findByText('Child 1: verification running')).toBeInTheDocument();
    expect(screen.getAllByRole('region', { name: 'Runtime activity' })).toHaveLength(1);
    expect(screen.getAllByText('On it — gathering the details.')).toHaveLength(1);
  });

  it('refetches stale items when the dashboard is already new', async () => {
    vi.useFakeTimers({ toFake: ['setInterval', 'clearInterval'] });
    let items = ITEMS;
    const listThreadItems = vi.fn(async () => ({ items, nextCursor: null }));
    const getThreadDashboard = vi.fn(async () => laterDashboard());
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient({ 'thread.items': listThreadItems }, { 'thread.dashboard': getThreadDashboard })
    );
    expect(await screen.findByText('On it — gathering the details.')).toBeInTheDocument();
    expect(screen.queryByText('CATALOG_OK_GROK')).not.toBeInTheDocument();
    const itemCallsAfterItems = listThreadItems.mock.calls.length;

    items = [...ITEMS, laterItem];
    await act(async () => {
      await vi.advanceTimersByTimeAsync(5_000);
    });

    await waitFor(() => expect(screen.getByText('CATALOG_OK_GROK')).toBeInTheDocument());
    expect(listThreadItems.mock.calls.length).toBeGreaterThan(itemCallsAfterItems);
  });

  it('refreshes verified request summaries while running without polling streamed items', async () => {
    vi.useFakeTimers({ toFake: ['setInterval', 'clearInterval'] });
    const requestText = '{"schemaVersion":1,"objective":"raw-input"}';
    const objective = 'Verified maintenance request';
    const item = ItemSchema.parse({ ...ITEMS[0], text: requestText });
    let verified = false;
    const getThreadDashboard = vi.fn(async (_input: { workspaceId: string; threadId: string }) => ({
      pendingRequests: [
        {
          requestId: 'ap1',
          canRespond: true,
          approvalEffect: {
            status: 'available',
            summary: 'Summary: Approval',
            detail: '{"effect":{"amount":5}}',
          },
          state: 'pending',
          resolution: null,
          ending: null,
          disposition: null,
        },
      ],
      turns: [ACTIVE_TURN],
      taskInputs: verified ? [{ itemId: item.id, objective }] : [],
    }));
    const listThreadItems = vi.fn(async () => ({ items: [item], nextCursor: null }));
    const completed = createDeferred<void>();
    async function* stream() {
      await completed.promise;
      yield turnStreamEvent(1, 'turn.completed', {
        type: 'turn-completed',
        stopReason: 'completed',
        turn: COMPLETED_TURN,
      });
    }
    const subscribeTurnEvents = vi.fn().mockReturnValue(stream());
    const queryClient = renderApp(
      '/tasks/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient(
        { 'thread.items': listThreadItems, subscribeTurnEvents },
        { 'thread.dashboard': getThreadDashboard }
      )
    );
    expect(await screen.findByRole('button', { name: 'Stop turn' })).toBeInTheDocument();
    expect(screen.getByText(requestText)).toBeVisible();
    const itemCalls = listThreadItems.mock.calls.length;
    await waitFor(() => expect(subscribeTurnEvents).toHaveBeenCalledTimes(1));

    verified = true;
    await act(async () => {
      await vi.advanceTimersByTimeAsync(5_000);
    });

    expect(await screen.findByText(objective)).toBeVisible();
    const details = screen.getByText('View request details').closest('details')!;
    expect(details.open).toBe(false);
    expect(details.querySelector('pre')?.textContent).toBe(requestText);
    expect(listThreadItems.mock.calls.length).toBe(itemCalls);
    expect(subscribeTurnEvents).toHaveBeenCalledTimes(1);
    expect(
      getThreadDashboard.mock.calls.every(
        ([{ workspaceId, threadId }]) =>
          workspaceId === 'ws_00000000-0000-7b10-9af8-12fd37a880e0' &&
          threadId === 'th_00000000-0000-70a0-9cde-4561f64881c6'
      )
    ).toBe(true);
    expect(screen.getByRole('button', { name: 'Stop turn' })).toBeInTheDocument();

    const late = createDeferred<Awaited<ReturnType<typeof getThreadDashboard>>>();
    getThreadDashboard.mockImplementationOnce(() => late.promise);
    await act(async () => {
      await vi.advanceTimersByTimeAsync(5_000);
    });
    expect(
      queryClient.getQueryState(
        chatKeys.dashboard(
          'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          'th_00000000-0000-70a0-9cde-4561f64881c6'
        )
      )?.fetchStatus
    ).toBe('fetching');
    await act(async () => {
      completed.resolve();
    });
    await waitFor(() =>
      expect(screen.queryByRole('button', { name: 'Stop turn' })).not.toBeInTheDocument()
    );
    await act(async () => {
      late.resolve({
        pendingRequests: [
          {
            requestId: 'ap1',
            canRespond: true,
            approvalEffect: {
              status: 'available',
              summary: 'Summary: Approval',
              detail: '{"effect":{"amount":5}}',
            },
            state: 'pending',
            resolution: null,
            ending: null,
            disposition: null,
          },
        ],
        turns: [ACTIVE_TURN],
        taskInputs: [],
      });
    });
    expect(
      queryClient.getQueryData<{ turns: Array<{ status: string }> }>(
        chatKeys.dashboard(
          'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          'th_00000000-0000-70a0-9cde-4561f64881c6'
        )
      )?.turns[0]?.status
    ).toBe('completed');
  });

  it('does not poll items while a Turn is running', async () => {
    vi.useFakeTimers({ toFake: ['setInterval', 'clearInterval'] });
    const listThreadItems = vi.fn(async () => ({ items: ITEMS, nextCursor: null }));
    async function* hang() {
      yield turnStreamEvent(1, 'item.created', { type: 'item-created', item: ITEMS[1] });
      await new Promise(() => undefined);
    }
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient(
        { 'thread.items': listThreadItems, subscribeTurnEvents: vi.fn().mockReturnValue(hang()) },
        {
          'thread.dashboard': vi.fn().mockResolvedValue({
            pendingRequests: [
              {
                requestId: 'ap1',
                canRespond: true,
                approvalEffect: {
                  status: 'available',
                  summary: 'Summary: Approval',
                  detail: '{"effect":{"amount":5}}',
                },
                state: 'pending',
                resolution: null,
                ending: null,
                disposition: null,
              },
            ],
            turns: [ACTIVE_TURN],
          }),
        }
      )
    );
    expect(await screen.findByRole('button', { name: 'Stop turn' })).toBeInTheDocument();
    const itemCalls = listThreadItems.mock.calls.length;
    await act(async () => {
      await vi.advanceTimersByTimeAsync(5_000);
    });
    expect(listThreadItems.mock.calls.length).toBe(itemCalls);
  });

  it('does not fetch unrelated Thread items when switching workspace', async () => {
    const user = userEvent.setup();
    const otherThread = {
      ...THREAD,
      id: 'th_00000000-0000-7c00-b9fc-382312fdf476',
      name: 'Workspace B teardown',
      preview: 'Workspace B teardown',
    };
    const listConversationNavigation = vi.fn(async ({ workspaceId }: { workspaceId: string }) => ({
      items:
        workspaceId === 'ws_00000000-0000-7b10-9af8-12fd37a880e0'
          ? [
              navigationItem(THREAD, '2026-07-21T00:00:02.000Z'),
              navigationItem(otherThread, '2026-07-21T00:00:00.000Z'),
            ]
          : [
              navigationItem(
                {
                  ...otherThread,
                  workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
                  name: 'Second workspace thread',
                },
                '2026-07-21T00:00:00.000Z'
              ),
            ],
    }));
    const listThreadItems = vi.fn(
      async ({ workspaceId, threadId }: { workspaceId: string; threadId: string }) => ({
        items:
          threadId === 'th_00000000-0000-7c00-b9fc-382312fdf476'
            ? [
                ItemSchema.parse({
                  ...ITEMS[0],
                  id: 'it_00000000-0000-7b75-87ae-cd4800676a62',
                  workspaceId,
                  threadId: 'th_00000000-0000-7c00-b9fc-382312fdf476',
                  text: 'Other thread baseline.',
                }),
              ]
            : ITEMS,
        nextCursor: null,
      })
    );
    const getThread = vi.fn(
      async ({ workspaceId, threadId }: { workspaceId: string; threadId: string }) =>
        threadId === 'th_00000000-0000-7c00-b9fc-382312fdf476'
          ? {
              ...otherThread,
              workspaceId,
              name:
                workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6'
                  ? 'Second workspace thread'
                  : otherThread.name,
            }
          : THREAD
    );
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient(
        {
          'thread.read': getThread,
          'thread.items': listThreadItems,
          'thread.list': vi.fn(async ({ workspaceId }: { workspaceId: string }) => ({
            items:
              workspaceId === 'ws_00000000-0000-7b10-9af8-12fd37a880e0'
                ? [THREAD, otherThread]
                : [otherThread],
          })),
        },
        {
          'conversation.navigation': listConversationNavigation,
          'thread.dashboard': vi.fn(async () => ({ turns: [idleTurn] })),
        }
      )
    );

    expect(await screen.findByText('On it — gathering the details.')).toBeInTheDocument();
    const th1ItemCalls = listThreadItems.mock.calls.filter(
      ([{ threadId }]) => threadId === 'th_00000000-0000-70a0-9cde-4561f64881c6'
    ).length;
    await user.click(await screen.findByRole('button', { name: 'Workspace B teardown' }));
    expect(await screen.findByText('Other thread baseline.')).toBeInTheDocument();
    expect(
      listThreadItems.mock.calls.filter(
        ([{ threadId }]) => threadId === 'th_00000000-0000-7c00-b9fc-382312fdf476'
      )
    ).toHaveLength(1);
    expect(
      listThreadItems.mock.calls.filter(
        ([{ threadId }]) => threadId === 'th_00000000-0000-70a0-9cde-4561f64881c6'
      ).length
    ).toBe(th1ItemCalls);

    await user.click(await workspaceSelectTrigger());
    await user.click(await screen.findByRole('menuitem', { name: 'Second workspace' }));
    expect(
      await screen.findByRole('heading', { name: 'What can we get done?' })
    ).toBeInTheDocument();
    expect(
      listThreadItems.mock.calls.filter(
        ([{ workspaceId }]) => workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6'
      )
    ).toHaveLength(0);
  });
});

describe('task thread (board 04)', () => {
  it('frames the thread as a task and shows the inline approval-card pattern', async () => {
    const client = makeClient({
      'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
    });
    renderApp(
      '/tasks/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    expect(await screen.findByRole('img', { name: 'Task' })).toBeInTheDocument();
    expect(await screen.findByText('Approve $5 spend')).toBeInTheDocument();
  });

  it('dispatches the task Composer through the reusable warm Worker target', async () => {
    const user = userEvent.setup();
    const startTurn = vi.fn();
    const startTaskMode = vi.fn().mockResolvedValue(TASK_MODE_RESPONSE);
    const submitConversation = vi.fn().mockResolvedValue({
      ...CHAT_MODE_RESPONSE,
      targetRef: 'warm-worker:agent_codex_host:default',
    });
    const quickChat = vi.fn();
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
        'turn.start': startTurn,
      },
      {
        'chat.quick': quickChat,
        'conversation.submit': submitConversation,
        'task.start': startTaskMode,
      }
    );

    renderApp(
      '/tasks/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    await user.type(await screen.findByRole('textbox', { name: 'Message' }), 'Ship the fix');
    await user.click(screen.getByRole('button', { name: 'Send message' }));

    await waitFor(() =>
      expect(submitConversation).toHaveBeenCalledWith(
        expect.objectContaining({
          workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
          ...{
            input: 'Ship the fix',
            targetRef: 'warm-worker:agent_codex_host:default',
          },
        })
      )
    );
    expect(startTaskMode).not.toHaveBeenCalled();
    expect(startTurn).not.toHaveBeenCalled();
    expect(quickChat).not.toHaveBeenCalled();
  });

  const INITIATING_REQUEST_TEXT =
    '{"schemaVersion":1,"objective":"raw-input","acceptanceCriteria":["done"]}';
  const INITIATING_OBJECTIVE = 'Ship the bounded Task request.';

  it('projects a matching initiating-request objective and keeps exact bytes in closed details', async () => {
    const user = userEvent.setup();
    const item = ItemSchema.parse({
      ...ITEMS[0],
      id: 'it_00000000-0000-7fab-86e7-3930c0df3025',
      text: INITIATING_REQUEST_TEXT,
    });
    renderApp(
      '/tasks/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient(
        { 'thread.items': vi.fn().mockResolvedValue({ items: [item], nextCursor: null }) },
        {
          'thread.dashboard': vi.fn().mockResolvedValue({
            pendingRequests: [
              {
                requestId: 'uir1',
                state: 'pending',
                resolution: null,
                ending: null,
                disposition: null,
              },
            ],
            viewerUserId: 'usr_00000000-0000-7609-aed5-db4b5c95e76c',
            turns: [],
            taskInputs: [{ itemId: item.id, objective: INITIATING_OBJECTIVE }],
          }),
        }
      )
    );

    const article = await screen.findByRole('article', {
      name: 'Message from usr_00000000-0000-7609-aed5-db4b5c95e76c (You)',
    });
    expect(within(article).getByText(INITIATING_OBJECTIVE)).toBeVisible();
    const details = within(article).getByText('View request details').closest('details');
    expect(details).toBeInstanceOf(HTMLDetailsElement);
    expect((details as HTMLDetailsElement).open).toBe(false);
    expect(details).toHaveTextContent(INITIATING_REQUEST_TEXT);
    const preview = details!.querySelector('pre');
    expect(preview).not.toBeVisible();
    await user.click(within(article).getByText('View request details'));
    expect((details as HTMLDetailsElement).open).toBe(true);
    expect(preview).toBeVisible();
    expect(preview).toHaveTextContent(INITIATING_REQUEST_TEXT);
    expect(preview?.textContent).toBe(INITIATING_REQUEST_TEXT);
  });

  it('leaves ordinary human JSON verbatim when the initiating-request summary is absent or mismatched', async () => {
    const matched = ItemSchema.parse({
      ...ITEMS[0],
      id: 'it_00000000-0000-7763-afd7-6bec90791ac5',
      text: INITIATING_REQUEST_TEXT,
    });
    const unmatched = ItemSchema.parse({
      ...ITEMS[0],
      id: 'it_00000000-0000-7d02-bceb-2e3812d855a2',
      actor: { kind: 'user', id: 'usr_00000000-0000-73d4-904a-d4c4b905df7c' },
      text: '{"schemaVersion":1,"objective":"leave-verbatim"}',
    });
    renderApp(
      '/tasks/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient(
        {
          'thread.items': vi
            .fn()
            .mockResolvedValue({ items: [matched, unmatched], nextCursor: null }),
        },
        {
          'thread.dashboard': vi.fn().mockResolvedValue({
            pendingRequests: [
              {
                requestId: 'uir1',
                state: 'pending',
                resolution: null,
                ending: null,
                disposition: null,
              },
            ],
            viewerUserId: 'usr_00000000-0000-7609-aed5-db4b5c95e76c',
            turns: [],
            taskInputs: [
              {
                itemId: 'it_00000000-0000-792a-b057-1c9184591714',
                objective: INITIATING_OBJECTIVE,
              },
            ],
          }),
        }
      )
    );

    const self = await screen.findByRole('article', {
      name: 'Message from usr_00000000-0000-7609-aed5-db4b5c95e76c (You)',
    });
    const other = screen.getByRole('article', {
      name: 'Message from usr_00000000-0000-73d4-904a-d4c4b905df7c',
    });
    expect(within(self).getByText(INITIATING_REQUEST_TEXT)).toBeVisible();
    expect(
      within(other).getByText('{"schemaVersion":1,"objective":"leave-verbatim"}')
    ).toBeVisible();
    expect(screen.queryByText(INITIATING_OBJECTIVE)).not.toBeInTheDocument();
    expect(screen.queryByText('View request details')).not.toBeInTheDocument();
  });

  it('keeps Core-authored frozen outcome input out of the conversation while showing the answer', async () => {
    const envelope = JSON.stringify({
      triggerInput: 'Receive pending request outcomes.',
      pendingOutcomes: [{ request: { question: 'Which summary tone should the simulator use?' } }],
    });
    const input = ItemSchema.parse({
      ...ITEMS[0],
      id: 'it_00000000-0000-7b3e-a44b-d9b7370dfd90',
      actor: {
        kind: 'system',
        id: 'nanocore-pending-request',
        responsibleUserId: 'usr_00000000-0000-7609-aed5-db4b5c95e76c',
      },
      text: envelope,
    });
    const answer = ItemSchema.parse({
      ...ITEMS[0],
      id: 'it_00000000-0000-7e9b-99cc-a5622f956ef0',
      type: 'user-input-response',
      causationId: 'it_00000000-0000-7552-bffa-5f2e0a67b337',
      userInputRequestId: 'uir1',
      answers: { tone: ['Concise'] },
      answeredAt: ITEMS[0]!.createdAt,
    });
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient({
        'thread.dashboard': vi.fn().mockResolvedValue({
          viewerUserId: 'usr_00000000-0000-7609-aed5-db4b5c95e76c',
          turns: [],
        }),
        'thread.items': vi
          .fn()
          .mockResolvedValue({ items: [ITEMS[0], input, answer], nextCursor: null }),
      })
    );
    expect(await screen.findByText('You answered')).toBeVisible();
    expect(screen.getByText('Draft a competitive teardown.')).toBeVisible();
    expect(screen.queryByText(envelope)).not.toBeInTheDocument();
    expect(
      screen.queryByRole('article', { name: 'Message from nanocore-pending-request' })
    ).not.toBeInTheDocument();
  });

  it('applies the same initiating-request projection to self and agent user-message wrappers', async () => {
    const selfItem = ItemSchema.parse({
      ...ITEMS[0],
      id: 'it_00000000-0000-70b0-bdba-a70f39b377d6',
      text: INITIATING_REQUEST_TEXT,
    });
    const agentItem = ItemSchema.parse({
      ...ITEMS[0],
      id: 'it_00000000-0000-7cbd-897f-c447aa35c4cb',
      actor: {
        kind: 'agent',
        id: 'agent_codex_host',
        responsibleUserId: 'usr_00000000-0000-7609-aed5-db4b5c95e76c',
      },
      text: `${INITIATING_REQUEST_TEXT}\n`,
    });
    renderApp(
      '/tasks/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient(
        {
          'thread.items': vi
            .fn()
            .mockResolvedValue({ items: [selfItem, agentItem], nextCursor: null }),
        },
        {
          'thread.dashboard': vi.fn().mockResolvedValue({
            pendingRequests: [
              {
                requestId: 'uir1',
                state: 'pending',
                resolution: null,
                ending: null,
                disposition: null,
              },
            ],
            viewerUserId: 'usr_00000000-0000-7609-aed5-db4b5c95e76c',
            participants: [{ kind: 'agent', id: 'agent_codex_host', displayName: 'Codex Agent' }],
            turns: [],
            taskInputs: [
              { itemId: selfItem.id, objective: INITIATING_OBJECTIVE },
              { itemId: agentItem.id, objective: INITIATING_OBJECTIVE },
            ],
          }),
        }
      )
    );

    const self = await screen.findByRole('article', {
      name: 'Message from usr_00000000-0000-7609-aed5-db4b5c95e76c (You)',
    });
    const agent = screen.getByRole('article', { name: 'Message from Codex Agent' });
    expect(self).toHaveClass('items-end');
    expect(agent).toHaveClass('items-start');
    expect(within(self).getByText(INITIATING_OBJECTIVE)).toBeVisible();
    expect(within(agent).getByText(INITIATING_OBJECTIVE)).toBeVisible();
    expect(
      within(self).getByText('View request details').closest('details')!.querySelector('pre')
        ?.textContent
    ).toBe(INITIATING_REQUEST_TEXT);
    expect(
      within(agent).getByText('View request details').closest('details')!.querySelector('pre')
        ?.textContent
    ).toBe(`${INITIATING_REQUEST_TEXT}\n`);
  });
});

describe('mode entry and feedback (S8)', () => {
  it('uses the ordinary Chat Mode path for the built-in Quick Chat workspace', async () => {
    const user = userEvent.setup();
    const startTurn = vi.fn();
    const submitConversation = vi.fn().mockResolvedValue(QUICK_CHAT_MODE_RESPONSE);
    const startTaskMode = vi.fn();
    const quickChat = vi.fn();
    const client = makeClient(
      {
        'thread.read': vi
          .fn()
          .mockResolvedValue({ ...THREAD, workspaceId: QUICK_CHAT_WORKSPACE.id }),
        'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
        'workspace.list': vi.fn().mockResolvedValue({
          items: [QUICK_CHAT_WORKSPACE].map((workspace) => ({
            membershipStatus: 'active' as const,
            accessCause: 'membership' as const,
            workspace,
            effectiveRole: 'owner',
            membershipRevision: 1,
            ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
            registryRevision: 1,
          })),
        }),
        'turn.start': startTurn,
      },
      {
        'chat.quick': quickChat,
        'conversation.submit': submitConversation,
        'task.start': startTaskMode,
      }
    );

    renderApp(
      '/chat/ws_7d54f339-a119-5221-bbbf-bfbf3e8a3f28/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    await user.type(await screen.findByRole('textbox', { name: 'Message' }), 'Answer directly');
    await user.click(screen.getByRole('button', { name: 'Send message' }));

    await waitFor(() =>
      expect(submitConversation).toHaveBeenCalledWith(
        expect.objectContaining({
          workspaceId: 'ws_7d54f339-a119-5221-bbbf-bfbf3e8a3f28',
          threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
          ...{
            input: 'Answer directly',
            targetRef: 'internal-role:assistant',
          },
        })
      )
    );
    expect(startTaskMode).not.toHaveBeenCalled();
    expect(startTurn).not.toHaveBeenCalled();
    expect(quickChat).not.toHaveBeenCalled();
  });

  it('refreshes only the submitted composer owner after a workspace switch', async () => {
    const user = userEvent.setup();
    const started = createDeferred<typeof CHAT_MODE_RESPONSE>();
    const submitConversation = vi.fn().mockReturnValue(started.promise);
    const workspaceBThread = {
      ...THREAD,
      workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
      name: 'Workspace B teardown',
      preview: 'Workspace B teardown',
    };
    const workspaceBItem = ItemSchema.parse({
      ...ITEMS[0],
      id: 'it_00000000-0000-7dc6-b838-1e3fce692665',
      workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
      turnId: 'tu_00000000-0000-7135-a7d9-4aa63b405497',
      text: 'Workspace B stays authoritative.',
    });
    const client = makeClient(
      {
        'thread.read': vi
          .fn()
          .mockImplementation(({ workspaceId }: { workspaceId: string; threadId?: string }) =>
            Promise.resolve(
              workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6' ? workspaceBThread : THREAD
            )
          ),
        'thread.list': vi.fn().mockImplementation(({ workspaceId }: { workspaceId: string }) =>
          Promise.resolve({
            items: [
              workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6' ? workspaceBThread : THREAD,
            ],
          })
        ),
        'thread.items': vi
          .fn()
          .mockImplementation(({ workspaceId }: { workspaceId: string; threadId?: string }) =>
            Promise.resolve({
              items:
                workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6'
                  ? [workspaceBItem]
                  : ITEMS,
              nextCursor: null,
            })
          ),
      },
      { 'conversation.submit': submitConversation }
    );
    const queryClient = renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    const invalidateQueries = vi.spyOn(queryClient, 'invalidateQueries');

    await user.type(await screen.findByRole('textbox', { name: 'Message' }), 'Continue A');
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    await waitFor(() =>
      expect(submitConversation).toHaveBeenCalledWith(
        expect.objectContaining({
          workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
          ...{ input: 'Continue A', targetRef: 'internal-role:assistant' },
        })
      )
    );

    await switchToThread(user, 'Market research', 'Second workspace', 'Workspace B teardown');
    expect(await screen.findByText('Workspace B stays authoritative.')).toBeInTheDocument();
    await act(async () => {
      started.resolve(CHAT_MODE_RESPONSE);
      await started.promise;
    });

    await waitFor(() => {
      expect(invalidateQueries).toHaveBeenCalledWith({
        queryKey: chatKeys.items(
          'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          'th_00000000-0000-70a0-9cde-4561f64881c6'
        ),
      });
      expect(invalidateQueries).toHaveBeenCalledWith({
        queryKey: chatKeys.dashboard(
          'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          'th_00000000-0000-70a0-9cde-4561f64881c6'
        ),
      });
    });
    expect(invalidateQueries).not.toHaveBeenCalledWith({
      queryKey: chatKeys.items(
        'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
        'th_00000000-0000-70a0-9cde-4561f64881c6'
      ),
    });
    expect(invalidateQueries).not.toHaveBeenCalledWith({
      queryKey: chatKeys.dashboard(
        'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
        'th_00000000-0000-70a0-9cde-4561f64881c6'
      ),
    });
    expect(
      queryClient.getQueryData(
        chatKeys.items(
          'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
          'th_00000000-0000-70a0-9cde-4561f64881c6'
        )
      )
    ).toEqual([workspaceBItem]);
    expect(screen.queryByText("Couldn't send that message. Try again.")).not.toBeInTheDocument();
  });

  it('does not offer feedback for a completed Turn without a completed assistant message', async () => {
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: [ITEMS[0]], nextCursor: null }),
      },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          pendingRequests: [
            {
              requestId: 'ap1',
              canRespond: true,
              approvalEffect: {
                status: 'available',
                summary: 'Summary: Approval',
                detail: '{"effect":{"amount":5}}',
              },
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
          turns: [COMPLETED_TURN],
        }),
      }
    );

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );

    expect(await screen.findByText('Draft a competitive teardown.')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /good/i })).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /bad/i })).not.toBeInTheDocument();
  });

  it.each([
    'success',
    'failure',
  ] as const)('keeps a late workspace A feedback %s out of workspace B', async (settlement) => {
    const user = userEvent.setup();
    const priorFeedback = {
      turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
      agentId: 'agent_assistant',
      rating: 'good' as const,
      note: null,
      createdAt: '2026-07-21T00:00:03.000Z',
    };
    const settledFeedback = {
      ...priorFeedback,
      rating: 'bad' as const,
      createdAt: '2026-07-21T00:00:04.000Z',
    };
    const submitted = createDeferred<typeof settledFeedback>();
    const submitTurnFeedback = vi.fn().mockReturnValue(submitted.promise);
    const workspaceBThread = {
      ...THREAD,
      workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
      name: 'Workspace B teardown',
      preview: 'Workspace B teardown',
    };
    const workspaceBTurn = TurnSchema.parse({
      ...COMPLETED_TURN,
      id: 'tu_00000000-0000-7135-a7d9-4aa63b405497',
      workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
      triggerActor: { kind: 'user', id: 'usr_00000000-0000-7e1a-82fc-aa295bc43d6c' },
    });
    const workspaceBAssistant = ItemSchema.parse({
      ...ITEMS[1],
      id: 'it_00000000-0000-7a72-a3c3-089dca8798b5',
      workspaceId: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
      turnId: workspaceBTurn.id,
      text: 'Workspace B answer.',
    });
    const client = makeClient(
      {
        'thread.read': vi
          .fn()
          .mockImplementation(({ workspaceId }: { workspaceId: string; threadId?: string }) =>
            Promise.resolve(
              workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6' ? workspaceBThread : THREAD
            )
          ),
        'thread.list': vi.fn().mockImplementation(({ workspaceId }: { workspaceId: string }) =>
          Promise.resolve({
            items: [
              workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6' ? workspaceBThread : THREAD,
            ],
          })
        ),
        'thread.items': vi
          .fn()
          .mockImplementation(({ workspaceId }: { workspaceId: string; threadId?: string }) =>
            Promise.resolve({
              items:
                workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6'
                  ? [workspaceBAssistant]
                  : [ITEMS[1]],
              nextCursor: null,
            })
          ),
      },
      {
        'thread.dashboard': vi
          .fn()
          .mockImplementation(({ workspaceId }: { workspaceId: string; threadId?: string }) =>
            Promise.resolve({
              turns: [
                workspaceId === 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6'
                  ? workspaceBTurn
                  : COMPLETED_TURN,
              ],
            })
          ),
        'turn.feedback': submitTurnFeedback,
      }
    );
    const queryClient = renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client,
      (cache) => {
        cache.setQueryData(
          chatKeys.feedback(
            'ws_00000000-0000-7b10-9af8-12fd37a880e0',
            'th_00000000-0000-70a0-9cde-4561f64881c6',
            'tu_00000000-0000-7da3-a7fc-80982f9b215e'
          ),
          priorFeedback
        );
      }
    );

    await user.click(await screen.findByRole('button', { name: /bad/i }));
    await waitFor(() =>
      expect(submitTurnFeedback).toHaveBeenCalledWith({
        turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
        rating: 'bad',
        note: null,
      })
    );

    await switchToThread(user, 'Market research', 'Second workspace', 'Workspace B teardown');
    expect(await screen.findByText('Workspace B answer.')).toBeInTheDocument();
    await act(async () => {
      if (settlement === 'success') submitted.resolve(settledFeedback);
      else submitted.reject(new Error('feedback rejected'));
      await submitted.promise.catch(() => undefined);
    });

    await waitFor(() => expect(submitTurnFeedback).toHaveBeenCalledTimes(1));
    expect(screen.queryByRole('alert')).not.toBeInTheDocument();
    expect(
      queryClient.getQueryData(
        chatKeys.feedback(
          'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          'th_00000000-0000-70a0-9cde-4561f64881c6',
          'tu_00000000-0000-7da3-a7fc-80982f9b215e'
        )
      )
    ).toEqual(settlement === 'success' ? settledFeedback : priorFeedback);
    expect(
      queryClient.getQueryData(
        chatKeys.feedback(
          'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
          'th_00000000-0000-70a0-9cde-4561f64881c6',
          workspaceBTurn.id
        )
      )
    ).toBeUndefined();
    expect(screen.getByRole('button', { name: /good/i })).toHaveAttribute('aria-pressed', 'false');
    expect(screen.getByRole('button', { name: /bad/i })).toHaveAttribute('aria-pressed', 'false');
  });

  it('keeps one feedback selection per completed Turn and applies only authoritative responses', async () => {
    const user = userEvent.setup();
    const goodResponse = {
      turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
      agentId: 'agent_assistant',
      rating: 'good' as const,
      note: null,
      createdAt: '2026-07-21T00:00:03.000Z',
    };
    const badResponse = {
      ...goodResponse,
      rating: 'bad' as const,
      createdAt: '2026-07-21T00:00:04.000Z',
    };
    const good = createDeferred<typeof goodResponse>();
    const bad = createDeferred<typeof badResponse>();
    const submitTurnFeedback = vi
      .fn()
      .mockReturnValueOnce(good.promise)
      .mockReturnValueOnce(bad.promise);
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({
          items: [ITEMS[1], SECOND_ASSISTANT_ITEM],
          nextCursor: null,
        }),
      },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          pendingRequests: [
            {
              requestId: 'ap1',
              canRespond: true,
              approvalEffect: {
                status: 'available',
                summary: 'Summary: Approval',
                detail: '{"effect":{"amount":5}}',
              },
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
          turns: [COMPLETED_TURN],
        }),
        'turn.feedback': submitTurnFeedback,
      }
    );

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    await screen.findByText('Here is the completed pricing comparison.');
    const goodButtons = screen.getAllByRole('button', { name: /good/i });
    const badButtons = screen.getAllByRole('button', { name: /bad/i });
    expect(goodButtons).toHaveLength(1);
    expect(badButtons).toHaveLength(1);
    const goodButton = goodButtons[0]!;
    const badButton = badButtons[0]!;

    await user.click(goodButton);
    expect(submitTurnFeedback).toHaveBeenNthCalledWith(1, {
      turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
      rating: 'good',
      note: null,
    });
    expect(goodButton).toHaveAttribute('aria-pressed', 'false');
    await act(async () => {
      good.resolve(goodResponse);
      await good.promise;
    });
    await waitFor(() => expect(goodButton).toHaveAttribute('aria-pressed', 'true'));

    await user.click(badButton);
    expect(submitTurnFeedback).toHaveBeenNthCalledWith(2, {
      turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
      rating: 'bad',
      note: null,
    });
    expect(goodButton).toHaveAttribute('aria-pressed', 'true');
    expect(badButton).toHaveAttribute('aria-pressed', 'false');
    await act(async () => {
      bad.resolve(badResponse);
      await bad.promise;
    });
    await waitFor(() => expect(badButton).toHaveAttribute('aria-pressed', 'true'));
    expect(goodButton).toHaveAttribute('aria-pressed', 'false');
  });

  it('retains the prior feedback after rejection and retries the exact failed command', async () => {
    const user = userEvent.setup();
    const goodResponse = {
      turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
      agentId: 'agent_assistant',
      rating: 'good' as const,
      note: null,
      createdAt: '2026-07-21T00:00:03.000Z',
    };
    const badResponse = {
      ...goodResponse,
      rating: 'bad' as const,
      createdAt: '2026-07-21T00:00:05.000Z',
    };
    const submitTurnFeedback = vi
      .fn()
      .mockResolvedValueOnce(goodResponse)
      .mockRejectedValueOnce(new Error('feedback_unavailable'))
      .mockResolvedValueOnce(badResponse);
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: [ITEMS[1]], nextCursor: null }),
      },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          pendingRequests: [
            {
              requestId: 'ap1',
              canRespond: true,
              approvalEffect: {
                status: 'available',
                summary: 'Summary: Approval',
                detail: '{"effect":{"amount":5}}',
              },
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
          turns: [COMPLETED_TURN],
        }),
        'turn.feedback': submitTurnFeedback,
      }
    );

    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    const goodButton = await screen.findByRole('button', { name: /good/i });
    const badButton = screen.getByRole('button', { name: /bad/i });
    await user.click(goodButton);
    await waitFor(() => expect(goodButton).toHaveAttribute('aria-pressed', 'true'));

    await user.click(badButton);
    expect(await screen.findByRole('alert')).toBeInTheDocument();
    expect(goodButton).toHaveAttribute('aria-pressed', 'true');
    expect(badButton).toHaveAttribute('aria-pressed', 'false');

    await user.click(screen.getByRole('button', { name: 'Try again' }));
    await waitFor(() =>
      expect(submitTurnFeedback).toHaveBeenNthCalledWith(3, {
        turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
        rating: 'bad',
        note: null,
      })
    );
    await waitFor(() => expect(badButton).toHaveAttribute('aria-pressed', 'true'));
    expect(goodButton).toHaveAttribute('aria-pressed', 'false');
  });

  it('rejects feedback responses owned by a different Turn without replacing prior state', async () => {
    const user = userEvent.setup();
    const priorFeedback = {
      turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
      agentId: 'agent_assistant',
      rating: 'good' as const,
      note: null,
      createdAt: '2026-07-21T00:00:03.000Z',
    };
    const mismatchedResponse = {
      ...priorFeedback,
      turnId: 'tu_00000000-0000-7229-bfed-21858f0c8836',
      rating: 'bad' as const,
      createdAt: '2026-07-21T00:00:04.000Z',
    };
    const retryResponse = {
      ...priorFeedback,
      rating: 'bad' as const,
      createdAt: '2026-07-21T00:00:05.000Z',
    };
    const submitTurnFeedback = vi
      .fn()
      .mockResolvedValueOnce(mismatchedResponse)
      .mockResolvedValueOnce(retryResponse);
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: [ITEMS[1]], nextCursor: null }),
      },
      {
        'thread.dashboard': vi.fn().mockResolvedValue({
          pendingRequests: [
            {
              requestId: 'ap1',
              canRespond: true,
              approvalEffect: {
                status: 'available',
                summary: 'Summary: Approval',
                detail: '{"effect":{"amount":5}}',
              },
              state: 'pending',
              resolution: null,
              ending: null,
              disposition: null,
            },
          ],
          turns: [COMPLETED_TURN],
        }),
        'turn.feedback': submitTurnFeedback,
      }
    );
    const queryClient = renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client,
      (cache) => {
        cache.setQueryData(
          chatKeys.feedback(
            'ws_00000000-0000-7b10-9af8-12fd37a880e0',
            'th_00000000-0000-70a0-9cde-4561f64881c6',
            'tu_00000000-0000-7da3-a7fc-80982f9b215e'
          ),
          priorFeedback
        );
      }
    );

    const goodButton = await screen.findByRole('button', { name: /good/i });
    const badButton = screen.getByRole('button', { name: /bad/i });
    await user.click(badButton);

    expect(await screen.findByRole('alert')).toHaveTextContent("Couldn't save feedback.");
    expect(
      queryClient.getQueryData(
        chatKeys.feedback(
          'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          'th_00000000-0000-70a0-9cde-4561f64881c6',
          'tu_00000000-0000-7da3-a7fc-80982f9b215e'
        )
      )
    ).toEqual(priorFeedback);
    expect(
      queryClient.getQueryData(
        chatKeys.feedback(
          'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          'th_00000000-0000-70a0-9cde-4561f64881c6',
          'tu_00000000-0000-7229-bfed-21858f0c8836'
        )
      )
    ).toBeUndefined();
    expect(goodButton).toHaveAttribute('aria-pressed', 'true');
    expect(badButton).toHaveAttribute('aria-pressed', 'false');

    await user.click(screen.getByRole('button', { name: 'Try again' }));
    await waitFor(() =>
      expect(submitTurnFeedback).toHaveBeenNthCalledWith(2, {
        turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
        rating: 'bad',
        note: null,
      })
    );
    await waitFor(() => expect(badButton).toHaveAttribute('aria-pressed', 'true'));
    expect(
      queryClient.getQueryData(
        chatKeys.feedback(
          'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          'th_00000000-0000-70a0-9cde-4561f64881c6',
          'tu_00000000-0000-7229-bfed-21858f0c8836'
        )
      )
    ).toBeUndefined();
  });
});

describe('conversation artifact inspection', () => {
  const reference = ArtifactReferenceItemSchema.parse({
    ...ITEMS[0],
    type: 'artifact-reference',
    id: 'it_00000000-0000-757c-bc4f-599212addef5',
    artifactId: 'ar_00000000-0000-7494-9abc-bc7b8306139b',
    artifactVersion: 1,
    lastMutationRequestId: 'req-artifact',
    title: 'Workspace changes ready for review',
    summary: '1 changed path staged for human review.',
  });
  const artifact = ArtifactSchema.parse({
    id: 'ar_00000000-0000-7494-9abc-bc7b8306139b',
    workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
    threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
    turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
    kind: 'diff',
    title: reference.title,
    status: 'ready',
    summary: reference.summary,
    version: 1,
    content: { format: 'text', body: 'diff --git a/example.txt b/example.txt\n+Reviewed content' },
    contentDigest: `sha256:${'a'.repeat(64)}`,
    lastMutationRequestId: 'req-artifact',
    origin: {
      kind: 'turn-output',
      threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
      turnId: 'tu_00000000-0000-7da3-a7fc-80982f9b215e',
      requestId: 'req-artifact',
    },
    createdAt: reference.createdAt,
    updatedAt: reference.createdAt,
  });

  it('distinguishes saved outputs from file-change records in the side panel and stream', async () => {
    const path = `src/${'long_file_name_'.repeat(12)}.ts`;
    const file = ItemSchema.parse({
      ...ITEMS[0],
      id: 'it_00000000-0000-7f8f-9ccf-39fc6fcf8be8',
      type: 'file-change',
      path,
      changeKind: 'modified',
    });
    const duplicate = ArtifactReferenceItemSchema.parse({
      ...reference,
      id: 'it_00000000-0000-7ebc-9433-5c60d4670618',
      lastMutationRequestId: 'req-artifact-again',
    });
    const laterVersion = ArtifactReferenceItemSchema.parse({
      ...reference,
      id: 'it_00000000-0000-7696-a90c-ad8b3e75d0d1',
      artifactVersion: 2,
      title: 'Workspace changes after revision',
      lastMutationRequestId: 'req-artifact-v2',
    });
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient({
        'thread.items': vi.fn().mockResolvedValue({
          items: [reference, duplicate, laterVersion, file],
          nextCursor: null,
        }),
      })
    );
    const panel = await screen.findByRole('complementary', { name: 'Side panel' });
    expect(await within(panel).findByText('Saved output · Version 1')).toBeInTheDocument();
    expect(within(panel).getAllByText('Saved output · Version 1')).toHaveLength(1);
    expect(within(panel).getAllByText('Saved output · Version 2')).toHaveLength(1);
    expect(within(panel).getByText('File change · modified')).toBeInTheDocument();
    expect(within(panel).getByText(reference.title)).toBeVisible();
    expect(within(panel).getByText(laterVersion.title)).toBeVisible();
    expect(within(panel).getByText(path)).toBeVisible();
    expect(screen.getAllByText('Saved output · Version 1')).toHaveLength(3);
    expect(screen.getAllByText('Saved output · Version 2')).toHaveLength(2);
    expect(screen.getAllByText('File change · modified')).toHaveLength(2);
  });

  it('opens the referenced content from both the stream and side panel only on demand', async () => {
    const user = userEvent.setup();
    const getArtifact = vi.fn().mockResolvedValue(artifact);
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient({
        'thread.items': vi.fn().mockResolvedValue({ items: [reference], nextCursor: null }),
        'artifact.read': getArtifact,
      })
    );
    await screen.findAllByText(reference.title);
    expect(getArtifact).not.toHaveBeenCalled();
    await user.click(screen.getAllByRole('button', { name: 'View content' })[0]);
    const dialog = await screen.findByRole('dialog', { name: reference.title });
    expect(await within(dialog).findByText(/Reviewed content/)).toBeInTheDocument();
    expect(getArtifact).toHaveBeenCalledWith({
      workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
      artifactId: 'ar_00000000-0000-7494-9abc-bc7b8306139b',
    });
    expect(within(dialog).getByText('Version 1')).toBeInTheDocument();
    await user.click(within(dialog).getByRole('button', { name: 'Close' }));
    await user.click(
      within(screen.getByRole('complementary', { name: 'Side panel' })).getByRole('button', {
        name: 'View content',
      })
    );
    expect(await screen.findByRole('dialog', { name: reference.title })).toBeInTheDocument();
  });

  it('shows load failure with retry and never labels a newer version as the referenced content', async () => {
    const user = userEvent.setup();
    const getArtifact = vi
      .fn()
      .mockRejectedValueOnce(new Error('unavailable'))
      .mockResolvedValue({ ...artifact, version: 2 });
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient({
        'thread.items': vi.fn().mockResolvedValue({ items: [reference], nextCursor: null }),
        'artifact.read': getArtifact,
      })
    );
    await user.click((await screen.findAllByRole('button', { name: 'View content' }))[0]);
    const dialog = await screen.findByRole('dialog');
    expect(await within(dialog).findByText("Couldn't load that artifact.")).toBeInTheDocument();
    await user.click(within(dialog).getByRole('button', { name: /Try again/i }));
    expect(
      await within(dialog).findByText(
        /This message references version 1, but the artifact is now version 2/
      )
    ).toBeInTheDocument();
    expect(within(dialog).queryByText(/Reviewed content/)).not.toBeInTheDocument();
  });
  it('makes recorded workspace paths and patch readable without treating the snapshot as a current decision', async () => {
    const user = userEvent.setup();
    const body = JSON.stringify({
      changeSet: {
        id: 'cs1',
        workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
        resourceId: 'default',
        materializationRecordId: 'mat1',
        inputSnapshotId: 'snap1',
        strategy: 'git',
        base: { commit: 'abc', contentDigest: null },
        head: { commit: 'def', contentDigest: null },
        changedPaths: [{ path: 'example.txt', status: 'added', binary: false }],
        patch: { ref: 'artifact://patch', digest: 'sha256:patch', bytes: 8 },
        bundle: null,
        artifactIds: ['ar_00000000-0000-7494-9abc-bc7b8306139b'],
        evidenceRefs: [],
        redaction: { status: 'redacted', notes: [] },
        createdAt: reference.createdAt,
      },
      patchPayload: {
        mediaType: 'text/x-diff',
        text: '+new line',
        bytes: 8,
        digest: 'sha256:patch',
      },
      review: {
        id: 'review1',
        changeSetId: 'cs1',
        workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
        status: 'pending',
        staging: { strategy: 'git_worktree', ref: 'staging://review1', branch: null },
        diffSummary: { filesChanged: 1, additions: 1, deletions: 0 },
        riskSummary: 'One changed path.',
        validation: [],
        actionCenterRowId: 'ws_00000000-0000-760b-95ac-b784a71280a8:review1',
        createdAt: reference.createdAt,
        updatedAt: reference.createdAt,
      },
    });
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient({
        'thread.items': vi.fn().mockResolvedValue({ items: [reference], nextCursor: null }),
        'artifact.read': vi
          .fn()
          .mockResolvedValue({ ...artifact, content: { format: 'json', body } }),
      })
    );
    await user.click((await screen.findAllByRole('button', { name: 'View content' }))[0]);
    const dialog = await screen.findByRole('dialog');
    expect(await within(dialog).findByText('example.txt')).toBeInTheDocument();
    expect(within(dialog).getByText('+new line')).toBeInTheDocument();
    expect(within(dialog).getByText('Type: Workspace change review')).toBeInTheDocument();
    expect(
      within(dialog).getByText(/Current review decisions are available in Workspace changes/)
    ).toBeInTheDocument();
    expect(within(dialog).queryByRole('button', { name: 'Accept' })).not.toBeInTheDocument();
  });
});

describe('approval decision evidence', () => {
  const decision = ItemSchema.parse({
    ...ITEMS[0],
    id: 'it_00000000-0000-7e60-a164-5c61d0b124bc',
    type: 'approval-decision',
    actor: { kind: 'user', id: 'usr_00000000-0000-7706-800d-9f6504ae7325' },
    approvalRequestId: 'ap1',
    causationId: 'it_00000000-0000-7570-9913-dd37f2bda2fe',
    decision: 'denied',
    decidedAt: '2026-07-21T00:00:03.000Z',
  });

  it('uses the recorded human identity and time without guessing a reason or client', async () => {
    const human = ItemSchema.parse({
      ...decision,
      actor: { kind: 'user', id: 'usr_00000000-0000-7706-800d-9f6504ae7325' },
      causationId: 'req-denial',
    });
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient(
        {
          'thread.items': vi.fn().mockResolvedValue({ items: [...ITEMS, human], nextCursor: null }),
        },
        {
          'thread.dashboard': vi.fn().mockResolvedValue({
            turns: [],
            pendingRequests: [
              {
                requestId: 'uir1',
                state: 'pending',
                resolution: null,
                ending: null,
                disposition: null,
              },
            ],
            viewerUserId: 'usr_00000000-0000-7ae3-81c6-235923895900',
            participants: [
              {
                kind: 'user',
                id: 'usr_00000000-0000-7706-800d-9f6504ae7325',
                displayName: 'Alex Chen',
              },
            ],
          }),
        }
      )
    );
    expect(await screen.findByText('by Alex Chen')).toBeInTheDocument();
    expect(screen.getByText('Decision time')).toBeInTheDocument();
    expect(screen.getByText('No reason was recorded.')).toBeInTheDocument();
    expect(screen.getByText('Not recorded')).toBeInTheDocument();
    expect(screen.getByText('User decision')).toBeInTheDocument();
  });

  it('distinguishes an automatic policy grant from human approval and recovery', async () => {
    const grant = ItemSchema.parse({
      ...decision,
      actor: { kind: 'system', id: 'nanocore-repo-push-policy', responsibleUserId: null },
      decision: 'granted',
    });
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient({
        'thread.items': vi.fn().mockResolvedValue({ items: [...ITEMS, grant], nextCursor: null }),
      })
    );
    expect(await screen.findByText('Repository push policy')).toBeInTheDocument();
    expect(
      screen.getByText('Automatically granted by the repository push policy.')
    ).toBeInTheDocument();
    expect(screen.queryByText('Inherited timestamp')).not.toBeInTheDocument();
  });
});

it('closes the outputs panel from inside and returns focus to its toggle', async () => {
  const user = userEvent.setup();
  renderApp(
    '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
    makeClient()
  );
  const panel = await screen.findByRole('complementary', { name: 'Side panel' });
  await user.click(within(panel).getByRole('button', { name: 'Close outputs' }));
  expect(screen.queryByRole('complementary', { name: 'Side panel' })).not.toBeInTheDocument();
  const toggle = screen.getByRole('button', { name: 'Show Side panel' });
  expect(toggle).toHaveFocus();
  expect(toggle).toHaveAttribute('aria-expanded', 'false');
  await user.click(toggle);
  expect(screen.getByRole('complementary', { name: 'Side panel' })).toBeInTheDocument();
  expect(screen.getByRole('button', { name: 'Hide Side panel' })).toHaveAttribute(
    'aria-expanded',
    'true'
  );
});

const WORKER_STORAGE_REF = 'wst_00000000-0000-70fd-914d-b51e699cd632';
const WORKER_LAYOUT_DIGEST = `sha256:${'e'.repeat(64)}`;
const WORKER_ENVIRONMENT = {
  attachmentGeneration: 1,
  contributors: [
    {
      attachmentGeneration: 1,
      createdAt: '2026-09-16T14:24:10.747Z',
      goalId: null,
      purpose: 'work' as const,
      responsibleUserId: 'usr_00000000-0000-7011-88df-c2b1e8466b6f',
      taskId: null,
      threadId: THREAD.id,
    },
  ],
  createdAt: '2026-09-16T14:24:10.746Z',
  layout: {
    family: 'openkit-worker',
    version: '1',
    uid: 1000,
    gid: 1000,
    workingDirectory: '/tmp/openkit-bootstrap',
    platform: { architecture: 'arm64', os: 'linux' },
    targets: [{ target: '/workspace' }, { target: '/sandbox' }],
  },
  layoutDigest: WORKER_LAYOUT_DIGEST,
  revision: 4,
  state: 'idle' as const,
  storageRef: WORKER_STORAGE_REF,
  updatedAt: '2026-09-16T15:05:28.713Z',
  workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
};

async function chooseNewTaskWorker(user: ReturnType<typeof userEvent.setup>) {
  await user.click(await screen.findByRole('button', { name: /Conversation agent/ }));
  await user.click(await screen.findByRole('option', { name: 'New task worker' }));
}

function workerSelectRequest(
  threadId: string,
  environment: Pick<
    typeof WORKER_ENVIRONMENT,
    'revision' | 'layoutDigest' | 'storageRef'
  > = WORKER_ENVIRONMENT
) {
  return {
    adjudicatedThreadIds: [],
    expectedRevision: environment.revision,
    goalId: null,
    layoutDigest: environment.layoutDigest,
    purpose: 'work' as const,
    storageRef: environment.storageRef,
    taskId: null,
    threadId,
  };
}

function workerEnvironmentOptionName(sourceLabel: string, occupancy: string, createdAt: string) {
  return `${sourceLabel} · ${occupancy} · Created ${new Date(createdAt).toLocaleString(undefined, { timeZoneName: 'short' })}`;
}

async function chooseRetainedEnvironment(
  user: ReturnType<typeof userEvent.setup>,
  optionName = workerEnvironmentOptionName(
    'Competitive teardown',
    'Idle',
    WORKER_ENVIRONMENT.createdAt
  ),
  storageRef = WORKER_STORAGE_REF
) {
  await user.click(screen.getByRole('button', { name: 'Add artifact or upload attachment' }));
  const details = screen.getByText('Advanced settings').closest('details');
  expect(details).toBeInstanceOf(HTMLDetailsElement);
  expect((details as HTMLDetailsElement).open).toBe(false);
  await user.click(screen.getByText('Advanced settings'));
  await waitFor(() => expect(screen.getByRole('option', { name: optionName })).toBeInTheDocument());
  await user.selectOptions(
    screen.getByRole('combobox', { name: 'Worker environment' }),
    storageRef
  );
  await user.keyboard('{Escape}');
}

describe('Worker environment Advanced choice', () => {
  it('omits a new-environment choice and does not list or select retained storage', async () => {
    const user = userEvent.setup();
    const listWorkerEnvironments = vi.fn();
    const selectWorkerEnvironment = vi.fn();
    const submitConversation = vi.fn().mockResolvedValue({
      ...CHAT_MODE_RESPONSE,
      targetRef: 'new-task-worker',
    });
    const client = makeClient(
      { 'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }) },
      {
        'worker-environment.list': listWorkerEnvironments,
        'worker-environment.select': selectWorkerEnvironment,
        'conversation.submit': submitConversation,
      }
    );
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    await chooseNewTaskWorker(user);
    await user.type(await screen.findByRole('textbox', { name: 'Message' }), 'Fresh worker');
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    await waitFor(() =>
      expect(submitConversation).toHaveBeenCalledWith(
        expect.objectContaining({
          workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
          ...{
            input: 'Fresh worker',
            targetRef: 'new-task-worker',
          },
        })
      )
    );
    expect(submitConversation.mock.calls[0]?.[0]).not.toHaveProperty('workerStorageChoice');
    expect(listWorkerEnvironments).not.toHaveBeenCalled();
    expect(selectWorkerEnvironment).not.toHaveBeenCalled();
    expect(screen.queryByRole('button', { name: /environment/i })).not.toBeInTheDocument();
  });

  it('labels occupancy from Thread names and shows independent-review as lineage, not Task purpose', async () => {
    const user = userEvent.setup();
    const attachedRef = 'wst_00000000-0000-77bf-8428-f147a9737e89';
    const attachedThread = {
      ...THREAD,
      id: 'th_00000000-0000-7f90-a51d-ce0a575ee74f',
      name: 'Goal closeout',
      preview: 'Goal closeout',
    };
    const attached = {
      ...WORKER_ENVIRONMENT,
      contributors: [
        {
          ...WORKER_ENVIRONMENT.contributors[0]!,
          purpose: 'independent-review' as const,
          threadId: attachedThread.id,
        },
      ],
      state: 'attached' as const,
      storageRef: attachedRef,
    };
    const selectWorkerEnvironment = vi.fn().mockResolvedValue({ selected: attached });
    const listWorkerEnvironments = vi.fn().mockResolvedValue({
      items: [WORKER_ENVIRONMENT, attached],
      nextCursor: null,
    });
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient(
        {
          'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
          'thread.list': vi.fn().mockResolvedValue({ items: [THREAD, attachedThread] }),
        },
        {
          'worker-environment.list': listWorkerEnvironments,
          'worker-environment.select': selectWorkerEnvironment,
        }
      )
    );
    await chooseNewTaskWorker(user);
    await user.click(screen.getByRole('button', { name: 'Add artifact or upload attachment' }));
    await user.click(screen.getByText('Advanced settings'));
    expect(
      await screen.findByRole('option', {
        name: workerEnvironmentOptionName(
          'Competitive teardown',
          'Idle',
          WORKER_ENVIRONMENT.createdAt
        ),
      })
    ).toBeInTheDocument();
    expect(
      screen.getByRole('option', {
        name: workerEnvironmentOptionName('Goal closeout', 'Attached', attached.createdAt),
      })
    ).toBeInTheDocument();
    await user.selectOptions(
      screen.getByRole('combobox', { name: 'Worker environment' }),
      attachedRef
    );
    expect(screen.getByText('Independent review from Goal closeout')).toBeInTheDocument();
    await waitFor(() =>
      expect(selectWorkerEnvironment).toHaveBeenCalledWith({
        workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
        ...workerSelectRequest('th_00000000-0000-70a0-9cde-4561f64881c6', attached),
      })
    );
    expect(screen.queryByText('Eligible')).not.toBeInTheDocument();
    expect(document.body).not.toHaveTextContent(WORKER_LAYOUT_DIGEST);
    expect(document.body).not.toHaveTextContent(WORKER_STORAGE_REF);
    expect(document.body).not.toHaveTextContent(attachedRef);
    expect(document.body).not.toHaveTextContent('th_00000000-0000-7f90-a51d-ce0a575ee74f');
  });

  it('previews select on an existing Thread then forwards the exact choice without a send-time select', async () => {
    const user = userEvent.setup();
    const listWorkerEnvironments = vi
      .fn()
      .mockResolvedValue({ items: [WORKER_ENVIRONMENT], nextCursor: null });
    const selectWorkerEnvironment = vi.fn().mockResolvedValue({ selected: WORKER_ENVIRONMENT });
    const submitConversation = vi.fn().mockResolvedValue({
      ...CHAT_MODE_RESPONSE,
      targetRef: 'new-task-worker',
    });
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
        'thread.list': vi.fn().mockResolvedValue({ items: [THREAD] }),
      },
      {
        'worker-environment.list': listWorkerEnvironments,
        'worker-environment.select': selectWorkerEnvironment,
        'conversation.submit': submitConversation,
      }
    );
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    await chooseNewTaskWorker(user);
    await chooseRetainedEnvironment(user);
    await user.click(screen.getByRole('button', { name: 'Add artifact or upload attachment' }));
    await waitFor(() =>
      expect(selectWorkerEnvironment).toHaveBeenCalledWith({
        workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
        ...workerSelectRequest('th_00000000-0000-70a0-9cde-4561f64881c6'),
      })
    );
    expect(screen.getByRole('combobox', { name: 'Worker environment' })).toHaveDisplayValue(
      workerEnvironmentOptionName('Competitive teardown', 'Idle', WORKER_ENVIRONMENT.createdAt)
    );
    expect(screen.getByText('Idle')).toBeInTheDocument();
    expect(
      screen.getByText('Preview passed. Task permissions are checked again when you send.')
    ).toBeInTheDocument();
    expect(document.body).not.toHaveTextContent(WORKER_STORAGE_REF);
    expect(document.body).not.toHaveTextContent('/tmp/openkit-bootstrap');
    expect(document.body).not.toHaveTextContent(WORKER_LAYOUT_DIGEST);
    await user.keyboard('{Escape}');
    await user.type(screen.getByRole('textbox', { name: 'Message' }), 'Reuse worker');
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    await waitFor(() =>
      expect(submitConversation).toHaveBeenCalledWith(
        expect.objectContaining({
          workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          threadId: 'th_00000000-0000-70a0-9cde-4561f64881c6',
          ...{
            input: 'Reuse worker',
            targetRef: 'new-task-worker',
            workerStorageChoice: {
              expectedRevision: 4,
              kind: 'selected',
              purpose: 'work',
              storageRef: WORKER_STORAGE_REF,
            },
          },
        })
      )
    );
    expect(submitConversation.mock.calls[0]?.[0]).not.toHaveProperty(
      'workerEnvironmentLayoutDigest'
    );
    expect(selectWorkerEnvironment).toHaveBeenCalledTimes(1);
    expect(selectWorkerEnvironment.mock.invocationCallOrder[0]).toBeLessThan(
      submitConversation.mock.invocationCallOrder[0] ?? 0
    );
  });

  it('tells a starter that send checks permission and retries the exact submit after transport failure', async () => {
    const user = userEvent.setup();
    const createThread = vi
      .fn()
      .mockResolvedValue({ ...THREAD, id: 'th_00000000-0000-75c2-bada-0a01c17d153e' });
    const listWorkerEnvironments = vi
      .fn()
      .mockResolvedValue({ items: [WORKER_ENVIRONMENT], nextCursor: null });
    const selectWorkerEnvironment = vi.fn();
    const submitConversation = vi.fn().mockRejectedValue(new Error('chat_mode_unavailable'));
    const client = makeClient(
      {
        'thread.create': createThread,
        'artifact.list': vi.fn().mockResolvedValue({
          items: [
            { id: 'ar_00000000-0000-7fcd-91a3-6acf6c2aee4e', version: 2, title: 'Existing brief' },
          ],
        }),
        'thread.read': vi
          .fn()
          .mockResolvedValue({ ...THREAD, id: 'th_00000000-0000-75c2-bada-0a01c17d153e' }),
        'thread.list': vi.fn().mockResolvedValue({ items: [THREAD] }),
      },
      {
        'worker-environment.list': listWorkerEnvironments,
        'worker-environment.select': selectWorkerEnvironment,
        'conversation.submit': submitConversation,
      }
    );
    renderApp('/chat', client);
    await chooseNewTaskWorker(user);
    await user.click(screen.getByRole('button', { name: 'Add artifact or upload attachment' }));
    await user.click(screen.getByText('Advanced settings'));
    await waitFor(() =>
      expect(
        screen.getByRole('option', {
          name: workerEnvironmentOptionName(
            'Competitive teardown',
            'Idle',
            WORKER_ENVIRONMENT.createdAt
          ),
        })
      ).toBeInTheDocument()
    );
    await user.selectOptions(
      screen.getByRole('combobox', { name: 'Worker environment' }),
      WORKER_STORAGE_REF
    );
    expect(screen.getByText('Permission is checked when you send.')).toBeInTheDocument();
    expect(selectWorkerEnvironment).not.toHaveBeenCalled();
    await user.click(await screen.findByRole('button', { name: 'Existing brief' }));
    await user.keyboard('{Escape}');
    const input = await screen.findByRole('textbox', { name: 'Message' });
    await user.type(input, 'Starter reuse');
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    expect(await screen.findByText("Couldn't send that message. Try again.")).toBeInTheDocument();
    await waitFor(() => expect(submitConversation).toHaveBeenCalledTimes(1));
    expect(createThread.mock.invocationCallOrder[0]).toBeLessThan(
      submitConversation.mock.invocationCallOrder[0] ?? 0
    );
    expect(selectWorkerEnvironment).not.toHaveBeenCalled();
    const submitted = submitConversation.mock.calls[0]?.[0] as { requestId: string };
    expect(screen.getByRole('textbox', { name: 'Message' })).toHaveValue('Starter reuse');
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    await waitFor(() => expect(submitConversation).toHaveBeenCalledTimes(2));
    expect(submitConversation.mock.calls[1]?.[0]).toMatchObject({
      input: 'Starter reuse',
      artifactRefs: [{ artifactId: 'ar_00000000-0000-7fcd-91a3-6acf6c2aee4e', artifactVersion: 2 }],
      requestId: submitted.requestId,
      targetRef: 'new-task-worker',
      workerStorageChoice: {
        expectedRevision: 4,
        kind: 'selected',
        purpose: 'work',
        storageRef: WORKER_STORAGE_REF,
      },
    });
    expect(submitConversation.mock.calls[1]).toEqual(submitConversation.mock.calls[0]);
    expect(createThread).toHaveBeenCalledTimes(1);
    expect(selectWorkerEnvironment).not.toHaveBeenCalled();
  });

  it.each([
    '/chat',
    '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
  ])('starts a fresh request only on explicit Send from %s after definitive Chat cancellation and retries that identity after transport uncertainty', async (path) => {
    const user = userEvent.setup();
    const threadId =
      path === '/chat'
        ? 'th_00000000-0000-75c2-bada-0a01c17d153e'
        : 'th_00000000-0000-70a0-9cde-4561f64881c6';
    const originalId = '00000000-0000-4000-8000-000000000911';
    const freshId = '00000000-0000-4000-8000-000000000912';
    const randomUUID = vi
      .spyOn(crypto, 'randomUUID')
      .mockReturnValueOnce(originalId)
      .mockReturnValueOnce(freshId)
      .mockReturnValue('00000000-0000-4000-8000-000000000913');
    onTestFinished(() => randomUUID.mockRestore());
    const submitConversation = vi
      .fn()
      .mockRejectedValueOnce(
        new ApiCallError(499, 'Private cancellation detail', { code: 'provider_call_aborted' })
      )
      .mockRejectedValue(new TypeError('Private transport detail'));
    renderApp(
      path,
      makeClient(
        {
          'thread.read': vi.fn().mockResolvedValue({ ...THREAD, id: threadId }),
          'thread.list': vi.fn().mockResolvedValue({ items: [THREAD] }),
          'artifact.list': vi.fn().mockResolvedValue({
            items: [
              {
                id: 'ar_00000000-0000-7fcd-91a3-6acf6c2aee4e',
                version: 2,
                title: 'Existing brief',
              },
            ],
          }),
        },
        {
          'conversation.submit': submitConversation,
          'conversation.targets': vi.fn().mockResolvedValue({
            ...CONVERSATION_TARGET,
            targets: CONVERSATION_TARGET.targets.map((target) => ({
              ...target,
              logicalModels: [
                ...target.logicalModels,
                { id: 'alternate', label: 'Alternate model', capabilities: ['chat'] },
              ],
            })),
          }),
          'worker-environment.list': vi
            .fn()
            .mockResolvedValue({ items: [WORKER_ENVIRONMENT], nextCursor: null }),
          'worker-environment.select': vi.fn().mockResolvedValue({ selected: WORKER_ENVIRONMENT }),
        }
      )
    );
    await user.click(await screen.findByRole('button', { name: /Logical model/ }));
    await user.click(await screen.findByRole('option', { name: 'Alternate model' }));
    await user.click(screen.getByRole('button', { name: 'Add artifact or upload attachment' }));
    await user.click(await screen.findByRole('button', { name: 'Existing brief' }));
    await user.keyboard('{Escape}');
    await user.type(screen.getByRole('textbox', { name: 'Message' }), 'Original Chat draft');
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    const cancellationExplanation = (
      await screen.findByText(/This turn was stopped|Couldn't send that message/)
    ).textContent;
    expect(submitConversation).toHaveBeenCalledTimes(1);
    expect(submitConversation.mock.calls[0]?.[0]).toMatchObject({
      requestId: originalId,
      targetRef: 'internal-role:assistant',
      logicalModelId: 'alternate',
    });
    expect(screen.getByRole('textbox', { name: 'Message' })).toHaveValue('Original Chat draft');
    expect(
      await screen.findByRole('button', { name: /Alternate model.*Logical model/ })
    ).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Remove Existing brief' })).toBeInTheDocument();
    expect(randomUUID).toHaveBeenCalledTimes(1);
    expect(document.body).not.toHaveTextContent('Private cancellation detail');

    // The cancelled request remains retained while the user prepares different, valid Worker work.
    await user.clear(screen.getByRole('textbox', { name: 'Message' }));
    await user.type(screen.getByRole('textbox', { name: 'Message' }), 'Replacement work');
    await chooseNewTaskWorker(user);
    await chooseRetainedEnvironment(user);
    expect(randomUUID).toHaveBeenCalledTimes(1);
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    expect(await screen.findByText("Couldn't send that message. Try again.")).toBeInTheDocument();
    expect(submitConversation).toHaveBeenCalledTimes(2);
    const freshDraft = {
      input: 'Replacement work',
      targetRef: 'new-task-worker',
      logicalModelId: 'alternate',
      artifactRefs: [{ artifactId: 'ar_00000000-0000-7fcd-91a3-6acf6c2aee4e', artifactVersion: 2 }],
      requestId: freshId,
      workerStorageChoice: {
        expectedRevision: 4,
        kind: 'selected',
        purpose: 'work',
        storageRef: WORKER_STORAGE_REF,
      },
    };
    expect(submitConversation.mock.calls[1]).toEqual([
      { workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0', threadId: threadId, ...freshDraft },
    ]);
    expect(cancellationExplanation).toBe('This turn was stopped. Send starts a new turn.');
    expect(randomUUID).toHaveBeenCalledTimes(2);
    expect(screen.getByRole('textbox', { name: 'Message' })).toHaveValue('Replacement work');
    expect(document.body).not.toHaveTextContent('Private transport detail');
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    await waitFor(() => expect(submitConversation).toHaveBeenCalledTimes(3));
    expect(submitConversation.mock.calls[2]).toEqual([
      { workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0', threadId: threadId, ...freshDraft },
    ]);
    expect(randomUUID).toHaveBeenCalledTimes(2);
  });

  it('keeps a stale retained choice after server send denial and does not substitute a new environment', async () => {
    const user = userEvent.setup();
    const listWorkerEnvironments = vi
      .fn()
      .mockResolvedValue({ items: [WORKER_ENVIRONMENT], nextCursor: null });
    const selectWorkerEnvironment = vi.fn().mockResolvedValue({ selected: WORKER_ENVIRONMENT });
    const submitConversation = vi.fn().mockRejectedValue(
      new ApiCallError(409, 'Worker environment revision changed.', {
        code: 'revision_conflict',
      })
    );
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
        'thread.list': vi.fn().mockResolvedValue({ items: [THREAD] }),
      },
      {
        'worker-environment.list': listWorkerEnvironments,
        'worker-environment.select': selectWorkerEnvironment,
        'conversation.submit': submitConversation,
      }
    );
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    await chooseNewTaskWorker(user);
    await chooseRetainedEnvironment(user);
    const input = screen.getByRole('textbox', { name: 'Message' });
    await user.type(input, 'Stale reuse');
    await user.click(screen.getByRole('button', { name: 'Send message' }));
    expect(await screen.findByText("Couldn't send that message. Try again.")).toBeInTheDocument();
    await waitFor(() => expect(submitConversation).toHaveBeenCalledTimes(1));
    expect(selectWorkerEnvironment).toHaveBeenCalledTimes(1);
    expect(submitConversation.mock.calls[0]?.[0]).toMatchObject({
      input: 'Stale reuse',
      workerStorageChoice: {
        expectedRevision: 4,
        kind: 'selected',
        purpose: 'work',
        storageRef: WORKER_STORAGE_REF,
      },
    });
    expect(input).toHaveValue('Stale reuse');
    expect(document.body).not.toHaveTextContent('revision_conflict');
    await user.click(screen.getByRole('button', { name: 'Add artifact or upload attachment' }));
    expect(screen.getByRole('combobox', { name: 'Worker environment' })).toHaveValue(
      WORKER_STORAGE_REF
    );
  });

  it('shows idle occupancy with the actual select denial on an existing Thread', async () => {
    const user = userEvent.setup();
    const listWorkerEnvironments = vi
      .fn()
      .mockResolvedValue({ items: [WORKER_ENVIRONMENT], nextCursor: null });
    const selectWorkerEnvironment = vi.fn().mockRejectedValue(
      new ApiCallError(403, 'Current deployment administrator authority is required.', {
        code: 'deployment_admin_required',
      })
    );
    const client = makeClient(
      {
        'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
        'thread.list': vi.fn().mockResolvedValue({ items: [THREAD] }),
      },
      {
        'worker-environment.list': listWorkerEnvironments,
        'worker-environment.select': selectWorkerEnvironment,
      }
    );
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    await chooseNewTaskWorker(user);
    await chooseRetainedEnvironment(user);
    await user.click(screen.getByRole('button', { name: 'Add artifact or upload attachment' }));
    expect(await screen.findByText('Idle')).toBeInTheDocument();
    expect(
      await screen.findByText('Current deployment administrator authority is required.')
    ).toBeInTheDocument();
    expect(screen.queryByText('Eligible')).not.toBeInTheDocument();
    expect(document.body).not.toHaveTextContent('deployment_admin_required');
    expect(selectWorkerEnvironment).toHaveBeenCalledTimes(1);
    expect(selectWorkerEnvironment).toHaveBeenCalledWith({
      workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
      ...workerSelectRequest('th_00000000-0000-70a0-9cde-4561f64881c6'),
    });
  });

  it('preserves the selected retained environment when inventory order changes', async () => {
    const user = userEvent.setup();
    const otherRef = 'wst_00000000-0000-77bf-8428-f147a9737e89';
    const otherThread = {
      ...THREAD,
      id: 'th_00000000-0000-7f90-a51d-ce0a575ee74f',
      name: 'Goal closeout',
      preview: 'Goal closeout',
    };
    const other = {
      ...WORKER_ENVIRONMENT,
      contributors: [
        {
          ...WORKER_ENVIRONMENT.contributors[0]!,
          threadId: otherThread.id,
        },
      ],
      storageRef: otherRef,
    };
    const listWorkerEnvironments = vi
      .fn()
      .mockResolvedValueOnce({ items: [WORKER_ENVIRONMENT, other], nextCursor: null })
      .mockResolvedValue({ items: [other], nextCursor: null });
    const selectWorkerEnvironment = vi.fn().mockResolvedValue({ selected: WORKER_ENVIRONMENT });
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient(
        {
          'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
          'thread.list': vi.fn().mockResolvedValue({ items: [THREAD, otherThread] }),
        },
        {
          'worker-environment.list': listWorkerEnvironments,
          'worker-environment.select': selectWorkerEnvironment,
        }
      )
    );
    await chooseNewTaskWorker(user);
    await chooseRetainedEnvironment(user);
    await user.click(screen.getByRole('button', { name: 'Add artifact or upload attachment' }));
    expect(screen.getByRole('combobox', { name: 'Worker environment' })).toHaveValue(
      WORKER_STORAGE_REF
    );
    await user.click(screen.getByText('Advanced settings'));
    await waitFor(() => expect(listWorkerEnvironments).toHaveBeenCalledTimes(2));
    expect(
      screen.getByRole('option', {
        name: workerEnvironmentOptionName('Goal closeout', 'Idle', other.createdAt),
      })
    ).toBeInTheDocument();
    expect(
      screen.getByRole('option', {
        name: workerEnvironmentOptionName(
          'Competitive teardown',
          'Idle',
          WORKER_ENVIRONMENT.createdAt
        ),
      })
    ).toBeInTheDocument();
    expect(screen.getByRole('combobox', { name: 'Worker environment' })).toHaveValue(
      WORKER_STORAGE_REF
    );
    expect(screen.getByRole('combobox', { name: 'Worker environment' })).toHaveDisplayValue(
      workerEnvironmentOptionName('Competitive teardown', 'Idle', WORKER_ENVIRONMENT.createdAt)
    );
    expect(selectWorkerEnvironment).toHaveBeenCalledTimes(1);
  });

  it('distinguishes same-source retained environments by recorded creation time', async () => {
    const user = userEvent.setup();
    const laterAt = '2026-09-16T16:40:22.100Z';
    const laterRef = 'wst_00000000-0000-77bf-8428-f147a9737e89';
    const later = {
      ...WORKER_ENVIRONMENT,
      createdAt: laterAt,
      storageRef: laterRef,
      updatedAt: laterAt,
    };
    const listWorkerEnvironments = vi.fn().mockResolvedValue({
      items: [WORKER_ENVIRONMENT, later],
      nextCursor: null,
    });
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      makeClient(
        {
          'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }),
          'thread.list': vi.fn().mockResolvedValue({ items: [THREAD] }),
        },
        { 'worker-environment.list': listWorkerEnvironments }
      )
    );
    await chooseNewTaskWorker(user);
    await user.click(screen.getByRole('button', { name: 'Add artifact or upload attachment' }));
    await user.click(screen.getByText('Advanced settings'));
    const earlierName = workerEnvironmentOptionName(
      'Competitive teardown',
      'Idle',
      WORKER_ENVIRONMENT.createdAt
    );
    const laterName = workerEnvironmentOptionName('Competitive teardown', 'Idle', laterAt);
    expect(await screen.findByRole('option', { name: earlierName })).toBeInTheDocument();
    expect(screen.getByRole('option', { name: laterName })).toBeInTheDocument();
    await user.selectOptions(
      screen.getByRole('combobox', { name: 'Worker environment' }),
      laterRef
    );
    expect(screen.getByRole('combobox', { name: 'Worker environment' })).toHaveDisplayValue(
      laterName
    );
    expect(
      screen.getByRole('dialog', { name: 'Attachments' }).querySelector('time')
    ).toHaveAttribute('datetime', laterAt);
    expect(document.body).not.toHaveTextContent(WORKER_STORAGE_REF);
    expect(document.body).not.toHaveTextContent(laterRef);
    expect(document.body).not.toHaveTextContent(WORKER_LAYOUT_DIGEST);
  });

  it('shows list denial without widening authority', async () => {
    const user = userEvent.setup();
    const listWorkerEnvironments = vi.fn().mockRejectedValue(
      new ApiCallError(403, 'Current deployment administrator authority is required.', {
        code: 'deployment_admin_required',
      })
    );
    const client = makeClient(
      { 'thread.items': vi.fn().mockResolvedValue({ items: ITEMS, nextCursor: null }) },
      { 'worker-environment.list': listWorkerEnvironments }
    );
    renderApp(
      '/chat/ws_00000000-0000-7b10-9af8-12fd37a880e0/th_00000000-0000-70a0-9cde-4561f64881c6',
      client
    );
    await chooseNewTaskWorker(user);
    await user.click(screen.getByRole('button', { name: 'Add artifact or upload attachment' }));
    await user.click(screen.getByText('Advanced settings'));
    expect(await screen.findByText('Access denied')).toBeInTheDocument();
    expect(listWorkerEnvironments).toHaveBeenCalledWith({
      workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
      ...{ limit: 100 },
    });
    expect(screen.queryByLabelText(/token/i)).not.toBeInTheDocument();
    expect(document.body).not.toHaveTextContent('deployment_admin_required');
  });
});
