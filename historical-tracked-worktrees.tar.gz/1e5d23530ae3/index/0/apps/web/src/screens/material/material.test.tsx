import { ApiCallError, type CoreClient, type GetArtifactResponse } from '@openkit/core-client';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { act, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import type { ReactNode } from 'react';
import { MemoryRouter } from 'react-router-dom';
import { beforeEach, describe, expect, expectTypeOf, it, vi } from 'vitest';
import { CoreClientProvider } from '../../app/core-client';
import { AppRoutes } from '../../app/routes';
import { SURFACES } from '../../app/surfaces';
import type { ArtifactReview } from '../goal/data';
import { useWorkspaceStore } from '../workspace-store';
import { useSaveWorkspaceMaterialRevision } from './data';
import { ProposalReview } from './ProposalReview';

const WORKSPACE_ID = 'ws_00000000-0000-7a9e-899a-fcc8ac1a4a55';
const THREAD_ID = 'th_00000000-0000-7797-b2b8-f3be78117473';
const MATERIAL_ID = 'mat_00000000-0000-7afa-a16b-33440db6a104';
const TIMESTAMP = '2026-08-03T00:00:00.000Z';
const MATERIAL_ACTION_NAME =
  /new material|create material|save|bind material|unbind|exclude|restore|send.*(?:now|current revision)|follow.?up|cancel/i;

it('requires an exact Thread id for every Material revision save', () => {
  expectTypeOf(useSaveWorkspaceMaterialRevision).parameter(2).toEqualTypeOf<string>();
});

const MATERIAL = {
  workspaceId: WORKSPACE_ID,
  materialId: MATERIAL_ID,
  title: 'Release notes',
  kind: 'markdown' as const,
  currentRevisionId: 'mrev_00000000-0000-730e-b6bf-17ca9153c337',
  sensitivity: 'internal' as const,
  createdAt: TIMESTAMP,
  updatedAt: TIMESTAMP,
};

const REVISION_1 = {
  workspaceId: WORKSPACE_ID,
  materialId: MATERIAL_ID,
  revisionId: 'mrev_00000000-0000-7dfd-b321-ac6a81c1b523',
  parentRevisionId: null,
  mediaType: 'text/markdown' as const,
  contentDigest: 'sha256:96dedef0f21abaa9874b529b84fa425c3c30af02596ac0962e2bbbb53abadf74',
  authorId: 'usr_00000000-0000-7609-aed5-db4b5c95e76c',
  createdAt: '2026-08-03T00:00:00.000Z',
  content: '# Release notes\nFirst draft.\n',
};

const REVISION_2 = {
  workspaceId: WORKSPACE_ID,
  materialId: MATERIAL_ID,
  revisionId: 'mrev_00000000-0000-730e-b6bf-17ca9153c337',
  parentRevisionId: REVISION_1.revisionId,
  mediaType: 'text/markdown' as const,
  contentDigest: 'sha256:67dd813bbaa3012d8dffe3a0555859cd323550f99d709830981dad5ba218b70f',
  authorId: 'usr_00000000-0000-7609-aed5-db4b5c95e76c',
  createdAt: '2026-08-03T00:01:00.000Z',
  content: '# Release notes\n',
};

const REVISION_2_SUMMARY = {
  workspaceId: WORKSPACE_ID,
  materialId: MATERIAL_ID,
  revisionId: REVISION_2.revisionId,
  parentRevisionId: REVISION_2.parentRevisionId,
  mediaType: REVISION_2.mediaType,
  contentDigest: REVISION_2.contentDigest,
  authorId: REVISION_2.authorId,
  createdAt: REVISION_2.createdAt,
};

const THREAD_QUEUED_REVISION_ID = 'mrev_00000000-0000-7cd8-b971-826dd13dc847';
const THREAD_RESTORED_QUEUE_ID = 'mrev_00000000-0000-7253-af1b-c5407afa6b7a';
const THREAD_MATERIAL = {
  workspaceId: WORKSPACE_ID,
  threadId: THREAD_ID,
  resource: MATERIAL,
  currentRevision: REVISION_2_SUMMARY,
  inclusionState: 'included' as const,
  latestQueuedRevisionId: THREAD_QUEUED_REVISION_ID,
  lastWorkerSeenRevisionId: 'mrev_00000000-0000-78ed-ba4a-524613b47324',
  currentTurnRevisionId: 'mrev_00000000-0000-750d-8a07-6d157a32106c',
  activeDelivery: null,
};

const NULL_THREAD_MATERIAL = {
  ...THREAD_MATERIAL,
  currentRevision: null,
  latestQueuedRevisionId: null,
  lastWorkerSeenRevisionId: null,
  currentTurnRevisionId: null,
};

type MethodOverrides = Partial<Record<string, unknown>>;

/** Creates a caller-controlled promise for proving pre-settlement UI state. */
function createDeferred<T>() {
  let resolve!: (value: T) => void;
  let reject!: (reason?: unknown) => void;
  const promise = new Promise<T>((resolvePromise, rejectPromise) => {
    resolve = resolvePromise;
    reject = rejectPromise;
  });
  return { promise, reject, resolve };
}

/** Build a fake Core Client whose Material operations remain individually observable. */
function makeClient(
  overrides: { operations?: MethodOverrides; core?: MethodOverrides } = {}
): CoreClient {
  return {
    core: {
      meta: vi.fn().mockResolvedValue({}),

      ...overrides.core,
    },
    operations: {
      'material.list': vi.fn().mockResolvedValue({ materials: [MATERIAL] }),
      'material.create': vi
        .fn()
        .mockResolvedValue({ materialId: 'mat_00000000-0000-72a5-8964-fa2b62341db0' }),
      'material.read': vi.fn().mockResolvedValue({ material: MATERIAL }),
      'material.revision-list': vi.fn().mockResolvedValue({
        revisions: [REVISION_1, REVISION_2].map(({ content: _content, ...revision }) => revision),
      }),
      'material.revision-read': vi.fn().mockImplementation(async ({ revisionId }) => {
        if (revisionId === REVISION_1.revisionId) {
          return { revision: REVISION_1 };
        }
        if (revisionId === REVISION_2.revisionId) {
          return { revision: REVISION_2 };
        }
        throw new Error(`Unknown revision id: ${revisionId}`);
      }),
      'material.revision-save': vi.fn().mockResolvedValue({
        materialId: MATERIAL_ID,
        revisionId: 'mrev_00000000-0000-7d6b-9c3a-1a2dc21c80d1',
      }),
      'material.thread-read': vi.fn().mockResolvedValue({ material: null }),
      'material.bind': vi.fn().mockResolvedValue({
        materialId: MATERIAL_ID,
        threadId: THREAD_ID,
        outcome: 'bound',
      }),
      'material.unbind': vi.fn().mockResolvedValue({
        materialId: MATERIAL_ID,
        threadId: THREAD_ID,
        outcome: 'unbound',
      }),
      'material.exclude': vi.fn().mockResolvedValue({
        materialId: MATERIAL_ID,
        threadId: THREAD_ID,
        outcome: 'excluded',
      }),
      'material.restore': vi.fn().mockResolvedValue({
        materialId: MATERIAL_ID,
        threadId: THREAD_ID,
        outcome: 'included',
      }),

      'thread.list': vi.fn().mockResolvedValue({ items: [] }),
      'turn.start': vi.fn(),
      'conversation.submit': vi.fn(),
      'task.start': vi.fn(),

      'thread.read': vi.fn().mockResolvedValue({
        id: THREAD_ID,
        workspaceId: WORKSPACE_ID,
        name: 'Release',
        status: 'active',
        createdAt: TIMESTAMP,
        updatedAt: TIMESTAMP,
      }),
      ...overrides.operations,
      'workspace.list': vi
        .fn()
        .mockResolvedValueOnce({
          items: [{ id: WORKSPACE_ID, name: 'Product workspace' }].map((workspace) => ({
            membershipStatus: 'active' as const,
            accessCause: 'membership' as const,
            workspace,
            effectiveRole: 'owner',
            membershipRevision: 1,
            ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
            registryRevision: 1,
          })),
        })
        .mockImplementation(
          (overrides.operations?.['workspace.list'] as
            | CoreClient['operations']['workspace.list']
            | undefined) ??
            vi.fn().mockResolvedValue({
              items: [{ id: WORKSPACE_ID, name: 'Product workspace' }].map((workspace) => ({
                membershipStatus: 'active' as const,
                accessCause: 'membership' as const,
                workspace,
                effectiveRole: 'owner',
                membershipRevision: 1,
                ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
                registryRevision: 1,
              })),
            })
        ),
    },
  } as unknown as CoreClient;
}

/** Resolve the route registered for the live Material surface without prescribing its path shape. */
function materialPath(materialId: string | null = MATERIAL_ID): string {
  const path = SURFACES.find(
    (surface) => surface.wp === 'WP-5' && /material/i.test(surface.title)
  )?.path;
  return (path ?? '/__missing-material-surface')
    .replace(/:workspaceId\??/, WORKSPACE_ID)
    .replace(/:threadId\??/, THREAD_ID)
    .replace(/:materialId\??/, materialId ?? '');
}

/** Render the registered Material route with isolated server state and client transport. */
function renderMaterial(
  client: CoreClient,
  materialId: string | null = MATERIAL_ID,
  initialPath = materialPath(materialId)
): void {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  const wrapper = (children: ReactNode) => (
    <QueryClientProvider client={queryClient}>
      <CoreClientProvider client={client}>
        <MemoryRouter initialEntries={[initialPath]}>{children}</MemoryRouter>
      </CoreClientProvider>
    </QueryClientProvider>
  );
  render(wrapper(<AppRoutes />));
}

beforeEach(() => {
  localStorage.clear();
  useWorkspaceStore.setState({ currentWorkspaceId: WORKSPACE_ID });
});

describe('Material route identity', () => {
  it.each([
    'plain',
    '/?#%',
    '%2F%3F%23%25',
  ])('preserves owner identifiers when selecting a Material with %s identifiers', async (suffix) => {
    const user = userEvent.setup();
    const workspaceId = `ws_${suffix}`;
    const threadId = `th_${suffix}`;
    const materialId = `mat_${suffix}`;
    const material = { ...MATERIAL, workspaceId, materialId };
    const readMaterial = vi.fn().mockResolvedValue({ material });
    const client = makeClient({
      operations: {
        'workspace.list': vi.fn().mockResolvedValue({
          items: [
            {
              workspace: { id: workspaceId, name: 'Exact Workspace' },
              effectiveRole: 'owner',
              membershipRevision: 1,
              ownerUserId: 'user_local',
              registryRevision: 1,
            },
          ],
        }),
        'material.list': vi.fn().mockResolvedValue({ materials: [material] }),
        'material.read': readMaterial,
        'material.revision-list': vi
          .fn()
          .mockResolvedValue({ revisions: [{ ...REVISION_2_SUMMARY, workspaceId, materialId }] }),
        'material.revision-read': vi.fn().mockResolvedValue({
          revision: {
            ...REVISION_2,
            workspaceId,
            materialId,
          },
        }),
        'material.thread-read': vi.fn().mockResolvedValue({ material: null }),
      },
    });
    renderMaterial(
      client,
      null,
      `/materials/${encodeURIComponent(workspaceId)}/${encodeURIComponent(threadId)}`
    );
    await user.click(await screen.findByRole('button', { name: new RegExp(material.title) }));
    await user.click(await screen.findByRole('button', { name: /^bind material$/i }));

    expect(readMaterial.mock.calls).toEqual([[{ workspaceId, materialId }]]);
    expect(client.operations['material.bind']).toHaveBeenCalledWith({
      workspaceId,
      threadId,
      materialId,
      expectedBindingState: 'not_bound',
    });
  });
});

describe('S19-F Material Workspace discovery barrier', () => {
  it.each([
    {
      settlement: 'empty',
      workspaces: [] as { id: string; name: string }[],
    },
    {
      settlement: 'authorized',
      workspaces: [{ id: WORKSPACE_ID, name: 'Product workspace' }],
    },
  ])('waits for discovery before projecting the $settlement settlement', async ({
    settlement,
    workspaces,
  }) => {
    const discovery = createDeferred<{ items: { workspace: { id: string; name: string } }[] }>();
    const client = makeClient({
      core: {},

      operations: { 'workspace.list': vi.fn().mockReturnValue(discovery.promise) },
    });
    const materialOperations = [
      client.operations['material.list'],
      client.operations['material.create'],
      client.operations['material.read'],
      client.operations['material.revision-list'],
      client.operations['material.revision-read'],
      client.operations['material.revision-save'],
      client.operations['material.thread-read'],
      client.operations['material.bind'],
      client.operations['material.unbind'],
      client.operations['material.exclude'],
      client.operations['material.restore'],
    ];
    renderMaterial(client);

    await screen.findByRole('main', { name: 'Workspace' });
    expect.soft(screen.queryAllByRole('status', { name: /loading/i }).length).toBeGreaterThan(0);
    expect
      .soft(screen.queryByText(/choose a workspace first|create your first material/i))
      .not.toBeInTheDocument();
    expect
      .soft(
        screen.queryByText(/couldn't load (?:workspace materials|this material|thread material)/i)
      )
      .not.toBeInTheDocument();
    expect
      .soft(
        screen
          .queryAllByRole('button')
          .filter((button) => MATERIAL_ACTION_NAME.test(button.textContent ?? ''))
      )
      .toHaveLength(0);
    for (const operation of materialOperations) expect.soft(operation).not.toHaveBeenCalled();

    await act(async () => {
      discovery.resolve({
        items: workspaces.map((workspace) => ({
          workspace,
          effectiveRole: 'owner' as const,
          membershipStatus: 'active' as const,
          accessCause: 'membership' as const,
          membershipRevision: 1,
          ownerUserId: 'user_local',
          registryRevision: 1,
        })),
      });
      await discovery.promise;
    });

    if (settlement === 'empty') {
      expect(await screen.findByText(/choose a workspace first/i)).toBeInTheDocument();
      expect(screen.queryByRole('alert')).not.toBeInTheDocument();
      expect(
        screen
          .queryAllByRole('button')
          .filter((button) => MATERIAL_ACTION_NAME.test(button.textContent ?? ''))
      ).toHaveLength(0);
      for (const operation of materialOperations) expect(operation).not.toHaveBeenCalled();
      return;
    }

    expect(await screen.findByRole('textbox', { name: 'Release notes' })).toHaveValue(
      REVISION_2.content
    );
    await waitFor(() => {
      expect(client.operations['material.list']).toHaveBeenCalledWith({
        workspaceId: WORKSPACE_ID,
      });
      expect(client.operations['material.read']).toHaveBeenCalledWith({
        workspaceId: WORKSPACE_ID,
        materialId: MATERIAL_ID,
      });
      expect(client.operations['material.revision-list']).toHaveBeenCalledWith({
        workspaceId: WORKSPACE_ID,
        materialId: MATERIAL_ID,
      });
      expect(client.operations['material.thread-read']).toHaveBeenCalledWith({
        workspaceId: WORKSPACE_ID,
        threadId: THREAD_ID,
      });
    });
  });
});

describe('Workspace Material Plane 1 S11', () => {
  it('registers one live route and creates a Markdown Material through Core Client', async () => {
    const user = userEvent.setup();
    const client = makeClient();
    const surface = SURFACES.find(
      (candidate) => candidate.wp === 'WP-5' && /material/i.test(candidate.title)
    );

    expect(surface).toMatchObject({ tier: 'A', nav: 'route-only', wp: 'WP-5' });
    renderMaterial(client);

    await user.click(await screen.findByRole('button', { name: /new material/i }));
    await user.type(screen.getByRole('textbox', { name: /title/i }), 'Launch brief');
    await user.click(screen.getByLabelText(/markdown/i));
    await user.click(screen.getByLabelText(/internal/i));
    await user.click(screen.getByRole('button', { name: /create material/i }));

    await waitFor(() =>
      expect(client.operations['material.create']).toHaveBeenCalledWith(
        expect.objectContaining({
          workspaceId: WORKSPACE_ID,
          title: 'Launch brief',
          kind: 'markdown',
          sensitivity: 'internal',
        })
      )
    );
    expect(client.operations['turn.start']).not.toHaveBeenCalled();
    expect(client.operations['conversation.submit']).not.toHaveBeenCalled();
    expect(client.operations['task.start']).not.toHaveBeenCalled();
  });

  it('keeps a failed Material list retryable before settling on an authoritative empty list', async () => {
    const user = userEvent.setup();
    const listWorkspaceMaterials = vi
      .fn()
      .mockRejectedValueOnce(new Error('list unavailable'))
      .mockResolvedValueOnce({ materials: [] });
    const client = makeClient({ operations: { 'material.list': listWorkspaceMaterials } });
    renderMaterial(client, null);

    expect(screen.queryByText(/create your first material/i)).not.toBeInTheDocument();
    await user.click(await screen.findByRole('button', { name: /try again/i }));

    await waitFor(() => expect(listWorkspaceMaterials).toHaveBeenCalledTimes(2));
    expect(await screen.findByText(/create your first material/i)).toBeInTheDocument();
    expect(
      (await screen.findAllByRole('button', { name: /new material/i })).length
    ).toBeGreaterThan(0);
  });

  it('preserves failed Material creation input for an explicit retry without starting work', async () => {
    const user = userEvent.setup();
    const createWorkspaceMaterial = vi
      .fn()
      .mockRejectedValueOnce(new Error('create unavailable'))
      .mockResolvedValueOnce({ materialId: 'mat_00000000-0000-72a5-8964-fa2b62341db0' });
    const client = makeClient({ operations: { 'material.create': createWorkspaceMaterial } });
    renderMaterial(client);

    await user.click(await screen.findByRole('button', { name: /new material/i }));
    await user.type(screen.getByRole('textbox', { name: /title/i }), 'Launch brief');
    await user.click(screen.getByLabelText(/plain text/i));
    await user.click(screen.getByLabelText(/restricted/i));
    await user.click(screen.getByRole('button', { name: /create material/i }));

    await screen.findByRole('button', { name: /try again/i });
    expect(screen.getByRole('textbox', { name: /title/i })).toHaveValue('Launch brief');
    expect(screen.getByLabelText(/plain text/i)).toBeChecked();
    expect(screen.getByLabelText(/restricted/i)).toBeChecked();

    await user.click(screen.getByRole('button', { name: /try again/i }));

    await waitFor(() => expect(createWorkspaceMaterial).toHaveBeenCalledTimes(2));
    expect(createWorkspaceMaterial).toHaveBeenNthCalledWith(
      1,
      expect.objectContaining({
        workspaceId: WORKSPACE_ID,
        title: 'Launch brief',
        kind: 'text',
        sensitivity: 'restricted',
      })
    );
    expect(createWorkspaceMaterial).toHaveBeenNthCalledWith(
      2,
      expect.objectContaining({
        workspaceId: WORKSPACE_ID,
        title: 'Launch brief',
        kind: 'text',
        sensitivity: 'restricted',
      })
    );
    expect(client.operations['turn.start']).not.toHaveBeenCalled();
    expect(client.operations['conversation.submit']).not.toHaveBeenCalled();
    expect(client.operations['task.start']).not.toHaveBeenCalled();
  });

  it('creates and saves the first exact revision from a null-current Material', async () => {
    const user = userEvent.setup();
    const materialWithoutRevision = { ...MATERIAL, currentRevisionId: null };
    const saveWorkspaceMaterialRevision = vi.fn().mockResolvedValue({
      materialId: MATERIAL_ID,
      revisionId: 'mrev_00000000-0000-7dfd-b321-ac6a81c1b523',
    });
    const client = makeClient({
      operations: {
        'material.list': vi.fn().mockResolvedValue({ materials: [materialWithoutRevision] }),
        'material.read': vi.fn().mockResolvedValue({ material: materialWithoutRevision }),
        'material.revision-list': vi.fn().mockResolvedValue({ revisions: [] }),
        'material.revision-save': saveWorkspaceMaterialRevision,
      },
    });
    renderMaterial(client);

    await waitFor(() => {
      const editor = screen.getByRole('textbox', { name: 'Release notes' });
      expect(editor).toHaveValue('');
      expect(editor).toBeEnabled();
    });
    await user.type(screen.getByRole('textbox', { name: 'Release notes' }), '# First draft.\n');
    await waitFor(() => expect(screen.getByRole('button', { name: /^save$/i })).toBeEnabled());
    await user.click(screen.getByRole('button', { name: /^save$/i }));

    await waitFor(() =>
      expect(saveWorkspaceMaterialRevision).toHaveBeenCalledWith(
        expect.objectContaining({
          workspaceId: WORKSPACE_ID,
          materialId: MATERIAL_ID,
          expectedRevisionId: null,
          contentDigest: 'sha256:ec1119548ae594f4eabe554616b81c5ae0050d615c0f9934679b0d6a5dc44645',
          content: '# First draft.\n',
        })
      )
    );
    expect(saveWorkspaceMaterialRevision).toHaveBeenCalledTimes(1);
  });

  it('keeps an explicit Material route independent while the catalog read reports a retryable failure', async () => {
    const listWorkspaceMaterials = vi.fn().mockRejectedValue(new Error('list unavailable'));
    const client = makeClient({ operations: { 'material.list': listWorkspaceMaterials } });
    renderMaterial(client, MATERIAL_ID);

    const editor = await screen.findByRole('textbox', { name: 'Release notes' });
    expect(editor).toHaveValue(REVISION_2.content);
    expect(listWorkspaceMaterials).toHaveBeenCalledWith({ workspaceId: WORKSPACE_ID });
    expect(client.operations['material.read']).toHaveBeenCalledWith({
      workspaceId: WORKSPACE_ID,
      materialId: MATERIAL_ID,
    });
    expect(client.operations['material.revision-read']).toHaveBeenCalledWith({
      workspaceId: WORKSPACE_ID,
      materialId: MATERIAL_ID,
      revisionId: REVISION_2.revisionId,
    });
    expect(screen.getByRole('button', { name: /try again/i })).toBeInTheDocument();
  });

  it('keeps edits local until one stable revision save with the exact expected base', async () => {
    const user = userEvent.setup();
    const client = makeClient();
    renderMaterial(client);

    const editor = await screen.findByRole('textbox', { name: 'Release notes' });
    expect(editor).toHaveValue(REVISION_2.content);
    expect(client.operations['material.revision-read']).toHaveBeenCalledWith({
      workspaceId: WORKSPACE_ID,
      materialId: MATERIAL_ID,
      revisionId: REVISION_2.revisionId,
    });
    await user.type(editor, 'Ship exactly.\n');

    expect(screen.getByText(/unsaved/i)).toBeInTheDocument();
    expect(client.operations['material.revision-save']).not.toHaveBeenCalled();
    expect(client.operations['turn.start']).not.toHaveBeenCalled();
    expect(client.operations['conversation.submit']).not.toHaveBeenCalled();
    expect(client.operations['task.start']).not.toHaveBeenCalled();

    await user.click(screen.getByRole('button', { name: 'Save' }));

    await waitFor(() =>
      expect(client.operations['material.revision-save']).toHaveBeenCalledWith(
        expect.objectContaining({
          workspaceId: WORKSPACE_ID,
          materialId: MATERIAL_ID,
          expectedRevisionId: REVISION_2.revisionId,
          contentDigest: 'sha256:9f93be420182b7f4885bc2dc66ab9eadc62e89cc39845bb5dec4e4cbe65833bd',
          content: '# Release notes\nShip exactly.\n',
        })
      )
    );
    expect(client.operations['material.revision-save']).toHaveBeenCalledOnce();
  });

  it('surfaces a typed stale-precondition conflict while preserving the unsaved draft', async () => {
    const user = userEvent.setup();
    const saveWorkspaceMaterialRevision = vi.fn().mockRejectedValue(
      new ApiCallError(409, 'Mutation rejected.', {
        code: 'conflict',
      })
    );
    const client = makeClient({
      operations: { 'material.revision-save': saveWorkspaceMaterialRevision },
    });
    renderMaterial(client);

    const editor = await screen.findByRole('textbox', { name: 'Release notes' });
    await user.type(editor, 'Keep this local draft.');
    await user.click(screen.getByRole('button', { name: 'Save' }));

    expect(
      await screen.findByText(/conflict|newer saved revision|changed since/i)
    ).toBeInTheDocument();
    expect(editor).toHaveValue('# Release notes\nKeep this local draft.');
    expect(screen.getByText(/unsaved/i)).toBeInTheDocument();
    expect(screen.getByText(REVISION_2.revisionId)).toBeInTheDocument();
    expect(screen.queryByText('mrev_00000000-0000-7d6b-9c3a-1a2dc21c80d1')).not.toBeInTheDocument();
    expect(saveWorkspaceMaterialRevision).toHaveBeenCalledWith(
      expect.objectContaining({
        workspaceId: WORKSPACE_ID,
        materialId: MATERIAL_ID,
        expectedRevisionId: REVISION_2.revisionId,
      })
    );
  });

  it('opens immutable revisions and compares their exact bytes as non-authoritative client state', async () => {
    const user = userEvent.setup();
    const client = makeClient();
    renderMaterial(client);

    await waitFor(() => {
      expect(screen.getByText(REVISION_1.revisionId)).toBeInTheDocument();
      expect(screen.getByText(REVISION_2.revisionId)).toBeInTheDocument();
    });
    expect(client.operations['material.revision-read']).toHaveBeenCalledWith({
      workspaceId: WORKSPACE_ID,
      materialId: MATERIAL_ID,
      revisionId: REVISION_2.revisionId,
    });
    await user.click(screen.getByText(REVISION_1.revisionId));

    const openedRevision = await screen.findByLabelText(new RegExp(REVISION_1.revisionId));
    expect(openedRevision.textContent).toBe(REVISION_1.content);
    expect(client.operations['material.revision-read']).toHaveBeenCalledWith({
      workspaceId: WORKSPACE_ID,
      materialId: MATERIAL_ID,
      revisionId: REVISION_1.revisionId,
    });

    await user.click(screen.getByRole('button', { name: /compare revisions/i }));
    const before = await screen.findByLabelText(new RegExp(REVISION_1.revisionId));
    const after = await screen.findByLabelText(new RegExp(REVISION_2.revisionId));
    expect(before).not.toBe(after);
    expect(before.textContent).toBe(REVISION_1.content);
    expect(after.textContent).toBe(REVISION_2.content);
    expect(screen.queryByRole('button', { name: /apply|accept/i })).not.toBeInTheDocument();
    expect(client.operations['material.create']).not.toHaveBeenCalled();
    expect(client.operations['material.revision-save']).not.toHaveBeenCalled();
  });

  it('compares the earlier immutable revision before the current revision by default', async () => {
    const user = userEvent.setup();
    const client = makeClient();
    renderMaterial(client);

    await waitFor(() => {
      expect(screen.getByText(REVISION_1.revisionId)).toBeInTheDocument();
      expect(screen.getByText(REVISION_2.revisionId)).toBeInTheDocument();
    });
    await user.click(screen.getByRole('button', { name: /compare revisions/i }));

    const panes = (await screen.findAllByRole('region')).filter((region) =>
      [REVISION_1.content, REVISION_2.content].includes(region.textContent ?? '')
    );
    expect(panes).toHaveLength(2);
    expect(panes[0]?.textContent).toBe(REVISION_1.content);
    expect(panes[1]?.textContent).toBe(REVISION_2.content);
    expect(screen.queryByRole('button', { name: /apply|accept/i })).not.toBeInTheDocument();
  });
});

describe('Workspace Material Plane 1 S12', () => {
  it('disables Material create and save controls until the initial connection probe settles', async () => {
    const user = userEvent.setup();
    let resolveProbe: ((value: unknown) => void) | undefined;
    const meta = vi.fn().mockImplementation(
      () =>
        new Promise((resolve) => {
          resolveProbe = resolve;
        })
    );
    const client = makeClient({ core: { meta } });
    renderMaterial(client);

    const editor = await screen.findByRole('textbox', { name: 'Release notes' });
    const newMaterial = await screen.findByRole('button', { name: /new material/i });
    const save = await screen.findByRole('button', { name: /^save$/i });
    expect(newMaterial).toBeDisabled();
    expect(save).toBeDisabled();
    expect(client.operations['material.create']).not.toHaveBeenCalled();
    expect(client.operations['material.revision-save']).not.toHaveBeenCalled();

    resolveProbe?.({});
    await waitFor(() => expect(newMaterial).toBeEnabled());
    expect(save).toBeDisabled();
    await user.type(editor, 'Pending connection.');
    expect(save).toBeEnabled();
  });

  it('projects Thread Material facts from the authoritative read and disables S12 writes while disconnected', async () => {
    const getThreadMaterial = vi.fn().mockResolvedValue({ material: NULL_THREAD_MATERIAL });
    const client = makeClient({
      core: { meta: vi.fn().mockRejectedValue(new Error('offline')) },
      operations: { 'material.thread-read': getThreadMaterial },
    });
    renderMaterial(client);

    const panel = await screen.findByRole('region', { name: /thread material/i });
    expect(panel).toHaveTextContent(/bound/i);
    expect(panel).toHaveTextContent(/included/i);
    expect(panel).toHaveTextContent(/current revision.*(unknown|none|not available)/i);
    expect(panel).toHaveTextContent(/queued revision.*(unknown|none|not available)/i);
    expect(panel).toHaveTextContent(/worker-seen revision.*(unknown|none|not available)/i);
    expect(panel).toHaveTextContent(/current-turn revision.*(unknown|none|not available)/i);
    expect(screen.getByRole('button', { name: /unbind/i })).toBeDisabled();
    expect(screen.getByRole('button', { name: /exclude/i })).toBeDisabled();
    expect(getThreadMaterial).toHaveBeenCalledWith({
      workspaceId: WORKSPACE_ID,
      threadId: THREAD_ID,
    });
  });

  it('refetches the authoritative Thread Material projection after a successful bind without local advancement', async () => {
    const user = userEvent.setup();
    let resolveAuthoritativeRead:
      | ((response: { material: null | typeof THREAD_MATERIAL }) => void)
      | undefined;
    const getThreadMaterial = vi
      .fn()
      .mockResolvedValueOnce({ material: null })
      .mockImplementationOnce(
        () =>
          new Promise((resolve) => {
            resolveAuthoritativeRead = resolve;
          })
      );
    let resolveBindMutation:
      | ((response: { materialId: string; threadId: string; outcome: 'bound' }) => void)
      | undefined;
    const bindThreadMaterial = vi.fn().mockImplementation(
      () =>
        new Promise((resolve) => {
          resolveBindMutation = resolve;
        })
    );
    const client = makeClient({
      operations: {
        'material.thread-read': getThreadMaterial,
        'material.bind': bindThreadMaterial,
      },
    });
    renderMaterial(client);

    await user.click(await screen.findByRole('button', { name: /^bind material$/i }));

    await waitFor(() =>
      expect(bindThreadMaterial).toHaveBeenCalledWith({
        workspaceId: WORKSPACE_ID,
        threadId: THREAD_ID,
        materialId: MATERIAL_ID,
        ...{
          expectedBindingState: 'not_bound',
        },
      })
    );
    expect(getThreadMaterial).toHaveBeenCalledOnce();
    resolveBindMutation?.({ materialId: MATERIAL_ID, threadId: THREAD_ID, outcome: 'bound' });
    await waitFor(() => expect(getThreadMaterial).toHaveBeenCalledTimes(2));
    expect(screen.getByRole('button', { name: /^bind material$/i })).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /unbind/i })).not.toBeInTheDocument();
    resolveAuthoritativeRead?.({ material: THREAD_MATERIAL });
    await waitFor(() =>
      expect(screen.getByRole('button', { name: /unbind/i })).toBeInTheDocument()
    );
    expect(getThreadMaterial.mock.invocationCallOrder[1]).toBeGreaterThan(
      bindThreadMaterial.mock.invocationCallOrder[0]
    );
  });

  it('re-reads the Thread Material projection after a bound save and displays the advanced queue', async () => {
    const user = userEvent.setup();
    const advancedQueuedRevisionId = 'mrev_00000000-0000-7d6b-9c3a-1a2dc21c80d1';
    const getThreadMaterial = vi
      .fn()
      .mockResolvedValueOnce({ material: THREAD_MATERIAL })
      .mockResolvedValueOnce({
        material: {
          ...THREAD_MATERIAL,
          latestQueuedRevisionId: advancedQueuedRevisionId,
        },
      });
    const saveWorkspaceMaterialRevision = vi.fn().mockResolvedValue({
      materialId: MATERIAL_ID,
      revisionId: advancedQueuedRevisionId,
    });
    const client = makeClient({
      operations: {
        'material.thread-read': getThreadMaterial,
        'material.revision-save': saveWorkspaceMaterialRevision,
      },
    });
    renderMaterial(client);

    const editor = await screen.findByRole('textbox', { name: 'Release notes' });
    await user.type(editor, 'Queue this revision.');
    await user.click(screen.getByRole('button', { name: /^save$/i }));

    await waitFor(() => expect(saveWorkspaceMaterialRevision).toHaveBeenCalledOnce());
    await waitFor(() => expect(getThreadMaterial).toHaveBeenCalledTimes(2));
    const panel = await screen.findByRole('region', { name: /thread material/i });
    expect(panel).toHaveTextContent(advancedQueuedRevisionId);
    expect(panel).not.toHaveTextContent(THREAD_QUEUED_REVISION_ID);
    expect(getThreadMaterial.mock.invocationCallOrder[1]).toBeGreaterThan(
      saveWorkspaceMaterialRevision.mock.invocationCallOrder[0]
    );
  });

  it('sends every S12 expected-state precondition and exact identifier while re-reading restore queue state', async () => {
    const user = userEvent.setup();
    const getThreadMaterial = vi
      .fn()
      .mockResolvedValueOnce({ material: null })
      .mockResolvedValueOnce({ material: THREAD_MATERIAL })
      .mockResolvedValueOnce({ material: { ...THREAD_MATERIAL, inclusionState: 'excluded' } })
      .mockResolvedValueOnce({
        material: { ...THREAD_MATERIAL, latestQueuedRevisionId: THREAD_RESTORED_QUEUE_ID },
      })
      .mockResolvedValueOnce({ material: null });
    const bindThreadMaterial = vi.fn().mockResolvedValue({
      materialId: MATERIAL_ID,
      threadId: THREAD_ID,
      outcome: 'bound',
    });
    const excludeThreadMaterial = vi.fn().mockResolvedValue({
      materialId: MATERIAL_ID,
      threadId: THREAD_ID,
      outcome: 'excluded',
    });
    const restoreThreadMaterial = vi.fn().mockResolvedValue({
      materialId: MATERIAL_ID,
      threadId: THREAD_ID,
      outcome: 'included',
    });
    const unbindThreadMaterial = vi.fn().mockResolvedValue({
      materialId: MATERIAL_ID,
      threadId: THREAD_ID,
      outcome: 'unbound',
    });
    const client = makeClient({
      operations: {
        'material.thread-read': getThreadMaterial,
        'material.bind': bindThreadMaterial,
        'material.exclude': excludeThreadMaterial,
        'material.restore': restoreThreadMaterial,
        'material.unbind': unbindThreadMaterial,
      },
    });
    renderMaterial(client);

    await user.click(await screen.findByRole('button', { name: /^bind material$/i }));
    await waitFor(() => expect(getThreadMaterial).toHaveBeenCalledTimes(2));
    expect(bindThreadMaterial).toHaveBeenCalledWith({
      workspaceId: WORKSPACE_ID,
      threadId: THREAD_ID,
      materialId: MATERIAL_ID,
      ...{
        expectedBindingState: 'not_bound',
      },
    });
    let panel = await screen.findByRole('region', { name: /thread material/i });
    expect(panel).toHaveTextContent(new RegExp(`current revision.*${REVISION_2.revisionId}`, 'i'));
    expect(panel).toHaveTextContent(
      new RegExp(`queued revision.*${THREAD_QUEUED_REVISION_ID}`, 'i')
    );
    expect(panel).toHaveTextContent(
      new RegExp(`worker-seen revision.*${THREAD_MATERIAL.lastWorkerSeenRevisionId}`, 'i')
    );
    expect(panel).toHaveTextContent(
      new RegExp(`current-turn revision.*${THREAD_MATERIAL.currentTurnRevisionId}`, 'i')
    );
    expect(getThreadMaterial.mock.invocationCallOrder[1]).toBeGreaterThan(
      bindThreadMaterial.mock.invocationCallOrder[0]
    );

    await user.click(await screen.findByRole('button', { name: /exclude/i }));
    await waitFor(() => expect(getThreadMaterial).toHaveBeenCalledTimes(3));
    expect(excludeThreadMaterial).toHaveBeenCalledWith({
      workspaceId: WORKSPACE_ID,
      threadId: THREAD_ID,
      materialId: MATERIAL_ID,
      ...{
        expectedBindingState: 'bound',
        expectedInclusionState: 'included',
        expectedQueuedRevisionId: THREAD_QUEUED_REVISION_ID,
      },
    });
    expect(getThreadMaterial.mock.invocationCallOrder[2]).toBeGreaterThan(
      excludeThreadMaterial.mock.invocationCallOrder[0]
    );

    await user.click(await screen.findByRole('button', { name: /restore/i }));
    await waitFor(() => expect(getThreadMaterial).toHaveBeenCalledTimes(4));
    expect(restoreThreadMaterial).toHaveBeenCalledWith({
      workspaceId: WORKSPACE_ID,
      threadId: THREAD_ID,
      materialId: MATERIAL_ID,
      ...{
        expectedBindingState: 'bound',
        expectedInclusionState: 'excluded',
      },
    });
    expect(getThreadMaterial.mock.invocationCallOrder[3]).toBeGreaterThan(
      restoreThreadMaterial.mock.invocationCallOrder[0]
    );
    panel = await screen.findByRole('region', { name: /thread material/i });
    expect(panel).toHaveTextContent(THREAD_RESTORED_QUEUE_ID);
    expect(panel).not.toHaveTextContent(THREAD_QUEUED_REVISION_ID);

    await user.click(await screen.findByRole('button', { name: /unbind/i }));
    await waitFor(() => expect(getThreadMaterial).toHaveBeenCalledTimes(5));
    expect(unbindThreadMaterial).toHaveBeenCalledWith({
      workspaceId: WORKSPACE_ID,
      threadId: THREAD_ID,
      materialId: MATERIAL_ID,
      ...{
        expectedBindingState: 'bound',
      },
    });
    expect(getThreadMaterial.mock.invocationCallOrder[4]).toBeGreaterThan(
      unbindThreadMaterial.mock.invocationCallOrder[0]
    );
  });

  it('preserves the last authoritative projection on a typed conflict and offers retry without a second mutation', async () => {
    const user = userEvent.setup();
    const getThreadMaterial = vi.fn().mockResolvedValue({ material: THREAD_MATERIAL });
    const excludeThreadMaterial = vi
      .fn()
      .mockRejectedValue(new ApiCallError(409, 'Mutation rejected.', { code: 'conflict' }));
    const client = makeClient({
      operations: {
        'material.thread-read': getThreadMaterial,
        'material.exclude': excludeThreadMaterial,
      },
    });
    renderMaterial(client);

    const panel = await screen.findByRole('region', { name: /thread material/i });
    await user.click(screen.getByRole('button', { name: /exclude/i }));

    const conflictAlert = await screen.findByRole('alert');
    expect(conflictAlert).toHaveTextContent(/conflict|changed since/i);
    expect(conflictAlert).toHaveTextContent(/try again/i);
    expect(panel).toHaveTextContent(/included/i);
    expect(panel).toHaveTextContent(THREAD_QUEUED_REVISION_ID);
    expect(screen.getByRole('button', { name: 'Try again' })).toBeInTheDocument();
    expect(excludeThreadMaterial).toHaveBeenCalledOnce();
    expect(getThreadMaterial).toHaveBeenCalledOnce();
  });
});

/** Small canonical proposal fixture; expected SHA-256 literals were independently precomputed from its exact UTF-8 bytes. */
function proposalFixture(
  text = '\ufeff# Proposed release notes\n界 ships.\n',
  version = 1,
  contentDigest = 'sha256:7016ac7cb4a4f6358bed70b70eb9b64ad285a8d036402de53562c347db2025ad'
) {
  const bytes = new TextEncoder().encode(text);
  const artifact: GetArtifactResponse = {
    id: 'artifact_proposal',
    workspaceId: WORKSPACE_ID,
    threadId: THREAD_ID,
    turnId: 'turn_proposal',
    kind: 'report',
    title: 'Proposal',
    status: 'ready',
    summary: null,
    version,
    content: { format: 'file', mediaType: 'text/markdown', byteLength: bytes.length },
    contentDigest,
    lastMutationRequestId: 'req_proposal',
    origin: {
      kind: 'turn-output',
      threadId: THREAD_ID,
      turnId: 'turn_proposal',
      requestId: 'req_proposal',
    },
    createdAt: TIMESTAMP,
    updatedAt: TIMESTAMP,
  };
  const review: ArtifactReview = {
    workspaceId: WORKSPACE_ID,
    reviewId: 'review_proposal',
    artifactId: artifact.id,
    artifactVersion: version,
    contentDigest,
    sourceThreadId: THREAD_ID,
    sourceTurnId: 'turn_proposal',
    sourceAgentId: 'agent_proposal',
    materialProposal: {
      materialId: MATERIAL_ID,
      baseRevisionId: REVISION_2.revisionId,
      baseContentDigest: REVISION_2.contentDigest,
    },
    decision: null,
    decisionActorId: null,
    feedback: null,
    decidedAt: null,
    followUpTurnId: null,
    appliedMaterialRevisionId: null,
    createdAt: TIMESTAMP,
  };
  const cancel = vi.fn();
  const downloaded = () => ({
    body: new ReadableStream<Uint8Array>({
      start(controller) {
        // Split a multibyte BOM so the fixture observes streaming decoding.
        controller.enqueue(bytes.subarray(0, 1));
        controller.enqueue(bytes.subarray(1));
        controller.close();
      },
      cancel,
    }),
    byteLength: bytes.length,
    mediaType: 'text/markdown',
    contentDigest,
  });
  return { artifact, review, bytes, text, downloaded, cancel };
}

/** Keeps one QueryClient across rerenders to expose stale-query display. */
function renderProposal(
  download: CoreClient['artifactFiles']['download'],
  initial: ReturnType<typeof proposalFixture>
) {
  const client: CoreClient = {
    ...makeClient(),
    artifactFiles: { download, import: vi.fn(), browserDownloadUrl: vi.fn() },
  };
  const queries = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  const view = (fixture: ReturnType<typeof proposalFixture>) => (
    <QueryClientProvider client={queries}>
      <CoreClientProvider client={client}>
        <ProposalReview
          workspaceId={WORKSPACE_ID}
          artifact={fixture.artifact}
          review={fixture.review}
          conflict={false}
          onRefresh={vi.fn()}
        />
      </CoreClientProvider>
    </QueryClientProvider>
  );
  const result = render(view(initial));
  return {
    rerender: (fixture: ReturnType<typeof proposalFixture>) => result.rerender(view(fixture)),
  };
}

describe('exact Material proposal text', () => {
  it('downloads the exact file-backed proposal and preserves inline text without another download', async () => {
    const fixture = proposalFixture();
    const pending = createDeferred<ReturnType<typeof fixture.downloaded>>();
    const download = vi.fn().mockReturnValue(pending.promise);
    const view = renderProposal(download, fixture);
    expect(await screen.findByText('Loading reviewed proposal text.')).toBeInTheDocument();
    expect(download).toHaveBeenCalledExactlyOnceWith({
      workspaceId: WORKSPACE_ID,
      artifactId: fixture.artifact.id,
      artifactVersion: 1,
    });
    pending.resolve(fixture.downloaded());
    await waitFor(() =>
      expect(
        screen.getByRole('region', { name: 'Reviewed artifact proposal' }).querySelector('pre')
          ?.textContent
      ).toBe(fixture.text)
    );
    const inline = proposalFixture(
      'Inline proposal',
      2,
      'sha256:bb2d8b3e7f5c5bdc7f13cb38f8be6cf1876c621878af2e0baed801e9d2bded5b'
    );
    inline.artifact.content = { format: 'text', body: inline.text };
    view.rerender(inline);
    expect(screen.getByRole('region', { name: 'Reviewed artifact proposal' })).toHaveTextContent(
      'Inline proposal'
    );
    expect(download).toHaveBeenCalledOnce();
  });

  it('hides the previous version while loading and refuses changed original bytes', async () => {
    const first = proposalFixture(
      'Original version',
      1,
      'sha256:46dd9599c8810a12958ab82213e13650ebe51c805b3fd459e2b143ae03745a25'
    );
    const next = proposalFixture(
      'Changed version!',
      2,
      'sha256:5a7910d2e791c67a96a395727195787e828ec3ea3f8648e22eecb5123aea9116'
    );
    const pending = createDeferred<ReturnType<typeof next.downloaded>>();
    const download = vi
      .fn()
      .mockResolvedValueOnce(first.downloaded())
      .mockReturnValueOnce(pending.promise);
    const view = renderProposal(download, first);
    await screen.findByText(first.text);
    view.rerender(next);
    await screen.findByText('Loading reviewed proposal text.');
    expect(screen.queryByText(first.text)).not.toBeInTheDocument();
    const corrupt = first.downloaded();
    pending.resolve({
      ...corrupt,
      byteLength: next.bytes.length,
      contentDigest: next.artifact.contentDigest,
    });
    expect(await screen.findByRole('alert')).toHaveTextContent(
      "Couldn't load the reviewed proposal text."
    );
    expect(screen.queryByText(first.text)).not.toBeInTheDocument();
    expect(screen.queryByText(next.text)).not.toBeInTheDocument();
    expect(download).toHaveBeenLastCalledWith({
      workspaceId: WORKSPACE_ID,
      artifactId: next.artifact.id,
      artifactVersion: 2,
    });
  });

  it('refuses oversized metadata, invalid UTF-8 and an oversized actual stream before display', async () => {
    const fixture = proposalFixture();
    fixture.artifact.content = {
      format: 'file',
      mediaType: 'text/markdown',
      byteLength: 16_777_217,
    };
    const download = vi.fn();
    const view = renderProposal(download, fixture);
    expect(await screen.findByRole('alert')).toHaveTextContent(
      "Couldn't load the reviewed proposal text."
    );
    expect(download).not.toHaveBeenCalled();
    const invalid = proposalFixture(
      'a',
      2,
      'sha256:ca978112ca1bbdcafac231b39a23dc4da786eff8147c4e72b9807785afee48bb'
    );
    const bytes = new Uint8Array([255]);
    invalid.artifact.contentDigest =
      'sha256:a8100ae6aa1940d0b663bb31cd466142ebbdbd5187131b92d93818987832eb89';
    invalid.review.contentDigest = invalid.artifact.contentDigest;
    download.mockResolvedValue({
      ...invalid.downloaded(),
      contentDigest: invalid.artifact.contentDigest,
      body: new ReadableStream({
        start(controller) {
          controller.enqueue(bytes);
          controller.close();
        },
      }),
    });
    view.rerender(invalid);
    await waitFor(() => expect(download).toHaveBeenCalledOnce());
    expect(await screen.findByRole('alert')).toHaveTextContent(
      "Couldn't load the reviewed proposal text."
    );
    expect(screen.queryByText('\ufffd')).not.toBeInTheDocument();
    const overflow = proposalFixture(
      'a',
      3,
      'sha256:ca978112ca1bbdcafac231b39a23dc4da786eff8147c4e72b9807785afee48bb'
    );
    const cancelled = vi.fn();
    download.mockResolvedValue({
      ...overflow.downloaded(),
      body: new ReadableStream({
        start(controller) {
          controller.enqueue(new Uint8Array([97, 97]));
        },
        cancel: cancelled,
      }),
    });
    view.rerender(overflow);
    await waitFor(() => expect(cancelled).toHaveBeenCalledOnce());
    expect(await screen.findByRole('alert')).toHaveTextContent(
      "Couldn't load the reviewed proposal text."
    );
  });
});
