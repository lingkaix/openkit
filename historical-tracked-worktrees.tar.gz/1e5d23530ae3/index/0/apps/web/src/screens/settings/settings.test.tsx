import { ApiCallError, type CoreClient } from '@openkit/core-client';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { act, render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import type { ReactNode } from 'react';
import { MemoryRouter } from 'react-router-dom';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { CoreClientProvider } from '../../app/core-client';
import { isSurfaceLive } from '../../app/flags';
import { AppRoutes } from '../../app/routes';
import { surfaceById } from '../../app/surfaces';
import { useWorkspaceStore } from '../workspace-store';
import { overlayConnectedAppQuota, projectConnectedApps } from './data';
import { projectSafeValue, redactSecretShapedText, stripSecretFields } from './secret-safe';

const TIMESTAMP = '2026-07-21T12:00:00.000Z';
const POISON_SECRET = 'sk-secret-should-never-render';

const WORKSPACE = {
  id: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
  name: 'Market research',
  kind: 'general',
  status: 'active',
  counts: { threadCount: 2, artifactCount: 0, knowledgeEntryCount: 3 },
  createdAt: TIMESTAMP,
  updatedAt: TIMESTAMP,
};

const WORKSPACE_RESOURCES = {
  knowledge: [],
  skills: [{ id: 'skill_search', name: 'Web search', enabled: true }],
  agents: [
    {
      id: 'agent_coder',
      name: 'Coder',
      kind: 'coder',
      status: 'enabled',
      modelId: null,
      skillIds: [],
      profiles: [],
      defaultProfileId: null,
      capabilities: [],
      sandboxSummary: null,
      health: { status: 'ready', message: null, checkedAt: TIMESTAMP },
    },
  ],
  models: [{ id: 'model_fast', name: 'Fast model', enabled: true, isDefault: true }],
};

const META = {
  protocolVersion: '0.4.0',
  capabilities: ['core.questions', 'core.artifacts'],
  eventFamilies: [],
};

const PROVIDERS = {
  providers: [
    {
      subscriptionProviderId: 'openai-codex' as const,
      displayName: 'OpenAI Codex' as const,
      loginModes: ['device_code'] as ['device_code'],
      quotaCapability: 'available' as const,
    },
    {
      subscriptionProviderId: 'xai' as const,
      displayName: 'xAI' as const,
      loginModes: ['device_code'] as ['device_code'],
      quotaCapability: 'available' as const,
    },
  ] as const,
};

const CODEX_ACCOUNT = {
  subscriptionProviderId: 'openai-codex' as const,
  accountSlotId: 'primary',
  displayName: 'Codex primary',
  boundProviderIds: ['provider_codex'],
  status: 'logged_in' as const,
  accountLabel: 'Codex team',
  planLabel: 'Plus',
  createdAt: TIMESTAMP,
  updatedAt: TIMESTAMP,
};

const XAI_ACCOUNT = {
  subscriptionProviderId: 'xai' as const,
  accountSlotId: 'primary',
  displayName: 'xAI primary',
  boundProviderIds: ['provider_xai'],
  status: 'logged_in' as const,
  accountLabel: 'Grok team',
  createdAt: TIMESTAMP,
  updatedAt: TIMESTAMP,
};

const LIFECYCLE_ACCOUNTS = [
  {
    ...CODEX_ACCOUNT,
    accountSlotId: 'error',
    displayName: 'Error account',
    status: 'error' as const,
    message: 'A new login is required.',
  },
  {
    ...CODEX_ACCOUNT,
    accountSlotId: 'logged-out',
    displayName: 'Logged out account',
    status: 'logged_out' as const,
  },
  {
    ...CODEX_ACCOUNT,
    accountSlotId: 'pending',
    displayName: 'Pending account',
    status: 'pending' as const,
    interaction: {
      mode: 'device_code' as const,
      interactionId: 'interaction-pending',
      verificationUrl: 'https://example.com/device',
      userCode: 'ABCD-EFGH',
    },
  },
  CODEX_ACCOUNT,
  {
    ...CODEX_ACCOUNT,
    accountSlotId: 'unavailable',
    displayName: 'Unavailable account',
    status: 'unavailable' as const,
    message: 'Provider temporarily unavailable.',
  },
];

const CODEX_QUOTA = {
  subscriptionProviderId: 'openai-codex' as const,
  accountSlotId: 'primary',
  availability: 'available' as const,
  observedAt: TIMESTAMP,
  planType: 'plus',
  windows: [
    { id: 'primary', usedPercent: 40.4, remainingPercent: 59.6, resetsAt: TIMESTAMP },
    { id: 'secondary', usedPercent: 99.6, remainingPercent: 0.4 },
  ],
};

const XAI_QUOTA = {
  subscriptionProviderId: 'xai' as const,
  accountSlotId: 'primary',
  availability: 'available' as const,
  observedAt: TIMESTAMP,
  windows: [{ id: 'included', usedPercent: 12.5, remainingPercent: 87.5, resetsAt: TIMESTAMP }],
};

const DIAGNOSTICS = {
  service: 'nanocore',
  boot: {
    bootId: 'boot_1',
    acceptingProductWork: true,
    overall: 'ready',
    subsystems: {
      config: { state: 'ready', reasons: [] },
      storage: { state: 'ready', reasons: [] },
      policy: { state: 'ready', reasons: [] },
      vault: { state: 'ready', reasons: [] },
      scheduler: { state: 'ready', reasons: [] },
      llmGateway: { state: 'ready', reasons: [] },
      knowledgeIndex: { state: 'ready', reasons: [] },
    },
  },
  process: {
    observedAt: TIMESTAMP,
    nodeVersion: 'v24.0.0',
    uptimeSeconds: 1.5,
    memory: {
      rssBytes: 1,
      heapUsedBytes: 1,
      heapTotalBytes: 1,
    },
    telemetry: {
      enabled: false,
      exportConfigured: false,
    },
  },
  gateway: {
    status: 'ok',
    endpoints: ['/v1/chat/completions'],
    defaultModelId: 'default',
    models: [{ id: 'default', displayName: 'Default', capabilities: ['chat'] }],
  },
  providers: {
    diagnostics: [
      {
        code: 'ready',
        message: 'Provider is ready.',
        profileId: 'provider_demo',
        source: 'registry',
        status: 'ready',
      },
    ],
    registry: [
      {
        id: 'provider_demo',
        displayName: 'Demo provider',
        kind: 'custom',
        gatewayCapabilities: { chatCompletions: 'native', responses: 'unsupported' },
        models: ['gpt-demo', 'gpt-strong'],
        defaultModel: 'gpt-demo',
        readiness: { status: 'ready', message: null, checkedAt: TIMESTAMP },
      },
    ],
  },
  capabilities: META.capabilities,
  runtimeConfig: {
    currentVersion: 3,
    loadedAt: TIMESTAMP,
    lastReload: null,
    lastFailedReload: null,
    pendingRestart: [],
    staleSessions: [],
  },
};

const DEPLOYMENT_ADMIN_VAULT_STATUS = {
  backendKind: 'deployment-admin-backend-should-never-render',
  state: 'unavailable',
  diagnostic: `deployment-admin-diagnostic-should-never-render ${POISON_SECRET}`,
  token: 'status-field-poison-should-never-render',
};

const VAULT_REFERENCES = {
  workspaceId: WORKSPACE.id,
  apiKey: 'reference-field-poison-should-never-render',
  items: [
    {
      backendKind: 'encrypted-file',
      currentVersion: 2,
      ownerScope: 'workspace',
      referenceId: 'vault_00000000-0000-7fce-81f5-bbcd6886eec4',
      secretKind: `repository-credential ${POISON_SECRET}`,
      status: 'active',
      workspaceId: WORKSPACE.id,
      accessToken: 'reference-row-poison-should-never-render',
    },
    {
      backendKind: 'encrypted-file',
      currentVersion: 1,
      ownerScope: 'workspace',
      referenceId: 'vault_00000000-0000-79ba-85de-cbbc8f50e6fa',
      secretKind: 'repository-credential',
      status: 'revoked',
      workspaceId: WORKSPACE.id,
    },
    {
      backendKind: 'encrypted-file',
      currentVersion: 0,
      ownerScope: 'workspace',
      referenceId: 'vault_00000000-0000-771c-a997-47522da0dafe',
      secretKind: 'provider-credential',
      status: 'unbound',
      workspaceId: WORKSPACE.id,
    },
  ],
};

const VAULT_GRANTS = {
  workspaceId: WORKSPACE.id,
  password: 'grant-field-poison-should-never-render',
  items: [
    {
      grantId: 'grant_00000000-0000-7904-88dd-6de9f2d54a4e',
      vaultReferenceId: 'vault_00000000-0000-7fce-81f5-bbcd6886eec4',
      ownerScope: 'workspace',
      workspaceId: WORKSPACE.id,
      userId: null,
      subjectSummary: `Release worker ${POISON_SECRET}`,
      targetAgentId: null,
      targetAgentSessionId: null,
      targetCapabilityId: null,
      allowedInjectionPaths: ['gateway-only'],
      lifetime: 'turn',
      policyDecisionId: null,
      approvalId: null,
      status: 'active',
      createdAt: TIMESTAMP,
      expiresAt: null,
      clientSecret: 'grant-row-poison-should-never-render',
    },
    {
      grantId: 'grant_00000000-0000-7c55-9dd6-1f23541f7e01',
      vaultReferenceId: 'vault_00000000-0000-79ba-85de-cbbc8f50e6fa',
      ownerScope: 'workspace',
      workspaceId: WORKSPACE.id,
      userId: null,
      subjectSummary: 'Archive worker',
      targetAgentId: null,
      targetAgentSessionId: null,
      targetCapabilityId: null,
      allowedInjectionPaths: ['gateway-only'],
      lifetime: 'turn',
      policyDecisionId: null,
      approvalId: null,
      status: 'revoked',
      createdAt: TIMESTAMP,
      expiresAt: null,
    },
    {
      grantId: 'grant_00000000-0000-7c68-9bfa-8e5aaf9abfe9',
      vaultReferenceId: 'vault_00000000-0000-771c-a997-47522da0dafe',
      ownerScope: 'workspace',
      workspaceId: WORKSPACE.id,
      userId: null,
      subjectSummary: 'History worker',
      targetAgentId: null,
      targetAgentSessionId: null,
      targetCapabilityId: null,
      allowedInjectionPaths: ['gateway-only'],
      lifetime: 'turn',
      policyDecisionId: null,
      approvalId: null,
      status: 'expired',
      createdAt: TIMESTAMP,
      expiresAt: TIMESTAMP,
    },
  ],
};

const VAULT_USE_RECORDS = {
  workspaceId: WORKSPACE.id,
  secret: 'use-field-poison-should-never-render',
  vaultUseRecords: [
    {
      useId: 'vu_00000000-0000-7c5c-b6b6-c91fe7477020',
      ownerScope: 'workspace',
      workspaceId: WORKSPACE.id,
      vaultReferenceId: 'vault_00000000-0000-7fce-81f5-bbcd6886eec4',
      materialVersion: 2,
      backendKind: 'encrypted-file',
      resolvingPath: 'grant',
      grantId: 'grant_00000000-0000-7904-88dd-6de9f2d54a4e',
      planId: null,
      receiptId: null,
      agentSessionId: null,
      capabilityCallId: null,
      outcome: 'succeeded',
      failureCode: null,
      auditEventId: null,
      usedAt: TIMESTAMP,
      authorization: 'use-row-poison-should-never-render',
    },
    {
      useId: 'vu_00000000-0000-7af9-a8a7-9251d3e8c990',
      ownerScope: 'workspace',
      workspaceId: WORKSPACE.id,
      vaultReferenceId: 'vault_00000000-0000-7a31-b0e1-45f0875d4f6f',
      materialVersion: null,
      backendKind: 'encrypted-file',
      resolvingPath: 'grant',
      grantId: null,
      planId: null,
      receiptId: null,
      agentSessionId: null,
      capabilityCallId: null,
      outcome: 'denied',
      failureCode: 'policy',
      auditEventId: null,
      usedAt: TIMESTAMP,
    },
    {
      useId: 'vu_00000000-0000-7d04-bf1c-d040cf5ab373',
      ownerScope: 'workspace',
      workspaceId: WORKSPACE.id,
      vaultReferenceId: 'vault_00000000-0000-718b-bed8-d5cdaac28798',
      materialVersion: null,
      backendKind: 'encrypted-file',
      resolvingPath: 'provider',
      grantId: null,
      planId: null,
      receiptId: null,
      agentSessionId: null,
      capabilityCallId: null,
      outcome: 'failed',
      failureCode: 'transport',
      auditEventId: null,
      usedAt: TIMESTAMP,
    },
  ],
};

const VAULT_INJECTION_PLANS = {
  workspaceId: WORKSPACE.id,
  token: 'plan-field-poison-should-never-render',
  items: [
    {
      planId: 'plan_release_worker',
      grantId: 'grant_00000000-0000-7904-88dd-6de9f2d54a4e',
      packageSnapshotId: 'aepsnap_1',
      capabilityId: null,
      injectionVisibility: 'gateway-only',
      targetPath: null,
      targetEnvVarName: null,
      expirationBehavior: `Expires with turn grant ${POISON_SECRET}`,
      revocationBehavior: 'Detach provider.',
      redactionRule: 'Do not expose token.',
      backendCapabilityRequirement: 'OpenShell provider attachment.',
      status: 'active',
      createdAt: TIMESTAMP,
      clientSecret: 'plan-row-poison-should-never-render',
    },
  ],
};

const VAULT_INJECTION_RECEIPTS = {
  workspaceId: WORKSPACE.id,
  password: 'receipt-field-poison-should-never-render',
  items: [
    {
      receiptId: 'receipt_release_worker',
      planId: 'plan_release_worker',
      grantId: 'grant_00000000-0000-7904-88dd-6de9f2d54a4e',
      agentSessionId: 'as_00000000-0000-7603-8225-d488b91d9938',
      capabilityCallId: null,
      backendSummary: `OpenShell attach ${POISON_SECRET}`,
      injectedAt: TIMESTAMP,
      expiresAt: null,
      revocationStatus: 'active',
      auditEventId: null,
      accessToken: 'receipt-row-poison-should-never-render',
    },
    {
      receiptId: 'receipt_stale_worker',
      planId: 'plan_release_worker',
      grantId: 'grant_00000000-0000-7904-88dd-6de9f2d54a4e',
      agentSessionId: 'as_00000000-0000-7603-8225-d488b91d9938',
      capabilityCallId: null,
      backendSummary: 'OpenShell attach remains reachable after revoke.',
      injectedAt: TIMESTAMP,
      expiresAt: null,
      revocationStatus: 'stale-session',
      auditEventId: null,
    },
  ],
};

const VAULT_FIELD_POISONS = [
  'status-field-poison-should-never-render',
  'reference-field-poison-should-never-render',
  'reference-row-poison-should-never-render',
  'grant-field-poison-should-never-render',
  'grant-row-poison-should-never-render',
  'use-field-poison-should-never-render',
  'use-row-poison-should-never-render',
  'plan-field-poison-should-never-render',
  'plan-row-poison-should-never-render',
  'receipt-field-poison-should-never-render',
  'receipt-row-poison-should-never-render',
] as const;

const CAPABILITY_USAGE = {
  workspaceId: WORKSPACE.id,
  password: 'usage-response-poison-should-never-render',
  capabilityCalls: [
    {
      id: 'cap_00000000-0000-7d4f-884e-ab4fdf8dc968',
      workspaceId: WORKSPACE.id,
      threadId: 'th_00000000-0000-7c5c-9c79-5b0771f81e38',
      turnId: 'tu_00000000-0000-7b5c-9add-c4bfc5a04575',
      itemId: null,
      agentId: 'agent_1',
      agentSessionId: 'as_00000000-0000-7fee-81f4-cfcfc003f25f',
      packageSnapshotId: null,
      runtimeOriginRef: null,
      runtimeCacheLineageRef: null,
      sourceIds: [],
      requestId: null,
      capabilityId: 'llm.chat_completions',
      family: 'llm',
      operation: 'chat_completions',
      providerRef: 'provider_openai',
      serviceRef: 'llm-gateway',
      redactionClass: 'metadata-only',
      status: 'succeeded',
      summary: `Model request completed with ${POISON_SECRET}.`,
      errorCode: null,
      startedAt: TIMESTAMP,
      completedAt: TIMESTAMP,
      accessToken: 'capability-row-poison-should-never-render',
    },
  ],
  usageRecords: [
    {
      id: 'use_00000000-0000-7bad-8061-11b8ce86e984',
      workspaceId: WORKSPACE.id,
      responsibleUserId: 'usr_00000000-0000-7e68-8ab1-8dcac1be1b5b',
      threadId: 'th_00000000-0000-7c5c-9c79-5b0771f81e38',
      turnId: 'tu_00000000-0000-7b5c-9add-c4bfc5a04575',
      itemId: null,
      capabilityCallId: 'cap_00000000-0000-7d4f-884e-ab4fdf8dc968',
      requestId: null,
      agentId: 'agent_1',
      agentSessionId: 'as_00000000-0000-7fee-81f4-cfcfc003f25f',
      sourceIds: [],
      category: 'llm',
      unit: 'tokens',
      quantity: 12,
      modelId: 'gpt-5',
      providerRef: 'provider_openai',
      source: 'gateway-reported:input',
      recordedAt: TIMESTAMP,
      apiKey: 'usage-row-poison-should-never-render',
    },
  ],
};

const WORKSPACE_AUDIT_EVENTS = {
  workspaceId: WORKSPACE.id,
  token: 'audit-response-poison-should-never-render',
  auditEvents: [
    {
      id: 'aud_00000000-0000-70e2-abff-6e1084ebf069',
      workspaceId: WORKSPACE.id,
      protocolVersion: '0.6.0',
      threadId: 'th_00000000-0000-7c5c-9c79-5b0771f81e38',
      turnId: 'tu_00000000-0000-7b5c-9add-c4bfc5a04575',
      itemId: null,
      capabilityCallId: 'cap_00000000-0000-7d4f-884e-ab4fdf8dc968',
      permissionDecisionId: null,
      vaultGrantId: null,
      requestId: null,
      actor: null,
      subject: null,
      agentId: 'agent_1',
      agentSessionId: 'as_00000000-0000-7fee-81f4-cfcfc003f25f',
      category: 'capability',
      action: 'llm.chat_completions',
      resource: 'model:gpt-5',
      resourceRevision: null,
      outcome: 'succeeded',
      severity: 'info',
      summary: 'Model request completed.',
      errorCode: null,
      createdAt: TIMESTAMP,
      occurredAt: TIMESTAMP,
      authorization: 'audit-row-poison-should-never-render',
    },
  ],
};

const WORKSPACE_PERMISSION_DECISIONS = {
  workspaceId: WORKSPACE.id,
  secret: 'decision-response-poison-should-never-render',
  permissionDecisions: [
    {
      decisionId: 'decision_1',
      ownerScope: 'workspace',
      workspaceId: WORKSPACE.id,
      policyEngineVersion: 'policy:v1',
      policySnapshotId: 'workspace-policy',
      subjectSummary: { kind: 'agent', id: 'agent_1' },
      action: 'llm.gateway.use',
      resourceSummary: { kind: 'model', id: 'gpt-5' },
      contextSummary: { turnId: 'tu_00000000-0000-7b5c-9add-c4bfc5a04575' },
      result: 'allow',
      reasonCode: 'workspace_policy_allowed',
      enforcementPoint: 'llm.gateway.policy',
      requiredApprovalKind: null,
      approvalId: null,
      auditEventId: 'aud_00000000-0000-70e2-abff-6e1084ebf069',
      createdAt: TIMESTAMP,
      cookie: 'decision-row-poison-should-never-render',
    },
  ],
};

const SERVER_AUDIT_EVENTS = {
  auditEvents: [
    {
      id: 'aud_00000000-0000-76f6-9eb1-b44f53e46f96',
      workspaceId: null,
      action: 'server.config.update',
      outcome: 'succeeded',
      severity: 'info',
      summary: `deployment-admin-audit-should-never-render ${POISON_SECRET}`,
    },
  ],
};

const USAGE_FIELD_POISONS = [
  'usage-response-poison-should-never-render',
  'capability-row-poison-should-never-render',
  'usage-row-poison-should-never-render',
  'audit-response-poison-should-never-render',
  'audit-row-poison-should-never-render',
  'decision-response-poison-should-never-render',
  'decision-row-poison-should-never-render',
  'deployment-admin-audit-should-never-render',
] as const;

const USAGE_NON_DISPLAY_FIELDS = [
  'th_00000000-0000-7c5c-9c79-5b0771f81e38',
  'as_00000000-0000-7fee-81f4-cfcfc003f25f',
  'provider_openai',
  'gateway-reported:input',
  'policy:v1',
  'workspace-policy',
  'workspace_policy_allowed',
  'llm.gateway.policy',
] as const;

const EVIDENCE_BUNDLES = {
  workspaceId: WORKSPACE.id,
  apiKey: 'evidence-response-poison-should-never-render',
  evidenceBundles: [
    {
      id: 'evb_debug_1',
      workspaceId: WORKSPACE.id,
      threadId: 'th_00000000-0000-76d3-a603-91157f81e5c0',
      goalId: null,
      turnId: 'tu_00000000-0000-734d-b2a2-e75b248313a6',
      agentSessionId: 'as_00000000-0000-7603-8225-d488b91d9938',
      backendType: null,
      sourceKind: 'manual',
      summary: `Goal evidence is ready with ${POISON_SECRET}.`,
      rawEvidenceRefs: [{ kind: 'backend-log', ref: 'raw-evidence-locator-should-never-render' }],
      redactedEvidenceRefs: [{ kind: 'artifact', ref: 'ar_00000000-0000-7b7e-8526-70bc66fa3094' }],
      contentDigests: ['sha256:evidence'],
      retentionClass: 'turn-evidence',
      sensitivityClass: 'product-safe',
      importStatus: 'collected',
      requiredFeatures: [],
      createdAt: TIMESTAMP,
      accessToken: 'evidence-row-poison-should-never-render',
    },
  ],
};

const RUNTIME_EVIDENCE = {
  workspaceId: WORKSPACE.id,
  token: 'runtime-response-poison-should-never-render',
  runtimeEvidence: [
    {
      id: 'rte_debug_1',
      workspaceId: WORKSPACE.id,
      threadId: 'th_00000000-0000-76d3-a603-91157f81e5c0',
      turnId: 'tu_00000000-0000-734d-b2a2-e75b248313a6',
      goalId: null,
      taskId: null,
      agentSessionId: 'as_00000000-0000-7603-8225-d488b91d9938',
      backendType: 'openshell',
      backendVersion: null,
      placement: 'local',
      phase: 'teardown',
      summary: 'Worker checkpoint terminal: completed.',
      policyDigest: null,
      workerImage: null,
      sandboxSummary: null,
      capabilitySummary: 'worker turn checkpoint',
      uploadManifest: [],
      downloadManifest: [],
      transcriptSummary: null,
      workspaceChangeSummary: null,
      controlSummary: null,
      outcome: 'succeeded',
      exitCode: 0,
      signal: null,
      stopReason: 'completed',
      errorCode: null,
      errorMessage: null,
      redactedStdoutSummary: `stdout ${POISON_SECRET}`,
      redactedStderrSummary: null,
      evidenceBundleIds: ['evb_debug_1'],
      contentDigests: ['sha256:runtime'],
      requiredFeatures: [],
      createdAt: TIMESTAMP,
      startedAt: null,
      completedAt: TIMESTAMP,
      collectedAt: TIMESTAMP,
      authorization: 'runtime-row-poison-should-never-render',
    },
  ],
};

const AEP_SNAPSHOT_LIST_ITEM = {
  snapshotId: 'aepsnap_1',
  workspaceId: WORKSPACE.id,
  turnId: 'tu_00000000-0000-734d-b2a2-e75b248313a6',
  threadId: 'th_00000000-0000-76d3-a603-91157f81e5c0',
  agentSessionId: 'as_00000000-0000-7603-8225-d488b91d9938',
  agentId: 'agent_1',
  packageId: 'aepkg_1',
  runtimeKind: 'coder',
  backendKind: 'openshell',
  contentDigest: '0123456789abcdef',
  snapshot: { snapshotId: 'aepsnap_1' },
  createdAt: TIMESTAMP,
};

const AEP_SNAPSHOTS = {
  items: [AEP_SNAPSHOT_LIST_ITEM],
};

const AEP_SNAPSHOT_DETAIL = {
  ...AEP_SNAPSHOT_LIST_ITEM,
  snapshot: {
    snapshotId: 'aepsnap_1',
    packageId: 'aepkg_1',
    scope: {
      workspaceId: WORKSPACE.id,
      threadId: 'th_00000000-0000-76d3-a603-91157f81e5c0',
      turnId: 'tu_00000000-0000-734d-b2a2-e75b248313a6',
      agentSessionId: 'as_00000000-0000-7603-8225-d488b91d9938',
    },
    agent: {
      agentId: 'agent_1',
      runtimeKind: 'coder',
    },
    backend: {
      preferred: 'openshell',
    },
    apiKey: POISON_SECRET,
  },
};

const DEBUG_FIELD_POISONS = [
  'evidence-response-poison-should-never-render',
  'evidence-row-poison-should-never-render',
  'raw-evidence-locator-should-never-render',
  'runtime-response-poison-should-never-render',
  'runtime-row-poison-should-never-render',
  'as_00000000-0000-7603-8225-d488b91d9938',
] as const;

type MethodOverrides = Partial<Record<string, unknown>>;

/** Build a fake CoreClient; per-test overrides replace individual methods. */
function makeClient(
  overrides: { operations?: MethodOverrides; core?: MethodOverrides; app?: MethodOverrides } = {}
): CoreClient {
  return {
    core: {
      meta: vi.fn().mockResolvedValue(META),

      listKnowledge: vi.fn().mockResolvedValue({ items: [] }),
      ...overrides.core,
    },
    app: { ...overrides.app },
    auth: { email: { signUp: vi.fn(), signIn: vi.fn(), signOut: vi.fn(), getSession: vi.fn() } },
    capabilities: {
      refresh: vi.fn(),
      snapshot: vi.fn().mockReturnValue(META),
      supports: vi.fn().mockReturnValue(true),
      require: vi.fn(),
    },
    agents: {
      list: vi.fn().mockResolvedValue({ items: [] }),
      get: vi.fn(),
      refreshHealth: vi.fn(),
    },
    repositories: {},
    operations: {
      'diagnostics.app': vi.fn().mockResolvedValue(DIAGNOSTICS),
      'runtime.file-list': vi.fn().mockResolvedValue({
        files: [
          {
            id: 'server',
            kind: 'server',
            path: 'config/server.jsonc',
            exists: true,
            revision: 'rev1',
            updatedAt: TIMESTAMP,
          },
          {
            id: 'provider_demo',
            kind: 'provider',
            path: 'config/providers/demo.provider.jsonc',
            exists: true,
            revision: 'rev2',
            updatedAt: TIMESTAMP,
          },
        ],
      }),
      'runtime.file-read': vi.fn().mockResolvedValue({
        file: {
          id: 'server',
          kind: 'server',
          path: 'config/server.jsonc',
          exists: true,
          revision: 'rev1',
          updatedAt: TIMESTAMP,
        },
        content: JSON.stringify({ apiKey: POISON_SECRET }),
      }),
      'runtime.file-create': vi.fn(),
      'runtime.validate': vi.fn(),
      'runtime.file-update': vi.fn(),
      'runtime.reload': vi.fn(),
      'provider-subscription.provider-list': vi.fn().mockResolvedValue(PROVIDERS),
      'provider-subscription.account-list': vi
        .fn()
        .mockImplementation(
          ({ subscriptionProviderId: providerId }: { subscriptionProviderId: string }) =>
            Promise.resolve({
              accounts: providerId === 'openai-codex' ? [CODEX_ACCOUNT] : [XAI_ACCOUNT],
            })
        ),
      'provider-subscription.account-create': vi.fn(),
      'provider-subscription.account-update': vi.fn(),
      'provider-subscription.account-delete': vi.fn(),
      'provider-subscription.account-status': vi
        .fn()
        .mockImplementation(
          ({
            subscriptionProviderId: provider,
            accountSlotId: slot,
          }: {
            subscriptionProviderId: string;
            accountSlotId: string;
          }) =>
            Promise.resolve({
              ...(provider === 'xai' ? XAI_ACCOUNT : CODEX_ACCOUNT),
              subscriptionProviderId: provider,
              accountSlotId: slot,
            })
        ),
      'provider-subscription.account-login-start': vi.fn(),
      'provider-subscription.account-login-cancel': vi.fn(),
      'provider-subscription.account-logout': vi.fn(),
      'provider-subscription.account-quota': vi
        .fn()
        .mockImplementation(
          ({ subscriptionProviderId: providerId }: { subscriptionProviderId: string }) =>
            Promise.resolve(providerId === 'openai-codex' ? CODEX_QUOTA : XAI_QUOTA)
        ),
      'vault.provider-api-key-set': vi
        .fn()
        .mockResolvedValue({ providerId: 'provider_demo', configured: true }),
      'vault.status': vi.fn().mockResolvedValue(DEPLOYMENT_ADMIN_VAULT_STATUS),
      'vault.reference-list': vi.fn().mockResolvedValue(VAULT_REFERENCES),
      'vault.grant-list': vi.fn().mockResolvedValue(VAULT_GRANTS),
      'vault.use-list': vi.fn().mockResolvedValue(VAULT_USE_RECORDS),
      'vault.injection-plan-list': vi.fn().mockResolvedValue(VAULT_INJECTION_PLANS),
      'vault.injection-receipt-list': vi.fn().mockResolvedValue(VAULT_INJECTION_RECEIPTS),
      'vault.server-use-list': vi.fn(),
      'vault.unlock': vi.fn(),
      'vault.lock': vi.fn(),
      'vault.bootstrap-codex-auth': vi.fn(),
      'vault.reference-rebind': vi.fn(),
      'usage.read': vi.fn().mockResolvedValue(CAPABILITY_USAGE),
      'audit.workspace-list': vi.fn().mockResolvedValue(WORKSPACE_AUDIT_EVENTS),
      'audit.server-list': vi.fn().mockResolvedValue(SERVER_AUDIT_EVENTS),
      'permission.workspace-list': vi.fn().mockResolvedValue(WORKSPACE_PERMISSION_DECISIONS),
      'permission.server-list': vi.fn(),
      'evidence.bundle-list': vi.fn().mockResolvedValue(EVIDENCE_BUNDLES),
      'evidence.runtime-list': vi.fn().mockResolvedValue(RUNTIME_EVIDENCE),
      'environment.snapshot-list': vi.fn().mockResolvedValue(AEP_SNAPSHOTS),
      'environment.snapshot-read': vi.fn().mockResolvedValue(AEP_SNAPSHOT_DETAIL),
      'thread.list': vi.fn().mockResolvedValue({ items: [] }),
      'workspace.read': vi.fn().mockResolvedValue(WORKSPACE),
      'workspace.update': vi.fn().mockResolvedValue({ ...WORKSPACE, name: 'Renamed workspace' }),
      'workspace.dashboard': vi.fn().mockResolvedValue({
        workspace: WORKSPACE,
        counts: WORKSPACE.counts,
        defaultContext: { agentId: null },
        agentHealth: [],
        recentThreads: [],
        activeWork: [],
        recentCompletions: [],
        attentionNeeded: [],
      }),
      'attention.list': vi.fn().mockResolvedValue({ items: [] }),
      'workspace.resources': vi.fn().mockResolvedValue(WORKSPACE_RESOURCES),
      ...overrides.operations,
      'workspace.list': vi
        .fn()
        .mockResolvedValueOnce({
          items: [WORKSPACE].map((workspace) => ({
            membershipStatus: 'active' as const,
            accessCause: 'membership' as const,
            workspace,
            effectiveRole: 'owner',
            membershipRevision: 1,
            ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
            registryRevision: 1,
          })),
        })
        .mockImplementation(
          (overrides.operations?.['workspace.list'] as
            | CoreClient['operations']['workspace.list']
            | undefined) ??
            vi.fn().mockResolvedValue({
              items: [WORKSPACE].map((workspace) => ({
                membershipStatus: 'active' as const,
                accessCause: 'membership' as const,
                workspace,
                effectiveRole: 'owner',
                membershipRevision: 1,
                ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
                registryRevision: 1,
              })),
            })
        ),
    },
  } as unknown as CoreClient;
}

function renderApp(path: string, client: CoreClient, content: ReactNode = <AppRoutes />) {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  const wrapper = (children: ReactNode) => (
    <QueryClientProvider client={queryClient}>
      <CoreClientProvider client={client}>
        <MemoryRouter initialEntries={[path]}>{children}</MemoryRouter>
      </CoreClientProvider>
    </QueryClientProvider>
  );
  render(wrapper(content));
  return client;
}

beforeEach(() => {
  localStorage.clear();
  useWorkspaceStore.setState({ currentWorkspaceId: null });
});

describe('secret-safe projection helpers', () => {
  it('redacts secret-shaped substrings', () => {
    expect(redactSecretShapedText(`token ${POISON_SECRET} ok`)).not.toContain(POISON_SECRET);
    expect(redactSecretShapedText(`token ${POISON_SECRET} ok`)).toContain('[redacted]');
  });

  it('strips known secret field names before projection', () => {
    const safe = stripSecretFields({
      displayName: 'ChatGPT',
      apiKey: POISON_SECRET,
      nested: { token: 'okt_should_go', status: 'logged_in' },
    }) as Record<string, unknown>;
    expect(safe.displayName).toBe('ChatGPT');
    expect(safe.apiKey).toBeUndefined();
    expect((safe.nested as Record<string, unknown>).status).toBe('logged_in');
    expect((safe.nested as Record<string, unknown>).token).toBeUndefined();
  });

  it('projectSafeValue never returns raw secret strings', () => {
    const projected = projectSafeValue({
      apiKey: POISON_SECRET,
      label: `Bearer ${POISON_SECRET}`,
      status: 'configured',
    }) as Record<string, unknown>;
    expect(JSON.stringify(projected)).not.toContain(POISON_SECRET);
    expect(projected.status).toBe('configured');
  });
});

describe('provider subscription projection', () => {
  it('fails closed when an account belongs to another provider', () => {
    expect(() =>
      projectConnectedApps(PROVIDERS.providers[0], { accounts: [XAI_ACCOUNT] }, [XAI_QUOTA])
    ).toThrow();
  });

  it.each([
    ['provider differs', XAI_QUOTA],
    ['account slot differs', { ...CODEX_QUOTA, accountSlotId: 'secondary' }],
  ])('fails closed when the quota %s from its account', (_dimension, quota) => {
    expect(() =>
      projectConnectedApps(PROVIDERS.providers[0], { accounts: [CODEX_ACCOUNT] }, [quota])
    ).toThrow();
  });

  it('preserves full quota windows instead of remaining percents only', () => {
    const projected = projectConnectedApps(PROVIDERS.providers[0], { accounts: [CODEX_ACCOUNT] }, [
      {
        ...CODEX_QUOTA,
        windows: [
          { id: 'primary', usedPercent: 40.4, remainingPercent: 59.6, resetsAt: TIMESTAMP },
          { id: 'secondary', usedPercent: 99.6 },
        ],
      },
    ]);
    expect(projected.accounts[0]?.quotaWindows).toEqual([
      {
        id: 'primary',
        usedPercent: 40.4,
        remainingPercent: 59.6,
        periodType: null,
        startsAt: null,
        resetsAt: TIMESTAMP,
      },
      {
        id: 'secondary',
        usedPercent: 99.6,
        remainingPercent: null,
        periodType: null,
        startsAt: null,
        resetsAt: null,
      },
    ]);
    expect(projected.accounts[0]).not.toHaveProperty('quotaRemainingPercents');
  });

  it('projects omitted percents and periods as unknown and keeps same-call account metadata', () => {
    const omitted = projectConnectedApps(PROVIDERS.providers[1], { accounts: [XAI_ACCOUNT] }, [
      {
        subscriptionProviderId: 'xai',
        accountSlotId: 'primary',
        availability: 'available',
        observedAt: TIMESTAMP,
        planType: 'SuperGrok',
        subscriptionActive: true,
        accountObservedAt: TIMESTAMP,
        windows: [{ id: 'included', periodType: 'weekly', resetsAt: TIMESTAMP }],
        billing: { currency: 'USD', prepaidBalanceCents: 0, sharedAllowance: true },
      },
    ]);
    expect(omitted.accounts[0]?.quotaWindows).toEqual([
      {
        id: 'included',
        usedPercent: null,
        remainingPercent: null,
        periodType: 'weekly',
        startsAt: null,
        resetsAt: TIMESTAMP,
      },
    ]);
    expect(omitted.accounts[0]?.quotaBilling).toEqual({
      currency: 'USD',
      prepaidBalanceCents: 0,
      onDemandUsedCents: null,
      onDemandCapCents: null,
      sharedAllowance: true,
    });
    const failedBilling = projectConnectedApps(
      PROVIDERS.providers[1],
      { accounts: [XAI_ACCOUNT] },
      [
        {
          subscriptionProviderId: 'xai',
          accountSlotId: 'primary',
          availability: 'temporarily_unavailable',
          observedAt: TIMESTAMP,
          planType: 'SuperGrok',
          subscriptionActive: true,
          accountObservedAt: TIMESTAMP,
        },
      ]
    );
    expect(failedBilling.accounts[0]?.quotaPlanType).toBe('SuperGrok');
    expect(failedBilling.accounts[0]?.quotaSubscriptionActive).toBe(true);
    expect(failedBilling.accounts[0]?.quotaAccountObservedAt).toBe(TIMESTAMP);
    expect(failedBilling.accounts[0]?.quotaWindows).toEqual([]);
    expect(failedBilling.accounts[0]?.quotaBilling).toBeNull();
  });

  it('overlays a newer matching quota and ignores stale or mismatched pairs', () => {
    const providers = [
      projectConnectedApps(PROVIDERS.providers[0], { accounts: [CODEX_ACCOUNT] }, [CODEX_QUOTA]),
      projectConnectedApps(PROVIDERS.providers[1], { accounts: [XAI_ACCOUNT] }, [XAI_QUOTA]),
    ];
    const newerAt = '2026-07-21T13:00:00.000Z';
    const newer = overlayConnectedAppQuota(providers, {
      ...CODEX_QUOTA,
      observedAt: newerAt,
      windows: [{ id: 'primary', usedPercent: 10, remainingPercent: 90, resetsAt: newerAt }],
    });
    expect(newer[0]?.accounts[0]?.quotaObservedAt).toBe(newerAt);
    expect(newer[0]?.accounts[0]?.quotaWindows).toEqual([
      {
        id: 'primary',
        usedPercent: 10,
        remainingPercent: 90,
        periodType: null,
        startsAt: null,
        resetsAt: newerAt,
      },
    ]);
    expect(newer[1]?.accounts[0]?.quotaWindows[0]?.id).toBe('included');

    const stale = overlayConnectedAppQuota(newer, {
      ...CODEX_QUOTA,
      observedAt: TIMESTAMP,
      windows: [{ id: 'primary', usedPercent: 1, remainingPercent: 99 }],
    });
    expect(stale[0]?.accounts[0]?.quotaObservedAt).toBe(newerAt);
    expect(stale[0]?.accounts[0]?.quotaWindows[0]?.remainingPercent).toBe(90);

    const mismatched = overlayConnectedAppQuota(newer, {
      ...CODEX_QUOTA,
      accountSlotId: 'secondary',
      observedAt: '2026-07-21T14:00:00.000Z',
      windows: [{ id: 'primary', usedPercent: 1, remainingPercent: 99 }],
    });
    expect(mismatched[0]?.accounts[0]?.accountSlotId).toBe('primary');
    expect(mismatched[0]?.accounts[0]?.quotaObservedAt).toBe(newerAt);
  });
});

describe('Vault settings (board 15)', () => {
  it('is live in normal Settings navigation and renders only bounded secret-safe live metadata', async () => {
    const client = makeClient();
    const surface = surfaceById('vault');
    expect(surface).toMatchObject({ tier: 'A', nav: 'workspace-compact' });
    expect(isSurfaceLive(surface!)).toBe(true);

    renderApp('/workspace/vault', client);

    expect(await screen.findByRole('heading', { level: 1, name: 'Vault' })).toBeInTheDocument();
    expect(screen.queryByText(/not yet backed by the kernel/i)).not.toBeInTheDocument();
    const references = await screen.findByRole('region', { name: 'References' });
    const grants = screen.getByRole('region', { name: 'Grants' });
    const uses = screen.getByRole('region', { name: 'Recent use' });
    const plans = screen.getByRole('region', { name: 'Injection plans' });
    const receipts = screen.getByRole('region', { name: 'Injection receipts' });
    expect(
      within(references).getByText('vault_00000000-0000-7fce-81f5-bbcd6886eec4', { exact: true })
    ).toBeInTheDocument();
    expect(within(plans).getByText('plan_release_worker', { exact: true })).toBeInTheDocument();
    expect(within(plans).getByText('gateway-only', { exact: true })).toBeInTheDocument();
    expect(
      within(plans).getByText('Expires with turn grant [redacted]', { exact: true })
    ).toBeInTheDocument();
    expect(
      within(receipts).getByText('receipt_release_worker', { exact: true })
    ).toBeInTheDocument();
    expect(
      within(receipts).getByText('OpenShell attach [redacted]', { exact: true })
    ).toBeInTheDocument();

    const renderedText = document.body.textContent ?? '';
    expect(renderedText).toContain('vault_00000000-0000-7fce-81f5-bbcd6886eec4');
    expect(renderedText).toContain('Release worker [redacted]');
    expect(screen.queryByText('Vault backend', { exact: true })).not.toBeInTheDocument();
    expect(
      screen.queryByText(DEPLOYMENT_ADMIN_VAULT_STATUS.backendKind, { exact: true })
    ).not.toBeInTheDocument();
    expect(
      screen.queryByText('deployment-admin-diagnostic-should-never-render [redacted]', {
        exact: true,
      })
    ).not.toBeInTheDocument();
    expect(screen.queryByText('Error', { exact: true })).not.toBeInTheDocument();
    expect({
      references: [
        within(references).getByText('vault_00000000-0000-7fce-81f5-bbcd6886eec4').parentElement!
          .parentElement!.lastElementChild?.textContent,
        within(references).getByText('vault_00000000-0000-79ba-85de-cbbc8f50e6fa').parentElement!
          .parentElement!.lastElementChild?.textContent,
        within(references).getByText('vault_00000000-0000-771c-a997-47522da0dafe').parentElement!
          .parentElement!.lastElementChild?.textContent,
      ],
      grants: [
        within(grants).getByText('Release worker [redacted]', { exact: true }).parentElement!
          .parentElement!.lastElementChild?.textContent,
        within(grants).getByText('Archive worker').parentElement!.parentElement!.lastElementChild
          ?.textContent,
        within(grants).getByText('History worker').parentElement!.parentElement!.lastElementChild
          ?.textContent,
      ],
      uses: [
        within(uses).getByText('vault_00000000-0000-7fce-81f5-bbcd6886eec4').parentElement!
          .parentElement!.lastElementChild?.textContent,
        within(uses).getByText('vault_00000000-0000-7a31-b0e1-45f0875d4f6f').parentElement!
          .parentElement!.lastElementChild?.textContent,
        within(uses).getByText('vault_00000000-0000-718b-bed8-d5cdaac28798').parentElement!
          .parentElement!.lastElementChild?.textContent,
      ],
      plans: [
        within(plans).getByText('plan_release_worker').parentElement!.parentElement!
          .lastElementChild?.textContent,
      ],
      receipts: [
        within(receipts).getByText('receipt_release_worker').parentElement!.parentElement!
          .lastElementChild?.textContent,
      ],
    }).toEqual({
      references: ['Ready', 'Cancelled', 'Blocked'],
      grants: ['Ready', 'Cancelled', 'Cancelled'],
      uses: ['Done', 'Rejected', 'Failed'],
      plans: ['Ready'],
      receipts: ['Ready'],
    });
    const staleReceiptChip =
      within(receipts).getByText('receipt_stale_worker').parentElement!.parentElement!
        .lastElementChild?.textContent;
    expect(staleReceiptChip).toMatch(/review|stale|warning|attention/i);
    expect(staleReceiptChip).not.toMatch(/^(Failed|Ready|Cancelled|Done|Blocked|Rejected)$/);
    for (const [region, rawStatuses] of [
      [references, ['active', 'revoked', 'unbound']],
      [grants, ['active', 'revoked', 'expired']],
      [uses, ['succeeded', 'denied', 'failed']],
      [plans, ['active']],
      [receipts, ['active', 'stale-session']],
    ] as const) {
      for (const rawStatus of rawStatuses) {
        expect(within(region).queryByText(rawStatus, { exact: true })).not.toBeInTheDocument();
      }
    }
    const serializedDom = document.documentElement.outerHTML;
    expect(serializedDom).not.toContain(POISON_SECRET);
    for (const poison of VAULT_FIELD_POISONS) expect(serializedDom).not.toContain(poison);
    expect(screen.queryByRole('button', { name: /add secret/i })).not.toBeInTheDocument();
    expect(screen.queryAllByRole('button', { name: /more actions/i })).toHaveLength(0);

    for (const excludedRead of [
      client.operations['vault.status'],
      client.operations['vault.server-use-list'],
    ]) {
      expect(excludedRead).not.toHaveBeenCalled();
    }
    expect({
      plans: vi.mocked(client.operations['vault.injection-plan-list']).mock.calls,
      receipts: vi.mocked(client.operations['vault.injection-receipt-list']).mock.calls,
    }).toEqual({
      plans: [[{ workspaceId: WORKSPACE.id }]],
      receipts: [[{ workspaceId: WORKSPACE.id }]],
    });
    for (const mutation of [
      client.operations['vault.unlock'],
      client.operations['vault.lock'],
      client.operations['vault.bootstrap-codex-auth'],
      client.operations['vault.reference-rebind'],
    ]) {
      expect(mutation).not.toHaveBeenCalled();
    }
  });

  it('validates a persisted Workspace selection before Vault reads after discovery retry', async () => {
    const user = userEvent.setup();
    useWorkspaceStore.setState({ currentWorkspaceId: 'ws_00000000-0000-72a2-a815-916a363a02e2' });
    const listWorkspaces = vi
      .fn()
      .mockRejectedValueOnce(new Error('ws_00000000-0000-758f-ad51-c7addeabda71 failure'))
      .mockResolvedValue({
        items: [WORKSPACE].map((workspace) => ({
          membershipStatus: 'active' as const,
          accessCause: 'membership' as const,
          workspace,
          effectiveRole: 'owner' as const,
          membershipRevision: 1,
          ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
          registryRevision: 1,
        })),
      });
    const client = makeClient({ core: {}, operations: { 'workspace.list': listWorkspaces } });
    renderApp('/workspace/vault', client);

    const alert = await screen.findByRole('alert');
    expect(alert).toHaveTextContent(/couldn't load workspaces/i);
    expect(alert).not.toHaveTextContent('ws_00000000-0000-758f-ad51-c7addeabda71 failure');
    expect(screen.queryByText('No workspace selected')).not.toBeInTheDocument();

    await user.click(within(alert).getByRole('button', { name: 'Try again' }));
    await waitFor(() => expect(listWorkspaces).toHaveBeenCalledTimes(2));
    expect(await screen.findByText('Done')).toBeInTheDocument();
    const validatedAt = listWorkspaces.mock.invocationCallOrder[1];
    expect({
      deploymentAdminStatusCalls: vi.mocked(client.operations['vault.status']).mock.calls,
      references: {
        calls: vi.mocked(client.operations['vault.reference-list']).mock.calls,
        afterValidation:
          vi.mocked(client.operations['vault.reference-list']).mock.invocationCallOrder[0] >
          validatedAt,
      },
      grants: {
        calls: vi.mocked(client.operations['vault.grant-list']).mock.calls,
        afterValidation:
          vi.mocked(client.operations['vault.grant-list']).mock.invocationCallOrder[0] >
          validatedAt,
      },
      uses: {
        calls: vi.mocked(client.operations['vault.use-list']).mock.calls,
        afterValidation:
          vi.mocked(client.operations['vault.use-list']).mock.invocationCallOrder[0] > validatedAt,
      },
    }).toEqual({
      deploymentAdminStatusCalls: [],
      references: { calls: [[{ workspaceId: WORKSPACE.id }]], afterValidation: true },
      grants: { calls: [[{ workspaceId: WORKSPACE.id }]], afterValidation: true },
      uses: { calls: [[{ workspaceId: WORKSPACE.id }]], afterValidation: true },
    });
  });

  it('shows content-shaped loading skeletons while the live reads are pending', async () => {
    const pending = new Promise(() => {});
    renderApp(
      '/workspace/vault',
      makeClient({
        app: {},
        operations: {
          'vault.reference-list': vi.fn().mockReturnValue(pending),
          'vault.grant-list': vi.fn().mockReturnValue(pending),
          'vault.use-list': vi.fn().mockReturnValue(pending),
        },
      })
    );

    await waitFor(() => expect(screen.getAllByLabelText('Loading').length).toBeGreaterThan(0));
  });

  it('shows an explicit empty state for each Workspace Vault record family', async () => {
    const client = makeClient({
      app: {},
      operations: {
        'vault.reference-list': vi.fn().mockResolvedValue({ workspaceId: WORKSPACE.id, items: [] }),
        'vault.grant-list': vi.fn().mockResolvedValue({ workspaceId: WORKSPACE.id, items: [] }),
        'vault.use-list': vi
          .fn()
          .mockResolvedValue({ workspaceId: WORKSPACE.id, vaultUseRecords: [] }),
      },
    });
    renderApp('/workspace/vault', client);

    expect(
      await screen.findByText('No credential references', { exact: true })
    ).toBeInTheDocument();
    expect(screen.getByText('No active or historical grants', { exact: true })).toBeInTheDocument();
    expect(screen.getByText('No credential use recorded', { exact: true })).toBeInTheDocument();
  });

  it('shows a plain error and retries the failed live read', async () => {
    const user = userEvent.setup();
    const listWorkspaceVaultReferences = vi
      .fn()
      .mockRejectedValueOnce(new Error('ws_00000000-0000-70ee-aa39-ad23b095f65e failure'))
      .mockResolvedValue(VAULT_REFERENCES);
    renderApp(
      '/workspace/vault',
      makeClient({ app: {}, operations: { 'vault.reference-list': listWorkspaceVaultReferences } })
    );

    const alert = await screen.findByRole('alert');
    expect(alert).not.toHaveTextContent('ws_00000000-0000-70ee-aa39-ad23b095f65e failure');
    await user.click(within(alert).getByRole('button', { name: 'Try again' }));
    await waitFor(() => expect(listWorkspaceVaultReferences).toHaveBeenCalledTimes(2));
    const references = await screen.findByRole('region', { name: 'References' });
    expect(
      within(references).getByText('vault_00000000-0000-7fce-81f5-bbcd6886eec4', { exact: true })
    ).toBeInTheDocument();
  });

  it('shows an explicit retry when injection-plan reads fail without dropping other Vault families after recovery', async () => {
    const user = userEvent.setup();
    const listWorkspaceVaultInjectionPlans = vi
      .fn()
      .mockRejectedValueOnce(
        new ApiCallError(403, 'injection-plan-private failure', {
          code: 'workspace_access_denied',
        })
      )
      .mockResolvedValue(VAULT_INJECTION_PLANS);
    renderApp(
      '/workspace/vault',
      makeClient({
        app: {},
        operations: { 'vault.injection-plan-list': listWorkspaceVaultInjectionPlans },
      })
    );

    const alert = await screen.findByRole('alert');
    expect(alert).toHaveTextContent(/couldn't load/i);
    expect(alert).not.toHaveTextContent('injection-plan-private failure');
    expect(alert).not.toHaveTextContent('workspace_access_denied');
    expect(screen.queryByText('plan_release_worker', { exact: true })).not.toBeInTheDocument();
    await user.click(within(alert).getByRole('button', { name: 'Try again' }));
    await waitFor(() => expect(listWorkspaceVaultInjectionPlans).toHaveBeenCalledTimes(2));
    expect(listWorkspaceVaultInjectionPlans).toHaveBeenCalledWith({ workspaceId: WORKSPACE.id });
    const plans = await screen.findByRole('region', { name: 'Injection plans' });
    expect(within(plans).getByText('plan_release_worker', { exact: true })).toBeInTheDocument();
    const references = screen.getByRole('region', { name: 'References' });
    expect(
      within(references).getByText('vault_00000000-0000-7fce-81f5-bbcd6886eec4', { exact: true })
    ).toBeInTheDocument();
    expect(screen.getByRole('region', { name: 'Grants' })).toBeInTheDocument();
    expect(screen.getByRole('region', { name: 'Recent use' })).toBeInTheDocument();
    expect(screen.getByRole('region', { name: 'Injection receipts' })).toBeInTheDocument();
  });

  it('marks Workspace Vault metadata as stale while Core is disconnected', async () => {
    const client = makeClient({
      core: { meta: vi.fn().mockRejectedValue(new Error('down')) },
    });
    renderApp('/workspace/vault', client);

    const references = await screen.findByRole('region', { name: 'References' });
    expect(
      within(references).getByText('vault_00000000-0000-7fce-81f5-bbcd6886eec4', { exact: true })
    ).toBeInTheDocument();
    expect(await screen.findByText('Status may be stale', { exact: true })).toBeInTheDocument();
  });
});

describe('Debug settings (board 11)', () => {
  it('reads selected-Workspace evidence and AEP snapshots, then lazily loads one snapshot detail', async () => {
    const user = userEvent.setup();
    const client = makeClient();
    renderApp('/settings/debug', client);

    expect(await screen.findByRole('heading', { level: 1, name: 'Debug' })).toBeInTheDocument();
    expect(screen.getByText('Buttons', { exact: true })).toBeInTheDocument();
    expect(
      await screen.findByText('Goal evidence is ready with [redacted].', { exact: true })
    ).toBeInTheDocument();
    expect(
      screen.getByText('Worker checkpoint terminal: completed.', { exact: true })
    ).toBeInTheDocument();
    expect(screen.getByText('aepsnap_1', { exact: true })).toBeInTheDocument();
    expect(screen.queryByText('coder', { exact: true })).not.toBeInTheDocument();
    expect(screen.queryByText('aepkg_1', { exact: true })).not.toBeInTheDocument();
    expect(client.operations['environment.snapshot-read']).not.toHaveBeenCalled();

    const snapshotButton = screen.getByRole('button', { name: 'aepsnap_1' });
    expect(snapshotButton).not.toHaveAttribute('aria-pressed', 'true');
    await user.click(snapshotButton);
    await waitFor(() =>
      expect(client.operations['environment.snapshot-read']).toHaveBeenCalledWith({
        workspaceId: WORKSPACE.id,
        snapshotId: 'aepsnap_1',
      })
    );
    expect(await screen.findByText('coder', { exact: true })).toBeInTheDocument();
    expect(screen.getByText('aepkg_1', { exact: true })).toBeInTheDocument();
    expect(snapshotButton).toHaveAttribute('aria-pressed', 'true');
    expect(client.operations['environment.snapshot-read']).toHaveBeenCalledTimes(1);

    const serializedDom = document.documentElement.outerHTML;
    expect(serializedDom).not.toContain(POISON_SECRET);
    for (const poison of DEBUG_FIELD_POISONS) expect(serializedDom).not.toContain(poison);
    expect({
      bundles: vi.mocked(client.operations['evidence.bundle-list']).mock.calls,
      runtime: vi.mocked(client.operations['evidence.runtime-list']).mock.calls,
      snapshots: vi.mocked(client.operations['environment.snapshot-list']).mock.calls,
      diagnostics: vi.mocked(client.operations['diagnostics.app']).mock.calls,
      serverAudit: vi.mocked(client.operations['audit.server-list']).mock.calls,
      vaultAdmin: vi.mocked(client.operations['vault.status']).mock.calls,
    }).toEqual({
      bundles: [[{ workspaceId: WORKSPACE.id }]],
      runtime: [[{ workspaceId: WORKSPACE.id }]],
      snapshots: [[{ workspaceId: WORKSPACE.id }]],
      diagnostics: [],
      serverAudit: [],
      vaultAdmin: [],
    });
  });

  it('keeps other Debug sections visible and retries a typed evidence denial', async () => {
    const user = userEvent.setup();
    const listWorkspaceEvidenceBundles = vi
      .fn()
      .mockRejectedValueOnce(
        new ApiCallError(403, 'evidence-bundle-private failure', {
          code: 'workspace_access_denied',
        })
      )
      .mockResolvedValue(EVIDENCE_BUNDLES);
    const client = makeClient({
      app: {},
      operations: { 'evidence.bundle-list': listWorkspaceEvidenceBundles },
    });
    renderApp('/settings/debug', client);

    expect(await screen.findByRole('heading', { level: 1, name: 'Debug' })).toBeInTheDocument();
    expect(screen.getByText('Buttons', { exact: true })).toBeInTheDocument();
    expect(
      await screen.findByText('Worker checkpoint terminal: completed.', { exact: true })
    ).toBeInTheDocument();
    expect(screen.getByText('aepsnap_1', { exact: true })).toBeInTheDocument();
    expect(
      screen.queryByText('Goal evidence is ready with [redacted].', { exact: true })
    ).not.toBeInTheDocument();

    const evidenceAlert = screen
      .getAllByRole('alert')
      .find((node) => /couldn't load/i.test(node.textContent ?? ''));
    expect(evidenceAlert).toBeTruthy();
    expect(evidenceAlert).not.toHaveTextContent('evidence-bundle-private failure');
    expect(evidenceAlert).not.toHaveTextContent('workspace_access_denied');
    await user.click(
      within(evidenceAlert as HTMLElement).getByRole('button', { name: 'Try again' })
    );
    await waitFor(() => expect(listWorkspaceEvidenceBundles).toHaveBeenCalledTimes(2));
    expect(listWorkspaceEvidenceBundles).toHaveBeenCalledWith({ workspaceId: WORKSPACE.id });
    expect(
      await screen.findByText('Goal evidence is ready with [redacted].', { exact: true })
    ).toBeInTheDocument();
    expect(screen.getByText('Buttons', { exact: true })).toBeInTheDocument();
    expect(
      screen.getByText('Worker checkpoint terminal: completed.', { exact: true })
    ).toBeInTheDocument();
    expect(screen.getByText('aepsnap_1', { exact: true })).toBeInTheDocument();
  });

  it('shows content-shaped loading skeletons while Workspace discovery is pending', async () => {
    renderApp(
      '/settings/debug',
      makeClient({
        core: {},
        operations: { 'workspace.list': vi.fn().mockReturnValue(new Promise(() => {})) },
      })
    );

    expect(await screen.findByRole('heading', { level: 1, name: 'Debug' })).toBeInTheDocument();
    expect(screen.getByText('Buttons', { exact: true })).toBeInTheDocument();
    expect(screen.queryByRole('region', { name: 'Evidence bundles' })).not.toBeInTheDocument();
    await waitFor(() => expect(screen.getAllByLabelText('Loading').length).toBeGreaterThan(1));
  });

  it('shows an empty state when no Workspace is selected', async () => {
    renderApp(
      '/settings/debug',
      makeClient({
        core: {},
        operations: {
          'workspace.list': vi.fn().mockResolvedValue({
            items: [].map((workspace) => ({
              membershipStatus: 'active' as const,
              accessCause: 'membership' as const,
              workspace,
              effectiveRole: 'owner',
              membershipRevision: 1,
              ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
              registryRevision: 1,
            })),
          }),
        },
      })
    );

    expect(await screen.findByText('No workspace selected', { exact: true })).toBeInTheDocument();
    expect(screen.getByText('Buttons', { exact: true })).toBeInTheDocument();
    expect(
      screen.queryByText('Goal evidence is ready with [redacted].', { exact: true })
    ).not.toBeInTheDocument();
  });

  it('clears the selected AEP snapshot when the Workspace switches and does not reread the old id', async () => {
    const user = userEvent.setup();
    const workspaceB = {
      ...WORKSPACE,
      id: 'ws_00000000-0000-7ec6-8e33-a3b1d758efc6',
      name: 'Second workspace',
    };
    const listEnvironmentSnapshots = vi
      .fn()
      .mockImplementation(({ workspaceId }: { workspaceId: string }) =>
        Promise.resolve({
          items: workspaceId === WORKSPACE.id ? [AEP_SNAPSHOT_LIST_ITEM] : [],
        })
      );
    const getAgentEnvironmentPackageSnapshot = vi.fn().mockResolvedValue(AEP_SNAPSHOT_DETAIL);
    const client = makeClient({
      core: {},
      app: {},

      operations: {
        'environment.snapshot-list': listEnvironmentSnapshots,
        'environment.snapshot-read': getAgentEnvironmentPackageSnapshot,
        'workspace.list': vi.fn().mockResolvedValue({
          items: [WORKSPACE, workspaceB].map((workspace) => ({
            membershipStatus: 'active' as const,
            accessCause: 'membership' as const,
            workspace,
            effectiveRole: 'owner',
            membershipRevision: 1,
            ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
            registryRevision: 1,
          })),
        }),
      },
    });
    renderApp('/settings/debug', client);

    const snapshotButton = await screen.findByRole('button', { name: 'aepsnap_1' });
    await user.click(snapshotButton);
    await waitFor(() =>
      expect(getAgentEnvironmentPackageSnapshot).toHaveBeenCalledWith({
        workspaceId: WORKSPACE.id,
        snapshotId: 'aepsnap_1',
      })
    );

    act(() => useWorkspaceStore.setState({ currentWorkspaceId: workspaceB.id }));

    await waitFor(() =>
      expect(listEnvironmentSnapshots).toHaveBeenCalledWith({
        workspaceId: workspaceB.id,
      })
    );
    expect(getAgentEnvironmentPackageSnapshot).not.toHaveBeenCalledWith({
      workspaceId: workspaceB.id,
      snapshotId: 'aepsnap_1',
    });
    expect(getAgentEnvironmentPackageSnapshot.mock.calls).toEqual([
      [{ workspaceId: WORKSPACE.id, snapshotId: 'aepsnap_1' }],
    ]);
    expect(screen.queryByRole('button', { name: 'aepsnap_1' })).not.toBeInTheDocument();
    expect(screen.queryByText('coder', { exact: true })).not.toBeInTheDocument();
    expect(screen.queryByText('aepkg_1', { exact: true })).not.toBeInTheDocument();
  });
});

describe('Usage and audit settings (board 17)', () => {
  it('labels recorded measurements and keeps capability details collapsed until opened', async () => {
    const user = userEvent.setup();
    const sources = ['input', 'output', 'cache_read', 'cache_write', 'total', 'cost_estimate'];
    const client = makeClient({
      app: {},
      operations: {
        'usage.read': vi.fn().mockResolvedValue({
          ...CAPABILITY_USAGE,
          usageRecords: [
            ...sources.map((source, index) => ({
              ...CAPABILITY_USAGE.usageRecords[0],
              id: `usage_${index}`,
              source: `llm-gateway-adapter-reported:${source}`,
              unit: source === 'cost_estimate' ? 'usd' : 'tokens',
            })),
            {
              ...CAPABILITY_USAGE.usageRecords[0],
              id: 'unknown',
              source: 'untrusted:input',
              modelId: null,
            },
          ],
        }),
      },
    });
    renderApp('/workspace/usage', client);
    for (const label of [
      'Input',
      'Output',
      'Cache read',
      'Cache write',
      'Total',
      'Estimated cost',
    ]) {
      expect(await screen.findByText(label, { exact: true })).toBeVisible();
    }
    expect(screen.getAllByText('Logical model: gpt-5')).toHaveLength(6);
    expect(screen.getByText('Logical model: Not recorded')).toBeVisible();
    const call = screen.getByText('chat_completions', { exact: true });
    const disclosure = call.closest('details');
    expect(disclosure).not.toHaveAttribute('open');
    expect(call).not.toBeVisible();
    expect(document.querySelectorAll(`time[datetime="${TIMESTAMP}"]`)).toHaveLength(10);
    await user.click(screen.getByText('Capability calls', { exact: true }));
    expect(disclosure).toHaveAttribute('open');
    expect(call).toBeVisible();
    expect(document.body.textContent).not.toContain('untrusted:input');
    expect(document.body.textContent).not.toContain('llm-gateway-adapter-reported');
  });

  it('is a selected-Workspace read-only surface with exact live reads and a bounded DOM', async () => {
    const client = makeClient();
    const surface = surfaceById('usage');
    expect(surface).toMatchObject({ tier: 'A', nav: 'workspace-compact' });
    expect(isSurfaceLive(surface!)).toBe(true);

    renderApp('/workspace/usage', client);

    expect(
      await screen.findByRole('heading', { level: 1, name: 'Usage & audit' })
    ).toBeInTheDocument();
    const main = screen.getByRole('main');
    expect(screen.queryByText(/not yet backed by the kernel/i)).not.toBeInTheDocument();
    expect(within(main).getByText('Market research', { exact: true })).toBeInTheDocument();
    expect(screen.getByText('chat_completions', { exact: true })).toBeInTheDocument();
    expect(screen.getByText('12 tokens', { exact: true })).toBeInTheDocument();
    expect(
      screen.getByText('Model request completed with [redacted].', { exact: true })
    ).toBeInTheDocument();
    expect(screen.getByText('llm.gateway.use', { exact: true })).toBeInTheDocument();
    expect(screen.getByText('Approved', { exact: true })).toBeInTheDocument();
    expect(screen.getAllByText('Done', { exact: true }).length).toBeGreaterThan(0);
    const usageTimes = document.querySelectorAll(`time[datetime="${TIMESTAMP}"]`);
    expect(usageTimes).toHaveLength(4);
    expect(usageTimes[0]).toHaveTextContent(
      new Date(TIMESTAMP).toLocaleString(undefined, { timeZoneName: 'short' })
    );

    expect(screen.queryByText('succeeded', { exact: true })).not.toBeInTheDocument();
    expect(screen.queryByText('allow', { exact: true })).not.toBeInTheDocument();
    expect(
      within(main).queryByRole('button', {
        name: /approve|deny|delete|edit|export|re-run/i,
      })
    ).not.toBeInTheDocument();
    expect(main).not.toHaveTextContent(
      /so (?:this|the) (?:record|audit) is complete|complete across (?:the )?deployment/i
    );

    const serializedDom = document.documentElement.outerHTML;
    expect(serializedDom).not.toContain(POISON_SECRET);
    for (const poison of USAGE_FIELD_POISONS) expect(serializedDom).not.toContain(poison);
    for (const field of USAGE_NON_DISPLAY_FIELDS) expect(serializedDom).not.toContain(field);

    expect({
      usage: vi.mocked(client.operations['usage.read']).mock.calls,
      audit: vi.mocked(client.operations['audit.workspace-list']).mock.calls,
      decisions: vi.mocked(client.operations['permission.workspace-list']).mock.calls,
      serverAudit: vi.mocked(client.operations['audit.server-list']).mock.calls,
      serverDecisions: vi.mocked(client.operations['permission.server-list']).mock.calls,
    }).toEqual({
      usage: [[{ workspaceId: WORKSPACE.id }]],
      audit: [[{ workspaceId: WORKSPACE.id }]],
      decisions: [[{ workspaceId: WORKSPACE.id }]],
      serverAudit: [],
      serverDecisions: [],
    });
  });

  it('validates a persisted Workspace selection before the three reads after discovery retry', async () => {
    const user = userEvent.setup();
    useWorkspaceStore.setState({ currentWorkspaceId: 'ws_00000000-0000-72a2-a815-916a363a02e2' });
    const listWorkspaces = vi
      .fn()
      .mockRejectedValueOnce(new Error('ws_00000000-0000-7641-ba4a-a1306b8c904a failure'))
      .mockResolvedValue({
        items: [WORKSPACE].map((workspace) => ({
          membershipStatus: 'active' as const,
          accessCause: 'membership' as const,
          workspace,
          effectiveRole: 'owner' as const,
          membershipRevision: 1,
          ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
          registryRevision: 1,
        })),
      });
    const client = makeClient({ core: {}, operations: { 'workspace.list': listWorkspaces } });
    renderApp('/workspace/usage', client);

    const alert = await screen.findByRole('alert');
    expect(alert).toHaveTextContent(/couldn't load workspaces/i);
    expect(alert).not.toHaveTextContent('ws_00000000-0000-7641-ba4a-a1306b8c904a failure');
    await user.click(within(alert).getByRole('button', { name: 'Try again' }));
    await waitFor(() => expect(listWorkspaces).toHaveBeenCalledTimes(2));
    expect(await screen.findByText('chat_completions', { exact: true })).toBeInTheDocument();
    const validatedAt = listWorkspaces.mock.invocationCallOrder[1];
    expect({
      usage: {
        calls: vi.mocked(client.operations['usage.read']).mock.calls,
        afterValidation:
          vi.mocked(client.operations['usage.read']).mock.invocationCallOrder[0] > validatedAt,
      },
      audit: {
        calls: vi.mocked(client.operations['audit.workspace-list']).mock.calls,
        afterValidation:
          vi.mocked(client.operations['audit.workspace-list']).mock.invocationCallOrder[0] >
          validatedAt,
      },
      decisions: {
        calls: vi.mocked(client.operations['permission.workspace-list']).mock.calls,
        afterValidation:
          vi.mocked(client.operations['permission.workspace-list']).mock.invocationCallOrder[0] >
          validatedAt,
      },
      serverAudit: vi.mocked(client.operations['audit.server-list']).mock.calls,
    }).toEqual({
      usage: { calls: [[{ workspaceId: WORKSPACE.id }]], afterValidation: true },
      audit: { calls: [[{ workspaceId: WORKSPACE.id }]], afterValidation: true },
      decisions: { calls: [[{ workspaceId: WORKSPACE.id }]], afterValidation: true },
      serverAudit: [],
    });
  });

  it('shows content-shaped loading skeletons while the three live reads are pending', async () => {
    const pending = new Promise(() => {});
    renderApp(
      '/workspace/usage',
      makeClient({
        app: {},
        operations: {
          'usage.read': vi.fn().mockReturnValue(pending),
          'audit.workspace-list': vi.fn().mockReturnValue(pending),
          'permission.workspace-list': vi.fn().mockReturnValue(pending),
        },
      })
    );

    await waitFor(() => expect(screen.getAllByLabelText('Loading').length).toBeGreaterThan(0));
  });

  it('shows a distinct empty state for usage, audit events, and permission decisions', async () => {
    renderApp(
      '/workspace/usage',
      makeClient({
        app: {},
        operations: {
          'usage.read': vi.fn().mockResolvedValue({
            workspaceId: WORKSPACE.id,
            capabilityCalls: [],
            usageRecords: [],
          }),
          'audit.workspace-list': vi
            .fn()
            .mockResolvedValue({ workspaceId: WORKSPACE.id, auditEvents: [] }),
          'permission.workspace-list': vi
            .fn()
            .mockResolvedValue({ workspaceId: WORKSPACE.id, permissionDecisions: [] }),
        },
      })
    );

    expect(await screen.findByText('No usage recorded', { exact: true })).toBeInTheDocument();
    expect(screen.getByText('No audit events', { exact: true })).toBeInTheDocument();
    expect(screen.getByText('No permission decisions', { exact: true })).toBeInTheDocument();
  });

  it('shows one plain error and retries the failed projection without partial masking', async () => {
    const user = userEvent.setup();
    const listWorkspaceAuditEvents = vi
      .fn()
      .mockRejectedValueOnce(new Error('ws_00000000-0000-74d0-a117-676ff6917be8 failure'))
      .mockResolvedValue(WORKSPACE_AUDIT_EVENTS);
    const client = makeClient({
      app: {},
      operations: { 'audit.workspace-list': listWorkspaceAuditEvents },
    });
    renderApp('/workspace/usage', client);

    const alert = await screen.findByRole('alert');
    expect(alert).toHaveTextContent(/couldn't load usage and audit/i);
    expect(alert).not.toHaveTextContent('ws_00000000-0000-74d0-a117-676ff6917be8 failure');
    expect(screen.queryByText('chat_completions', { exact: true })).not.toBeInTheDocument();
    await user.click(within(alert).getByRole('button', { name: 'Try again' }));
    await waitFor(() => expect(listWorkspaceAuditEvents).toHaveBeenCalledTimes(2));
    expect(await screen.findByText('chat_completions', { exact: true })).toBeInTheDocument();
  });

  it('keeps the selected-Workspace projection visible but marks it stale when disconnected', async () => {
    const client = makeClient({ core: { meta: vi.fn().mockRejectedValue(new Error('down')) } });
    renderApp('/workspace/usage', client);

    expect(await screen.findByText('chat_completions', { exact: true })).toBeInTheDocument();
    expect(await screen.findByText('Status may be stale', { exact: true })).toBeInTheDocument();
  });
});

describe('General settings (board 10)', () => {
  it('loads only Workspace-authorized settings and never requests deployment-admin data', async () => {
    const client = makeClient();
    renderApp('/workspace', client);
    expect(await screen.findByRole('heading', { level: 1, name: 'General' })).toBeInTheDocument();
    expect(await screen.findByLabelText(/Display name/i)).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: /Knowledge/i, level: 2 })).toBeInTheDocument();
    expect(
      screen.queryByRole('heading', { name: 'Configuration', level: 2 })
    ).not.toBeInTheDocument();
    expect(
      screen.queryByRole('heading', { name: 'Diagnostics', level: 2 })
    ).not.toBeInTheDocument();
    expect(client.operations['runtime.file-list']).not.toHaveBeenCalled();
    expect(client.operations['diagnostics.app']).not.toHaveBeenCalled();
    expect(screen.getByRole('link', { name: /Appearance/i })).toHaveAttribute(
      'href',
      '/settings/appearance'
    );
  });

  it('shows a skeleton while workspace settings load', async () => {
    const client = makeClient({
      core: {},
      operations: { 'workspace.read': vi.fn().mockReturnValue(new Promise(() => {})) },
    });
    renderApp('/workspace', client);
    await waitFor(() => expect(screen.getAllByLabelText('Loading').length).toBeGreaterThan(0));
  });

  it('shows an error banner with retry when settings fail to load', async () => {
    const user = userEvent.setup();
    const getWorkspace = vi
      .fn()
      .mockRejectedValueOnce(new Error('boom'))
      .mockResolvedValue(WORKSPACE);
    const client = makeClient({ core: {}, operations: { 'workspace.read': getWorkspace } });
    renderApp('/workspace', client);
    expect(await screen.findByText(/Couldn't load settings/i)).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'Try again' }));
    await waitFor(() => expect(getWorkspace).toHaveBeenCalledTimes(2));
  });

  it('saves the workspace display name', async () => {
    const user = userEvent.setup();
    const updateWorkspace = vi.fn().mockResolvedValue({ ...WORKSPACE, name: 'Team workspace' });
    const client = makeClient({ core: {}, operations: { 'workspace.update': updateWorkspace } });
    renderApp('/workspace', client);

    const nameField = await screen.findByLabelText(/Display name/i);
    await user.clear(nameField);
    await user.type(nameField, 'Team workspace');
    await user.click(screen.getByRole('button', { name: 'Save changes' }));
    await waitFor(() =>
      expect(updateWorkspace).toHaveBeenCalledWith(
        expect.objectContaining({
          workspaceId: 'ws_00000000-0000-7b10-9af8-12fd37a880e0',
          name: 'Team workspace',
        })
      )
    );
  });

  it('disables Save when disconnected', async () => {
    const client = makeClient({
      core: {
        meta: vi.fn().mockRejectedValue(new Error('down')),
      },
      operations: { 'workspace.read': vi.fn().mockResolvedValue(WORKSPACE) },
    });
    renderApp('/workspace', client);
    expect(await screen.findByLabelText(/Display name/i)).toBeInTheDocument();
    await waitFor(
      () => {
        expect(screen.getByRole('button', { name: 'Save changes' })).toBeDisabled();
      },
      { timeout: 3000 }
    );
  });

  it('exposes page landmarks and section headings for a11y', async () => {
    renderApp('/workspace', makeClient());
    expect(await screen.findByRole('heading', { level: 1, name: 'General' })).toBeInTheDocument();
    expect(await screen.findByLabelText(/Display name/i)).toBeInTheDocument();
    expect(screen.getByRole('main')).toBeInTheDocument();
  });
});

describe('Gateway (board 20)', () => {
  it('is a published Tier-A Settings destination', async () => {
    const surface = surfaceById('ai-interface');
    expect(surface).toMatchObject({
      tier: 'A',
      nav: 'settings-server',
      path: '/settings/ai-interface',
    });
    expect(isSurfaceLive(surface!)).toBe(true);

    const client = makeClient();
    renderApp('/settings/ai-interface', client);

    expect(await screen.findByRole('heading', { level: 1, name: 'Gateway' })).toBeInTheDocument();
    expect(screen.getByRole('navigation')).toHaveAccessibleName('Settings sections');
    expect(screen.getByRole('button', { name: 'Gateway' })).toBeInTheDocument();
    expect(screen.queryByText(/status only/i)).not.toBeInTheDocument();
    expect(screen.queryByText('Concept demos')).not.toBeInTheDocument();
    expect(screen.queryByText(/not yet backed by the kernel/i)).not.toBeInTheDocument();
  });

  it('renders the fixed provider inventory, provider-scoped slots, and quota posture', async () => {
    const listProviders = vi.fn().mockResolvedValue(PROVIDERS);
    const listAccounts = vi
      .fn()
      .mockImplementation(
        ({ subscriptionProviderId: providerId }: { subscriptionProviderId: string }) =>
          Promise.resolve({
            accounts: providerId === 'openai-codex' ? [CODEX_ACCOUNT] : [XAI_ACCOUNT],
          })
      );
    const getAccountQuota = vi
      .fn()
      .mockImplementation(
        ({ subscriptionProviderId: providerId }: { subscriptionProviderId: string }) =>
          Promise.resolve(providerId === 'openai-codex' ? CODEX_QUOTA : XAI_QUOTA)
      );
    const client = makeClient({
      operations: {
        'provider-subscription.provider-list': listProviders,
        'provider-subscription.account-list': listAccounts,
        'provider-subscription.account-quota': getAccountQuota,
      },
    });

    renderApp('/settings/ai-interface', client);

    const codexProvider = await screen.findByRole('heading', { name: 'OpenAI Codex' });
    const xaiProvider = screen.getByRole('heading', { name: 'xAI' });
    expect(
      codexProvider.compareDocumentPosition(xaiProvider) & Node.DOCUMENT_POSITION_FOLLOWING
    ).toBeTruthy();
    expect(screen.getByText('Codex primary')).toBeInTheDocument();
    expect(screen.getByText('xAI primary')).toBeInTheDocument();
    expect(screen.getByText('Primary 59.6% remaining')).toBeInTheDocument();
    expect(screen.getByText('Secondary 0.4% remaining')).toBeInTheDocument();
    expect(screen.getByText('Included 87.5% remaining')).toBeInTheDocument();
    expect(screen.getByRole('meter', { name: 'Primary remaining 59.6%' })).toBeInTheDocument();
    expect(screen.getByRole('meter', { name: 'Included remaining 87.5%' })).toBeInTheDocument();
    expect(screen.queryByText('40.4% used')).not.toBeInTheDocument();
    expect(screen.getByText('Resets unknown')).toBeInTheDocument();
    expect(screen.queryByText('Quota unsupported')).not.toBeInTheDocument();
    expect(screen.queryByText(/5h|\bweekly\b/i)).not.toBeInTheDocument();
    expect((await screen.findAllByText('Demo provider')).length).toBeGreaterThan(0);
    expect(client.operations['diagnostics.app']).toHaveBeenCalled();

    expect(listProviders).toHaveBeenCalledTimes(1);
    expect(listAccounts).toHaveBeenCalledTimes(2);
    expect(listAccounts).toHaveBeenCalledWith({ subscriptionProviderId: 'openai-codex' });
    expect(listAccounts).toHaveBeenCalledWith({ subscriptionProviderId: 'xai' });
    expect(getAccountQuota).toHaveBeenCalledTimes(2);
    expect(getAccountQuota).toHaveBeenCalledWith({
      subscriptionProviderId: 'openai-codex',
      accountSlotId: 'primary',
    });
    expect(getAccountQuota).toHaveBeenCalledWith({
      subscriptionProviderId: 'xai',
      accountSlotId: 'primary',
    });
  });

  it('renders all five provider-neutral account lifecycle states and pending device-code details', async () => {
    const listAccounts = vi
      .fn()
      .mockImplementation(
        ({ subscriptionProviderId: providerId }: { subscriptionProviderId: string }) =>
          Promise.resolve({ accounts: providerId === 'openai-codex' ? LIFECYCLE_ACCOUNTS : [] })
      );
    const getAccountQuota = vi
      .fn()
      .mockImplementation(
        ({
          subscriptionProviderId: _providerId,
          accountSlotId,
        }: {
          subscriptionProviderId: string;
          accountSlotId: string;
        }) => Promise.resolve({ ...CODEX_QUOTA, accountSlotId })
      );
    const getAccountStatus = vi
      .fn()
      .mockImplementation(
        ({
          subscriptionProviderId: _providerId,
          accountSlotId,
        }: {
          subscriptionProviderId: string;
          accountSlotId: string;
        }) =>
          Promise.resolve(
            LIFECYCLE_ACCOUNTS.find((account) => account.accountSlotId === accountSlotId)
          )
      );
    renderApp(
      '/settings/ai-interface',
      makeClient({
        operations: {
          'provider-subscription.account-list': listAccounts,
          'provider-subscription.account-quota': getAccountQuota,
          'provider-subscription.account-status': getAccountStatus,
        },
      })
    );

    expect(await screen.findByText('Logged out account')).toBeInTheDocument();
    for (const label of [
      'Not connected',
      'Connecting',
      'Connected',
      'Unavailable',
      'Needs attention',
    ]) {
      expect(screen.getByText(label)).toBeInTheDocument();
    }
    expect(screen.getByText('ABCD-EFGH')).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'https://example.com/device' })).toHaveAttribute(
      'href',
      'https://example.com/device'
    );
  });

  it('renders Codex quota as temporarily unavailable without changing account status', async () => {
    const getAccountQuota = vi
      .fn()
      .mockImplementation(
        ({ subscriptionProviderId: providerId }: { subscriptionProviderId: string }) =>
          Promise.resolve(
            providerId === 'openai-codex'
              ? {
                  subscriptionProviderId: 'openai-codex',
                  accountSlotId: 'primary',
                  availability: 'temporarily_unavailable',
                  observedAt: TIMESTAMP,
                }
              : XAI_QUOTA
          )
      );
    renderApp(
      '/settings/ai-interface',
      makeClient({ operations: { 'provider-subscription.account-quota': getAccountQuota } })
    );
    expect(await screen.findByText('Quota query failed')).toBeInTheDocument();
    expect(screen.getByText('Login saved')).toBeInTheDocument();
    expect(screen.getAllByText('Connected')).toHaveLength(1);
  });

  it('never renders credential or provider-private values from poisoned payloads', async () => {
    const poisonedAccount = {
      ...CODEX_ACCOUNT,
      accessToken: POISON_SECRET,
      vaultReferenceId: 'vault_00000000-0000-7e73-9b11-a88139e7b328',
      rawProviderAccountId: 'raw-provider-id-should-never-render',
      accountLabel: `team ${POISON_SECRET}`,
      message: `credential ${POISON_SECRET}`,
      displayName: 'Poisoned app',
    };
    const client = makeClient({
      operations: {
        'provider-subscription.account-list': vi
          .fn()
          .mockImplementation(
            ({ subscriptionProviderId: providerId }: { subscriptionProviderId: string }) =>
              Promise.resolve({ accounts: providerId === 'openai-codex' ? [poisonedAccount] : [] })
          ),
        'provider-subscription.account-quota': vi
          .fn()
          .mockImplementation(
            ({ subscriptionProviderId: providerId }: { subscriptionProviderId: string }) =>
              Promise.resolve(
                providerId === 'openai-codex'
                  ? {
                      ...CODEX_QUOTA,
                      planType: POISON_SECRET,
                      rawQuotaResponse: 'raw-quota-should-never-render',
                    }
                  : XAI_QUOTA
              )
          ),
      },
    });
    renderApp('/settings/ai-interface', client);
    expect(await screen.findByText('Poisoned app')).toBeInTheDocument();
    const rendered = document.body.textContent ?? '';
    expect(rendered).not.toContain(POISON_SECRET);
    expect(rendered).not.toContain(poisonedAccount.vaultReferenceId);
    expect(rendered).not.toContain('raw-provider-id-should-never-render');
    expect(rendered).not.toContain('raw-quota-should-never-render');
  });

  it('re-runs the provider-neutral query after an error retry', async () => {
    const user = userEvent.setup();
    const listProviders = vi
      .fn()
      .mockRejectedValueOnce(new Error('boom'))
      .mockResolvedValue(PROVIDERS);
    const client = makeClient({
      operations: { 'provider-subscription.provider-list': listProviders },
    });
    renderApp('/settings/ai-interface', client);
    expect(await screen.findByText(/Couldn't load Gateway/i)).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'Try again' }));
    await waitFor(() => expect(listProviders).toHaveBeenCalledTimes(2));
    expect(await screen.findByRole('heading', { name: 'OpenAI Codex' })).toBeInTheDocument();
    expect(screen.queryByText(/Couldn't load Gateway/i)).not.toBeInTheDocument();
    expect(screen.getByText('Codex primary')).toBeInTheDocument();
    expect(screen.getByText('xAI primary')).toBeInTheDocument();
    expect(screen.getByText('Primary 59.6% remaining')).toBeInTheDocument();
    expect(screen.getByText('Secondary 0.4% remaining')).toBeInTheDocument();
    expect(screen.getByText('Included 87.5% remaining')).toBeInTheDocument();
    expect(screen.getByRole('meter', { name: 'Primary remaining 59.6%' })).toBeInTheDocument();
    expect(screen.getByRole('meter', { name: 'Included remaining 87.5%' })).toBeInTheDocument();
    expect(screen.queryByText('40.4% used')).not.toBeInTheDocument();
    expect(screen.getByText('Resets unknown')).toBeInTheDocument();
    expect(screen.queryByText('Quota unsupported')).not.toBeInTheDocument();
    expect(screen.queryByText(/5h|\bweekly\b/i)).not.toBeInTheDocument();
  });

  it('disables reconnect actions when disconnected', async () => {
    const client = makeClient({
      core: { meta: vi.fn().mockRejectedValue(new Error('down')) },
    });
    renderApp('/settings/ai-interface', client);
    expect(await screen.findByRole('heading', { name: 'Gateway' })).toBeInTheDocument();
    await waitFor(
      () => {
        expect(screen.getByRole('button', { name: /Refresh status/i })).toBeDisabled();
        expect(screen.getAllByRole('button', { name: 'Refresh quota' })[0]).toBeDisabled();
      },
      { timeout: 3000 }
    );
  });

  it('exposes landmarks and headings for a11y', async () => {
    renderApp('/settings/ai-interface', makeClient());
    expect(await screen.findByRole('heading', { level: 1, name: 'Gateway' })).toBeInTheDocument();
    expect(await screen.findByText('Codex primary')).toBeInTheDocument();
    expect(screen.getByRole('main')).toBeInTheDocument();
  });
});
