import type { CoreClient, WorkspaceRecord } from '@openkit/core-client';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { act, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { CoreClientProvider } from '../../app/core-client';
import { chatKeys, useWorkspaceSummaries, workspaceBelongsToCaller } from '../chat/data';
import { useWorkspaceStore, WORKSPACE_SELECTION_STORAGE_KEY } from '../workspace-store';
import * as accountData from './data';
import { type AccountWorkspaceSummary, useSelfLeave, useWorkspaceOwnerManagement } from './data';
import { MembersScreen } from './MembersScreen';
import { accountAdmissionKey } from './session';

const PROJECT_WORKSPACE: WorkspaceRecord = {
  counts: { artifactCount: 0, knowledgeEntryCount: 0, threadCount: 0 },
  createdAt: '2026-08-04T00:00:00.000Z',
  id: 'ws_00000000-0000-7d15-8bb9-5d57f3c7a053',
  kind: 'general',
  name: 'Project Workspace',
  status: 'active',
  updatedAt: '2026-08-04T00:00:00.000Z',
};
const OTHER_WORKSPACE: WorkspaceRecord = {
  ...PROJECT_WORKSPACE,
  id: 'ws_00000000-0000-71f5-922f-6fd42f52f580',
  name: 'Other Workspace',
};
const USER_A_QUICK_CHAT: WorkspaceRecord = {
  ...PROJECT_WORKSPACE,
  id: 'ws_00000000-0000-737c-9c81-84e684e8ce40',
  kind: 'quick-chat',
  name: 'Quick Chat',
};
const USER_B_QUICK_CHAT: WorkspaceRecord = {
  ...PROJECT_WORKSPACE,
  id: 'ws_00000000-0000-7e52-8632-71d920cde3ce',
  kind: 'quick-chat',
  name: 'Quick Chat',
};

function summary(
  workspace: WorkspaceRecord,
  effectiveRole: 'owner' | 'editor' | 'viewer'
): AccountWorkspaceSummary {
  return {
    effectiveRole,
    membershipStatus: 'active',
    accessCause: 'membership',
    membershipRevision: 17,
    ownerUserId: 'usr_00000000-0000-7108-840f-833c46c69722',
    registryRevision: 9,
    workspace,
  };
}

const REMOVED_MEMBER = {
  accessLevel: 'editor' as const,
  createdAt: '2026-08-01T00:00:00.000Z',
  effectiveRole: null,
  invitationId: 'inv_00000000-0000-7d98-aedf-51772368ee4c',
  joinedAt: '2026-08-01T00:00:00.000Z',
  removedAt: '2026-08-04T00:00:00.000Z',
  revision: 18,
  status: 'removed' as const,
  updatedAt: '2026-08-04T00:00:00.000Z',
  userId: 'usr_00000000-0000-732c-ad36-35686dc3d29f',
  workspaceId: PROJECT_WORKSPACE.id,
};

/** Reads Account's selected Workspace through the live self-leave owner. */
function AccountSelectionProbe() {
  const { leave, selectedWorkspaceId } = useSelfLeave();
  const summaries = useWorkspaceSummaries();
  return (
    <>
      <output aria-label="Account workspace">{selectedWorkspaceId ?? ''}</output>
      <output aria-label="Sidebar workspace choices">
        {(summaries.data ?? [])
          .filter((item) => workspaceBelongsToCaller(item))
          .map((item) => item.workspace.id)
          .join(',')}
      </output>
      <button
        type="button"
        onClick={() =>
          leave.mutate({
            expectedRevision: 17,
            workspaceId: PROJECT_WORKSPACE.id,
          })
        }
      >
        leave
      </button>
    </>
  );
}

/** Reads Account selection through owner management so project owner reads are observable. */
function AccountOwnerSelectionProbe() {
  const { selectedWorkspaceId } = useWorkspaceOwnerManagement();
  return <output aria-label="Account workspace">{selectedWorkspaceId ?? ''}</output>;
}

function renderAccountSelection(options: {
  admission: AccountWorkspaceSummary[];
  items: WorkspaceRecord[];
  leaveWorkspace?: ReturnType<typeof vi.fn>;
}) {
  let discovery = options.items;
  const listWorkspaces = vi.fn(async () => ({
    items: discovery.map(
      (workspace) =>
        options.admission.find((item) => item.workspace.id === workspace.id) ?? {
          workspace,
          effectiveRole: 'owner' as const,
          membershipStatus: 'active' as const,
          accessCause: 'membership' as const,
          membershipRevision: 1,
          ownerUserId: 'usr_00000000-0000-7000-8000-000000000001',
          registryRevision: 1,
        }
    ),
  }));
  const client = {
    app: {},
    core: {},

    operations: {
      'workspace.leave': options.leaveWorkspace ?? vi.fn(),
      'workspace.list': listWorkspaces,
    },
  } as unknown as CoreClient;
  const queryClient = new QueryClient({
    defaultOptions: { mutations: { retry: false }, queries: { retry: false } },
  });
  queryClient.setQueryData(accountAdmissionKey, { items: options.admission });
  const view = render(
    <QueryClientProvider client={queryClient}>
      <CoreClientProvider client={client}>
        <AccountSelectionProbe />
      </CoreClientProvider>
    </QueryClientProvider>
  );
  return {
    ...view,
    listWorkspaces,
    queryClient,
    setDiscovery(items: WorkspaceRecord[]) {
      discovery = items;
    },
  };
}

beforeEach(() => {
  localStorage.clear();
  useWorkspaceStore.setState({ currentWorkspaceId: null, selectionUserKey: null });
});

describe('account selected Workspace', () => {
  it('requires a membership revision for Leave and submits the exact admitted revision', async () => {
    const selectedWorkspace = { ...summary(PROJECT_WORKSPACE, 'editor'), membershipRevision: null };
    const mutate = vi.fn();
    const selfLeave = {
      // Keep hook eligibility true so this check decides the screen's revision guard.
      canLeave: true,
      leave: { error: null, isError: false, isPending: false, mutate },
      selectedWorkspace,
      selectedWorkspaceId: PROJECT_WORKSPACE.id,
    } as unknown as ReturnType<typeof useSelfLeave>;
    const owner = {
      canManage: false,
      effectiveWorkspace: selectedWorkspace,
      selectedWorkspaceId: PROJECT_WORKSPACE.id,
      transferOwnership: { data: undefined, error: null, isError: false },
    } as ReturnType<typeof useWorkspaceOwnerManagement>;
    const leaveHook = vi.spyOn(accountData, 'useSelfLeave').mockReturnValue(selfLeave);
    const ownerHook = vi.spyOn(accountData, 'useWorkspaceOwnerManagement').mockReturnValue(owner);
    try {
      const view = render(<MembersScreen />);
      expect(screen.getByText(PROJECT_WORKSPACE.name)).toBeInTheDocument();
      expect(screen.queryByRole('button', { name: 'Leave Workspace' })).not.toBeInTheDocument();
      expect(mutate).not.toHaveBeenCalled();

      const admitted = { ...selectedWorkspace, membershipRevision: 37 };
      leaveHook.mockReturnValue({ ...selfLeave, selectedWorkspace: admitted });
      ownerHook.mockReturnValue({ ...owner, effectiveWorkspace: admitted });
      view.rerender(<MembersScreen />);
      const user = userEvent.setup();
      await user.click(screen.getByRole('button', { name: 'Leave Workspace' }));
      expect(mutate).not.toHaveBeenCalled();
      await user.click(screen.getByRole('button', { name: 'Confirm leave' }));
      expect(mutate).toHaveBeenCalledExactlyOnceWith({
        expectedRevision: 37,
        workspaceId: PROJECT_WORKSPACE.id,
      });
    } finally {
      leaveHook.mockRestore();
      ownerHook.mockRestore();
    }
  });

  it('restores a validated explicit selection on Account after reload', async () => {
    useWorkspaceStore.getState().bindSelectionUserKey(USER_A_QUICK_CHAT.id);
    useWorkspaceStore.getState().setCurrentWorkspaceId(PROJECT_WORKSPACE.id);
    renderAccountSelection({
      admission: [summary(PROJECT_WORKSPACE, 'editor'), summary(OTHER_WORKSPACE, 'viewer')],
      items: [PROJECT_WORKSPACE, USER_A_QUICK_CHAT],
    });
    await waitFor(() => {
      expect(screen.getByLabelText('Account workspace')).toHaveTextContent(PROJECT_WORKSPACE.id);
    });
  });

  it('does not prefer a raw persisted id over the validated switcher Workspace', async () => {
    let releaseDiscovery!: (items: WorkspaceRecord[]) => void;
    const listWorkspaces = vi.fn(
      () =>
        new Promise<{ items: Array<{ workspace: WorkspaceRecord }> }>((resolve) => {
          releaseDiscovery = (items) =>
            resolve({
              items: items.map((workspace) => ({
                workspace,
                effectiveRole: 'owner' as const,
                membershipStatus: 'active' as const,
                accessCause: 'membership' as const,
                membershipRevision: 1,
                ownerUserId: 'user_local',
                registryRevision: 1,
              })),
            });
        })
    );
    const listWorkspaceMembers = vi.fn().mockResolvedValue({ items: [] });
    const listWorkspaceInvitations = vi.fn().mockResolvedValue({ items: [] });
    const client = {
      app: {},
      core: {},

      operations: {
        'workspace.leave': vi.fn(),
        'workspace.invitation-list': listWorkspaceInvitations,
        'workspace.member-list': listWorkspaceMembers,
        'workspace.list': listWorkspaces,
      },
    } as unknown as CoreClient;
    const queryClient = new QueryClient({
      defaultOptions: { mutations: { retry: false }, queries: { retry: false } },
    });
    queryClient.setQueryData(accountAdmissionKey, {
      items: [summary(PROJECT_WORKSPACE, 'owner'), summary(USER_B_QUICK_CHAT, 'owner')],
    });
    useWorkspaceStore.getState().bindSelectionUserKey(USER_A_QUICK_CHAT.id);
    useWorkspaceStore.getState().setCurrentWorkspaceId(PROJECT_WORKSPACE.id);
    render(
      <QueryClientProvider client={queryClient}>
        <CoreClientProvider client={client}>
          <AccountOwnerSelectionProbe />
        </CoreClientProvider>
      </QueryClientProvider>
    );

    await waitFor(() => expect(listWorkspaces).toHaveBeenCalled());
    expect(screen.getByLabelText('Account workspace')).toHaveTextContent('');
    expect(listWorkspaceMembers).not.toHaveBeenCalled();
    expect(listWorkspaceInvitations).not.toHaveBeenCalled();

    releaseDiscovery([PROJECT_WORKSPACE, USER_B_QUICK_CHAT]);
    await waitFor(() => {
      expect(screen.getByLabelText('Account workspace')).toHaveTextContent(USER_B_QUICK_CHAT.id);
    });
    expect(listWorkspaceMembers).not.toHaveBeenCalled();
    expect(listWorkspaceInvitations).not.toHaveBeenCalled();
  });

  it('clears the departed selection and Core discovery row after confirmed leave', async () => {
    const leaveWorkspace = vi.fn().mockResolvedValue({ member: REMOVED_MEMBER });
    useWorkspaceStore.getState().bindSelectionUserKey(USER_A_QUICK_CHAT.id);
    useWorkspaceStore.getState().setCurrentWorkspaceId(PROJECT_WORKSPACE.id);
    const { queryClient, setDiscovery } = renderAccountSelection({
      admission: [summary(PROJECT_WORKSPACE, 'editor'), summary(OTHER_WORKSPACE, 'viewer')],
      items: [PROJECT_WORKSPACE, OTHER_WORKSPACE, USER_A_QUICK_CHAT],
      leaveWorkspace,
    });
    await waitFor(() => {
      expect(screen.getByLabelText('Account workspace')).toHaveTextContent(PROJECT_WORKSPACE.id);
    });
    setDiscovery([OTHER_WORKSPACE, USER_A_QUICK_CHAT]);
    await userEvent.click(screen.getByRole('button', { name: 'leave' }));
    await waitFor(() => {
      expect(useWorkspaceStore.getState().currentWorkspaceId).toBeNull();
    });
    expect(localStorage.getItem(WORKSPACE_SELECTION_STORAGE_KEY) ?? '').not.toContain(
      PROJECT_WORKSPACE.id
    );
    const admission = queryClient.getQueryData<{ items: Array<{ workspace: { id: string } }> }>(
      accountAdmissionKey
    );
    expect(admission?.items.map((item) => item.workspace.id)).toEqual([OTHER_WORKSPACE.id]);
    await waitFor(() => {
      const discovered = queryClient.getQueryData<Array<{ id: string }>>(chatKeys.workspaces);
      expect(discovered?.map((item) => item.id)).toEqual([
        OTHER_WORKSPACE.id,
        USER_A_QUICK_CHAT.id,
      ]);
    });
  });

  it('removes the departed sidebar choice before pending rediscovery and retains removal after failure', async () => {
    const leaveWorkspace = vi.fn().mockResolvedValue({ member: REMOVED_MEMBER });
    useWorkspaceStore.getState().bindSelectionUserKey(USER_A_QUICK_CHAT.id);
    useWorkspaceStore.getState().setCurrentWorkspaceId(PROJECT_WORKSPACE.id);
    const { listWorkspaces, queryClient } = renderAccountSelection({
      admission: [summary(PROJECT_WORKSPACE, 'editor'), summary(OTHER_WORKSPACE, 'viewer')],
      items: [PROJECT_WORKSPACE, OTHER_WORKSPACE, USER_A_QUICK_CHAT],
      leaveWorkspace,
    });
    await waitFor(() => {
      expect(screen.getByLabelText('Account workspace')).toHaveTextContent(PROJECT_WORKSPACE.id);
    });
    await waitFor(() => {
      expect(screen.getByLabelText('Sidebar workspace choices')).toHaveTextContent(
        `${PROJECT_WORKSPACE.id},${OTHER_WORKSPACE.id},${USER_A_QUICK_CHAT.id}`
      );
    });
    let rejectDiscovery!: (error: Error) => void;
    listWorkspaces.mockImplementationOnce(
      () =>
        new Promise((_, reject) => {
          rejectDiscovery = reject;
        })
    );
    await userEvent.click(screen.getByRole('button', { name: 'leave' }));
    await waitFor(() => expect(listWorkspaces).toHaveBeenCalledTimes(2));
    expect(leaveWorkspace).toHaveBeenCalledExactlyOnceWith({
      expectedRevision: 17,
      workspaceId: PROJECT_WORKSPACE.id,
    });
    expect(queryClient.getQueryState(chatKeys.workspaces)?.fetchStatus).toBe('fetching');
    await waitFor(() => {
      expect(screen.getByLabelText('Sidebar workspace choices')).toHaveTextContent(
        `${OTHER_WORKSPACE.id},${USER_A_QUICK_CHAT.id}`
      );
      expect(screen.getByLabelText('Sidebar workspace choices')).not.toHaveTextContent(
        PROJECT_WORKSPACE.id
      );
    });

    await act(async () => rejectDiscovery(new Error('Workspace rediscovery failed.')));
    await waitFor(() => {
      expect(queryClient.getQueryState(chatKeys.workspaces)?.status).toBe('error');
    });
    expect(screen.getByLabelText('Sidebar workspace choices')).toHaveTextContent(
      `${OTHER_WORKSPACE.id},${USER_A_QUICK_CHAT.id}`
    );
    expect(screen.getByLabelText('Sidebar workspace choices')).not.toHaveTextContent(
      PROJECT_WORKSPACE.id
    );
  });
});
